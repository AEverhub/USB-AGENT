'use strict';
/**
 * 工具路由（省 token 的主力）：每次只送「這句話可能用到的」工具定義給模型，而不是全部 120 多個。
 *   ・常用核心工具永遠在（記憶、時間、計算、搜尋、記帳、排程、天氣…）
 *   ・依這句話（＋最近幾句、引言、有沒有圖片）的關鍵字加上相關工具組
 *   ・上一輪用過的工具組會延續幾輪（對話接續時不會突然少工具）
 *   ・永遠附一個 use_tools：模型覺得少了什麼就呼叫它，下一輪就會拿到那組工具 → 功能不受影響，只是晚一輪
 * 被路由「沒送出去」的工具仍然可以執行（權限照舊由 tools.run 檢查），所以模型記得工具名直接叫也不會失敗。
 */
const GROUPS = {
  core: { desc: '時間、計算、記憶、網路搜尋、記帳、排程提醒、天氣、簡報、自我說明', names: ['how_to', 'task_plan', 'get_time', 'calculate', 'date_calc', 'save_fact', 'forget', 'search_memory', 'update_profile', 'set_preference', 'web_search', 'fetch_url', 'ledger_add', 'ledger_view', 'schedule_task', 'list_tasks', 'cancel_task', 'update_task', 'weather', 'daily_brief'] },
  ledger: { desc: '記帳表查詢、修改、刪除、統計、電子發票', re: /帳|花了|花費|支出|收入|餘額|發票|收據|消費|多少錢|月結|einvoice|復原|刪錯/i, names: ['ledger_summary', 'ledger_edit', 'ledger_find', 'ledger_delete', 'ledger_restore', 'einvoice_record'] },
  files: { desc: '試算表、檔案讀寫、讀文件（Word／Excel／PDF／簡報）、下載、技能', re: /inbox\/|附件|傳了檔案|收到檔案|試算表|表格|excel|xlsx|csv|檔案|文件|資料夾|下載|上傳|存成|匯出|技能|skill|word|docx|pdf|報告|報表|簡報|產生.{0,6}(檔|表)|做(一|個|份)|寫成|整理成/i, names: ['doc_read', 'make_file', 'send_file', 'sheet_list', 'sheet_create', 'sheet_view', 'sheet_add_rows', 'sheet_edit', 'sheet_delete', 'sheet_export', 'file_list', 'file_read', 'file_write', 'file_delete', 'file_move', 'download_file', 'knowledge_add', 'skill_import_url', 'skill_list', 'skill_save', 'skill_delete', 'skill_trust'] },
  people: { desc: '用戶管理、權限、審批、傳訊息給別人、群發、群組紀錄與備忘、帳號連結', re: /備忘|記下來|剛剛.{0,3}(聊|說)|大家.{0,3}(說|講|怎麼)|誰說了|統計|誰要|誰說|點餐|訂飲料|飲料|團購|投票|喊單|整理.{0,4}(群|大家)|次數|幾次|限制|用戶|使用者|成員|權限|角色|允許|准許|授權|開放|不准|禁止|不能用|可以用|讓.{1,12}(用|使用|操作)|不用(問|審批|核准)|收回|封鎖|審批|核准|拒絕|傳給|轉告|通知他|告訴他|跟他說|群發|廣播|群組|誰說|聊天紀錄|連結帳號|綁定|撤回|刪(掉|除)?.{0,6}(訊息|那則|那句|剛剛)|頻道|改名|群組名稱|群名/i, names: ['message_delete', 'channel_rename', 'permission_change', 'request_permission', 'usage_limit', 'group_collect', 'group_note', 'list_users', 'set_user', 'set_role_permissions', 'link_account_start', 'list_approvals', 'decide_approval', 'send_message', 'find_message', 'broadcast', 'list_groups', 'group_log'] },
  app: { desc: 'App 自己的設定、狀態、畫面、規則、背景工人、推播、除錯、備份、用量', re: /設定|app|畫面|頁面|規則|以後都|不准|工人|worker|推播|除錯|debug|備份|還原|重啟|啟動|停止|bot|狀態|用量|token|消耗|手冊/i, names: ['app_api', 'app_manual', 'ui_snapshot', 'app_state', 'app_setting_get', 'app_setting_set', 'bot_control', 'rules_list', 'rules_add', 'rules_remove', 'worker_list', 'worker_save', 'worker_control', 'push_notification', 'debug_state', 'self_manage', 'usage_report'] },
  image: { desc: '畫圖、改圖、傳圖片', re: /畫|圖片|圖像|照片|插圖|海報|生成.*圖|改圖|p圖|傳圖|貼圖/i, names: ['generate_image', 'send_image'] },
  browser: { desc: '用瀏覽器上網操作：登入、點擊、填表、掛號、訂位、訂外送、截圖', re: /瀏覽器|網頁|網站|截圖紀錄|圖片紀錄|操作紀錄|登入|點(擊|選|一下|進去)|按鈕|填(寫|表)|表單|掛號|掛.{0,10}(科|醫|診|號)|看診|門診|醫院|診所|預約|訂位|訂房|訂票|外送|訂餐|點餐|下單|購買|買|搶|報名|截圖|打開.*(網|頁)|https?:\/\/|臉書|facebook|\bfb\b|粉專|粉絲專頁|instagram|\big\b|threads|在脆|脆上/i, names: ['browser_open', 'browser_read', 'browser_click', 'browser_click_xy', 'browser_type', 'browser_keys', 'browser_press', 'browser_scroll', 'browser_screenshot', 'browser_back', 'browser_wait', 'browser_tabs', 'browser_handoff', 'browser_vault_list', 'browser_login', 'browser_click_text', 'browser_fill', 'browser_select', 'browser_dismiss', 'browser_extract', 'browser_history'] },
  google: { desc: 'Gmail、Google 表單、試算表、文件、雲端硬碟、日曆、Tasks', re: /gmail|(寄|回|寫|收|看|查)信|信件|信箱|郵件|email|e-mail|google|表單|form|雲端硬碟|drive|日曆|行事曆|calendar|會議|tasks|待辦|docs|sheets/i, names: ['google_status', 'google_calendar_add', 'google_form_read', 'google_form_fill', 'gws_status', 'gmail_search', 'gmail_read', 'gmail_send', 'gmail_draft', 'gmail_reply', 'gmail_manage', 'gform_read', 'gform_submit', 'gform_autofill', 'google_forms_api', 'gsheets', 'gdocs', 'gdrive', 'gcal', 'gtasks', 'google_api'] },
  linux: { desc: 'Linux 電腦／終端機：跑指令、裝套件、寫程式、背景工作、Chromium', re: /linux|termux|終端|指令|命令|shell|bash|python|node|npm|pip|git|程式|腳本|script|安裝|編譯|伺服器|ssh|chromium|apk add/i, names: ['run_shell', 'termux_status', 'termux_exec', 'termux_job', 'termux_file', 'termux_chromium', 'linux_env'] },
  phone: { desc: '手機：電量、位置、網路、儲存空間、剪貼簿、聯絡人、簡訊、通話、通知、朗讀、手電筒、拍照、打電話、計時器、播放手機裡的音樂', re: /計時|倒數|碼錶|鬧鈴|分鐘後叫我|分鐘後提醒|音樂|放歌|播歌|播放(音樂|歌)|聽歌|下一首|上一首|暫停(音樂|播放)|歌曲|歌單|手機|電量|電池|位置|定位|在哪|wifi|wi-fi|網路|訊號|儲存空間|容量|記憶體|剪貼簿|聯絡人|簡訊|sms|通話|來電|打電話|撥|手電筒|音量|震動|朗讀|念給我/i, names: ['phone_timer', 'phone_music', 'phone_info', 'phone_do', 'phone_sms_send', 'phone_call'] },
  phone_ui: { desc: '操作手機上的其他 App：讀畫面、點擊、滑動、打字、開 App、連點器、巨集、遊戲協助', re: /遊戲|代打|刷關|掛機|巨集|macro|自動(點|刷|戰鬥|打)|手機上|手機裡|幫我(在|去|到|用).{0,12}(app|應用|軟體|程式)|打開.{0,12}(app|應用|軟體)|操作手機|懸浮(球|面板)|連點|自動點|點.{0,6}(下|次)|phone_|youtube|instagram|\big\b|facebook|臉書|抖音|tiktok|蝦皮|shopee|line ?pay|設定裡|通知欄/i, names: ['phone_macro', 'phone_screen', 'phone_screenshot', 'phone_tap', 'phone_type', 'phone_swipe', 'phone_key', 'phone_open_app', 'phone_apps', 'phone_wait', 'phone_autoclick', 'phone_autoclick_stop'] },
  logic: { desc: '邏輯電路：化簡（SOP／POS）、轉 NAND／NOR、真值表、IC 實際接線、加法器／減法器', re: /加法器|減法器|加減法器|半加|全加|半減|全減|補數|進位|借位|接線|麵包板|邏輯閘|邏輯電路|邏輯測試|轉換器|數位邏輯|布林|卡諾|k-?map|真值表|最小項|最大項|sop|pos\b|nand|nor\b|xor|74(ls|hc|hct)?\d{2,3}\b|cd?40\d{2}|ic.{0,6}(接|腳)|化簡/i, names: ['logic_convert', 'logic_state', 'logic_set', 'logic_adder'] },
  circuit: { desc: '電子電路：算電壓電流電阻功率、LED 限流電阻、分壓、RC、555、色碼、7805、運放、感測器', re: /電路(?!板設計)|電阻|電容|電感|電壓|電流|歐姆|功率|瓦數|限流|分壓|色碼|色環|\bled\b|二極體|齊納|電晶體|三極體|npn|pnp|運放|運算放大|op-?amp|lm35|lm358|741\b|555|78\d\d|穩壓|光敏|熱敏|ntc|ldr|感測器|感應器|麵包板|續航|\bmah\b|共振|充電時間|時間常數|\d\s*(k|m|u|µ)?(Ω|ohm|歐)|\d\s*(m|u|µ|n|p)?f\b|\d\s*(m)?a\b/i, names: ['circuit_solve', 'circuit_calc', 'circuit_state', 'circuit_set'] },
  code: { desc: '程式碼工具：寫程式、看程式、修 bug、解釋／優化／加註解／轉語言、執行程式', re: /程式碼|代碼|原始碼|source|code|寫(個|一個)?程式|程式(有|跑|執行|錯|怎麼)|bug|除錯|debug|報錯|錯誤訊息|traceback|exception|編譯|compile|函式|函數|function|變數|迴圈|演算法|javascript|\bjs\b|typescript|python|\bc\+\+|\bcpp\b|java\b|golang|rust|php|ruby|lua|html|css|sql|正規表達式|regex/i, names: ['code_state', 'code_set', 'code_run', 'code_save'] },
  meeting: { desc: '會議監聽：整場會議／演講轉文字並整理重點、Discord 語音頻道監聽、會議記錄', re: /會議|開會|演講|講座|語音頻道|語音房|會議室|監聽|逐字稿|會議記錄|meeting/i, names: ['meeting_list', 'meeting_read', 'meeting_discord_listen', 'meeting_stop', 'meeting_export'] },
  chart: { desc: '股價走勢、把數據畫成折線圖或長條圖', re: /股價|股票|台股|美股|指數|大盤|走勢|k線|漲跌|收盤|etf|加密貨幣|比特幣|折線圖|長條圖|圖表|畫成圖|趨勢圖|\b\d{4}\.?tw\b/i, names: ['stock_history', 'chart_make'] },
  life: { desc: '找地點、附近的店、路線距離與時間、匯率換算', re: /附近|地址|在哪|哪裡有|怎麼去|多遠|多久.{0,2}到|路線|導航|開車|走路|騎車|搭車|捷運|公車|客運|火車|台鐵|高鐵|飛機|班機|航班|機場|youbike|ubike|微笑單車|共享單車|單車|到站|誤點|比較快|哪個快|匯率|換算|美金|美元|日幣|日圓|日元|台幣|歐元|人民幣|韓元|港幣|USD|JPY|EUR|藥局|藥房|加油站|便利商店|超商|ATM|提款機|停車場|醫院|診所/i, names: ['places_search', 'route_info', 'currency_convert', 'transit_nearby', 'transit_plan'] },
  stem: { desc: '理工與工程：單位換算、公式與方法速查（數學、物理、電學、材料、熱流、控制、電腦科學、化學）', re: /物理|化學|數學|微積分|微分|積分|方程|矩陣|向量|機率|統計|幾何|三角函數|力學|熱力|流體|波長|頻率|光學|能量|功率|速度|加速度|動量|壓力|密度|莫耳|濃度|應力|應變|梁|撓度|扭矩|轉速|熱傳|雷諾|控制系統|pid|傅立葉|拉普拉斯|挫屈|彎矩|安全係數|管流|壓損|拋體|射程|理想氣體|減速比|解方程|聯立|多項式|行列式|特徵值|反矩陣|質因數|進位|二進位|十六進位|迴歸|擬合|標準差|演算法|複雜度|資料結構|系統設計|工程|換算|等於多少|幾(公尺|公里|公斤|公克|公升|瓦|焦耳|牛頓|帕|度|坪|英吋|英里|磅)|\b(km|kg|mph|psi|kwh|kpa|rpm|hz)\b/i, names: ['math_solve', 'eng_calc', 'unit_convert', 'stem_kb'] },
  security: { desc: '資安（防禦）：稽核程式碼找弱點、紅隊綠隊檢查、威脅建模、強化建議、OWASP／CWE 知識', re: /資安|資訊安全|安全(性|風險|漏洞|檢|稽|測|強化|嗎)|的安全|安不安全|漏洞|弱點|滲透|渗透|紅隊|綠隊|藍隊|red.?team|blue.?team|pentest|pen.?test|owasp|\bcwe\b|\bcve\b|injection|注入|xss|csrf|ssrf|sql.?inject|反序列化|越權|提權|idor|硬化|harden|加密|雜湊|hash|bcrypt|argon2|憑證綁定|資料外洩|資安稽核|security|vulnerab|exploit|威脅建模|threat.?model|stride|最小權限|防禦|防護|祕密管理|secret|金鑰外洩/i, names: ['security_audit', 'security_review', 'attack_surface', 'security_kb'] },
  // Anti-gravity-engine2：網站開發、影片製作
  web: { desc: '網站工作室：自己開發完整網頁系統（官網、管理系統、儀表板、前後端），檢查、預覽、打包 zip', re: /網站|網頁|官網|一頁式|landing|網頁版|前端|後端|全端|full.?stack|html|css|javascript|react|vue|做.{0,6}(系統|平台|後台|網頁|頁面|app)|管理系統|後台|儀表板|dashboard|作品集|部落格|購物車|登入頁|表單頁|web ?(site|app|page)/i, names: ['site_build', 'site_list', 'site_create', 'site_write', 'site_read', 'site_check', 'site_preview', 'site_zip', 'browser_open', 'browser_screenshot'] },
  video: { desc: '影片工作室：自己製作影片（分鏡、字幕、背景音樂、直式短影音／橫式），做好自動傳回', re: /影片|視頻|短影音|短片|動畫|video|reels|shorts|抖音|tiktok|剪輯|片頭|宣傳片|介紹片|投影片.{0,4}(影片|動態)|做.{0,4}(mv|片)|hyperframes|remotion|gsap|pixel2motion|shotcraft|主持人|數位人|旁白|配音/i, names: ['video_create', 'video_status', 'video_make', 'video_engine', 'generate_image', 'termux_exec'] },
  usb: { desc: 'USB 專版：整理 USB 檔案、找檔案、把檔案搬出來到電腦、改完存回 USB', re: /usb|隨身碟|整理.{0,4}(檔案|資料夾|一下)|找不到.{0,8}(檔|資料|文件|照片|報告)|在哪.{0,4}(檔|資料)|搬出來|拿出來|複製到(桌面|電腦)|存回去|放回去|存回.{0,3}usb|復原整理|借出/i, names: ['usb_organize', 'usb_undo', 'usb_find', 'usb_file_out', 'usb_file_back', 'usb_checkouts'] },
  watch: { desc: '監控哨兵：盯網頁、價格、關鍵字，有變動就通知', re: /盯|監控|追蹤|降價|價格|到貨|有貨|開賣|變動|更新了|通知我|提醒我.*(有|變|到)|哨兵/i, names: ['watch_add', 'watch_list', 'watch_check', 'watch_update', 'watch_remove'] },
};
/*
 * engine4.8 省額度：組內精選。工具定義每一輪都要重送，是最大宗的固定消耗；
 * core（每句話都送）和 files（很容易被「做一個…」對到）裡，多數工具這句話根本用不到 → 只送 base＋這句話對得到的小類。
 * 沒送的仍列在 use_tools（要「core」或該組名就整組載入），模型直接叫也照樣執行。
 */
const FOCUS = {
  core: { base: ['how_to', 'task_plan', 'get_time', 'calculate', 'search_memory', 'save_fact', 'web_search', 'fetch_url'], sub: [
    { re: /幾天|星期|禮拜|週[一二三四五六日末]|日期|幾號|天(後|前)|倒數|月底|年底|生日|紀念日|工作天|幾歲/, names: ['date_calc'] },
    { re: /忘(掉|記|了)|別記|不要記|刪.{0,4}記憶|叫我|稱呼|以後(都|請|要|不)|偏好|習慣|喜歡|討厭|語氣|回(覆|答).{0,4}(短|長|簡|詳)|我是|我的(名字|生日|工作|職業)/, names: ['forget', 'update_profile', 'set_preference'] },
    { re: /帳|花了|花費|[0-9０-９]\s*(元|塊|圓)|\$|錢|買了|付了|收入|支出|消費|薪水|發票/, names: ['ledger_add', 'ledger_view'] },
    { re: /提醒|排程|每(天|週|周|月|年|個?小時|隔)|定時|叫我|分鐘後|小時後|明天|後天|大後天|下(週|周|個?月|星期|禮拜)|今晚|待會|等一下|任務|取消|改(時間|成|到)|鬧鐘|[0-9０-９一二三四五六七八九十]\s*(點|:|：)/, names: ['schedule_task', 'list_tasks', 'cancel_task', 'update_task'] },
    { re: /天氣|氣溫|溫度|下雨|會雨|降雨|颱風|帶傘|雨傘|紫外線|空氣品質|aqi|冷不冷|熱不熱|幾度/i, names: ['weather'] },
    { re: /簡報|晨報|早報|今日摘要|每日摘要|brief/i, names: ['daily_brief'] },
    { re: /整理.{0,4}記憶|記憶.{0,4}整理|重複的記憶|清.{0,2}記憶/, names: ['memory_tidy'] }] },   // engine5（加在最後：前面的編號被經驗記憶拿來比對，不能變）
  files: { base: ['make_file', 'send_file', 'doc_read', 'file_list', 'file_read'], sub: [
    { re: /試算表|表格|excel|xlsx|csv|sheet|欄位|新增.{0,4}列|匯出/i, names: ['sheet_list', 'sheet_create', 'sheet_view', 'sheet_add_rows', 'sheet_edit', 'sheet_delete', 'sheet_export'] },
    { re: /檔案|資料夾|inbox\/|存成|寫(入|進|到)|存檔|搬|移動|改名|刪/i, names: ['file_write', 'file_delete', 'file_move'] },
    { re: /下載|https?:\/\//i, names: ['download_file'] },
    { re: /技能|skill/i, names: ['skill_import_url', 'skill_list', 'skill_save', 'skill_delete', 'skill_trust'] },
    { re: /知識庫|knowledge|手冊|加進.{0,4}知識/i, names: ['knowledge_add'] }] },
};
/** 這個組在這句話下要送哪些工具名（null＝整組） */
function focusNames(group, text) { const f = FOCUS[group]; if (!f) return null; const out = new Set(f.base); const t = String(text || ''); for (const x of f.sub) if (x.re.test(t)) for (const n of x.names) out.add(n); return out; }
const STICKY_TURNS = 3;
const LITE = ['get_time', 'search_memory', 'save_fact', 'web_search', 'ledger_add'];   // 輕量對話只送這幾個

class Router {
  constructor(ctx) { this.ctx = ctx; this.recent = new Map(); }   // scope → [{groups, turn}]
  enabled() { return this.ctx.settings.get('model.tool_routing', true) !== false; }
  /** 依文字挑工具組 */
  pick(text, { images = false, scope = '', person = null, context = '' } = {}) {
    const g = new Set(['core']); const t = String(text || '');
    for (const [k, v] of Object.entries(GROUPS)) if (v.re && v.re.test(t)) g.add(k);
    // 26.11.3 pro5（省 token）：這句話自己就看得出要什麼（有對到工具組、而且不是「那…呢／再來／一樣」這種接話）→ 不再把前兩句的工具組也帶進來
    const follow = t.length < 8 || /^(那|然後|再|還有|另外|繼續|接著|一樣|同上|好|對|是|嗯|可以|不(是|要|用)|改成|換成|上面|剛剛|這個|那個)/.test(t.trim());
    const bye = /^(謝+|謝謝你?|感謝|thanks?|thx|晚安|早安|午安|你好|哈囉|嗨|hi|hello|掰+|bye|哈+|讚|辛苦了|沒事了?|不用了)[\s!！。.~～]*$/i.test(t.trim());   // 道謝、打招呼：不需要延續上一件事的工具
    if (context && !bye && (follow || (g.size === 1 && t.length < 15))) for (const [k, v] of Object.entries(GROUPS)) if (v.re && v.re.test(String(context))) g.add(k);
    if (images) { g.add('ledger'); g.add('image'); }
    const r = this.recent.get(scope) || []; for (const x of r) for (const k of x.groups) g.add(k);
    void person; return g;
  }
  remember(scope, groups) {
    const r = (this.recent.get(scope) || []).map((x) => ({ ...x, left: x.left - 1 })).filter((x) => x.left > 0);
    const add = [...groups].filter((k) => k !== 'core'); if (add.length) r.push({ groups: add, left: STICKY_TURNS });
    this.recent.set(scope, r); if (this.recent.size > 500) this.recent.delete(this.recent.keys().next().value);
  }
  groupOf(name) { if (name.startsWith('mcp__')) return 'mcp:' + name.split('__')[1]; for (const [k, v] of Object.entries(GROUPS)) if (v.names.includes(name)) return k; return 'core'; }
  /** 從「這個人可用的全部工具」中挑出要送的定義；含 use_tools */
  select(all, groups, text, { lite = false, full = null, keep = null } = {}) {
    if (!this.enabled()) return all;
    // 26.11.3 pro5：打招呼、閒聊這種輕量對話只送幾個最基本的工具；其他的（含常用核心）列在 use_tools 裡，要用時下一步就有
    if (lite) return [...all.filter((t) => LITE.includes(t.name)), { name: 'use_tools', description: `目前是輕量對話，只載入了最基本的工具。需要其他能力時先呼叫這個（可一次要多組），下一步就能用：\ncore＝${GROUPS.core.desc}\n${Object.entries(GROUPS).filter(([k]) => k !== 'core' && all.some((t) => GROUPS[k].names.includes(t.name))).map(([k, v]) => `${k}＝${v.desc}`).join('\n')}`, parameters: { type: 'object', properties: { groups: { type: 'array', items: { type: 'string' }, description: '要載入的組別代號' } }, required: ['groups'] } }];
    const mcpServers = [...new Set(all.filter((t) => t.mcp).map((t) => t.name.split('__')[1]))];
    const lower = String(text || '').toLowerCase();
    for (const s of mcpServers) { const label = (this.ctx.connectors && this.ctx.connectors.label(s)) || s; if (lower.includes(s.toLowerCase()) || lower.includes(String(label).toLowerCase())) groups.add('mcp:' + s); }
    // engine4.8：組內精選（eco=off、或該組已被 use_tools／經驗記憶要求整組載入時不精選）
    const eco = this.ctx.settings.get('model.eco', 'auto'); const fn = {}; const part = [];
    if (eco !== 'off') for (const g of Object.keys(FOCUS)) if (groups.has(g) && !(full && full.has(g))) fn[g] = focusNames(g, text);
    const out = all.filter((t) => { const g = this.groupOf(t.name); if (!groups.has(g)) return false; if (fn[g] && !fn[g].has(t.name) && !(keep && keep.has(t.name))) { if (!part.includes(g)) part.push(g); return false; } return true; });
    const avail = Object.entries(GROUPS).filter(([k]) => k !== 'core' && !groups.has(k) && all.some((t) => GROUPS[k].names.includes(t.name))).map(([k, v]) => `${k}＝${v.desc}`);
    for (const g of part) avail.unshift(`${g}＝${GROUPS[g].desc}（目前只載入這句話用得到的幾個；要其他的就載入整組）`);
    for (const s of mcpServers) if (!groups.has('mcp:' + s)) avail.push(`mcp:${s}＝已連結的「${(this.ctx.connectors && this.ctx.connectors.label(s)) || s}」`);
    if (avail.length) out.push({ name: 'use_tools', description: `目前只載入了常用工具。需要下面這些能力時先呼叫這個（可一次要多組），下一步就能用：\n${avail.join('\n')}`, parameters: { type: 'object', properties: { groups: { type: 'array', items: { type: 'string' }, description: '要載入的工具組名稱' } }, required: ['groups'] }, meta: true });
    return out;
  }
}
module.exports = { FOCUS, focusNames, Router, GROUPS };
