'use strict';
/**
 * engine6.4：安全退出 USB（T-Dongle 綠燈後長按 5 秒，或跟 AI 說「安全退出」）
 *   1. 存檔、停掉所有服務（跟按 Ctrl+C 一樣）
 *   2. 在電腦的暫存資料夾放一個小程式（不在 USB 上，才不會擋住退出），等 AI 程式和啟動視窗都關掉
 *   3. 退出 USB（Windows：檔案總管的「退出」；Mac：diskutil eject）
 *   4. 告訴 Dongle 結果：成功 → 閃綠燈「已安全退出」；失敗（例如還有檔案開著）→ 紅燈說明原因
 *   AI 程式用結束代碼 42 離開：啟動檔看到 42 就不停在「按任意鍵繼續」、直接關掉視窗（視窗停在 USB 上會擋住退出）
 */
const fs = require('fs');
const os = require('os');
const path = require('path');
const { spawn } = require('child_process');

const EJECT_CODE = 42;

/** Windows 的小程式：等 → 退出 → 用序列埠告訴 Dongle（E ok／E fail 原因） */
const WIN_HELPER = String.raw`param([int]$NodePid, [string]$Drive)
$ErrorActionPreference = 'SilentlyContinue'
function Say([string]$line) {
  try {
    $n = (Get-CimInstance Win32_PnPEntity | Where-Object { $_.PNPDeviceID -match 'VID_303A' -and $_.Name -match '\(COM\d+\)' } | Select-Object -First 1).Name
    if (-not $n) { return }
    $p = New-Object System.IO.Ports.SerialPort ([regex]::Match($n, 'COM\d+').Value), 115200; $p.DtrEnable = $true; $p.Open()
    $b = [Text.UTF8Encoding]::new($false).GetBytes($line + [char]10); $p.BaseStream.Write($b, 0, $b.Length); $p.BaseStream.Flush(); Start-Sleep -Milliseconds 300; $p.Close()
  } catch {}
}
$t0 = Get-Date
while ((Get-Process -Id $NodePid -ErrorAction SilentlyContinue) -and ((Get-Date) - $t0).TotalSeconds -lt 30) { Start-Sleep -Milliseconds 300 }
# 啟動視窗（cmd）在 USB 上：等它自己關掉
for ($i = 0; $i -lt 20; $i++) {
  $cmds = @(Get-CimInstance Win32_Process -Filter "Name='cmd.exe'" | Where-Object { $_.CommandLine -match [regex]::Escape($Drive + '\AgentCenter') })
  if (-not $cmds.Count) { break }; Start-Sleep -Milliseconds 500
}
Start-Sleep -Seconds 1
$ok = $false
for ($i = 0; $i -lt 3 -and -not $ok; $i++) {
  try { (New-Object -ComObject Shell.Application).Namespace(17).ParseName($Drive).InvokeVerb('Eject') } catch {}
  for ($j = 0; $j -lt 10; $j++) { Start-Sleep -Milliseconds 500; if (-not (Test-Path ($Drive + '\'))) { $ok = $true; break } }
}
if ($ok) { Say 'E ok' } else { Say 'E fail 有檔案還開著' }
Remove-Item -LiteralPath $MyInvocation.MyCommand.Path -Force
`;

/** USB 的磁碟（Windows：「E:」；Mac：/Volumes/XXX） */
function driveOf(root) {
  if (!root) return '';
  if (process.platform === 'win32') return path.parse(path.resolve(root)).root.replace(/[\\/]+$/, '');
  return path.resolve(root);
}

/** 開始安全退出（回傳要不要結束程式）。exit 可以換掉（測試用） */
async function safeEject(ctx, { exit = (c) => process.exit(c), spawnFn = spawn } = {}) {
  const td = ctx.tdongle; const root = ctx.usb && ctx.usb.root(); const drive = driveOf(root);
  const show = (o) => { try { if (td) td.screen(o); } catch { /* ignore */ } };
  show({ state: 'busy', title: '安全退出中…', l1: '正在存檔', l2: '請先不要拔', total: 0 });
  try { if (ctx.phonelink) ctx.phonelink.stop(); } catch { /* ignore */ }
  try { await ctx.supervisor.stopAll(); } catch { /* ignore */ }
  try { ctx.terminal && ctx.terminal.closeAll(); } catch { /* ignore */ }
  try { ctx.store.flush(); } catch { /* ignore */ }
  let helper = '';
  if (drive && process.platform === 'win32') {
    helper = path.join(os.tmpdir(), `agent-eject-${process.pid}.ps1`);
    fs.writeFileSync(helper, '﻿' + WIN_HELPER, 'utf8');
    const ch = spawnFn('powershell.exe', ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-WindowStyle', 'Hidden', '-File', helper, '-NodePid', String(process.pid), '-Drive', drive], { detached: true, stdio: 'ignore', windowsHide: true, cwd: os.tmpdir() });
    if (ch && ch.unref) ch.unref();
  } else if (drive && process.platform === 'darwin') {
    const ch = spawnFn('/bin/sh', ['-c', `while kill -0 ${process.pid} 2>/dev/null; do sleep 0.3; done; sleep 1; diskutil eject "${drive.replace(/"/g, '')}"`], { detached: true, stdio: 'ignore', cwd: '/' });
    if (ch && ch.unref) ch.unref();
  }
  show({ state: 'busy', title: '安全退出中…', l1: '關閉程式', l2: '請先不要拔' });
  try { if (td) td.close(); } catch { /* ignore */ }   // 放開序列埠：小程式等一下要用它告訴 Dongle 結果
  setTimeout(() => exit(EJECT_CODE), 300);
  return { drive, helper };
}

module.exports = { safeEject, EJECT_CODE, WIN_HELPER, driveOf };
