'use strict';
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const seal = require('./seal');
const { isObj } = require('./util');
const { logger } = require('./log');
const log = logger('settings');

const VERSION = '26.11.3-Anti-gravity-engine6.4';

const PERMS = ['chat', 'search', 'files', 'sheets', 'ledger', 'schedule', 'terminal', 'mcp', 'skills', 'night',
  'news', 'broadcast', 'manage_users', 'manage_app', 'request_download', 'image', 'google', 'phone', 'watch', 'weather', 'console_view'];   // console_view：聯機／連到伺服器的人可以看操作端（監控）

const DEFAULTS = {
  model: { provider: 'gemini', name: 'gemini-3.6-flash', gemini_key: '', anthropic_key: '', openai_key: '', nvidia_key: '', groq_key: '', custom_key: '', custom_base_url: '', provider_models: {}, provider_order: [], fallback_provider: '', api_keys: [], api_key_cursor: 0, api_keys_notified: false, max_tokens: 4096, max_rounds: 14, history: 12, no_repeat: true, vague_help: true, summary: true, summary_every: 10, tool_routing: true, eco: 'auto', experience: true,
    embed_model: 'gemini-embedding-001', thinking: 'low', fallback_model: '', recall_timeout_ms: 1200, turn_timeout_s: 170, tool_timeout_s: 100 },
  image: { provider: 'auto', model: 'gemini-2.5-flash-image', openai_key: '', openai_model: 'gpt-image-1' },
  browser: { home_url: 'https://www.google.com/', auto_dismiss: true, step_ttl_min: 30, shot_keep_h: 24, show_steps: true, clear_after_task_min: 5, enabled: true, provider: 'auto', allow_webview: false, chrome_path: '', cdp_url: '', headless: true, port: 9333, width: 1280, height: 800, autostart: false, idle_close_min: 45, proxy: '' },
  // Google Workspace API 通道（不經瀏覽器）。憑證加密存在 data/google-auth.json；以下只放用戶端 ID／密鑰與安全政策，整個 google.* 鍵 AI 不可改
  memory: { group_keep_h: 32, group_drop_junk: true, group_save_important: true },   // 26.11.3 pro6：群組訊息保存時數、廢話不存、刪除前重要的存向量記憶
  transit: { tdx_id: '', tdx_secret: '', google_maps_key: '' },   // 26.11.3 pro2.1：公車即時到站（TDX）、大眾運輸路線比較（Google Routes API）；都不填也能用（OpenStreetMap＋Google 地圖連結）
  google: { enabled: true, client_id: '', client_secret: '', scopes: [], send_requires_approval: true, daily_send_cap: 50, default_calendar: 'primary' },
  // Termux 整合（完整 Linux＋真 Chromium）。整組 termux.* 對 AI 鎖定；token 在回傳時遮罩
  termux: { enabled: true, mode: 'termux', url: 'http://127.0.0.1:8766', token: '', allow_remote: false, chromium_port: 9222, full_access: true },
  // Anti-gravity-engine4：影片（引擎 auto＝HyperFrames 裝好且自我測試通過就用它，否則用手機內建；旁白人聲；實拍素材 Pexels；數位主持人 HeyGen；AI 實景影片 Gemini Omni 要付費、預設關）
  video: { engine: 'auto', narration: true, voice_pack: '', auto_images: true, footage: true, pexels_key: '', heygen_key: '', heygen_avatar: '', heygen_voice: '', ai_clips: false, omni_model: 'gemini-omni-1.1-flash', free_stock: true, avatar: 'auto', gender: 'auto', device_voice: '', device_rate: 1.05 },
  tz: 'Asia/Taipei',
  platforms: {
    line: { enabled: false, secret: '', token: '', mode: 'direct', relay_url: '', relay_token: '', auto_webhook: true },
    telegram: { enabled: false, token: '' },
    discord: { enabled: false, token: '' },
  },
  dev: { claim_password: '', debug_inspector: false, debug_eval: false, debug_port: 9229, public_base_url: '', hook_port: 8787, hook_bind: '127.0.0.1' },
  tunnel: { enabled: true, provider: 'auto', cloudflare_token: '', cloudflare_hostname: '', cloudflared_path: '', subdomain: '', manual_url: '', server: 'https://localtunnel.me' },
  roles: {
    admin: ['*'],
    staff: ['chat', 'search', 'files', 'sheets', 'ledger', 'schedule', 'skills', 'night', 'news', 'request_download', 'image', 'watch', 'weather'],
    user: ['chat', 'search', 'sheets', 'ledger', 'schedule', 'news', 'image', 'weather'],
    guest: [],
  },
  policy: {
    approve_downloads: true, approve_new_users: true,
    ai_fs_scope: 'app',            // app＝AI 可動整個 App 沙盒（含自己的程式）；workspace＝只能動工作區
    ai_can_edit_rules: true, ai_can_manage_app: true, ai_shell: true, snapshot_before_destructive: true,
    group_trigger: 'mention',      // mention｜all
    group_followup_s: 60, bot_reply: 'mention', bot_max_turns: 3,   // 26.11.3 pro6：接著說的秒數；其他機器人 @AI 時回不回、10 分鐘內最多回幾次
    quote_reply: 'smart',      // 引言回覆：smart＝群組一律引言、私訊在對方有引用時才引言｜always｜never
    reply_in_quiet: '夜間（21:00–07:00）僅開放管理員與員工使用，明早 7 點再來找我吧。',
  },
  quiet: { enabled: true, start: '21:00', end: '07:00' },
  schedule: {
    good_morning: { enabled: true, at: '07:00' }, good_night: { enabled: true, at: '21:00' },
    diary: { enabled: true, at: '06:30' }, news: { enabled: true, at: '08:00', feed: 'https://news.google.com/rss?hl=zh-TW&gl=TW&ceid=TW:zh-Hant' },
  },
  supervisor: { enabled: true, health_interval_s: 30, max_restarts: 10, window_s: 600, workers: [] },
  vector: { enabled: true, backend: 'auto', dims: 256 },
  memory: { consolidate: { enabled: true, at: '03:30' } },   // engine5：每天整理一次記憶（合併重複的事實；不呼叫模型）
  skills: { auto_attach: true, env: {} },
  usb: { root: '', organize: { enabled: true, require_online: true }, backup_mb: 500, index_max: 100000, pc_access: '' },   // engine5.5 USB 專版
  tdongle: { enabled: 'auto', port: '' },   // engine5.6 T-Dongle-S3 小螢幕：auto＝USB 版才找；port 可以手動指定（例如 COM5）                  // engine5：最相關的技能自動附上全文；技能需要的環境變數   // auto＝有 Gemini 金鑰用雲端嵌入，否則用本地雜湊嵌入
  link: { mode: '', me: null, directory_url: '', web_entry: '', host: {}, client: {} },
  notify: { webhook_url: '', ntfy_topic: '', ntfy_server: 'https://ntfy.sh', min_level: 'warn', android: true, to_admin_dm: true },
  mcp: { servers: [] },
  bot: { aliases: [], enabled: true },
  // 語音訊息轉文字（金鑰沿用模型頁）；每日簡報（送給管理員）
  speech: { enabled: true, provider: 'auto', language: 'zh' },
  // 26.11.3 Revise5 語音模式：語音包（device＝手機內建、g-*＝Gemini、o-*＝OpenAI、custom＝自訂）
  // 26.11.3 Revise6 會議監聽：每多幾字整理一次重點、最長幾小時、Discord 進頻道時是否在文字區公告
  // 26.11.3 Revise7 手機代理（付款／刪除等高風險按鈕的確認寫死在程式裡，這裡只有「送出訊息要不要確認」可以關）
  phone_link: { enabled: '', port: 8790 },   // engine6.0 手機連線（區域網路）：enabled ''＝跟著版本（開發版預設開）
  phone_agent: { confirm_send: true, step_ttl_min: 30, settle_ms: 700 },
  meeting: { summarize_every_chars: 1200, max_hours: 6, announce: true },
  voice: { pack: 'auto', rate: 1, pitch: 1, device_voice: '', auto_listen: true, speak_replies: true, stt: 'auto', custom: null, max_chars: 1200 },
  brief: { enabled: false, at: '07:30', city: 'Taipei', gmail_query: 'is:unread newer_than:1d -category:promotions -category:social' },
  // 人設（只影響說話方式）
  persona: { enabled: true, name: '', identity: '', personality: '', style: '', relation: '', call_user: '', emoji: 'none', avoid: '', humanize: true },
  extra_prompt: '',
};

/** AI 與一般 API 都不能修改的鍵（只有 F 開發者頁、由人類在 App 內設定） */
const LOCKED = ['phone_agent', 'transit', 'google', 'termux', 'model.api_keys', 'model.provider_order', 'model.custom_base_url', 'model.gemini_key', 'model.anthropic_key', 'model.openai_key', 'model.nvidia_key', 'model.groq_key', 'model.custom_key', 'dev.claim_password', 'dev.debug_inspector', 'dev.debug_eval', 'dev.debug_port', 'auth', 'link'];   // link：聯機模式、聯機碼與密碼只有人能改
const SECRET = [/\.(tdx_secret|google_maps_key|gemini_key|client_secret|anthropic_key|openai_key|nvidia_key|groq_key|custom_key|secret|token|relay_token|claim_password|cloudflare_token|pexels_key|heygen_key)$/, /^model\.api_keys$/, /^notify\.webhook_url$/, /^link\.host\.(key|password_hash)$/];

class Settings {
  constructor(dir) {
    this.file = path.join(dir, 'settings.json');
    this.data = JSON.parse(JSON.stringify(DEFAULTS));
    // 設定檔損毀（斷電／寫到一半）不能直接回到預設值再覆蓋掉：先把壞檔留下，改讀備份
    for (const f of [this.file, this.file + '.bak']) {
      try { if (!fs.existsSync(f)) continue; this._merge(this.data, Settings._unseal(JSON.parse(fs.readFileSync(f, 'utf8')))); if (f !== this.file) log.warn('settings.json 損毀，已從備份還原'); break; }
      catch (e) { log.error('settings 讀取失敗 ' + path.basename(f), e.message); if (f === this.file) { try { fs.copyFileSync(f, f + '.corrupt-' + Date.now()); } catch { /* ignore */ } } }
    }
    // 26.5.6 一次性升級：舊設定檔的角色權限清單沒有 image，補上（只做一次，之後尊重管理員的修改）
    if (!this.data.meta_2656) { for (const r of ['staff', 'user']) { const l = this.data.roles[r]; if (Array.isArray(l) && !l.includes('image') && !l.includes('*')) l.push('image'); } this.data.meta_2656 = true; this.save(); }
    // 26.9.1：橋接埠 8765 會撞到 App 自己的控制 API → 改 8766
    if (this.data.termux && /^http:\/\/127\.0\.0\.1:8765\/?$/.test(this.data.termux.url || '')) { this.data.termux.url = 'http://127.0.0.1:8766'; this.save(); }
    // 26.9.6 省 token：歷史改「最近 12 則原文＋更早的滾動摘要」（舊設定 30 則一次性改掉；之後尊重管理員的修改）
    if (!this.data.meta_2696) { if ((+this.data.model.history || 0) > 12) this.data.model.history = 12; this.data.meta_2696 = true; this.save(); }
    if (!this.data.meta_2691) { for (const [r, add] of [['staff', ['watch', 'weather']], ['user', ['weather']]]) { const l = this.data.roles[r]; if (Array.isArray(l) && !l.includes('*')) for (const x of add) if (!l.includes(x)) l.push(x); } this.data.meta_2691 = true; this.save(); }
    this.listeners = [];
  }
  _merge(base, over) {
    for (const k of Object.keys(over || {})) {
      if (isObj(base[k]) && isObj(over[k])) this._merge(base[k], over[k]); else base[k] = over[k];
    }
  }
  save() { if (this.frozen) return; try { fs.writeFileSync(this.file + '.tmp', JSON.stringify(Settings._seal(this.data), null, 1)); if (fs.existsSync(this.file)) { try { fs.copyFileSync(this.file, this.file + '.bak'); } catch { /* ignore */ } } fs.renameSync(this.file + '.tmp', this.file); } catch (e) { log.error('settings 寫入失敗', e.message); } }
  /** engine4.8 USB 密碼：存檔時金鑰欄位加密（沒設 USB 密碼就原樣） */
  static _seal(data) {
    if (!seal.on()) return data;
    const walk = (o, pre) => { const out = Array.isArray(o) ? [] : {};
      for (const k of Object.keys(o)) { const p = pre ? pre + '.' + k : k; const v = o[k];
        if (Settings.isSecret(p) && v !== '' && v != null && !(Array.isArray(v) && !v.length)) out[k] = seal.wrap(JSON.stringify(v));
        else out[k] = isObj(v) ? walk(v, p) : v; }
      return out; };
    return walk(data, '');
  }
  static _unseal(data) {
    const walk = (o) => { if (!o || typeof o !== 'object') return o; for (const k of Object.keys(o)) { const v = o[k]; if (seal.isSealed(v)) o[k] = JSON.parse(seal.unwrap(v)); else if (v && typeof v === 'object') walk(v); } return o; };
    return walk(data);
  }
  get(p, dflt) { let o = this.data; for (const k of String(p).split('.')) { if (o == null) return dflt; o = o[k]; } return o === undefined ? dflt : o; }
  static hashSecret(pw) { const salt = crypto.randomBytes(16).toString('hex'); return `scrypt$${salt}$${crypto.scryptSync(String(pw), salt, 32).toString('hex')}`; }
  static verifySecret(pw, stored) {
    if (!stored) return false; if (!String(stored).startsWith('scrypt$')) { const a = Buffer.from(String(pw)), b = Buffer.from(String(stored)); return a.length === b.length && crypto.timingSafeEqual(a, b); }   // 相容手動寫入的明文
    const [, salt, h] = String(stored).split('$'); const x = crypto.scryptSync(String(pw), salt, 32); const y = Buffer.from(h, 'hex'); return x.length === y.length && crypto.timingSafeEqual(x, y);
  }
  static isLocked(p) { return LOCKED.some((l) => p === l || p.startsWith(l + '.')); }
  static isSecret(p) { return SECRET.some((r) => r.test(p)); }
  /** who: 'human'（App 操作）或 'ai'；AI 不能動鎖定鍵 */
  /** 26.11.3：清理機密值（貼上時常帶到的空白、換行、引號、零寬字元、遮罩字、「Bot 」「Bearer 」前綴） */
  static cleanSecret(p, v) {
    if (typeof v !== 'string') return v; let s = v.replace(/••••已設定/g, '').replace(/[\u200B-\u200D\uFEFF\u00A0]/g, '').trim().replace(/^["'「『]+|["'」』]+$/g, '').trim();
    if (/^platforms\.discord\.token$/.test(p)) s = s.replace(/^Bot\s+/i, '');
    if (/\.(token|relay_token|cloudflare_token)$/.test(p)) s = s.replace(/^Bearer\s+/i, '').replace(/\s+/g, '');
    return s;
  }
  set(p, v, who = 'human') {
    if (Settings.isSecret(p) && p !== 'dev.claim_password') v = Settings.cleanSecret(p, v);
    if (who === 'ai' && Settings.isLocked(p)) throw new Error(`「${p}」是密碼類設定，AI 不可修改（請管理員自己到 App 的開發者頁設定）`);
    if (p === 'dev.claim_password' && typeof v === 'string' && v && !v.startsWith('scrypt$')) v = Settings.hashSecret(v);   // 只存雜湊，AI 與檔案都讀不到明文
    const ks = String(p).split('.'); let o = this.data;
    for (let i = 0; i < ks.length - 1; i++) { if (!isObj(o[ks[i]])) o[ks[i]] = {}; o = o[ks[i]]; }
    const before = o[ks[ks.length - 1]]; o[ks[ks.length - 1]] = v; this.save();
    for (const f of this.listeners) { try { f(p, v, before); } catch (e) { log.error(e); } }
  }
  onChange(f) { this.listeners.push(f); }
  /** 給前端：機密欄位只回「是否已設定」 */
  masked() {
    const walk = (o, pre) => { const out = Array.isArray(o) ? [] : {};
      for (const k of Object.keys(o)) { const p = pre ? pre + '.' + k : k; const v = o[k];
        if (p === 'model.api_keys' && Array.isArray(v)) out[k] = v.map((x) => ({ label: x.label || '', provider: x.provider || 'gemini', model: x.model || '', base_url: x.base_url || '', enabled: x.enabled !== false, exhausted: !!x.exhausted, rate_limited: !!x.rate_limited, cooldown_until: x.cooldown_until || 0, last_error: x.last_error || '', last_used: x.last_used || 0, key: x.key ? '••••已設定' : '' }));
        else if (isObj(v)) out[k] = walk(v, p); else if (Settings.isSecret(p)) out[k] = v ? '••••已設定' : ''; else out[k] = v; }
      return out; };
    return walk(this.data, '');
  }
  roleHas(role, perm) { const l = this.data.roles[role] || []; return l.includes('*') || l.includes(perm); }
}
module.exports = { Settings, PERMS, DEFAULTS, VERSION };
