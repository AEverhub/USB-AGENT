'use strict';
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const logm = require('./core/log');
const { Settings, VERSION } = require('./core/settings');
const { Store } = require('./core/store');
const { Users } = require('./services/users');
const { Usage } = require('./services/usage');
const { Notifier } = require('./services/notifier');
const { VectorMemory } = require('./services/vector');
const { Approvals } = require('./services/approvals');
const { Terminal } = require('./services/terminal');
const { Fsx } = require('./services/fsx');
const { Sheets } = require('./services/sheets');
const { Ledger } = require('./services/ledger');
const { Skills } = require('./services/skills');
const { Mcp } = require('./agent/mcp');
const { Tools } = require('./agent/tools');
const { Agent } = require('./agent/agent');
const { Hub } = require('./platforms/hub');
const { Supervisor } = require('./services/supervisor');
const { Debug } = require('./services/debug');
const { Tunnel } = require('./services/tunnel');
const { Scheduler } = require('./services/scheduler');
const { Hooks } = require('./api/hooks');
const { MsgRefs } = require('./platforms/common');
const { Media } = require('./services/media');
const { ImageGen } = require('./services/imagegen');
const { Vault } = require('./services/vault');
const { Browser } = require('./services/browser');
const { Google } = require('./services/google');
const { GWorkspace } = require('./services/gws');
const { Termux } = require('./services/termux');
const { Speech } = require('./services/speech');
const { Phone } = require('./services/phone');
const { Watch } = require('./services/watch');
const { Brief } = require('./services/brief');
const { LinuxEnv } = require('./services/linux');
const { EInvoice } = require('./services/einvoice');
const { Tiles } = require('./services/tiles');
const { McpAuth } = require('./agent/mcpauth');
const { Connectors } = require('./agent/connectors');
const { Router } = require('./agent/router');
const { Grants } = require('./services/grants');
const { ChatMedia } = require('./services/chatmedia');
const { FileGen } = require('./services/filegen');
const { Api } = require('./api/server');
const executors = require('./services/executors');
const log = logm.logger('app');

function makePaths(dataDir, appRoot) {
  const d = path.resolve(dataDir); const p = { appRoot: path.resolve(appRoot || path.dirname(d)), data: d, workspace: path.join(d, 'workspace'), snapshots: path.join(d, 'snapshots'), backups: path.join(d, 'backups'),
    skills: path.join(d, 'skills'), workers: path.join(d, 'workers'), diary: path.join(d, 'diary'), news: path.join(d, 'news'), tmp: path.join(d, 'tmp'), home: path.join(d, 'home'), logs: path.join(d, 'logs') };
  for (const k of Object.keys(p)) if (k !== 'appRoot') fs.mkdirSync(p[k], { recursive: true }); return p;
}

/** engine4.8：設定／變更／拿掉 USB 密碼後，把所有金鑰檔用目前的狀態重存一次（舊的 .bak 明文也一併蓋掉） */
function resealAll(ctx) {
  const d = ctx.paths.data; ctx.settings.save(); try { ctx.settings.save(); } catch { /* 第二次讓 .bak 也是新格式 */ }
  try { const raw = fs.readFileSync(path.join(d, 'vault.key'), 'utf8').trim(); const k = Buffer.from(require('./core/seal').unwrap(raw), 'hex'); if (k.length === 32) ctx.vault.resealKey(k); } catch { /* 還沒有保險箱 */ }
  try { if (ctx.mcpauth && fs.existsSync(ctx.mcpauth.file)) ctx.mcpauth._save(ctx.mcpauth._load()); } catch { /* ignore */ }
}
/** 組裝所有元件（不開啟任何網路監聽），方便測試 */
/** 26.11.3 Revise：新加的附加功能（資料轉移、聯機）就算初始化失敗也不能讓整個後台開不起來 → 記錄錯誤、該功能停用，其他照常 */
const BOOT_ERRORS = [];
function optional(name, make) { try { return make(); } catch (e) { BOOT_ERRORS.push({ name, message: e.message, stack: e.stack }); try { require('./core/log').logger('app').error(`附加功能「${name}」初始化失敗，已停用：${e.message}`); } catch { /* ignore */ } return null; } }
function createApp({ dataDir, appRoot, token }) {
  const paths = makePaths(dataDir, appRoot); logm.init(paths.logs);
  // engine4.8 USB 可攜版：資料夾設了 USB 密碼卻沒解鎖 → 不能啟動（否則讀不到金鑰會被當成「沒設定」而覆蓋掉）
  { const seal = require('./core/seal'); if (seal.hasLock(paths.data) && !seal.on()) { const pw = process.env.LA_USB_PASSWORD; if (!pw || !seal.unlock(paths.data, pw)) throw new Error('這個資料夾有 USB 密碼保護：請用 USB 裡的「啟動」程式開啟並輸入密碼（或設定環境變數 LA_USB_PASSWORD）'); } }
  const ctx = { paths, uiState: {}, version: VERSION };
  ctx.token = token || (() => { const f = path.join(paths.data, 'ui_token'); try { return fs.readFileSync(f, 'utf8').trim(); } catch { const t = crypto.randomBytes(24).toString('hex'); fs.writeFileSync(f, t, { mode: 0o600 }); return t; } })();
  ctx.settings = new Settings(paths.data); ctx.store = new Store(paths.data);
  ctx.refs = new MsgRefs(paths.data); ctx.media = new Media(ctx); ctx.imagegen = new ImageGen(ctx); ctx.vault = new Vault(ctx); ctx.browser = new Browser(ctx); ctx.google = new Google(ctx); ctx.gws = new GWorkspace(ctx); ctx.termux = new Termux(ctx); ctx.speech = new Speech(ctx); ctx.voice = optional('voice', () => new (require('./services/voice').Voice)(ctx)); ctx.meeting = optional('meeting', () => new (require('./services/meeting').Meetings)(ctx)); ctx.dvoice = optional('dvoice', () => new (require('./services/dvoice').DVoice)(ctx)); ctx.phoneagent = optional('phoneagent', () => new (require('./services/phoneagent').PhoneAgent)(ctx)); ctx.logic = optional('logic', () => new (require('./services/logicstate').LogicState)(ctx)); ctx.circuit = optional('circuit', () => new (require('./services/circuitstate').CircuitState)(ctx)); ctx.code = optional('code', () => new (require('./services/codestate').CodeState)(ctx)); ctx.phone = new Phone(ctx); ctx.transit = optional('transit', () => new (require('./services/transit').Transit)(ctx)); ctx.watch = new Watch(ctx); ctx.brief = new Brief(ctx); ctx.linux = new LinuxEnv(ctx); ctx.einvoice = new EInvoice(ctx); ctx.tiles = new Tiles(ctx); ctx.mcpauth = new McpAuth(ctx); ctx.connectors = new Connectors(ctx); ctx.router = new Router(ctx); ctx.grants = new Grants(ctx); ctx.chatmedia = new ChatMedia(ctx); ctx.filegen = new FileGen(ctx); ctx.transfer = optional('transfer', () => new (require('./services/transfer').Transfer)(ctx)); ctx.link = optional('link', () => new (require('./services/link').Link)(ctx)); ctx.deploy = optional('deploy', () => new (require('./services/deploy').Deploy)(ctx));   // 在 optional 裡才載入：連「載入檔案」失敗也只停用該功能
  ctx.users = new Users(ctx); ctx.usage = new Usage(ctx); ctx.notifier = new Notifier(ctx); ctx.vector = new VectorMemory(ctx); ctx.approvals = new Approvals(ctx);
  ctx.terminal = new Terminal(ctx); ctx.fsx = new Fsx(ctx); ctx.sheets = new Sheets(ctx); ctx.ledger = new Ledger(ctx); ctx.skills = new Skills(ctx); ctx.mcp = new Mcp(ctx);
  ctx.debug = new Debug(ctx); ctx.supervisor = new Supervisor(ctx); ctx.tools = new Tools(ctx); ctx.experience = optional('experience', () => new (require('./agent/experience').Experience)(ctx)); ctx.consolidate = optional('consolidate', () => new (require('./services/consolidate').Consolidator)(ctx)); ctx.agent = new Agent(ctx); ctx.hub = new Hub(ctx);
  ctx.tunnel = new Tunnel(ctx); ctx.tasks = new (require('./services/tasks').Tasks)(ctx); ctx.scheduler = new Scheduler(ctx); ctx.hooks = new Hooks(ctx); ctx.api = new Api(ctx);
  executors.register(ctx);
  ctx.portable = { on: process.env.LA_PORTABLE === '1', root: process.env.LA_PORTABLE_ROOT || '', sealed: require('./core/seal').on() };
  ctx.reseal = () => resealAll(ctx);
  ctx.usb = new (require('./services/usbfiles').UsbFiles)(ctx);   // engine5.5 USB 專版：自動整理、搬出來／存回去
  ctx.pc = new (require('./services/pcfiles').PcFiles)(ctx);
  ctx.phonelink = new (require('./services/phonelink').Phone)(ctx);   // engine6.0：手機連線（同一個 Wi-Fi，掃 QR Code 就能用）   // engine5.8 開發版：AI 存取這台電腦的檔案（複製到 USB、搬運）
  ctx.tdongle = new (require('./services/tdongle').TDongle)(ctx);   // engine5.6 T-Dongle-S3：小螢幕顯示狀態與進度
  { const orig = ctx.agent.handle.bind(ctx.agent); let n = 0;      // AI 在想的時候螢幕顯示「思考中」
    ctx.agent.handle = async (...a) => { const td = ctx.tdongle; const on = td.fd != null; if (on) { n++; td.screen({ state: 'busy', title: 'AI 思考中…' }); }
      try { return await orig(...a); } finally { if (on && --n <= 0) { n = 0; td.screen({ state: 'ready', title: 'AI 就緒' }); } } }; }
  if (ctx.portable.sealed) { try { resealAll(ctx); } catch (e) { require('./core/log').logger('app').warn('USB 密碼重新封存失敗：' + e.message); } }
  { const f = ctx.store.flush.bind(ctx.store); ctx.store.flush = () => { f(); try { ctx.refs.flush(); } catch { /* ignore */ } }; }   // 重啟前一併存下訊息登記簿

  // 守護進程底下的服務（啟動順序＝註冊順序）
  const sup = ctx.supervisor;
  sup.register(ctx.hooks); sup.register(ctx.tunnel);
  if (ctx.link) ctx.hub.connectors.net = ctx.link;   // 26.11.3 聯機：主機上的聯機用戶就像另一個平台
  for (const c of Object.values(ctx.hub.connectors)) sup.register(c);
  ctx.groupmem = new (require('./services/groupmem').GroupMem)(ctx); sup.register(ctx.groupmem);
  ctx.timers = new (require('./services/timers').Timers)(ctx); sup.register(ctx.timers);
  ctx.terms = new (require('./services/terms').Terms)(ctx);
  ctx.sites = new (require('./services/sites').Sites)(ctx);     // Anti-gravity-engine2：網站工作室（AI 開發網頁系統）
  ctx.videos = new (require('./services/video').Videos)(ctx);   // Anti-gravity-engine2：影片工作室（AI 做影片）
  ctx.vidmedia = new (require('./services/vidmedia').VidMedia)(ctx);       // Anti-gravity-engine4：旁白人聲、實拍素材、數位主持人、AI 實景
  ctx.vengine = new (require('./services/videoengine').VideoEngine)(ctx);  // Anti-gravity-engine4：HyperFrames 專業引擎（Termux）   // 26.11.3 pro10：用戶條款   // 26.11.3 pro10：計時器（到時間手機響鈴）   // 26.11.3 pro6：群組訊息只留 32 小時
  sup.register(ctx.scheduler);
  sup.register({ name: 'media', start: async () => ctx.media.start(), stop: async () => ctx.media.stop(), health: () => true });
  sup.register(ctx.linux);   // 內建 Linux（沒內建 PRoot 或沒安裝時什麼都不做）
  sup.register(ctx.browser);
  sup.register({ name: 'mcp', start: async () => { await ctx.mcp.reload(); }, stop: async () => ctx.mcp.stop(), health: () => true });

  // 設定變更 → 對應服務自動套用
  let t = null; const pending = new Set();
  ctx.settings.onChange((key) => {
    if (key === 'dev.debug_inspector' || key === 'dev.debug_port') return void ctx.debug.applyInspector();
    const m = /^platforms\.(line|telegram|discord)\./.exec(key); if (m) pending.add(m[1]);
    if (/^tunnel\./.test(key) || /^dev\.hook_/.test(key)) { pending.add('tunnel'); if (/^dev\.hook_/.test(key)) pending.add('hooks'); }
    if (key.startsWith('mcp.')) pending.add('mcp');
    if (/^platforms\.line\.(token|secret|mode)/.test(key)) pending.add('tunnel');
    if (pending.size) { clearTimeout(t); t = setTimeout(async () => { const names = [...pending]; pending.clear(); for (const n of names) { try { if (ctx.supervisor.running) await ctx.supervisor.restartService(n); } catch (e) { log.warn(`套用設定重啟 ${n} 失敗：${e.message}`); } } }, 800); }
  });
  return ctx;
}
module.exports = { createApp, makePaths, BOOT_ERRORS };
