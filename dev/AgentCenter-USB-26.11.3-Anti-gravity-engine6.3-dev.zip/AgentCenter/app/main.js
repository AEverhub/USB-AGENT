'use strict';
/**
 * 後台入口。
 *  Android：由 NodeService 以 `node main.js --data=<files>/data --port=8765 --token=<hex>` 啟動（nodejs-mobile）。
 *  桌機／伺服器：node main.js  （資料放在 ./data，啟動後會印出控制網址與 token）
 */
const path = require('path');
const fs = require('fs');
// 手機網路常見 IPv6 半通：Node 18 預設只連 DNS 第一個位址（常是 IPv6）→ 連線卡到逾時。改成 IPv4 優先＋自動嘗試兩種（Happy Eyeballs）。
try { require('dns').setDefaultResultOrder('ipv4first'); } catch { /* 舊版 Node */ }
try { const net = require('net'); if (net.setDefaultAutoSelectFamily) net.setDefaultAutoSelectFamily(true); if (net.setDefaultAutoSelectFamilyAttemptTimeout) net.setDefaultAutoSelectFamilyAttemptTimeout(300); } catch { /* ignore */ }
const args = Object.fromEntries(process.argv.slice(2).map((a) => { const m = /^--([\w-]+)(?:=(.*))?$/.exec(a); return m ? [m[1], m[2] ?? true] : []; }).filter((x) => x.length));
const env = process.env;
const dataDir = args.data || env.LA_DATA || path.join(__dirname, 'data');
const port = +(args.port || env.LA_PORT || 8765);

// ---- 開機防護：連續「還沒就緒就掛掉」3 次（多半是 AI 改壞了自己的程式）→ 要求 Android 端下次啟動從 APK 還原內建程式，避免無限重啟 ----
const bootFile = path.join(dataDir, 'boot_state.json'); let boot = { starts: [], ready: 0 };
try { fs.mkdirSync(dataDir, { recursive: true }); boot = JSON.parse(fs.readFileSync(bootFile, 'utf8')); } catch { /* 第一次 */ }
const nowTs = Date.now(); boot.starts = (boot.starts || []).filter((t) => nowTs - t < 5 * 60e3 && t > (boot.ready || 0)); boot.starts.push(nowTs);
const saveBoot = () => { try { fs.writeFileSync(bootFile, JSON.stringify(boot)); } catch { /* ignore */ } };
if (boot.starts.length >= 4) {
  const root = args['app-root'] || env.LA_APP_ROOT; boot = { starts: [], ready: nowTs }; saveBoot();
  if (root) { try { fs.writeFileSync(path.join(root, '.force_reset'), '1'); console.error('連續開機失敗，已要求下次啟動還原內建程式'); } catch { /* ignore */ } }
  process.exit(1);
}
saveBoot();

// 26.11.3 Revise：開機失敗的原因寫進 logs/app.log 與 boot_error.txt（手機的 console 看不到；「後台沒有起來」畫面會顯示並可複製）
const bootFail = (stage, e) => {
  const line = `${new Date().toISOString()} [ERROR] boot: ${stage}失敗：${(e && e.stack) || e}\n`; console.error(line);
  try { fs.mkdirSync(path.join(dataDir, 'logs'), { recursive: true }); fs.appendFileSync(path.join(dataDir, 'logs', 'app.log'), line); fs.writeFileSync(path.join(dataDir, 'boot_error.txt'), line); } catch { /* ignore */ }
};
let createApp, logger;
try { ({ createApp } = require('./src/app')); ({ logger } = require('./src/core/log')); }
catch (e) { bootFail('載入程式', e); process.exit(1); }
const log = logger('main');
/** engine4.8：用電腦預設瀏覽器開控制台（USB 版啟動後自動打開） */
function openBrowser(url) {
  try {
    const { spawn } = require('child_process'); const o = { detached: true, stdio: 'ignore' };
    const c = process.platform === 'win32' ? spawn('cmd', ['/c', 'start', '""', url.replace(/&/g, '^&')], { ...o, windowsHide: true }) : spawn(process.platform === 'darwin' ? 'open' : 'xdg-open', [url], o);
    c.on('error', () => {}); c.unref();
  } catch { /* 開不了就算了，網址印在視窗裡 */ }
}

let ctx;
try { ctx = createApp({ dataDir, appRoot: args['app-root'] || env.LA_APP_ROOT || null, token: args.token || env.LA_TOKEN || null }); }
catch (e) { bootFail('初始化', e); process.exit(1); }
// 26.11.3 Revise4 伺服器安裝腳本用的指令：--import=轉移檔（匯入資料後結束）、--setup=設定檔（設定＋設成伺服器主機後結束）
if (args.import || args.setup) {
  (async () => {
    try {
      if (args.import) {
        if (!ctx.transfer) throw new Error('資料轉移功能沒有啟動'); ctx.transfer.restart = () => {};
        const id = await ctx.transfer.receive(fs.createReadStream(String(args.import))); const r = await ctx.transfer.import(id, { password: args['import-password'] || '' });
        console.log(`已匯入 ${r.files} 個檔案${r.secrets ? '（含金鑰）' : r.secrets_skipped ? '（沒有密碼，金鑰沒有匯入，之後在伺服器的管理介面設定模型金鑰）' : ''}`);
      } else {
        const j = JSON.parse(fs.readFileSync(String(args.setup), 'utf8'));
        for (const [k, v] of Object.entries(j.settings || {})) if (v !== '' && v !== null && v !== undefined) ctx.settings.set(k, v, 'human');
        const st = ctx.link.serverInit({ name: j.server_name, public_url: args['public-url'] || '' }); const inv = ctx.link.inviteLink();
        ctx.store.flush(); ctx.settings.save();
        console.log(`伺服器名稱：${st.me.name}\n聯機碼：${st.host.code}\n連線連結（傳給要連進來的人，App 點了按同意就連上）：${(inv && inv.url) || '（沒有公開網址）'}`);
      }
      boot = { starts: [], ready: Date.now() }; saveBoot();   // 指令模式不算「開機失敗」
      process.exit(0);
    } catch (e) { boot = { starts: [], ready: Date.now() }; saveBoot(); console.error('失敗：' + e.message); process.exit(1); }
  })();
  return;
}
if (args.proot) process.env.PROOT_PATH = args.proot;   // 內建 Linux：APK 裡的 libproot.so（路徑每次更新 App 都可能變，所以不寫進設定）
if (args.cloudflared || env.CLOUDFLARED_PATH) ctx.settings.data.tunnel.cloudflared_path = args.cloudflared || env.CLOUDFLARED_PATH;

// 未捕捉的錯誤：記錄並繼續跑；但 60 秒內連續 8 次以上代表狀態已壞 → 存檔後結束行程，由 Android 前景服務重拉（比卡在半死狀態好）
const crashes = [];
function guardCrash(kind) { const t = Date.now(); crashes.push(t); while (crashes.length && t - crashes[0] > 60000) crashes.shift(); if (crashes.length >= 8) { log.error(`${kind} 60 秒內發生 ${crashes.length} 次，重新啟動後台`); try { ctx.store.flush(); } catch { /* ignore */ } setTimeout(() => process.exit(75), 300); } }
process.on('uncaughtException', (e) => { try { log.error('uncaughtException', e); ctx.debug.recordError('uncaught', e); ctx.notifier.critical('後台發生未捕捉的例外', e.message).catch(() => {}); } catch { /* ignore */ } guardCrash('uncaughtException'); });
process.on('unhandledRejection', (e) => { try { log.error('unhandledRejection', e); ctx.debug.recordError('rejection', e); ctx.notifier.error('後台有未處理的錯誤', e && e.message ? e.message : String(e)).catch(() => {}); } catch { /* ignore */ } guardCrash('unhandledRejection'); });
const bye = (sig) => async () => { log.info(sig + '，收尾中'); try { await ctx.supervisor.stopAll(); ctx.terminal.closeAll(); ctx.store.flush(); } catch { /* ignore */ } try { ctx.tdongle && ctx.tdongle.stop(); } catch { /* ignore */ } process.exit(0); };
process.on('SIGTERM', bye('SIGTERM')); process.on('SIGINT', bye('SIGINT'));
// engine4.8 USB 版：Windows 直接關掉命令視窗是 SIGHUP、Ctrl+Break 是 SIGBREAK → 一樣先存檔再結束（拔 USB 前資料不會少）
for (const sig of ['SIGHUP', 'SIGBREAK']) { try { process.on(sig, bye(sig)); } catch { /* 該平台沒有這個訊號 */ } }

(async () => {
  const bound = await ctx.api.start(port, args.bind || env.LA_BIND || '127.0.0.1');
  ctx.debug.applyInspector();
  if (ctx.settings.get('bot.enabled', true)) await ctx.supervisor.startAll(); else log.info('bot.enabled=false，等待在 App 按「啟動」');
  ctx.store.audit('system', 'boot', `v${ctx.version} port=${bound}`);
  log.info(`READY v${ctx.version} http://127.0.0.1:${bound}/#t=${ctx.token}`);
  boot = { starts: [], ready: Date.now() }; saveBoot();      // 成功就緒：清掉連續失敗計數
  try { fs.unlinkSync(path.join(dataDir, 'boot_error.txt')); } catch { /* 沒有就算了 */ }
  if (process.send) process.send({ ready: true, port: bound });
  // engine5.6：T-Dongle-S3 小螢幕：AI 就緒／還沒有金鑰
  // engine6.2：可以存取電腦檔案時（開發版、或插著 T-Dongle），背景建立整台電腦的檔案位置索引，之後每 30 分鐘更新
  const pcIndex = () => { if (ctx.pc && ctx.pc.enabled()) ctx.pc.buildIndex().then((st) => log.info(`電腦檔案索引：${st.files} 個（${Math.round(st.ms / 1000)} 秒）`)).catch((e) => log.warn('電腦檔案索引失敗：' + e.message)); };
  { const t = setInterval(pcIndex, 30 * 60e3); t.unref(); }
  if (ctx.tdongle) ctx.tdongle.start().then((ok) => { setTimeout(pcIndex, 3000).unref(); if (!ok) return; const hasKey = require('./src/llm').hasKey(ctx.settings);
    ctx.tdongle.screen(hasKey ? { state: 'ready', title: '開啟成功・AI 就緒', l1: '協助找檔案、搬運', l2: 'v' + String(ctx.version).replace(/^.*engine/, ''), total: 0 } : { state: 'error', title: '還沒有 AI 金鑰', l1: '在電腦上輸入金鑰', l2: '設定→模型', total: 0 }); }).catch(() => {});
  // engine5.5：USB 專版插上啟動後，有網路就自動整理一次 USB 上散落的檔案
  if (env.LA_PORTABLE === '1' && ctx.usb) { const t = setTimeout(() => { ctx.usb.autoRun().catch((e) => log.warn('USB 自動整理失敗：' + e.message)); }, 8000); t.unref(); }
  if (env.LA_OPEN === '1') openBrowser(`http://127.0.0.1:${bound}/#t=${ctx.token}`);
  // engine6.0：手機連線（開發版預設開；同一個 Wi-Fi 掃 QR Code）
  if (ctx.phonelink && ctx.phonelink.wanted()) ctx.phonelink.start(bound).then((st) => { if (env.LA_PORTABLE === '1') console.log(require('./src/services/phonelink').banner(st)); }).catch((e) => log.warn('手機連線沒開成：' + e.message));
  if (env.LA_PORTABLE === '1') {
    console.log(`\n========================================\n  Agent 中控中心（USB 版）已啟動  v${ctx.version}\n  控制台：http://127.0.0.1:${bound}/#t=${ctx.token}\n  資料夾：${dataDir}${ctx.portable && ctx.portable.sealed ? '\n  金鑰：已用 USB 密碼加密' : '\n  金鑰：沒有加密（建議設 USB 密碼）'}\n  要關閉：在這個視窗按 Ctrl+C，等它說「已存檔」再拔 USB\n========================================\n`);
    process.on('exit', () => { try { console.log('已存檔，可以安全拔除 USB。'); } catch { /* ignore */ } });
  }
})().catch((e) => { bootFail('啟動', e); process.exit(1); });
