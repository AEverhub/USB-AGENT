# story-to-handdrawn-video：故事 → 手繪動畫
<!-- builtin:video v1 -->
來源：https://github.com/gnipbao/story-to-handdrawn-video（未標示授權，僅參考做法）

## 風格
白底、黑色線稿逐步畫出、再慢慢上色；手寫感字幕；一句故事一個鏡頭；同一個角色每格外型一致（角色鎖定）。

## 流程
1. 故事切成句子，一句一個鏡頭
2. 規劃分鏡（可以先存成 JSON）
3. 用固定的角色與場景描述產生每格插圖
4. 匯入、裁切素材
5. 安排動畫與轉場
6. 預覽、匯出

## 在本 App
- video_create 遇到「說故事、繪本、寓言」會用 style=handdrawn：每格自動產生線稿插圖（image_prompt 結尾固定加線稿風格、同一角色同一描述），用 anim=draw 做「由左往右畫出、再上色」，並加上旁白人聲與字幕（原專案沒有配音，這裡補上）。
