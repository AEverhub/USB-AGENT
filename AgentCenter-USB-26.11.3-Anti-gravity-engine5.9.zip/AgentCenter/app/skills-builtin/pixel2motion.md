# Pixel2Motion：把圖片 Logo 變成動態 SVG（MIT）
<!-- builtin:video v1 -->
來源：https://github.com/nolangz/pixel2motion

## 做什麼
輸入一張點陣圖 Logo（PNG／JPG／WebP）或截圖 → 輸出乾淨的語意化 SVG、CSS 動畫編排、一個展示用 HTML，以及預覽用的 GIF／影片與檢查資料。原則：「最少、平滑的幾何最好動」。

## 流程
1. 寫動態簡報（品牌個性、要強調什麼、時長）
2. 向量化並和原圖比對
3. 檢查曲線平滑度
4. 產生展示 HTML
5. 擷取固定的動態影格
6. 檢查容易出錯的時間段是否連續

## 在本 App
- 快速版：video_create 的分鏡用 layout=logo，就有圓形展開＋光暈＋回彈的 Logo 開場（手機內建引擎）。
- 完整版：Termux 裡 ~/agent-video/skills/nolangz__pixel2motion，照它的 SKILL.md 用 termux_exec 執行，產出的 HTML 可以再用 HyperFrames 算成影片。
