# Remotion：用 React 寫影片
<!-- builtin:video v1 -->
來源：https://www.remotion.dev ・Agent 技能：remotion-dev/skills ・授權：個人與小團隊免費，公司規模較大需要購買公司授權（用之前請使用者自己確認）。

## 什麼時候用
- 需要 React 元件、資料驅動的大量影片（例如每個客戶一支）、複雜轉場，而且有電腦可以跑。
- 在手機上：Remotion 的原生合成元件只發布給一般 Linux／macOS／Windows，Termux（Android）多半跑不起來；安裝時會試，失敗就請使用者在電腦上用。一般需求用 HyperFrames 就好。

## 基本結構
- `npx create-video@latest` 建專案；`src/Root.tsx` 用 `<Composition id fps width height durationInFrames component />` 註冊。
- 動畫用 `useCurrentFrame()`、`interpolate()`、`spring()`；片段用 `<Sequence from durationInFrames>`；媒體用 `<OffthreadVideo>`、`<Img>`、`<Audio>`（都要用 staticFile 或網址）。
- 算圖：`npx remotion render <id> out.mp4`；無頭 Linux 可能要 `--concurrency=1` 與指定瀏覽器路徑。
- 不要在算圖時用 Math.random（用 remotion 的 random(seed)），否則每格不一樣。
