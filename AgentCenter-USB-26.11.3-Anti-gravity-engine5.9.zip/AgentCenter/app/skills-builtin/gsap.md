# GSAP 動畫（官方 GSAP AI Skills 重點，MIT）
<!-- builtin:video v1 -->
來源：https://github.com/greensock/gsap-skills ・GSAP 本體與所有外掛（SplitText、MorphSVG…）現在都免費、可商用（npm 套件 gsap）。

## 核心
- `gsap.to(目標, {屬性, duration, ease, delay, stagger})`、`from`、`fromTo`；屬性優先用 transform（x、y、scale、rotation）和 autoAlpha，效能好也不會跳版。
- 緩動：進場用 ease-out（power3.out、expo.out），出場用 ease-in（power2.in），畫面內移動用 inOut；空間移動不要用 linear（只有進度條、轉圈用 none）。
- stagger：清單逐項出現 0.05～0.15 秒一個。

## 時間軸
- `const tl = gsap.timeline({ paused: true, defaults: { ease: 'power3.out', duration: 0.6 } })`
- 位置參數：數字＝絕對秒數、`'<'` 跟上一段同時、`'-=0.2'` 提早、label 標記。
- 給影片算圖時：時間軸要可 seek（`tl.seek(t)` 結果固定），不要依賴真實時間或隨機數。

## 外掛（需要時才載入）
- SplitText（逐字／逐行出場）、MorphSVG（形狀變形）、DrawSVG（線條畫出來，手繪風很好用）、MotionPath、Flip、CustomEase。
