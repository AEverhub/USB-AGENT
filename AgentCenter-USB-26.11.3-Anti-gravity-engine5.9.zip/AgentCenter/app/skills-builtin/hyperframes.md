# HyperFrames（HeyGen 開源，Apache-2.0）：寫 HTML、算出 MP4
<!-- builtin:video v1 -->
來源：https://github.com/heygen-com/hyperframes ・需要 Node 22+、FFmpeg、Chromium。在本 App 是裝在 Termux（影片工作室 →「專業引擎」→ 安裝）。

## 原理
無頭 Chromium 逐格把 GSAP 時間軸 seek 到每一格的時間點、截圖，FFmpeg 編碼成影片；同樣的 HTML 每次算出一樣的結果。

## 組合（composition）怎麼寫
- 根元素：`data-composition-id`、`data-start="0"`、`data-duration`（總秒數）、`data-width`、`data-height`。
- 片段（clip）、`<video muted playsinline>`、`<audio>`：都用 `data-start`、`data-duration`、`data-track-index`；音訊可加 `data-volume`。
- 時間軸：`const tl = gsap.timeline({ paused: true }); window.__timelines["<composition-id>"] = tl;`
- 規則：時間軸建立時不要用 Math.random、Date.now、setTimeout、async／Promise；不要自己呼叫 video.play()／audio.play()（框架控制）；重複動畫用有限次數（不要 repeat:-1）；晚出場的元素用 tl.set(…, 時間點) 而不是 gsap.set；用 autoAlpha 代替改 visibility／display。

## 指令（在 Termux 用 termux_exec）
- `hyperframes render --output out.mp4 --fps 30 --quality standard`（品質 draft／standard／high；格式 mp4／webm）
- `hyperframes doctor`（看用哪個瀏覽器、缺什麼）
- `hyperframes lint`、`hyperframes preview`、`hyperframes tts "文字" --voice <id> --output n.wav`（英文以外需要 espeak-ng）
- 驗證：`ffprobe -v error -show_entries format=duration -of default=nw=1:nk=1 out.mp4`

## 手機上的注意
- 官方建議 chrome-headless-shell，但它沒有 Android arm64 版；本 App 用 Termux 的 Chromium，並設 `PRODUCER_FORCE_SCREENSHOT=true`（官方的截圖模式，比較慢）。
- 中文字型：安裝時會從 Android 系統字型複製 Noto CJK 到 ~/.fonts，否則中文會變方塊。
- 一般情況不用手寫：video_create 會自動把分鏡編譯成 HyperFrames 組合。要做特別的版面，再自己寫 HTML 放到 ~/agent-video/projects/<名稱>/ 算圖。
