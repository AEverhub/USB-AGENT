# Video Shotcraft：用真實產品頁面做宣傳片（Apache-2.0）
<!-- builtin:video v1 -->
來源：https://github.com/Vincentwei1021/video-shotcraft ・算圖用 Remotion（另有授權），音效來自 Freesound（各自授權，要保留標示）。

## 想法
不是 AI 生成影片：每一格都是用程式把「你自己的頁面截圖和文案」做成鏡頭，所以內容真實、可以改。

## 流程
1. 擷取真實頁面
2. 從鏡頭食譜挑鏡頭（運鏡、轉場、字體動畫…，例如 2.5D 頁面鏡頭、爆炸圖）
3. 分鏡
4. 做動畫
5. 剪輯點對齊音樂節拍、加音效
6. 算圖並逐格檢查

## 在本 App
- 快速版：video_create 帶 urls（產品網址），會自動截圖並用 layout=screen 做「瀏覽器框＋推近＋往下掃」的頁面鏡頭，style=product。
- 完整版（需要 Remotion，通常要電腦）：Termux 裡 ~/agent-video/skills/Vincentwei1021__video-shotcraft 有完整鏡頭食譜，可以拿來規劃鏡頭。
