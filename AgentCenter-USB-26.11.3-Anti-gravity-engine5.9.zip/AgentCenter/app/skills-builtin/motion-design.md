# Motion design 原則（整理自 LottieFiles motion-design-skill，MIT；另參考 rosby17/motion-design-skill 的做法）
<!-- builtin:video v1 -->
來源：https://github.com/LottieFiles/motion-design-skill ・https://github.com/rosby17/motion-design-skill（未標示授權，僅參考）

## 先定調
- 三件事：情緒意圖、視覺敘事、動態工藝。
- 三層：主要動作、次要（陰影、細節）、環境（背景的生命感）。
- 一次動一個屬性最直接，兩個比較精緻，三個以上容易亂。

## 個性
- 活潑：150～300ms、ease-out-back、10～20% 回彈
- 高級：350～600ms、cubic-bezier(0.4,0,0.2,1)、不回彈
- 專業：200～400ms、cubic-bezier(0.2,0,0,1)、幾乎不回彈
- 有能量：100～250ms、ease-out-expo、15～30% 回彈

## 時間與緩動
- 進場比出場長 30～50%；移動距離越長時間越長。
- 進場減速（ease-out）、出場加速（ease-in）、畫面內移動兩端都緩；空間移動不要 linear。
- stagger：一般 50～100ms 一個，總長不超過 0.4～0.6 秒。

## 編排
- 主角先動；同一組從同一方向進場。
- 環境元素以主角 20～30% 的速度反向移動。
- 三分之一規則：一個動作不要一次走超過畫面三分之一；三個以上元素時，同時動的不超過三分之一。
- 重要狀態變化不要只靠透明度，要搭配位置或縮放。

## 影片節奏（rosby17 的做法）
- 每一格是「時間的函式」，逐格算圖；旁白先錄、再依字詞時間點對齊畫面；音樂約 −14 LUFS、壓在人聲下面。
