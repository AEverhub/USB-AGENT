'use strict';
/**
 * engine4.8 USB 可攜版啟動器（由 USB 根目錄的「啟動-Windows.bat／啟動-Mac.command／啟動-Linux.sh」呼叫）。
 *  USB 結構：<USB>/AgentCenter/{app/（本程式）, data/（你的資料）, node/（第一次啟動自動下載的 Node.js）}
 *  ・資料全部放在 USB 的 data/，換電腦插上就是同一個 AI（記憶、設定、技能都在）。
 *  ・可設「USB 密碼」：金鑰類資料加密，USB 掉了別人拿不到你的 API 金鑰和帳密。
 *  ・同一份資料同時只能一台電腦開（避免兩邊同時寫壞）。
 *  指令：node portable.js [--port=8765] [--no-open] [--set-password] [--change-password] [--remove-password] [--set-key]
 */
const fs = require('fs');
const os = require('os');
const net = require('net');
const path = require('path');

const ROOT = path.resolve(process.env.LA_PORTABLE_ROOT || path.join(__dirname, '..'));
const DATA = path.resolve(process.env.LA_DATA || path.join(ROOT, 'data'));
const args = Object.fromEntries(process.argv.slice(2).map((a) => { const m = /^--([\w-]+)(?:=(.*))?$/.exec(a); return m ? [m[1], m[2] ?? true] : []; }).filter((x) => x.length));
const seal = require('./src/core/seal');
const LOCK = path.join(DATA, '.running.json');
const META = path.join(DATA, 'usb.json');
const say = (s) => process.stdout.write(s + '\n');

// ---------- 小工具 ----------
function readJson(f, d) { try { return JSON.parse(fs.readFileSync(f, 'utf8')); } catch { return d; } }
function writeJson(f, j) { fs.writeFileSync(f + '.tmp', JSON.stringify(j, null, 1)); fs.renameSync(f + '.tmp', f); }
function alive(pid) { try { process.kill(pid, 0); return true; } catch (e) { return e.code === 'EPERM'; } }

/** 共用一個 readline（輸入是管線時，一次讀進來的多行不能被丟掉） */
let RL = null; const lines = []; const waiters = []; let ended = false;
function nextLine() {
  if (!RL) { RL = require('readline').createInterface({ input: process.stdin, terminal: false }); RL.on('line', (l) => { if (waiters.length) waiters.shift()(l); else lines.push(l); }); RL.on('close', () => { ended = true; while (waiters.length) waiters.shift()(''); }); }
  if (lines.length) return Promise.resolve(lines.shift()); if (ended) return Promise.resolve('');
  return new Promise((r) => waiters.push(r));
}
function closeInput() { try { if (RL) RL.close(); process.stdin.pause(); } catch { /* ignore */ } }
/** 問一行字；hidden=true 時不顯示輸入的字（打密碼用） */
function ask(q, hidden = false) {
  return new Promise((resolve) => {
    const stdin = process.stdin;
    if (!hidden || !stdin.isTTY) { process.stdout.write(q); nextLine().then((a) => resolve(String(a || '').trim())); return; }
    if (RL) { RL.removeAllListeners('close'); RL.close(); RL = null; lines.length = 0; }   // 打密碼時不能讓逐字輸入也被 readline 收成一行
    process.stdout.write(q); let buf = '';
    stdin.setRawMode(true); stdin.resume(); stdin.setEncoding('utf8');
    const onData = (ch) => {
      for (const c of ch) {
        if (c === '\r' || c === '\n') { stdin.setRawMode(false); stdin.pause(); stdin.removeListener('data', onData); process.stdout.write('\n'); return resolve(buf); }
        if (c === '\u0003') { process.stdout.write('\n'); process.exit(130); }
        if (c === '\u007f' || c === '\b') { if (buf) { buf = buf.slice(0, -1); process.stdout.write('\b \b'); } continue; }
        buf += c; process.stdout.write('*');
      }
    };
    stdin.on('data', onData);
  });
}

function freePort(start) {
  return new Promise((resolve) => {
    const tryP = (p) => { if (p > start + 30) return resolve(0); const s = net.createServer(); s.once('error', () => tryP(p + 1)); s.listen(p, '127.0.0.1', () => s.close(() => resolve(p))); };
    tryP(start);
  });
}

/**
 * 用目前的金鑰（可能沒有）讀出所有金鑰檔，再用新的狀態寫回：
 *  newPw 是字串 → 設新密碼；null → 拿掉密碼（改回明文）。
 */
function rekey(newPw) {
  const { Settings } = require('./src/core/settings');
  const f = (n) => path.join(DATA, n);
  const plain = {};
  if (fs.existsSync(f('settings.json'))) plain.settings = Settings._unseal(JSON.parse(fs.readFileSync(f('settings.json'), 'utf8')));
  if (fs.existsSync(f('vault.key'))) plain.vault = seal.unwrap(fs.readFileSync(f('vault.key'), 'utf8').trim());
  if (fs.existsSync(f('mcp-auth.json'))) plain.mcp = seal.unwrap(fs.readFileSync(f('mcp-auth.json'), 'utf8'));
  if (newPw) seal.create(DATA, newPw); else seal.remove(DATA);
  const put = (n, s) => { fs.writeFileSync(f(n) + '.tmp', s, { mode: 0o600 }); fs.renameSync(f(n) + '.tmp', f(n)); };
  if (plain.settings) { const s = JSON.stringify(Settings._seal(plain.settings), null, 1); put('settings.json', s); put('settings.json.bak', s); }
  if (plain.vault) put('vault.key', seal.wrap(plain.vault));
  if (plain.mcp) put('mcp-auth.json', seal.wrap(plain.mcp));
  for (const n of fs.readdirSync(DATA)) if (/^settings\.json\.corrupt-/.test(n)) { try { fs.unlinkSync(f(n)); } catch { /* ignore */ } }   // 舊的損毀檔可能有明文金鑰
}

async function newPassword() {
  for (let i = 0; i < 3; i++) {
    const a = await ask('  設定 USB 密碼（至少 6 個字，輸入時不會顯示）：', true);
    if (a.length < 6) { say('  太短了，再試一次。'); continue; }
    const b = await ask('  再輸入一次確認：', true);
    if (a === b) return a; say('  兩次不一樣，再試一次。');
  }
  return '';
}

/** engine5.5：在啟動視窗裡輸入 AI 金鑰（不用先開網頁）。存進設定；有 USB 密碼的話會加密 */
const KEY_MENU = [
  ['gemini', 'Google Gemini（有免費額度，推薦）', 'https://aistudio.google.com/apikey'],
  ['openai', 'OpenAI（ChatGPT）', 'https://platform.openai.com/api-keys'],
  ['anthropic', 'Anthropic（Claude）', 'https://console.anthropic.com/settings/keys'],
  ['groq', 'Groq（有免費額度）', 'https://console.groq.com/keys'],
  ['nvidia', 'NVIDIA NIM', 'https://build.nvidia.com'],
  ['custom', '自訂 OpenAI 相容（含本機模型：Ollama、LM Studio）', ''],
];
function loadSettings() { const { Settings } = require('./src/core/settings'); return new Settings(DATA); }
function hasAnyKey(S) {
  const pool = S.get('model.api_keys', []); if (Array.isArray(pool) && pool.some((x) => x && x.key && x.enabled !== false)) return true;
  return KEY_MENU.some(([id]) => S.get(`model.${id}_key`)) || !!S.get('model.custom_base_url');
}
async function setupKey({ first = false } = {}) {
  const S = loadSettings();
  if (first) { say('\n還沒有設定 AI 金鑰：沒有金鑰 AI 不會回話。現在可以直接在這裡貼上（之後也能在控制台「設定 → 模型」改）。'); }
  say('\n選擇 AI 供應商：'); KEY_MENU.forEach(([, label], i) => say(`  ${i + 1}. ${label}`));
  const pick = await ask(first ? '輸入編號（直接 Enter 跳過）：' : '輸入編號：'); const n = +pick;
  if (!pick || !(n >= 1 && n <= KEY_MENU.length)) { if (pick) say('  沒有這個選項。'); return false; }
  const [id, label, url] = KEY_MENU[n - 1];
  let base = '', model = '';
  if (id === 'custom') {
    say('  本機模型的網址範例：Ollama → http://127.0.0.1:11434/v1　LM Studio → http://127.0.0.1:1234/v1');
    base = await ask('  API 網址：'); if (!/^https?:\/\/\S+$/i.test(base)) { say('  網址格式不對（要 http:// 或 https:// 開頭）。'); return false; }
    model = await ask('  模型名稱（例如 qwen2.5:7b）：'); if (!model) { say('  要給模型名稱。'); return false; }
  } else if (url) say(`  金鑰到這裡申請：${url}`);
  const key = await ask(id === 'custom' ? '  金鑰（本機模型通常不用，直接 Enter）：' : `  貼上 ${label.split('（')[0]} 金鑰（輸入時不會顯示）：`, true);
  if (!key && id !== 'custom') { say('  沒有輸入，略過。'); return false; }
  if (key && !/^[\x21-\x7e]{8,300}$/.test(key)) { say('  金鑰格式看起來不對（只能是英數符號、不能有空白）。'); return false; }
  S.set('model.provider', id);
  if (id === 'custom') { S.set('model.custom_base_url', base.replace(/\/+$/, '')); S.set('model.custom_key', key || 'local'); S.set('model.name', model); }
  else { S.set(`model.${id}_key`, key); const { PROVIDERS } = require('./src/llm'); S.set('model.name', (PROVIDERS[id] && PROVIDERS[id].defaultModel) || S.get('model.name')); }
  say(`  ✓ 已設定 ${label.split('（')[0]}${seal.on() ? '（已用 USB 密碼加密）' : ''}。啟動後可以在控制台「設定 → 模型」按「測試」確認能不能用。`);
  return true;
}

async function unlockLoop() {
  if (process.env.LA_USB_PASSWORD && seal.unlock(DATA, process.env.LA_USB_PASSWORD)) return true;
  for (let i = 0; i < 5; i++) {
    const pw = await ask('請輸入 USB 密碼：', true);
    if (pw && seal.unlock(DATA, pw)) return true;
    say('  密碼不對。' + (i < 4 ? '再試一次。' : ''));
  }
  return false;
}

/** 同一份資料同時只能一台電腦開。回傳 false 代表不要繼續 */
async function takeLock(port) {
  const host = os.hostname(); const cur = readJson(LOCK, null);
  if (cur && Date.now() - (cur.at || 0) < 90e3) {
    if (cur.host === host && alive(cur.pid)) {
      say(`這台電腦已經開著 Agent 中控中心了（http://127.0.0.1:${cur.port}）。`);
      if (args['no-open'] !== true && cur.port && cur.token) { process.env.LA_OPEN = ''; openUrl(`http://127.0.0.1:${cur.port}/#t=${cur.token}`); }
      return false;
    }
    if (cur.host !== host) {
      say(`⚠ 這個 USB 的資料看起來正在另一台電腦「${cur.host}」上使用（或那邊沒有正常關閉就拔掉了）。`);
      say('  兩台同時開會把資料寫壞。如果確定那台已經關了，可以繼續。');
      const a = await ask('  仍要在這台開啟嗎？輸入 y 繼續，其他鍵取消：');
      if (!/^y(es)?$/i.test(a)) return false;
    }
  }
  const write = () => { try { writeJson(LOCK, { host, pid: process.pid, port, at: Date.now(), token: readToken() }); } catch { /* USB 被拔了 */ } };
  write(); const t = setInterval(write, 30e3); t.unref();
  process.on('exit', () => { try { const j = readJson(LOCK, null); if (j && j.pid === process.pid && j.host === host) fs.unlinkSync(LOCK); } catch { /* ignore */ } });
  return true;
}
function readToken() { try { return fs.readFileSync(path.join(DATA, 'ui_token'), 'utf8').trim(); } catch { return ''; } }
function openUrl(url) {
  const { spawn } = require('child_process');
  try { const c = process.platform === 'win32' ? spawn('cmd', ['/c', 'start', '""', url.replace(/&/g, '^&')], { detached: true, stdio: 'ignore', windowsHide: true }) : spawn(process.platform === 'darwin' ? 'open' : 'xdg-open', [url], { detached: true, stdio: 'ignore' }); c.on('error', () => {}); c.unref(); } catch { /* ignore */ }
}

async function main() {
  const [maj] = process.versions.node.split('.').map(Number);
  if (maj < 18) { say(`Node.js 版本太舊（${process.version}），需要 18 以上。刪掉 USB 裡的 node 資料夾後重新啟動會自動下載新版。`); process.exit(1); }
  fs.mkdirSync(DATA, { recursive: true });
  try { fs.accessSync(DATA, fs.constants.W_OK); fs.writeFileSync(path.join(DATA, '.w'), '1'); fs.unlinkSync(path.join(DATA, '.w')); }
  catch { say('USB 不能寫入（可能是唯讀或已滿）：' + DATA); process.exit(1); }
  say(`Agent 中控中心 USB 版　資料夾：${DATA}`);
  // engine5.5：這支 USB 的識別碼（自動啟動小幫手用它認出「是這支」）
  try { const idf = path.join(ROOT, 'usb-id'); if (!fs.existsSync(idf)) fs.writeFileSync(idf, require('crypto').randomBytes(16).toString('hex')); } catch { /* 唯讀就算了 */ }

  const meta = readJson(META, {});
  // engine5.8 只跑一次：這台電腦已經開著（還在跑）→ 打開那個的控制台就結束，不再問密碼、不再啟動第二個
  { const cur = readJson(LOCK, null); if (cur && cur.host === os.hostname() && Date.now() - (cur.at || 0) < 90e3 && alive(cur.pid) && !args['set-key'] && !args['change-password'] && !args['remove-password']) {
    say(`這台電腦已經開著 Agent 中控中心了（http://127.0.0.1:${cur.port}），不用再開一次。`); if (cur.port && cur.token) openUrl(`http://127.0.0.1:${cur.port}/#t=${cur.token}`); process.exit(0); } }
  const locked = seal.hasLock(DATA);
  // engine5.6：T-Dongle-S3 小螢幕（沒有插 Dongle 就什麼都不做）
  const { TDongle } = require('./src/services/tdongle'); const td = new TDongle(null); try { await td.connect(); } catch { /* ignore */ }
  td.screen({ state: 'boot', title: '啟動中…', l1: 'Agent 中控中心', l2: '', total: 0 });

  // ---- 密碼相關指令 ----
  if (args['set-password'] || args['change-password'] || args['remove-password']) {
    if (locked && !(await unlockLoop())) { say('沒有解鎖，什麼都沒改。'); process.exit(1); }
    if (args['remove-password']) { if (!locked) { say('目前沒有 USB 密碼。'); process.exit(0); } rekey(null); say('已拿掉 USB 密碼，金鑰改回不加密。'); process.exit(0); }
    if (!locked && args['change-password']) say('目前沒有 USB 密碼，改成新設一個。');
    const pw = await newPassword(); if (!pw) { say('沒有設定。'); process.exit(1); }
    rekey(pw); meta.asked = true; writeJson(META, meta); say('✓ USB 密碼已設定，金鑰已加密。忘記密碼就要重新輸入所有 API 金鑰，請記好。'); process.exit(0);
  }

  // ---- 平常啟動 ----
  if (locked) { td.screen({ state: 'busy', title: '請輸入 USB 密碼', l1: '在電腦的視窗裡輸入' }); if (!(await unlockLoop())) { td.screen({ state: 'error', title: '密碼錯太多次', l1: '重新插上再試' }); say('密碼錯太多次，結束。'); process.exit(1); } say('✓ 已解鎖'); }
  else if (!meta.asked && process.stdin.isTTY) {
    say('\n第一次使用：建議設一組「USB 密碼」。USB 掉了，別人也拿不到你的 AI 金鑰和帳密。');
    say('（之後每次啟動要輸入；不設的話直接按 Enter 跳過，之後可以執行「設定USB密碼」再設）');
    const a = await ask('要現在設定嗎？輸入 y 設定，直接 Enter 跳過：');
    if (/^y(es)?$/i.test(a)) { const pw = await newPassword(); if (pw) { rekey(pw); say('✓ 已設定 USB 密碼'); } }
    meta.asked = true; writeJson(META, meta);
  }

  // ---- AI 金鑰：--set-key 指令，或第一次啟動還沒有金鑰時問一次 ----
  if (args['set-key']) { td.screen({ state: 'busy', title: '請輸入 AI 金鑰', l1: '在電腦的視窗裡輸入' }); await setupKey(); td.close(); closeInput(); process.exit(0); }
  else if (process.stdin.isTTY) { try { if (!hasAnyKey(loadSettings())) { td.screen({ state: 'busy', title: '請輸入 AI 金鑰', l1: '在電腦的視窗裡輸入' }); await setupKey({ first: true }); } } catch (e) { say('（讀設定失敗：' + e.message + '）'); } }   // 還沒有金鑰就每次都問（直接 Enter 可以跳過）

  const want = +(args.port || process.env.LA_PORT || 8765);
  const port = await freePort(want);
  if (!port) { say(`${want} 附近的連接埠都被占用了，用 --port= 指定別的`); process.exit(1); }
  if (port !== want) say(`（${want} 被別的程式占用，改用 ${port}）`);
  if (!(await takeLock(port))) process.exit(0);

  meta.last_host = os.hostname(); meta.last_start = new Date().toISOString(); meta.starts = (meta.starts || 0) + 1; try { writeJson(META, meta); } catch { /* ignore */ }
  closeInput();
  td.screen({ state: 'boot', title: 'AI 啟動中…', l1: '', l2: '' }); td.close();   // 交棒：AI 程式會自己再打開序列埠
  process.env.LA_PORTABLE = '1'; process.env.LA_PORTABLE_ROOT = ROOT;
  if (args['no-open'] !== true) process.env.LA_OPEN = '1';
  process.argv = [process.argv[0], path.join(__dirname, 'main.js'), `--data=${DATA}`, `--port=${port}`];
  require('./main.js');
}

if (require.main === module) main().catch((e) => { say('啟動失敗：' + (e && e.stack || e)); process.exit(1); });
module.exports = { rekey, freePort, ROOT, DATA, setupKey, hasAnyKey, KEY_MENU };
