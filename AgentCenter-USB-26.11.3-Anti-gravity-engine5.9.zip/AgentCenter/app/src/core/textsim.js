'use strict';
/**
 * engine5：中英混合的輕量文字相關度（不用斷詞、不用模型、離線、毫秒級）。
 *  ・詞元：中文取單字＋雙連字；英文／數字取整個字（小寫），長字再加前 5 碼當詞幹（skills ↔ skill）。
 *  ・Ranker：BM25 排名（常見字權重低、稀有詞權重高，長描述不會因為字多就佔便宜）。
 *    拿來挑「這句話最相關的技能」，也用在記憶整理找重複。
 */
const STOP = new Set(['的', '了', '是', '我', '你', '他', '她', '在', '有', '和', '與', '就', '都', '也', '要', '會', '把', '這', '那', '一', '個', '嗎', '呢', '吧', '啊', '喔', '請', '幫', '下', '用', '做',
  'the', 'a', 'an', 'to', 'of', 'and', 'or', 'for', 'in', 'on', 'with', 'is', 'are', 'be', 'it', 'this', 'that', 'use', 'when', 'how', 'you', 'your', 'can', 'from', 'by', 'as', 'at']);

function tokens(text) {
  const s = String(text || '').toLowerCase(); const out = [];
  for (const m of s.matchAll(/[a-z0-9][a-z0-9_+#.-]*/g)) { const w = m[0].replace(/[.-]+$/, ''); if (w.length < 2 || STOP.has(w)) continue; out.push(w); if (w.length > 6) out.push(w.slice(0, 5) + '*'); }
  for (const seg of s.match(/[㐀-鿿豈-﫿]+/g) || []) {
    for (let i = 0; i < seg.length; i++) { if (!STOP.has(seg[i])) out.push(seg[i]); if (i < seg.length - 1) out.push(seg.slice(i, i + 2)); }
  }
  return out;
}

class Ranker {
  /** docs：[{ id, text }]；k1、b 是 BM25 的標準參數 */
  constructor(docs, { k1 = 1.2, b = 0.6 } = {}) {
    this.k1 = k1; this.b = b; this.docs = docs.map((d) => { const tf = new Map(); const tk = tokens(d.text); for (const t of tk) tf.set(t, (tf.get(t) || 0) + 1); return { id: d.id, tf, len: tk.length || 1 }; });
    this.N = this.docs.length; this.avg = this.docs.reduce((s, d) => s + d.len, 0) / (this.N || 1) || 1;
    this.df = new Map(); for (const d of this.docs) for (const t of d.tf.keys()) this.df.set(t, (this.df.get(t) || 0) + 1);
  }
  idf(t) { const n = this.df.get(t) || 0; return Math.log(1 + (this.N - n + 0.5) / (n + 0.5)); }
  /** 回傳 [{ id, score, cover }]，cover＝查詢的詞（加權後）有多少比例在文件裡出現（0～1，可當成「像不像」的門檻） */
  rank(query, { top = 0 } = {}) {
    const q = [...new Set(tokens(query))]; if (!q.length || !this.N) return [];
    const qw = q.map((t) => this.idf(t) * (/^[\u3400-\u9fff\uf900-\ufaff]$/.test(t) ? 0.3 : 1));   // 中文單字權重低（「影」「片」到處都有），雙字詞和英文字才是重點
    const qsum = qw.reduce((a, b) => a + b, 0) || 1;
    const res = this.docs.map((d) => {
      let s = 0, hit = 0;
      q.forEach((t, i) => { const f = d.tf.get(t); if (!f) return; hit += qw[i]; s += qw[i] * (f * (this.k1 + 1)) / (f + this.k1 * (1 - this.b + this.b * d.len / this.avg)); });
      return { id: d.id, score: s, cover: hit / qsum, rel: s / qsum };   // rel：分數除以「整句話的權重」→ 不同長度的句子可以用同一個門檻
    }).filter((r) => r.score > 0).sort((a, b) => b.score - a.score);
    return top ? res.slice(0, top) : res;
  }
}

/** 兩段文字的相似度（0～1）：共同詞元佔較短那段的比例；拿來找「幾乎一樣的兩則記憶」 */
function overlap(a, b) {
  const A = new Set(tokens(a)); const B = new Set(tokens(b)); if (!A.size || !B.size) return 0;
  let n = 0; for (const x of A) if (B.has(x)) n++; return n / Math.min(A.size, B.size);
}
/** 對稱版本（Dice）：兩段長度差很多時不會誤判成重複 */
function dice(a, b) {
  const A = new Set(tokens(a)); const B = new Set(tokens(b)); if (!A.size || !B.size) return 0;
  let n = 0; for (const x of A) if (B.has(x)) n++; return (2 * n) / (A.size + B.size);
}

module.exports = { tokens, Ranker, overlap, dice };
