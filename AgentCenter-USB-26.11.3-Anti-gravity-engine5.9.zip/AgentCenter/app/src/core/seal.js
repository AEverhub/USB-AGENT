'use strict';
/**
 * engine4.8 USB 可攜版：「USB 密碼」封存。
 *  ・設了 USB 密碼後，設定檔裡的金鑰欄位、帳密保險箱的金鑰（vault.key）、MCP 授權檔都改用這把密碼衍生的金鑰加密（AES-256-GCM）。
 *  ・密碼本身不存：data/usb-lock.json 只放 salt 和一段驗證用密文，用 scrypt 從密碼算出金鑰。
 *  ・沒設密碼（手機版、一般桌機）時完全不作用：wrap/unwrap 原樣傳回。
 *  ・誠實的限制：程式在跑的時候金鑰在記憶體裡；這是防「USB 掉了被撿走」，不是防正在用的那台電腦。
 */
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const PREFIX = 'seal1:';
let KEY = null;

function derive(pw, salt) { return crypto.scryptSync(String(pw), Buffer.from(salt, 'hex'), 32, { N: 1 << 15, r: 8, p: 1, maxmem: 64 * 1024 * 1024 }); }
function encWith(key, str) {
  const iv = crypto.randomBytes(12); const c = crypto.createCipheriv('aes-256-gcm', key, iv);
  const ct = Buffer.concat([c.update(String(str), 'utf8'), c.final()]);
  return PREFIX + [iv, c.getAuthTag(), ct].map((b) => b.toString('base64')).join(':');
}
function decWith(key, s) {
  const [iv, tag, ct] = String(s).slice(PREFIX.length).split(':').map((x) => Buffer.from(x, 'base64'));
  const d = crypto.createDecipheriv('aes-256-gcm', key, iv); d.setAuthTag(tag);
  return Buffer.concat([d.update(ct), d.final()]).toString('utf8');
}

const seal = {
  on() { return !!KEY; },
  setKey(k) { KEY = k ? Buffer.from(k) : null; },
  isSealed(s) { return typeof s === 'string' && s.startsWith(PREFIX); },
  wrap(str) { return KEY ? encWith(KEY, str) : str; },
  /** 不是封存格式就原樣傳回（相容沒加密的舊檔）；是封存格式但沒解鎖 → 丟錯 */
  unwrap(s) {
    if (!seal.isSealed(s)) return s;
    if (!KEY) throw new Error('這個資料已用 USB 密碼加密，要先輸入密碼解鎖');
    return decWith(KEY, s);
  },
  lockFile(dataDir) { return path.join(dataDir, 'usb-lock.json'); },
  hasLock(dataDir) { return fs.existsSync(seal.lockFile(dataDir)); },
  /** 新設密碼：寫 usb-lock.json 並啟用金鑰（呼叫端要接著把設定、保險箱金鑰重新存一次） */
  create(dataDir, pw) {
    if (String(pw).length < 6) throw new Error('USB 密碼至少 6 個字');
    const salt = crypto.randomBytes(16).toString('hex'); const key = derive(pw, salt);
    fs.mkdirSync(dataDir, { recursive: true });
    fs.writeFileSync(seal.lockFile(dataDir), JSON.stringify({ v: 1, kdf: 'scrypt', salt, check: encWith(key, 'agent-usb-ok') }, null, 1));
    KEY = key; return true;
  },
  /** 用密碼解鎖；密碼錯回 false */
  unlock(dataDir, pw) {
    const j = JSON.parse(fs.readFileSync(seal.lockFile(dataDir), 'utf8')); const key = derive(pw, j.salt);
    try { if (decWith(key, j.check) !== 'agent-usb-ok') return false; } catch { return false; }
    KEY = key; return true;
  },
  /** 拿掉密碼：只刪鎖檔並停用金鑰（呼叫端要先在解鎖狀態把資料以明文重存） */
  remove(dataDir) { try { fs.unlinkSync(seal.lockFile(dataDir)); } catch { /* ignore */ } KEY = null; },
  PREFIX,
};

module.exports = seal;
