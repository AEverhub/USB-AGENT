'use strict';
const fs = require('fs');
const path = require('path');
const { EventEmitter } = require('events');

const bus = new EventEmitter(); bus.setMaxListeners(100);
const ring = [];            // 最近 500 行，給 App 即時顯示
let file = null;

function init(dir) {
  try { fs.mkdirSync(dir, { recursive: true }); file = path.join(dir, 'app.log');
    if (fs.existsSync(file) && fs.statSync(file).size > 2 * 1024 * 1024) fs.renameSync(file, file + '.1'); } catch { /* ignore */ }
}
function write(level, tag, msg) {
  const line = `${new Date().toISOString()} [${level}] ${tag}: ${msg}`;
  ring.push(line); if (ring.length > 500) ring.shift();
  try { (level === 'ERROR' ? console.error : console.log)(line); } catch { /* ignore */ }
  if (file) { try { fs.appendFileSync(file, line + '\n'); } catch { /* ignore */ } }
  bus.emit('line', { level, tag, line });
}
const fmt = (a) => a.map((x) => (x instanceof Error ? (x.stack || x.message) : typeof x === 'string' ? x : JSON.stringify(x))).join(' ');
const logger = (tag) => ({
  info: (...a) => write('INFO', tag, fmt(a)), warn: (...a) => write('WARN', tag, fmt(a)),
  error: (...a) => write('ERROR', tag, fmt(a)), debug: (...a) => { if (process.env.DEBUG) write('DEBUG', tag, fmt(a)); },
});
module.exports = { init, logger, ring, bus };
