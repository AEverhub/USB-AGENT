'use strict';
/**
 * 純 JS 的 .tar／.tar.gz 解壓（Android 上不一定有可用的 tar）。
 * 支援：一般檔、資料夾、符號連結、硬連結、GNU 長檔名（L/K）、PAX 擴充標頭（path/linkpath）。
 * 安全：拒絕含 .. 的路徑；寫檔前若目標是符號連結先移除（避免透過連結寫到 rootfs 外）。
 * 檔案權限照抄（可執行位元很重要）；擁有者不處理（proot -0 模擬 root）。
 */
const fs = require('fs');
const path = require('path');
const zlib = require('zlib');

function str(b, o, n) { const s = b.subarray(o, o + n); const z = s.indexOf(0); return s.subarray(0, z < 0 ? n : z).toString('utf8'); }
function oct(b, o, n) {
  if (b[o] & 0x80) { let v = 0; for (let i = o + 1; i < o + n; i++) v = v * 256 + b[i]; return v; }   // base-256（大檔）
  const s = str(b, o, n).trim(); return s ? parseInt(s, 8) : 0;
}
function pax(buf) {
  const out = {}; let i = 0;
  while (i < buf.length) { const sp = buf.indexOf(0x20, i); if (sp < 0) break; const len = parseInt(buf.subarray(i, sp).toString(), 10); if (!len) break; const rec = buf.subarray(sp + 1, i + len - 1).toString('utf8'); const eq = rec.indexOf('='); if (eq > 0) out[rec.slice(0, eq)] = rec.slice(eq + 1); i += len; }
  return out;
}
function safeRel(name) {
  const n = String(name).replace(/\\/g, '/').replace(/^(\.\/)+/, '').replace(/^\/+/, '');
  if (!n || n === '.') return '';
  if (n.split('/').some((s) => s === '..')) throw new Error('tar 內有不安全的路徑：' + name);
  return n.replace(/\/+$/, '');
}

/** 解壓 buf（.tar 或 .tar.gz）到 dest；回傳統計 */
function extract(buf, dest, { onEntry } = {}) {
  if (buf[0] === 0x1f && buf[1] === 0x8b) buf = zlib.gunzipSync(buf);
  fs.mkdirSync(dest, { recursive: true }); const root = path.resolve(dest); const realRoot = fs.realpathSync(root);
  const st = { files: 0, dirs: 0, symlinks: 0, hardlinks: 0, bytes: 0 }; const hard = []; const dirModes = [];
  let off = 0; let longName = null; let longLink = null; let paxH = null;
  while (off + 512 <= buf.length) {
    const h = buf.subarray(off, off + 512); if (h.every((x) => x === 0)) break;
    const size = oct(h, 124, 12); const type = String.fromCharCode(h[156] || 48); const dataOff = off + 512; const data = buf.subarray(dataOff, dataOff + size);
    off = dataOff + Math.ceil(size / 512) * 512;
    if (type === 'L') { longName = str(data, 0, data.length); continue; }
    if (type === 'K') { longLink = str(data, 0, data.length); continue; }
    if (type === 'x') { paxH = pax(data); continue; }
    if (type === 'g') continue;
    const prefix = h.subarray(257, 263).toString() === 'ustar\u0000' || h.subarray(257, 262).toString() === 'ustar' ? str(h, 345, 155) : '';
    let name = longName || (paxH && paxH.path) || (prefix ? prefix + '/' : '') + str(h, 0, 100);
    const link = longLink || (paxH && paxH.linkpath) || str(h, 157, 100); longName = longLink = paxH = null;
    const rel = safeRel(name); if (!rel) continue; const full = path.join(root, rel);
    const mode = oct(h, 100, 8) & 0o7777;
    if (onEntry) onEntry(rel, type);
    fs.mkdirSync(path.dirname(full), { recursive: true });
    const realParent = fs.realpathSync(path.dirname(full)); if (realParent !== realRoot && !realParent.startsWith(realRoot + path.sep)) throw new Error('tar 想透過連結寫到資料夾外：' + rel);
    const clear = () => { try { const l = fs.lstatSync(full); if (l.isDirectory() && !l.isSymbolicLink()) return false; fs.unlinkSync(full); } catch { /* 不存在 */ } return true; };
    if (type === '5') { try { const l = fs.lstatSync(full); if (l.isSymbolicLink()) fs.unlinkSync(full); } catch { /* ignore */ } fs.mkdirSync(full, { recursive: true }); dirModes.push([full, mode || 0o755]); st.dirs++; }
    else if (type === '2') { clear(); fs.symlinkSync(link, full); st.symlinks++; }
    else if (type === '1') { hard.push([full, path.join(root, safeRel(link))]); }
    else if (type === '0' || type === '\u0000' || type === '7') { if (!clear()) throw new Error('檔案和資料夾同名：' + rel); fs.writeFileSync(full, data, { mode: mode || 0o644 }); try { fs.chmodSync(full, mode || 0o644); } catch { /* ignore */ } st.files++; st.bytes += size; }
    // 其他型別（字元／區塊裝置、FIFO）在 proot 裡用不到，略過
  }
  for (const [to, from] of hard) { try { fs.unlinkSync(to); } catch { /* ignore */ } try { fs.linkSync(from, to); } catch { fs.copyFileSync(from, to); fs.chmodSync(to, fs.statSync(from).mode & 0o7777); } st.hardlinks++; }
  for (const [d, m] of dirModes.reverse()) { try { fs.chmodSync(d, m | 0o700); } catch { /* ignore */ } }   // 保留擁有者可寫，之後才能更新／刪除
  return st;
}
module.exports = { extract, safeRel };
