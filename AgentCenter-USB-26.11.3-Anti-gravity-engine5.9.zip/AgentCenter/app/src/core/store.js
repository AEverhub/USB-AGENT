'use strict';
/**
 * 零相依的資料庫：db.json（結構化資料，原子寫入 + 去抖）＋ messages/*.jsonl（對話紀錄，附加寫入）。
 * 資料量為「個人／小團體助理」等級；若日後訊息量大，可把這層換成 SQLite 而不動其他程式（介面集中在此）。
 */
const fs = require('fs');
const path = require('path');
const { logger } = require('./log');
const log = logger('store');
const slow = require('./slow');

const EMPTY = () => ({
  version: 2, seq: {},
  persons: {}, idmap: {}, chats: {}, facts: [], tasks: [], ledger: [], sheets: [], approvals: [], audit: [],
  usage: { days: {} }, lessons: [], rules: [], linkcodes: {}, notifications: [], watches: [], meta: {},
});

class Store {
  constructor(dir) {
    this.vec = []; this.vfile = path.join(dir, 'vectors.json'); this._vt = null; this._vdirty = false;
    this.dir = dir; this.msgDir = path.join(dir, 'messages'); this.file = path.join(dir, 'db.json');
    fs.mkdirSync(this.msgDir, { recursive: true });
    this.db = EMPTY(); this._t = null; this._dirty = false;
    this.load(); this.loadVec();
  }
  load() {
    for (const f of [this.file, this.file + '.bak']) {
      try {
        if (!fs.existsSync(f)) continue;
        const j = JSON.parse(fs.readFileSync(f, 'utf8'));
        this.db = Object.assign(EMPTY(), j); if (f.endsWith('.bak')) log.warn('主檔損毀，已從備份還原');
        return;
      } catch (e) { log.error('讀取資料庫失敗', f, e.message); }
    }
  }
  loadVec() { try { if (fs.existsSync(this.vfile)) this.vec = JSON.parse(fs.readFileSync(this.vfile, 'utf8')); } catch (e) { log.error('讀取向量庫失敗', e.message); this.vec = []; } }
  touchVec() { this._vdirty = true; if (!this._vt) this._vt = setTimeout(() => { this._vt = null; this.flushVecAsync(); }, 20000); }
  /**
   * 向量庫可能到十幾 MB（3000 筆 × 768 維）。舊版每次對話後整檔同步序列化＋寫入，手機上會卡住 1～3 秒，
   * 剛好卡在回覆送出 LINE／Discord／TG 的時候。改成每 100 筆一段、段與段之間讓出事件迴圈。
   */
  async flushVecAsync() {
    if (this.frozen || !this._vdirty) return; if (this._vwriting) { this._vagain = true; return; }
    this._vdirty = false; this._vwriting = true; const tmp = this.vfile + '.tmpa'; const items = this.vec.slice(); let fh = null;
    try {
      fh = await fs.promises.open(tmp, 'w'); await fh.write('[');
      for (let i = 0; i < items.length; i += 100) {
        const part = slow.time('寫入向量庫（分段）', () => items.slice(i, i + 100).map((x) => JSON.stringify(x)).join(','));
        await fh.write((i ? ',' : '') + part); await new Promise((r) => setImmediate(r));
      }
      await fh.write(']'); await fh.close(); fh = null; await fs.promises.rename(tmp, this.vfile);
    } catch (e) { log.error('寫入向量庫失敗', e.message); this._vdirty = true; }
    finally { if (fh) await fh.close().catch(() => {}); this._vwriting = false; if (this._vagain || this._vdirty) { this._vagain = false; this.touchVec(); } }
  }
  flushVec() { if (this.frozen || !this._vdirty) return; this._vdirty = false; try { slow.time('寫入向量庫', () => { fs.writeFileSync(this.vfile + '.tmp', JSON.stringify(this.vec)); fs.renameSync(this.vfile + '.tmp', this.vfile); }, () => `${this.vec.length} 筆`); } catch (e) { log.error('寫入向量庫失敗', e.message); this._vdirty = true; } }
  nextId(name) { this.db.seq[name] = (this.db.seq[name] || 0) + 1; this.touch(); return this.db.seq[name]; }
  // 去抖 1.5 秒；平常用非同步寫檔（不卡事件迴圈），備份檔最多 10 分鐘複製一次。flush() 仍是同步的，給重啟／備份前用。
  touch() { this._dirty = true; if (!this._t) { this._t = setTimeout(() => { this._t = null; this.flushAsync(); }, 1500); } }
  _bak() { if (Date.now() - (this._bakAt || 0) < 600e3) return false; this._bakAt = Date.now(); return true; }
  flush() {
    if (this.frozen) return;   // 資料轉移匯入後、重啟前：不讓記憶體裡的舊資料寫回去
    this.flushVec(); clearTimeout(this._t); this._t = null;
    if (!this._dirty) return; this._dirty = false;
    try {
      const s = slow.time('資料庫序列化', () => JSON.stringify(this.db)); const tmp = this.file + '.tmp'; fs.writeFileSync(tmp, s);
      if (fs.existsSync(this.file) && this._bak()) { try { fs.copyFileSync(this.file, this.file + '.bak'); } catch { /* ignore */ } }
      fs.renameSync(tmp, this.file);
    } catch (e) { log.error('寫入資料庫失敗', e.message); this._dirty = true; }
  }
  async flushAsync() {
    if (this.frozen) return;
    if (this._writing) { this._again = true; return; }
    if (!this._dirty) return; this._dirty = false; this._writing = true;
    try {
      const s = slow.time('資料庫序列化', () => JSON.stringify(this.db)); const tmp = this.file + '.tmpa';
      this.dbBytes = Buffer.byteLength(s);
      await fs.promises.writeFile(tmp, s);
      if (this._bak()) await fs.promises.copyFile(this.file, this.file + '.bak').catch(() => {});
      await fs.promises.rename(tmp, this.file);
    } catch (e) { log.error('寫入資料庫失敗', e.message); this._dirty = true; }
    finally { this._writing = false; if (this._again || this._dirty) { this._again = false; this.touch(); } }
  }
  // ---- 對話紀錄 ----
  _mf(scope) { return path.join(this.msgDir, scope.replace(/[^\w.-]/g, '_') + '.jsonl'); }
  addMessage(scope, rec) {
    try { fs.appendFileSync(this._mf(scope), JSON.stringify({ ts: Date.now(), ...rec }) + '\n'); } catch (e) { log.error('寫入訊息失敗', e.message); }
  }
  tail(scope, n = 30) {
    const f = this._mf(scope); if (!fs.existsSync(f)) return [];
    try {
      const st = fs.statSync(f); const size = Math.min(st.size, 256 * 1024 + n * 2000);
      const fd = fs.openSync(f, 'r'); const buf = Buffer.alloc(size); fs.readSync(fd, buf, 0, size, st.size - size); fs.closeSync(fd);
      const lines = buf.toString('utf8').split('\n').filter(Boolean); if (st.size > size) lines.shift();
      return lines.slice(-n).map((l) => { try { return JSON.parse(l); } catch { return null; } }).filter(Boolean);
    } catch { return []; }
  }
  /** 往前翻頁：ts 早於 before 的最後 n 則（從檔尾一塊一塊往前讀，不整份載入） */
  page(scope, before = Infinity, n = 40) {
    const f = this._mf(scope); if (!fs.existsSync(f)) return [];
    try {
      const st = fs.statSync(f); const fd = fs.openSync(f, 'r'); let pos = st.size; let carry = ''; const got = [];
      while (pos > 0 && got.length < n) {
        const size = Math.min(256 * 1024, pos); pos -= size; const buf = Buffer.alloc(size); fs.readSync(fd, buf, 0, size, pos);
        const lines = (buf.toString('utf8') + carry).split('\n'); carry = pos > 0 ? lines.shift() : '';
        for (let i = lines.length - 1; i >= 0 && got.length < n; i--) { if (!lines[i]) continue; try { const m = JSON.parse(lines[i]); if (m.ts < before) got.push(m); } catch { /* 跳過壞行 */ } }
      }
      fs.closeSync(fd); return got.reverse();
    } catch { return []; }
  }
  searchMessages(scope, q, limit = 20) {
    const f = this._mf(scope); if (!fs.existsSync(f)) return [];
    const words = String(q).toLowerCase().split(/\s+/).filter(Boolean); const out = [];
    for (const l of fs.readFileSync(f, 'utf8').split('\n')) {
      if (!l) continue; const low = l.toLowerCase();
      if (words.every((w) => low.includes(w))) { try { out.push(JSON.parse(l)); } catch { /* skip */ } }
    }
    return out.slice(-limit);
  }
  countMessages() {
    let n = 0, bytes = 0;
    try { for (const f of fs.readdirSync(this.msgDir)) { const p = path.join(this.msgDir, f); bytes += fs.statSync(p).size;
      n += fs.readFileSync(p, 'utf8').split('\n').filter(Boolean).length; } } catch { /* ignore */ }
    return { messages: n, bytes };
  }
  audit(who, action, detail = '') {
    this.db.audit.push({ ts: Date.now(), who, action, detail: String(detail).slice(0, 500) });
    if (this.db.audit.length > 5000) this.db.audit.splice(0, this.db.audit.length - 5000);
    this.touch();
  }
}
module.exports = { Store };
