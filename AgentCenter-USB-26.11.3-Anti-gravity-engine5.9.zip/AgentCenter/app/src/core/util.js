'use strict';
const crypto = require('crypto');

const pad = (n, w = 2) => String(n).padStart(w, '0');
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const rid = (n = 8) => crypto.randomBytes(n).toString('hex');
const sha = (s) => crypto.createHash('sha256').update(String(s)).digest('hex');
const clip = (s, n = 4000) => { s = String(s ?? ''); return s.length > n ? s.slice(0, n) + `…（已截斷，共 ${s.length} 字）` : s; };
const isObj = (v) => v && typeof v === 'object' && !Array.isArray(v);
const r2 = (x) => Math.round((Number(x) + Number.EPSILON) * 100) / 100;

/** 台北標準時間（UTC+8，無日光節約），不依賴 Intl，nodejs-mobile 也穩 */
function taipei(ts = Date.now()) {
  const d = new Date(ts + 8 * 3600e3);
  const y = d.getUTCFullYear(), m = d.getUTCMonth() + 1, day = d.getUTCDate();
  const hh = d.getUTCHours(), mm = d.getUTCMinutes(), ss = d.getUTCSeconds();
  return { y, m, d: day, hh, mm, ss, wd: d.getUTCDay(),
    date: `${y}/${pad(m)}/${pad(day)}`, time: `${pad(hh)}:${pad(mm)}`, iso: `${y}-${pad(m)}-${pad(day)}` };
}

/** 任意時區；Intl 不可用時退回台北 */
function zoned(ts = Date.now(), tz = 'Asia/Taipei') {
  if (tz === 'Asia/Taipei') return taipei(ts);
  try {
    const f = new Intl.DateTimeFormat('en-GB', { timeZone: tz, hourCycle: 'h23', year: 'numeric', month: '2-digit',
      day: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit' });
    const p = {}; for (const x of f.formatToParts(new Date(ts))) p[x.type] = x.value;
    const y = +p.year, m = +p.month, day = +p.day, hh = +p.hour % 24, mm = +p.minute, ss = +p.second;
    const wd = new Date(Date.UTC(y, m - 1, day)).getUTCDay();
    return { y, m, d: day, hh, mm, ss, wd, date: `${y}/${pad(m)}/${pad(day)}`, time: `${pad(hh)}:${pad(mm)}`, iso: `${y}-${pad(m)}-${pad(day)}` };
  } catch { return taipei(ts); }
}

/** 把「台北當地 y/m/d hh:mm」轉回 epoch ms */
function fromTaipei(y, m, d, hh = 0, mm = 0, ss = 0) { return Date.UTC(y, m - 1, d, hh, mm, ss) - 8 * 3600e3; }

/** 任意時區的當地時間 → epoch ms（以兩次逼近處理偏移） */
function fromZoned(y, m, d, hh = 0, mm = 0, tz = 'Asia/Taipei') {
  const target = Date.UTC(y, m - 1, d, hh, mm); let ts = target;
  for (let i = 0; i < 3; i++) { const z = zoned(ts, tz); const got = Date.UTC(z.y, z.m - 1, z.d, z.hh, z.mm); ts += target - got; }
  return ts;
}

/** 給 Promise 加逾時：逾時會 reject（底層工作可能仍在跑，但不會再卡住呼叫者） */
function withTimeout(p, ms, label = '操作') {
  let t; const to = new Promise((_, rej) => { t = setTimeout(() => rej(new Error(`${label}逾時（${Math.round(ms / 1000)} 秒）`)), ms); });
  return Promise.race([Promise.resolve(p), to]).finally(() => clearTimeout(t));
}

/** 序列化佇列：同一個 key 的任務依序執行；可設單一任務最長時間，避免一個卡死的任務堵住整個聊天室 */
class KeyedQueue {
  constructor(maxMs = 0) { this.tails = new Map(); this.maxMs = maxMs; }
  run(key, fn) {
    const prev = this.tails.get(key) || Promise.resolve();
    const task = () => (this.maxMs ? withTimeout(fn(), this.maxMs, '處理') : fn());
    const next = prev.catch(() => {}).then(task);
    this.tails.set(key, next);
    next.finally(() => { if (this.tails.get(key) === next) this.tails.delete(key); }).catch(() => {});
    return next;
  }
}

function hhmmToMin(s) { const m = /^(\d{1,2}):(\d{2})$/.exec(String(s || '')); return m ? (+m[1]) * 60 + (+m[2]) : null; }

async function fetchJson(url, opt = {}, timeout = 60000) {
  const ctl = new AbortController(); const t = setTimeout(() => ctl.abort(), timeout);
  try {
    const r = await fetch(url, { ...opt, signal: ctl.signal });
    const text = await r.text(); let j = null; try { j = JSON.parse(text); } catch { /* not json */ }
    // retry-after（秒）：供應商常在 429 回這個標頭，告訴我們該等多久；拿不到就 0
    let retryAfter = 0; try { const ra = r.headers.get('retry-after'); if (ra) { const n = Number(ra); retryAfter = Number.isFinite(n) ? n : Math.max(0, Math.round((Date.parse(ra) - Date.now()) / 1000)); } } catch { /* ignore */ }
    return { ok: r.ok, status: r.status, json: j, text, retryAfter };
  } finally { clearTimeout(t); }
}

/**
 * 送訊息到 LINE／Discord／Telegram 用：逾時短（預設 12 秒）、連線類錯誤自動重試。
 * 手機網路常見「連線池裡的舊連線已被電信 NAT 切掉」→ 請求卡到逾時才失敗；舊版一卡就是 20～40 秒。
 * idempotent=true（平台有防重複機制，例如 LINE X-Line-Retry-Key、Discord nonce）時，逾時與 5xx 也重試。
 */
const CONNECT_ERR = /ECONNREFUSED|ENOTFOUND|EAI_AGAIN|ENETUNREACH|EHOSTUNREACH|UND_ERR_CONNECT_TIMEOUT|UND_ERR_SOCKET|ECONNRESET|EPIPE|other side closed/;
function netCode(e) { const c = e && (e.cause || e); return String((c && (c.code || c.message)) || (e && e.message) || ''); }
async function fetchSend(url, opt = {}, { timeout = 12000, idempotent = false, tries = 3, onRetry } = {}) {
  for (let a = 1; ; a++) {
    try {
      const r = await fetchJson(url, opt, timeout);
      if (idempotent && r.status >= 500 && a < tries) { if (onRetry) onRetry(`HTTP ${r.status}`, a); await sleep(500 * a); continue; }
      return r;
    } catch (e) {
      const why = e.name === 'AbortError' ? '逾時' : netCode(e);
      if (a < tries && (CONNECT_ERR.test(why) || (idempotent && why === '逾時'))) { if (onRetry) onRetry(why, a); await sleep(300 * a); continue; }
      if (e.name === 'AbortError') throw new Error(`連線逾時（${Math.round(timeout / 1000)} 秒）`);
      throw new Error(`連線失敗：${why}`);
    }
  }
}

/** 下載成 Buffer（含逾時與大小上限） */
async function fetchBuf(url, opt = {}, timeout = 30000, maxBytes = 25 * 1024 * 1024) {
  const ctl = new AbortController(); const t = setTimeout(() => ctl.abort(), timeout);
  try {
    const r = await fetch(url, { ...opt, signal: ctl.signal });
    if (!r.ok) throw new Error(`HTTP ${r.status}`);
    const len = Number(r.headers.get('content-length') || 0); if (len > maxBytes) throw new Error('檔案太大');
    const b = Buffer.from(await r.arrayBuffer()); if (b.length > maxBytes) throw new Error('檔案太大');
    return { buf: b, mime: (r.headers.get('content-type') || '').split(';')[0].trim(), headers: r.headers };
  } finally { clearTimeout(t); }
}

/** 小型 TTL 快取（取使用者名稱、群組名稱這類每則訊息都會問的資料） */
class TTLCache {
  constructor(ttl = 3600e3, max = 500) { this.ttl = ttl; this.max = max; this.m = new Map(); }
  get(k) { const e = this.m.get(k); if (!e) return undefined; if (Date.now() > e.exp) { this.m.delete(k); return undefined; } return e.v; }
  set(k, v) { this.m.set(k, { v, exp: Date.now() + this.ttl }); if (this.m.size > this.max) this.m.delete(this.m.keys().next().value); return v; }
  async wrap(k, fn) { const c = this.get(k); if (c !== undefined) return c; const v = await fn(); if (v) this.set(k, v); return v; }
}

module.exports = { withTimeout, fetchBuf, TTLCache, pad, sleep, rid, sha, clip, isObj, r2, taipei, zoned, fromTaipei, fromZoned, KeyedQueue, hhmmToMin, fetchJson, fetchSend, netCode };
