'use strict';
/**
 * 找出「誰卡住事件迴圈」：同步執行超過門檻的操作記在環形緩衝區，卡頓警告會附上嫌疑名單。
 *   slow.time(label, fn)    同步包一段程式並計時
 *   slow.note(label, ms, extra)  手動記錄
 */
const RING = []; const MIN_MS = 120;
function note(label, ms, extra) { if (ms < MIN_MS) return; RING.push({ ts: Date.now(), label, ms: Math.round(ms), extra: extra || '' }); if (RING.length > 50) RING.shift(); }
function time(label, fn, extra) { const t = process.hrtime.bigint(); try { return fn(); } finally { note(label, Number(process.hrtime.bigint() - t) / 1e6, typeof extra === 'function' ? extra() : extra); } }
/** since 之後最慢的幾筆（同 label 合併） */
function suspects(since = 0, n = 3) {
  const m = new Map(); for (const r of RING) if (r.ts >= since) { const x = m.get(r.label) || { label: r.label, ms: 0, count: 0, extra: '' }; x.count++; if (r.ms > x.ms) { x.ms = r.ms; x.extra = r.extra; } m.set(r.label, x); }
  return [...m.values()].sort((a, b) => b.ms - a.ms).slice(0, n);
}
module.exports = { note, time, suspects, recent: () => RING.slice(), MIN_MS };
