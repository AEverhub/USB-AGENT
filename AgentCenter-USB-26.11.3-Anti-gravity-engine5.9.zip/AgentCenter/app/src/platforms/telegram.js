'use strict';
const { logger } = require('../core/log');
const { fetchJson, fetchSend, fetchBuf, sleep } = require('../core/util');
const M = require('./mentions');
const { splitText, form, extOf } = require('./common');
const log = logger('telegram');

class Telegram {
  constructor(ctx) { this.ctx = ctx; this.name = 'telegram'; this.on = false; this.offset = 0; this.me = null; this.sentIds = new Set(); this.lastOk = 0; this.loopId = 0; this.fails = 0; this.threads = new Map(); }
  get cfg() { return this.ctx.settings.get('platforms.telegram'); }
  enabled() { return !!this.cfg.enabled; }
  api(m, body, t = 40000) { return fetchJson(`https://api.telegram.org/bot${this.cfg.token}/${m}`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body || {}) }, t); }
  async start() {
    if (!this.cfg.enabled) { this.on = false; return; } if (!this.cfg.token) throw new Error('Telegram Bot token 未設定');
    const r = await this.api('getMe', {}, 15000); if (!r.json || !r.json.ok) throw new Error('Telegram token 無效：' + (r.text || '').slice(0, 120));
    this.me = r.json.result; this.on = true; this.lastOk = Date.now(); this.fails = 0; const id = ++this.loopId; this._loop(id);
  }
  async stop() { this.on = false; this.loopId++; }
  health() { return !this.cfg.enabled || (this.on && Date.now() - this.lastOk < 120000); }
  async _loop(id) {
    while (this.on && id === this.loopId) {
      try {
        const r = await this.api('getUpdates', { offset: this.offset, timeout: 25, allowed_updates: ['message'] }, 40000);
        if (!r.json || !r.json.ok) { if (r.json && r.json.error_code === 409) throw new Error('另一個程式正在用同一個 Bot Token 收訊息（409），請確認沒有重複執行'); throw new Error((r.text || '').slice(0, 120)); }
        this.lastOk = Date.now(); this.fails = 0;
        for (const u of r.json.result) { this.offset = u.update_id + 1; if (u.message) this.message(u.message).catch((e) => log.error(e)); }
      } catch (e) { this.fails++; if (this.fails === 1 || this.fails % 15 === 0) log.warn(`getUpdates 失敗（連續 ${this.fails} 次）：${e.message}`); await sleep(Math.min(30000, 2000 * 2 ** Math.min(this.fails, 4))); }
    }
  }
  async message(m) {
    if (!m.from || (this.me && m.from.id === this.me.id)) return; const group = m.chat.type !== 'private'; const isBot = !!m.from.is_bot; if (isBot && !group) return;   /* 26.11.3 pro6：群組裡其他機器人的訊息也記下來、它 @你時可以回 */ const text = m.text || m.caption || ''; const uname = this.me && this.me.username ? '@' + this.me.username : null;
    const aliases = (this.ctx.settings.get('bot.aliases') || []).filter(Boolean); const refs = this.ctx.refs; const chatId = String(m.chat.id);
    const nm = (u) => (u ? [u.first_name, u.last_name].filter(Boolean).join(' ') || u.username || '' : '');
    const photoOf = (x) => { if (!x) return null; if (x.photo && x.photo.length) return x.photo[x.photo.length - 1].file_id; if (x.document && /^image\//.test(x.document.mime_type || '')) return x.document.file_id; return null; };
    const photo = photoOf(m); const name = nm(m.from);
    const au = m.voice || m.audio || (m.document && /^audio\//.test(m.document.mime_type || '') ? m.document : null);   // 語音訊息／音檔
    refs.put('telegram', chatId, { id: m.message_id, text: text || (photo ? '[圖片]' : au ? '[語音]' : ''), name, uid: String(m.from.id), img: !!photo });
    // 引言：Telegram 的「回覆」帶整則被回覆的訊息；若對方只選了其中一段文字（quote）就以那一段為準
    let quote = null; let qPhoto = null; const rm = m.reply_to_message;
    if (rm && !rm.forum_topic_created && !rm.forum_topic_edited) {
      qPhoto = photoOf(rm); const full = rm.text || rm.caption || ''; const fromBot = !!(rm.from && this.me && rm.from.id === this.me.id);
      const picked = m.quote && m.quote.text ? m.quote.text : full;
      quote = { id: String(rm.message_id), text: picked || (qPhoto ? '[圖片]' : (rm.sticker ? '[貼圖]' : rm.voice ? '[語音]' : rm.document ? '[檔案]' : '')), name: nm(rm.from) || (rm.sender_chat && rm.sender_chat.title) || '', fromBot, hasImage: !!qPhoto };
      refs.put('telegram', chatId, { id: rm.message_id, text: full || quote.text, name: quote.name, uid: rm.from ? String(rm.from.id) : '', bot: fromBot, img: !!qPhoto });
    }
    const direct = !!(uname && text.toLowerCase().includes(uname.toLowerCase()));
    const mentioned = !group || direct || !!(quote && quote.fromBot) || (!isBot && aliases.some((a) => text.includes(a)));
    const mentionsOthers = (m.entities || []).some((e) => (e.type === 'mention' && text.substr(e.offset, e.length).toLowerCase() !== String(uname || '').toLowerCase()) || e.type === 'text_mention');
    const thread = m.is_topic_message ? m.message_thread_id : undefined;
    const msg = { platform: 'telegram', chatId, chatType: group ? 'group' : 'dm', chatName: m.chat.title || '', uid: String(m.from.id), userName: name, direct, mentionsOthers, isBot, botName: isBot ? name : '', text: uname ? text.replace(new RegExp(uname, 'ig'), '').trim() : text,
      mentioned: !!mentioned, ts: (m.date || 0) * 1000 || Date.now(), hasImage: !!photo, hasAudio: !!au, msgId: String(m.message_id), quote, ref: { id: String(m.message_id) },
      fetchAudio: async () => { const f = await this.file(au.file_id); return { mime: au.mime_type || 'audio/ogg', data: f.data }; },
      hasDoc: !!(m.document && !photo && !au), docName: (m.document && m.document.file_name) || '', docSize: (m.document && m.document.file_size) || 0,
      fetchDoc: async () => { const r = await this.api('getFile', { file_id: m.document.file_id }, 15000); const p = r.json && r.json.result && r.json.result.file_path; if (!p) throw new Error('取不到檔案（Telegram Bot 只能下載 20MB 以下的檔案）'); const f = await fetchBuf(`https://api.telegram.org/file/bot${this.cfg.token}/${p}`, {}, 45000, 20 * 1024 * 1024); return { name: m.document.file_name || 'file', mime: m.document.mime_type || '', buf: f.buf }; },
      fetchImages: async () => (photo ? [await this.file(photo)] : []), fetchQuotedImages: async () => (qPhoto ? [await this.file(qPhoto)] : []), typing: () => this.typing(chatId, thread), _quoted: false };
    if (thread) this.threads.set(chatId, thread);
    msg.reply = (t, o = {}) => { const wq = o.quote !== undefined ? o.quote : msg.wantQuote; const q = wq && !msg._quoted; if (q) msg._quoted = true; return this.send(chatId, t, { quote: q ? { id: m.message_id } : undefined, thread }); };
    msg.sendImage = (img, caption) => { const wq = msg.wantQuote && !msg._quoted; if (wq) msg._quoted = true; return this.sendImage(chatId, img, caption, { quote: wq ? { id: m.message_id } : undefined, thread }); };
    await this.ctx.hub.incoming(msg);
  }
  async file(fid) {
    const r = await this.api('getFile', { file_id: fid }, 15000); const p = r.json && r.json.result && r.json.result.file_path; if (!p) throw new Error('取不到檔案');
    const f = await fetchBuf(`https://api.telegram.org/file/bot${this.cfg.token}/${p}`, {}, 25000, 8 * 1024 * 1024);
    return { mime: /\.png$/i.test(p) ? 'image/png' : /\.webp$/i.test(p) ? 'image/webp' : 'image/jpeg', data: f.buf.toString('base64') };
  }
  async typing(chatId, thread) { try { await this.api('sendChatAction', { chat_id: chatId, action: 'typing', ...(thread ? { message_thread_id: thread } : {}) }, 5000); } catch { /* 不重要 */ } }
  _rp(opt) { return { ...(opt.quote ? { reply_parameters: { message_id: Number(opt.quote.id), allow_sending_without_reply: true } } : {}), ...(opt.thread ? { message_thread_id: opt.thread } : {}) }; }
  /** quote={id}：用 Telegram 的「回覆」引用那則訊息（只有第一段）；原訊息不存在也照樣送出 */
  async send(chatId, text, opt = {}) {
    let first = true; let last;
    text = require('./common').mdTables(text);   // 26.11.3 Revise7：表格改成看得懂的文字
    for (const t of splitText(text, 4000)) {
      const tm = M.telegram(this.ctx, chatId, t);   // @[名字] → text_mention
      const body = { chat_id: chatId, text: tm.text, ...(tm.entities.length ? { entities: tm.entities } : {}), disable_web_page_preview: true, ...(first ? this._rp(opt) : (opt.thread ? { message_thread_id: opt.thread } : {})) }; first = false;
      let r = await fetchSend(`https://api.telegram.org/bot${this.cfg.token}/sendMessage`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body) }, { onRetry: (w, a) => log.warn(`Telegram 發送第 ${a} 次失敗（${w}），重試`) });
      if ((!r.json || !r.json.ok) && r.json && r.json.error_code === 429) { await sleep(Math.min(8000, ((r.json.parameters && r.json.parameters.retry_after) || 2) * 1000)); r = await this.api('sendMessage', body); }
      if ((!r.json || !r.json.ok) && body.message_thread_id && /thread/i.test(r.text || '')) { delete body.message_thread_id; r = await this.api('sendMessage', body); }
      if (!r.json || !r.json.ok) throw new Error('Telegram 發送失敗：' + (r.text || '').slice(0, 150));
      last = r.json.result; if (last) this.ctx.refs.put('telegram', chatId, { id: last.message_id, text: t, bot: true, name: 'AI' });
    }
    return last;
  }
  /** 直接上傳圖片（multipart）；PNG／JPEG 走 sendPhoto，其他格式走 sendDocument */
  async sendImage(chatId, img, caption, opt = {}) {
    const photo = img.mime === 'image/png' || img.mime === 'image/jpeg'; const method = photo ? 'sendPhoto' : 'sendDocument';
    const fields = { chat_id: chatId, ...(caption ? { caption: String(caption).slice(0, 1000) } : {}), ...(opt.quote ? { reply_parameters: JSON.stringify({ message_id: Number(opt.quote.id), allow_sending_without_reply: true }) } : {}), ...(opt.thread ? { message_thread_id: opt.thread } : {}) };
    const fd = form(fields, { field: photo ? 'photo' : 'document', buf: img.buf, mime: img.mime, name: `image.${extOf(img.mime)}` });
    const r = await fetchJson(`https://api.telegram.org/bot${this.cfg.token}/${method}`, { method: 'POST', body: fd }, 60000);
    if (!r.json || !r.json.ok) throw new Error('Telegram 傳圖失敗：' + (r.text || '').slice(0, 150));
    const res = r.json.result; if (res) this.ctx.refs.put('telegram', chatId, { id: res.message_id, text: caption || '[圖片]', bot: true, img: true, name: 'AI' }); return res;
  }
  async sendFile(chatId, f) {
    const fd = form({ chat_id: chatId }, { field: 'document', buf: f.buf, mime: f.mime, name: f.name });
    const r = await fetchJson(`https://api.telegram.org/bot${this.cfg.token}/sendDocument`, { method: 'POST', body: fd }, 90000);
    if (!r.json || !r.json.ok) throw new Error('Telegram 傳檔失敗：' + (r.text || '').slice(0, 150)); return r.json.result;
  }
  /** 26.11.3 Revise8：影片直接在 Telegram 裡播放（50MB 以內） */
  async sendVideo(chatId, f) {
    const fd = form({ chat_id: chatId, supports_streaming: 'true' }, { field: 'video', buf: f.buf, mime: f.mime, name: f.name });
    const r = await fetchJson(`https://api.telegram.org/bot${this.cfg.token}/sendVideo`, { method: 'POST', body: fd }, 120000);
    if (!r.json || !r.json.ok) return this.sendFile(chatId, f); return r.json.result;
  }
  // ---- engine5.4：刪除／收回訊息、改群組名稱 ----
  _why(r, act) {
    const d = String((r.json && r.json.description) || r.text || '').slice(0, 160);
    if (/can't be deleted|message can.t be deleted/i.test(d)) return `${act}失敗：Telegram 不讓刪（Bot 自己的訊息超過 48 小時就不能刪；刪別人的訊息要 Bot 是群組管理員、有「刪除訊息」權限，而且同樣限 48 小時內）`;
    if (/not enough rights|administrator|CHAT_ADMIN_REQUIRED/i.test(d)) return `${act}失敗：Bot 不是群組管理員，或沒有「${act.includes('名稱') ? '變更群組資訊' : '刪除訊息'}」權限`;
    if (/message to delete not found|not found/i.test(d)) return `${act}失敗：找不到這則訊息（可能已經被刪掉）`;
    if (/private chat|chat_id/i.test(d) && act.includes('名稱')) return `${act}失敗：私人對話沒有名稱可以改，只有群組可以`;
    return `${act}失敗：${d || r.status}`;
  }
  async deleteMessage(chatId, msgId) { const r = await this.api('deleteMessage', { chat_id: chatId, message_id: +msgId }, 15000); if (r.json && r.json.ok) return true; throw new Error(this._why(r, '刪除訊息')); }
  async setTitle(chatId, title) { const r = await this.api('setChatTitle', { chat_id: chatId, title: String(title).slice(0, 128) }, 15000); if (r.json && r.json.ok) return true; throw new Error(this._why(r, '改群組名稱')); }
  async setDescription(chatId, text) { const r = await this.api('setChatDescription', { chat_id: chatId, description: String(text || '').slice(0, 255) }, 15000); if (r.json && r.json.ok) return true; throw new Error(this._why(r, '改群組說明')); }
  async sendToUser(uid, text) { return this.send(uid, text); }
}
module.exports = { Telegram };
