'use strict';
const { logger } = require('../core/log');
const { fetchJson, fetchSend, fetchBuf, TTLCache } = require('../core/util');
const M = require('./mentions');
const { splitText, form, extOf } = require('./common');
const log = logger('discord');
const API = 'https://discord.com/api/v10';
const FATAL = new Set([4004, 4010, 4011, 4012, 4013, 4014]);   // 金鑰錯、intent 沒開等：重連也沒用

class Discord {
  constructor(ctx) {
    this.ctx = ctx; this.name = 'discord'; this.on = false; this.ws = null; this.me = null; this.seq = null; this.hb = null; this.ready = false; this.lastAck = 0; this.dmCache = new Map(); this.sentIds = new Set();
    this.session = null; this.resumeUrl = null; this.guilds = new TTLCache(24 * 3600e3, 300); this.retry = 0; this.beatAcked = true; this.fatal = '';
  }
  get cfg() { const c = this.ctx.settings.get('platforms.discord') || {}; return { ...c, token: require('../core/settings').Settings.cleanSecret('platforms.discord.token', c.token || '') }; }
  /** 26.11.3：檢查 token（不連 Gateway）：Bot 名稱、MESSAGE CONTENT INTENT 有沒有開 */
  async test(token) {
    const t = require('../core/settings').Settings.cleanSecret('platforms.discord.token', token || this.cfg.token || ''); if (!t) return { ok: false, code: 'DISCORD_NO_TOKEN', error: '還沒填 Discord Bot Token' };
    if (!/^[\w-]{20,}\.[\w-]{4,}\.[\w-]{20,}$/.test(t)) return { ok: false, code: 'DISCORD_TOKEN_FORMAT', error: `格式不像 Discord Bot Token（應該是三段用「.」分開、約 70 字；目前 ${t.length} 字）。請到 Discord Developer Portal → Bot → Reset Token 重新複製` };
    const h = { authorization: 'Bot ' + t }; const me = await fetchJson(`${API}/users/@me`, { headers: h }, 10000).catch((e) => ({ ok: false, status: 0, text: e.message }));
    if (me.status === 401) return { ok: false, code: 'DISCORD_401', error: 'Discord 說這個 Token 無效（可能已被重設），請到 Developer Portal 重新產生' };
    if (!me.ok) return { ok: false, code: 'DISCORD_HTTP_' + me.status, error: `連不到 Discord（${me.status || ''} ${String(me.text || '').slice(0, 80)}）` };
    const app = await fetchJson(`${API}/applications/@me`, { headers: h }, 10000).catch(() => null); const flags = (app && app.json && app.json.flags) || 0;
    const intent = !!(flags & ((1 << 18) | (1 << 19)));
    return { ok: intent, bot: me.json.username, id: me.json.id, intent, code: intent ? 'OK' : 'DISCORD_NO_INTENT', error: intent ? '' : 'Token 正確，但還沒開「MESSAGE CONTENT INTENT」：Developer Portal → Bot → Privileged Gateway Intents → 打開 Message Content Intent → Save' };
  }
  enabled() { return !!this.cfg.enabled; }
  async start() {
    if (!this.cfg.enabled) { this.on = false; return; } if (!this.cfg.token) throw new Error('Discord Bot token 未設定');
    this.on = true; this.fatal = ''; this.retry = 0; this._connect(false);
  }
  async stop() { this.on = false; clearInterval(this.hb); clearTimeout(this.rt); try { this.ws && this.ws.close(1000); } catch { /* ignore */ } this.ws = null; this.ready = false; }
  /**
   * 26.11.3 pro6：以前「沒連上」或「120 秒沒收到心跳回應」就判定不健康 → 守護進程把 Discord 整個重啟，還發通知。但這兩種多半是正常的：
   *  ・Discord 會定期要求重連（op 7）、手機換網路也會斷，自己的重連幾秒內就好；被守護進程打斷反而要重新登入
   *  ・手機休眠時計時器整個停住，醒來那一刻「上次心跳」看起來很久以前，其實只是心跳還沒機會送
   * 現在：重連中 3 分鐘內算正常（交給自己的重連）；醒來發現心跳太久沒送就先補送一拍；只有真的連不上、或心跳送了卻一直沒回應才算不健康，並寫清楚原因。
   */
  health() {
    if (!this.cfg.enabled) return true; if (this.fatal) { this.healthWhy = this.fatal; return false; } if (!this.on) { this.healthWhy = '沒有啟動'; return false; }
    const now = Date.now(); const iv = this.hbEvery || 41250;
    if (!this.ready) { const down = now - (this.downSince || now); this.healthWhy = `斷線 ${Math.round(down / 1000)} 秒，正在自動重連`; return down < 180000; }
    if (now - this.lastAck < iv * 2 + 30000) { this.healthWhy = ''; return true; }
    if (now - (this.lastBeatAt || 0) > iv * 1.5) { this.healthWhy = ''; try { this.beatAcked = true; this._beat && this._beat(); } catch { /* ignore */ } return true; }   // 剛從休眠醒來：補送心跳，下一輪再看
    this.healthWhy = `心跳送出後 ${Math.round((now - this.lastAck) / 1000)} 秒沒有回應（連線可能已經斷了）`; return false;
  }
  _headers() { return { 'content-type': 'application/json', authorization: 'Bot ' + this.cfg.token }; }
  _connect(resume) {
    const WebSocket = require('ws'); const url = (resume && this.resumeUrl ? this.resumeUrl : 'wss://gateway.discord.gg') + '/?v=10&encoding=json';
    const ws = new WebSocket(url); this.ws = ws; this.ready = false; this.beatAcked = true; if (!this.downSince) this.downSince = Date.now();
    const send = (o) => { try { ws.send(JSON.stringify(o)); } catch { /* ignore */ } };
    const identify = () => send({ op: 2, d: { token: this.cfg.token, intents: 1 | 128 | 512 | 4096 | 32768, properties: { os: 'android', browser: 'line-agent', device: 'line-agent' } } });
    ws.on('message', (d) => {
      if (this.ws !== ws) { try { ws.terminate(); } catch { /* ignore */ } return; }   // 已經被換掉的舊連線還在收東西：直接關掉，不能動到新連線的狀態
      let p; try { p = JSON.parse(d.toString()); } catch { return; } if (p.s != null) this.seq = p.s;
      if (p.op === 10) {
        clearInterval(ws._hb); this.lastAck = Date.now(); const every = p.d.heartbeat_interval;
        const beat = () => { if (this.ws !== ws) return; if (!this.beatAcked) { log.warn('Discord 心跳沒有回應（連線已死），重連'); try { ws.terminate(); } catch { /* ignore */ } return; } this.beatAcked = false; this.lastBeatAt = Date.now(); send({ op: 1, d: this.seq }); };
        this._beat = beat; this.hbEvery = every; this.lastBeatAt = Date.now();
        setTimeout(() => { if (this.ws === ws) beat(); }, Math.random() * every);       // 官方建議第一拍加隨機延遲
        ws._hb = setInterval(beat, every); this.hb = ws._hb;   // 26.11.3 pro6：心跳計時器跟著「這一條」連線，舊連線晚到的 close 不會再把新連線的心跳停掉
        if (resume && this.session) send({ op: 6, d: { token: this.cfg.token, session_id: this.session, seq: this.seq } }); else identify();
      }
      else if (p.op === 11) { if (this.ws === ws) { this.lastAck = Date.now(); this.beatAcked = true; } }
      else if (p.op === 1) send({ op: 1, d: this.seq });
      else if (p.op === 7) { try { ws.close(4000); } catch { /* ignore */ } }                                   // 伺服器要求重連（可 resume）
      else if (p.op === 9) { if (!p.d) { this.session = null; this.seq = null; } setTimeout(() => { try { ws.close(p.d ? 4000 : 4001); } catch { /* ignore */ } }, 1500 + Math.random() * 3000); }
      else if (p.t === 'READY') { this.downSince = 0; this.me = p.d.user; this.session = p.d.session_id; this.resumeUrl = p.d.resume_gateway_url; this.ready = true; this.retry = 0; log.info('Discord 已連線：' + this.me.username); }
      else if (p.t === 'RESUMED') { this.downSince = 0; this.ready = true; this.retry = 0; log.info('Discord 已恢復連線（不漏訊息）'); }
      else if (p.t === 'MESSAGE_CREATE') this.message(p.d).catch((e) => log.error(e));
      else if (p.t === 'VOICE_STATE_UPDATE' || p.t === 'VOICE_SERVER_UPDATE') this._voiceEvt(p.t, p.d);
    });
    ws.on('close', (c) => {
      clearInterval(ws._hb); if (this.ws !== ws) return; this.ready = false; if (!this.downSince) this.downSince = Date.now();
      if (FATAL.has(c)) { this.fatal = `Discord 關閉連線（${c}）：${c === 4004 ? 'Bot Token 無效' : c === 4014 || c === 4013 ? '尚未在開發者後台開啟 MESSAGE CONTENT INTENT' : '設定有誤'}`; log.error(this.fatal); this.ctx.notifier.error('Discord 無法連線', this.fatal).catch(() => {}); return; }
      if (this.on) { const wait = Math.min(30000, 2000 * 2 ** Math.min(this.retry++, 4)); log.warn(`Discord 斷線 ${c}，${Math.round(wait / 1000)} 秒後重連`); this.rt = setTimeout(() => this.on && this._connect(c !== 4001 && c !== 4007 && c !== 4009 && !!this.session), wait); }
    });
    ws.on('error', (e) => log.warn('Discord ws 錯誤：' + e.message));
  }
  async guildOf(channelId) {
    return this.guilds.wrap(channelId, async () => { const r = await fetchJson(`${API}/channels/${channelId}`, { headers: this._headers() }, 8000); return (r.json && r.json.guild_id) || ''; });
  }
  async message(m) {
    if (!m.author || !this.me || m.author.id === this.me.id) return; const group = !!m.guild_id; const text = m.content || '';
    // 26.11.3 pro6：其他機器人的訊息不再整個丟掉——群組裡會記下來（分得出是哪個機器人），它 @你或回覆你的訊息時可以跟它對話（hub 會限制來回次數，避免兩個機器人無限互聊）；私訊裡的機器人一律不理
    const isBot = !!m.author.bot || !!m.webhook_id; if (isBot && !group) return;
    if (group) this.guilds.set(m.channel_id, m.guild_id);
    const refs = this.ctx.refs; const nameOf = (x, mem) => (mem && mem.nick) || (x && (x.global_name || x.username)) || '';
    const imgs = (m.attachments || []).filter((a) => (a.content_type || '').startsWith('image/'));
    const auds = (m.attachments || []).filter((a) => (a.content_type || '').startsWith('audio/'));   // 語音訊息（Discord 送 audio/ogg）
    const docs = (m.attachments || []).filter((a) => !/^(image|audio|video)\//.test(a.content_type || ''));   // 其他檔案（PDF、Word…）
    refs.put('discord', m.channel_id, { id: m.id, text: text || (imgs.length ? '[圖片]' : ''), name: nameOf(m.author, m.member), uid: m.author.id, img: imgs.length > 0 });
    // 引言：Discord 的「回覆」會帶整則被回覆的訊息（referenced_message）；沒帶（太舊／被刪）就向 API 補抓
    let quote = null; let qImgs = [];
    const rid_ = m.message_reference && m.message_reference.message_id;
    if (rid_ && m.type === 19) {
      let rm = m.referenced_message;
      if (!rm) { try { const r = await fetchJson(`${API}/channels/${m.channel_id}/messages/${rid_}`, { headers: this._headers() }, 8000); if (r.ok) rm = r.json; } catch { /* 抓不到就算了 */ } }
      if (rm && rm.author) {
        qImgs = (rm.attachments || []).filter((a) => (a.content_type || '').startsWith('image/'));
        const body = rm.content || (rm.embeds && rm.embeds[0] && (rm.embeds[0].description || rm.embeds[0].title)) || '';
        quote = { id: rm.id, text: body || (qImgs.length ? '[圖片]' : ''), name: nameOf(rm.author, rm.member), fromBot: rm.author.id === this.me.id, hasImage: qImgs.length > 0 };
        refs.put('discord', m.channel_id, { id: rm.id, text: quote.text, name: quote.name, uid: rm.author.id, bot: quote.fromBot, img: qImgs.length > 0 });
      } else quote = { id: rid_, text: '', name: '', fromBot: false, hasImage: false, unknown: true };
    }
    const aliases = (this.ctx.settings.get('bot.aliases') || []).filter(Boolean);
    const direct = (m.mentions || []).some((u) => u.id === this.me.id) || new RegExp(`<@!?${this.me.id}>`).test(text);
    const mentioned = !group || direct || !!(quote && quote.fromBot) || (!isBot && aliases.some((a) => text.includes(a)));
    // @ 了別人（不是你）：多半是在跟那個人說話
    const others = (m.mentions || []).filter((u) => u.id !== this.me.id); const mentionsOthers = others.length > 0 || /@everyone|@here|<@&\d+>/.test(text);
    for (const u of others) if (group) this.ctx.hub.noteMember('discord', m.channel_id, u.id, nameOf(u, u.member), !!u.bot);
    const dl = async (list) => Promise.all(list.slice(0, 3).map(async (a) => { const r = await fetchBuf(a.url, {}, 25000, 8 * 1024 * 1024); return { mime: a.content_type, data: r.buf.toString('base64') }; }));
    const msg = { platform: 'discord', chatId: m.channel_id, chatType: group ? 'group' : 'dm', chatName: '', uid: m.author.id, userName: nameOf(m.author, m.member),
      text: text.replace(new RegExp(`<@!?${this.me.id}>`, 'g'), '').replace(/<@!?(\d+)>/g, (s, id) => { const u = others.find((x) => x.id === id); return u ? '@' + nameOf(u, u.member) : s; }).trim(), mentioned: !!mentioned, direct, mentionsOthers, isBot, botName: isBot ? nameOf(m.author, m.member) : '', ts: Date.parse(m.timestamp) || Date.now(), hasImage: imgs.length > 0, hasAudio: auds.length > 0, msgId: m.id, quote,
      hasDoc: docs.length > 0, docName: docs[0] ? docs[0].filename : '', docSize: docs[0] ? docs[0].size : 0,
      fetchDoc: async () => { const r = await fetchBuf(docs[0].url, {}, 45000, 25 * 1024 * 1024); return { name: docs[0].filename || 'file', mime: docs[0].content_type || '', buf: r.buf }; },
      ref: { id: m.id }, fetchAudio: async () => { const r = await fetchBuf(auds[0].url, {}, 30000, 20 * 1024 * 1024); return { mime: auds[0].content_type, data: r.buf.toString('base64') }; }, fetchImages: () => dl(imgs), fetchQuotedImages: () => dl(qImgs), typing: () => this.typing(m.channel_id), _quoted: false };
    msg.reply = (t, o = {}) => { const wq = o.quote !== undefined ? o.quote : msg.wantQuote; const q = wq && !msg._quoted; if (q) msg._quoted = true; return this.send(m.channel_id, t, { quote: q ? { id: m.id } : undefined }); };
    msg.sendImage = (img, caption) => { const wq = msg.wantQuote && !msg._quoted; if (wq) msg._quoted = true; return this.sendImage(m.channel_id, img, caption, { quote: wq ? { id: m.id } : undefined }); };
    await this.ctx.hub.incoming(msg);
  }
  // ===== 26.11.3 Revise6 會議監聽：讓 Bot 進／出語音頻道（真正收音的是 voice-worker，見 services/dvoice.js）=====
  /** 送 op 4，等 Discord 回 VOICE_STATE_UPDATE（session_id）＋VOICE_SERVER_UPDATE（token、endpoint） */
  voiceJoin(guildId, channelId, { timeout = 15000 } = {}) {
    if (!this.ws || !this.ready || !this.me) return Promise.reject(new Error('Discord Bot 還沒連線'));
    return new Promise((resolve, reject) => {
      const got = { guild_id: String(guildId), channel_id: String(channelId), user_id: this.me.id }; const t = setTimeout(() => { this._vwait = null; reject(new Error('Discord 沒有回應進入語音頻道（Bot 有「連接」權限嗎？）')); }, timeout);
      this._vwait = { guildId: String(guildId), on: (k, d) => { if (k === 'state') got.session_id = d.session_id; else { got.token = d.token; got.endpoint = d.endpoint; } if (got.session_id && got.token && got.endpoint) { clearTimeout(t); this._vwait = null; resolve(got); } } };
      try { this.ws.send(JSON.stringify({ op: 4, d: { guild_id: String(guildId), channel_id: String(channelId), self_mute: true, self_deaf: false } })); } catch (e) { clearTimeout(t); this._vwait = null; reject(e); }
    });
  }
  voiceLeave(guildId) { try { this.ws && this.ws.send(JSON.stringify({ op: 4, d: { guild_id: String(guildId), channel_id: null, self_mute: false, self_deaf: false } })); } catch { /* ignore */ } }
  /** voice-worker 要 Bot 送的 gateway 封包（只允許 op 4：進出語音頻道） */
  voicePayload(payload) { if (!payload || payload.op !== 4 || !this.ws) return false; try { this.ws.send(JSON.stringify({ op: 4, d: payload.d })); return true; } catch { return false; } }
  _voiceEvt(t, d) {
    if (!d) return; if (t === 'VOICE_STATE_UPDATE' && (!this.me || d.user_id !== this.me.id)) return;
    const w = this._vwait; if (w && String(d.guild_id) === w.guildId) w.on(t === 'VOICE_STATE_UPDATE' ? 'state' : 'server', d);
    if (this.ctx.dvoice) this.ctx.dvoice.gatewayEvent(t, d);
  }
  /** 找語音頻道：名字或 ID；guildId 不給就找 Bot 所在的所有伺服器 */
  async findVoiceChannel(q, guildId) {
    const h = { headers: this._headers() }; const guilds = guildId ? [{ id: String(guildId) }] : ((await fetchJson(`${API}/users/@me/guilds`, h, 10000)).json || []);
    const want = String(q || '').trim().toLowerCase(); const found = [];
    for (const g of guilds.slice(0, 50)) {
      const r = await fetchJson(`${API}/guilds/${g.id}/channels`, h, 10000); if (!r.ok || !Array.isArray(r.json)) continue;
      for (const c of r.json) if (c.type === 2 || c.type === 13) found.push({ id: c.id, name: c.name, guild_id: g.id, guild: g.name || '' });
    }
    if (!want) return found;
    return found.filter((c) => c.id === want || c.name.toLowerCase() === want).concat(found.filter((c) => c.id !== want && c.name.toLowerCase() !== want && c.name.toLowerCase().includes(want)));
  }
  async userName(guildId, userId) {
    return this.guilds.wrap('name:' + guildId + ':' + userId, async () => { const r = await fetchJson(`${API}/guilds/${guildId}/members/${userId}`, { headers: this._headers() }, 8000); const m = r.json || {}; return m.nick || (m.user && (m.user.global_name || m.user.username)) || userId; });
  }
  // ---- engine5.4：刪除／收回訊息、改頻道名稱 ----
  _why(r, act) {
    const code = r.json && r.json.code; const msg = (r.json && r.json.message) || (r.text || '').slice(0, 120);
    if (r.status === 403 || code === 50013) return `${act}失敗：Bot 沒有權限（Discord 伺服器設定 → 身分組 → 給 Bot 的身分組打開「${act.includes('頻道') ? '管理頻道' : '管理訊息'}」，或在這個頻道的權限設定裡允許）`;
    if (r.status === 404 || code === 10008 || code === 10003) return `${act}失敗：找不到（可能已經被刪掉，或不在這個頻道）`;
    if (r.status === 429) return `${act}失敗：Discord 限速${act.includes('頻道') ? '（同一個頻道改名 10 分鐘內只能改 2 次）' : ''}，請 ${Math.ceil(((r.json && r.json.retry_after) || 60))} 秒後再試`;
    return `${act}失敗：${r.status} ${msg}`;
  }
  async deleteMessage(channelId, msgId) {
    const r = await fetchJson(`${API}/channels/${channelId}/messages/${msgId}`, { method: 'DELETE', headers: this._headers() }, 15000);
    if (r.status === 204 || r.ok) return true; throw new Error(this._why(r, '刪除訊息'));
  }
  async channelInfo(channelId) { const r = await fetchJson(`${API}/channels/${channelId}`, { headers: this._headers() }, 10000); if (!r.ok) throw new Error(this._why(r, '讀取頻道')); return r.json; }
  async listChannels(guildId) { const r = await fetchJson(`${API}/guilds/${guildId}/channels`, { headers: this._headers() }, 10000); if (!r.ok) throw new Error(this._why(r, '讀取頻道清單')); return r.json || []; }
  /** 改頻道：name、topic（文字頻道的主題）。name 會照 Discord 規則：文字頻道自動變小寫、空白變 -（中文可以） */
  async editChannel(channelId, { name, topic } = {}) {
    const body = {}; if (name) body.name = String(name).slice(0, 100); if (topic !== undefined && topic !== null) body.topic = String(topic).slice(0, 1024);
    if (!Object.keys(body).length) throw new Error('要給新名稱或主題');
    const r = await fetchJson(`${API}/channels/${channelId}`, { method: 'PATCH', headers: { ...this._headers(), 'x-audit-log-reason': encodeURIComponent('AI 中控中心（管理員要求）') }, body: JSON.stringify(body) }, 15000);
    if (!r.ok) throw new Error(this._why(r, '改頻道'));
    return r.json;
  }
  async typing(channelId) { try { await fetchJson(`${API}/channels/${channelId}/typing`, { method: 'POST', headers: this._headers() }, 5000); } catch { /* 不重要 */ } }
  async _ref(channelId, quote) {
    if (!quote) return {}; const guild = await this.guildOf(channelId).catch(() => '');
    return { message_reference: { message_id: String(quote.id), channel_id: channelId, ...(guild ? { guild_id: guild } : {}), fail_if_not_exists: false } };
  }
  /** 回覆／主動送出。quote={id}：用 Discord 的「回覆」功能引用那則訊息（只有第一段會引用）。allowed_mentions 關掉 @everyone／身分組，只保留被回覆者的通知 */
  async send(channelId, text, opt = {}) {
    let first = true; let last;
    text = require('./common').mdTables(text);   // 26.11.3 Revise7：表格改成看得懂的文字
    for (const t of splitText(text, 1900)) {
      const mm = M.discord(this.ctx, channelId, t);   // @[名字] → <@id>，只通知被點名的人
      // nonce＋enforce_nonce：重試時 Discord 自己去重，不會出現兩則一樣的訊息
      const body = { content: mm.content, allowed_mentions: { parse: [], users: mm.users, replied_user: true }, nonce: String(Date.now()) + String(Math.floor(Math.random() * 1e6)).padStart(6, '0'), enforce_nonce: true, ...(first ? await this._ref(channelId, opt.quote) : {}) }; first = false;
      let r = await fetchSend(`${API}/channels/${channelId}/messages`, { method: 'POST', headers: this._headers(), body: JSON.stringify(body) }, { idempotent: true, onRetry: (w, a) => log.warn(`Discord 發送第 ${a} 次失敗（${w}），重試`) });
      if (r.status === 429 && r.json && r.json.retry_after) { await new Promise((ok) => setTimeout(ok, Math.min(8000, r.json.retry_after * 1000 + 100))); r = await fetchJson(`${API}/channels/${channelId}/messages`, { method: 'POST', headers: this._headers(), body: JSON.stringify(body) }, 20000); }
      if (!r.ok && body.message_reference && r.status === 400) { delete body.message_reference; r = await fetchJson(`${API}/channels/${channelId}/messages`, { method: 'POST', headers: this._headers(), body: JSON.stringify(body) }, 20000); }   // 原訊息被刪：退回一般發送
      if (!r.ok) throw new Error(`Discord 發送失敗 ${r.status} ${r.text.slice(0, 150)}`);
      last = r.json; if (last && last.id) { this.ctx.refs.put('discord', channelId, { id: last.id, text: t, bot: true, name: 'AI' }); }
    }
    return last;
  }
  /** 直接上傳圖片（multipart），不需要任何公開網址 */
  async sendImage(channelId, img, caption, opt = {}) {
    const payload = { content: caption ? String(caption).slice(0, 1900) : '', allowed_mentions: { parse: [], replied_user: true }, ...(await this._ref(channelId, opt.quote)) };
    const fd = form({ payload_json: JSON.stringify(payload) }, { field: 'files[0]', buf: img.buf, mime: img.mime, name: `image.${extOf(img.mime)}` });
    const r = await fetchJson(`${API}/channels/${channelId}/messages`, { method: 'POST', headers: { authorization: 'Bot ' + this.cfg.token }, body: fd }, 60000);
    if (!r.ok) throw new Error(`Discord 傳圖失敗 ${r.status} ${r.text.slice(0, 150)}`);
    if (r.json && r.json.id) this.ctx.refs.put('discord', channelId, { id: r.json.id, text: caption || '[圖片]', bot: true, img: true, name: 'AI' }); return r.json;
  }
  async sendFile(channelId, f) {
    const fd = form({ payload_json: JSON.stringify({ content: '', allowed_mentions: { parse: [] } }) }, { field: 'files[0]', buf: f.buf, mime: f.mime, name: f.name });
    const r = await fetchJson(`${API}/channels/${channelId}/messages`, { method: 'POST', headers: { authorization: 'Bot ' + this.cfg.token }, body: fd }, 90000);
    if (!r.ok) throw new Error(`Discord 傳檔失敗 ${r.status} ${r.text.slice(0, 150)}`); return r.json;
  }
  async sendToUser(uid, text) {
    let ch = this.dmCache.get(uid); if (!ch) { const r = await fetchJson(`${API}/users/@me/channels`, { method: 'POST', headers: this._headers(), body: JSON.stringify({ recipient_id: uid }) }, 15000);
      if (!r.ok) throw new Error('無法開啟 Discord 私訊 ' + r.status); ch = r.json.id; this.dmCache.set(uid, ch); } return this.send(ch, text);
  }
}
module.exports = { Discord };
