'use strict';
/**
 * 跨平台 @提及：AI 在回覆裡寫 @[名字]，送出時依平台轉成「真正會通知對方」的提及。
 *   LINE：textV2 ＋ substitution（mention）；只在群組／多人聊天室有效
 *   Discord：<@使用者ID> ＋ allowed_mentions.users（只通知被點名的人，不會 @everyone）
 *   Telegram：text_mention 實體（不需要對方有 username）
 * 找不到這個人 → 退回純文字「@名字」，不會亂 tag 到別人。
 */
const TOKEN = /@\[([^\]\n]{1,40})\]/g;

/** 名字 → 該聊天室成員 uid（完全相同優先，其次不分大小寫，再其次唯一的包含比對） */
function resolve(ctx, platform, chatId, name) {
  const want = String(name || '').trim(); if (!want) return null;
  const chat = (ctx.store.db.chats || {})[`${platform}:${chatId}`]; const members = Object.entries((chat && chat.members) || {});
  for (const p of ctx.users.list()) { const id = (p.identities || []).find((i) => i.platform === platform); if (id && !members.some(([u]) => u === id.uid) && (p.name || id.name)) members.push([id.uid, p.name || id.name]); }
  const norm = (s) => String(s || '').trim().toLowerCase();
  let hit = members.find(([, n]) => String(n || '').trim() === want) || members.find(([, n]) => norm(n) === norm(want));
  if (!hit) { const c = members.filter(([, n]) => n && (norm(n).includes(norm(want)) || norm(want).includes(norm(n)))); if (c.length === 1) hit = c[0]; }
  if (!hit) { const p = ctx.users.find && ctx.users.find(want); const id = p && (p.identities || []).find((i) => i.platform === platform); if (id) hit = [id.uid, p.name || want]; }
  return hit ? { uid: hit[0], name: String(hit[1] || want) } : null;
}
const has = (text) => { TOKEN.lastIndex = 0; return TOKEN.test(String(text || '')); };
/** 沒有平台功能時：把 @[名字] 換成 @名字 */
const plain = (text) => String(text || '').replace(TOKEN, (_, n) => '@' + n.trim());

/** Discord：回傳 {content, users} */
function discord(ctx, chatId, text) {
  const users = []; const content = String(text || '').replace(TOKEN, (_, n) => { const r = resolve(ctx, 'discord', chatId, n); if (!r) return '@' + n.trim(); if (!users.includes(r.uid)) users.push(r.uid); return `<@${r.uid}>`; });
  return { content, users: users.slice(0, 100) };
}
/** Telegram：回傳 {text, entities}（offset／length 以 UTF-16 計，JS 字串長度剛好就是） */
function telegram(ctx, chatId, text) {
  const entities = []; let out = ''; let last = 0; const s = String(text || ''); TOKEN.lastIndex = 0; let m;
  while ((m = TOKEN.exec(s))) {
    out += s.slice(last, m.index); last = m.index + m[0].length; const r = resolve(ctx, 'telegram', chatId, m[1]); const label = '@' + (r ? r.name : m[1].trim());
    if (r && /^\d+$/.test(r.uid)) entities.push({ type: 'text_mention', offset: out.length, length: label.length, user: { id: Number(r.uid) } });
    out += label;
  }
  return { text: out + s.slice(last), entities };
}
/** LINE：回傳一則訊息物件（有可用的提及且是群組 → textV2，否則一般 text） */
function line(ctx, chatId, text, extra = {}) {
  const s = String(text || ''); const group = /^[CR]/.test(String(chatId || ''));
  if (!group || !has(s) || /[{}]/.test(s.replace(TOKEN, ''))) return { type: 'text', text: plain(s), ...extra };   // 文字本身有大括號時不用 textV2（避免被當成替換鍵）
  const sub = {}; let i = 0;
  const t = s.replace(TOKEN, (_, n) => { const r = resolve(ctx, 'line', chatId, n); if (!r || i >= 100) return '@' + n.trim(); const k = 'm' + (i++); sub[k] = { type: 'mention', mentionee: { type: 'user', userId: r.uid } }; return `{${k}}`; });
  return i ? { type: 'textV2', text: t, substitution: sub, ...extra } : { type: 'text', text: plain(s), ...extra };
}
module.exports = { resolve, discord, telegram, line, plain, has, TOKEN };
