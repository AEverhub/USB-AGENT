'use strict';
const crypto = require('crypto');
const { logger } = require('../core/log');
const { rid, KeyedQueue, clip } = require('../core/util');
const { Line } = require('./line');
const { Telegram } = require('./telegram');
const { Discord } = require('./discord');
const log = logger('hub');

const safeEq = (a, b) => { const x = Buffer.from(String(a)), y = Buffer.from(String(b)); return x.length === y.length && crypto.timingSafeEqual(x, y); };

class Hub {
  constructor(ctx) {
    this.ctx = ctx; this.q = new KeyedQueue(5 * 60e3);   // 同一個聊天室的任務依序處理；單一任務最長 5 分鐘，卡住也不會堵死整個聊天室
    this.connectors = { line: new Line(ctx), telegram: new Telegram(ctx), discord: new Discord(ctx) };
    this.warned = new Map(); this.claimFails = new Map();
    ctx.approvals.register('new_user', async (p) => {
      const u = ctx.users.byId(p.pid); if (!u) throw new Error('使用者已不存在'); ctx.users.setRole(u.id, p.role || 'user');
      await this.sendToPerson(u, `✅ 你已通過管理員審核，現在可以開始使用了！有什麼想問的，直接說吧。\n（使用即表示同意用戶條款；傳「條款」可以查看重點。）`).catch(() => {}); return `已開通 ${u.name || u.id}（${p.role || 'user'}）`;
    });
  }
  once(key, ms = 6 * 3600e3) { const t = this.warned.get(key) || 0; if (Date.now() - t < ms) return false; this.warned.set(key, Date.now()); return true; }

  async incoming(msg) {
    if (!msg.receivedAt) msg.receivedAt = Date.now();
    const { users, store, settings } = this.ctx; const db = store.db;
    const text = (msg.text || '').trim(); const group = msg.chatType === 'group';
    if (group) { const k = `${msg.platform}:${msg.chatId}`; const c = db.chats[k] || (db.chats[k] = { platform: msg.platform, chatId: msg.chatId, type: 'group', name: '', last_seen: 0, members: {} });
      if (msg.chatName) c.name = msg.chatName; c.last_seen = Date.now(); c.members[msg.uid] = msg.userName || c.members[msg.uid] || ''; if (msg.isBot) { c.bots = c.bots || {}; c.bots[msg.uid] = msg.userName || msg.botName || ''; } store.touch();
      this.noteSpeaker(msg); }
    // 26.11.3 pro6：群組裡其他機器人的訊息——記下來；只有它直接 @你／回覆你的訊息、而且沒有超過來回次數上限時才回它
    if (msg.isBot) return this.fromBot(msg);
    // ---- 平台層指令（不經過模型）----
    let m;
    if ((m = /^\/claim\s+(\S+)/i.exec(text))) return msg.reply(await this.claim(msg, m[1]));
    if (/^(\/terms|用戶條款|使用條款|服務條款|條款)$/i.test(text) && this.ctx.terms) return msg.reply(this.ctx.terms.summary());   // 26.11.3 pro10
    if ((m = /^(?:確認|confirm)\s*[:：]?\s*(\d{4})\s*$/i.exec(text))) { const pp = users.byIdentity(msg.platform, msg.uid); if (pp && pp.role === 'admin' && pp.status === 'active' && this.ctx.grants) { const r = this.ctx.grants.confirm(pp, m[1]); if (r) return msg.reply(r); } }
    if ((m = /^(?:\/link|連結驗證碼|驗證碼)\s*[:：]?\s*(\d{6})\s*$/i.exec(text))) return msg.reply(await this.link(msg, m[1]));

    let person = users.byIdentity(msg.platform, msg.uid);
    const scope = group ? `chat_${msg.platform}_${msg.chatId}` : null;
    // 26.11.2 多人聊天：叫 AI 的名字（人設名字／別名）也算在叫它；剛跟它說完話的人接著說，也算在跟它說（不用每句都 @）
    if (group && !msg.mentioned) { const why = this.addressed(msg, text); if (why) { msg.mentioned = true; msg.addressedBy = why; } }
    else if (group && msg.mentioned && !msg.addressedBy) msg.addressedBy = msg.direct ? 'mention' : msg.quote && msg.quote.fromBot ? 'reply' : 'name';
    if (group && !msg.mentioned) {            // 群組靜默記錄，不回話
      if (settings.get('policy.group_trigger') !== 'all' || !person || person.status !== 'active') { this.keepGroup(scope, { role: 'user', uid: msg.uid, name: msg.userName || (person && person.name) || '', text: text || (msg.hasImage ? '[圖片]' : msg.hasAudio ? '[語音]' : msg.hasSticker ? '[貼圖]' : ''), mid: msg.msgId, platform: msg.platform }); return; }
    }
    if (!person) {
      person = users.create({ platform: msg.platform, uid: msg.uid, name: msg.userName });
      if (!users.hasAdmin()) return msg.reply('嗨！目前還沒有管理員。如果你是這個 AI 的主人，請「私訊」我：/claim 你的密碼（密碼在 App 的開發者頁設定）。');
      if (settings.get('policy.approve_new_users')) {
        await this.ctx.approvals.request({ kind: 'new_user', summary: `新用戶「${msg.userName || '未命名'}」（${msg.platform}）想使用，第一句話：${clip(text, 60)}`, payload: { pid: person.id, role: 'user' }, requester: person.id, chat: { platform: msg.platform, chatId: msg.chatId } });
        return msg.reply('你好！我已經通知管理員審核，通過後我會馬上通知你。');
      }
      users.setRole(person.id, 'user');
    }
    users.attach(person.id, msg.platform, msg.uid, msg.userName); person.lastPlatform = msg.platform;
    if (person.status === 'blocked') return;
    if (person.status === 'pending' || person.role === 'guest') { if (this.once('pend:' + person.id, 3600e3)) return msg.reply('你還在等管理員審核中，通過後我會通知你。'); return; }
    if (!users.can(person, 'chat')) return;
    if (users.quietBlocked(person)) { if (this.once('quiet:' + person.id)) return msg.reply(settings.get('policy.reply_in_quiet')); return; }
    users.touchSeen(person);
    // 管理員設定的使用次數：用完就不再呼叫模型（省錢），只提醒一次
    if (users.quotaLeft(person) <= 0) { const q = person.quota; const per = { day: '今天', hour: '這個小時', week: '這週', total: '總共' }[q.per] || '今天'; if (this.once('quota:' + person.id + ':' + q.window, 6 * 3600e3)) return msg.reply(`${per}可以找我的 ${q.limit} 次已經用完了，${q.per === 'total' ? '請管理員調整' : '之後再來'}喔。`); return; }
    users.quotaUse(person);
    msg.wantQuote = this.shouldQuote(msg, group);
    // 群組裡不同人的請求同時處理（不用排隊等別人的長任務）；同一個人仍依序
    return this.q.run(group ? `${scope}:${person.id}` : 'dm_' + person.id, async () => {
      // 「正在輸入…」：讓對方馬上知道我有收到、在處理（Telegram／Discord 每 4.5 秒補一次，LINE 用載入動畫）
      const ping = () => { try { const r = msg.typing && msg.typing(); if (r && r.catch) r.catch(() => {}); } catch { /* ignore */ } }; ping(); const tt = setInterval(ping, 4500);
      // 26.11.2：做很久的事（開瀏覽器、查很多資料）超過 N 秒先回一句「還在處理」，對方才不會以為沒反應。LINE 預設不送（會用掉推播額度）
      const S2 = this.ctx.settings; const ns = +S2.get('policy.progress_notice_s', 25);
      const pn = ns > 0 && msg.platform !== 'app' && (msg.platform !== 'line' || S2.get('policy.progress_notice_line', false)) ? setTimeout(() => { msg._noticed = true; msg.reply(Hub.doing(msg._doing), { quote: false }).catch(() => {}); }, ns * 1000) : null;
      try {
        let images = [];
        if (msg.hasImage || (msg.quote && msg.quote.hasImage)) {
          const [own, quoted] = await Promise.all([msg.hasImage ? msg.fetchImages().catch((e) => { log.warn('取圖失敗：' + e.message); return []; }) : [], msg.quote && msg.quote.hasImage && msg.fetchQuotedImages ? msg.fetchQuotedImages().catch((e) => { log.warn('取被引用的圖失敗：' + e.message); return []; }) : []]);
          images = [...quoted, ...own].slice(0, 4);
        }
        // 語音訊息：先轉成文字再交給 AI（失敗也要讓 AI 知道，才能跟對方說明）
        if (msg.hasAudio && msg.fetchAudio && this.ctx.speech) {
          try { const a = await msg.fetchAudio(); const r = await this.ctx.speech.transcribe(a); msg.voiceText = r.text; msg.text = `${msg.text ? msg.text + '\n' : ''}🎤（語音轉文字）${r.text}`; }
          catch (e) { log.warn('語音轉文字失敗：' + e.message); msg.text = `${msg.text ? msg.text + '\n' : ''}（使用者傳了一段語音，但轉文字失敗：${e.message}。請簡短告訴對方原因，請他改打字或稍後再試。）`; }
        }
        // 26.11.3 Revise4：使用者傳了檔案 → 存到工作區 inbox/<人>/，告訴 AI 路徑，它就能用 doc_read 讀
        if (msg.hasDoc && msg.fetchDoc) {
          try {
            const d = await msg.fetchDoc(); const sv = this.saveInbox(person, d); const orig = String(msg.text || '').replace(/^\[file\][^\n]*$/, '').trim();
            msg._storeText = orig; msg._userFiles = [{ id: sv.rec.id, name: sv.rec.name, size: sv.rec.size, mime: sv.rec.mime }];
            msg.text = `${orig}${orig ? '\n' : ''}${sv.note}`;
          } catch (e) { log.warn('取檔案失敗：' + e.message); msg.text = `${msg.text || ''}（使用者傳了檔案「${msg.docName}」，但下載失敗：${e.message}。請告訴他原因。）`; }
        }
        let out;
        try { out = await this.ctx.agent.handle({ person, msg, images, group, scope: scope || 'dm_' + person.id }); }
        catch (e) { log.error('agent 失敗', e); this.ctx.debug.recordError('agent', e); out = '抱歉，我這邊出了點狀況：' + e.message; this.ctx.notifier.error('AI 處理失敗', `${person.name || person.id}：${e.message}`).catch(() => {}); }
        // AI 指定要引用（回覆）另一則訊息：回覆開頭寫 [[回覆:#編號]]
        const qd = /^\s*\[\[(?:quote|reply|回覆|引言)\s*[:：]\s*#?([\w-]+)\]\]\s*/i.exec(out || '');
        if (qd) { out = out.slice(qd[0].length); if (['line', 'discord', 'telegram'].includes(msg.platform) && this.ctx.refs.get(msg.platform, msg.chatId, qd[1])) { try { await this.send(msg.platform, msg.chatId, out, { quote: { id: qd[1] } }); return; } catch (e) { log.warn('指定引言失敗，改一般回覆：' + e.message); } } }
        const deliverFiles = async () => { for (const f of (msg.platform === 'net' ? [] : msg._files || [])) { try { await this.sendFile(msg.platform, msg.chatId, f); } catch (e) { log.warn('送檔失敗：' + e.message); await msg.reply(`檔案「${f.name}」送不出去（${e.message}），請到 App 對話頁下載。`, { quote: false }).catch(() => {}); } } };
        const tSend = Date.now(); const tRecv = msg.receivedAt || tSend;
        if (group && out) this.markReplied(msg, out);
        try { await msg.reply(out || '', { quote: msg.wantQuote }); const ms = Date.now() - tSend; require('../core/slow').note(`送出回覆到 ${msg.platform}`, ms); this.ctx.debug.delivery && this.ctx.debug.delivery({ platform: msg.platform, send_ms: ms, total_ms: Date.now() - tRecv, at: Date.now() }); if (ms > 3000) log.warn(`送出到 ${msg.platform} 花了 ${ms} ms`); await deliverFiles(); }
        catch (e) {
          log.error('回覆失敗', e); this.ctx.notifier.warn('回覆失敗', `${msg.platform}：${e.message}`).catch(() => {});
          // 引言失敗（例如原訊息被刪）不應該讓整則回覆消失：退回不引言再送一次
          if (msg.wantQuote) { try { await msg.reply(out || '', { quote: false }); } catch (e2) { log.error('退回一般回覆也失敗', e2); } }
        }
      } finally { clearInterval(tt); clearTimeout(pn); }
    });
  }
  /** 畫面上「AI 正在做什麼」的短句（App 對話的等待泡泡用） */
  static progress(msg) {
    if (!msg) return null; const t = String(msg._doing || 'think'); const ms = Date.now() - (msg._t0 || Date.now());
    const what = t === 'think' ? '思考中' : /^browser_|^form_/.test(t) ? '正在網頁上操作' : /web_search/.test(t) ? '正在搜尋' : /fetch_url/.test(t) ? '正在讀網頁' : /make_file|sheet_/.test(t) ? '正在做檔案' : /ledger/.test(t) ? '正在記帳' : /places|route/.test(t) ? '正在查地圖' : /doc_read/.test(t) ? '正在讀文件' : /termux|linux|shell/.test(t) ? '正在電腦上跑指令' : t.startsWith('mcp__') ? '正在連線外部服務' : /gmail|gcal|gdrive|gdocs|gsheets|google/.test(t) ? '正在用 Google' : /image/.test(t) ? '正在處理圖片' : /task_plan/.test(t) ? '正在安排步驟' : '正在處理';
    return { doing: what, round: msg._round || 1, sec: Math.round(ms / 1000), ...(msg._bstep && (!this.ctx.browser || this.ctx.browser.showSteps()) ? { browser_step: msg._bstep } : {}) };
  }
  static doing(tool) {
    const t = String(tool || ''); const what = /^browser_|^form_/.test(t) ? '正在網頁上操作' : /web_search|fetch_url/.test(t) ? '正在查資料' : /make_file|sheet_/.test(t) ? '正在做檔案' : /termux|linux|shell/.test(t) ? '正在電腦上跑指令' : t.startsWith('mcp__') ? '正在連線外部服務' : /image/.test(t) ? '正在處理圖片' : '還在處理';
    return `${what}，需要一點時間，好了馬上回你。`;
  }

  /**
   * 群組裡沒有 @ 也算在叫 AI 的情況（回傳原因字串，或 null）：
   *  1. 叫了 AI 的名字：人設名字、設定的別名（例：「小管家幫我查一下」）
   *  2. 對話延續：AI 剛回覆這個人（policy.group_followup_s 秒內，預設 90），他接著說的話看起來是在接續
   *     （AI 上一句是問句、或這句是問句／「那…」「再…」「幫我…」「改成…」這類接話）；寒暄（謝謝、收到、哈哈）不算
   *  有 @ 別人、或明顯在跟別人說話時不算。
   */
  addressed(msg, text) {
    const S = this.ctx.settings; const t = String(text || '').trim(); if (!t) return null;
    if (msg.mentionsOthers || (msg.quote && !msg.quote.fromBot)) return null;   // @了別人、或回覆別人的訊息＝在跟別人說話
    const names = [S.get('persona.name'), ...(S.get('bot.aliases') || [])].map((x) => String(x || '').trim()).filter((x) => x.length >= 2);
    // 叫名字：要像在叫它（句首、或「名字＋，／空白／幫我…」），聊天中順口提到它（「小管家很好用」）不算
    for (const n of names) { const i = t.indexOf(n); if (i < 0) continue; const after = t.slice(i + n.length, i + n.length + 4); if (i <= 2 || /^[\s,，:：!！~～、]|^(你|妳|幫|請|可以|能不能|在嗎|在不在|呢|啊|喔)/.test(after)) return 'name'; }
    // 26.11.3 pro6：「接著說」改嚴格——只在這個人剛跟 AI 說完、中間沒有別人插話，而且 AI 上一句是在問他、或這句明顯是在接著要求（不只是「好」「對」這種可能是在回別人的話）
    const secs = +S.get('policy.group_followup_s', 60); if (!secs) return null;
    const last = (this._talk || new Map()).get(`${msg.platform}:${msg.chatId}:${msg.uid}`); if (!last || Date.now() - last.at > secs * 1000) return null;
    const sp = (this._speakers || new Map()).get(`${msg.platform}:${msg.chatId}`) || []; if (sp.some((x) => x.at > last.at && x.uid !== msg.uid)) return null;   // AI 回完之後有別人說話了：話題可能換人了
    if (/@\S/.test(t)) return null;
    if (/^(謝謝|感謝|謝啦|3q|thx|thanks|收到|了解|ok|okay|好喔|好的喔|讚|哈+|呵+|lol|👍)[!！。~～\s]*$/i.test(t)) return null;
    if (last.asked && t.length <= 40) return 'followup';
    if (/^(那|再|還有|另外|順便|幫我|改成|換成|不是.{0,4}(我要|是要)|可以再|然後呢|為什麼)/.test(t) || (/[?？]\s*$/.test(t) && /(你|妳|它|幫|嗎|呢)/.test(t))) return 'followup';
    return null;
  }
  /** 26.11.3 pro6：群組訊息寫進紀錄前先過濾（廢話不存、其他精簡），見 services/groupmem.js */
  keepGroup(scope, rec, addressed = false) { const g = this.ctx.groupmem; const r = g ? g.prepare(rec, { addressed }) : rec; if (r) this.ctx.store.addMessage(scope, r); return !!r; }
  /** 記住群組裡最近誰說了話（判斷「接著說」用；AI 回完之後有別人插話就不算接著說） */
  noteSpeaker(msg) { if (!this._speakers) this._speakers = new Map(); const k = `${msg.platform}:${msg.chatId}`; const l = this._speakers.get(k) || []; l.push({ uid: msg.uid, at: Date.now(), bot: !!msg.isBot }); while (l.length > 12) l.shift(); this._speakers.set(k, l); if (this._speakers.size > 300) this._speakers.delete(this._speakers.keys().next().value); }
  /** 被別人 @ 到的成員（Discord 帶得到名字與是不是機器人）也記到群組成員，AI 才能 @[名字] 叫到它 */
  noteMember(platform, chatId, uid, name, bot) { const c = (this.ctx.store.db.chats || {})[`${platform}:${chatId}`]; if (!c) return; if (name && !c.members[uid]) c.members[uid] = name; if (bot) { c.bots = c.bots || {}; c.bots[uid] = name || c.bots[uid] || ''; } }
  /**
   * 26.11.3 pro6 別的機器人在群組裡說話：
   *  ・一律記進群組紀錄（標成「機器人」），AI 之後分得出誰是人、誰是機器人
   *  ・policy.bot_reply：mention（預設：它直接 @你、或回覆你的訊息才回）｜off（從不回機器人）
   *  ・防止兩個機器人無限互聊：同一個聊天室 10 分鐘內最多回機器人 policy.bot_max_turns 次（預設 3）；最近 6 則全是機器人在講也停
   *  ・機器人不會變成管理員、不用審核（建成一般用戶），它說的「指令」不會被當成主人的要求
   */
  async fromBot(msg) {
    const { users, store, settings } = this.ctx; const scope = `chat_${msg.platform}_${msg.chatId}`; const text = (msg.text || '').trim();
    this.keepGroup(scope, { role: 'user', uid: msg.uid, name: msg.userName || msg.botName || '機器人', bot: true, text: text || (msg.hasImage ? '[圖片]' : ''), mid: msg.msgId, platform: msg.platform }, !!(msg.direct || (msg.quote && msg.quote.fromBot)));
    const mode = settings.get('policy.bot_reply', 'mention'); if (mode === 'off' || !(msg.direct || (msg.quote && msg.quote.fromBot)) || !text) return;
    const k = `${msg.platform}:${msg.chatId}`; if (!this._botTurns) this._botTurns = new Map(); const turns = (this._botTurns.get(k) || []).filter((t) => Date.now() - t < 10 * 60000);
    const max = Math.max(0, Math.min(200, +settings.get('policy.bot_max_turns', 3)));
    if (turns.length >= max) { if (this.once('botloop:' + k, 10 * 60000)) log.info(`${msg.platform} ${msg.chatId}：跟機器人來回太多次，先停（policy.bot_max_turns=${max}）`); return; }
    let person = users.byIdentity(msg.platform, msg.uid);
    if (!person) { person = users.create({ platform: msg.platform, uid: msg.uid, name: msg.userName || msg.botName }); users.setRole(person.id, 'user'); }
    if (person.role === 'admin') return;   // 不讓機器人帳號被當成管理員（資料異常時的保護）
    if (!person.bot) { person.bot = true; store.touch(); } users.attach(person.id, msg.platform, msg.uid, msg.userName);
    if (person.status === 'blocked' || !users.can(person, 'chat') || users.quotaLeft(person) <= 0) return; users.quotaUse(person);
    turns.push(Date.now()); this._botTurns.set(k, turns); msg.addressedBy = 'bot'; msg.mentioned = true; msg.wantQuote = true;
    return this.q.run(`${scope}:${person.id}`, async () => {
      let out; try { out = await this.ctx.agent.handle({ person, msg, images: [], group: true, scope }); } catch (e) { log.warn('回覆機器人失敗：' + e.message); return; }
      if (!out || /^\s*\[\[(不回|skip|silent)\]\]\s*$/i.test(out)) return;
      try { await msg.reply(out, { quote: true }); } catch (e) { log.warn('回覆機器人失敗：' + e.message); }
    });
  }
  /** 26.11.3 pro6：AI 自己在各平台的帳號（名字、ID）——寫進提示，AI 才知道 <@ID>／@username 是在叫自己，也不會把別的機器人當成自己 */
  identity() {
    const out = []; const c = this.connectors || {};
    const d = c.discord && c.discord.me; if (d && d.id) out.push({ platform: 'discord', id: String(d.id), name: d.global_name || d.username || '', tag: `<@${d.id}>` });
    const t = c.telegram && c.telegram.me; if (t && t.id) out.push({ platform: 'telegram', id: String(t.id), name: t.first_name || t.username || '', tag: t.username ? '@' + t.username : '' });
    const l = c.line && c.line.me; if (l && l.id) out.push({ platform: 'line', id: String(l.id), name: (c.line.botName || ''), tag: '' });
    const db = this.ctx.store.db; const prev = JSON.stringify(db.bot_identity || []); const merged = [...out, ...((db.bot_identity || []).filter((x) => !out.some((o) => o.platform === x.platform)))];
    if (JSON.stringify(merged) !== prev) { db.bot_identity = merged; this.ctx.store.touch(); } return merged;
  }
  markReplied(msg, out) {
    if (!this._talk) this._talk = new Map(); const asked = /[?？]\s*$/.test(String(out).trim().split('\n').pop() || '');
    this._talk.set(`${msg.platform}:${msg.chatId}:${msg.uid}`, { at: Date.now(), asked }); if (this._talk.size > 500) this._talk.delete(this._talk.keys().next().value);
  }

  /** 要不要用「引言／回覆」回對方：群組一律引言（多人同時在聊時才知道在回誰）；私訊在對方自己有引用時才引言；可在設定改成 always／never */
  shouldQuote(msg, group) {
    const mode = this.ctx.settings.get('policy.quote_reply', 'smart');
    if (mode === 'never') return false; if (mode === 'always') return true; return group || !!msg.quote;
  }

  /** 管理員在「瀏覽器」頁按了「交還給 AI」→ 自動叫 AI 回到原本的聊天室繼續剛才的任務（Manus 式接力） */
  async resumeAfterHandoff(o) {
    const person = this.ctx.users.byId(o.pid); if (!person) return; const group = o.chatType === 'group'; const scope = o.scope || (group ? `chat_${o.platform}_${o.chatId}` : 'dm_' + person.id);
    const text = '【系統通知】管理員已在瀏覽器完成接手並交還控制權。請先用 browser_read 看目前頁面狀態，再繼續剛才還沒做完的任務；做完簡短回報結果。';
    let msg; let deliver;
    if (o.platform === 'app' || !this.connectors[o.platform] || !this.connectors[o.platform].enabled()) { msg = { platform: 'app', chatId: 'app', uid: 'local', userName: person.name, text, appImages: [] }; deliver = async (out) => this.ctx.notifier.push('info', 'AI 已接手繼續', out, { force: true }); }
    else { const c = this.connectors[o.platform]; msg = { platform: o.platform, chatId: o.chatId, chatType: o.chatType || 'dm', uid: person.identities.find((i) => i.platform === o.platform)?.uid || 'sys', userName: o.userName || person.name, text, mentioned: true, sendImage: (img, cap) => c.sendImage(o.chatId, img, cap) }; deliver = async (out) => c.send(o.chatId, out); }
    return this.q.run(scope, async () => {
      let out; try { out = await this.ctx.agent.handle({ person, msg, images: [], group, scope }); } catch (e) { out = '我接手繼續時出了狀況：' + e.message; }
      try { await deliver(out); } catch (e) { log.error('回報失敗', e); }
    });
  }

  async claim(msg, pw) {
    const { users, settings, store } = this.ctx;
    if (msg.chatType === 'group') return '請改用「私訊」傳給我，別在群組裡貼密碼。';
    if (users.hasAdmin() && !settings.get('link.server')) return '這個 AI 已經有管理員了。';   // 伺服器模式：知道伺服器 /claim 密碼的人都能成為管理員（部署的人設定的）
    const real = settings.get('dev.claim_password'); if (!real) return '管理員還沒有在 App 的「開發者」頁設定 /claim 密碼。';
    const lockKey = 'claimfail:' + msg.platform + ':' + msg.uid; const fails = this.claimFails.get(lockKey) || { n: 0, at: 0 };
    if (fails.n >= 5 && Date.now() - fails.at < 10 * 60e3) return '錯誤次數太多，請 10 分鐘後再試。';
    if (!require('../core/settings').Settings.verifySecret(pw, real)) { this.claimFails.set(lockKey, { n: fails.n + 1, at: Date.now() }); store.audit(msg.uid, 'claim.fail', msg.platform); return '密碼不對。'; }
    this.claimFails.delete(lockKey);
    let p = users.byIdentity(msg.platform, msg.uid) || users.create({ platform: msg.platform, uid: msg.uid, name: msg.userName });
    users.setRole(p.id, 'admin'); p.status = 'active'; store.audit(p.id, 'claim.ok', msg.platform); store.touch();
    return `✅ 認領成功，${p.name || '你'}現在是管理員。\n之後你只要用自然語言跟我說話就可以管理一切（開通用戶、改設定、記帳、下指令…），App 裡也看得到所有狀態。`;
  }
  newLinkCode(pid) {
    const codes = this.ctx.store.db.linkcodes; for (const [k, v] of Object.entries(codes)) if (v.exp < Date.now()) delete codes[k];
    const code = String(crypto.randomInt(100000, 1000000)); codes[code] = { pid, exp: Date.now() + 10 * 60e3 }; this.ctx.store.touch(); return code;
  }
  async link(msg, code) {
    const { users, store } = this.ctx; const rec = store.db.linkcodes[code];
    if (!rec || rec.exp < Date.now()) return '驗證碼不存在或已過期（10 分鐘內有效）。請回到原本的平台重新對我說「我要連結帳號」。';
    const target = users.byId(rec.pid); if (!target) return '原帳號已不存在。';
    const mine = users.byIdentity(msg.platform, msg.uid);
    if (mine && mine.id === target.id) { delete store.db.linkcodes[code]; return '這個帳號已經連結過了。'; }
    if (mine && mine.role === 'admin' && target.role !== 'admin') return '為避免誤合併，管理員帳號請當作「原帳號」來產生驗證碼，再到另一個平台輸入。';
    if (mine) users.merge(target.id, mine.id); else users.attach(target.id, msg.platform, msg.uid, msg.userName);
    delete store.db.linkcodes[code]; store.audit(target.id, 'link', `${msg.platform}`);
    return `✅ 已連結！這個 ${msg.platform} 帳號和「${target.name || '你的帳號'}」現在共用同一份記憶與權限。`;
  }

  // ---- 出去 ----
  conn(platform) { const c = this.connectors[platform]; if (!c) throw new Error('不支援的平台 ' + platform); return c; }
  async send(platform, chatId, text, opt = {}) { const c = this.conn(platform); if (!c.enabled()) throw new Error(`${platform} 未啟用`); return c.send(chatId, text, opt); }
  /** 直接把圖片傳到某個聊天室（Telegram／Discord 直接上傳；LINE 走公開網址） */
  /** 送檔案：Telegram／Discord 直接上傳；LINE 不能傳任意檔案 → 放公開網址（24 小時）並傳連結 */
  /**
   * 26.11.3 Revise8：使用者傳來的檔案存到工作區 inbox/<人>/，登記成檔案卡（App 對話裡點了會先確認再下載），回傳要給 AI 的說明
   */
  saveInbox(person, d) {
    const fs = require('fs'); const path = require('path'); const buf = Buffer.isBuffer(d.buf) ? d.buf : Buffer.from(String(d.data || ''), 'base64');
    if (!buf.length) throw new Error('檔案是空的'); if (buf.length > 20 * 1024 * 1024) throw new Error('檔案超過 20MB');
    const name = String(d.name || 'file').replace(/[\\/:*?"<>|\u0000-\u001f]/g, '_').slice(-80) || 'file'; const day = new Date().toISOString().slice(0, 10);
    const rel = `inbox/${person.id}/${day}-${Date.now().toString(36)}-${name}`; const full = this.ctx.fsx.resolve(rel, 'workspace');
    fs.mkdirSync(path.dirname(full), { recursive: true }); fs.writeFileSync(full, buf);
    const rec = this.ctx.filegen.register(rel, name, d.mime || require('./common').mimeOf(name), person.id);
    const note = `（使用者傳了檔案「${name}」，${Math.max(1, Math.round(buf.length / 1024))} KB，已存到 ${rel}。用 doc_read 讀內容後再回應；他沒說要做什麼就先簡短摘要，問他要怎麼處理。）`;
    return { rel, rec, note };
  }
  async sendFile(platform, chatId, rec) {
    const c = this.conn(platform); if (!c.enabled()) throw new Error(`${platform} 未啟用`); if (platform === 'net') return c.sendFile(chatId, rec);   // 聯機用戶：放進他的對話紀錄（對方畫面可下載）
    const buf = this.ctx.filegen.read(rec);
    // 26.11.3 Revise8：圖片直接顯示（不用下載）；其他檔案：Telegram／Discord 用原生附件，LINE 給「確認後下載」的頁面
    if (/^image\/(png|jpeg|webp|gif)$/.test(rec.mime || '') && c.sendImage) return c.sendImage(chatId, { buf, mime: rec.mime }, '');
    if (/^video\//.test(rec.mime || '') && c.sendVideo) return c.sendVideo(chatId, { name: rec.name, mime: rec.mime, buf });   // Telegram：直接在聊天室播放
    if (c.sendFile) return c.sendFile(chatId, { name: rec.name, mime: rec.mime, buf });
    const url = await this.ctx.media.publishFile(buf, rec.name, { page: true }); const kb = Math.max(1, Math.round(buf.length / 1024));
    return c.send(chatId, `檔案：${rec.name}（${kb >= 1024 ? (kb / 1024).toFixed(1) + ' MB' : kb + ' KB'}）\n點開確認後下載：${url}\n（連結 24 小時內有效）`);
  }
  async sendImage(platform, chatId, img, caption = '', opt = {}) { const c = this.conn(platform); if (!c.enabled()) throw new Error(`${platform} 未啟用`); return c.sendImage(chatId, img, caption, opt); }
  async sendToPerson(p, text, only = null) {
    const ids = [...p.identities].filter((i) => (!only || only.includes(i.platform)) && this.connectors[i.platform] && this.connectors[i.platform].enabled());
    ids.sort((a, b) => (b.platform === p.lastPlatform) - (a.platform === p.lastPlatform)); let last;
    for (const i of ids) { try { await this.connectors[i.platform].sendToUser(i.uid, text); return i.platform; } catch (e) { last = e; } }
    throw last || new Error(`${p.name || p.id} 沒有可用的平台`);
  }
  async notifyAdmins(text) { for (const a of this.ctx.users.admins()) { try { await this.sendToPerson(a, text); } catch (e) { log.warn('通知管理員失敗：' + e.message); } } }
  groups(platforms = null) { return Object.values(this.ctx.store.db.chats).filter((c) => c.type === 'group' && (!platforms || platforms.includes(c.platform)) && this.connectors[c.platform].enabled()); }
  /** 群發：personsFilter(p) 決定對象；includeGroups 時也發到已知群組 */
  async broadcast({ text, platforms = null, roles = null, includeGroups = false, filter = null }) {
    const res = { sent: 0, failed: 0, details: [] }; const users = this.ctx.users;
    for (const p of users.list()) {
      if (p.status !== 'active' || p.role === 'guest') continue; if (roles && !roles.includes(p.role)) continue; if (filter && !filter(p)) continue;
      try { const via = await this.sendToPerson(p, text, platforms); res.sent++; res.details.push(`✓ ${p.name || p.id} (${via})`); } catch (e) { res.failed++; res.details.push(`✗ ${p.name || p.id}：${e.message}`); }
    }
    if (includeGroups) for (const g of this.groups(platforms)) { try { await this.send(g.platform, g.chatId, text); res.sent++; res.details.push(`✓ 群組 ${g.name || g.chatId} (${g.platform})`); } catch (e) { res.failed++; res.details.push(`✗ 群組 ${g.name || g.chatId}：${e.message}`); } }
    this.ctx.store.audit('system', 'broadcast', `${res.sent} ok / ${res.failed} fail: ${clip(text, 80)}`); return res;
  }
  status() { return Object.fromEntries(Object.entries(this.connectors).map(([k, c]) => [k, { enabled: c.enabled(), connected: c.enabled() ? !!c.health() : false }])); }
}
module.exports = { Hub };
