'use strict';
const crypto = require('crypto');
const { logger } = require('../core/log');
const { fetchJson, fetchSend, fetchBuf, TTLCache } = require('../core/util');
const M = require('./mentions');
const { splitText, plain } = require('./common');
const log = logger('line');
const API = 'https://api.line.me/v2/bot';

class Line {
  constructor(ctx) {
    this.ctx = ctx; this.name = 'line'; this.on = false; this.sentIds = new Set(); this.seen = new Set(); this.pollTimer = null; this.lastPoll = 0; this.lastOk = 0;
    this.names = new TTLCache(3600e3, 800); this.pollFails = 0; this._lt = new Map();
  }
  get cfg() { return this.ctx.settings.get('platforms.line'); }
  /** 穿透選「cloudflare-worker」時，LINE 一律走中繼輪詢 */
  get mode() { const t = this.ctx.tunnel; return t && t.cfg.enabled && t.resolveProvider() === 'cloudflare-worker' ? 'relay' : this.cfg.mode; }
  async start() {
    if (!this.cfg.enabled) { this.on = false; return; }
    if (!this.cfg.token) throw new Error('LINE Channel access token 未設定');
    this.on = true; this.lastOk = Date.now(); this.pollFails = 0;
    if (this.mode === 'relay') { if (!this.cfg.relay_url) throw new Error('LINE relay（Cloudflare Worker）網址未設定'); this._poll(); }
  }
  async stop() { this.on = false; clearTimeout(this.pollTimer); }
  health() { if (!this.cfg.enabled) return true; if (!this.on) return false; return this.mode !== 'relay' || Date.now() - this.lastOk < 120000; }
  enabled() { return !!this.cfg.enabled; }

  // ---- 進來 ----
  verify(raw, sig) {
    if (!this.cfg.secret) return false; const h = crypto.createHmac('sha256', this.cfg.secret).update(raw).digest('base64');
    const a = Buffer.from(h), b = Buffer.from(String(sig || '')); return a.length === b.length && crypto.timingSafeEqual(a, b);
  }
  async handleWebhook(raw, sig) {
    if (!this.verify(raw, sig)) throw new Error('簽章錯誤'); const j = JSON.parse(raw); if (j.destination) this.me = { id: j.destination };   /* 26.11.3 pro6：webhook 的 destination＝這個 LINE 官方帳號自己的 userId */ for (const ev of j.events || []) this.event(ev).catch((e) => log.error(e));
  }
  async _poll() {
    if (!this.on || this.mode !== 'relay') return;
    try {
      const base = this.cfg.relay_url.replace(/\/$/, ''); const r = await fetchJson(`${base}/pull?token=${encodeURIComponent(this.cfg.relay_token)}`, {}, 20000);
      if (!r.ok) throw new Error(`relay ${r.status} ${r.text.slice(0, 100)}`);
      this.lastOk = Date.now(); this.pollFails = 0; const evs = (r.json && r.json.events) || [];
      for (const e of evs) this.event(e.event || e).catch((x) => log.error(x));
      if (evs.length) await fetchJson(`${base}/ack?token=${encodeURIComponent(this.cfg.relay_token)}&upto=${r.json.upto}`, { method: 'POST' }, 10000).catch(() => {});
    } catch (e) { this.pollFails++; if (this.pollFails === 1 || this.pollFails % 20 === 0) log.warn(`relay 輪詢失敗（連續 ${this.pollFails} 次）：` + e.message); }
    // 有新事件時輪詢間隔 1.5 秒（更快收到訊息）；失敗時指數退避，最長 15 秒，不拖垮網路
    this.pollTimer = setTimeout(() => this._poll(), this.pollFails ? Math.min(15000, 3000 * 2 ** Math.min(this.pollFails, 3)) : 2000);
  }
  async event(ev) {
    if (ev.type !== 'message' || !ev.message) return; const m = ev.message; if (this.seen.has(m.id)) return; this.seen.add(m.id); if (this.seen.size > 500) this.seen.delete(this.seen.values().next().value);
    const s = ev.source || {}; const group = s.type === 'group' || s.type === 'room'; const chatId = s.groupId || s.roomId || s.userId; if (!s.userId) return;
    const refs = this.ctx.refs;
    let text = m.type === 'text' ? m.text : m.type === 'image' || m.type === 'audio' ? '' : m.type === 'file' ? `[file] ${m.fileName || ''}` : `[${m.type}]`;
    // 引言：LINE 只給被引用訊息的編號 → 到登記簿查內容
    let quote = null;
    if (m.quotedMessageId) {
      const r = refs.get('line', chatId, m.quotedMessageId);
      quote = r ? { id: r.id, text: r.text || '', name: r.name || '', fromBot: !!r.bot, hasImage: !!r.img } : { id: m.quotedMessageId, text: '', name: '', fromBot: this.sentIds.has(m.quotedMessageId), hasImage: false, unknown: true };
    }
    const aliases = (this.ctx.settings.get('bot.aliases') || []).filter(Boolean);
    const mees = (m.mention && m.mention.mentionees) || []; const direct = mees.some((x) => x.isSelf); const mentionsOthers = mees.some((x) => !x.isSelf);
    let mentioned = !group || direct || !!(quote && quote.fromBot);
    if (!mentioned && aliases.some((a) => text.includes(a))) mentioned = true;
    // 名稱查詢有快取，而且和群組名稱同時查（以前每則訊息要連打 2 次 API）
    const [name, chatName] = await Promise.all([this.profile(s.userId, group ? chatId : null, s.type), group ? this.groupName(chatId, s.type) : '']);
    refs.put('line', chatId, { id: m.id, text: m.type === 'image' ? '[圖片]' : m.type === 'audio' ? '[語音]' : text, name, uid: s.userId, img: m.type === 'image', qt: m.quoteToken });
    const msg = { platform: 'line', chatId, chatType: group ? 'group' : 'dm', chatName, uid: s.userId, userName: name, text, mentioned, direct, mentionsOthers, ts: ev.timestamp || Date.now(), hasImage: m.type === 'image', hasAudio: m.type === 'audio', msgId: m.id, quote,
      fetchAudio: async () => { const r = await fetchBuf(`https://api-data.line.me/v2/bot/message/${m.id}/content`, { headers: { authorization: 'Bearer ' + this.cfg.token } }, 30000, 20 * 1024 * 1024); return { mime: r.mime || 'audio/m4a', data: r.buf.toString('base64') }; },
      ref: { id: m.id, token: m.quoteToken },
      fetchImages: async () => (m.type === 'image' ? [await this.image(m.id)] : []),
      hasDoc: m.type === 'file', docName: m.fileName || '', docSize: m.fileSize || 0,   // 26.11.3 Revise4：使用者傳的檔案（PDF、Word、Excel…）
      fetchDoc: async () => { const r = await fetchBuf(`https://api-data.line.me/v2/bot/message/${m.id}/content`, { headers: { authorization: 'Bearer ' + this.cfg.token } }, 45000, 20 * 1024 * 1024); return { name: m.fileName || 'file', mime: r.mime || '', buf: r.buf }; },
      fetchQuotedImages: async () => (quote && quote.hasImage ? [await this.image(quote.id)] : []),
      typing: () => this.typing(chatId, group), _pendingImages: [], _quoted: false };
    msg.reply = (t, o = {}) => this.reply(ev.replyToken, ev.timestamp, chatId, t, msg, o);
    msg.sendImage = async (img, caption) => { const urls = await this.ctx.media.lineUrls(img.buf, img.mime); msg._pendingImages.push({ type: 'image', originalContentUrl: urls.original, previewImageUrl: urls.preview }); if (caption) msg._pendingImages.push({ type: 'text', text: plain(caption) }); return '已排入傳送'; };
    await this.ctx.hub.incoming(msg);
  }
  async profile(uid, groupId, type) {
    return this.names.wrap(`p:${groupId || ''}:${uid}`, async () => {
      try { const path = groupId ? `${type === 'room' ? 'room' : 'group'}/${groupId}/member/${uid}` : `profile/${uid}`;
        const r = await fetchJson(`${API}/${path}`, { headers: { authorization: 'Bearer ' + this.cfg.token } }, 8000); return (r.json && r.json.displayName) || ''; } catch { return ''; }
    });
  }
  async groupName(id, type) {
    if (type === 'room') return '多人聊天室';
    return this.names.wrap('g:' + id, async () => { try { const r = await fetchJson(`${API}/group/${id}/summary`, { headers: { authorization: 'Bearer ' + this.cfg.token } }, 8000); return (r.json && r.json.groupName) || ''; } catch { return ''; } });
  }
  async image(id) {
    const r = await fetchBuf(`https://api-data.line.me/v2/bot/message/${id}/content`, { headers: { authorization: 'Bearer ' + this.cfg.token } }, 25000, 8 * 1024 * 1024);
    return { mime: r.mime || 'image/jpeg', data: r.buf.toString('base64') };
  }
  /** LINE 的「載入中」動畫（只有 1 對 1 聊天室支援），讓對方知道我在處理 */
  async typing(chatId, group) {
    if (group || Date.now() - (this._lt.get(chatId) || 0) < 20000) return; this._lt.set(chatId, Date.now()); if (this._lt.size > 200) this._lt.delete(this._lt.keys().next().value); try { await fetchJson(`${API}/chat/loading/start`, { method: 'POST', headers: { 'content-type': 'application/json', authorization: 'Bearer ' + this.cfg.token }, body: JSON.stringify({ chatId, loadingSeconds: 30 }) }, 5000); } catch { /* 不重要 */ }
  }
  // ---- 出去 ----
  _remember(chatId, sent, texts) {
    (sent || []).forEach((s, i) => { this.sentIds.add(s.id); if (this.sentIds.size > 300) this.sentIds.delete(this.sentIds.values().next().value); this.ctx.refs.put('line', chatId, { id: s.id, text: texts[i] || '', bot: true, qt: s.quoteToken, name: 'AI' }); });
  }
  async _post(path, body, chatId) {
    // push 帶 X-Line-Retry-Key：重試時 LINE 保證不會重複送出（重複的會回 409，代表上一次其實已經送到）
    const push = path === 'message/push'; const headers = { 'content-type': 'application/json', authorization: 'Bearer ' + this.cfg.token, ...(push ? { 'X-Line-Retry-Key': require('crypto').randomUUID() } : {}) };
    const r = await fetchSend(`${API}/${path}`, { method: 'POST', headers, body: JSON.stringify(body) }, { timeout: path === 'message/reply' ? 10000 : 12000, idempotent: push, onRetry: (w, a) => log.warn(`LINE ${path} 第 ${a} 次失敗（${w}），重試`) });
    if (push && r.status === 409) return {};
    if (!r.ok) throw new Error(`LINE ${path} ${r.status} ${r.text.slice(0, 200)}`);
    this._remember(chatId, r.json && r.json.sentMessages, (body.messages || []).map((m) => m.text || '[圖片]')); return r.json;
  }
  /** 文字訊息；quoteToken 給第一則（引言）。LINE 一次最多 5 則 */
  _msgs(text, quoteToken, images = [], chatId = '') {
    const parts = splitText(plain(text), 4800).filter((t) => t !== '' || !images.length); const room = Math.max(1, 5 - images.length);
    // @[名字] → LINE 真正的提及（textV2）；quoteToken 只放第一則
    const texts = parts.slice(0, room).map((t, i) => M.line(this.ctx, chatId, t, i === 0 && quoteToken ? { quoteToken } : {}));
    return [...images, ...texts].slice(0, 5);
  }
  /** msg.reply：待送出的圖片和文字合成同一次 reply（reply 免費，push 會吃每月訊息額度） */
  async reply(token, ts, chatId, text, msg, o = {}) {
    const images = msg ? msg._pendingImages.splice(0) : []; const wantQuote = o.quote !== undefined ? o.quote : (msg && msg.wantQuote);
    const qt = wantQuote && msg && !msg._quoted && msg.ref && msg.ref.token ? msg.ref.token : undefined;
    const messages = this._msgs(text, qt, images, chatId); if (qt) msg._quoted = true;
    if (!messages.length) return;
    const tryQuoteless = async (fn) => { try { return await fn(messages); } catch (e) { if (qt && /quote/i.test(e.message)) { const m2 = messages.map((x) => { const { quoteToken, ...rest } = x; return rest; }); return fn(m2); } throw e; } };
    if (token && Date.now() - ts < 25000) { try { return await tryQuoteless((ms) => this._post('message/reply', { replyToken: token, messages: ms }, chatId)); } catch (e) { log.warn('reply 失敗，改用 push：' + e.message); } }
    return tryQuoteless((ms) => this._post('message/push', { to: chatId, messages: ms }, chatId));
  }
  /** 主動送出。opt.quote = {id, token?}：引用某則訊息（token 沒帶就查登記簿） */
  async send(chatId, text, opt = {}) {
    let qt; if (opt.quote) { qt = opt.quote.token; if (!qt) { const r = this.ctx.refs.get('line', chatId, opt.quote.id); qt = r && r.qt; } }
    return this._post('message/push', { to: chatId, messages: this._msgs(text, qt, [], chatId) }, chatId);
  }
  async sendImage(chatId, img, caption, opt = {}) {
    const urls = await this.ctx.media.lineUrls(img.buf, img.mime); const messages = [{ type: 'image', originalContentUrl: urls.original, previewImageUrl: urls.preview }];
    if (caption) messages.push(...this._msgs(caption, opt.quote && opt.quote.token, [], chatId)); return this._post('message/push', { to: chatId, messages }, chatId);
  }
  async sendToUser(uid, text) { return this.send(uid, text); }
}
module.exports = { Line };
