'use strict';
const fs = require('fs');
const path = require('path');

function splitText(text, max) {
  text = String(text || ''); if (text.length <= max) return [text];
  const out = []; let rest = text;
  while (rest.length > max) { let i = rest.lastIndexOf('\n', max); if (i < max * 0.5) i = rest.lastIndexOf('。', max); if (i < max * 0.5) i = max; out.push(rest.slice(0, i + 1)); rest = rest.slice(i + 1); }
  if (rest) out.push(rest); return out;
}
/** 去掉 Markdown 的粗體／標題符號（LINE 不會渲染 Markdown） */
/**
 * 26.11.3 Revise7：Markdown 表格 → 聊天平台看得懂的文字（LINE／Telegram 不會畫表格，Discord 也不會）。
 *   | 品名 | 價格 |        【品名｜價格】
 *   |---|---|       →    ・藍牙耳機｜1,290
 *   | 藍牙耳機 | 1,290 |
 */
const TBL_SEP = /^\s*\|?\s*:?-+:?\s*(\|\s*:?-+:?\s*)*\|?\s*$/;
const splitCells = (t) => { const out = []; let cur = '', depth = 0; for (let i = 0; i < t.length; i++) { const ch = t[i]; if (ch === '\\' && t[i + 1] === '|') { cur += '|'; i++; continue; } if (ch === '{') depth++; else if (ch === '}' && depth) depth--; if (ch === '|' && !depth) { out.push(cur); cur = ''; } else cur += ch; } out.push(cur); return out.map((c) => c.trim()); };   // 彩色字 {紅|…} 裡的 | 不算分欄
const cellsOf = (line) => { let t = String(line).trim(); if (t.startsWith('|')) t = t.slice(1); if (t.endsWith('|')) t = t.slice(0, -1); return splitCells(t).map((c) => c.replace(/\*\*(.+?)\*\*/g, '$1')); };
const COLOR_TAG = /\{(?:紅|橙|橘|黃|綠|藍|紫|粉|灰|red|orange|yellow|green|blue|purple|pink|gray)\|([^{}\n]{1,300}?)\}/g;   // 26.11.3 pro2：彩色字標記在聊天平台只留文字
const CH = require('../../ui/chart.js');   // 26.11.3 pro2.1：```chart 區塊 → 文字摘要
function mdTables(t) {
  const L = CH.replaceBlocks(String(t ?? ''), (spec) => CH.summary(spec)).replace(COLOR_TAG, '$1').replace(/\[\[開啟[:：]([^\]]{1,12})\]\]/g, '（到 App 開啟「$1」可以看圖）').split('\n'); const out = [];
  for (let i = 0; i < L.length; i++) {
    if (L[i].includes('|') && i + 1 < L.length && TBL_SEP.test(L[i + 1]) && cellsOf(L[i]).length >= 2) {
      const head = cellsOf(L[i]); out.push(`【${head.join('｜')}】`); let j = i + 2;
      while (j < L.length && L[j].includes('|') && L[j].trim()) { out.push('・' + cellsOf(L[j]).slice(0, head.length).join('｜')); j++; }
      i = j - 1; continue;
    }
    out.push(L[i]);
  }
  return out.join('\n');
}
function plain(t) { return mdTables(t).replace(/\*\*(.+?)\*\*/g, '$1').replace(/^#{1,6}\s+/gm, '').replace(/`{3}[a-z]*\n?/g, '').replace(/`([^`]+)`/g, '$1'); }

/**
 * 訊息登記簿（引言用）。
 * 三個平台的「引用／回覆」都只給對方訊息的編號（LINE 連內容都不給），而且 LINE 要「引用某則訊息」必須拿那則的 quoteToken。
 * 所以每一則收到、送出的訊息都登記：編號 → 內容、發言者、是否為 AI 自己送的、是否含圖、quoteToken。
 * 存在 data/msgrefs.json（最多 3000 則，去抖寫入），重啟後引用舊訊息也看得懂。
 */
class MsgRefs {
  constructor(dir) { this.file = path.join(dir, 'msgrefs.json'); this.m = new Map(); this.max = 3000; this._t = null; this._dirty = false; this.load(); }
  load() { try { if (fs.existsSync(this.file)) for (const [k, v] of JSON.parse(fs.readFileSync(this.file, 'utf8'))) this.m.set(k, v); } catch { this.m = new Map(); } }
  key(platform, chatId, id) { return `${platform}:${chatId}:${id}`; }
  put(platform, chatId, rec) {
    if (!rec || rec.id == null) return; const k = this.key(platform, chatId, rec.id); this.m.delete(k); this.m.set(k, { ...rec, id: String(rec.id), ts: rec.ts || Date.now() });
    while (this.m.size > this.max) this.m.delete(this.m.keys().next().value); this._dirty = true;
    if (!this._t) { this._t = setTimeout(() => { this._t = null; this.flush(); }, 10000); if (this._t.unref) this._t.unref(); }
  }
  get(platform, chatId, id) { return id == null ? null : this.m.get(this.key(platform, chatId, id)) || null; }
  /** 依內容關鍵字找最近的幾則（給 AI 的 find_message 工具） */
  find(platform, chatId, q, limit = 8) {
    const out = []; const w = String(q || '').toLowerCase();
    for (const [k, v] of [...this.m.entries()].reverse()) { if (!k.startsWith(`${platform}:${chatId}:`)) continue; if (!w || String(v.text || '').toLowerCase().includes(w)) out.push(v); if (out.length >= limit) break; }
    return out;
  }
  flush() { if (!this._dirty) return; this._dirty = false; try { fs.writeFileSync(this.file + '.tmp', JSON.stringify([...this.m.entries()])); fs.renameSync(this.file + '.tmp', this.file); } catch { this._dirty = true; } }
}

/** 組 multipart（Node 18+ 內建 FormData/Blob；fetch 會自動帶 boundary） */
function form(fields, file) {
  const f = new FormData();
  for (const [k, v] of Object.entries(fields || {})) if (v !== undefined && v !== null) f.append(k, String(v));
  if (file) f.append(file.field, new Blob([file.buf], { type: file.mime }), file.name);
  return f;
}
const extOf = (mime) => ({ 'image/png': 'png', 'image/jpeg': 'jpg', 'image/webp': 'webp', 'image/gif': 'gif' }[mime] || 'png');

const MIME_EXT = { pdf: 'application/pdf', doc: 'application/msword', docx: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', xls: 'application/vnd.ms-excel', xlsx: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', ppt: 'application/vnd.ms-powerpoint', pptx: 'application/vnd.openxmlformats-officedocument.presentationml.presentation', txt: 'text/plain', csv: 'text/csv', md: 'text/markdown', json: 'application/json', html: 'text/html', zip: 'application/zip', mp3: 'audio/mpeg', m4a: 'audio/mp4', mp4: 'video/mp4', png: 'image/png', jpg: 'image/jpeg', jpeg: 'image/jpeg', webp: 'image/webp', gif: 'image/gif' };
const mimeOf = (name) => MIME_EXT[String(name || '').split('.').pop().toLowerCase()] || 'application/octet-stream';
module.exports = { splitText, plain, mdTables, mimeOf, MsgRefs, form, extOf };
