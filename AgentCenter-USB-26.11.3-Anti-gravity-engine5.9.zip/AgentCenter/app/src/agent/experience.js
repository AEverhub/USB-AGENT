'use strict';
/*
 * 26.11.3 Anti-gravity-engine4.8：經驗記憶（自主演算法）
 *  ・做完一件「用了工具才完成」的事 → 記下「這類需求用哪些工具、什麼順序做成的」，以及中途踩到的坑（哪個工具失敗、後來改用哪個成功）
 *  ・下次遇到相似的需求 → 直接把那幾組工具備好、提示上次成功的做法，不用再摸索一遍（少幾輪模型呼叫＝省額度、也比較快）
 *  ・只記工具名稱與需求開頭，不記參數（參數可能有個資或金鑰）；每個人各記各的；只是提示，不會跳過任何確認或權限
 */
const MAX_PER = 80;          // 每個人最多記幾筆
const SKIP = new Set(['use_tools', 'task_plan', 'how_to', 'app_manual', 'get_time', 'skill_list']);   // 不算「做法」的輔助工具
const norm = (t) => String(t || '').toLowerCase().replace(/https?:\/\/\S+/g, ' ').replace(/[0-9]+/g, '0').replace(/幫我|請你?|麻煩你?|可以|一下|我要|我想|給我|能不能|好嗎|謝謝/g, '').replace(/[的了嗎呢吧啊喔耶\s，。！？、；：,.!?;:「」『』（）()\[\]【】"'`~\-_/\\|<>]+/g, '');
/** 單字＋雙連字集合（中文不用斷詞也能比相似度；去掉「幫我、一下」這類客套字） */
function grams(t) { const s = norm(t).slice(0, 160); const g = new Set(); for (let i = 0; i < s.length; i++) { g.add(s[i]); if (i < s.length - 1) g.add(s.slice(i, i + 2)); } return g; }
/** 字面相似度：共同的部分佔「比較短那句」多少（主角換了——台積電→聯發科——其他一樣，仍然算像） */
function sim(a, b) { if (!a.size || !b.size) return 0; let n = 0; for (const x of a) if (b.has(x)) n++; return n / Math.min(a.size, b.size); }
/** 意圖特徵：這句話對到哪些工具組／小類（和工具路由同一套關鍵字）。同一類的事即使用詞不同也認得出來 */
function sig(text) { const { GROUPS, FOCUS } = require('./router'); const t = String(text || ''); const out = [];
  for (const [k, v] of Object.entries(GROUPS)) if (v.re && v.re.test(t)) out.push(k);
  for (const [k, f] of Object.entries(FOCUS)) f.sub.forEach((x, i) => { if (x.re.test(t)) out.push(`${k}:${i}`); }); return out; }
const jac = (a, b) => { if (!a.length || !b.length) return 0; const B = new Set(b); let n = 0; for (const x of a) if (B.has(x)) n++; return n / (a.length + b.length - n); };
/** 綜合分數：字面 55%＋意圖 45%；字面太不像（< 0.2）就不算，免得只是同一類工具就亂套別件事的做法 */
function score(g, s, e) { const lex = sim(g, new Set(e.g)); if (lex < 0.2) return 0; const es = e.s || []; if (!s.length && !es.length) return 0.9 * lex;   // 兩句都對不到任何關鍵字類別：只能看字面（打九折）
  return 0.55 * lex + 0.45 * jac(s, es); }

class Experience {
  constructor(ctx) { this.ctx = ctx; }
  on() { return this.ctx.settings.get('model.experience', true) !== false; }
  book(pid) { const m = this.ctx.store.db.meta; m.experience = m.experience || {}; return (m.experience[pid] = m.experience[pid] || []); }
  /** 從這一輪的紀錄整理出做法：成功的工具順序（去掉連續重複）、踩到的坑 */
  digest(calls) {
    const seq = []; const pit = []; let lastFail = null;
    for (const c of calls || []) {
      if (!c || SKIP.has(c.name) || c.dup) continue; const bad = /^錯誤：/.test(String(c.result || ''));
      if (bad) { lastFail = c.name; continue; }
      if (lastFail && lastFail !== c.name && !pit.some((p) => p[0] === lastFail)) pit.push([lastFail, c.name]); lastFail = null;
      if (seq[seq.length - 1] !== c.name) seq.push(c.name);
    }
    return { seq: seq.slice(0, 8), pit: pit.slice(0, 2) };
  }
  /** 回覆看起來是「沒做成」就不記 */
  failed(reply) { return /做不到|無法完成|沒辦法|失敗了|發生問題|卡在|工具呼叫次數已達上限|花的時間比預期久|沒有產生內容/.test(String(reply || '').slice(0, 300)); }
  record(pid, text, trace, reply) {
    if (!this.on() || !pid || String(text || '').length < 6) return null;
    const { seq, pit } = this.digest(trace && trace.calls); if (!seq.length || this.failed(reply)) return null;
    const list = this.book(pid); const g = grams(text); const now = Date.now();
    const sg = sig(text); const same = list.find((e) => e.seq.join('>') === seq.join('>') && score(g, sg, e) >= 0.42);
    if (same) { same.n = (same.n || 1) + 1; same.ts = now; same.rounds = Math.min(same.rounds || 99, trace.rounds || 99); if (pit.length) same.pit = pit; }
    else list.push({ t: String(text).replace(/\s+/g, ' ').slice(0, 40), g: [...g].slice(0, 240), s: sg, seq, pit, rounds: trace.rounds || 0, n: 1, ts: now });
    // 滿了：先丟最少用、最舊的
    if (list.length > MAX_PER) { list.sort((a, b) => (b.n || 1) - (a.n || 1) || b.ts - a.ts); list.length = MAX_PER; }
    this.ctx.store.touch(); return same || list[list.length - 1];
  }
  /** 找最像的一筆經驗。has(name)：這個人現在還有沒有這個工具（權限被收回、工具被移除的不提示） */
  match(pid, text, has = () => true) {
    if (!this.on() || !pid) return null; const g = grams(text); if (g.size < 5) return null; const sg = sig(text);
    let best = null, bs = 0; for (const e of this.book(pid)) { const s0 = score(g, sg, e); const s = s0 ? s0 + Math.min(0.05, ((e.n || 1) - 1) * 0.01) : 0; if (s > bs) { bs = s; best = e; } }
    const need = +this.ctx.settings.get('model.experience_min', 0.42) || 0.42; if (!best || bs < need) return null;
    const seq = best.seq.filter((n) => has(n)); if (!seq.length || seq.length < best.seq.length) return null;
    return { seq, pit: (best.pit || []).filter((p) => has(p[1])), rounds: best.rounds, n: best.n || 1, t: best.t, score: Math.round(bs * 100) / 100 };
  }
  /** 放進系統提示的一小段（約 100～200 字） */
  hint(m) {
    if (!m) return '';
    return `\n\n【經驗】你之前做過類似的事（「${m.t}」），這樣做成功${m.n > 1 ? ` ${m.n} 次` : ''}：${m.seq.join(' → ')}。這些工具已經備好，可以直接照這個順序做，不用重新摸索或先查用法；這次的情況不一樣就照實際判斷。${m.pit.length ? `上次踩過的坑：${m.pit.map((p) => `${p[0]} 不行，改用 ${p[1]} 才成功`).join('；')}。` : ''}`;
  }
  forget(pid) { const m = this.ctx.store.db.meta; if (m.experience) { if (pid) delete m.experience[pid]; else m.experience = {}; this.ctx.store.touch(); } return { ok: true }; }
  stats() { const m = this.ctx.store.db.meta.experience || {}; let n = 0, used = 0; for (const l of Object.values(m)) { n += l.length; for (const e of l) used += (e.n || 1) - 1; } return { entries: n, reused: used }; }
}
module.exports = { Experience, grams, sim, sig, score, norm };
