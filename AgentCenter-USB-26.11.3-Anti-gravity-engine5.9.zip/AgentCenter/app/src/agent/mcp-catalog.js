'use strict';
/**
 * 連接器目錄：常見的「遠端 MCP 伺服器」。auth：oauth＝按一下連結登入｜open＝免登入｜key＝要貼 API Key。
 * 網址來源：各服務官方文件（Google：docs.cloud.google.com/mcp/supported-products、developers.google.com/workspace/guides/configure-mcp-servers；
 * GitHub：github/github-mcp-server README）與 github.com/jaw9c/awesome-remote-mcp-servers（2026-11 整理）；各家可能改網址，以官方為準。
 * auth：builtin＝App 內建功能；oauth_client:'google'＝用「瀏覽器」頁 Google 卡片裡的 OAuth Client（Google 不支援自動註冊）。
 * 結尾是 /sse 的是舊版 SSE 傳輸，其餘是 Streamable HTTP；用戶端兩種都支援。
 */
const G = 'https://www.googleapis.com/auth/';
const GW = { auth: 'oauth', oauth_client: 'google', no_resource: true, redirect_host: 'localhost', extra_auth: { access_type: 'offline', prompt: 'consent' }, cat: 'Google Workspace（官方 MCP，開發者預覽）' };
const DRIVE = [G + 'drive.readonly', G + 'drive.file'];
const CATALOG = [
  // ---- Google ----
  { id: 'google_builtin', name: 'Google Workspace（內建）', icon: 'google', cat: 'Google', auth: 'builtin', url: '', desc: 'Gmail、表單、試算表、文件、雲端硬碟、日曆、Tasks，用 App 內建的 Google 通道（設定在「瀏覽器」頁），最穩、不需開發者預覽' },
  { id: 'gmail', name: 'Gmail', icon: 'mail', url: 'https://gmailmcp.googleapis.com/mcp/v1', scopes: [G + 'gmail.readonly', G + 'gmail.compose'], desc: '讀信、草擬信件', ...GW },
  { id: 'gdrive', name: 'Google 雲端硬碟', icon: 'folder', url: 'https://drivemcp.googleapis.com/mcp/v1', scopes: DRIVE, desc: '搜尋與讀取檔案', ...GW },
  { id: 'gdocs', name: 'Google 文件', icon: 'doc', url: 'https://docsmcp.googleapis.com/mcp/v1', scopes: [...DRIVE, G + 'documents.readonly', G + 'documents'], desc: '讀寫文件', ...GW },
  { id: 'gsheets', name: 'Google 試算表', icon: 'table', url: 'https://sheetsmcp.googleapis.com/mcp/v1', scopes: [...DRIVE, G + 'spreadsheets.readonly', G + 'spreadsheets'], desc: '讀寫試算表', ...GW },
  { id: 'gslides', name: 'Google 簡報', icon: 'slides', url: 'https://slidesmcp.googleapis.com/mcp/v1', scopes: [...DRIVE, G + 'presentations.readonly', G + 'presentations'], desc: '讀寫簡報', ...GW },
  { id: 'gcalendar', name: 'Google 日曆', icon: 'calendar', url: 'https://calendarmcp.googleapis.com/mcp/v1', scopes: [G + 'calendar.calendarlist.readonly', G + 'calendar.events.freebusy', G + 'calendar.events.readonly'], desc: '查行程與空檔', ...GW },
  { id: 'gchat', name: 'Google Chat', icon: 'chat', url: 'https://chatmcp.googleapis.com/mcp/v1', scopes: ['chat.spaces.readonly', 'chat.memberships.readonly', 'chat.messages.readonly', 'chat.messages.create', 'chat.users.readstate', 'chat.users.spacesettings'].map((x) => G + x), desc: '讀取與傳送 Chat 訊息（需另外設定 Chat App）', ...GW },
  { id: 'gpeople', name: 'Google 聯絡人', icon: 'users', url: 'https://people.googleapis.com/mcp/v1', scopes: [G + 'directory.readonly', G + 'userinfo.profile', G + 'contacts.readonly'], desc: '聯絡人與通訊錄', ...GW },
  { id: 'gsearch', name: 'Workspace 全域搜尋', icon: 'search', url: 'https://workspacemcp.googleapis.com/mcp/v1', scopes: [...DRIVE, G + 'gmail.readonly'], desc: '一次搜尋信件、檔案等', ...GW },
  { id: 'gmaps', name: 'Google 地圖（Grounding Lite）', icon: 'map', cat: 'Google', url: 'https://mapstools.googleapis.com/mcp', auth: 'key', key_header: 'X-Goog-Api-Key', key_hint: 'Google Cloud 的 API 金鑰（要啟用 Maps Grounding Lite）', desc: '地點、路線、營業資訊（資料來自 Google 地圖）' },
  { id: 'gdevdocs', name: 'Google 開發者文件', icon: 'book', cat: 'Google', url: 'https://developerknowledge.googleapis.com/mcp', auth: 'key', key_header: 'X-Goog-Api-Key', key_hint: 'Google Cloud 的 API 金鑰（要啟用 Developer Knowledge API）', desc: '查 Google 官方開發文件' },
  // ---- 推薦（私人助理常用）----
  { id: 'wolfram', name: 'Wolfram', icon: 'calc', cat: '推薦', url: 'https://agenttools.wolfram.com/mcp', auth: 'open', desc: '精確計算、單位換算、統計與事實資料（資料來源可靠）' },
  { id: 'exa', name: 'Exa 搜尋', icon: 'search', cat: '推薦', url: 'https://mcp.exa.ai/mcp', auth: 'open', desc: '附原文來源的網路搜尋' },
  { id: 'apify', name: 'Apify', icon: 'spider', cat: '推薦', url: 'https://mcp.apify.com', auth: 'key', key_hint: 'Apify 的 API Token（Console → Settings → Integrations）', desc: '抓網頁、比價、社群與地圖資料（數千個現成爬蟲）' },
  { id: 'zapier', name: 'Zapier', icon: 'bolt', cat: '推薦', url: 'https://mcp.zapier.com/api/mcp/mcp', auth: 'key', key_hint: '到 Zapier MCP 頁面產生的金鑰', desc: '串 8000+ 個 App（LINE 通知、Slack、試算表…）' },
  { id: 'fireflies', name: 'Fireflies', icon: 'mic', cat: '推薦', url: 'https://api.fireflies.ai/mcp', auth: 'oauth', desc: '會議錄音逐字稿與摘要' },
  // ---- 筆記與工作 ----
  { id: 'notion', name: 'Notion', icon: 'doc', cat: '筆記與工作', url: 'https://mcp.notion.com/mcp', auth: 'oauth', desc: '讀寫你的 Notion 頁面與資料庫' },
  { id: 'atlassian', name: 'Jira／Confluence', icon: 'board', cat: '筆記與工作', url: 'https://mcp.atlassian.com/v1/sse', auth: 'oauth', desc: 'Atlassian 的議題與文件' },
  { id: 'linear', name: 'Linear', icon: 'board', cat: '筆記與工作', url: 'https://mcp.linear.app/sse', auth: 'oauth', desc: '專案與議題追蹤' },
  { id: 'asana', name: 'Asana', icon: 'check', cat: '筆記與工作', url: 'https://mcp.asana.com/sse', auth: 'oauth', desc: '任務與專案' },
  { id: 'monday', name: 'monday.com', icon: 'calendar', cat: '筆記與工作', url: 'https://mcp.monday.com/sse', auth: 'oauth', desc: '看板與工作流程' },
  { id: 'airtable', name: 'Airtable', icon: 'table', cat: '筆記與工作', url: 'https://mcp.airtable.com/mcp', auth: 'oauth', desc: '表格資料庫' },
  { id: 'box', name: 'Box', icon: 'box', cat: '檔案與設計', url: 'https://mcp.box.com', auth: 'oauth', desc: '雲端檔案' },
  { id: 'canva', name: 'Canva', icon: 'palette', cat: '檔案與設計', url: 'https://mcp.canva.com/mcp', auth: 'oauth', desc: '設計與簡報' },
  // ---- 開發 ----
  { id: 'github', name: 'GitHub', icon: 'code', cat: '開發', url: 'https://api.githubcopilot.com/mcp/', auth: 'key', key_hint: 'GitHub Personal Access Token（github.com → Settings → Developer settings → Fine-grained tokens；勾要給 AI 的 repo 權限）', key_url: 'https://github.com/settings/personal-access-tokens/new', desc: '程式碼、議題、PR（用個人存取權杖連結）' },
  { id: 'vercel', name: 'Vercel', icon: 'code', cat: '開發', url: 'https://mcp.vercel.com/', auth: 'oauth', desc: '網站部署' },
  { id: 'supabase', name: 'Supabase', icon: 'db', cat: '開發', url: 'https://mcp.supabase.com/mcp', auth: 'oauth', desc: '資料庫與後端' },
  { id: 'neon', name: 'Neon', icon: 'db', cat: '開發', url: 'https://mcp.neon.tech/mcp', auth: 'oauth', desc: 'Postgres 資料庫' },
  { id: 'sentry', name: 'Sentry', icon: 'alert', cat: '開發', url: 'https://mcp.sentry.dev/sse', auth: 'oauth', desc: '錯誤監控' },
  // ---- 金流與網站 ----
  { id: 'paypal', name: 'PayPal', icon: 'card', cat: '金流與網站', url: 'https://mcp.paypal.com/sse', auth: 'oauth', desc: '交易、發票（涉及金錢的操作 AI 會先確認）' },
  { id: 'stripe', name: 'Stripe', icon: 'card', cat: '金流與網站', url: 'https://mcp.stripe.com/', auth: 'oauth', desc: '金流與訂閱' },
  { id: 'square', name: 'Square', icon: 'card', cat: '金流與網站', url: 'https://mcp.squareup.com/sse', auth: 'oauth', desc: '店家收銀' },
  { id: 'wix', name: 'Wix', icon: 'globe', cat: '金流與網站', url: 'https://mcp.wix.com/sse', auth: 'oauth', desc: '網站與商店' },
  { id: 'webflow', name: 'Webflow', icon: 'globe', cat: '金流與網站', url: 'https://mcp.webflow.com/sse', auth: 'oauth', desc: '網站內容' },
  { id: 'intercom', name: 'Intercom', icon: 'chat', cat: '金流與網站', url: 'https://mcp.intercom.com/sse', auth: 'oauth', desc: '客服對話' },
  // ---- 查資料（免登入）----
  { id: 'deepwiki', name: 'DeepWiki', icon: 'book', cat: '查資料（免登入）', url: 'https://mcp.deepwiki.com/sse', auth: 'open', desc: '查 GitHub 專案文件' },
  { id: 'cfdocs', name: 'Cloudflare 文件', icon: 'cloud', cat: '查資料（免登入）', url: 'https://docs.mcp.cloudflare.com/sse', auth: 'open', desc: '查 Cloudflare 文件' },
  { id: 'awsdocs', name: 'AWS 知識庫', icon: 'cloud', cat: '查資料（免登入）', url: 'https://knowledge-mcp.global.api.aws', auth: 'open', desc: '查 AWS 官方文件' },
  { id: 'hf', name: 'Hugging Face', icon: 'brain', cat: '查資料（免登入）', url: 'https://hf.co/mcp', auth: 'open', desc: '模型與資料集' },
];
module.exports = { CATALOG };
