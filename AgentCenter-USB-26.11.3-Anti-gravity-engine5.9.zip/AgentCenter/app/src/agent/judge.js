'use strict';
/**
 * 回覆前的自我檢查（26.11.3 Revise4）——讓 AI 不會「說做不到但其實有工具」「說做好了但根本沒做」「做到一半就停」。
 * 模型要給最終回覆時，先過這幾道檢查；沒過就把一段「系統檢查」訊息丟回去讓它再想一次（每種最多一次，整輪最多 2 次，不會無限循環）。
 *
 *   cant       回覆說「沒辦法／無法／不支援」，但這位使用者其實還有沒載入的工具組 → 全部載入，請它再確認一次
 *   fake_done  回覆說「已經幫你 X 好了」，但這一輪沒有任何會改變東西的工具成功執行 → 要它真的去做，或誠實說沒做
 *   plan_open  task_plan 還有沒打勾的步驟 → 繼續做完，或說明為什麼略過
 *   empty      用了工具卻沒有給使用者任何回覆 → 用一兩句話講結果
 *   unverified 26.11.3 Revise5：問的是會變的事實（價格、新聞、現任、營業時間、最新版本…）卻沒查就回答 → 先查證再答
 *   math       26.11.3 Revise5：要算數字（總共、平均、利息、換算…）卻沒用計算工具 → 用 calculate 驗算
 */
const READ_ONLY = /^(how_to|use_tools|task_plan|get_time|calculate|date_calc|search_memory|web_search|fetch_url|weather|places_search|route_info|currency_convert|doc_read|.*_(list|view|read|find|status|summary|search|state|check|info|get)|list_.*|app_manual|ui_snapshot|debug_state|usage_report|group_log|group_collect|browser_(read|screenshot|tabs)|daily_brief|skill_read|google_status|gws_status)$/;

const CANT = /(沒辦法|無法|不能|做不到|辦不到|不支援|沒有(這個|這種|相關的?)?(功能|工具|能力|權限)|超出.{0,6}能力|I can(?:'|no)t|unable to|not able to)/i;
const DONE = /(已(經)?(幫你|替你|為你|幫您|替您)?(把|將)?.{0,12}(記|加|新增|建立|刪|移除|寄|送|傳|發|設定|設好|改|更新|預約|掛號|訂|安排|排好|提醒|完成|填|提交|上傳|下載|儲存|存好|整理)|搞定了|弄好了|處理好了|幫你(記|訂|寄|傳|設)好了)/;
const ACTION_REQ = /(幫我|幫忙|請|麻煩|把|給我|替我|記|新增|加|刪|寄|傳|送|發|設|改|訂|預約|掛號|提醒|填|上傳|下載|存|整理|安排|取消|登入|買|點)/;

const FRESH = /(最新|現在|目前|今天|今年|最近|即時|現任|股價|匯率|油價|金價|房價|票價|價格|多少錢|售價|新聞|比分|戰績|賽程|上市|發布|發表|版本|誰是|還在嗎|還有嗎|營業時間|開到幾點|有沒有開|公告|規定|法規|稅率|利率)/;
const QUESTION = /[?？嗎呢]|多少|幾|誰|哪|什麼|怎麼樣|如何|是否|有沒有/;
const NOT_LOOKUP = /(提醒|記帳|記下|記住|設定|鬧鐘|排程|幫我寫|翻譯|改寫|潤飾|畫|生成圖)/;
const LOOKED = /^(web_search|fetch_url|weather|currency_convert|places_search|route_info|browser_|mcp__|gws_|gmail_|gcal|gdrive|gsheets|gdocs|search_memory|doc_read|stock|news|einvoice|google_api)/;
const CALC_Q = /(算|多少|總共|合計|共計|平均|加總|總和|乘|除以|百分之|%|％|打.?折|折扣|利息|利率|換算|差多少|差幾|幾天|幾歲|分期|每月|稅)/;
const CALC_TOOLS = /^(calculate|date_calc|ledger_|currency_convert|xlsx|sheets_|gsheets|file_generate|run_code|termux_exec|python)/;
/** 這一輪有沒有「會改變東西」的工具成功執行 */
function didAct(calls) { return calls.some((c) => !READ_ONLY.test(c.name) && !/^錯誤：/.test(String(c.result || ''))); }

/**
 * @returns null（通過）或 { kind, note, expandAll? }
 */
function check({ reply, userText, vague = false, hasContext = false, calls, plan, missingGroups = [], used = new Set(), round = 0, maxRounds = 14, canWeb = false, canCalc = false }) {
  const t = String(reply || '').trim(); if (round >= maxRounds - 2) return null;
  const has = (k) => used.has(k); const n = used.size; if (n >= 2) return null;
  // 26.11.3 pro10：使用者講得很省略，而回覆只是丟一個開放式反問、也沒查任何東西 → 先自己推斷
  if (vague && !has('vague_ask') && !calls.length && require('./vague').openQuestion(t)) return { kind: 'vague_ask', note: `使用者講得很省略，但你只是反問他。請先自己補齊：${hasContext ? '看上面的對話他剛才在講什麼、' : ''}用 search_memory 查他的習慣與之前談過的事，選最可能的意思直接做，並在回覆第一句說出你的理解；真的無從判斷才問，而且要給 2～3 個具體選項讓他選。` };
  if (!t && calls.length && !has('empty')) return { kind: 'empty', note: '你用了工具，但還沒有告訴使用者結果。請用一兩句話說明做了什麼、結果如何（失敗就說原因與下一步）。' };
  if (!has('cant') && CANT.test(t) && t.length < 600 && missingGroups.length) {
    return { kind: 'cant', expandAll: true, note: `你剛才說做不到，但你其實還有這些工具可以用：${missingGroups.join('、')}（已經全部載入）。請再確認一次能不能用工具完成；真的不行，再誠實說明原因並提供最接近的替代做法。不要提到這段檢查。` };
  }
  if (!has('fake_done') && DONE.test(t) && ACTION_REQ.test(String(userText || '')) && !didAct(calls)) {
    return { kind: 'fake_done', note: '你的回覆說「已經做好了」，但這一輪沒有任何會改變資料的工具成功執行。請真的用工具把事情做完再回覆；如果做不到或缺資訊，誠實告訴使用者，不要說已完成。不要提到這段檢查。' };
  }
  const open = plan && plan.steps ? plan.steps.filter((s) => s.state === 'todo') : [];
  if (!has('plan_open') && open.length) {
    return { kind: 'plan_open', note: `你的待辦清單還有沒完成的步驟：${open.map((s) => '「' + s.text + '」').join('、')}。請繼續做完（做完用 task_plan done 打勾）；真的做不到就用 task_plan skip 並在回覆裡說明原因。不要提到這段檢查。` };
  }
  const u = String(userText || ''); const asksBack = t.length < 80 && /[?？]\s*$/.test(t);
  if (!has('unverified') && canWeb && !asksBack && t && FRESH.test(u) && QUESTION.test(u) && !NOT_LOOKUP.test(u) && !calls.some((c) => LOOKED.test(c.name) && !/^錯誤：/.test(String(c.result || '')))) {
    return { kind: 'unverified', note: '使用者問的是會隨時間改變的資訊，但你這一輪沒有查證就回答了。請先用 web_search（必要時 fetch_url）查到最新、可靠的資料再回答，並附上來源；查不到就明說查不到，不要憑記憶給可能過時的答案。不要提到這段檢查。' };
  }
  const nums = (u.match(/\d+(\.\d+)?/g) || []).length;
  if (!has('math') && canCalc && !asksBack && nums >= 2 && CALC_Q.test(u) && /\d/.test(t) && !calls.some((c) => CALC_TOOLS.test(c.name))) {
    return { kind: 'math', note: '這題要算數字，但你沒有用計算工具。請用 calculate（日期用 date_calc）把答案驗算一次，確認數字正確後再回覆；算錯了就改正。不要提到這段檢查。' };
  }
  return null;
}

/** 是不是多步驟任務（給更多回合、提示先列計畫） */
function complex(text) {
  const t = String(text || ''); if (t.length < 14) return false;
  const joins = (t.match(/然後|接著|再來|再幫|順便|並且|另外|同時|之後|還要|最後|第[一二三四五]|[1-9][.、)]|\n-/g) || []).length;
  const verbs = (t.match(/查|找|記|寄|傳|整理|做成|做一份|比較|訂|預約|掛號|提醒|設定|下載|填|算|翻譯|摘要|統計/g) || []).length;
  return joins >= 2 || (joins >= 1 && verbs >= 2) || verbs >= 4;
}
/** 同樣的呼叫一直失敗 → 提醒換方法 */
function repeatKey(name, args) { try { return name + ':' + JSON.stringify(args || {}); } catch { return name; } }

/** 26.11.3 Revise5：需要想深一點的問題（分析、推理、規劃、除錯、比較…）→ 開深度思考 */
const DEEP = /(為什麼|為何|分析|推理|證明|推導|評估|優缺點|利弊|規劃|策略|方案|怎麼解|解題|題目|演算法|debug|除錯|錯在哪|bug|報錯|仔細|深入|詳細想|想清楚|權衡|建議.*(哪個|怎麼選)|比較.*(差別|差異|哪個))/i;
function deep(text) { return DEEP.test(String(text || '')) || complex(text); }

module.exports = { check, complex, deep, didAct, repeatKey, CANT, DONE, READ_ONLY, FRESH };
