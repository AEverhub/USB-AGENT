'use strict';
/** 極簡 MCP 用戶端：streamable-http（POST JSON-RPC，回應可為 JSON 或 SSE）與 stdio（換行分隔 JSON-RPC）。 */
const { spawn } = require('child_process');
const { logger } = require('../core/log');
const { fetchJson } = require('../core/util');
const log = logger('mcp');

/** 取得連線要帶的標頭：OAuth（一鍵連結）時由 McpAuth 給 token，快到期會自動 refresh */
async function authHeaders(def, ctx, force = false) {
  const h = { ...(def.headers || {}) };
  if (def.oauth && ctx && ctx.mcpauth) { const t = await ctx.mcpauth.token(def.name, { force }); if (def.key_header) h[def.key_header] = t; else h.authorization = 'Bearer ' + t; }   // key_header：例如 Google 的 X-Goog-Api-Key
  else if (def.token) h.authorization = 'Bearer ' + def.token;
  return h;
}
class HttpClient {
  constructor(def, ctx) { this.def = def; this.ctx = ctx; this.sid = null; this.id = 0; }
  async rpc(method, params, notify = false, retried = false) {
    const body = { jsonrpc: '2.0', method, params }; if (!notify) body.id = ++this.id;
    const headers = { 'content-type': 'application/json', accept: 'application/json, text/event-stream', ...(await authHeaders(this.def, this.ctx, retried)) };
    if (this.sid) headers['mcp-session-id'] = this.sid;
    const ctl = new AbortController(); const t = setTimeout(() => ctl.abort(), 60000);
    try {
      const r = await fetch(this.def.url, { method: 'POST', headers, body: JSON.stringify(body), signal: ctl.signal });
      if (r.status === 401 && this.def.oauth && !retried) { try { await r.text(); } catch { /* ignore */ } return this.rpc(method, params, notify, true); }   // token 過期：強制 refresh 再試一次
      const sid = r.headers.get('mcp-session-id'); if (sid) this.sid = sid;
      if (notify) { try { await r.text(); } catch { /* ignore */ } return null; } const text = await r.text(); if (!r.ok) throw new Error(r.status === 401 ? '需要登入（到「連接器」按連結）' : `HTTP ${r.status} ${text.slice(0, 200)}`);
      let j; if ((r.headers.get('content-type') || '').includes('text/event-stream')) {
        for (const l of text.split('\n')) if (l.startsWith('data:')) { try { const x = JSON.parse(l.slice(5)); if (x.id === body.id) j = x; } catch { /* skip */ } }
      } else j = JSON.parse(text);
      if (!j) throw new Error('沒有收到回應'); if (j.error) throw new Error(j.error.message || JSON.stringify(j.error)); return j.result;
    } finally { clearTimeout(t); }
  }
  async init() { await this.rpc('initialize', { protocolVersion: '2025-03-26', capabilities: {}, clientInfo: { name: 'agent-center', version: '26.9.5' } }); await this.rpc('notifications/initialized', {}, true); }
  close() {}
}
/** 舊版「HTTP＋SSE」傳輸（網址結尾 /sse）：GET 開一條事件串流，伺服器先給 endpoint，之後回應都從串流回來 */
class SseClient {
  constructor(def, ctx) { this.def = def; this.ctx = ctx; this.id = 0; this.pending = new Map(); this.post = null; this.ctl = null; }
  async _open(force = false) {
    this.ctl = new AbortController();
    const r = await fetch(this.def.url, { headers: { accept: 'text/event-stream', ...(await authHeaders(this.def, this.ctx, force)) }, signal: this.ctl.signal });
    if (r.status === 401 && this.def.oauth && !force) { try { this.ctl.abort(); } catch { /* ignore */ } return this._open(true); }
    if (!r.ok || !r.body) throw new Error(r.status === 401 ? '需要登入（到「連接器」按連結）' : `SSE 連線失敗 HTTP ${r.status}`);
    let gotEndpoint; const ready = new Promise((res, rej) => { gotEndpoint = res; setTimeout(() => rej(new Error('SSE 伺服器沒有給 endpoint')), 20000); });
    (async () => {
      const reader = r.body.getReader(); const dec = new TextDecoder(); let buf = '';
      try {
        for (;;) {
          const { done, value } = await reader.read(); if (done) break; buf += dec.decode(value, { stream: true });
          let i; while ((i = buf.search(/\r?\n\r?\n/)) >= 0) {
            const raw = buf.slice(0, i); buf = buf.slice(i).replace(/^\r?\n\r?\n/, ''); let ev = 'message'; const data = [];
            for (const l of raw.split(/\r?\n/)) { if (l.startsWith('event:')) ev = l.slice(6).trim(); else if (l.startsWith('data:')) data.push(l.slice(5).replace(/^ /, '')); }
            const d = data.join('\n'); if (ev === 'endpoint') { this.post = new URL(d, this.def.url).toString(); gotEndpoint(); continue; }
            try { const j = JSON.parse(d); const w = this.pending.get(j.id); if (w) { this.pending.delete(j.id); j.error ? w.rej(new Error(j.error.message || 'MCP 錯誤')) : w.res(j.result); } } catch { /* 不是 JSON-RPC */ }
          }
        }
      } catch { /* 串流中斷 */ }
      for (const w of this.pending.values()) w.rej(new Error('SSE 串流已中斷')); this.pending.clear(); this.post = null;
    })();
    await ready;
  }
  async rpc(method, params, notify = false) {
    if (!this.post) await this._open();
    const body = { jsonrpc: '2.0', method, params }; let wait = null;
    if (!notify) { body.id = ++this.id; wait = new Promise((res, rej) => { this.pending.set(body.id, { res, rej }); setTimeout(() => { if (this.pending.delete(body.id)) rej(new Error('MCP 逾時')); }, 60000); }); }
    const r = await fetch(this.post, { method: 'POST', headers: { 'content-type': 'application/json', ...(await authHeaders(this.def, this.ctx)) }, body: JSON.stringify(body), signal: AbortSignal.timeout(30000) });
    const t = await r.text(); if (!r.ok && r.status !== 202) { if (body.id) this.pending.delete(body.id); throw new Error(`HTTP ${r.status} ${t.slice(0, 200)}`); }
    if (wait && t.trim().startsWith('{')) { try { const j = JSON.parse(t); if (j.id === body.id) { this.pending.delete(body.id); if (j.error) throw new Error(j.error.message); return j.result; } } catch (e) { if (!/JSON/.test(e.message)) throw e; } }
    return wait;
  }
  async init() { await this._open(); await this.rpc('initialize', { protocolVersion: '2024-11-05', capabilities: {}, clientInfo: { name: 'agent-center', version: '26.9.5' } }); await this.rpc('notifications/initialized', {}, true); }
  close() { try { this.ctl && this.ctl.abort(); } catch { /* ignore */ } }
}
class StdioClient {
  constructor(def) { this.def = def; this.id = 0; this.pending = new Map(); this.buf = ''; }
  start() {
    this.p = spawn(this.def.command, this.def.args || [], { env: { ...process.env, ...(this.def.env || {}) }, stdio: ['pipe', 'pipe', 'pipe'] });
    this.p.stdout.on('data', (d) => { this.buf += d; let i; while ((i = this.buf.indexOf('\n')) >= 0) { const l = this.buf.slice(0, i).trim(); this.buf = this.buf.slice(i + 1);
      if (!l) continue; try { const j = JSON.parse(l); const w = this.pending.get(j.id); if (w) { this.pending.delete(j.id); j.error ? w.rej(new Error(j.error.message)) : w.res(j.result); } } catch { /* ignore */ } } });
    this.p.on('error', (e) => { for (const w of this.pending.values()) w.rej(e); this.pending.clear(); });
    this.p.on('close', () => { for (const w of this.pending.values()) w.rej(new Error('MCP 行程結束')); this.pending.clear(); });
  }
  rpc(method, params, notify = false) {
    if (notify) { this.p.stdin.write(JSON.stringify({ jsonrpc: '2.0', method, params }) + '\n'); return Promise.resolve(null); }
    const id = ++this.id; return new Promise((res, rej) => { this.pending.set(id, { res, rej }); this.p.stdin.write(JSON.stringify({ jsonrpc: '2.0', id, method, params }) + '\n');
      setTimeout(() => { if (this.pending.delete(id)) rej(new Error('MCP 逾時')); }, 60000); });
  }
  async init() { this.start(); await this.rpc('initialize', { protocolVersion: '2025-03-26', capabilities: {}, clientInfo: { name: 'line-agent', version: '1.4.0' } }); await this.rpc('notifications/initialized', {}, true); }
  close() { try { this.p.kill(); } catch { /* ignore */ } }
}

class Mcp {
  constructor(ctx) { this.ctx = ctx; this.clients = new Map(); this.tools = []; this.errors = {}; this.counts = {}; }
  async reload() {
    for (const c of this.clients.values()) c.close(); this.clients.clear(); this.tools = []; this.errors = {}; this.counts = {};
    for (const def of this.ctx.settings.get('mcp.servers', [])) {
      if (def.enabled === false || !def.name) continue;
      try {
        const c = def.command ? new StdioClient(def) : (def.transport === 'sse' || (!def.transport && /\/sse\/?$/.test(def.url || ''))) ? new SseClient(def, this.ctx) : new HttpClient(def, this.ctx); await c.init();
        const r = await c.rpc('tools/list', {}); this.clients.set(def.name, c); this.counts[def.name] = (r.tools || []).length;
        for (const t of r.tools || []) this.tools.push({ server: def.name, name: `mcp__${def.name}__${t.name}`.slice(0, 64), raw: t.name, description: `[${def.name}] ${t.description || ''}`.slice(0, 900),
          parameters: t.inputSchema && t.inputSchema.type ? t.inputSchema : { type: 'object', properties: {} } });
      } catch (e) { this.errors[def.name] = e.message; log.warn(`MCP ${def.name} 連線失敗：${e.message}`); }
    }
    return { tools: this.tools.length, errors: this.errors };
  }
  async call(fullName, args) {
    const t = this.tools.find((x) => x.name === fullName); if (!t) throw new Error('沒有這個 MCP 工具');
    const r = await this.clients.get(t.server).rpc('tools/call', { name: t.raw, arguments: args });
    const text = (r.content || []).map((c) => c.text || (c.type ? `[${c.type}]` : '')).join('\n'); return r.isError ? '工具回報錯誤：' + text : text;
  }
  stop() { for (const c of this.clients.values()) c.close(); this.clients.clear(); }
}
module.exports = { Mcp, HttpClient, SseClient };
