'use strict';
const { logger } = require('../core/log');
const { clip, withTimeout } = require('../core/util');
const llm = require('../llm');
const judge = require('./judge');
const prompt = require('./prompt');
const log = logger('agent');

/** 沒有副作用、可以同時跑的工具 */
const PARALLEL_OK = new Set(['web_search', 'fetch_url', 'search_memory', 'get_time', 'calculate', 'date_calc', 'file_read', 'file_list', 'ledger_view', 'ledger_summary', 'ledger_find', 'sheet_view', 'sheet_list', 'skill_read', 'skill_list', 'list_users', 'list_groups', 'group_log', 'rules_list', 'app_state', 'browser_read']);
const safeJson = (o) => { try { return JSON.stringify(o); } catch { return '{…}'; } };
async function seq(list, fn) { const out = []; for (const c of list) out.push(await fn(c)); return out; }
/** 工具回傳的截圖很吃 token：只保留最近 keep 張，舊的拿掉 */
function pruneImages(messages, keep) {
  let n = 0;
  for (let i = messages.length - 1; i >= 0; i--) { const m = messages[i]; if (m.role !== 'tool') continue;
    for (const r of m.results) if (r.images && r.images.length) { n += r.images.length; if (n > keep) r.images = []; } }
}

/** 同一輪對話裡，舊回合的工具結果每一輪都會重送：只留最近一回合完整，更早的截短（省 token；模型需要時可再查一次） */
function compactOld(messages, keepLast = 1, max = 1200, far = 0) {
  let seen = 0;
  for (let i = messages.length - 1; i >= 0; i--) { const m = messages[i]; if (m.role !== 'tool') continue; seen++; if (seen <= keepLast) continue;
    // engine4.8：三回合以前的結果再縮一次（far）——模型多半已經用過了，每一輪重送整段只是浪費
    const lim = far && seen > keepLast + 2 ? far : max; const flag = lim === far && far ? '_far' : '_short';
    for (const r of m.results) if (typeof r.content === 'string' && r.content.length > lim + 60 && !r[flag]) { r.content = r.content.slice(0, lim) + `\n…（較早的結果已截短，需要完整內容請再呼叫一次）`; r._short = true; r[flag] = true; } }
}
/** engine4.8 省額度：工具說明瘦身。這次任務的重點工具（focus）留完整；其他的只留前幾句，細節模型可以用 how_to 查。eco＝on 時連參數說明也縮短 */
function slimDef(t, { eco = 'auto', focus = false } = {}) {
  const full = { name: t.name, description: t.description, parameters: t.parameters }; if (eco === 'off' || t.meta || t.name === 'how_to' || t.name === 'use_tools') return full;
  const lim = focus ? (eco === 'on' ? 420 : 0) : (eco === 'on' ? 170 : 300); let d = String(t.description || '');
  if (lim && d.length > lim + 40) { const head = d.slice(0, lim); const cut = Math.max(head.lastIndexOf('。'), head.lastIndexOf('；'), head.lastIndexOf('\n')); d = (cut > lim * 0.5 ? head.slice(0, cut + 1) : head + '…') + '（細節用 how_to 查）'; }
  let prm = t.parameters;
  if (eco === 'on' && prm && prm.properties) { const props = {}; for (const [k, v] of Object.entries(prm.properties)) props[k] = v && typeof v.description === 'string' && v.description.length > 70 ? { ...v, description: v.description.slice(0, 64) + '…' } : v; prm = { ...prm, properties: props }; }
  return { name: t.name, description: d, parameters: prm };
}
const DEDUPE_OK = new Set(['web_search', 'fetch_url', 'search_memory', 'calculate', 'date_calc', 'file_read', 'ledger_view', 'ledger_summary', 'ledger_find', 'sheet_view', 'skill_read', 'group_log', 'doc_read', 'weather', 'places_search', 'route_info', 'currency_convert', 'stock_history', 'logic_convert', 'logic_adder', 'how_to', 'app_manual']);
const HIST_CLIP = { user: 1500, assistant: 1000 };
/** 歷史訊息瘦身：```chart 區塊 → 「〔圖表：標題〕」、自動附的來源清單拿掉 */
const slim = (t) => String(t || '').replace(/```chart[ \t]*\n([\s\S]*?)\n?```/g, (m, b) => { try { return `〔圖表：${JSON.parse(b).title || ''}〕`; } catch { return '〔圖表〕'; } }).replace(/\n\n來源：\n(・https?:\/\/\S+\n?)+$/, '');

class Agent {
  constructor(ctx) { this.ctx = ctx; }

  history(scope, n, group, focusUid = '') {
    // 群組：大家你一言我一語，12 則太少 → 預設帶 30 則（model.group_history），發言者後面標時間，才分得出誰在什麼時候說了什麼
    if (group) n = Math.max(n, +this.ctx.settings.get('model.group_history', 30) || 30);
    const tz = this.ctx.settings.get('tz') || 'Asia/Taipei'; const stamp = (r) => { if (!r.ts) return ''; try { return ' ' + new Date(r.ts).toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit', hour12: false, timeZone: tz }); } catch { return ''; } };
    // 有滾動摘要時：摘要之後的訊息全帶（避免「還沒摘要、又不在最近 n 則」的空窗），至少帶最近 n 則
    const sum = (this.ctx.store.db.summaries || {})[scope]; const every = this.ctx.settings.get('model.summary_every', 10);
    const all = this.ctx.store.tail(scope, n + every); const after = sum && sum.until ? all.filter((r) => r.ts > sum.until) : all.slice(-n);
    const rows = after.length >= n ? after : all.slice(-n); const out = [];
    for (const r of rows) {
      // 26.11.3 pro5（省 token）：歷史裡的圖表資料換成一行標題；越舊的訊息留越短（最近 4 則完整，其餘減半）
      const old = rows.length - rows.indexOf(r) > 4; const k = old ? 0.5 : 1;
      if (r.role === 'assistant') out.push({ role: 'assistant', text: clip(slim(r.text), Math.round(HIST_CLIP.assistant * k)) });
      // 26.11.3 pro6：群組裡「別人」的發言只是背景 → 標清楚、留短一點；機器人標成機器人；現在在問你的人的發言照常
      else if (group) { const mine = !focusUid || r.uid === focusUid; out.push({ role: 'user', text: clip(`【${r.name || r.uid || '成員'}${r.bot ? '（機器人）' : ''}${stamp(r)}${mine ? '' : '｜背景'}】${r.text}`, mine ? Math.round(HIST_CLIP.user * k) : 220) }); }
      else out.push({ role: 'user', text: clip(r.text, Math.round(HIST_CLIP.user * k)) });
    }
    // 合併相鄰同角色，並確保第一則是 user
    const merged = []; for (const m of out) { const l = merged[merged.length - 1]; if (l && l.role === m.role) l.text += '\n' + m.text; else merged.push({ ...m }); }
    while (merged.length && merged[0].role !== 'user') merged.shift(); return merged;
  }

  /** 一次完整的「思考→用工具→回答」。回傳要送給使用者的文字。 */
  async handle({ person, msg, images = [], group = false, scope }) {
    const { ctx } = this; const S = ctx.settings; const started = Date.now();
    if (!S.get('bot.enabled', true) && person.role !== 'admin') return '系統維護中，請稍後再試。';
    if (!llm.hasKey(S)) return person.role === 'admin' ? '還沒設定模型金鑰。請到 App「模型」分頁選擇供應商（Gemini／Claude／ChatGPT／NVIDIA／Groq）並填入 API Key。' : '系統還在設定中，請稍後再試。';
    const q = msg.quote || null;
    let text = (msg.text || '').trim() || (images.length ? '(使用者傳了圖片)' : '');
    // 使用者用「引言／回覆」指著某則訊息說話：把被引用的內容一併交給模型，並說清楚誰說的
    if (q && (q.text || q.hasImage)) text = `【使用者正在回覆（引用）這則訊息｜來自 ${q.fromBot ? '你（AI）自己' : (q.name || '某人')}：「${clip(q.text || '[圖片]', 600)}」${q.hasImage ? '（引用的訊息含圖片，已附在下方）' : ''}】\n${text}`;
    // 語意回想最多等 1.2 秒：雲端嵌入偶爾很慢，不能為了「可能有用」的記憶讓整段回覆卡住
    // 記憶檢索和下面的準備工作同時進行（26.11.3 Revise4 加速），真的要組提示時才等它
    const recallP = text.length >= 6 ? withTimeout(group ? (ctx.groupmem ? ctx.groupmem.recall(text, `g:${msg.platform}:${msg.chatId}`, 3) : Promise.resolve([])) : ctx.vector.search(text, { pid: person.id, k: 4 }), S.get('model.recall_timeout_ms', 1200), '記憶檢索').catch(() => []) : Promise.resolve([]);   // 群組：只查「這個群組」超過 32 小時、存進向量記憶的重要訊息
    const eco = ['on', 'off'].includes(S.get('model.eco', 'auto')) ? S.get('model.eco') : 'auto';   // engine4.8 省額度模式：auto（預設）／on（更省）／off
    const hist = this.history(scope, eco === 'on' ? Math.min(8, S.get('model.history', 12)) : S.get('model.history', 12), group, msg.uid);
    // 工具路由：只送這句話用得到的工具（＋use_tools 可隨時補），系統提示也只放對應的使用說明
    const allTools = ctx.tools.forPerson(person, group);
    const prevText = hist.filter((m) => m.role === 'user').slice(-2).map((m) => m.text).join('\n'); const routeText = [text, prevText].join('\n');
    const groups = ctx.router.pick(text, { images: images.length > 0, scope, context: prevText }); const used = new Set();
    const summary = (ctx.store.db.summaries || {})[scope];
    // 26.11.3 Revise4：多步驟任務 → 給更多回合，並要求先列待辦清單、逐項完成
    const isComplex = judge.complex(text); const recall = await recallP; const wantDeep = judge.deep(text);   // 26.11.3 Revise5：需要推理／多步驟的問題想深一點
    // 簡單的一句話（打招呼、閒聊、短問題、不需要工具）：叫模型「不要思考、直接回」，快很多
    const isLight = !isComplex && !images.length && text.length <= 30 && [...groups].every((g) => g === 'core') && !/(查|搜|找|算|記|寄|訂|提醒|設定|幫我|怎麼|為什麼|比較|翻譯|寫|做|整理|多少|幾點|天氣|新聞)/.test(text);
    // 26.11.3 pro10：模糊需求（「那個弄一下」「跟上次一樣」「隨便」）→ 不走輕量模式（要能查記憶、要帶「模糊需求」的做法），回覆若只是反問會被自我檢查擋下
    const vagueHint = S.get('model.vague_help', true) !== false && (require('./vague').detect(msg.text || '').vague || require('./playbooks').ids(msg.text || '').includes('vague'));
    let lite = isLight && !group && !vagueHint && S.get('model.lite_turns', true) !== false;   // 26.11.3 pro5：輕量對話＝最少的工具＋精簡的提示
    // engine4.8 經驗記憶：做過類似的事 → 把上次成功用到的工具組直接備好（省掉「先要工具」那一輪），並在提示裡帶上做法
    const exp = !isLight && ctx.experience ? ctx.experience.match(person.id, text, (n) => allTools.some((t) => t.name === n)) : null;
    if (exp) for (const n of exp.seq) { const g = ctx.router.groupOf(n); if (g) groups.add(g); }
    const fullGroups = new Set(); const keepTools = new Set(exp ? exp.seq : []);
    // engine5：有可用的技能 → skill_read 一定在（技能清單在提示裡，AI 要讀全文不用先 use_tools）；skill_read 歸在 core
    try { if (!isLight && ctx.skills && allTools.some((t) => t.name === 'skill_read') && ctx.skills.eligible({ video: groups.has('video') }).length) keepTools.add('skill_read'); } catch { /* ignore */ }   // 整組載入的組；一定要送的工具（經驗裡用過的、模型直接叫過的）
    let tools = ctx.router.select(allTools, groups, routeText, { lite, full: fullGroups, keep: keepTools });
    const PLAN = '\n\n【這是多步驟任務】先用 task_plan（action=set）列出步驟，再一步一步用工具做，每完成一步用 task_plan done 打勾；全部做完（或確定做不到的用 skip 說明）才回覆使用者，回覆時整理每一項的結果。';
    const mkSystem = () => prompt.build(ctx, { person, group, msg, recall, text, groups, light: lite }) + (summary && summary.text ? `\n\n【更早之前的對話摘要（最近幾則在下面的對話裡）】\n${summary.text}` : '') + (isComplex ? PLAN : '') + (exp ? ctx.experience.hint(exp) : '');
    let system = mkSystem();
    const label = group ? `【${msg.userName || person.name || '成員'}${msg.isBot ? '（機器人）' : ''}｜${msg.isBot ? '這個機器人在 @你' : msg.addressedBy === 'followup' ? '接著跟你說' : '@你'}，這一則才是你現在要回答的】` : '';
    const messages = [...hist, { role: 'user', text: label + text, images }];
    const imgNames = (images || []).slice(0, 4).map((im) => ctx.chatmedia && ctx.chatmedia.save(im)).filter(Boolean);   // 圖片永久保存，往回捲還看得到
    const urec = { role: 'user', uid: msg.uid, pid: person.id, name: msg.userName || person.name, text: (msg._storeText !== undefined ? msg._storeText : msg.text) || (msg._userFiles ? '' : '[圖片]'), ...(imgNames.length ? { imgs: imgNames } : {}), ...(msg._userFiles ? { files: msg._userFiles } : {}), platform: msg.platform, mid: msg.msgId, quote: q ? { id: q.id, text: clip(q.text || '', 200), name: q.name } : undefined };
    if (group && ctx.groupmem) { const r = ctx.groupmem.prepare({ ...urec, ...(msg.isBot ? { bot: true } : {}) }, { addressed: true }); if (r) ctx.store.addMessage(scope, r); } else ctx.store.addMessage(scope, urec);   // 26.11.3 pro6：群組訊息精簡後再存

    const tctx = { person, msg, group, scope, ctx, images, files: [] }; msg._files = tctx.files;   // AI 產生的檔案：回覆後由平台送出
    const focusGroups = new Set([...groups].filter((g) => g !== 'core'));   // 這句話直接對到的工具組＝重點，說明留完整
    const defsOf = (l) => l.map((t) => slimDef(t, { eco, focus: focusGroups.has(ctx.router.groupOf(t.name)) || (exp && exp.seq.includes(t.name)) }));
    let toolDefs = defsOf(tools);
    const sources = { read: [], seen: [] };   // 這一輪實際讀過／看過的網址（附來源用）
    const URL_RE = /https?:\/\/[^\s<>"'）)\]】]+/g;
    const expand = (gs, ask = false) => { let changed = false; if (lite && gs.length) { lite = false; changed = true; } for (const g of gs) { if (!groups.has(g)) { groups.add(g); changed = true; } if (ask && !fullGroups.has(g)) { fullGroups.add(g); changed = true; } } if (changed) { tools = ctx.router.select(allTools, groups, routeText, { full: fullGroups, keep: keepTools }); toolDefs = defsOf(tools); system = mkSystem(); } return changed; };
    const trace = { who: person.name || person.id, role: person.role, input: clip(text, 300), calls: [], rounds: 0, tokens: { in: 0, out: 0 }, ...(exp ? { exp: exp.seq.join('>') } : {}) };
    const maxRounds = isComplex ? Math.max(S.get('model.max_rounds', 14), S.get('model.max_rounds_complex', 24)) : S.get('model.max_rounds', 14);
    const deadline = started + (isComplex ? Math.max(S.get('model.turn_timeout_s', 170), 300) : S.get('model.turn_timeout_s', 170)) * 1000; const toolMs = S.get('model.tool_timeout_s', 100) * 1000;
    const seenCalls = new Set(); const gates = new Set(); const fails = new Map();   // 自我檢查用過哪些；同一個呼叫失敗幾次
    const missingGroups = () => { const all = new Set(allTools.map((t) => ctx.router.groupOf(t.name)).filter((g) => g && g !== 'core')); return [...all].filter((g) => !groups.has(g)); };
    let finalText = ''; let stuck = 0; const nudged = new Set(); const perTool = new Map(); const outMax = eco === 'on' ? 5000 : 8000;
    try {
      for (let round = 0; round < maxRounds; round++) {
        if (Date.now() > deadline) { finalText = '（這件事花的時間比預期久，我先停在這裡；已完成的部分都有保留，需要的話請再說一聲讓我接著做。）'; break; }
        trace.rounds++;
        msg._round = round + 1; msg._doing = round ? msg._doing : 'think'; const tl = Date.now();
        const deepNow = !isLight && (wantDeep || fails.size > 0 || gates.size > 0); if (deepNow) trace.deep = true;   // 上一步失敗、自我檢查沒過 → 下一輪想深一點再動手
        const r = await withTimeout(llm.generate(ctx, { system, messages, tools: toolDefs, fast: isLight && round === 0, deep: deepNow }), Math.max(20000, deadline - Date.now()), '模型回應');
        trace.llm_ms = (trace.llm_ms || 0) + (Date.now() - tl); if (isLight) trace.light = true;
        trace.tokens.in += r.usage.in; trace.tokens.out += r.usage.out; person.usage.tokens += r.usage.in + r.usage.out;
        if (!r.toolCalls.length) {
          // 回覆前自我檢查：說做不到但其實有工具／說做好了但沒做／待辦沒做完／沒給結果 → 讓它再想一次（最多 2 次）
          const miss = missingGroups(); const G = require('./router').GROUPS || {};
          const g = S.get('model.self_check', true) !== false && Date.now() < deadline - 15000 ? judge.check({ reply: r.text, userText: text, vague: !!vagueHint, hasContext: hist.length > 0, calls: trace.calls, plan: tctx.plan, missingGroups: miss.map((k) => `${k}（${(G[k] || {}).desc || k}）`), used: gates, round, maxRounds, canWeb: allTools.some((t) => t.name === 'web_search'), canCalc: allTools.some((t) => t.name === 'calculate') }) : null;
          if (g) {
            gates.add(g.kind); trace.self_check = [...gates]; if (g.expandAll) { for (const k of miss) used.add(k); expand([...miss, 'core', 'files'].filter((k) => k === 'core' || groups.has(k) || miss.includes(k)), true); }
            messages.push({ role: 'assistant', text: r.text || '（還在處理）' }); messages.push({ role: 'user', text: '【系統自我檢查（這不是使用者說的話，不要回應這段本身）】' + g.note }); continue;
          }
          finalText = r.text; break;
        }
        messages.push({ role: 'assistant', text: r.text, toolCalls: r.toolCalls, raw: r.raw });
        const runOne = async (c) => {
          const t0 = Date.now(); let out; let imgs = []; msg._doing = c.name;   // 給「還在處理中」提示用
          if (c.name === 'use_tools') {
            const want = (Array.isArray(c.args && c.args.groups) ? c.args.groups : [c.args && c.args.groups]).map(String).filter((g) => allTools.some((t) => ctx.router.groupOf(t.name) === g));
            for (const g of want) used.add(g); expand(want, true); out = want.length ? `已載入：${want.join('、')}。現在可以直接使用這些工具。` : '沒有這個工具組（或你沒有權限）。可用的組別請看 use_tools 的說明。';
            trace.calls.push({ name: c.name, args: clip(safeJson(c.args), 300), result: out, ms: 0 }); return { id: c.id, name: c.name, content: out, images: [] };
          }
          { const g = ctx.router.groupOf(c.name); used.add(g); if (!groups.has(g)) expand([g]); else if (!toolDefs.some((d) => d.name === c.name) && !keepTools.has(c.name)) { keepTools.add(c.name); tools = ctx.router.select(allTools, groups, routeText, { lite, full: fullGroups, keep: keepTools }); toolDefs = defsOf(tools); } }   // 模型直接叫了沒送出去的工具：照樣執行，並在下一輪補上定義
          // 26.11.3 pro5（省 token、避免原地打轉）：同一輪裡完全一樣的唯讀查詢不重跑、也不把同一大段結果再送一次
          const dk = DEDUPE_OK.has(c.name) ? judge.repeatKey(c.name, c.args) : ''; if (dk && seenCalls.has(dk)) { out = '（這一輪已經用完全相同的參數查過了，結果就在上面，不再重複。請直接用那個結果；要不同的資料就換參數或換工具。）'; trace.calls.push({ name: c.name, args: clip(safeJson(c.args), 300), result: out, ms: 0, dup: true }); return { id: c.id, name: c.name, content: out, images: [] }; }
          try { out = await withTimeout(ctx.tools.run(c.name, c.args, tctx, allTools), toolMs, `工具 ${c.name} `); if (dk) seenCalls.add(dk); }
          catch (e) {
            // 錯誤附上「下一步建議」，讓模型自己修正，而不是放棄或亂猜
            const em = e.message; const hint = /權限|沒有使用/.test(em) ? (tctx.person.role === 'admin' ? '（提示：可用 permission_change 開放，或改用其他工具）' : '（提示：這件事需要管理員開放，請告訴使用者可以用 request_permission 申請）')
              : /找不到|不存在|no such/i.test(em) ? '（提示：先用 list／find 類工具查正確的名稱或編號再試）' : /缺少必要參數|參數不符/.test(em) ? '（提示：用 how_to 查這個工具的參數格式）'
              : /逾時|timeout|連不上|ECONN|503|502/i.test(em) ? '（提示：稍等再試一次，或換一個來源／工具）' : '（提示：換個方法或參數再試；不確定用法先 how_to）';
            const k = judge.repeatKey(c.name, c.args); const nf = (fails.get(k) || 0) + 1; fails.set(k, nf);
            out = '錯誤：' + em + hint + (nf >= 2 ? `（同樣的呼叫已經失敗 ${nf} 次：不要再用一樣的參數重試，換工具、換參數，或直接告訴使用者卡在哪、需要他提供什麼）` : ''); ctx.debug.recordError('tool:' + c.name, e);
          }
          if (out && typeof out === 'object' && !Array.isArray(out) && (out.images || out.text !== undefined)) { imgs = (out.images || []).slice(0, 2); out = out.text ?? ''; }
          try { out = clip(typeof out === 'string' ? out : JSON.stringify(out), outMax); } catch { out = '（結果無法序列化）'; }
          if (!/^錯誤：/.test(out)) {
            if (['fetch_url', 'browser_open'].includes(c.name) && c.args && c.args.url) sources.read.push(String(c.args.url));
            else if (c.name === 'web_search' || c.name.startsWith('mcp__')) for (const u of (out.match(URL_RE) || []).slice(0, 5)) sources.seen.push(u);
          }
          trace.calls.push({ name: c.name, args: clip(safeJson(c.args), 300), result: clip(out, 300), ms: Date.now() - t0 }); return { id: c.id, name: c.name, content: out, images: imgs };
        };
        // 互不影響的唯讀工具同時跑（例如一次搜尋三個關鍵字），其餘維持依序，避免寫入互相打架
        const results = r.toolCalls.length > 1 && r.toolCalls.every((c) => PARALLEL_OK.has(c.name)) ? await Promise.all(r.toolCalls.map(runOne)) : await seq(r.toolCalls, runOne);
        // engine4.8 自主：偵測「原地打轉」並自己換策略（提示接在工具結果後面，不多花一輪）
        const note = (k, t) => { if (nudged.has(k) || !results.length) return; nudged.add(k); trace.nudges = [...nudged]; results[results.length - 1].content += '\n\n【系統提醒（不是使用者說的）】' + t; };
        const noGain = results.every((x) => /^錯誤：|^（這一輪已經用完全相同的參數查過了/.test(String(x.content || ''))); stuck = noGain ? stuck + 1 : 0;
        if (stuck >= 3) note('stuck', '已經連續 3 輪沒有任何進展（都是錯誤或重複查詢）。停下來換策略：①換一種完全不同的工具或做法；②把問題拆小，先做能做的部分；③真的做不到就直接告訴使用者卡在哪、你試過什麼、需要他提供什麼。不要再重試一樣的東西。');
        for (const x of results) { if (/^錯誤：/.test(String(x.content || ''))) continue; perTool.set(x.name, (perTool.get(x.name) || 0) + 1); }
        if ((perTool.get('web_search') || 0) + (perTool.get('fetch_url') || 0) >= 7) note('search', '已經查了很多次網路資料。用手上已有的資料整理出答案；真的還缺關鍵資料才再查一次，缺的部分照實說明。');
        if (round === maxRounds - 2 && maxRounds >= 4) note('wrap', '下一輪是最後一輪：不要再呼叫工具，直接回覆使用者——整理已經完成的結果，沒完成的部分說明做到哪、還差什麼，讓他說「繼續」就能接著做。');
        else if (Date.now() > deadline - 30000) note('wrap', '時間快用完了：下一步不要再呼叫工具，直接回覆使用者已完成的結果與還沒做完的部分。');
        messages.push({ role: 'tool', results });
        pruneImages(messages, 2); compactOld(messages, 1, eco === 'on' ? 700 : 1200, eco === 'off' ? 0 : 400);
        if (round === maxRounds - 1) finalText = r.text || '（工具呼叫次數已達上限，我先停在這裡；如需繼續請再說一聲。）';
      }
    } finally { try { if (ctx.browser && trace.calls.some((c) => /^(browser_|phone_|google_form|google_calendar)/.test(c.name))) ctx.browser.taskDone(); } catch { /* ignore */ }   // 26.11.3 pro2.1：任務做完 5 分鐘後刪圖片紀錄
      trace.ms = Date.now() - started; trace.tools_sent = toolDefs.length; trace.system_chars = system.length; ctx.debug.trace(trace); ctx.router.remember(scope, used); ctx.usage.turn && ctx.usage.turn(trace); }
    try { if (ctx.experience && !group) ctx.experience.record(person.id, text, trace, finalText); } catch (e) { log.warn('經驗記憶：' + e.message); }
    finalText = require('./persona').humanize((finalText || '').trim(), S) || '（我這次沒有產生內容，請換個方式再問一次。）';
    // 26.11.3 pro7：不要一直重複同一句話（同一則裡重複的句子、連續重複的詞、最近幾則一直講的口頭禪）；使用者要求重複時不處理
    if (S.get('model.no_repeat', true) !== false) { try { const recent = ctx.store.tail(scope, 12).filter((m) => m.role === 'assistant').slice(-4).map((m) => m.text || ''); finalText = require('./norepeat').dedupe(finalText, { recent, user: msg.text || '' }); } catch (e) { log.warn('norepeat：' + e.message); } }
    // 資料來源：這一輪用了網路資料、回覆卻沒附任何網址 → 自動附上實際讀過的來源（最多 3 個），讓使用者能查證
    if (S.get('model.cite_sources', true) !== false && finalText.length > 12 && !/https?:\/\//.test(finalText)) {
      const list = [...new Set([...sources.read, ...sources.seen])].filter((u) => !/duckduckgo\.com|google\.com\/search|bing\.com\/search/.test(u)).slice(0, 3);
      if (list.length) finalText += `\n\n來源：\n${list.map((u) => '・' + u).join('\n')}`;
    }
    if (!['line', 'discord', 'telegram'].includes(msg.platform)) finalText = require('../platforms/mentions').plain(finalText).replace(/^\s*\[\[(?:quote|reply|回覆|引言)\s*[:：][^\]]*\]\]\s*/i, '');   // App 裡沒有 @／引言：轉成純文字
    const outImgs = (msg.appImages || []).slice(0, 4).map((im) => ctx.chatmedia && ctx.chatmedia.save(im)).filter(Boolean);
    ctx.store.addMessage(scope, { role: 'assistant', text: finalText, ...(outImgs.length ? { imgs: outImgs } : {}), ...(tctx.files.length ? { files: tctx.files.map((f) => ({ id: f.id, name: f.name, size: f.size, mime: f.mime })) } : {}) });
    // 記憶、摘要、個性整理都晚 2.5 秒再做：先讓回覆順利送出，不跟它搶網路與 CPU
    setTimeout(() => this.afterTurn(person, text, scope, group).catch((e) => log.warn('afterTurn：' + e.message)), +S.get('model.after_turn_delay_ms', 2500) || 0);
    return finalText;
  }

  async afterTurn(person, text, scope, group) {
    const { ctx } = this;
    if (!group && text.length >= 30) await ctx.vector.add({ pid: person.id, source: 'chat', text });
    // 每 12 則訊息整理一次這個人的個性／偏好（背景進行）
    if (person.usage.messages % 12 === 0 && person.usage.messages > 0 && llm.hasKey(ctx.settings)) await this.learnProfile(person, scope);
    await this.summarize(scope).catch((e) => log.warn('對話摘要：' + e.message));
  }
  /**
   * 滾動摘要：只把最近 model.history 則原文送給模型，更早的濃縮成一段摘要（每累積 summary_every 則才更新一次）。
   * 長對話的上下文不會丟，但每一輪送出的 token 大幅減少。
   */
  async summarize(scope) {
    const { ctx } = this; const S = ctx.settings; if (S.get('model.summary', true) === false || !llm.hasKey(S)) return;
    const keep = S.get('model.history', 12); const every = S.get('model.summary_every', 10);
    const db = ctx.store.db; db.summaries = db.summaries || {}; const cur = db.summaries[scope] || { until: 0, text: '' };
    const rows = ctx.store.tail(scope, keep + 60); const older = rows.slice(0, Math.max(0, rows.length - keep)).filter((r) => r.ts > cur.until);
    if (older.length < every) return;
    const lines = older.map((r) => `${r.role === 'assistant' ? 'AI' : (r.name || '使用者')}：${clip(String(r.text || ''), 400)}`).join('\n');
    const out = await llm.simple(ctx, `把對話濃縮成給 AI 自己看的「前情提要」（繁體中文，最多 12 行條列）：保留使用者的要求、做過的決定、正在進行的事、約定的時間、提到的人事物與數字、還沒完成的事；刪掉寒暄。\n\n既有摘要：\n${cur.text || '（無）'}\n\n新的對話：\n${lines}`, '你是精準的會議記錄員，只輸出摘要條列。');
    if (out && out.trim()) { db.summaries[scope] = { until: older[older.length - 1].ts, text: clip(out.trim(), 1500), updated: Date.now() }; ctx.store.touch(); }
  }
  async learnProfile(person, scope) {
    const rows = this.ctx.store.tail(scope, 24).filter((r) => r.role === 'user').map((r) => r.text).join('\n'); if (rows.length < 40) return;
    const old = person.profile;
    const out = await llm.simple(this.ctx, `以下是使用者「${person.name || person.id}」最近說的話，與你先前對他的觀察。請更新對他的個性與溝通偏好（語氣、用詞、專業程度、偏好的回覆長度與格式、作息、在意的事）。\n只輸出 JSON：{"style":"一句話總結","notes":["最多 8 條簡短觀察"]}\n\n先前：${JSON.stringify({ style: old.style, notes: old.notes.slice(-8) })}\n\n最近發言：\n${clip(rows, 3000)}`);
    const m = /\{[\s\S]*\}/.exec(out); if (!m) return;
    try { const j = JSON.parse(m[0]); if (j.style) old.style = String(j.style).slice(0, 200); if (Array.isArray(j.notes)) old.notes = j.notes.map(String).slice(0, 8); old.updated = Date.now(); this.ctx.store.touch(); } catch { /* ignore */ }
  }
}
module.exports = { Agent, slimDef, compactOld };
