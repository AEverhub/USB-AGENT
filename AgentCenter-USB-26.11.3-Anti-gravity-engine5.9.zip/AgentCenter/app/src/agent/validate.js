'use strict';
/**
 * 本地參數驗證：用工具的「原始」JSON Schema（不是送給模型的簡化版）在執行前檢查參數。
 * 送給 Gemini 時被拿掉的限制（exclusiveMinimum、multipleOf、uniqueItems、const、oneOf、additionalProperties:false…）都在這裡把關，
 * 所以 Schema 轉換不會讓安全性變低。驗證失敗 → 工具不執行，把原因回給模型讓它修正後重試。
 *
 * strict=false（App 內建工具）：只檢查「限制」類規則（範圍、長度、樣式、列舉、必填），型別寬鬆（內建工具本身會處理字串數字等）
 * strict=true（MCP 外部工具）：連型別、多餘欄位都檢查
 */
const isObj = (x) => x && typeof x === 'object' && !Array.isArray(x);
const typeOf = (v) => (v === null ? 'null' : Array.isArray(v) ? 'array' : Number.isInteger(v) ? 'integer' : typeof v);
const fits = (v, t) => { const a = typeOf(v); return t === a || (t === 'number' && a === 'integer'); };
const show = (v) => { const s = JSON.stringify(v); return s && s.length > 60 ? s.slice(0, 57) + '…' : s; };

function validate(value, schema, { strict = false, root = schema, path = '', depth = 0 } = {}) {
  const errs = []; if (!isObj(schema) || depth > 20) return errs;
  const at = path || '(參數)'; const sub = (v, s, p) => validate(v, s, { strict, root, path: p, depth: depth + 1 });
  if (typeof schema.$ref === 'string') { const m = /^#\/(\$defs|definitions)\/(.+)$/.exec(schema.$ref); const t = m && root && root[m[1]] && root[m[1]][m[2]]; if (t) errs.push(...sub(value, { ...t, ...schema, $ref: undefined }, path)); return errs; }
  if (Array.isArray(schema.allOf)) for (const s of schema.allOf) errs.push(...sub(value, s, path));
  const alts = schema.anyOf || schema.oneOf;
  if (Array.isArray(alts) && alts.length) {
    const ok = alts.filter((s) => !sub(value, s, path).length).length;
    if (!ok) errs.push(`${at}：不符合任何一種允許的格式`); else if (schema.oneOf && ok > 1 && strict) errs.push(`${at}：同時符合多種格式（oneOf 只能符合一種）`);
  }
  if (value === undefined) return errs;
  if (schema.type !== undefined && (strict || value === null)) {
    const ts = Array.isArray(schema.type) ? schema.type : [schema.type]; if (schema.nullable) ts.push('null');
    if (!ts.some((t) => fits(value, t))) { errs.push(`${at}：型別應為 ${ts.join('／')}，收到 ${typeOf(value)}`); return errs; }
  }
  if (schema.const !== undefined && JSON.stringify(value) !== JSON.stringify(schema.const)) errs.push(`${at}：必須是 ${show(schema.const)}`);
  if (Array.isArray(schema.enum) && !schema.enum.some((e) => JSON.stringify(e) === JSON.stringify(value) || (!strict && String(e) === String(value)))) errs.push(`${at}：只能是 ${schema.enum.slice(0, 15).map(show).join('、')}`);
  const num = typeof value === 'number' ? value : (!strict && typeof value === 'string' && value.trim() !== '' && !isNaN(value) && ['number', 'integer'].includes(schema.type) ? Number(value) : null);
  if (num !== null) {
    if (typeof schema.minimum === 'number' && (schema.exclusiveMinimum === true ? num <= schema.minimum : num < schema.minimum)) errs.push(`${at}：必須${schema.exclusiveMinimum === true ? '大於' : '≥'} ${schema.minimum}`);
    if (typeof schema.maximum === 'number' && (schema.exclusiveMaximum === true ? num >= schema.maximum : num > schema.maximum)) errs.push(`${at}：必須${schema.exclusiveMaximum === true ? '小於' : '≤'} ${schema.maximum}`);
    if (typeof schema.exclusiveMinimum === 'number' && num <= schema.exclusiveMinimum) errs.push(`${at}：必須大於 ${schema.exclusiveMinimum}`);
    if (typeof schema.exclusiveMaximum === 'number' && num >= schema.exclusiveMaximum) errs.push(`${at}：必須小於 ${schema.exclusiveMaximum}`);
    if (typeof schema.multipleOf === 'number' && schema.multipleOf > 0 && Math.abs(num / schema.multipleOf - Math.round(num / schema.multipleOf)) > 1e-9) errs.push(`${at}：必須是 ${schema.multipleOf} 的倍數`);
    if (schema.type === 'integer' && !Number.isInteger(num)) errs.push(`${at}：必須是整數`);
  }
  if (typeof value === 'string') {
    const len = [...value].length;
    if (Number.isInteger(+schema.minLength) && len < +schema.minLength) errs.push(`${at}：至少 ${schema.minLength} 個字`);
    if (Number.isInteger(+schema.maxLength) && schema.maxLength !== undefined && len > +schema.maxLength) errs.push(`${at}：最多 ${schema.maxLength} 個字`);
    if (typeof schema.pattern === 'string') { try { if (!new RegExp(schema.pattern, 'u').test(value)) errs.push(`${at}：格式不符（${schema.pattern}）`); } catch { /* 規格本身的正規式無效就略過 */ } }
  }
  if (Array.isArray(value)) {
    if (Number.isInteger(+schema.minItems) && schema.minItems !== undefined && value.length < +schema.minItems) errs.push(`${at}：至少 ${schema.minItems} 項`);
    if (Number.isInteger(+schema.maxItems) && schema.maxItems !== undefined && value.length > +schema.maxItems) errs.push(`${at}：最多 ${schema.maxItems} 項`);
    if (schema.uniqueItems && new Set(value.map((v) => JSON.stringify(v))).size !== value.length) errs.push(`${at}：項目不可重複`);
    const it = schema.items; if (isObj(it)) value.forEach((v, i) => errs.push(...sub(v, it, `${path}[${i}]`))); else if (Array.isArray(it)) it.forEach((s, i) => { if (i < value.length) errs.push(...sub(value[i], s, `${path}[${i}]`)); });
  }
  if (isObj(value)) {
    const props = isObj(schema.properties) ? schema.properties : {};
    // required 裡有、properties 卻沒定義的欄位（常見的規格錯誤）不強制，否則工具永遠無法呼叫；伺服器自己仍會檢查
    for (const r of (Array.isArray(schema.required) ? schema.required : []).filter((k) => !isObj(schema.properties) || k in schema.properties)) if (value[r] === undefined || value[r] === null || (!strict && value[r] === '')) errs.push(`${path ? path + '.' : ''}${r}：必填`);
    for (const [k, v] of Object.entries(value)) {
      if (props[k]) errs.push(...sub(v, props[k], path ? `${path}.${k}` : k));
      else if (schema.additionalProperties === false && strict) errs.push(`${path ? path + '.' : ''}${k}：不允許的欄位`);
      else if (isObj(schema.additionalProperties)) errs.push(...sub(v, schema.additionalProperties, path ? `${path}.${k}` : k));
    }
    if (Number.isInteger(schema.minProperties) && Object.keys(value).length < schema.minProperties) errs.push(`${at}：至少 ${schema.minProperties} 個欄位`);
    if (Number.isInteger(schema.maxProperties) && Object.keys(value).length > schema.maxProperties) errs.push(`${at}：最多 ${schema.maxProperties} 個欄位`);
  }
  return errs;
}
module.exports = { validate };
