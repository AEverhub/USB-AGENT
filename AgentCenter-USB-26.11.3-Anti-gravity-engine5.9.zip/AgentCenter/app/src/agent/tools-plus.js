'use strict';
/** 26.9.1 新增工具：天氣、監控哨兵、每日簡報、手機能力（Termux:API）。由 tools.js 的 build() 載入。 */
const weather = require('../services/weather');
const { NUM } = require('../services/phone');

module.exports = function plus(ctx, def, h) {
  const { S, N, B, need, aud, chatOf } = h; const { zoned } = require('../core/util'); const ARR = (d) => ({ type: 'array', description: d, items: { type: 'string' } });
  const J = (o) => JSON.stringify(o, null, 1);
  const mine = (tc) => (w) => tc.person.role === 'admin' || w.pid === tc.person.id;
  const fmtW = (w) => `#${w.id} ${w.enabled ? '🟢' : '⏸'} ${w.name}｜每 ${w.every_min} 分｜${w.cond}${w.value !== '' ? ' ' + w.value : ''}｜${w.extract}${w.path ? ' ' + w.path : ''}${w.pattern ? ' /' + w.pattern + '/' : ''}\n   上次：${w.last_at ? new Date(w.last_at).toISOString().slice(5, 16).replace('T', ' ') : '尚未檢查'} ${w.last_ok === false ? '❌ ' + w.last_error : w.last_value ? '→ ' + w.last_value.slice(0, 80) : ''}${w.fired ? `｜已通知 ${w.fired} 次` : ''}\n   ${w.url}`;

  // ---------------- 天氣 ----------------
  def('weather', '查天氣：現況＋未來幾天預報（Open-Meteo，免金鑰）。place 可用中文或英文地名，或「緯度,經度」。使用者沒說地點時用 App 設定的簡報城市。', { place: S('地名，例如 台北、高雄、Tokyo'), days: N('預報天數 1–7，預設 3') }, [], { perm: 'weather' },
    async (a) => weather.text(await weather.forecast(a.place || ctx.settings.get('brief.city') || 'Taipei', a.days || 3)));

  // ---------------- 26.11.3 Revise4：生活查詢、讀文件、多步驟計畫 ----------------
  const places = require('../services/places');
  def('places_search', '找地點：「附近的藥局／加油站／便利商店／餐廳／ATM／停車場／醫院…」或用名字、地址找地方（OpenStreetMap，免金鑰）。query＝類別或店名；near＝在哪附近（地址、地標、或「緯度,經度」；使用者沒說就問，或用 phone_info 取定位）。結果附 Google 地圖連結與資料來源。',
    { query: S('要找什麼，例：藥局、加油站、鼎泰豐、台北車站'), near: S('在哪附近，例：板橋車站、台中市西屯區…'), radius_m: N('搜尋半徑公尺（附近類別用，預設 1500）') }, ['query'], { perm: 'chat' }, (a) => places.search(a));
  def('route_info', '算路線距離與時間：開車（實際道路計算，不含塞車）、走路、騎車（依道路距離估算）、大眾運輸（給 Google 地圖即時連結）。',
    { from: S('起點（地址、地標）'), to: S('終點'), mode: S('driving｜walking｜cycling｜transit，預設 driving') }, ['from', 'to'], { perm: 'chat' }, (a) => places.route(a));
  def('currency_convert', '匯率換算（國際參考匯率，每天更新）。幣別可用 USD／JPY／TWD 或「美金」「日幣」「台幣」。',
    { amount: N('金額，預設 1'), from: S('原幣別'), to: S('目標幣別，預設 TWD') }, ['from'], { perm: 'chat' }, (a) => places.fx(a));
  def('doc_read', '讀文件內容：Word（docx）、Excel（xlsx）、PowerPoint（pptx）、PDF（文字型）、txt／csv／md／json／html。使用者傳來的檔案在 inbox/ 底下（訊息裡會告訴你路徑）；也可以給網址。讀完再幫他摘要、回答問題、整理成表格或做成新檔案。',
    { path: S('工作區裡的路徑，例：inbox/xxx/報告.pdf'), url: S('或文件網址'), max_chars: N('最多回傳幾個字（預設 12000）') }, [], { perm: 'chat' }, async (a, tc) => {
      const fs = require('fs'); let buf; let name;
      if (a.url) { need(/^https?:\/\//.test(a.url), '網址要 http／https 開頭'); const r = await require('../core/util').fetchBuf(a.url, {}, 30000, 25 * 1024 * 1024); buf = r.buf; name = decodeURIComponent(new URL(a.url).pathname.split('/').pop() || ''); }
      else {
        need(a.path, '要給 path 或 url'); const rel = String(a.path).replace(/^\/+/, '');
        if (tc.person.role !== 'admin') need(rel.startsWith(`inbox/${tc.person.id}/`), '你只能讀自己傳來的檔案（inbox/ 底下）');
        const full = ctx.fsx.resolve(rel, 'workspace'); need(fs.existsSync(full), '找不到這個檔案'); buf = fs.readFileSync(full); name = rel;
      }
      const r = require('../services/docread').extract(buf, name); const max = Math.max(1000, Math.min(+a.max_chars || 12000, 40000));
      return `【${name}】${r.kind}，共 ${r.chars} 字${r.chars > max ? `（只顯示前 ${max} 字，要看後面請再讀一次並說明要找什麼）` : ''}\n\n${r.text.slice(0, max)}`;
    });
  def('task_plan', '多步驟任務的待辦清單（自己用的）：使用者一次交代好幾件事、或一件事要好幾個步驟時，先 set 列出步驟，每做完一步就 done 打勾。還有沒做完的步驟時，系統會提醒你繼續做完，避免做到一半就回覆。',
    { action: S('set＝列出步驟（覆蓋）｜done＝完成第幾步｜skip＝這步做不到要略過（附原因）'), steps: ARR('set 時的步驟清單（短句）'), index: N('done／skip 的步驟編號（從 1 開始）'), note: S('skip 的原因或 done 的結果') }, ['action'], { perm: 'chat' }, (a, tc) => {
      const pl = tc.plan = tc.plan || { steps: [] };
      if (a.action === 'set') { need(Array.isArray(a.steps) && a.steps.length, 'set 要給 steps'); pl.steps = a.steps.slice(0, 12).map((t) => ({ text: String(t).slice(0, 120), state: 'todo', note: '' })); }
      else { const st = pl.steps[(+a.index || 0) - 1]; need(st, '沒有這個步驟編號'); st.state = a.action === 'skip' ? 'skip' : 'done'; st.note = String(a.note || '').slice(0, 200); }
      const left = pl.steps.filter((x) => x.state === 'todo').length;
      return pl.steps.map((x, i) => `${x.state === 'done' ? '[完成]' : x.state === 'skip' ? '[略過]' : '[待辦]'} ${i + 1}. ${x.text}${x.note ? '（' + x.note + '）' : ''}`).join('\n') + (left ? `\n還有 ${left} 步。` : '\n全部完成，可以回覆使用者了（告訴他結果；略過的要說明原因）。');
    });

  // ---------------- 監控哨兵 ----------------
  def('watch_add', '新增監控哨兵：定時檢查網頁或 API，條件成立就主動通知使用者（例：商品降價、網頁出現「開賣」、公告有更新、API 數值超過門檻）。\n'
    + 'extract：text＝整頁文字｜regex＝用 pattern 取第一個括號（例 "售價\\\\s*\\\\$?([\\\\d,]+)"）｜json＝用 path 取值（例 data.items[0].price）。\n'
    + 'cond：changed＝內容有變就通知｜contains／missing＝出現／消失關鍵字 value｜lt／gt＝數字低於／高於 value。狀態型條件只在「剛成立」時通知一次。先用 watch_check 試一次確認取得到值。',
  { name: S('名稱'), url: S('網址（http/https）'), extract: S('text|regex|json'), pattern: S('regex 取值用'), path: S('json 取值路徑'), cond: S('changed|contains|missing|lt|gt'), value: S('關鍵字或數字門檻'), every_min: N('幾分鐘檢查一次（5–1440，預設 30）'), once: B('觸發一次後自動停用') },
  ['url', 'cond'], { perm: 'watch' }, async (a, tc) => {
    const w = ctx.watch.add(a, tc.person.id); aud(tc, 'watch.add', `#${w.id} ${w.url}`);
    const r = await ctx.watch.check(w, { notify: false });
    return `已建立哨兵 #${w.id}「${w.name}」，每 ${w.every_min} 分鐘檢查。\n第一次檢查：${r.error ? '❌ ' + r.error + '（請修正網址或取值方式，否則會一直失敗）' : '取得 → ' + (r.value || '（空字串：pattern/path 可能沒對到）')}${r.fired ? '\n⚠️ 條件現在就已成立（之後要再次由不成立變成立才會通知）' : ''}`;
  });
  def('watch_list', '列出監控哨兵與最近一次檢查結果。', {}, [], { perm: 'watch' }, (a, tc) => ctx.watch.all().filter(mine(tc)).map(fmtW).join('\n') || '（沒有哨兵）');
  def('watch_check', '立刻檢查某個哨兵一次，回傳目前取得的值（不會發通知，方便除錯）。', { id: N('哨兵編號') }, ['id'], { perm: 'watch' }, async (a, tc) => {
    const w = ctx.watch.get(a.id); need(w && mine(tc)(w), '找不到這個哨兵'); const r = await ctx.watch.check(w, { notify: false });
    return r.error ? `❌ ${r.error}` : `目前值：${r.value || '（空）'}${r.fired ? '\n條件成立（已記錄；正式排程時才會通知）' : '\n條件未成立'}`;
  });
  def('watch_update', '修改哨兵：暫停／恢復（enabled）、改檢查頻率、改門檻或名稱。', { id: N('哨兵編號'), enabled: B('啟用'), every_min: N('分鐘'), value: S('新門檻／關鍵字'), name: S('名稱'), once: B('單次') }, ['id'], { perm: 'watch' }, (a, tc) => {
    const w = ctx.watch.get(a.id); need(w && mine(tc)(w), '找不到這個哨兵'); const { id, ...patch } = a; ctx.watch.update(id, patch); aud(tc, 'watch.update', `#${id}`); return fmtW(ctx.watch.get(id));
  });
  def('watch_remove', '刪除哨兵。', { id: N('哨兵編號') }, ['id'], { perm: 'watch' }, (a, tc) => { const w = ctx.watch.get(a.id); need(w && mine(tc)(w), '找不到這個哨兵'); ctx.watch.remove(a.id); aud(tc, 'watch.remove', `#${a.id}`); return '已刪除。'; });

  // ---------------- 每日簡報 ----------------
  def('daily_brief', '立刻產生「每日簡報」：天氣、今天行程、未讀重要信、今日提醒、待審批、哨兵觸發、手機電量（有連上的才會出現）。使用者說「今天有什麼事」「幫我整理一下今天」時用。', {}, [], { perm: 'chat' }, async (a, tc) => ctx.brief.build(tc.person));

  // ---------------- 手機（Termux:API） ----------------
  const PH = { perm: 'phone' };
  def('phone_info', '讀取管理員手機的資訊。電量、位置、網路、機型／儲存空間／記憶體／音量由 App 自己讀（不用 Termux；位置要管理員在 App 允許「位置」）；剪貼簿、聯絡人、簡訊、通話紀錄需 Termux＋Termux:API App。action：status＝電量與網路｜location＝位置（precise=true 用 GPS，較慢）｜network＝網路／Wi-Fi｜device＝機型、儲存空間、記憶體、音量、鈴聲模式｜clipboard＝剪貼簿內容｜contacts＝聯絡人（query 篩選）｜sms＝最近簡訊（box: inbox/sent/all）｜calls＝通話紀錄。這些是私人資料：只回答管理員本人要的部分，不要主動轉述給別人。',
  { action: S('status|location|network|device|clipboard|contacts|sms|calls'), query: S('聯絡人關鍵字'), precise: B('GPS 精確定位'), limit: N('筆數'), box: S('inbox|sent|all') }, ['action'], PH, async (a, tc) => {
    const P = ctx.phone; aud(tc, 'phone.info', a.action);
    if (a.action === 'status') return J(await P.status());
    if (a.action === 'location') { const l = await P.location(!!a.precise); return l && l.latitude != null ? `緯度 ${l.latitude}，經度 ${l.longitude}（誤差約 ${Math.round(l.accuracy || 0)} 公尺，來源 ${l.provider || ''}）\nhttps://maps.google.com/?q=${l.latitude},${l.longitude}` : J(l); }
    if (a.action === 'network') return J(await P.network());
    if (a.action === 'device') return J(await P.device());
    if (a.action === 'clipboard') return (await P.clipboardGet()) || '（剪貼簿是空的）';
    if (a.action === 'contacts') return J(await P.contacts(a.query || ''));
    if (a.action === 'sms') return J(await P.sms(a.limit, a.box));
    if (a.action === 'calls') return J(await P.calls(a.limit));
    throw new Error('不支援的 action');
  });
  def('phone_do', '在管理員手機上做事：notify＝跳系統通知（title,text）｜speak＝語音朗讀 text｜torch_on／torch_off＝手電筒｜vibrate｜volume＝看或設定音量（stream, level）｜clipboard_set＝把 text 放到剪貼簿｜photo＝用相機拍照並回傳（camera 0 後鏡頭／1 前鏡頭；只在管理員明確要求時用）。',
  { action: S('notify|speak|torch_on|torch_off|vibrate|volume|clipboard_set|photo'), title: S('通知標題'), text: S('文字'), stream: S('music|ring|alarm|notification|system|call'), level: N('音量'), camera: N('0 或 1') }, ['action'], PH, async (a, tc) => {
    const P = ctx.phone; aud(tc, 'phone.do', a.action);
    switch (a.action) {
      case 'notify': return P.notify(a.title || 'Agent', a.text || '');
      case 'speak': need(a.text, '要給 text'); return P.speak(a.text);
      case 'torch_on': return P.torch(true); case 'torch_off': return P.torch(false);
      case 'vibrate': return P.vibrate(a.level);
      case 'volume': return typeof (a.level) === 'number' ? P.volume(a.stream, a.level) : J(await P.volume(a.stream));
      case 'clipboard_set': need(a.text !== undefined, '要給 text'); return P.clipboardSet(a.text);
      case 'photo': { const img = await P.photo(a.camera); return { text: '已拍照（附圖）。要傳給使用者請用 send_image 或直接描述。', images: [img] }; }
      default: throw new Error('不支援的 action');
    }
  });
  // ---------------- 26.11.3 pro2.1：訊息裡的圖表、股價走勢 ----------------
  const CHART = require('../../ui/chart.js');
  def('stock_history', '查股票／指數／加密貨幣的價格走勢，並產生 App 聊天裡會畫成折線圖的 chart 區塊。symbol：台股代號 2330（自動判斷上市／上櫃）、美股 AAPL、指數 ^TWII、BTC-USD，常見中文名稱（台積電、鴻海、輝達…）也可以。range：1d|5d|1mo|3mo|6mo|ytd|1y|2y|5y|max。回覆時把工具給的 chart 區塊原封不動貼進去，再用一兩句話說重點（漲跌幅、最高最低）；資料來自 Yahoo Finance、可能延遲，不要給買賣建議。',
    { symbol: S('代號或名稱'), range: S('1d|5d|1mo|3mo|6mo|ytd|1y|2y|5y|max'), interval: S('可不填') }, ['symbol'], { perm: 'chat' }, async (a) => {
      const r = await require('../services/stocks').history(a); const f = CHART.fmt;
      return `${r.name}（${r.symbol}）現價 ${f(r.price)} ${r.currency}，${r.change >= 0 ? '漲' : '跌'} ${f(Math.abs(r.change))}（${r.pct >= 0 ? '+' : ''}${r.pct.toFixed(2)}%，與前一收盤比）；區間最高 ${f(r.high)}、最低 ${f(r.low)}，共 ${r.points} 筆。\n資料來源：${r.source}（Yahoo Finance，可能延遲）\n\n把下面這段原封不動放進回覆（App 會畫成折線圖，LINE／Discord／TG 會自動變成文字摘要）：\n${r.block}`; });
  def('chart_make', '把已經從工具查到的數據（記帳、天氣、用量、成績、匯率…）做成 App 聊天裡的折線圖／長條圖。只能用真的查到的數字，不能編。回傳的 chart 區塊要原封不動貼進回覆。',
    { type: S('line|bar'), title: S('標題'), unit: S('單位'), x: { type: 'array', items: { type: 'string' }, description: 'X 軸標籤（日期、類別）' }, series: { type: 'array', items: { type: 'object', properties: { name: S('名稱'), data: { type: 'array', items: { type: 'number' } } } }, description: '最多 6 組' }, source: S('資料來源') }, ['x', 'series'], { perm: 'chat' }, async (a) => {
      const spec = CHART.parse(a); return '把下面這段原封不動放進回覆：\n' + CHART.block(spec); });

  // ---------------- 26.11.3 pro2.1：用手機位置導航、提示附近的交通 ----------------
  const TR = () => ctx.transit; const atOk = (a, tc) => need(a.at || tc.person.role === 'admin', '要用手機定位只限管理員；請說你在哪裡（地名或地址）');
  def('transit_nearby', '附近有什麼交通工具可以搭（預設用管理員手機目前的位置，App 自己定位，不用 Termux）。kind：bus＝公車／客運（有 TDX 金鑰時有幾分鐘到站）｜rail＝捷運、台鐵、高鐵車站與 60 公里內的機場（有 TDX 時含台鐵看板誤點、高鐵班次、機場航班）｜bike＝共享單車 YouBike（可借／可還數量）｜all＝全部。dest 填使用者要去的地方（例：東港、屏東、萬丹），會標出能到那邊的路線／班次。使用者問「附近有什麼車」「怎麼去 X」「X 要搭什麼」時用；結果要附資料來源，沒有的資料不要編。',
    { kind: S('bus|rail|bike|all'), dest: S('要去的地方，可多個用、分隔'), at: S('不用手機定位時，改從這個地名／地址查'), radius_m: N('搜尋半徑（公尺）') }, [], { perm: 'chat' }, async (a, tc) => {
      atOk(a, tc); aud(tc, 'transit.nearby', `${a.kind || 'all'} ${a.dest || ''}`); const k = a.kind || 'all'; const out = [];
      if (k === 'bus' || k === 'all') out.push((await TR().nearby({ at: a.at, radius_m: a.radius_m, dest: a.dest }).catch((e) => ({ text: '公車：' + e.message }))).text);
      if (k === 'rail' || k === 'all') out.push((await TR().stations({ at: a.at, radius_m: k === 'rail' ? a.radius_m : undefined, dest: a.dest }).catch((e) => ({ text: '車站：' + e.message }))).text);
      if (k === 'bike' || k === 'all') out.push((await TR().bikes({ at: a.at, radius_m: k === 'bike' ? a.radius_m : undefined }).catch((e) => ({ text: '共享單車：' + e.message }))).text);
      return out.join('\n\n'); });
  def('transit_plan', '從管理員現在的位置（或 from）到目的地，比較哪種方式最快：大眾運輸（公車、捷運、台鐵、高鐵；有 Google Maps 金鑰時列出每種搭法與上車時間）、開車、騎機車、騎共享單車、走路，每個都附 Google 地圖導航連結。遠距離會提醒可以搭高鐵或飛機（航班用 transit_nearby kind=rail 查）。',
    { to: S('目的地'), from: S('起點；不填＝手機目前位置'), modes: S('要比較的方式：transit,driving,scooter,bike,walking') }, ['to'], { perm: 'chat' }, async (a, tc) => { need(a.from || tc.person.role === 'admin', '要用手機定位只限管理員；請說從哪裡出發'); aud(tc, 'transit.plan', a.to); return (await TR().plan({ to: a.to, from: a.from, modes: a.modes })).text; });
  // 26.11.3 pro10：計時器（到時間手機響鈴＋通知，精確到秒、不花 token）與本機音樂（播手機裡原本就有的音檔，不用匯入）
  def('phone_timer', '計時器／倒數：action＝set（duration 例 "5m"、"90"（秒）、"1h30m"、"1:30"、"三分半"；label 選填）｜list｜cancel（id；不給＝全部）｜stop_ring（停止正在響的鈴聲）。時間到手機會用鬧鐘音量響鈴＋震動＋通知，並在對話裡說一聲。只是倒數提醒用它；到時間要「做事」（查資料、傳訊息）才用 schedule_task。', { action: S('set|list|cancel|stop_ring'), duration: S('多久，例 5m、90、1:30、十分鐘'), label: S('名稱，例：泡麵'), id: N('要取消的編號') }, ['action'], PH, async (a, tc) => {
    need(ctx.timers, '計時器沒有啟動'); const T = ctx.timers;
    if (a.action === 'set') { const t = T.create({ duration: a.duration, label: a.label }, tc.person); aud(tc, 'phone.timer', t.label || String(t.seconds)); const v = T.view(t); return `已開始計時 ${v.text}（${new Date(t.due).toLocaleTimeString('zh-TW', { timeZone: ctx.settings.get('tz') || 'Asia/Taipei', hour12: false })} 響）。`; }
    if (a.action === 'list') { const l = T.list(); return l.length ? l.map((x) => x.text).join('\n') : '沒有正在跑的計時器。'; }
    if (a.action === 'cancel') return `已取消 ${T.cancel(a.id)} 個計時器。`;
    if (a.action === 'stop_ring') { await T.stopRing(); return '已停止鈴聲。'; }
    throw new Error('action：set｜list｜cancel｜stop_ring'); });
  def('phone_music', '播放手機裡「原本就有」的音樂檔（讀手機的媒體庫，不用匯入）：action＝list（q 搜尋歌名／歌手／專輯）｜play（q 或 id；shuffle=true 隨機；不給 q＝全部歌）｜pause｜resume｜next｜prev｜stop｜status（現在播什麼）。App 自己沒在播的時候，pause／resume／next／prev 會改成控制正在播放的其他 App（Spotify、YouTube Music…）。音量用 phone_do volume。', { action: S('list|play|pause|resume|next|prev|stop|status'), q: S('歌名、歌手或專輯'), id: N('list 回傳的編號'), shuffle: B('隨機播放') }, ['action'], PH, async (a, tc) => {
    const P = ctx.phone; const song = (s) => `${s.title}${s.artist ? '－' + s.artist : ''}`; const mmss = (n) => `${Math.floor(n / 60)}:${String(n % 60).padStart(2, '0')}`;
    const st = (r) => (r.song ? `${r.paused ? '已暫停' : '正在播放'}：${song(r.song)}（${mmss(r.position_s || 0)}／${mmss(r.song.duration_s || 0)}，第 ${r.index + 1}／${r.queue} 首${r.next ? '，下一首：' + r.next : ''}）` : r.external ? r.text : r.other_playing ? '現在是其他 App 在播放音樂（可以用 pause／next 控制它）。' : '現在沒有在播放。');
    if (a.action === 'list') { const r = await P.musicList(a.q, 40); return r.count ? `找到 ${r.count} 首${r.count >= 40 ? '（只列前 40，請用 q 縮小範圍）' : ''}：\n` + r.songs.map((s) => `[${s.id}] ${song(s)}（${mmss(s.duration_s)}）`).join('\n') : (a.q ? `手機裡找不到符合「${a.q}」的音樂。` : '手機裡沒有找到音樂檔。'); }
    if (a.action === 'play') { aud(tc, 'phone.music', a.q || String(a.id || 'all')); return st(await P.musicPlay({ id: a.id, q: a.q, shuffle: a.shuffle })); }
    if (a.action === 'status') return st(await P.musicStatus());
    return st(await P.musicControl(a.action)); });
  def('phone_sms_send', '用管理員手機發簡訊。一定會先送管理員審批，核准後才真的發出（可能產生費用、代表管理員發言）。發之前確認號碼與內容；不要冒充管理員做承諾。', { number: S('電話號碼'), text: S('簡訊內容') }, ['number', 'text'], PH, async (a, tc) => {
    need(NUM.test(String(a.number)), '電話號碼格式不正確'); need(String(a.text).trim(), '內容是空的');
    const ap = await ctx.approvals.request({ kind: 'phone_sms', summary: `傳簡訊給 ${a.number}：「${String(a.text).slice(0, 80)}」`, payload: { number: String(a.number), text: String(a.text) }, requester: tc.person.id, chat: chatOf(tc) });
    aud(tc, 'phone.sms.queue', `#${ap.id}`); return `已提出審批 #${ap.id}。管理員在 App 待審批區核准（或回覆「核准 ${ap.id}」）後才會發出。`;
  });
  def('phone_call', '用管理員手機撥電話（撥出後由管理員本人通話；AI 不會講話）。一定先送審批。', { number: S('電話號碼') }, ['number'], PH, async (a, tc) => {
    need(NUM.test(String(a.number)), '電話號碼格式不正確');
    const ap = await ctx.approvals.request({ kind: 'phone_call', summary: `撥電話給 ${a.number}`, payload: { number: String(a.number) }, requester: tc.person.id, chat: chatOf(tc) });
    aud(tc, 'phone.call.queue', `#${ap.id}`); return `已提出審批 #${ap.id}，核准後手機會直接撥出。`;
  });

  // ---------------- 用講的改權限 ----------------
  const PERMS = require('../core/settings').PERMS; const { Grants } = require('../services/grants');
  def('permission_change', `管理員用自然語言授權／收回權限時用（例：「讓小明可以用記帳」「staff 不准用終端機」「AI 以後下載不用問我」「先讓 AI 開瀏覽器一小時」）。改完 App 的權限頁同步更新。高風險變更會回傳確認碼，請你把「回覆『確認 碼』」原樣告訴管理員，由他本人回覆才生效；你絕不能自己代為確認或叫別人確認。\n${Grants.catalog(PERMS)}`,
  { target: S('ai＝AI 自己的政策；或某人的名字；或角色 staff/user/guest'), perm: S('權限鍵或 AI 政策鍵'), action: S('allow 允許｜deny 禁止｜default 恢復預設'), until_minutes: N('暫時開放幾分鐘（選填，到時自動恢復）') }, ['target', 'perm', 'action'], { admin: true }, (a, tc) => ctx.grants.request(a, tc.person, chatOf(tc)).text);
  def('request_permission', '一般用戶想要某個權限（例如「我也想用記帳」）時用：送給管理員審批，核准後自動開通。', { perm: S('權限鍵：' + PERMS.join(' ')), reason: S('原因') }, ['perm'], {}, async (a, tc) => (await ctx.grants.ask(tc.person, a.perm, a.reason, chatOf(tc))).text);
  // ---------------- 產檔案 ----------------
  // ===== 26.11.3 pro2 邏輯閘轉換器（和 App 的轉換器頁同一套程式）=====
  def('logic_convert', '邏輯電路化簡與轉換：輸入布林式（A\'B + BC、~A&B|C、A⊕B）或最小項（F(A,B,C)=Σm(1,3,5)+d(7)、ΠM(0,4)），回傳真值表摘要、最簡 SOP、最簡 POS、只用 NAND 的式子（由 SOP）、只用 NOR 的式子（由 POS）；給 ics（例：7400 或 7408,7432,7404、74HC02、CD4011）會算出要幾顆 IC、每支腳接什麼。結果請照原樣整理給使用者，不要自己重算；也可以告訴他 App 的「邏輯閘轉換器」技能卡能看邏輯圖、點閘改種類。', { expr: S('布林式或最小項'), ics: S('IC 編號（選填，逗號分開）') }, ['expr'], { perm: 'chat' }, (a) => {
    const L = require('../../ui/logic.js'); const out = L.report(String(a.expr || ''), a.ics ? String(a.ics) : undefined); const s = L.solve(String(a.expr || ''));
    const tt = s.vars.length <= 4 ? '\n\n真值表：\n| ' + s.vars.join(' | ') + ' | F |\n|' + s.vars.map(() => ':-:|').join('') + ':-:|\n' + s.table.map((r) => '| ' + [...r.bits].join(' | ') + ' | ' + r.f + ' |').join('\n') : '';
    return out + tt + '\n\n卡諾圖：\n' + L.kmapText(s); });
  def('logic_adder', '加法器／減法器：kind＝ha 半加器｜fa 全加器｜hs 半減器｜fs 全減器｜add N 位元加法器｜sub N 位元減法器（2 的補數）｜addsub 加減法器（M=0 加、M=1 減）。回傳布林式、真值表（單位元）、閘數；給 a、b（十進位）會代入算一次；要實際 IC 接線就給 impl：gates＝用基本閘（7486／7408／7432／7404，可用 ic_map 指定每種閘的 IC）｜msi＝用 4 位元加法器 IC（ic：74283｜7483｜4008，減法另用 7404、加減法用 7486），會列出每支腳接什麼。結果照原樣整理給使用者，不要自己重算。', { kind: S('ha|fa|hs|fs|add|sub|addsub'), bits: N('位元數 1～8（add／sub／addsub）'), a: N('A（十進位）'), b: N('B（十進位）'), x: N('Cin 或 M（0／1）'), impl: S('gates|msi'), ic: S('74283|7483|4008'), ic_map: { type: 'object', description: '{"XOR":"7486","AND":"7408"}', additionalProperties: { type: 'string' } } }, ['kind'], { perm: 'chat' }, (a) => {
    const L = require('../../ui/logic.js'); return L.arithReport(String(a.kind || ''), { bits: a.bits, a: a.a, b: a.b, x: a.x, impl: a.impl, ic: a.ic, map: a.ic_map }); });
  def('logic_state', '讀 App「邏輯閘轉換器」目前的畫面：電路裡每個閘（編號、種類、接哪些訊號）、輸入的 0／1、電路布林式、真值表、卡諾圖、最簡 SOP／POS、NAND／NOR、IC 接線。要操作之前先讀。', {}, [], { perm: 'chat' }, () => { need(ctx.logic, '邏輯閘轉換器沒有啟動'); return ctx.logic.describe(); });
  def('logic_set', '操作 App 的「邏輯閘轉換器」（和管理員看到的是同一個畫面，會即時更新）。expr＝換成這個函數的電路（form：sop｜pos｜nand｜nor）；form＋rebuild＝切換形式；inputs＝設輸入 {A:1}；gate／add_gate／remove_gate／output／add_input／remove_input＝改電路；ic_map＝每種閘用哪顆 IC（實際接線圖）；wire_source＝接線照 ckt（畫的電路）或 form（轉換結果）；ics＝只有這幾顆 IC 時自動換做法；arith＝打開加法器／減法器（null 關掉）；reset＝回預設。做完在回覆最後加 [[開啟:邏輯閘轉換器]]（App 會變成按鈕）。', { expr: S('布林式或最小項'), form: S('sop|pos|nand|nor'), rebuild: B('連上面的電路一起換'), ics: S('IC 編號'), ic_map: { type: 'object', description: '{"AND":"7408"}', additionalProperties: { type: 'string' } }, wire_source: S('ckt|form'), arith: { type: 'object', nullable: true, description: '{"kind":"addsub","bits":4,"a":7,"b":2,"x":1,"impl":"msi","ic":"74283"}', properties: { kind: S('ha|fa|hs|fs|add|sub|addsub'), bits: N('1～8'), a: N('A'), b: N('B'), x: N('Cin／M'), impl: S('gates|msi'), ic: S('加法器 IC') } }, inputs: { type: 'object', description: '{"A":1,"B":0}', additionalProperties: { type: 'number' } }, gate: { type: 'object', description: '{id, type, ins}', properties: { id: S('閘編號，例 g1'), type: S('AND|OR|NAND|NOR|XOR|XNOR|NOT|BUF'), ins: ARR('輸入訊號') } }, add_gate: { type: 'object', description: '{type, ins}', properties: { type: S('閘種類'), ins: ARR('輸入訊號') } }, remove_gate: S('要刪的閘編號'), output: S('輸出接的訊號'), add_input: B('加一個變數'), remove_input: S('要刪的變數'), reset: B('回到預設電路') }, [], { perm: 'chat' }, (a, tc) => {
    need(ctx.logic, '邏輯閘轉換器沒有啟動'); ctx.logic.apply(a); aud(tc, 'logic.set', Object.keys(a).join(',')); return '已更新邏輯閘轉換器（App 畫面會同步）。目前狀態：\n' + ctx.logic.describe(); });

  // ===== 26.11.3 pro7 電路工具（和 App 的「電路工具」同一套算法；算出來的數字照原樣給使用者，不要自己重算） =====
  const NET = '零件清單（netlist）一行一個：名稱 節點… 值。節點 0＝地。R1 a b 1k｜C1 a 0 100u｜L1 a b 10m｜V1 vcc 0 9（直流電源，+ 在前）｜I1 a b 10m｜D1 a k（矽二極體；schottky；zener vz=5.1，齊納要反接：D1 0 z zener）｜LED1 a 0 red（red/orange/yellow/green/blue/white/ir/uv）｜SW1 a b on/off｜POT1 a b w 10k pos=0.3（第三個節點是滑動端）｜LDR1 a 0（光敏電阻，env light=lux）｜NTC1 a 0 10k beta=3950（env temp=°C）｜LAMP1 a 0 v=6 w=0.5｜Q1 c b e beta=100（NPN）｜U1 in 0 out 7805（7812、7833；腳：輸入 地 輸出）｜OP1 inp inn out opamp vpos=12 vneg=-12｜U2 vcc out 0 555 r1=1k r2=10k c=10u｜U3 vcc out 0 lm35｜env light=300 temp=25。可以用「;」分隔寫在同一行。';
  const Ck = () => require('../../ui/circuit.js');
  def('circuit_solve', '電路計算（直流工作點＋時間模擬）：給零件清單，算出每個節點的電壓、每個零件的電壓／電流／功率、LED 亮不亮、電晶體狀態、穩壓 IC 有沒有在穩壓、運放有沒有飽和、哪些零件會燒掉；有電容／電感／555 時 tran=true 會加上從 0 秒開始的時間模擬（充放電時間、方波）。' + NET + ' 結果照原樣整理給使用者，不要自己重算。', { netlist: S('零件清單'), tran: B('也做時間模擬'), t_end: N('時間模擬到幾秒（選填，預設自動）') }, ['netlist'], { perm: 'chat' }, (a) => {
    const C = Ck(); const r = C.parse(String(a.netlist || '')); const ck = { parts: r.parts, env: { light: 300, temp: 25, ...r.env } }; return C.report(ck, { tran: a.tran ? (a.t_end ? { t_end: +a.t_end } : true) : false }); });
  def('circuit_calc', '電子計算機（公式＋標準值＋接法）：kind＝ohm 歐姆定律（v,i,r,p 填兩個）｜led LED 限流電阻（vs, vf 或 color, if, n）｜divider 分壓（vin,r1,r2,vout 填三個）｜rc 時間常數／截止頻率（r,c）｜t555 555 頻率（r1,r2,c；或 f,duty,c 反推電阻）｜color 色碼（r→色碼，或 colors：棕 黑 紅 金→阻值）｜series 串並聯（list：1k 2.2k；kind=c 是電容）｜lc 共振頻率（l,c）｜battery 電池續航（mah, ma）。數值可以寫 4.7k、100u、15mA。', { kind: S('ohm|led|divider|rc|t555|color|series|lc|battery'), v: S('電壓'), i: S('電流'), r: S('電阻'), p: S('功率'), vs: S('電源電壓'), vf: S('LED 順向電壓'), color: S('LED 顏色'), if: S('LED 電流'), n: N('LED 串幾顆'), vin: S('輸入電壓'), vout: S('輸出電壓'), r1: S('R1'), r2: S('R2'), c: S('電容'), l: S('電感'), f: S('頻率'), duty: S('工作週期'), colors: S('色碼'), list: S('數值清單'), mah: S('電池 mAh'), ma: S('耗電 mA') }, ['kind'], { perm: 'chat' }, (a) => { const { kind, ...rest } = a; return Ck().calc(String(kind || ''), rest).text; });
  def('circuit_state', '讀 App「電路工具」目前的畫面：零件清單、每個節點電壓、每個零件的電壓電流功率、警告、時間模擬摘要。要操作之前先讀。', {}, [], { perm: 'chat' }, () => { need(ctx.circuit, '電路工具沒有啟動'); return ctx.circuit.describe(); });
  def('circuit_set', '操作 App 的「電路工具」（和管理員看到的是同一個畫面，會即時更新）。netlist＝整個電路換掉；preset＝載入範例（divider 分壓｜led｜rc 充電｜night 光控夜燈｜reg 7805 穩壓｜amp 運放｜blink 555 閃爍｜temp LM35｜bridge 電橋｜zener｜rl）；add＝加零件（同 netlist 格式）；remove＝刪零件（名稱）；set＝改零件 [{id, value, pos, on, color, beta, vz, r1, r2, c, nodes}]；env＝{light（lux）, temp（°C）}；title；reset。零件格式同 circuit_solve。做完在回覆最後加 [[開啟:電路工具]]。', { netlist: S('整個電路'), preset: S('範例名稱'), add: S('要加的零件'), remove: S('要刪的零件名稱'), set: { type: 'array', description: '[{"id":"R1","value":"2.2k"},{"id":"SW1","on":false},{"id":"POT1","pos":0.8}]', items: { type: 'object', properties: { id: S('零件名稱'), value: S('新數值'), pos: N('可變電阻 0～1'), on: B('開關'), color: S('LED 顏色'), beta: N('β'), vz: S('齊納電壓'), r1: S('555 R1'), r2: S('555 R2'), c: S('555 C'), nodes: ARR('改接到哪些節點') } } }, env: { type: 'object', description: '{"light":50,"temp":40}', properties: { light: N('光線 lux'), temp: N('溫度 °C') } }, title: S('標題'), reset: B('回到預設電路') }, [], { perm: 'chat' }, (a, tc) => {
    need(ctx.circuit, '電路工具沒有啟動'); ctx.circuit.apply(a); aud(tc, 'circuit.set', Object.keys(a).join(',')); return '已更新電路工具（App 畫面會同步）。\n' + ctx.circuit.describe(); });

  // ===== 26.11.3 pro7 程式碼工具（和 App 的「程式碼工具」同一份；改程式碼前先讀，局部修改用 replace，不要整份重寫） =====
  const Cd = () => { need(ctx.code, '程式碼工具沒有啟動'); return ctx.code; };
  def('code_state', '讀 App「程式碼工具」目前的程式碼（含行號）與上次執行結果。file＝只看某個檔案。', { file: S('檔名（選填）') }, [], { perm: 'chat' }, (a) => Cd().describe(undefined, { name: a.file }));
  def('code_set', '修改 App「程式碼工具」裡的程式碼（管理員畫面會即時更新）。file＝檔名（沒有就新增）；lang＝javascript｜python｜c｜cpp｜bash｜go｜java｜rust｜php｜ruby｜lua｜html｜css｜json｜sql｜text；code＝整份換掉（新檔或要全改才用）；replace＝局部取代 [{find, with}]（find 要剛好出現一次，修 bug／小改用這個，省 token）；insert＝{line, text} 在第幾行後插入；open＝切到某檔；rename；remove＝刪檔；reset。做完在回覆最後加 [[開啟:程式碼工具]]。', { file: S('檔名'), lang: S('語言'), code: S('整份程式碼'), replace: { type: 'array', items: { type: 'object', properties: { find: S('原本的片段'), with: S('換成') } } }, insert: { type: 'object', properties: { line: N('在第幾行後'), text: S('插入的內容') } }, open: S('切到哪個檔'), rename: S('新檔名'), remove: S('要刪的檔'), reset: B('回到範例') }, [], { perm: 'chat' }, (a, tc) => { const st = Cd().apply(a); aud(tc, 'code.set', Object.keys(a).join(',')); const f = st.files[st.cur]; return `已更新 ${f.name}（${f.code.split('\n').length} 行，App 畫面會同步）。`; });
  def('code_run', '執行「程式碼工具」裡的程式（或直接給 code＋lang），在 App 內建 Linux／Termux 跑（Python、C、C++、Bash、Go、Java、Rust、PHP、Ruby、Lua、Node.js），回傳輸出與結束碼；結果也會顯示在 App 畫面。stdin＝標準輸入。缺執行環境時會說要裝什麼。', { file: S('檔名（選填，預設目前打開的）'), code: S('直接給程式碼（選填）'), lang: S('語言（配合 code）'), stdin: S('標準輸入'), timeout_s: N('逾時秒數，預設 30，最多 120') }, [], { perm: 'terminal' }, async (a, tc) => { aud(tc, 'code.run', a.file || a.lang || ''); const r = await Cd().run({ name: a.file, code: a.code, lang: a.lang, stdin: a.stdin, timeout_s: a.timeout_s, save: a.code == null }); return `${r.name}（結束碼 ${r.code}${r.timedOut ? '，逾時' : ''}）：\n${r.text}`; });
  def('code_save', '把「程式碼工具」的檔案存到工作區（預設 code/ 資料夾），之後可以用檔案工具傳給使用者。', { file: S('只存這個檔（選填）'), dir: S('資料夾，預設 code') }, [], { perm: 'chat' }, (a) => Cd().save({ name: a.file, dir: a.dir }).text);

  // ===== 26.11.3 pro9 資安專家（只做防禦：找弱點、給修法、威脅建模；不產生攻擊程式、不攻擊第三方） =====
  const Sec = () => require('../services/secaudit.js');
  const kbSearch = (file, label) => (query) => {
    let md = ''; try { md = require('fs').readFileSync(require('path').join(__dirname, '..', '..', 'knowledge', file), 'utf8'); } catch { return `（${label}讀取失敗）`; }
    const q = String(query || '').trim().toLowerCase(); const secs = md.split(/\n(?=## )/);
    if (!q) return label + '章節：\n' + secs.map((x) => (x.match(/^##\s+(.+)/m) || [])[1]).filter(Boolean).map((t) => '・' + t).join('\n') + '\n（給關鍵字可看該章內容）';
    const grams = new Set(); const cjk = q.replace(/[^一-鿿]/g, ' ').split(/\s+/).filter(Boolean); for (const w of cjk) for (let i = 0; i + 2 <= w.length; i++) grams.add(w.slice(i, i + 2));
    for (const w of q.match(/[a-z0-9]{2,}/g) || []) grams.add(w);
    const scored = secs.map((x) => { const low = x.toLowerCase(); const head = (low.split('\n')[0] || ''); let sc = 0; for (const g of grams) { if (head.includes(g)) sc += 3; else if (low.includes(g)) sc += 1; } return { x, sc }; }).filter((o) => o.sc >= Math.min(2, grams.size)).sort((a, b) => b.sc - a.sc).slice(0, 3);
    return scored.length ? scored.map((o) => o.x.trim()).join('\n\n') : '知識庫沒有直接相符的章節，可用空白查詢看全部章節標題。';
  };
  const secKB = kbSearch('security.md', '資安知識庫'); const stemKB = kbSearch('engineering.md', '理工知識庫');
  // ===== 26.11.3 pro9 理工／工程：單位換算、公式與方法速查（計算用 calculate：已支援三角、對數、階乘、物理常數） =====
  def('unit_convert', '單位換算（精確、不連網）：長度、質量、時間、溫度（C／F／K）、面積（含坪）、體積、速度、力、壓力、能量、功率、角度、頻率、資料量、電學（A V Ω F H C mAh）。SI 字首可直接寫（km、mA、µF、GHz、kPa、MJ）。不同物理量不能互換會直接報錯。理工計算換單位都用它，不要心算。', { value: N('數值'), from: S('原單位，例 km/h、psi、°C、µF、坪'), to: S('目標單位') }, ['value', 'from', 'to'], { perm: 'chat' }, (a) => require('../services/units').convert(a.value, a.from, a.to).text);
  def('stem_kb', '查理工與工程知識庫：解題方法、數學（微積分、線代、機率統計）、物理（力學、熱、波、光、近代）、電學電子、材料結構、熱流能源、控制訊號、電腦科學與軟體工程、化學、單位與常數。空白查詢列出章節。解理工題前先查公式，再用 calculate 算。', { query: S('關鍵字，例：梁 撓度、RC、貝氏、雷諾數、PID、複雜度') }, [], { perm: 'chat' }, (a) => stemKB(a.query));
  def('math_solve', '數學求解（精確數值計算，不要自己硬算）。kind＝solve 解方程（expr 例 "x^3-2*x=5"，可給 variable、lo、hi 搜尋範圍）｜poly 多項式全部根含複數（coeffs 高次到常數，例 "1,-6,11,-6"）｜linear 聯立 Ax=b（A 例 "2 1; 1 3"，b 例 "5,10"）｜matrix（op＝det｜inv｜mul｜transpose｜rank｜eig，A、B）｜diff 微分（expr、at，order=2 二階）｜integrate 定積分（expr、a、b_）｜regress 擬合（x、y、degree）｜stats 統計（data）｜base 進位（value、from、to）｜factor 質因數（value）｜ode 解 y\'=f(x,y)（expr、x0、y0、x1）。算式語法同 calculate（乘號寫 *）。',
    { kind: S('solve|poly|linear|matrix|diff|integrate|regress|stats|base|factor|ode'), expr: S('算式'), variable: S('變數名，預設 x'), lo: N('solve 搜尋下限'), hi: N('solve 搜尋上限'), coeffs: S('poly 係數'), A: S('矩陣'), B: S('第二個矩陣（mul）'), b: S('linear 的右邊'), op: S('matrix 的運算'), at: N('diff 的點'), order: N('1 或 2'), a: N('積分下限'), b_: N('積分上限'), x: S('regress 的 x 資料'), y: S('regress 的 y 資料'), degree: N('擬合次數'), data: S('stats 的資料'), value: S('base／factor 的數'), from: N('原進位'), to: N('目標進位'), x0: N('ode 起點 x'), y0: N('ode 起點 y'), x1: N('ode 算到的 x'), steps: N('ode 步數') }, ['kind'], { perm: 'chat' }, (a) => require('../services/mathx').run(a).text);
  def('eng_calc', '工程計算機（SI 單位，回傳公式、代入與工程判讀）。kind＝beam 梁（L、P 集中載重 N 或 w 均布 N/m、support=simple｜cantilever、截面 width＋height 或 diameter(＋inner) 或 I＋c、material=steel｜aluminum｜copper｜wood｜titanium 或 E、yield）→ 彎矩、撓度、應力、安全係數｜pipe 管流（D、L、v 或 Q，可給 rho、mu、roughness）→ 雷諾數、摩擦係數、壓損、泵功率｜gas 理想氣體（P、V、n、T 給三個）｜projectile 拋體（v、angle、h）｜rotation（P、torque、rpm 給兩個，可加 gear）｜thermal（傳導 k,A,dT,thickness；膨脹 alpha,L0,dT；加熱 m,dT,c,power）｜buckling 柱挫屈（L、截面、end）。單位不是 SI 先用 unit_convert。',
    { kind: S('beam|pipe|gas|projectile|rotation|thermal|buckling'), L: N('長度 m'), P: N('集中載重 N／壓力 Pa／功率 W（依 kind）'), w: N('均布載重 N/m'), support: S('simple|cantilever'), width: N('矩形寬 m'), height: N('矩形高 m'), diameter: N('圓直徑 m'), inner: N('空心內徑 m'), I: N('慣性矩 m⁴'), c: N('到中性軸距離 m／比熱（thermal）'), material: S('材料'), E: N('彈性模數 Pa'), yield: N('降伏強度 Pa'), D: N('管內徑 m'), v: N('速度 m/s'), Q: N('流量 m³/s'), rho: N('密度'), mu: N('黏度 Pa·s'), roughness: N('粗糙度 m'), efficiency: N('效率 0～1'), V: N('體積 m³'), n: N('莫耳數'), T: N('溫度 K'), angle: N('仰角 度'), h: N('起始高度 m'), torque: N('扭矩 N·m'), rpm: N('轉速'), gear: N('減速比'), k: N('熱傳導係數'), A: N('面積 m²'), dT: N('溫差 K'), thickness: N('厚度 m'), alpha: N('膨脹係數 1/K'), L0: N('原長 m'), m: N('質量 kg'), power: N('加熱功率 W'), end: S('pinned|fixed|cantilever|fixed-pinned') }, ['kind'], { perm: 'chat' }, (a) => require('../services/engcalc').run(a).text);
  def('security_audit', '資安靜態稽核（防禦）：掃描一段程式碼或設定，找常見弱點類型（寫死金鑰、SQL／指令注入、XSS、弱加密、不安全亂數、反序列化、路徑穿越、SSRF、關掉 TLS 驗證、CORS 全開、開著 debug、把祕密寫進 log、JWT 設定不安全…），每項附 CWE、嚴重度、風險說明與修法。可給 code（直接貼），或 from_code_tool=true 掃「程式碼工具」裡目前的檔案。只指出問題與修法，不會產生任何攻擊程式。結果照原樣整理給使用者，嚴重度高的先修。',
    { code: S('要稽核的程式碼或設定內容'), lang: S('語言（js／python／php／java…，選填，幫助判斷）'), from_code_tool: B('改掃「程式碼工具」目前的檔案'), file: S('配合 from_code_tool：指定檔名（選填）') }, [], { perm: 'chat' }, (a) => {
      let code = a.code; let lang = a.lang;
      if (a.from_code_tool) { need(ctx.code, '程式碼工具沒有啟動'); const st = ctx.code.get(); const f = ctx.code.file(st, a.file); code = f.code; lang = lang || f.lang; }
      need(code && String(code).trim(), '要給 code，或 from_code_tool=true');
      return Sec().report(code, { lang }); });
  def('security_review', '資安評估（紅隊檢查＋綠隊強化，防禦）：給一段系統描述（技術棧、部署方式、處理什麼資料），產生「攻擊者會檢查哪些點」的紅隊清單，與對應的綠隊強化建議。這是檢查清單與建議，不是入侵步驟。可搭配 security_kb 補細節。',
    { system: S('系統描述，例：Node + Express + MySQL 的 API，JWT 登入，部署在 Ubuntu VPS，處理會員個資') }, ['system'], { perm: 'chat' }, (a) => Sec().assess(a.system));
  def('security_kb', '查資安知識庫（OWASP、API 安全、注入防護、認證授權、密碼學、祕密管理、伺服器／雲端／Android 硬化、威脅建模 STRIDE、事件應變、供應鏈、安全標頭）。空白查詢列出所有章節。回答資安問題前先查，確保建議正確、具體。',
    { query: S('關鍵字或主題，例：JWT、SSRF、密碼雜湊、SSH 硬化、威脅建模') }, [], { perm: 'chat' }, (a) => secKB(a.query));
  // ---- Anti-gravity-engine2：網站工作室——AI 自己開發完整網頁系統 ----
  const SI = () => { need(ctx.sites, '網站工作室沒有啟動'); return ctx.sites; };
  const FILES = { type: 'array', description: '要寫入的檔案（可一次好幾個）。content＝完整檔案內容（不是片段）；要刪除就給 delete:true', items: { type: 'object', properties: { path: S('專案內的相對路徑，例：index.html、css/style.css、js/app.js、public/index.html、server.js'), content: S('完整檔案內容'), delete: B('刪除這個檔案') }, required: ['path'] } };
  // Anti-gravity-engine3：一句話直接生成（使用者不用選範本、不用設定）
  def('site_build', '一句話直接生成完整網站（首選）：自動判斷類型（官網／管理系統／儀表板／前後端）、規劃版面與功能、寫好所有檔案、檢查並自動修錯、打包 zip，做好自動把結果與 zip 傳到這個聊天室（約 1～3 分鐘）。使用者說要做網站／網頁／系統時直接呼叫，不要先問問題、不要叫使用者選範本。request 照使用者原話，可補上對話中已知的細節。',
    { request: S('使用者想要的網站（原話＋已知細節）') }, ['request'], { perm: 'files' }, (a, tc) => {
      const m = tc.msg || {}; const j = SI().build(a.request, { by: tc.person.id, reply: { platform: m.platform || 'app', chatId: m.chatId || '', pid: tc.person.id } }); aud(tc, 'site.build', j.id);
      return `已開始製作網站（工作 ${j.id}）：AI 會自己規劃、寫程式、檢查修錯、打包，大約 1～3 分鐘，做好會自動把預覽方式和 zip 傳到這個聊天室。回覆使用者：已經開始做、大概多久、做好會自動傳來、之後想改哪裡直接說；不要說已經做好，也不要問他要選什麼。`; });
  def('site_list', '列出網站工作室裡的網站專案與可用範本。', {}, [], { perm: 'files' }, () => { const l = SI().list(); return (l.length ? l.map((s) => `・${s.name}（id：${s.id}，範本 ${s.template}，${s.files} 個檔案，${Math.max(1, Math.round(s.bytes / 1024))} KB）`).join('\n') : '還沒有網站') + '\n範本：' + SI().templates().map((t) => `${t.id}＝${t.name}`).join('、'); });
  def('site_create', '建立網站專案（網站工作室）。template：blank 空白｜landing 一頁式官網（導覽、主視覺、特色、方案、聯絡表單）｜app 資料管理系統（新增／編輯／刪除／搜尋／排序／匯出 CSV）｜dashboard 數據儀表板（KPI、折線、長條圖，純 JS）｜fullstack 前後端系統（Node 原生 http＋REST API＋JSON 檔案資料庫，零相依）。挑最接近需求的範本當骨架，再用 site_write 改成使用者要的樣子。',
    { name: S('網站名稱（會顯示在標題）'), template: S('blank|landing|app|dashboard|fullstack'), description: S('需求摘要（給之後修改時參考）') }, ['name'], { perm: 'files' }, (a, tc) => { const s = SI().create(a, tc.person.id); aud(tc, 'site.create', s.id); return `已建立網站「${s.name}」（id：${s.id}，範本 ${s.template}）：\n${SI().files(s).map((f) => '・' + f.path).join('\n')}\n下一步：site_read 看範本內容，site_write 依需求改寫，完成後 site_check。`; });
  def('site_write', '寫入／修改／刪除網站專案的檔案（一次可多個）。每個檔案給「完整內容」。寫完會自動做一次快速檢查並回報錯誤，有錯就繼續修到沒錯。',
    { site: S('網站 id 或名稱'), files: FILES }, ['site', 'files'], { perm: 'files' }, (a, tc) => {
      const r = SI().write(a.site, (a.files || []).map((f) => ({ path: f.path, content: f.delete ? null : f.content })), tc.person.id); aud(tc, 'site.write', `${r.site.id} ${r.done.length}`);
      const c = SI().check(r.site.id); return `${r.done.join('\n')}\n\n${SI().report(c)}`; });
  def('site_read', '讀網站專案：不給 path＝列出所有檔案；給 path＝讀那個檔案的內容（含行號，修改前先讀）。', { site: S('網站 id 或名稱'), path: S('檔案路徑（選填）') }, ['site'], { perm: 'files' }, (a) => {
    const r = SI().read(a.site, a.path); if (!a.path) return `網站「${r.site.name}」（${r.site.id}）：\n${r.files.map((f) => `・${f.path}（${f.size} B）`).join('\n')}`;
    if (r.binary) return `${r.path} 是二進位檔（${r.size} B）`; const lines = r.content.split('\n'); return `${r.path}（${lines.length} 行）：\n` + lines.slice(0, 600).map((l, i) => `${String(i + 1).padStart(4)}| ${l}`).join('\n') + (lines.length > 600 ? '\n…（後面省略）' : ''); });
  def('site_check', '檢查網站（不執行程式）：JS 語法、JSON、CSS、HTML 結構、找不到的引用檔、手機版 viewport、重複 id、圖片 alt、常見資安問題（XSS、寫死金鑰）。交付前一定要跑到 0 錯誤。', { site: S('網站 id 或名稱') }, ['site'], { perm: 'files' }, (a) => SI().report(SI().check(a.site)));
  def('site_preview', '取得網站的預覽網址（只在這支手機上能開，http://127.0.0.1:…）。要親眼確認畫面：用 browser_open 開這個網址再 browser_screenshot；使用者也可以在 App「網站工作室」直接看。', { site: S('網站 id 或名稱') }, ['site'], { perm: 'files' }, async (a) => { const p = await SI().preview(a.site); return `預覽網址：${p.url}\n（這個網址只在這支手機上有效；和 App 是不同來源，網站程式碰不到 App 的資料。後端 server.js 要另外用 node 執行，預覽時前端會自動改用瀏覽器儲存。）`; });
  def('site_zip', '把整個網站打包成 zip 傳給使用者（可以直接上傳到主機、GitHub Pages、Netlify、Vercel，或解壓後 node server.js）。', { site: S('網站 id 或名稱') }, ['site'], { perm: 'files' }, (a, tc) => {
    const c = SI().check(a.site); const rec = SI().zip(a.site, tc.person.id); if (tc.files) tc.files.push(rec); aud(tc, 'site.zip', rec.name);
    return `已打包「${rec.name}」（${Math.max(1, Math.round(rec.size / 1024))} KB），回覆後會自動傳給使用者。${c.ok ? '' : `\n注意：還有 ${c.errors.length} 個錯誤沒修：\n` + c.errors.slice(0, 5).map((e) => `・${e.file}${e.line ? ':' + e.line : ''} ${e.msg}`).join('\n')}`; });
  // ---- Anti-gravity-engine2：影片工作室——AI 自己做影片 ----
  const VD = () => { need(ctx.videos, '影片工作室沒有啟動'); return ctx.videos; };
  const SCENES = { type: 'array', description: '分鏡（依序播放，最多 30 格、總長最多 180 秒）', items: { type: 'object', properties: {
    layout: S('title 大標題｜text 標題＋段落｜bullets 條列（逐條出現）｜image 圖片（緩慢推近）｜quote 引言｜stat 大數字（會跳動計數）｜end 結尾；不給會依內容自動判斷'),
    title: S('標題（60 字內）'), text: S('內文（220 字內，簡短有力）'), bullets: ARR('條列（最多 6 條，每條 60 字內）'), image: S('工作區裡的圖片路徑（例：images/xxx.png，可先用 generate_image 產生）'),
    stat: { type: 'object', description: 'layout=stat 用', properties: { value: S('數字，例：98%、NT$1,200、3.5 倍'), label: S('說明') } },
    caption: S('底部字幕（選填）'), duration: N('秒數（1.5～20；不給會依字數自動算）'), anim: S('fade｜slide｜zoom｜type（打字機）'), bg: S('背景色 #RRGGBB（選填）'), bg2: S('漸層第二色（選填）') } } };
  def('video_create', '一句話直接生成影片（首選）：AI 自動寫分鏡與旁白、挑風格（動態圖像／手繪故事／電影感實拍／產品宣傳／數位主持人）、直式或橫式、配色、背景音樂，自動備素材（旁白人聲、實拍、AI 插圖、AI 自己用瀏覽器截網頁、用手機代理截其他 App 的畫面、虛擬或 HeyGen 主持人），算圖後自動傳到這個聊天室。使用者說要做影片／短影音時直接呼叫，不要先問問題、不要叫使用者設定。使用者剛傳了自己的影片或照片就放進 media；要介紹網站／App 就把網址放進 urls。',
    { request: S('使用者想要的影片（原話＋已知細節：主題、對象、長度、要不要主持人）'), media: ARR('使用者自己的影片／照片（工作區路徑，選填）'), urls: ARR('要截圖介紹的網頁網址（選填，最多 4 個）') }, ['request'], { perm: 'chat' }, (a, tc) => {
      const m = tc.msg || {}; const v = VD().auto(a.request, { by: tc.person.id, reply: { platform: m.platform || 'app', chatId: m.chatId || '', pid: tc.person.id }, media: a.media, urls: a.urls }); aud(tc, 'video.auto', v.id);
      const caps = ctx.vidmedia ? ctx.vidmedia.caps() : {}; const has = [caps.narration && `旁白人聲（${caps.voice}）`, caps.stock && `實拍素材（${caps.stock_source}）`, caps.presenter ? 'HeyGen 數位主持人' : caps.avatar && '免費虛擬主持人（要主持人時）', caps.images && 'AI 插圖'].filter(Boolean); const miss = [!caps.narration && '旁白人聲（在 Android App 裡會用手機內建語音；或加 Gemini／OpenAI 金鑰）', !caps.stock && '實拍素材（影片工作室打開「免費實拍」）'].filter(Boolean);
      const eng = ctx.vengine && ctx.vengine.passed() ? 'HyperFrames 專業引擎會在背景算圖' : 'App 畫面會自動算圖（App 畫面要開著）';
      return `已開始製作影片（${v.id}）：AI 正在寫分鏡與旁白、準備素材，接著${eng}，通常 1～3 分鐘（有數位主持人要更久），做好自動傳到這個聊天室。可用素材：${has.join('、') || '動態文字與合成音樂'}${miss.length ? `；目前缺：${miss.join('、')}` : ''}。回覆使用者：已經開始做、大概多久、做好會自動傳來；缺的東西簡短提一句怎麼補；不要說已經做好，也不要問他要什麼尺寸或風格。`; });
  def('video_engine', '管理影片專業引擎（Termux 裡的 HyperFrames＋GSAP＋FFmpeg＋Chromium＋Remotion）與 7 個影片技能（HyperFrames、Remotion、GSAP AI Skills、Pixel2Motion、Video Shotcraft、story-to-handdrawn-video、motion-design）。action：status 狀態｜install 安裝（背景，約 10～30 分鐘）｜install_log 看安裝進度｜check 檢查版本與 doctor｜import_skills 把官方技能檔匯入技能庫（之後用 skill_read 讀）｜test 算一支測試片（通過後自動啟用）。',
    { action: S('status|install|install_log|check|import_skills|test') }, ['action'], { perm: 'admin' }, async (a) => {
      need(ctx.vengine, '影片引擎沒有啟動'); const E = ctx.vengine; const act = String(a.action || 'status');
      if (act === 'install') return (await E.install()).text;
      if (act === 'install_log') { const r = await E.installLog(); return `${r.done ? '安裝完成' : '安裝中…'}\n${r.log.split('\n').slice(-25).join('\n')}`; }
      if (act === 'check') { const r = await E.check(); return `${r.ok ? '環境齊全' : '還缺：' + r.missing.join('、')}\n版本：${JSON.stringify(r.versions)}\n技能：${r.skills.join('、') || '還沒下載'}\n${r.doctor ? 'doctor：\n' + r.doctor.split('\n').slice(-12).join('\n') : ''}`; }
      if (act === 'import_skills') { const r = await E.importSkills(); return `已匯入 ${r.imported.length} 份官方技能：${r.imported.join('、')}（用 skill_read 讀）`; }
      if (act === 'test') { const r = await E.selfTest(); return r.ok ? `測試通過：${r.sec} 秒算出 ${Math.round(r.size / 1024)} KB 的 MP4，之後自動用 HyperFrames 算圖` : `測試沒通過：${r.error}\n影片會繼續用 App 畫面算圖。`; }
      const st = E.state(); return `Termux：${st.termux ? '已連線' : '未設定'}｜安裝：${st.installed_at ? '完成' : st.install_job ? '進行中' : '未安裝'}｜測試：${st.passed ? '通過（自動使用 HyperFrames）' : st.test_error ? '未通過：' + st.test_error : '還沒測'}｜引擎設定：${st.engine}\n版本：${JSON.stringify(st.versions)}\n已匯入技能：${st.imported.join('、') || '無'}`; });
  def('video_make', '（進階）自己寫好完整分鏡再做影片——一般情況請用 video_create。自己製作影片（MP4／WebM，含背景音樂）：寫好分鏡腳本交給影片工作室，App 畫面會自動算圖，做好後自動傳回這個聊天室。適合：產品介紹、重點整理、教學步驟、活動宣傳、數據報告、社群短影音。寫腳本：第一格吸睛標題 → 中間每格只講一個重點（字少、條列、數字）→ 最後一格行動呼籲。需要圖片先用 generate_image 產生再填 image。限制：這條路不會自動配旁白人聲與備實拍素材（要人聲、實拍、主持人請用 video_create）；App 畫面要開著才會開始算（任何一頁都行），算圖時間約等於影片長度。',
    { title: S('影片標題'), size: S('portrait 直式 9:16（短影音、預設）｜landscape 橫式 16:9｜square 方形 1:1'), theme: S('dark｜light｜vivid｜warm｜mono｜ocean'), accent: S('主色 #RRGGBB（選填）'), music: S('none｜calm 柔和（預設）｜upbeat 輕快｜cinematic 電影感'), scenes: SCENES }, ['scenes'], { perm: 'chat' }, (a, tc) => {
      const m = tc.msg || {}; const v = VD().make(a, { by: tc.person.id, reply: { platform: m.platform || 'app', chatId: m.chatId || '', pid: tc.person.id } }); aud(tc, 'video.make', v.id);
      return `已排入影片工作室（id：${v.id}，${v.spec.scenes.length} 格、約 ${v.spec.duration} 秒、${v.spec.w}×${v.spec.h}）。App 畫面開著時會自動算圖（大約 ${Math.ceil(v.spec.duration + 5)} 秒），做好會自動傳到這個聊天室。回覆使用者：已開始製作、大概多久、做好會自動傳來；不要說已經做好。`; });
  def('video_status', '查影片工作室裡影片的製作狀態（寫分鏡中／排隊中／製作中 %／完成／失敗原因）。', {}, [], { perm: 'chat' }, () => { const l = VD().list().slice(0, 10); return l.length ? l.map((v) => `・${v.title}（${v.id}）：${{ drafting: 'AI 寫分鏡中', queued: '排隊中（App 畫面開著才會開始）', rendering: `製作中 ${v.progress}%`, done: '完成', error: '失敗：' + v.error }[v.status] || v.status}，${v.duration} 秒`).join('\n') : '還沒有影片'; });
  def('attack_surface', '攻擊面盤點＋授權滲透測試計畫（紅隊視角）：給一段「你自己的」系統或目標描述，產出攻擊面地圖（攻擊者會從哪些進入點／信任邊界接觸系統）、要逐項驗證的檢查清單、可用現成合規工具做的測試方法、優先序，以及對應的綠隊修補。這是規劃與檢查清單，不含任何可執行的 exploit、payload 或入侵步驟。只能用於自己擁有或有書面授權（ROE）的系統；要攻擊第三方或要可直接執行的攻擊程式一律拒絕，改給防禦與偵測。',
    { target: S('目標描述，例：對外的 Node/Express API＋MySQL，JWT 登入，跑在 Ubuntu VPS 上，處理會員個資；或：我家的 Android App＋後端') }, ['target'], { perm: 'chat' }, (a) => Sec().recon(a.target));

  // ===== 26.11.3 Revise7 手機代理（管理員限定）：操作手機上的其他 App =====
  const PHA = { admin: true }; const Pa = () => { need(ctx.phoneagent, '手機代理沒有啟動'); return ctx.phoneagent; };
  const brief = async (pre) => { try { return `${pre}\n\n${Pa().fmt(await Pa().screen(), 70)}`; } catch (e) { return `${pre}（讀畫面失敗：${e.message}）`; } };
  def('phone_screen', '讀手機目前的畫面：哪個 App、所有可操作的元素（編號、按鈕／輸入框／文字）。操作前先讀；編號只在當下畫面有效。', {}, [], PHA, async () => Pa().fmt(await Pa().screen()));
  def('phone_screenshot', '截手機目前的畫面給你看（Android 11 以上）。元素文字讀不到（遊戲、影片、圖片按鈕）時用；之後可用 phone_tap 的 x,y（就是這張圖上的座標）點擊。', {}, [], PHA, async () => { const b = await Pa().shot(); const z = Pa().shotSize || {}; return { text: `手機截圖（${z.w || '?'}×${z.h || '?'}）。用 phone_tap x,y 點擊時直接用這張圖上的座標。`, images: [{ mime: 'image/jpeg', data: b.toString('base64') }] }; });
  def('phone_tap', '點擊手機畫面：id＝phone_screen 的編號（優先）｜text＝按鈕上的字｜x,y＝phone_screenshot 圖上的座標。long=true 長按。付款、刪除、安裝、授權、送出訊息這類按鈕會先跳確認給管理員。', { id: N('元素編號'), text: S('按鈕文字'), x: N('截圖上的 x'), y: N('截圖上的 y'), long: B('長按') }, [], PHA, async (a, tc) => { const w = await Pa().tap(a); aud(tc, 'phone.tap', String(w).slice(0, 60)); return brief(`已${a.long ? '長按' : '點擊'}「${w}」`); });
  def('phone_type', '在輸入框打字（id＝輸入框編號；不給就用目前焦點的輸入框）。submit=true 打完按 Enter 送出（送出前會先請管理員確認）。打字本身不會刷新畫面紀錄，送出才算一步。不能輸入密碼。', { id: N('輸入框編號'), text: S('要輸入的文字'), submit: B('打完送出'), clear: B('先清空，預設 true') }, ['text'], PHA, async (a, tc) => { await Pa().type(a); aud(tc, 'phone.type', a.submit ? 'submit' : 'type'); return brief(`已輸入${a.submit ? '並送出' : ''}`); });
  def('phone_swipe', '滑動畫面：direction＝up（往上滑，看下面的內容）｜down｜left｜right。', { direction: S('up|down|left|right') }, ['direction'], PHA, async (a) => { await Pa().swipe(a); return brief('已滑動'); });
  def('phone_key', '系統按鍵：back（返回）｜home（主畫面）｜recents（多工）｜notifications（通知欄）｜quick_settings｜enter。', { key: S('back|home|recents|notifications|quick_settings|enter') }, ['key'], PHA, async (a) => { await Pa().key(a.key); return brief('已按 ' + a.key); });
  def('phone_open_app', '用名稱開啟手機上的 App（例：YouTube、LINE、設定、相機、蝦皮）。', { name: S('App 名稱') }, ['name'], PHA, async (a, tc) => { const h = await Pa().openApp(a.name); aud(tc, 'phone.open', h.label); return brief(`已開啟 ${h.label}`); });
  def('phone_apps', '列出手機上可以開啟的 App。', {}, [], PHA, async () => (await Pa().apps()).map((x) => x.label).join('、') || '（讀不到）');
  def('phone_wait', '等畫面出現某段文字（最多 30 秒），例如等載入完成。', { text: S('要等的文字'), seconds: N('最多幾秒') }, ['text'], PHA, async (a) => brief((await Pa().waitText(a.text, a.seconds)) ? `畫面已出現「${a.text}」` : `等了仍沒出現「${a.text}」`));
  def('phone_autoclick', '連點器：在一個或多個位置依序重複點擊（例如每 0.2 秒點一次、共 100 下）。points＝[{id}] 或 [{x,y}]（截圖座標）；interval_ms ≥ 40；count 0＝不限（最長 max_s 秒，上限 3600）。管理員點懸浮球就會停。', { points: { type: 'array', description: '[{id}|{x,y}]', items: { type: 'object', properties: { id: N('元素編號'), x: N('x'), y: N('y') } } }, interval_ms: N('間隔毫秒'), count: N('次數，0＝不限'), max_s: N('最長秒數') }, ['points'], PHA, async (a, tc) => { const r = await Pa().autoclick(a); aud(tc, 'phone.autoclick', `${a.points.length} 點 ${a.interval_ms || 200}ms ×${a.count || '∞'}`); return `連點器已開始（${a.points.length} 個點）。${r.running ? '' : '（Android 端沒有回報執行中，請 phone_screenshot 確認）'}要停止就用 phone_autoclick_stop。`; });
  def('phone_macro', '巨集：照固定順序重複一串動作（遊戲刷關、收獎勵、固定流程），不看畫面、不花 token。action＝run（steps 或 name，repeat 次數，gap_ms 每步間隔）｜save（name＋steps）｜list｜delete（name）｜stop｜state。steps 一行一步：tap x y｜long x y｜swipe up/down/left/right｜swipe x1 y1 x2 y2 毫秒｜wait 毫秒｜key back。x,y 是螢幕座標（phone_screen 元素的位置；截圖座標要先換算）。點到付款、刪除這類按鈕會先跳確認。', { action: S('run|save|list|delete|stop|state'), name: S('巨集名稱'), steps: S('步驟（一行一步，或用 ; 分隔）'), repeat: N('重複幾次，預設 1'), gap_ms: N('每步間隔毫秒，預設 300') }, ['action'], PHA, async (a, tc) => {
    const A = Pa();
    if (a.action === 'run') { const r = await A.macroStart({ name: a.steps ? '' : a.name, steps: a.steps, repeat: a.repeat, gap_ms: a.gap_ms }); aud(tc, 'phone.macro', `${r.steps}x${r.repeat}`); return `巨集開始：${r.steps} 步 × ${r.repeat} 次（背景執行；phone_macro state 看進度、stop 停止）。`; }
    if (a.action === 'save') { const r = A.macroSave(a.name, a.steps); return `已存巨集「${r.name}」（${r.steps} 步）。`; }
    if (a.action === 'list') { const m = A.macros(); const k = Object.keys(m); return k.length ? k.map((n) => `${n}（${m[n].steps.length} 步）`).join('、') : '還沒有存任何巨集。'; }
    if (a.action === 'delete') { A.macroDelete(a.name); return '已刪除。'; }
    if (a.action === 'stop') { A.macroStop(); return '已要求停止。'; }
    if (a.action === 'state') { const s = A.macroState(); return s.running ? `執行中：第 ${s.round}／${s.repeat} 輪，已做 ${s.done} 個動作（${s.elapsed_s} 秒）` : s.last ? `沒有在跑。上次做了 ${s.last.done} 個動作${s.last.error ? '（' + s.last.error + '）' : s.last.stopped ? '（被停止）' : '（完成）'}` : '沒有在跑。'; }
    throw new Error('action：run｜save｜list｜delete｜stop｜state'); });
  def('phone_autoclick_stop', '停止連點器。', {}, [], PHA, async () => { const r = await Pa().clickerStop(); return `已停止，共點了 ${r.done} 下。`; });

  // ===== 26.11.3 Revise6 會議監聽（管理員限定：要進語音頻道錄音、讀別人說的話）=====
  const MG = { admin: true };
  const Mt = () => { need(ctx.meeting, '會議監聽功能沒有啟動'); return ctx.meeting; };
  def('meeting_list', '列出會議記錄（App 錄的與 Discord 語音頻道監聽的），含狀態與摘要開頭。', {}, [], MG, () => { const l = Mt().list(); return l.length ? l.slice(0, 20).map((m) => `${m.id}｜${m.title}｜${{ live: '記錄中', processing: '整理中', done: '完成', interrupted: '中斷' }[m.status] || m.status}｜${m.source === 'discord' ? 'Discord「' + m.channel + '」' : 'App'}｜${m.segments} 段${m.summary ? '｜' + m.summary : ''}`).join('\n') : '（還沒有會議記錄）'; });
  def('meeting_read', '讀一場會議：part=notes（摘要、重點、決議、待辦）｜transcript（逐字稿）｜all。id 不給就讀最新一場。', { id: S('會議編號（meeting_list 看）'), part: S('notes|transcript|all') }, [], MG, (a) => {
    const id = a.id || (Mt().list()[0] || {}).id; need(id, '還沒有會議記錄'); const m = Mt().get(id); const part = a.part || 'notes';
    if (part === 'transcript') return Mt().transcript(m).slice(-12000) || '（還沒有逐字稿）'; return Mt().markdown(m, { transcript: part === 'all' }).slice(0, 14000); });
  def('meeting_discord_listen', '讓 Bot 進入 Discord 語音頻道監聽整場會議：自動轉文字、依講者整理重點，結束時把會議記錄貼回原本的文字頻道並通知管理員。channel＝語音頻道名稱或 ID。', { channel: S('語音頻道名稱或 ID'), title: S('會議標題（選填，不給會依內容自動取）') }, ['channel'], MG, async (a, tc) => {
    const msg = tc.msg || {}; let guild = ''; const d = ctx.hub && ctx.hub.connectors && ctx.hub.connectors.discord;
    if (msg.platform === 'discord' && d && msg.chatId) { try { guild = await d.guildOf(msg.chatId); } catch { /* 找全部伺服器 */ } }
    const m = await ctx.dvoice.joinAndListen({ channel: a.channel, guild_id: guild, title: a.title || '', by: tc.person.name || tc.person.id, reply_channel: msg.platform === 'discord' ? msg.chatId : '' });
    aud(tc, 'meeting.discord', `${m.discord.channel_name}`); return `已進入語音頻道「${m.discord.channel_name}」開始記錄（會議 ${m.id}）。每多一段發言會自動整理重點；要結束就叫 meeting_stop。結束後會議記錄會${msg.platform === 'discord' ? '貼回這個頻道' : '通知管理員'}。`; });
  def('meeting_stop', '結束一場正在記錄的會議（Discord 的會離開語音頻道），整理出完整會議記錄。id 不給就結束最新一場進行中的。', { id: S('會議編號') }, [], MG, async (a, tc) => {
    const id = a.id || (Mt().list().find((m) => m.status === 'live') || {}).id; need(id, '目前沒有進行中的會議'); const m = await Mt().stop(id, { reason: '管理員要求結束' }); aud(tc, 'meeting.stop', m.title);
    return Mt().markdown(m, { transcript: false }).slice(0, 6000); });
  def('meeting_export', '把會議記錄做成檔案傳給使用者（docx／pdf／md），可選要不要附逐字稿。', { id: S('會議編號（不給＝最新）'), format: S('docx|pdf|md'), transcript: B('附逐字稿，預設 true') }, [], MG, async (a, tc) => {
    const id = a.id || (Mt().list()[0] || {}).id; need(id, '還沒有會議記錄'); const m = Mt().get(id);
    const rec = await ctx.filegen.make({ name: m.title, format: ['docx', 'pdf', 'md'].includes(a.format) ? a.format : 'docx', content: Mt().markdown(m, { transcript: a.transcript !== false }) }, tc.person.id); if (tc.files) tc.files.push(rec); aud(tc, 'meeting.export', rec.name);
    return `已產生「${rec.name}」，回覆後會自動傳給使用者。`; });
  def('make_file', '產生檔案並直接傳給使用者（App 對話可下載；Telegram／Discord 直接上傳；LINE 傳下載連結）。格式：docx（Word 報告）、xlsx（Excel，給 rows）、pdf、csv、md、txt、html、json、tex（LaTeX 原始檔，可貼到 Overleaf 用 XeLaTeX 編譯）。content 用類 Markdown：# 標題、- 條列、| 表格 |、**粗體**；數學公式寫 LaTeX：$行內$、$$獨立一行$$（html／pdf 會排版成公式，tex 原樣保留）。使用者說「做成檔案／給我 Word／匯出 Excel／整理成報告」時用；內容要先用工具查好、算好再寫。',
  { format: S('docx|xlsx|pdf|csv|md|txt|html|json'), name: S('檔名（不含副檔名）'), title: S('標題'), content: S('內文（類 Markdown）'), rows: { type: 'array', description: '表格資料（二維陣列，第一列是欄名）；xlsx／csv 用', items: { type: 'array', items: { type: 'string' } } } }, ['format'], { perm: 'chat' }, async (a, tc) => {
    const rec = await ctx.filegen.make(a, tc.person.id); if (tc.files) tc.files.push(rec); aud(tc, 'file.make', rec.name);
    return `已產生「${rec.name}」（${Math.max(1, Math.round(rec.size / 1024))} KB），回覆後會自動傳給使用者。回覆時簡單說明檔案內容即可，不用貼網址。`;
  });
  def('send_file', '把工作區裡已經存在的檔案傳給使用者（例如 sheet_export 匯出的 xlsx、file_write 寫好的檔案）。', { path: S('工作區內的路徑，例如 exports/記帳表.xlsx') }, ['path'], { perm: 'files' }, async (a, tc) => {
    const full = ctx.fsx.resolve(a.path, 'workspace'); need(require('fs').existsSync(full), '找不到這個檔案'); const buf = require('fs').readFileSync(full); need(buf.length <= 20 * 1024 * 1024, '檔案超過 20MB');
    const name = require('path').basename(full); const ext = name.split('.').pop().toLowerCase(); const rel = require('path').relative(ctx.paths.workspace, full).split(require('path').sep).join('/');
    const rec = { id: require('../core/util').rid(8), name, path: rel, mime: require('../services/filegen').MIME[ext] || require('../platforms/common').mimeOf(name), size: buf.length, at: Date.now(), owner: tc.person.id };
    ctx.filegen.list.push(rec); ctx.store.touch(); if (tc.files) tc.files.push(rec); return `會把「${name}」傳給使用者。`;
  });

  // ---------------- 群組統計 ----------------
  def('group_note', '這個群組的備忘（群組固定資訊：用途、預算、規則、聚餐時間…），存了之後在這個群組回話會自動參考。只有管理員能新增／刪除；大家都能看。', {
    action: { type: 'string', enum: ['add', 'list', 'remove'], description: 'add 新增／list 列出／remove 刪除' }, text: { type: 'string', description: 'add 時的內容' }, id: { type: 'string', description: 'remove 時的編號' },
  }, ['action'], { perm: 'chat' }, async (a, tc) => {
    if (!tc.group || !tc.msg) throw new Error('這要在群組裡用'); const key = `${tc.msg.platform}:${tc.msg.chatId}`; const db = tc.ctx.store.db; db.group_notes = db.group_notes || {}; const list = db.group_notes[key] = db.group_notes[key] || [];
    if (a.action === 'list') return list.length ? list.map((n) => `#${n.id} ${n.text}`).join('\n') : '這個群組還沒有備忘。';
    if (!tc.person || tc.person.role !== 'admin') throw new Error('只有管理員能修改群組備忘（永遠只聽管理員的）');
    if (a.action === 'add') { const text = String(a.text || '').trim().slice(0, 300); if (!text) throw new Error('缺少內容'); const id = String((list.reduce((m, n) => Math.max(m, +n.id || 0), 0)) + 1); list.push({ id, text, by: tc.person.id, at: Date.now() }); if (list.length > 50) list.shift(); tc.ctx.store.touch(); return `記下了（#${id}）：${text}`; }
    const i = list.findIndex((n) => n.id === String(a.id || '').replace('#', '')); if (i < 0) throw new Error('找不到這個編號（先 list）'); const [r] = list.splice(i, 1); tc.ctx.store.touch(); return `已刪除 #${r.id}：${r.text}`;
  });
  def('group_collect', '讀取「目前這個群組」從某個時間點起的所有發言（含沒有 @你 的），用來統計：誰要訂什麼飲料／便當、甜度冰塊大小、投票結果、誰還沒回。since 可給 HH:mm、「30分鐘」或訊息編號；keyword 可只看相關的。拿到後逐人整理（同一人改單以最後一次為準）、列出每人內容與數量、加總金額，最後列出還沒回覆的成員。管理員可指定其他群組 chat。', { since: S('起點：HH:mm、N分鐘、N小時、#訊息編號；預設 3 小時'), keyword: S('只看含這些字的訊息（選填，用空白分隔）'), chat: S('管理員專用：其他群組名稱或 id') }, [], { perm: 'chat' }, (a, tc) => {
    let c = null; const chats = Object.values(ctx.store.db.chats || {});
    if (a.chat && tc.person.role === 'admin') c = chats.find((x) => x.chatId === a.chat || x.name === a.chat || (x.name || '').includes(a.chat));
    else { need(tc.group && tc.msg && tc.msg.chatId, '這個功能要在群組裡用（管理員可指定 chat）'); c = (ctx.store.db.chats || {})[`${tc.msg.platform}:${tc.msg.chatId}`]; }
    need(c, '找不到這個群組的紀錄');
    const scope = `chat_${c.platform}_${c.chatId}`; const now = Date.now(); let since = now - 3 * 3600e3; const sv = String(a.since || '').trim(); let fromMid = null;
    let m; if ((m = /^(\d{1,2})[:：](\d{2})$/.exec(sv))) { const z = zoned(now, ctx.settings.get('tz')); since = require('../core/util').fromZoned(z.y, z.m, z.d, +m[1], +m[2], ctx.settings.get('tz')); if (since > now) since -= 86400e3; }
    else if ((m = /^(\d+)\s*(分|分鐘|min)/.exec(sv))) since = now - +m[1] * 60e3; else if ((m = /^(\d+)\s*(小時|h)/.exec(sv))) since = now - +m[1] * 3600e3; else if ((m = /^#?(\w{3,})$/.exec(sv))) fromMid = m[1];
    let rows = ctx.store.page(scope, Infinity, 600); if (fromMid) { const i = rows.findIndex((r) => String(r.mid) === fromMid); rows = i >= 0 ? rows.slice(i) : rows.filter((r) => r.ts >= since); } else rows = rows.filter((r) => r.ts >= since);
    const kws = String(a.keyword || '').split(/\s+/).filter(Boolean); if (kws.length) rows = rows.filter((r) => kws.some((k) => String(r.text || '').includes(k)));
    const members = Object.entries(c.members || {}).map(([, n]) => n).filter(Boolean);
    const said = new Set(rows.filter((r) => r.role !== 'assistant').map((r) => r.name)); const silent = members.filter((n) => !said.has(n));
    return `群組「${c.name || c.chatId}」${rows.length} 則（${new Date(rows.length ? rows[0].ts : since).toLocaleString('zh-TW', { hour12: false, timeZone: ctx.settings.get('tz') })} 起）：\n` + rows.map((r) => `[${zoned(r.ts, ctx.settings.get('tz')).time}] ${r.role === 'assistant' ? 'AI' : (r.name || r.uid)}：${String(r.text || '').slice(0, 300)}`).join('\n') + `\n\n這段時間沒發言的成員：${silent.join('、') || '（無）'}`;
  });
  def('usage_limit', '管理員設定某人可以找你幾次（例：「小明每天只能叫你 5 次」「阿華這小時 2 次」「取消小明的限制」），或查看大家的次數限制與剩餘。用完後系統直接擋下、不呼叫模型。管理員不受限制。', { person: S('名稱或 id'), limit: N('次數；0＝取消限制'), per: S('day 每天｜hour 每小時｜week 每週｜total 總共'), action: S('set｜list') }, [], { admin: true }, (a, tc) => {
    if (a.action === 'list' || !a.person) return ctx.users.list().filter((p) => p.quota && p.quota.limit).map((p) => `${p.name || p.id}：${{ day: '每天', hour: '每小時', week: '每週', total: '總共' }[p.quota.per] || '每天'} ${p.quota.limit} 次，剩 ${ctx.users.quotaLeft(p)} 次`).join('\n') || '目前沒有人有次數限制';
    const p = ctx.users.find(a.person); need(p, '找不到這個人'); need(p.role !== 'admin', '管理員不受次數限制');
    if (!a.limit) { delete p.quota; ctx.store.touch(); aud(tc, 'quota.off', p.id); return `已取消 ${p.name || p.id} 的次數限制。`; }
    const per = ['day', 'hour', 'week', 'total'].includes(a.per) ? a.per : 'day'; p.quota = { limit: Math.max(1, Math.round(a.limit)), per, used: 0, window: ctx.users.quotaWindow(per) }; ctx.store.touch(); aud(tc, 'quota.set', `${p.id} ${per} ${p.quota.limit}`);
    return `好，${p.name || p.id} ${{ day: '每天', hour: '每小時', week: '每週', total: '總共' }[per]}可以找我 ${p.quota.limit} 次（從現在開始算）。用完我會自動婉拒，不會再花模型費用。`;
  });

  // ---------------- 完整操作 App ----------------
  const APP_DENY = [/^POST \/api\/phone\/(confirm|settings|task|stop)/, /^POST \/api\/settings$/, /^\w+ \/api\/google\/(config|auth|refresh|service|disconnect|form-cookie)/, /^\w+ \/api\/termux\/(config|register)/, /^\w+ \/api\/model-(keys|select|order)/, /^\w+ \/api\/dev\//, /^\w+ \/api\/debug\/eval/, /^\w+ \/api\/vault/, /^(POST|DELETE|PUT) \/api\/users/, /^\w+ \/api\/roles/, /^POST \/api\/approvals\//, /^POST \/api\/linux\/reset/, /^\w+ \/api\/connectors\//, /^\w+ \/api\/term\//, /^POST \/api\/(chat|services\/run)$/, /^POST \/api\/browser\/(input|takeover|giveback)/, /^POST \/api\/link/, /^\w+ \/api\/mcp\/oauth/, /^\w+ \/api\/transfer/, /^\w+ \/api\/link/, /^\w+ \/api\/deploy/, /^\w+ \/api\/transit\/config/];
  def('app_api', '直接操作 App（和管理員在畫面上按按鈕是同一套 API）：查狀態、啟停 Bot、穿透、排程、哨兵、簡報、檔案、試算表、記帳表、群發、通知、備份、內建 Linux、瀏覽器啟動、MCP 重新載入…。先用 action=list 看有哪些 API，再用 method＋path（＋body）呼叫；看不懂某個畫面的功能先讀 app_manual。密碼／金鑰／帳號授權、改權限與角色、審批決定這些不能用這個工具（改權限用 permission_change，審批要管理員自己說）。', { action: S('list｜call'), method: S('GET｜POST｜DELETE｜PUT'), path: S('例如 /api/status、/api/watch'), body: S('POST 的 JSON 內容（字串）') }, ['action'], { admin: true }, async (a, tc) => {
    if (a.action === 'list') return ctx.api.routeList().filter((r) => !APP_DENY.some((re) => re.test(r))).join('\n');
    const method = String(a.method || 'GET').toUpperCase(); const p = String(a.path || ''); need(/^\/api\//.test(p), 'path 要以 /api/ 開頭');
    need(!APP_DENY.some((re) => re.test(`${method} ${p.split('?')[0]}`)), '這個操作涉及密碼、金鑰、授權、權限或審批，不能由 AI 透過 app_api 執行（改權限用 permission_change；其餘請管理員在 App 內操作）');
    let body = {}; if (a.body) { try { body = typeof a.body === 'string' ? JSON.parse(a.body) : a.body; } catch { throw new Error('body 不是合法 JSON'); } }
    aud(tc, 'app_api', `${method} ${p}`); const r = await ctx.api.invoke(method, p, body);
    return typeof r === 'string' ? r : JSON.stringify(r, null, 1).slice(0, 8000);
  });

  // ---------------- 自我說明：我有哪些工具／MCP／技能、怎麼用 ----------------
  def('how_to', '查「你自己」的能力與用法：工具（含參數）、已連結的 MCP 連接器與它們的工具、已存技能、App 操作手冊。不確定某件事能不能做、該用哪個工具、參數怎麼填時先查。query 留空＝總覽。', { query: S('要找的能力，例如「刪記帳」「產生 Word」「Notion」「群組統計」') }, [], { perm: 'chat' }, (a, tc) => {
    const allowed = ctx.tools.forPerson(tc.person, !!tc.group); const R = ctx.router; const G = require('./router').GROUPS;
    const q = String(a.query || '').trim().toLowerCase();
    if (!q) {
      const groups = Object.entries(G).map(([k, g]) => { const ns = allowed.filter((t) => g.names.includes(t.name)).map((t) => t.name); return ns.length ? `【${k}】${g.desc}：${ns.join('、')}` : ''; }).filter(Boolean);
      const mcp = [...new Set(allowed.filter((t) => t.mcp).map((t) => t.name.split('__')[1]))].map((s) => `【mcp:${s}】${ctx.connectors ? ctx.connectors.label(s) : s}：${allowed.filter((t) => t.mcp && t.name.split('__')[1] === s).map((t) => t.name.split('__').slice(2).join('__')).join('、')}`);
      const sk = ctx.skills ? ctx.skills.index() : '';
      return ['你目前可用的能力（不在這一輪工具清單的，用 use_tools 載入那一組）：', ...groups, ...mcp, sk ? '【技能】\n' + sk : '【技能】（尚無）', '想知道某個工具的參數：how_to 帶工具名或關鍵字。操作 App 畫面：app_api（action=list）。'].join('\n');
    }
    // 口語查詢也要找得到：整詞、中文兩字片段、所屬工具組（同 router 的關鍵字）、動詞對應（刪→delete…）
    const words = q.split(/\s+/).filter(Boolean); const cjk = q.replace(/[^\u4e00-\u9fff]/g, ''); const bi = []; for (let k = 0; k + 1 < cjk.length; k++) bi.push(cjk.slice(k, k + 2));
    const VERB = [[/刪|移除|清掉|清空|拿掉/, /delete|remove|clear/], [/復原|救回|刪錯/, /restore|undo/], [/新增|加入|記一筆|記帳|建立/, /add|create|new/], [/改|修改|更正|編輯/, /update|edit|set/], [/查|看|列出|找/, /query|list|search|get|read/], [/傳|寄|送/, /send|mail|push/], [/產生|做成|做一份|匯出|轉成|word|pdf|excel/i, /make_file|export/], [/統計|誰要|喊單|點餐|投票/, /group_collect|stats/], [/次數|幾次|限制/, /usage_limit/]];
    const verbs = VERB.filter(([zh]) => zh.test(q)).map(([, en]) => en); const grp = Object.entries(G).filter(([, g]) => g.re && g.re.test(q)).map(([k]) => k);
    const score = (t) => { const n = t.name.toLowerCase(); const d = String(t.description).toLowerCase(); let s = words.reduce((x, w) => x + (n.includes(w) ? 3 : 0) + (d.includes(w) ? 1 : 0), 0);
      s += bi.filter((b) => d.includes(b)).length * 0.5; if (grp.includes(R.groupOf(t.name))) s += 2; s += verbs.filter((re) => re.test(n)).length * 3; return s >= 2.5 ? s : 0; };
    const hits = allowed.map((t) => ({ t, s: score(t) })).filter((x) => x.s > 0).sort((x, y) => y.s - x.s).slice(0, 6);
    const fmt = ({ t }) => `● ${t.name}（${R.groupOf(t.name)}）：${String(t.description).slice(0, 500)}\n  參數：${Object.entries((t.parameters && t.parameters.properties) || {}).map(([k, v]) => `${k}${((t.parameters.required || []).includes(k)) ? '*' : ''}＝${(v.description || v.type || '').slice(0, 80)}`).join('；') || '無'}`;
    const guide = (() => { try { const g = require('fs').readFileSync(require('path').join(__dirname, '..', '..', 'knowledge', 'app-guide.md'), 'utf8'); return g.split(/\n(?=## )/).filter((sec) => words.some((w) => sec.toLowerCase().includes(w))).slice(0, 2).map((sec) => sec.slice(0, 900)).join('\n'); } catch { return ''; } })();
    const sk = ctx.skills ? ctx.skills.index().split('\n').filter((l) => words.some((w) => l.toLowerCase().includes(w))).join('\n') : '';
    return [hits.length ? hits.map(fmt).join('\n') : '沒有直接相符的工具。', sk ? '相關技能：\n' + sk : '', guide ? 'App 手冊相關段落：\n' + guide : ''].filter(Boolean).join('\n\n');
  });

  // ---------------- 電子發票 ----------------
  def('einvoice_record', '用台灣電子發票 QR Code 的文字直接記帳（左碼以兩個英文字母＋8 位數字開頭；右碼以 ** 開頭，可一起給）。會解析日期、總金額、品項，同一張發票不會重複記。使用者貼上發票 QR 內容或掃描結果時用；發票「照片」則自己看圖後用 ledger_add。', { qr: ARR('QR Code 文字（左碼，必要時加右碼）'), for_person: S('管理員專用：幫誰記') }, ['qr'], { perm: 'ledger' }, (a, tc) => {
    let o = tc.person.id; if (a.for_person && tc.person.role === 'admin') { const p = ctx.users.find(a.for_person); need(p, '找不到使用者'); o = p.id; }
    return ctx.einvoice.record(a.qr, o).text;
  });
  // ---------------- 內建 Linux ----------------
  def('linux_env', 'App 內建 Linux（PRoot＋Alpine，不需 Termux App）的狀態與管理。action：status｜install（安裝基本環境：node、python、git…，背景進行，幾分鐘）｜install_chromium（加裝 Chromium）｜start｜stop。裝好後用 termux_exec／termux_file／termux_chromium 操作（工具名稱沿用）。', { action: S('status|install|install_chromium|start|stop') }, ['action'], { admin: true }, async (a, tc) => {
    const L = ctx.linux; const st = () => { const x = L.state(); return `內建 Linux：${x.supported ? '此 App 版本支援' : '此 App 版本沒有內建 PRoot（要用新版 APK）'}｜${x.installed ? `已安裝 Alpine ${x.version}${x.chromium ? '＋Chromium' : ''}` : '尚未安裝'}｜橋接 ${x.bridge.running ? '執行中' : '未執行'}${x.job ? `｜工作：${x.job.phase}（${x.job.step}/${x.job.steps}）${x.job.running ? '進行中' : x.job.ok ? '完成' : '失敗：' + x.job.error}` : ''}\n${x.log.slice(-8).join('\n')}`; };
    if (a.action === 'status') return st();
    if (a.action === 'install' || a.action === 'install_chromium') { need(L.supported(), '這個 App 版本沒有內建 PRoot，請管理員更新 APK'); need(!(L.job && L.job.running), '已經在安裝中'); aud(tc, 'linux.install', a.action); L.install({ chromium: a.action === 'install_chromium' }).catch(() => {}); return '已開始在背景安裝（需要網路，約 3–10 分鐘；Chromium 再多幾分鐘）。稍後用 linux_env status 看進度。'; }
    if (a.action === 'start') { ctx.settings.set('termux.mode', 'embedded', 'human'); await L.start(); return st(); }
    if (a.action === 'stop') { await L.stop(); return st(); }
    throw new Error('不支援的 action');
  });
};
