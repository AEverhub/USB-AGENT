'use strict';
/** 連接器（MCP）管理：目錄＋自訂；按「連結」→ 免登入直接接上／OAuth 開登入頁／API Key 加密保存。 */
const { CATALOG } = require('./mcp-catalog');

const SAFE = /^[a-z0-9_-]{2,32}$/;
class Connectors {
  constructor(ctx) { this.ctx = ctx; }
  servers() { return this.ctx.settings.get('mcp.servers', []) || []; }
  label(name) { const c = CATALOG.find((x) => x.id === name); const s = this.servers().find((x) => x.name === name); return (c && c.name) || (s && s.label) || name; }
  /** 確保設定裡有這個伺服器（OAuth／Key 由 McpAuth 提供 token，設定裡不存任何機密） */
  ensureServer(name, extra = {}) {
    const list = this.servers().slice(); const c = CATALOG.find((x) => x.id === name); const i = list.findIndex((x) => x.name === name);
    const pending = (this._custom || {})[name] || {};
    const def = { name, url: extra.url || pending.url || (c && c.url) || (i >= 0 && list[i].url), label: extra.label || pending.label || (c && c.name) || name, enabled: true, ...(extra.oauth !== false && (extra.oauth || pending.oauth || (c && c.auth !== 'open')) ? { oauth: true } : {}), ...((extra.key_header || (c && c.key_header)) ? { key_header: extra.key_header || c.key_header } : {}) };
    if (!def.url) throw new Error('沒有網址');
    if (i >= 0) list[i] = { ...list[i], ...def }; else list.push(def);
    this.ctx.settings.set('mcp.servers', list, 'human'); return def;
  }
  state() {
    const S = this.servers(); const M = this.ctx.mcp; const A = this.ctx.mcpauth;
    const row = (name, base) => { const s = S.find((x) => x.name === name); const a = A.status(name); return { ...base, installed: !!s, enabled: !!(s && s.enabled !== false), connected: !!s && (base.auth === 'open' || a.connected) && !M.errors[name], tools: (M.counts || {})[name] || 0, error: s ? M.errors[name] || '' : '', login: a.connected }; };
    const catalog = CATALOG.map((c) => (c.auth === 'builtin' ? { ...c, installed: true, enabled: true, connected: !!(this.ctx.gws && this.ctx.gws.ready()), tools: this.ctx.gws && this.ctx.gws.ready() ? this.ctx.tools.defs.filter((d) => require('./router').GROUPS.google.names.includes(d.name)).length : 0, error: '', login: !!(this.ctx.gws && this.ctx.gws.ready()) } : row(c.id, c)));
    const custom = S.filter((s) => !CATALOG.find((c) => c.id === s.name)).map((s) => row(s.name, { id: s.name, name: s.label || s.name, icon: s.command ? '🖥️' : '🔌', cat: '自訂', url: s.url || `${s.command} ${(s.args || []).join(' ')}`, auth: s.command ? 'local' : s.oauth ? 'oauth' : 'open', desc: s.command ? '本機程式（stdio）' : '自訂伺服器', custom: true }));
    return { catalog, custom };
  }
  /** 連結：回傳 {done:true} 或 {auth_url} */
  /** redirect：{origin, port}（App 網址；Google 這類要求 localhost 的用 http://localhost:埠） */
  async connect(o, redirectUri, { port } = {}) {
    let { id, name, url, auth, key, client_id: clientId, client_secret: clientSecret, scope, label } = o || {};
    const c = id && CATALOG.find((x) => x.id === id);
    if (c && c.auth === 'builtin') return { go: 'browser', message: '內建 Google 通道在「瀏覽器」頁的 Google 卡片設定（一次授權即可）' };
    let extra = {};
    if (c) {
      name = c.id; url = c.url; auth = c.auth; label = c.name;
      if (c.oauth_client === 'google') {
        const S = this.ctx.settings; clientId = clientId || S.get('google.client_id'); clientSecret = clientSecret || S.get('google.client_secret');
        if (!clientId || !clientSecret) throw new Error('Google 的 MCP 需要你自己的 OAuth 用戶端：到 Google Cloud 建立「網頁應用程式」類型的 OAuth Client（勾選給 AI agent 使用）、啟用對應的 API 與 MCP 服務、重新導向 URI 加上 http://localhost:' + (port || 8765) + '/api/mcp/oauth/callback，再把 Client ID／Secret 填到「瀏覽器」頁的 Google 卡片。');
        if (c.redirect_host === 'localhost' && port) redirectUri = `http://localhost:${port}/api/mcp/oauth/callback`;
        extra = { meta: { issuer: 'https://accounts.google.com', authorization_endpoint: 'https://accounts.google.com/o/oauth2/v2/auth', token_endpoint: 'https://oauth2.googleapis.com/token' }, scope: (c.scopes || []).join(' '), extraParams: c.extra_auth || {}, noResource: !!c.no_resource };
      }
    }
    else {
      name = String(name || id || '').toLowerCase().trim(); if (!SAFE.test(name)) throw new Error('名稱只能用英文小寫、數字、- 或 _（2–32 字）');
      url = String(url || '').trim(); if (!/^https:\/\//i.test(url) && !/^http:\/\/(127\.0\.0\.1|localhost)(:\d+)?\//i.test(url)) throw new Error('網址必須是 https:// 開頭（本機服務可用 http://127.0.0.1）'); auth = ['oauth', 'open', 'key'].includes(auth) ? auth : 'oauth';
      this._custom = { ...(this._custom || {}), [name]: { url, label: label || name, oauth: auth !== 'open' } };
    }
    if (auth === 'open') { this.ensureServer(name, { url, label, oauth: false }); await this.ctx.mcp.reload(); return this.result(name); }
    if (auth === 'key') {
      key = String(key || '').trim(); if (key.length < 8) throw new Error('請貼上 API Key');
      this.ctx.mcpauth._put(name, { url, client: {}, meta: {}, created: Date.now(), tokens: { access_token: key, expires_at: 0, refresh_token: '' } });
      this.ensureServer(name, { url, label, oauth: true, key_header: (c && c.key_header) || o.key_header || '' }); await this.ctx.mcp.reload(); return this.result(name);
    }
    const r = await this.ctx.mcpauth.start({ name, url, redirectUri, clientId, clientSecret, scope: extra.scope || scope, meta: extra.meta || null, extraParams: extra.extraParams || {}, noResource: !!extra.noResource });
    if (r.open) { this.ensureServer(name, { url, label, oauth: false }); await this.ctx.mcp.reload(); return this.result(name); }
    return { auth_url: r.auth_url };
  }
  result(name) { const err = this.ctx.mcp.errors[name]; if (err) throw new Error(`${this.label(name)} 連不上：${err}`); return { done: true, name, tools: (this.ctx.mcp.counts || {})[name] || 0 }; }
  async disconnect(name) {
    this.ctx.settings.set('mcp.servers', this.servers().filter((x) => x.name !== name), 'human'); this.ctx.mcpauth.remove(name); await this.ctx.mcp.reload(); return true;
  }
}
module.exports = { Connectors };
