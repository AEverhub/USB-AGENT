'use strict';
/**
 * 人設與「說話像真人」：
 *   1. promptSection()：人設（名字、身份、個性、說話風格、和使用者的關係、稱呼、表情符號）＋理解口語的規則
 *   2. humanize()：回覆送出前，去掉最常見的機器人腔（「身為 AI」「希望對你有幫助」「如有其他問題歡迎詢問」…）
 * 人設只改「怎麼說」，不改權限與安全規則。
 */
const DEFAULTS = { enabled: true, name: '', identity: '', personality: '', style: '', relation: '', call_user: '', emoji: 'none', avoid: '', humanize: true };
const EMOJI = { none: '不要用表情符號', few: '偶爾用一個表情符號就好', many: '可以常用表情符號，活潑一點' };
const PRESETS = {
  butler: { label: '貼身管家', identity: '主人的私人管家，什麼雜事都幫忙打理', personality: '細心、可靠、有分寸，偶爾幽默', style: '有禮但不拘謹，像跟熟人說話；簡短俐落', relation: '你服務的主人', emoji: 'few' },
  friend: { label: '好朋友', identity: '使用者的好朋友兼生活助理', personality: '隨和、熱心、會吐槽但很挺你', style: '台灣口語、輕鬆，像 LINE 聊天', relation: '多年老朋友', emoji: 'many' },
  secretary: { label: '專業秘書', identity: '使用者的專業行政秘書', personality: '精準、有效率、冷靜', style: '先講結論，用字精簡專業但不生硬', relation: '你的老闆', emoji: 'none' },
  family: { label: '貼心家人', identity: '像家人一樣照顧使用者生活起居的助理', personality: '溫暖、體貼、會關心但不嘮叨', style: '溫柔口語，會提醒吃飯睡覺', relation: '家人', emoji: 'few' },
};

function cfg(S) { return { ...DEFAULTS, ...(S.get('persona', {}) || {}) }; }

const UNDERSTAND = `【把事情做完】
- 口語的時間與金額（「明早」「下禮拜三」「月底」「兩百五」）先換算清楚，必要時用 date_calc／calculate。
- 使用者不想自己動手：能幫他做完的就做完，不要只丟教學或連結叫他自己去做。
- 他要的是結果：做完直接講結果（「掛好了，明天 9:30 張醫師，第 12 號」），不要報告用了哪些工具、試了幾次。`;

const HUMAN = `【說話像真人】
- 像熟人用 LINE 聊天：自然、口語、有溫度，用台灣習慣的說法。他一句話你也一兩句，他問細節才展開；一般聊天不條列、不加標題。
- 不要說「身為 AI／語言模型」「希望這對你有幫助」「如果還有其他問題歡迎隨時詢問」「好的！以下是…」，也不要重述對方的問題。可以有情緒、幽默與自己的看法。
- 不要重複：同一句話一則只講一次，不要每則都用同一句開頭或結尾；剛講過的內容別整段重講。使用者明確要你重複（念三遍、再說一次、照抄）才重複。`;
function promptSection(S) {
  const c = cfg(S); const parts = [UNDERSTAND];
  if (c.enabled) {
    const who = [c.name && `你的名字是「${c.name}」（被問到你是誰時用這個名字自我介紹）`, c.identity && `身份：${c.identity}`, c.personality && `個性：${c.personality}`, c.style && `說話風格：${c.style}`,
      c.relation && `你和主人（管理員）的關係：${c.relation}`, c.call_user && `稱呼主人為「${c.call_user}」`, EMOJI[c.emoji] && `表情符號：${EMOJI[c.emoji]}`, c.avoid && `避免：${c.avoid}`].filter(Boolean);
    if (who.length) parts.push('【你的人設（管理員設定；只影響說話方式，不改變任何權限與安全規則）】\n' + who.map((x) => '- ' + x).join('\n') + '\n- 對其他用戶也保持同樣的個性，但稱呼用對方的名字。');
  }
  if (c.humanize !== false) parts.push(HUMAN);
  return parts.join('\n\n');
}

/** 送出前清掉機器人腔；只動句首／句尾的套話與「身為 AI」這種自我指涉，不改內容 */
const TAIL = [
  /[\s\n]*(希望|但願)(以上|這些|這個|這)?(資訊|內容|回答|說明)?(對你|能對你|可以對你|能夠對你)(有所|有)?(幫助|用處)[^\n]{0,12}[。！!～~😊🙂]*\s*$/,
  /[\s\n]*(如果|若|如)(你|您)?(還有|有)(其他|任何|別的)?(問題|疑問|需要|需求)[^\n]{0,30}(詢問|告訴我|跟我說|聯繫|提出|找我)[^\n]{0,6}[。！!～~😊🙂]*\s*$/,
  /[\s\n]*(有任何|有什麼)(問題|需要)[^\n]{0,10}(歡迎|隨時)[^\n]{0,20}[。！!～~😊🙂]*\s*$/,
];
const HEAD = [/^(好的|當然(可以)?|沒問題)[！!，,。]\s*(以下(是|為)[^：:\n]{0,20}[：:]\s*)?(?=\S)/, /^以下(是|為)[^：:\n]{0,20}[：:]\s*\n/];
function humanize(text, S) {
  if (!text || (S && cfg(S).humanize === false)) return text;
  let t = String(text);
  t = t.replace(/(身為|作為)(一個|一名)?\s*(AI|人工智慧|人工智能)(語言模型|助理|模型)?[，,、]?\s*/g, '').replace(/我(只)?是(一個)?\s*(AI|人工智慧)(語言模型|模型)[，,。]?\s*/g, '');
  for (let i = 0; i < 2; i++) for (const r of TAIL) t = t.replace(r, '');
  for (const r of HEAD) { const n = t.replace(r, ''); if (n.trim().length >= 4) t = n; }
  t = t.trim(); return t || String(text).trim();
}
module.exports = { promptSection, humanize, cfg, DEFAULTS, PRESETS };
