'use strict';
/**
 * 26.11.3 pro10 模糊需求：使用者講得很省略（「那個弄一下」「跟上次一樣」「幫我處理」「隨便」）時，
 *  ・detect()：判斷這句話缺了什麼（指的是誰／什麼、要做什麼動作、範圍或條件）
 *  ・做法的提示在 playbooks.js 的 vague 劇本（只在這種時候才放，省 token）
 *  ・openQuestion()：回覆如果只是丟一個開放式反問（「你是指什麼？」）而沒有先試著推斷，自我檢查會請它重來
 */
const REF = /那個|這個|那件|這件|那邊|那家|那間|那位|那封|那份|那張|那支|那台|它|這樣|那樣|上次|上回|剛剛|剛才|之前|先前|昨天那|老樣子|照舊|照之前|同上|一樣的|跟.{0,6}一樣|再來一(次|個|份)|再一次|繼續|接著|還有呢|然後呢|另外那/;
const VERB = /弄一下|弄好|處理一下|處理掉|搞定|喬一下|用一下|看一下|看看|幫我看|檢查一下|改一下|修一下|調一下|整理一下|想辦法|解決|優化|加強|弄漂亮|好看一點|好一點|快一點|簡單一點|專業一點|怎麼辦|怎麼弄|怎麼用|可以嗎|行不行/;
const OPEN = /隨便|都可以|都行|你決定|你看著辦|看著辦|你覺得呢|推薦一下|有什麼建議|有什麼好|幫我想|幫我選|哪個好/;
const MAKE = /(做|建|弄|寫|生成|產生|設計|開發|架|來|要)[^，。,]{0,10}(網站|網頁|官網|一頁式|系統|後台|儀表板|影片|短影音|短片|視頻)|make (a |an )?(video|website)|landing page/i;
const CONCRETE = /\d|https?:|[A-Za-z]{4,}|「[^」]{2,}」|[：:].{4,}/;   // 有數字、網址、英文詞、引號內容、冒號後的說明 → 比較具體
/** @returns {{vague:boolean, why:string[]}} */
function detect(text) {
  const t = String(text || '').replace(/【[^】]*】/g, '').trim(); const why = [];
  if (!t || t.length > 60) return { vague: false, why };
  if (MAKE.test(t)) return { vague: false, why };   // Anti-gravity-engine3：要做網站／影片＝直接做，不反問（AI 自己補合理預設）
  const concrete = CONCRETE.test(t);
  if (REF.test(t) && !concrete) why.push('指代');             // 「那個」「上次」沒說是哪個
  if (VERB.test(t) && t.length <= 16 && !concrete) why.push('動作不明');   // 「幫我弄一下」沒說弄什麼、弄成怎樣
  if (OPEN.test(t) && t.length <= 20) why.push('條件開放');     // 「隨便」「你決定」
  if (!why.length && t.length <= 6 && /^(幫我|可以|能不能|要|來|給我|再|還要)/.test(t) && !concrete) why.push('太短');
  return { vague: why.length > 0, why };
}
/** 回覆是不是「只丟一個開放式反問」 */
function openQuestion(reply) {
  const t = String(reply || '').trim(); if (!t || t.length > 90) return false;
  if (!/[?？]\s*$/.test(t) && !/(請問|可以說|能不能說|能否提供|請提供|請告訴我|需要更多)/.test(t)) return false;
  if (/(還是|或是|或者|[1-3１-３][.、)）]|・|A[.、)]|選項)/.test(t)) return false;   // 有給選項就不算
  return /(什麼|哪個|哪一|哪些|哪裡|誰|怎樣|如何|更具體|更詳細|說明一下|講清楚|指的是|意思是|需要我做)/.test(t);
}
module.exports = { detect, openQuestion };
