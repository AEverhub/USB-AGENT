'use strict';
/**
 * 26.11.3 pro7：不要一直重複同一句話（除非使用者特別要求）。回覆送出前處理：
 *  1. 同一則回覆裡，一模一樣（去掉標點空白後）的句子／行出現第二次以上 → 只留第一次
 *  2. 同一個詞或短句連續重複好幾次（「好的好的好的好的」「哈哈哈哈哈哈」）→ 最多留兩次
 *  3. 最近幾則回覆裡已經講過 2 次以上的「口頭禪」句子（例：「有需要隨時跟我說！」）→ 這次不再講
 *     （只刪短句，而且刪完還要有別的內容；內容性的句子、程式碼、表格、圖表、清單都不動）
 * 使用者說「重複／再說一次／念 3 遍／跟我念／抄寫／複誦／repeat」之類 → 完全不處理。
 */
const ASK = /重複|再(說|講|念|唸|講述|貼|傳|發)(一|1)?(次|遍)|(說|講|念|唸|寫|抄|印|輸出|print|echo).{0,6}\d+\s*(次|遍|行)|[一二三四五六七八九十兩百千]+\s*(次|遍)|跟我(念|唸|說)|複誦|抄寫|照(抄|念|唸)|原封不動|一字不漏|repeat|again|say it|copy (it|this)|loop|迴圈|洗版|刷屏|口號|咒語|繞口令|歌詞/i;
const norm = (s) => String(s).toLowerCase().replace(/[\s。，、！？!?,.;；:：~～…「」『』（）()【】\[\]"'`*_#>|-]+/g, '');
/** 句子切分：保留原本的標點與換行 */
function pieces(line) { return line.match(/[^。！？!?\n]+[。！？!?]*|\n/g) || [line]; }
function requested(userText) { return ASK.test(String(userText || '')); }
/** 連續重複的詞（2～12 字）出現 4 次以上 → 留 2 次 */
function collapseRuns(s) { return s.replace(/(.{2,12}?)(?:[，, ]?\1){3,}/g, (m, w) => (/^\d+$/.test(w) || /^[=\-*_.#~]+$/.test(w) ? m : w + w)).replace(/(.)\1{5,}/g, (m, c) => (/[=\-*_.#~\s\d]/.test(c) ? m : c.repeat(3))); }

function dedupe(text, { recent = [], user = '', max = 1 } = {}) {
  let t = String(text || ''); if (!t || requested(user)) return t;
  const lines = t.split('\n'); const seen = new Set(); const out = []; let fence = false; let removed = 0;
  // 最近回覆裡出現 2 次以上的短句（口頭禪）
  const habit = new Map(); for (const r of recent.slice(-4)) { const once = new Set(); for (const ln of String(r || '').split('\n')) for (const p of pieces(ln)) { const k = norm(p); if (k.length >= 4 && k.length <= 40 && !once.has(k)) { once.add(k); habit.set(k, (habit.get(k) || 0) + 1); } } }
  for (const ln of lines) {
    if (/^\s*```/.test(ln)) { fence = !fence; out.push(ln); continue; }
    if (fence || /^\s*\|/.test(ln) || /^\s*\[\[/.test(ln) || /^\s*$/.test(ln) || /^\s*(來源|資料來源)[:：]/.test(ln) || /^\s*[・•\-*]\s*https?:/.test(ln)) { out.push(ln); continue; }
    const isList = /^\s*([・•\-*+]|\d+[.、)]|[①-⑳])\s*/.test(ln);
    const kept = []; for (const p of pieces(collapseRuns(ln))) {
      const k = norm(p); if (k.length < 4) { kept.push(p); continue; }
      if (seen.has(k) && !isList) { removed++; continue; }   // 同一則回覆裡第二次出現
      if (!isList && k.length <= 40 && (habit.get(k) || 0) >= 2) { removed++; continue; }   // 最近一直在講的口頭禪
      seen.add(k); kept.push(p);
    }
    const joined = kept.join(''); if (joined.trim() || !ln.trim()) out.push(joined.replace(/\s+$/, '')); else removed++;
  }
  let r = out.join('\n').replace(/\n{3,}/g, '\n\n').trim();
  if (!norm(r)) return t.trim();   // 全部都被刪光（例如整則只有口頭禪）→ 不動，避免空白回覆
  void max; void removed; return r;
}
module.exports = { dedupe, requested, collapseRuns };
