'use strict';
/**
 * MCP 一鍵連結（OAuth 2.1，依 MCP Authorization 規格）：
 *   1. 找授權伺服器：RFC 9728 受保護資源中繼資料（/.well-known/oauth-protected-resource）→ 沒有就用伺服器網域（舊版規格）
 *   2. 讀授權伺服器中繼資料（RFC 8414 / OIDC discovery）
 *   3. 動態註冊用戶端（RFC 7591），沒有註冊端點時用目錄裡預先填的 client_id
 *   4. PKCE（S256）＋ state ＋ resource（RFC 8707）→ 使用者在瀏覽器登入同意 → 回到 App 的 /api/mcp/oauth/callback
 *   5. 換 token，用保險箱的 AES-256-GCM 加密存在 data/mcp-auth.json；快到期自動 refresh
 * token 永遠不會出現在設定、AI 提示詞或日誌裡。
 */
const fs = require('fs');
const seal = require('../core/seal');
const path = require('path');
const crypto = require('crypto');
const { logger } = require('../core/log');
const log = logger('mcpauth');

const b64u = (b) => Buffer.from(b).toString('base64url');
const PENDING_TTL = 15 * 60e3;

async function getJson(url, opt = {}) {
  const r = await fetch(url, { ...opt, headers: { accept: 'application/json', ...(opt.headers || {}) }, signal: AbortSignal.timeout(20000) });
  const t = await r.text(); let j = null; try { j = JSON.parse(t); } catch { /* 不是 JSON */ }
  return { ok: r.ok, status: r.status, json: j, text: t, headers: r.headers };
}
function wellKnown(base, name) {
  const u = new URL(base); const p = u.pathname.replace(/\/+$/, '');
  return [...(p && p !== '/' ? [`${u.origin}/.well-known/${name}${p}`] : []), `${u.origin}/.well-known/${name}`];
}

class McpAuth {
  constructor(ctx) { this.ctx = ctx; this.file = path.join(ctx.paths.data, 'mcp-auth.json'); this.pending = new Map(); }
  _load() { let raw; try { raw = fs.readFileSync(this.file, 'utf8'); } catch { return {}; } try { return JSON.parse(seal.unwrap(raw)); } catch { return {}; } }
  _save(all) { fs.writeFileSync(this.file + '.tmp', seal.wrap(JSON.stringify(all)), { mode: 0o600 }); fs.renameSync(this.file + '.tmp', this.file); }
  _get(name) { const x = this._load()[name]; if (!x) return null; try { return { ...x, tokens: JSON.parse(this.ctx.vault.dec(x.enc)) }; } catch { return null; } }
  _put(name, rec) { const all = this._load(); const { tokens, ...rest } = rec; all[name] = { ...rest, enc: this.ctx.vault.enc(JSON.stringify(tokens)), updated: Date.now() }; this._save(all); }
  remove(name) { const all = this._load(); delete all[name]; this._save(all); }
  status(name) { const x = this._get(name); if (!x) return { connected: false }; return { connected: true, expires_at: x.tokens.expires_at || 0, has_refresh: !!x.tokens.refresh_token, scope: x.tokens.scope || '', since: x.created || 0 }; }

  /** 找出授權伺服器與中繼資料 */
  async discover(serverUrl) {
    let asUrl = ''; let scopes = [];
    // 先問伺服器本身：401 的 WWW-Authenticate 可能直接給 resource_metadata
    let prmUrls = wellKnown(serverUrl, 'oauth-protected-resource');
    try {
      const r = await fetch(serverUrl, { method: 'POST', headers: { 'content-type': 'application/json', accept: 'application/json, text/event-stream' }, body: JSON.stringify({ jsonrpc: '2.0', id: 1, method: 'initialize', params: { protocolVersion: '2025-06-18', capabilities: {}, clientInfo: { name: 'agent', version: '1' } } }), signal: AbortSignal.timeout(15000) });
      const wa = r.headers.get('www-authenticate') || ''; const m = /resource_metadata="([^"]+)"/.exec(wa); if (m) prmUrls = [m[1], ...prmUrls];
      if (r.ok) { try { await r.body?.cancel(); } catch { /* ignore */ } if (!wa) return { open: true }; }
    } catch { /* 有些伺服器不收 POST 探測，繼續走 well-known */ }
    for (const u of prmUrls) { try { const r = await getJson(u); if (r.ok && r.json && Array.isArray(r.json.authorization_servers) && r.json.authorization_servers.length) { asUrl = r.json.authorization_servers[0]; scopes = r.json.scopes_supported || []; break; } } catch { /* 下一個 */ } }
    if (!asUrl) asUrl = new URL(serverUrl).origin;   // 2025-03-26 版規格：授權伺服器＝MCP 伺服器網域
    let meta = null;
    for (const u of [...wellKnown(asUrl, 'oauth-authorization-server'), ...wellKnown(asUrl, 'openid-configuration')]) { try { const r = await getJson(u); if (r.ok && r.json && r.json.authorization_endpoint) { meta = r.json; break; } } catch { /* 下一個 */ } }
    if (!meta) { const o = new URL(asUrl).origin; meta = { issuer: o, authorization_endpoint: `${o}/authorize`, token_endpoint: `${o}/token`, registration_endpoint: `${o}/register`, guessed: true }; }
    return { as: asUrl, meta, scopes };
  }

  /** 開始連結：回傳要開的登入網址 */
  async start({ name, url, redirectUri, clientId = '', clientSecret = '', scope = '', meta = null, extraParams = {}, noResource = false }) {
    if (!/^https:\/\//i.test(url) && !/^http:\/\/(127\.0\.0\.1|localhost)[:/]/i.test(url)) throw new Error('MCP 網址必須是 https');
    // meta：已知授權伺服器（例如 Google）直接給，不探索
    const d = meta ? { meta, scopes: [] } : await this.discover(url); if (d.open) return { open: true };
    const m = d.meta; if (!/^https:\/\//i.test(m.authorization_endpoint) && !/^http:\/\/(127\.0\.0\.1|localhost)/.test(m.authorization_endpoint)) throw new Error('授權網址不是 https，拒絕連結');
    let client = { client_id: clientId, client_secret: clientSecret };
    if (!client.client_id) {
      if (!m.registration_endpoint) throw new Error('這個服務不支援自動註冊，需要先到它的開發者後台建立 OAuth App，再把 client_id 填進「自訂連接器」');
      const r = await getJson(m.registration_endpoint, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ client_name: 'Agent中控中心', redirect_uris: [redirectUri], grant_types: ['authorization_code', 'refresh_token'], response_types: ['code'], token_endpoint_auth_method: 'none', application_type: 'native' }) });
      if (!r.ok || !r.json || !r.json.client_id) throw new Error(`自動註冊失敗（HTTP ${r.status}）：${(r.json && (r.json.error_description || r.json.error)) || r.text.slice(0, 160)}`);
      client = { client_id: r.json.client_id, client_secret: r.json.client_secret || '' };
    }
    const verifier = b64u(crypto.randomBytes(32)); const challenge = b64u(crypto.createHash('sha256').update(verifier).digest()); const state = b64u(crypto.randomBytes(16));
    const sc = scope || (d.scopes || []).join(' ');
    const q = new URLSearchParams({ response_type: 'code', client_id: client.client_id, redirect_uri: redirectUri, code_challenge: challenge, code_challenge_method: 'S256', state, ...(noResource ? {} : { resource: url }), ...(sc ? { scope: sc } : {}), ...extraParams });
    for (const [k, p] of this.pending) if (Date.now() - p.created > PENDING_TTL) this.pending.delete(k);
    this.pending.set(state, { name, url, redirectUri, verifier, client, meta: m, noResource, created: Date.now() });
    return { auth_url: `${m.authorization_endpoint}${m.authorization_endpoint.includes('?') ? '&' : '?'}${q}`, state };
  }
  async _token(meta, client, params) {
    const body = new URLSearchParams({ client_id: client.client_id, ...params }); if (client.client_secret) body.set('client_secret', client.client_secret);
    const r = await getJson(meta.token_endpoint, { method: 'POST', headers: { 'content-type': 'application/x-www-form-urlencoded' }, body: body.toString() });
    if (!r.ok || !r.json || !r.json.access_token) throw new Error(`換 token 失敗（HTTP ${r.status}）：${(r.json && (r.json.error_description || r.json.error)) || r.text.slice(0, 160)}`);
    const t = r.json; return { access_token: t.access_token, refresh_token: t.refresh_token || '', token_type: t.token_type || 'Bearer', scope: t.scope || '', expires_at: t.expires_in ? Date.now() + t.expires_in * 1000 : 0 };
  }
  /** 授權回來：用 code 換 token 並存起來；回傳伺服器名稱 */
  async finish(state, code) {
    const p = this.pending.get(state); if (!p) throw new Error('連結已逾時或不是從這台 App 發起的，請重新按「連結」');
    this.pending.delete(state); if (Date.now() - p.created > PENDING_TTL) throw new Error('連結已逾時，請重新按「連結」');
    const tokens = await this._token(p.meta, p.client, { grant_type: 'authorization_code', code, redirect_uri: p.redirectUri, code_verifier: p.verifier, ...(p.noResource ? {} : { resource: p.url }) });
    this._put(p.name, { url: p.url, client: p.client, meta: { token_endpoint: p.meta.token_endpoint, issuer: p.meta.issuer || '' }, noResource: !!p.noResource, created: Date.now(), tokens });
    this.ctx.store.audit('app', 'mcp.oauth', p.name); return p.name;
  }
  /** 給 MCP 用戶端：取得有效的 access token（快到期就 refresh） */
  async token(name, { force = false } = {}) {
    const x = this._get(name); if (!x) throw new Error(`「${name}」還沒登入，請到「連接器」按一下連結`);
    const t = x.tokens; const soon = t.expires_at && t.expires_at - Date.now() < 60e3;
    if ((soon || force) && t.refresh_token) {
      try { const n = await this._token(x.meta, x.client, { grant_type: 'refresh_token', refresh_token: t.refresh_token, ...(x.noResource ? {} : { resource: x.url }) }); if (!n.refresh_token) n.refresh_token = t.refresh_token; this._put(name, { ...x, tokens: n }); return n.access_token; }
      catch (e) { log.warn(`${name} refresh 失敗：${e.message}`); if (force || (t.expires_at && t.expires_at < Date.now())) throw new Error(`「${name}」登入已過期，請到「連接器」重新連結`); }
    } else if (force) throw new Error(`「${name}」登入已失效，請到「連接器」重新連結`);
    return t.access_token;
  }
}
module.exports = { McpAuth, wellKnown };
