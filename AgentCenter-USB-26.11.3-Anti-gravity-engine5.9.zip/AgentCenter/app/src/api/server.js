'use strict';
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { logger, ring, bus } = require('../core/log');
const { Settings, PERMS, VERSION } = require('../core/settings');
const { Ledger } = require('../services/ledger');
const { buildXlsx } = require('../services/xlsx');
const { taipei } = require('../core/util');
const llm = require('../llm');
const log = logger('api');

const MIME = { '.woff2': 'font/woff2', '.woff': 'font/woff', '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.png': 'image/png', '.svg': 'image/svg+xml', '.json': 'application/json', '.webmanifest': 'application/manifest+json' };
const UI_DIR = path.join(__dirname, '..', '..', 'ui');

function readBody(req, limit = 5 * 1024 * 1024) {
  return new Promise((resolve, reject) => { const c = []; let n = 0; req.on('data', (d) => { n += d.length; if (n > limit) { reject(new Error('內容太大')); req.destroy(); } else c.push(d); }); req.on('end', () => resolve(Buffer.concat(c))); req.on('error', reject); });
}

class Api {
  constructor(ctx) { this.ctx = ctx; this.server = null; this.routes = []; this.sse = new Set(); this.mount(); }
  safeEq(a, b) { const x = Buffer.from(String(a)), y = Buffer.from(String(b)); return x.length === y.length && crypto.timingSafeEqual(x, y); }

  start(port, host = '127.0.0.1') {
    return new Promise((resolve, reject) => {
      this.server = http.createServer((req, res) => this.handle(req, res).catch((e) => { log.error(e); this.json(res, 500, { error: e.message }); }));
      this.server.on('error', reject); this.server.listen(port, host, () => { log.info(`控制 API http://${host}:${port}`); this.port = this.server.address().port; resolve(this.port); });
    });
  }
  stop() { for (const r of this.sse) { try { r.end(); } catch { /* ignore */ } } try { this.server && this.server.close(); } catch { /* ignore */ } }
  json(res, code, obj) { const b = JSON.stringify(obj); res.writeHead(code, { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store', 'x-content-type-options': 'nosniff' }); res.end(b); }

  async handle(req, res) {
    const url = new URL(req.url, 'http://x'); const p = url.pathname;
    if (!p.startsWith('/api/')) return this.static(p, res);
    // MCP OAuth 授權回來的那一下是使用者的瀏覽器直接打進來（沒有 App token）：只認得我們自己發出的一次性 state
    if (p === '/api/mcp/oauth/callback' && req.method === 'GET') return this.oauthCallback(url, res);
    // 26.11.3 Revise6：Discord 收音程式送聲音進來（不用 App token，只認這場會議自己的一次性 token）
    if (p.startsWith('/api/meeting-ingest/') && req.method === 'POST') return this.meetingIngest(p, req, res);
    const tok = (req.headers.authorization || '').replace(/^Bearer\s+/i, '') || url.searchParams.get('t') || '';
    if (!this.safeEq(tok, this.ctx.token)) return this.json(res, 401, { error: '未授權' });
    if (p.startsWith('/api/link/c/') && !this.ctx.link) return this.json(res, 503, { error: '聯機功能沒有啟動（開發者 → 除錯 看原因）' });
    if (p.startsWith('/api/link/c/')) return void this.ctx.link.proxy(req, res, p.slice('/api/link/c'.length) + url.search).catch((e) => { if (!res.headersSent) this.json(res, 502, { error: e.message }); });   // 聯機模式：轉送到主機
    for (const r of this.routes) {
      if (r.method !== req.method) continue; const m = r.re.exec(p); if (!m) continue;
      const params = {}; r.keys.forEach((k, i) => { params[k] = decodeURIComponent(m[i + 1]); });
      const q = Object.fromEntries(url.searchParams); let body = {};
      if (!r.raw && req.method !== 'GET' && req.method !== 'DELETE') { const b = await readBody(req, p === '/api/chat' ? 30e6 : undefined); if (b.length) { try { body = JSON.parse(b.toString('utf8')); } catch { return this.json(res, 400, { error: 'JSON 格式錯誤' }); } } }
      try { const t0 = process.hrtime.bigint(); const pr = r.fn({ params, q, body, req, res, url }); require('../core/slow').note('API ' + req.method + ' ' + p.replace(/\/[^/]*\d[^/]*$/, '/:id'), Number(process.hrtime.bigint() - t0) / 1e6); const out = await pr; if (out !== undefined && !res.headersSent) { const t1 = process.hrtime.bigint(); this.json(res, 200, out); require('../core/slow').note('API 回應 ' + p, Number(process.hrtime.bigint() - t1) / 1e6); } }
      catch (e) { if (!res.headersSent) this.json(res, 400, { error: e.message }); }
      return;
    }
    this.json(res, 404, { error: '沒有這個 API' });
  }
  async meetingIngest(p, req, res) {
    const M = this.ctx.meeting; const id = decodeURIComponent(p.split('/')[3] || ''); const tok = String(req.headers['x-meeting-token'] || '');
    if (!M || !M.checkIngest(id, tok)) return this.json(res, 403, { error: 'unknown', stop: true });
    let b; try { b = JSON.parse((await readBody(req, 25 * 1024 * 1024)).toString('utf8') || '{}'); } catch { return this.json(res, 400, { error: 'JSON 格式錯誤' }); }
    try {
      if (b.type === 'ping') return this.json(res, 200, M.workerPing(id));
      if (b.type === 'status') { M.workerStatus(id, { state: b.state || undefined, error: b.error || undefined, reason: b.reason || undefined }); if (b.state === 'ended') { const m = M.get(id); if (m.status === 'live') M.stop(id, { reason: 'Discord 語音連線結束：' + (b.reason || '') }).catch(() => {}); } return this.json(res, 200, { ok: true, ...M.workerPing(id) }); }
      if (b.type === 'audio') { const r = await M.opus(id, { packets: Array.isArray(b.packets) ? b.packets : [], channels: b.channels, at: b.at, speaker_id: String(b.speaker_id || '') }); return this.json(res, 200, { ok: true, ...r, ...M.workerPing(id) }); }
      if (b.type === 'gateway') { const m = M.get(id); const d = this.ctx.hub && this.ctx.hub.connectors && this.ctx.hub.connectors.discord; const pl = b.payload || {}; const ok = !!(d && m.discord && pl.op === 4 && pl.d && String(pl.d.guild_id) === String(m.discord.guild_id) && d.voicePayload(pl)); return this.json(res, 200, { ok }); }
      return this.json(res, 400, { error: '不認得的類型' });
    } catch (e) { return this.json(res, 400, { error: e.message }); }
  }
  /** AI 的 app_api：直接呼叫和 App 畫面同一套 API（不經 HTTP）。被擋的路徑由呼叫端決定 */
  async invoke(method, p, body = {}) {
    const url = new URL(p, 'http://x'); const pathOnly = url.pathname;
    for (const r of this.routes) {
      if (r.method !== method || r.raw) continue; const m = r.re.exec(pathOnly); if (!m) continue;
      const params = {}; r.keys.forEach((k, i) => { params[k] = decodeURIComponent(m[i + 1]); });
      return r.fn({ params, q: Object.fromEntries(url.searchParams), body: body || {}, req: { headers: {} }, res: null, url });
    }
    throw new Error(`沒有這個 API：${method} ${pathOnly}`);
  }
  routeList() { return this.routes.filter((r) => !r.raw).map((r) => `${r.method} ${r.re.source.replace(/^\^|\$$/g, '').replace(/\(\[\^\/\]\+\)/g, ':x').replace(/\\\//g, '/')}`); }
  async oauthCallback(url, res) {
    const page = (ok, msg) => { res.writeHead(ok ? 200 : 400, { 'content-type': 'text/html; charset=utf-8', 'cache-control': 'no-store' }); res.end(`<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>連接器</title><body style="font-family:system-ui,sans-serif;background:#0b1020;color:#edf3ff;display:grid;place-items:center;min-height:90vh;margin:0;padding:16px;text-align:center"><div><div style="font-size:52px">${ok ? '✅' : '⚠️'}</div><h2>${msg.replace(/[<>&]/g, '')}</h2><p style="color:#91a0ba">${ok ? '可以關掉這頁，回到 App 了。' : '請回到 App 再按一次「連結」。'}</p></div>`); };
    const q = url.searchParams; const c = this.ctx;
    if (q.get('error')) return page(false, `授權被取消或失敗：${q.get('error_description') || q.get('error')}`);
    if (!q.get('state') || !q.get('code')) return page(false, '缺少授權資料');
    try { const name = await c.mcpauth.finish(q.get('state'), q.get('code')); c.connectors.ensureServer(name); await c.mcp.reload(); const n = (c.mcp.counts || {})[name]; return page(true, `${c.connectors.label(name)} 已連結${n ? `，可用 ${n} 個工具` : ''}`); }
    catch (e) { return page(false, e.message); }
  }
  static(p, res) {
    if (p === '/') p = '/index.html'; const f = path.join(UI_DIR, path.normalize(p).replace(/^(\.\.[/\\])+/, ''));
    if (!f.startsWith(UI_DIR) || !fs.existsSync(f) || fs.statSync(f).isDirectory()) { res.writeHead(404); return res.end('not found'); }
    // Anti-gravity-engine1 硬化：控制介面加防護標頭（禁止被內嵌／嗅探型別／外洩 referrer）
    res.writeHead(200, { 'content-type': MIME[path.extname(f)] || 'application/octet-stream', 'cache-control': 'no-cache', 'x-content-type-options': 'nosniff', 'x-frame-options': 'DENY', 'referrer-policy': 'no-referrer' }); fs.createReadStream(f).pipe(res);
  }
  sseStart(res) { res.writeHead(200, { 'content-type': 'text/event-stream', 'cache-control': 'no-cache', connection: 'keep-alive' }); res.write(':ok\n\n'); this.sse.add(res); res.on('close', () => this.sse.delete(res)); }
  add(method, pattern, fn, raw = false) {
    const keys = []; const re = new RegExp('^' + pattern.replace(/:(\w+)/g, (_, k) => { keys.push(k); return '([^/]+)'; }) + '$'); this.routes.push({ method, re, keys, fn, raw });
  }

  mount() {
    const c = this.ctx; const g = (p, f) => this.add('GET', p, f), po = (p, f) => this.add('POST', p, f), de = (p, f) => this.add('DELETE', p, f), pu = (p, f) => this.add('PUT', p, f);
    // ---- 狀態／控制 ----
    g('/api/status', () => this.status());
    po('/api/bot', async ({ body }) => { c.store.audit('app', 'bot', body.action); if (body.action === 'start') await c.supervisor.startAll(); else if (body.action === 'stop') await c.supervisor.stopAll(); else if (body.action === 'restart') await c.supervisor.restartAll(); else throw new Error('action 要 start/stop/restart'); return this.status(); });
    po('/api/service/:name/restart', async ({ params }) => { await c.supervisor.restartService(params.name); return this.status(); });
    g('/api/tunnel', () => c.tunnel.info());
    po('/api/tunnel/restart', async () => { await c.supervisor.restartService('tunnel').catch(() => {}); return c.tunnel.info(); });
    po('/api/process/restart', () => { c.store.flush(); setTimeout(() => process.exit(75), 800); return { ok: true }; });
    po('/api/ui/state', ({ body }) => { c.uiState = { page: body.page, data: body.data, ts: Date.now() }; return { ok: true }; });
    // ---- 審批／通知 ----
    g('/api/approvals', ({ q }) => (q.all ? c.store.db.approvals.slice(-100).reverse() : c.approvals.pending()));
    po('/api/approvals/:id', async ({ params, body }) => { const a = await c.approvals.decide(params.id, !!body.approve, 'app-admin'); return a; });
    g('/api/notifications', ({ q }) => ({ items: c.notifier.list(+q.since || 0).slice(-100), unread: c.store.db.notifications.filter((n) => !n.read).length }));
    po('/api/notifications/read', () => { for (const n of c.store.db.notifications) n.read = true; c.store.touch(); return { ok: true }; });
    // ---- 終端機 ----
    po('/api/term/open', ({ body }) => { const s = c.terminal.open('app-admin', { linux: !!(body && body.linux) }); return { id: s.id, buf: s.buf, linux: !!s.linux }; });
    // ---- 服務頁（第一頁）：服務按鈕、電子發票 ----
    const appAdmin = () => { const p = c.users.admins()[0]; if (!p) throw new Error('還沒有管理員。到「更多 → 用戶」按「建立 App 管理員」，或在平台私訊 /claim 密碼。'); return p; };
    g('/api/services', () => ({ items: c.tiles.list() }));
    po('/api/services', ({ body }) => ({ ok: true, items: c.tiles.save(body.items) }));
    po('/api/services/reset', () => ({ ok: true, items: c.tiles.reset() }));
    po('/api/services/run', async ({ body }) => { const b = body || {}; if (b.image && String(b.image.data || '').length > 14e6) throw new Error('照片太大（上限約 10MB）'); return c.tiles.run(String(b.id || ''), { text: b.text || '', image: b.image || null, qr: b.qr || [] }, appAdmin()); });
    po('/api/einvoice', ({ body }) => c.einvoice.record(body.qr || [], appAdmin().id));
    // ---- 人設 ----
    g('/api/persona', () => ({ persona: require('../agent/persona').cfg(c.settings), presets: require('../agent/persona').PRESETS }));
    po('/api/persona', ({ body }) => { const P = require('../agent/persona'); const cur = P.cfg(c.settings); const next = { ...cur };
      for (const k of Object.keys(P.DEFAULTS)) if (body[k] !== undefined) next[k] = typeof P.DEFAULTS[k] === 'boolean' ? !!body[k] : String(body[k]).slice(0, k === 'avoid' || k === 'identity' ? 300 : 120);
      c.settings.set('persona', next, 'human'); c.store.audit('app', 'persona', next.name || ''); return { ok: true, persona: next }; });
    // ---- 連接器（MCP 一鍵連結）----
    g('/api/connectors', () => c.connectors.state());
    po('/api/connectors/connect', async ({ body, req }) => {
      const origin = String(body.origin || ''); const redirect = /^https?:\/\/[^/\s]+$/i.test(origin) ? `${origin}/api/mcp/oauth/callback` : `http://127.0.0.1:${this.port}/api/mcp/oauth/callback`; void req;
      const r = await c.connectors.connect(body, redirect, { port: this.port }); c.store.audit('app', 'connector.connect', body.id || body.name || ''); return r;
    });
    po('/api/connectors/disconnect', async ({ body }) => { await c.connectors.disconnect(String(body.name || '')); c.store.audit('app', 'connector.disconnect', body.name || ''); return c.connectors.state(); });
    // ---- 內建 Linux（PRoot＋Alpine，不需 Termux App）----
    g('/api/linux/state', () => c.linux.state());
    po('/api/linux/install', ({ body }) => { if (c.linux.job && c.linux.job.running) throw new Error('正在安裝中'); c.store.audit('app', 'linux.install', body && body.chromium ? 'chromium' : 'base'); c.linux.install({ chromium: !!(body && body.chromium) }).catch(() => {}); return { ok: true, started: true }; });
    po('/api/linux/diagnose', async () => { if (c.linux.job && c.linux.job.running) throw new Error('正在安裝中'); return c.linux.diagnose(); });
    po('/api/linux/start', async () => { await c.settings.set('termux.mode', 'embedded', 'human'); const ok = await c.linux.start(); return { ok, ...c.linux.state() }; });
    po('/api/linux/stop', async () => { await c.linux.stop(); return c.linux.state(); });
    po('/api/linux/use-termux', async () => { await c.linux.stop(); c.settings.set('termux.mode', 'termux', 'human'); c.settings.set('termux.url', 'http://127.0.0.1:8766', 'human'); c.settings.set('termux.token', '', 'human'); return c.linux.state(); });
    po('/api/linux/reset', async ({ body }) => { if (!body || body.confirm !== 'RESET') throw new Error('要帶 confirm: RESET'); c.store.audit('app', 'linux.reset', ''); return c.linux.reset(); });
    g('/api/term/stream', ({ q, req, res }) => { const s = c.terminal.sessions.get(q.id); if (!s) throw new Error('終端機不存在'); this.sseStart(res); const on = (t) => res.write(`data: ${JSON.stringify(t)}\n\n`); s.ev.on('data', on); req.on('close', () => s.ev.off('data', on)); });
    po('/api/term/input', ({ body }) => { c.terminal.input(body.id, body.text); return { ok: true }; });
    po('/api/term/close', ({ body }) => { c.terminal.close(body.id); return { ok: true }; });
    // ---- 日誌 ----
    g('/api/logs', () => ({ lines: ring.slice(-300) }));
    g('/api/logs/stream', ({ req, res }) => { this.sseStart(res); const on = (e) => res.write(`data: ${JSON.stringify(e.line)}\n\n`); bus.on('line', on); req.on('close', () => bus.off('line', on)); });
    // ---- 設定 ----
    g('/api/settings', () => ({ settings: c.settings.masked(), perms: PERMS, version: VERSION }));
    po('/api/settings', ({ body }) => { const items = body.items || [{ key: body.key, value: body.value }]; for (const i of items) { if (!i.key) throw new Error('缺 key'); if (Settings.isSecret(i.key) && (i.value === '••••已設定' || i.value === '')) continue; c.settings.set(i.key, i.value, 'human'); } c.store.audit('app', 'settings', items.map((i) => i.key).join(',')); return { ok: true }; });
    g('/api/model-providers', () => ({ providers: llm.providerList(c.settings), current: { provider: c.settings.get('model.provider'), name: c.settings.get('model.name'), fallback_provider: c.settings.get('model.fallback_provider', ''), fallback_model: c.settings.get('model.fallback_model', ''), order: llm.providerOrder(c.settings), provider_models: c.settings.get('model.provider_models', {}), custom_base_url: c.settings.get('model.custom_base_url', '') } }));
    // 一次切換主供應商＋模型（並記住每家各自的模型，切回去不用重填）
    po('/api/model-select', ({ body }) => {
      const provider = String(body.provider || ''); if (!llm.isProvider(provider)) throw new Error('不支援的供應商：' + provider);
      const name = String(body.model || '').trim().slice(0, 120) || llm.modelFor(c.settings, provider) || llm.PROVIDERS[provider].defaultModel;
      const pm = { ...(c.settings.get('model.provider_models', {}) || {}) }; pm[provider] = name;
      if (c.settings.get('model.provider') !== provider) { const cur = c.settings.get('model.provider'); pm[cur] = pm[cur] || c.settings.get('model.name'); }
      c.settings.set('model.provider_models', pm, 'human'); c.settings.set('model.provider', provider, 'human'); c.settings.set('model.name', name, 'human');
      { const o = c.settings.get('model.provider_order', []) || []; if (o.length) c.settings.set('model.provider_order', [provider, ...o.filter((x) => x !== provider)], 'human'); }   // 設為主要＝排到第一
      if (body.fallback_provider !== undefined) { const fp = String(body.fallback_provider || ''); if (fp && !llm.isProvider(fp)) throw new Error('備援供應商不支援：' + fp); c.settings.set('model.fallback_provider', fp === provider ? '' : fp, 'human'); if ((c.settings.get('model.provider_order', []) || []).length) c.settings.set('model.provider_order', [provider, ...(fp && fp !== provider ? [fp] : [])], 'human'); }
      if (body.fallback_model !== undefined) c.settings.set('model.fallback_model', String(body.fallback_model || '').trim().slice(0, 120), 'human');
      if (body.custom_base_url !== undefined) { const u = String(body.custom_base_url || '').trim(); if (u && !/^https?:\/\/[^\s]+$/i.test(u)) throw new Error('API 網址要以 http:// 或 https:// 開頭'); c.settings.set('model.custom_base_url', u, 'human'); }
      c.store.audit('app', 'model_select', `${provider}/${name}`); return { ok: true, provider, model: name };
    });
    // 26.11.3 pro3：供應商順序（第一個＝主要；額度用完／金鑰失效／故障就自動跳下一個）；可順便設每家要用的模型
    po('/api/model-order', ({ body }) => {
      const order = [...new Set((Array.isArray(body.order) ? body.order : []).map(String))]; if (!order.length) throw new Error('至少要有一個供應商');
      for (const p of order) if (!llm.isProvider(p)) throw new Error('不支援的供應商：' + p);
      const pm = { ...(c.settings.get('model.provider_models', {}) || {}) }; const cur = c.settings.get('model.provider'); pm[cur] = pm[cur] || c.settings.get('model.name');
      if (body.models && typeof body.models === 'object') for (const [p, m] of Object.entries(body.models)) if (llm.isProvider(p) && String(m || '').trim()) pm[p] = String(m).trim().slice(0, 120);
      c.settings.set('model.provider_models', pm, 'human'); c.settings.set('model.provider_order', order, 'human');
      c.settings.set('model.provider', order[0], 'human'); c.settings.set('model.name', pm[order[0]] || llm.PROVIDERS[order[0]].defaultModel, 'human');
      c.settings.set('model.fallback_provider', order[1] || '', 'human'); c.settings.set('model.api_keys_notified', false, 'system');
      c.store.audit('app', 'model_order', order.join(' > ')); return { ok: true, order: llm.providerOrder(c.settings), provider: order[0], model: c.settings.get('model.name') };
    });
    // ---- 26.9.1 自動化：監控哨兵、每日簡報、語音、手機 ----
    const owner = () => (c.users.list().find((p) => p.role === 'admin' && p.status === 'active') || {}).id || '';
    g('/api/auto/state', () => ({ brief: { ...c.brief.cfg() }, speech: { ...c.speech.cfg(), routes: c.speech.routes() }, phone: { ready: c.phone.ready() }, watches: c.watch.all() }));
    g('/api/watch', () => ({ items: c.watch.all() }));
    po('/api/watch', async ({ body }) => { const w = c.watch.add(body || {}, owner()); c.store.audit('app', 'watch.add', `#${w.id} ${w.url}`); const r = await c.watch.check(w, { notify: false }); return { ok: true, item: c.watch.get(w.id), first: r }; });
    po('/api/watch/:id', ({ params, body }) => ({ ok: true, item: c.watch.update(params.id, body || {}) }));
    po('/api/watch/:id/check', async ({ params }) => { const w = c.watch.get(params.id); if (!w) throw new Error('找不到這個哨兵'); const r = await c.watch.check(w, { notify: false }); return { ok: true, ...r, item: c.watch.get(w.id) }; });
    de('/api/watch/:id', ({ params }) => { c.watch.remove(params.id); c.store.audit('app', 'watch.remove', `#${params.id}`); return { ok: true }; });
    po('/api/brief/config', ({ body }) => {
      const b = body || {}; if (b.enabled !== undefined) c.settings.set('brief.enabled', !!b.enabled, 'human');
      if (b.at !== undefined) { if (!/^\d{1,2}:\d{2}$/.test(String(b.at))) throw new Error('時間格式 HH:mm'); c.settings.set('brief.at', String(b.at), 'human'); }
      if (b.city !== undefined) c.settings.set('brief.city', String(b.city).trim().slice(0, 60), 'human');
      if (b.speech_enabled !== undefined) c.settings.set('speech.enabled', !!b.speech_enabled, 'human');
      return { ok: true, brief: c.brief.cfg() };
    });
    po('/api/brief/preview', async () => { const admin = c.users.list().find((p) => p.role === 'admin' && p.status === 'active') || null; return { text: await c.brief.build(admin) }; });
    po('/api/brief/send', async () => ({ ok: true, sent: await c.brief.send() }));
    g('/api/phone/status', async () => ({ ok: true, ...(await c.phone.status()) }));
    g('/api/model-keys', () => ({ items: c.settings.masked().model.api_keys || [], max: null }));   // 26.11.3 pro3：不限組數
    po('/api/model-keys', ({ body }) => {
      const incoming = Array.isArray(body.items) ? body.items : [];
      const old = c.settings.get('model.api_keys', []); const next = [];
      for (let i = 0; i < incoming.length; i++) {
        const x = incoming[i] || {}; const prev = (Number.isInteger(x.from) ? old[x.from] : x.from === undefined ? old[i] : null) || {}; const key = String(x.key || '').trim(); const keep = key === '••••已設定' || !key ? prev.key : key;
        if (!keep) continue;
        const provider = llm.isProvider(x.provider) ? x.provider : 'gemini'; const bu = String(x.base_url !== undefined ? x.base_url : (prev.base_url || '')).trim();
        if (bu && !/^https?:\/\/[^\s]+$/i.test(bu)) throw new Error(`第 ${i + 1} 組的 API 網址要以 http:// 或 https:// 開頭`);
        const changed = key && key !== '••••已設定';
        next.push({ label: String(x.label || prev.label || `金鑰 ${i + 1}`).slice(0, 40), provider, model: String(x.model || prev.model || '').slice(0, 120), key: keep, ...(provider === 'custom' && bu ? { base_url: bu } : {}),
          enabled: x.enabled !== false, exhausted: changed ? false : !!prev.exhausted, last_error: changed ? '' : (prev.last_error || ''), last_used: prev.last_used || 0 });
      }
      c.settings.set('model.api_keys', next, 'human'); c.settings.set('model.api_key_cursor', 0, 'system'); c.settings.set('model.api_keys_notified', false, 'system'); c.store.audit('app', 'model_keys', `${next.length} 組`); return { ok: true, items: c.settings.masked().model.api_keys };
    });
    po('/api/model-keys/reset', () => { const next = (c.settings.get('model.api_keys', []) || []).map((x) => ({ ...x, exhausted: false, last_error: '' })); c.settings.set('model.api_keys', next, 'human'); c.settings.set('model.api_key_cursor', 0, 'system'); c.settings.set('model.api_keys_notified', false, 'system'); return { ok: true }; });
    // 沒帶參數＝測試目前設定的主模型（走金鑰池）；帶 provider＋key＝儲存前先試這一把（不寫入設定）。key 是 ••••已設定 時用池裡同位置那把
    po('/api/model-test', async ({ body }) => {
      body = body || {};
      if (body.provider) {
        let key = String(body.key || '').trim(); let bu = String(body.base_url || '').trim();
        if (!key || key === '••••已設定') { const pool = c.settings.get('model.api_keys', []) || []; const hit = Number.isInteger(body.index) ? pool[body.index] : null; const cand = hit && hit.provider === body.provider ? hit : llm.keyCandidates(c.settings, body.provider).find(llm.usable); key = cand && cand.key; bu = bu || (cand && cand.base_url) || ''; }
        const r = await llm.probe(c, { provider: body.provider, model: String(body.model || '').trim(), key, base_url: bu || c.settings.get('model.custom_base_url', '') });
        return { ok: true, provider: r.provider, model: r.model, text: r.text };
      }
      const provider = c.settings.get('model.provider'); const model = c.settings.get('model.name'); const text = await llm.simple(c, '請只回覆「模型連線正常」。不要補充其他內容。', '你正在執行模型連線測試。'); return { ok: true, provider, model, text };
    });
    // 工具相容性檢查：目前主模型下，每個工具的 Schema 轉換／預檢結果與被隔離的工具
    g('/api/model-schema-check', () => { const p = c.users.admins()[0] || { role: 'admin', id: 'x' }; const all = c.tools.forPerson(p, false); return { total: all.length, ...llm.schemaReport(c, c.settings.get('model.provider'), all) }; });
    po('/api/model-schema-check/reset', () => { llm.clearQuarantine(); return { ok: true }; });
    po('/api/model-list', async ({ body }) => {
      body = body || {}; let key = String(body.key || '').trim(); if (key === '••••已設定') key = '';
      return await llm.listModels(c, { provider: String(body.provider || c.settings.get('model.provider')), key, base_url: String(body.base_url || c.settings.get('model.custom_base_url', '')) });
    });
    po('/api/notify/test', async () => { const n = await c.notifier.push('error', '測試通知', '如果你在手機通知列、App 通知中心、管理員私訊都看到這則，代表推播通道正常。', { force: true }); return n; });
    po('/api/mcp/reload', async () => c.mcp.reload());
    g('/api/mcp', () => ({ tools: c.mcp.tools.map((t) => ({ name: t.name, server: t.server, description: t.description })), errors: c.mcp.errors, servers: c.settings.get('mcp.servers', []) }));
    po('/api/link/start', ({ body }) => { const p = body.pid ? c.users.byId(body.pid) : (c.users.admins()[0] || null); if (!p) throw new Error('還沒有管理員，請先到平台用 /claim 認領，或建立 App 管理員'); return { code: c.hub.newLinkCode(p.id), person: p.name || p.id }; });
    po('/api/app-admin', () => { if (c.users.hasAdmin()) throw new Error('已經有管理員了'); const p = c.users.create({ platform: 'app', uid: 'local', name: '管理員', role: 'admin', status: 'active' }); return c.users.summary(p); });
    // ---- 使用者 ----
    g('/api/users', () => ({ users: c.users.list().map((p) => c.users.summary(p)), roles: c.settings.get('roles'), perms: PERMS }));
    po('/api/users/:id', ({ params, body }) => { const p = c.users.byId(params.id); if (!p) throw new Error('找不到使用者'); if (body.role) c.users.setRole(p.id, body.role); if (body.name !== undefined) p.name = body.name; if (body.instructions !== undefined) p.instructions = body.instructions; if (body.status) p.status = body.status; if (body.quota !== undefined) { const L = Math.max(0, Math.min(100000, Math.floor(+((body.quota || {}).limit) || 0))); const per = ['hour', 'day', 'week', 'total'].includes((body.quota || {}).per) ? body.quota.per : 'day'; p.quota = L ? { ...(p.quota || {}), limit: L, per, ...(p.quota && p.quota.per !== per ? { used: 0, window: '' } : {}) } : null; c.store.audit('app', 'quota', `${p.name || p.id} ${L ? L + '/' + per : '不限'}`); }
      if (body.perms) p.perms = { allow: body.perms.allow || [], deny: body.perms.deny || [] }; if (body.prefs) Object.assign(p.prefs, body.prefs); c.store.touch(); c.store.audit('app', 'user.set', p.id); return c.users.summary(p); });
    de('/api/users/:id', ({ params }) => { const p = c.users.byId(params.id); if (!p) throw new Error('找不到'); if (p.role === 'admin' && c.users.admins().length <= 1) throw new Error('至少保留一位管理員'); for (const i of p.identities) delete c.store.db.idmap[`${i.platform}:${i.uid}`]; delete c.store.db.persons[p.id]; c.store.touch(); return { ok: true }; });
    po('/api/users/:id/merge', ({ params, body }) => { c.users.merge(body.into, params.id); return { ok: true }; });
    po('/api/roles', ({ body }) => { if (body.role === 'admin') throw new Error('管理員權限固定為全部'); c.settings.set('roles.' + body.role, body.perms || [], 'human'); return { ok: true }; });
    // ---- 廣播 ----
    po('/api/broadcast', async ({ body }) => { if (!body.text || !String(body.text).trim()) throw new Error('內容不能空白'); return c.hub.broadcast({ text: body.text, platforms: body.platforms && body.platforms.length ? body.platforms : null, roles: body.roles && body.roles.length ? body.roles : null, includeGroups: !!body.include_groups }); });
    g('/api/groups', () => Object.values(c.store.db.chats).map((x) => ({ ...x, members: Object.keys(x.members).length })));
    // ---- 試算表 ----
    g('/api/sheets', () => c.sheets.list());
    po('/api/sheets', ({ body }) => c.sheets.create(body.name, body.headers || ['A', 'B', 'C'], '*', body.rows || []));
    g('/api/sheets/:id', ({ params }) => { const s = c.sheets.get(params.id); if (!s) throw new Error('找不到'); return { sheet: { id: s.id, name: s.name, headers: s.headers, rows: s.rows, version: s.version, versions: s.versions.map((v) => ({ v: v.v, note: v.note, ts: v.ts })) }, computed: c.sheets.computed(s) }; });
    po('/api/sheets/:id/cell', ({ params, body }) => { const s = c.sheets.get(params.id); if (!s) throw new Error('找不到'); c.sheets.setCell(s, body.cell, body.value, 'app'); return { ok: true }; });
    po('/api/sheets/:id/rows', ({ params, body }) => { const s = c.sheets.get(params.id); if (!s) throw new Error('找不到'); c.sheets.addRows(s, body.rows || [[]], 'app'); return { ok: true }; });
    po('/api/sheets/:id/restore', ({ params, body }) => { const s = c.sheets.get(params.id); c.sheets.restore(s, body.version); return { ok: true }; });
    de('/api/sheets/:id', ({ params }) => { const s = c.sheets.get(params.id); if (!s) throw new Error('找不到'); c.sheets.remove(s); return { ok: true }; });
    g('/api/sheets/:id/export', ({ params, q, res }) => { const s = c.sheets.get(params.id); if (!s) throw new Error('找不到'); const x = q.fmt === 'csv';
      const buf = x ? Buffer.from(c.sheets.toCSV(s)) : buildXlsx({ name: s.name, rows: [s.headers.map((h) => ({ v: h, s: 2 })), ...c.sheets.computed(s).map((r) => r.map((v) => ({ v, s: 6 })))], widths: s.headers.map(() => 16) });
      res.writeHead(200, { 'content-type': x ? 'text/csv; charset=utf-8' : 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'content-disposition': `attachment; filename*=UTF-8''${encodeURIComponent(s.name)}.${x ? 'csv' : 'xlsx'}` }); res.end(buf); });
    // ---- 記帳表（常駐）----
    g('/api/ledger', ({ q }) => ({ ...c.ledger.layout(q.owner || null), summary: c.ledger.summary(q.owner || null, +q.days || 30), owners: [...new Set(c.ledger.all.map((e) => e.owner))].map((id) => ({ id, name: id === '*' ? '共用' : (c.users.byId(id) || {}).name || id })) }));
    po('/api/ledger', ({ body }) => c.ledger.add({ owner: body.owner || '*', kind: body.kind, amount: body.amount, note: body.note, tag: body.tag, ts: body.when ? Ledger.parseWhen(body.when) || Date.now() : Date.now() }));
    pu('/api/ledger/:id', ({ params, body }) => c.ledger.update(params.id, body));
    de('/api/ledger/:id', ({ params }) => { c.ledger.remove(params.id); return { ok: true }; });
    g('/api/ledger/export', ({ q, res }) => { const x = q.fmt === 'csv'; const o = q.owner || null; const name = `記帳表-${taipei().iso}.${x ? 'csv' : 'xlsx'}`;
      res.writeHead(200, { 'content-type': x ? 'text/csv; charset=utf-8' : 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'content-disposition': `attachment; filename*=UTF-8''${encodeURIComponent(name)}` }); res.end(x ? Buffer.from(c.ledger.toCSV(o)) : c.ledger.toXlsx(o)); });
    // ---- 檔案 ----
    const sc = (q) => (['app', 'workspace', 'data'].includes(q.scope) ? q.scope : 'data');
    g('/api/files', ({ q }) => ({ path: q.path || '.', items: c.fsx.list(q.path || '.', sc(q)), disk_bytes: c.fsx.usage() }));
    g('/api/files/read', ({ q }) => ({ content: c.fsx.read(q.path, sc(q)) }));
    po('/api/files/write', ({ body, q }) => { c.fsx.write(body.path, body.content ?? '', sc(q), 'app'); return { ok: true }; });
    po('/api/files/mkdir', ({ body, q }) => { c.fsx.mkdir(body.path, sc(q)); return { ok: true }; });
    po('/api/files/move', ({ body, q }) => { c.fsx.move(body.from, body.to, sc(q), 'app'); return { ok: true }; });
    de('/api/files', ({ q }) => ({ ok: true, snapshot: c.fsx.remove(q.path, sc(q), 'app') }));
    g('/api/files/download', ({ q, res }) => { const buf = c.fsx.read(q.path, sc(q), true); res.writeHead(200, { 'content-type': 'application/octet-stream', 'content-disposition': `attachment; filename*=UTF-8''${encodeURIComponent(path.basename(q.path))}` }); res.end(buf); });
    this.add('POST', '/api/files/upload', async ({ q, req }) => { const b = await readBody(req, 80 * 1024 * 1024); c.fsx.write(q.path, b, sc(q), 'app'); return { ok: true, bytes: b.length }; }, true);
    // ---- 開發者 ----
    g('/api/debug/state', () => c.debug.state());
    g('/api/debug/traces', () => c.debug.traces.slice(-40).reverse());
    po('/api/debug/eval', async ({ body }) => ({ result: await c.debug.evalCode(String(body.code || '')) }));
    po('/api/debug/inspector', ({ body }) => { c.settings.set('dev.debug_inspector', !!body.on, 'human'); if (body.port) c.settings.set('dev.debug_port', +body.port, 'human'); return c.debug.applyInspector(); });
    g('/api/audit', ({ q }) => c.store.db.audit.slice(-(+q.n || 100)).reverse());
    g('/api/supervisor', () => c.supervisor.status());
    po('/api/workers', ({ body }) => { c.supervisor.saveWorker(body); if (body.autostart !== false) { c.supervisor.stopWorker(body.name); c.supervisor.startWorker(body); } return c.supervisor.status(); });
    po('/api/workers/:name/:action', ({ params }) => { const d = c.settings.get('supervisor.workers', []).find((w) => w.name === params.name); if (params.action === 'delete') c.supervisor.deleteWorker(params.name); else { if (!d) throw new Error('沒有這個工人'); if (params.action !== 'start') c.supervisor.stopWorker(params.name); if (params.action !== 'stop') c.supervisor.startWorker(d); } return c.supervisor.status(); });
    g('/api/workers/:name/logs', ({ params }) => ({ lines: c.supervisor.workerLogs(params.name) }));
    // ---- 資料轉移（換手機）：下載一個 JSON → 新手機上傳 ----
    const needTransfer = () => { if (!c.transfer) throw new Error('資料轉移功能沒有啟動（開發者 → 除錯 看原因）'); return c.transfer; };
    g('/api/transfer/summary', ({ q }) => needTransfer().summary({ media: q.media !== '0', workspace: q.workspace !== '0' }));
    po('/api/transfer/export', ({ body }) => needTransfer().export({ password: body.password || '', media: body.media !== false, workspace: body.workspace !== false }));
    this.add('GET', '/api/transfer/file/:id', ({ params, q, res }) => { const f = needTransfer().path(params.id); const name = String(q.name || 'transfer.json').replace(/[\r\n"]/g, '');
      res.writeHead(200, { 'content-type': 'application/json; charset=utf-8', 'content-length': fs.statSync(f).size, 'content-disposition': `attachment; filename="transfer.json"; filename*=UTF-8''${encodeURIComponent(name)}`, 'cache-control': 'no-store' }); fs.createReadStream(f).pipe(res); }, true);
    this.add('POST', '/api/transfer/upload', async ({ req, res }) => { try { const id = await needTransfer().receive(req); this.json(res, 200, needTransfer().preview(id)); } catch (e) { this.json(res, 400, { error: e.message }); } }, true);
    po('/api/transfer/import', ({ body }) => { if (body.confirm !== true) throw new Error('需要確認'); c.store.audit('app', 'transfer_import', body.id); return needTransfer().import(body.id, { password: body.password || '' }); });
    // ---- 聯機（26.11.3）----
    const needLink = () => { if (!c.link) throw new Error('聯機功能沒有啟動（開發者 → 除錯 看原因）'); return c.link; };
    g('/api/link/state', () => (c.link ? c.link.state() : { mode: 'host', unavailable: true }));
    po('/api/link/register', ({ body }) => ({ me: needLink().register(body.name) }));
    po('/api/link/host', ({ body }) => needLink().setupHost({ name: body.name, password: body.password || '', public: body.public !== false }));
    po('/api/link/host/update', ({ body }) => needLink().hostUpdate(body));
    po('/api/link/announce', async () => ({ ok: true, result: await needLink().announce() }));
    g('/api/link/list', () => needLink().list());
    po('/api/link/join', ({ body }) => needLink().join({ target: body.target, password: body.password || '', name: body.name, invite: body.invite || '', directory: body.directory || '' }));
    po('/api/link/leave', () => needLink().leave());
    // 聯機群組（主機管理員自己用；聯機端走 /api/link/c/api/groups/…）
    const hostMe = () => { const L = needLink(); if (L.mode !== 'host') throw new Error('要先在「開發者 → 聯機」設為主機'); const p = c.users.admins()[0]; if (!p) throw new Error('還沒有管理員'); return p; };
    g('/api/ngroups', () => ({ items: needLink().mode === 'host' ? c.link.groupList(hostMe()) : [] }));
    g('/api/ngroups/people', () => ({ items: c.link.people().filter((x) => x.pid !== hostMe().id) }));
    g('/api/ngroups/:id/history', ({ params, q }) => c.link.groupHistory(hostMe(), params.id, q));
    po('/api/ngroups', ({ body }) => c.link.groupCreate(hostMe(), body));
    po('/api/ngroups/:id/send', ({ params, body }) => c.link.groupSend(hostMe(), params.id, body));
    po('/api/ngroups/:id/members', ({ params, body }) => c.link.groupAdd(hostMe(), params.id, body.pids || []));
    po('/api/ngroups/:id/leave', ({ params }) => c.link.groupLeave(hostMe(), params.id));
    // ---- 伺服器安裝（26.11.3 Revise4）----
    po('/api/deploy/prepare', ({ body }) => { if (!c.deploy) throw new Error('伺服器安裝功能沒有啟動'); return c.deploy.prepare(body); });
    this.add('GET', '/api/deploy/:token/standalone.sh', ({ params, res }) => { const f = c.deploy.standalonePath(params.token); res.writeHead(200, { 'content-type': 'text/x-shellscript; charset=utf-8', 'content-length': fs.statSync(f).size, 'content-disposition': 'attachment; filename="agent-center-install.sh"' }); fs.createReadStream(f).pipe(res); }, true);
    g('/api/debug/speed', () => c.debug.speed() || { turns: 0 });
    g('/api/debug/issues', () => ({ issues: c.debug.issues() }));
    g('/api/debug/report', () => ({ text: c.debug.report() }));
    // 26.11.3 pro10：用戶條款（App 第一次使用、條款更新後要同意）
    g('/api/terms', () => c.terms.state('app'));
    po('/api/terms/accept', ({ body }) => { if (!body || body.agree !== true) throw new Error('要勾選同意'); return c.terms.accept('app', 'app'); });
    // Anti-gravity-engine2：介面旗標存在後端（例如「新手教學已看過」）。WebView 的 localStorage 在 App 被系統砍掉時可能還沒寫進磁碟，存後端才不會重開又跳出來
    g('/api/ui/flags', () => ({ flags: { ...((c.store.db.meta || {}).ui_flags || {}) } }));
    po('/api/ui/flags', ({ body }) => {
      const k = String((body || {}).key || ''); if (!/^[a-z0-9_]{1,40}$/.test(k)) throw new Error('旗標名稱不合法');
      const v = body.value; if (!(typeof v === 'boolean' || typeof v === 'number' || (typeof v === 'string' && v.length <= 200))) throw new Error('旗標值不合法');
      c.store.db.meta = c.store.db.meta || {}; const f = c.store.db.meta.ui_flags = c.store.db.meta.ui_flags || {};
      if (Object.keys(f).length >= 100 && !(k in f)) throw new Error('旗標太多');
      f[k] = v; c.store.touch(); try { c.store.flush(); } catch { /* 下次自動存 */ }   // 立刻落地，避免剛設完 App 就被關掉
      return { flags: { ...f } };
    });
    // Anti-gravity-engine2：網站工作室（AI 開發網頁系統）
    const SI = () => { if (!c.sites) throw new Error('網站工作室沒有啟動'); return c.sites; };
    g('/api/sites', () => ({ sites: SI().list(), templates: SI().templates() }));
    po('/api/sites', ({ body }) => SI().create(body || {}, 'app'));
    po('/api/sites/build', ({ body }) => SI().jobPub(SI().build((body || {}).request, { by: 'app', reply: { platform: 'app' } })));   // Anti-gravity-engine3：一句話生成
    g('/api/sites/jobs', () => ({ jobs: SI().jobList() }));
    g('/api/sites/:id', ({ params }) => { const r = SI().read(params.id); return { site: r.site, files: r.files }; });
    g('/api/sites/:id/file', ({ params, q }) => SI().read(params.id, q.path));
    po('/api/sites/:id/file', ({ params, body }) => SI().write(params.id, [{ path: body.path, content: body.delete ? null : body.content }], 'app'));
    po('/api/sites/:id/check', ({ params }) => { const r = SI().check(params.id); return { ...r, text: SI().report(r) }; });
    g('/api/sites/:id/preview', async ({ params }) => SI().preview(params.id));
    po('/api/sites/:id/zip', ({ params }) => SI().zip(params.id, 'app'));
    this.add('DELETE', '/api/sites/:id', ({ params }) => SI().remove(params.id, 'app'));
    // Anti-gravity-engine2：影片工作室（AI 寫分鏡 → App 畫面算圖 → 傳回聊天室）
    const VD = () => { if (!c.videos) throw new Error('影片工作室沒有啟動'); return c.videos; };
    // Anti-gravity-engine4：專業引擎（Termux 的 HyperFrames）與素材能力；放在 /api/video/:id 前面
    const VE = () => { if (!c.vengine) throw new Error('影片引擎沒有啟動'); return c.vengine; };
    g('/api/video/engine', () => ({ ...VE().state(), repos: require('../services/videoengine').SKILL_REPOS }));
    po('/api/video/engine/install', () => VE().install());
    g('/api/video/engine/log', () => VE().installLog());
    po('/api/video/engine/check', () => VE().check());
    po('/api/video/engine/import', () => VE().importSkills());
    po('/api/video/engine/test', () => VE().selfTest());
    g('/api/video/caps', () => ({ ...(c.vidmedia ? c.vidmedia.caps() : {}), packs: (() => { try { return c.voice.packs().filter((p) => p.provider !== 'device').map((p) => ({ id: p.id, name: p.name, provider: p.provider, available: !!p.available })); } catch { return []; } })(), settings: (() => { const v = c.settings.get('video', {}) || {}; return { engine: v.engine || 'auto', narration: v.narration !== false, voice_pack: v.voice_pack || '', auto_images: v.auto_images !== false, footage: v.footage !== false, pexels_key: v.pexels_key ? '••••已設定' : '', heygen_key: v.heygen_key ? '••••已設定' : '', heygen_avatar: v.heygen_avatar || '', heygen_voice: v.heygen_voice || '', ai_clips: !!v.ai_clips, omni_model: v.omni_model || '', free_stock: v.free_stock !== false, avatar: v.avatar || 'auto', gender: v.gender || 'auto' }; })() }));
    g('/api/video', () => ({ videos: VD().list(), pending: VD().pending(), drafting: VD().drafting() }));
    po('/api/video/auto', ({ body }) => VD().pub(VD().auto((body || {}).request, { by: 'app', reply: { platform: 'app' }, media: (body || {}).media, urls: (body || {}).urls })));   // Anti-gravity-engine3：一句話生成
    po('/api/video', ({ body }) => VD().pub(VD().make(body || {}, { by: 'app', reply: { platform: 'app' } })));
    g('/api/video/queue', () => ({ pending: VD().pending() }));
    po('/api/video/claim', ({ body }) => ({ job: VD().claim((body || {}).worker) }));
    g('/api/video/:id', ({ params }) => { const v = VD().get(params.id); return { ...VD().pub(v), spec: v.spec, assets: VD().assets(v) }; });
    po('/api/video/:id/progress', ({ params, body }) => VD().progress(params.id, (body || {}).progress));
    po('/api/video/:id/fail', ({ params, body }) => VD().fail(params.id, (body || {}).error, !!(body || {}).requeue));
    po('/api/video/:id/retry', ({ params }) => VD().retry(params.id));
    this.add('DELETE', '/api/video/:id', ({ params }) => VD().remove(params.id));
    this.add('GET', '/api/video/:id/asset', ({ params, q, req, res }) => { try {
      const a = VD().asset(params.id, q.i, q.k || 'image'); const head = { 'content-type': a.mime, 'accept-ranges': 'bytes', 'cache-control': 'no-store', 'x-content-type-options': 'nosniff' };
      const m = /^bytes=(\d*)-(\d*)$/.exec(String(req.headers.range || ''));
      if (m && a.size) { let st = m[1] === '' ? Math.max(0, a.size - (+m[2] || 0)) : +m[1]; let en = m[1] !== '' && m[2] !== '' ? Math.min(+m[2], a.size - 1) : a.size - 1; if (st > en || st >= a.size) { res.writeHead(416, { 'content-range': `bytes */${a.size}` }); return res.end(); }
        res.writeHead(206, { ...head, 'content-range': `bytes ${st}-${en}/${a.size}`, 'content-length': en - st + 1 }); return fs.createReadStream(a.file, { start: st, end: en }).pipe(res); }
      res.writeHead(200, { ...head, 'content-length': a.size }); fs.createReadStream(a.file).pipe(res);
    } catch (e) { this.json(res, 404, { error: e.message }); } }, true);
    this.add('POST', '/api/video/:id/upload', async ({ params, q, req, res }) => { try { const buf = await readBody(req, 85 * 1024 * 1024); this.json(res, 200, await VD().upload(params.id, buf, q.mime)); } catch (e) { this.json(res, 400, { error: e.message }); } }, true);
    g('/api/debug/logs/export', () => c.debug.exportLog());   // 26.11.3 pro10：運行記錄下載（執行記錄＋錯誤記錄＋日誌，已遮蔽祕密）
    po('/api/platforms/discord/test', async ({ body }) => c.hub.connectors.discord.test(body.token));
    po('/api/backup', () => { const d = path.join(c.paths.backups, String(Date.now())); fs.mkdirSync(d, { recursive: true }); c.store.flush(); for (const f of ['db.json', 'vectors.json', 'settings.json']) { const s = path.join(c.paths.data, f); if (fs.existsSync(s)) fs.copyFileSync(s, path.join(d, f)); } return { path: d }; });
    g('/api/snapshots', () => c.fsx.snapshots());
    po('/api/snapshots/restore', ({ body }) => ({ restored: c.fsx.restoreSnapshot(body.id, 'app') }));
    g('/api/vector/stats', () => c.vector.stats());
    po('/api/vector/search', async ({ body }) => c.vector.search(body.query, { k: 10, min: 0 }));
    po('/api/vector/reindex', async () => ({ n: await c.vector.reindex() }));
    // ---- App 內對話（以管理員身分直接和 AI 說話，不需任何平台）----
    // 26.11.3 Revise4：App 對話也能「回覆」某則訊息（長按 → 回覆）
    const appQuote = (qt, me) => (qt && qt.text ? { id: String(qt.ts || ''), text: String(qt.text).slice(0, 1500), name: qt.role === 'assistant' ? 'AI' : me || '我', fromBot: qt.role === 'assistant' } : null);
    this.appQuote = appQuote;
    // ===== 26.11.3 pro2 邏輯閘轉換器共用狀態（App 與 AI 操作同一份）=====
    g('/api/logic/state', () => { if (!c.logic) throw new Error('邏輯閘轉換器沒有啟動'); return c.logic.get(); });
    po('/api/logic/state', ({ body }) => { if (!c.logic) throw new Error('邏輯閘轉換器沒有啟動'); return c.logic.put(body || {}, 'app'); });
    // 26.11.3 pro8 排程任務／長期任務（對話頁上方的下拉面板）：App 使用者就是管理員
    const taskOwner = () => { const p = c.users.admins()[0]; if (!p) throw new Error("還沒有管理員"); return p; };
    g('/api/tasks', () => c.tasks.list(taskOwner()));
    po('/api/tasks', ({ body }) => c.tasks.view(c.tasks.create(body || {}, taskOwner())));
    po('/api/tasks/system', ({ body }) => { const k = String((body || {}).key || ''); if (!/^(schedule\.(good_morning|good_night|diary|news)|brief)$/.test(k)) throw new Error('不能改這個項目'); c.settings.set(k + '.enabled', !!body.enabled, 'human'); return c.tasks.list(taskOwner()); });
    po('/api/tasks/:id', ({ params, body }) => c.tasks.view(c.tasks.act(params.id, (body || {}).action, taskOwner(), body || {})));
    // 26.11.3 pro7 電路工具、程式碼工具（App 畫面與 AI 共用同一份）
    g('/api/circuit/state', () => { if (!c.circuit) throw new Error('電路工具沒有啟動'); return c.circuit.get(); });
    po('/api/circuit/state', ({ body }) => { if (!c.circuit) throw new Error('電路工具沒有啟動'); return c.circuit.put(body || {}, 'app'); });
    g('/api/code/state', () => { if (!c.code) throw new Error('程式碼工具沒有啟動'); return c.code.get(); });
    po('/api/code/state', ({ body }) => { if (!c.code) throw new Error('程式碼工具沒有啟動'); return c.code.put(body || {}, 'app'); });
    po('/api/code/run', async ({ body }) => { if (!c.code) throw new Error('程式碼工具沒有啟動'); return c.code.run(body || {}); });
    po('/api/code/save', async ({ body }) => { if (!c.code) throw new Error('程式碼工具沒有啟動'); return c.code.save(body || {}); });

    // ===== 26.11.3 Revise7 手機代理（懸浮球下指令、步驟截圖、確認、連點器）=====
    const PA = () => { if (!c.phoneagent) throw new Error('手機代理沒有啟動'); return c.phoneagent; };
    g('/api/phone/state', () => PA().status());
    g('/api/phone/steps', () => ({ items: c.browser.showSteps() ? PA().steps.map((x) => PA().meta(x)) : [], show: c.browser.showSteps(), clear_at: c.browser._clearAt || 0 }));
    po('/api/phone/steps/clear', () => c.browser.clearSteps({ reason: 'manual' }));
    g('/api/phone/step/:seq', ({ params, res }) => { const x = PA().steps.find((s2) => s2.seq === +params.seq); if (!x || !x.jpeg) throw new Error('這一步沒有截圖（或已自動刪除）'); res.writeHead(200, { 'content-type': 'image/jpeg', 'cache-control': 'private, max-age=600', 'content-length': x.jpeg.length }); res.end(x.jpeg); });
    g('/api/phone/events', ({ req, res }) => { this.sseStart(res); const w = (ev, d) => res.write(`event: ${ev}\ndata: ${JSON.stringify(d)}\n\n`); const on = { step: (m) => { if (c.browser.showSteps()) w('step', m); }, pending: (m) => w('pending', m), done: (m) => w('done', m), cleared: (m) => w('cleared', m) }; for (const [k, f] of Object.entries(on)) PA().ev.on(k, f); const ka = setInterval(() => res.write(':ka\n\n'), 20000); req.on('close', () => { for (const [k, f] of Object.entries(on)) PA().ev.off(k, f); clearInterval(ka); }); });
    po('/api/phone/task', ({ body }) => PA().runTask(body.text, { game: !!body.game }));
    // 26.11.3 pro10：巨集、計時器、本機音樂
    g('/api/phone/macros', () => ({ macros: Object.entries(PA().macros()).map(([name, m]) => ({ name, steps: m.steps })), state: PA().macroState() }));
    po('/api/phone/macro', async ({ body }) => { const b = body || {}; if (b.action === 'save') return PA().macroSave(b.name, b.steps); if (b.action === 'delete') return PA().macroDelete(b.name); if (b.action === 'stop') return PA().macroStop(); return PA().macroStart({ name: b.steps ? '' : b.name, steps: b.steps, repeat: b.repeat, gap_ms: b.gap_ms }); });
    g('/api/timers', () => ({ timers: c.timers.list(), now: Date.now() }));
    po('/api/timers', ({ body }) => c.timers.view(c.timers.create(body || {}, c.users.admins()[0] || null)));
    po('/api/timers/cancel', ({ body }) => ({ cancelled: c.timers.cancel((body || {}).id) }));
    po('/api/timers/stop_ring', async () => ({ ok: await c.timers.stopRing() }));
    g('/api/music', async () => c.phone.musicStatus());
    po('/api/music/list', async ({ body }) => c.phone.musicList((body || {}).q, (body || {}).limit || 100));
    po('/api/music/play', async ({ body }) => c.phone.musicPlay(body || {}));
    po('/api/music/control', async ({ body }) => c.phone.musicControl(String((body || {}).action || '')));
    po('/api/phone/stop', async () => { const r = PA().stop(); try { await PA().clickerStop(); } catch { /* 沒在連點 */ } return r; });
    po('/api/phone/confirm', ({ body }) => PA().decide(body.id, body.allow === true));
    // 26.11.3 pro2.1：手機資訊（App 自己讀，不用 Termux）＋交通資料金鑰
    g('/api/phone/device', async () => { const P = c.phone; const h = await P.nativeHealth(); let st = null; if (P.ready()) { try { st = await P.status(); } catch (e) { st = { error: e.message }; } } return { native: P.nativeReady(), health: h, termux: P.termuxReady(), status: st, transit: c.transit ? c.transit.state() : null }; });
    po('/api/transit/config', ({ body }) => { for (const k of ['tdx_id', 'tdx_secret', 'google_maps_key']) if (typeof body[k] === 'string' && (body[k].trim() || body.clear)) c.settings.set('transit.' + k, body[k].trim().slice(0, 300), 'human'); if (body.clear === true) for (const k of ['tdx_id', 'tdx_secret', 'google_maps_key']) c.settings.set('transit.' + k, '', 'human'); c.transit._tok = null; return c.transit.state(); });
    po('/api/transit/nearby', async ({ body }) => { const T = c.transit; const k = body.kind || 'all'; const out = []; const opt = { at: body.at, dest: body.dest };
      if (k === 'bus' || k === 'all') out.push((await T.nearby(opt).catch((e) => ({ text: '公車：' + e.message }))).text);
      if (k === 'rail' || k === 'all') out.push((await T.stations(opt).catch((e) => ({ text: '車站：' + e.message }))).text);
      if (k === 'bike' || k === 'all') out.push((await T.bikes({ at: body.at }).catch((e) => ({ text: '共享單車：' + e.message }))).text);
      return { text: out.join('\n\n') }; });
    po('/api/phone/settings', ({ body }) => { if (body.confirm_send !== undefined) c.settings.set('phone_agent.confirm_send', !!body.confirm_send, 'human'); if (body.step_ttl_min !== undefined) c.settings.set('phone_agent.step_ttl_min', Math.min(240, Math.max(1, +body.step_ttl_min || 30)), 'human'); return PA().cfg(); });
    po('/api/phone/screen', async () => { const s2 = await PA().screen(); return { text: PA().fmt(s2) }; });
    po('/api/phone/clicker', async ({ body }) => (body.action === 'stop' ? PA().clickerStop() : PA().clickerState()));

    // ===== 26.11.3 Revise6 會議監聽 =====
    const MT = () => { if (!c.meeting) throw new Error('會議監聽功能沒有啟動（開發者 → 除錯 看原因）'); return c.meeting; };
    const DV = () => { if (!c.dvoice) throw new Error('Discord 收音功能沒有啟動'); return c.dvoice; };
    g('/api/meetings', () => ({ items: MT().list(), discord: c.dvoice ? c.dvoice.state() : null, stt: c.speech ? c.speech.routes() : [] }));
    g('/api/meetings/voice-worker', () => DV().state());
    po('/api/meetings/voice-worker/install', () => DV().install());
    g('/api/meetings/discord/channels', async () => { const d = c.hub && c.hub.connectors.discord; if (!d || !d.ready) throw new Error('Discord Bot 還沒連線'); return { items: await d.findVoiceChannel('') }; });
    po('/api/meetings/discord/join', async ({ body }) => DV().joinAndListen({ channel: body.channel, guild_id: body.guild_id || '', title: body.title || '', by: 'admin' }));
    po('/api/meetings', ({ body }) => MT().start({ title: body.title || '', source: 'app', by: 'admin' }));
    g('/api/meetings/:id', ({ params }) => MT().state(params.id));
    g('/api/meetings/:id/markdown', ({ params, q }) => ({ text: MT().markdown(params.id, { transcript: q.transcript !== '0' }) }));
    po('/api/meetings/:id/audio', ({ params, body }) => MT().audio(params.id, { mime: String(body.mime || 'audio/wav'), data: body.data, at: body.at }));
    po('/api/meetings/:id/text', ({ params, body }) => MT().text(params.id, { text: body.text, at: body.at }));
    po('/api/meetings/:id/stop', ({ params }) => { const m = MT().get(params.id); if (m.status === 'live') MT().stop(params.id).catch((e) => log.warn(e.message)); return { ok: true, status: 'processing' }; });
    po('/api/meetings/:id/summarize', ({ params }) => MT().summarizeNow(params.id));
    po('/api/meetings/:id/rename', ({ params, body }) => MT().rename(params.id, body.title));
    po('/api/meetings/:id/export', async ({ params, body }) => { const m = MT().get(params.id); const f = ['docx', 'pdf', 'md', 'txt'].includes(body.format) ? body.format : 'docx'; const md = MT().markdown(m, { transcript: body.transcript !== false }); return c.filegen.make({ name: m.title, format: f, title: '', content: md }, 'admin'); });
    de('/api/meetings/:id', ({ params }) => MT().remove(params.id));

    // ===== 26.11.3 Revise5 語音：麥克風（語音轉文字）＋語音模式（文字轉語音、語音包）=====
    const V = () => { if (!c.voice) throw new Error('語音功能沒有啟動（開發者 → 除錯 看原因）'); return c.voice; };
    g('/api/voice/state', () => V().state());
    po('/api/voice/settings', ({ body }) => V().update(body || {}));
    po('/api/voice/transcribe', async ({ body }) => {
      const b = body || {}; if (!b.data) throw new Error('沒有收到聲音'); if (!c.speech || !c.speech.enabled()) return { ok: false, code: 'no_stt', error: '管理員已關閉語音轉文字' };
      if (!c.speech.routes().length) return { ok: false, code: 'no_stt', error: '沒有雲端語音辨識金鑰（模型頁加 Groq／OpenAI／Gemini 任一家），改用手機內建辨識' };
      const r = await c.speech.transcribe({ mime: String(b.mime || 'audio/wav'), data: String(b.data) }); return { ok: true, text: r.text, provider: r.provider };
    });
    po('/api/voice/tts', async ({ body }) => {
      const { speakable } = require('../services/voice'); const b = body || {}; const raw = b.raw ? String(b.text || '') : speakable(b.text, +V().cfg().max_chars || 1200);
      const r = await V().tts(raw, b.pack || ''); if (r.device) return { ok: true, device: true, text: r.text, rate: r.rate, pitch: r.pitch, voice: r.voice };
      return { ok: true, mime: r.mime, data: r.buf.toString('base64'), provider: r.provider };
    });
    po('/api/voice/speakable', ({ body }) => { const { speakable, chunks } = require('../services/voice'); const t = speakable((body && body.text) || '', +V().cfg().max_chars || 1200); return { text: t, chunks: chunks(t) }; });
    po('/api/chat', async ({ body }) => {
      let p = c.users.admins()[0]; if (!p) throw new Error('還沒有管理員。到「用戶」頁按「建立 App 管理員」，或在平台私訊 /claim 密碼。');
      if (!p.identities.some((i) => i.platform === 'app')) c.users.attach(p.id, 'app', 'local', p.name);
      const img = body.image && body.image.data ? [{ mime: /^image\/(png|jpeg|webp)$/.test(body.image.mime) ? body.image.mime : 'image/jpeg', data: String(body.image.data) }] : [];
      if (img.length && img[0].data.length > 14e6) throw new Error('照片太大');
      const msg = { platform: 'app', chatId: 'app', uid: 'local', userName: p.name, text: String(body.text || ''), appImages: [], quote: appQuote(body.quote, p.name), _t0: Date.now() }; this.appBusy = msg;
      // 26.11.3 Revise8：App 傳檔案給 AI（像 LINE 一樣）：圖片照舊直接顯示，其他檔案存到 inbox 變成檔案卡
      if (body.file && body.file.data) {
        const f = body.file; const mime = String(f.mime || require('../platforms/common').mimeOf(f.name));
        if (/^image\/(png|jpeg|webp)$/.test(mime) && !img.length) img.push({ mime, data: String(f.data) });
        else { const sv = c.hub.saveInbox(p, { name: f.name, mime, data: f.data }); msg._storeText = msg.text; msg._userFiles = [{ id: sv.rec.id, name: sv.rec.name, size: sv.rec.size, mime: sv.rec.mime }]; msg.text = `${msg.text}${msg.text ? '\n' : ''}${sv.note}`; }
      }
      let out; try { out = await c.agent.handle({ person: p, msg, images: img, group: false, scope: 'dm_' + p.id }); } finally { if (this.appBusy === msg) this.appBusy = null; } return { text: out, images: msg.appImages, files: (msg._files || []).map((f) => ({ id: f.id, name: f.name, size: f.size, mime: f.mime })), user_files: msg._userFiles || [] };
    });
    g('/api/chat/progress', () => require('../platforms/hub').Hub.progress(this.appBusy) || { idle: true });
    // 對話頁：讀回管理員私訊的歷史（LINE／Telegram／Discord／App 的私訊共用同一份）
    g('/api/chat/history', ({ q }) => { const p = c.users.admins()[0]; if (!p) return { items: [], admin: false }; const n = Math.max(1, Math.min(+q.limit || 40, 200));
      const rows = q.before ? c.store.page('dm_' + p.id, +q.before, n) : c.store.tail('dm_' + p.id, n);
      return { admin: true, name: p.name, more: rows.length >= n, items: rows.map((m) => ({ role: m.role, text: m.text, ts: m.ts, platform: m.platform || '', imgs: m.imgs || [], files: m.files || [], ...(m.quote ? { quote: m.quote } : {}) })) }; });
    g('/api/chat/search', ({ q }) => { const p = c.users.admins()[0]; if (!p || !String(q.q || '').trim()) return { items: [] }; return { items: c.store.searchMessages('dm_' + p.id, String(q.q).trim(), 30).map((m) => ({ role: m.role, text: m.text, ts: m.ts, platform: m.platform || '' })) }; });
    this.add('GET', '/api/chat/media/:name', ({ params, res }) => { const f = c.chatmedia.get(params.name); if (!f) { res.writeHead(404); return res.end('not found'); } res.writeHead(200, { 'content-type': f.mime, 'content-length': f.buf.length, 'cache-control': 'private, max-age=86400' }); res.end(f.buf); }, true);
    // 26.11.3 Revise8：在 App 裡直接看／播放（影片、音訊、圖片、PDF），支援 Range（影片可以拖進度）
    this.add('GET', '/api/files/view/:id', ({ params, req, res }) => {
      const f = c.filegen.get(params.id); if (!f) { res.writeHead(404); return res.end('not found'); }
      const full = require('path').join(c.paths.workspace, f.path); let st; try { st = require('fs').statSync(full); } catch { res.writeHead(404); return res.end('not found'); }
      const inline = /^(video|audio|image)\//.test(f.mime) || f.mime === 'application/pdf'; const type = inline ? f.mime : 'application/octet-stream';
      const m = /^bytes=(\d*)-(\d*)$/.exec(req.headers.range || '');
      if (m) { const start = m[1] ? +m[1] : Math.max(0, st.size - +m[2]); const end = m[1] && m[2] ? Math.min(+m[2], st.size - 1) : st.size - 1; if (start >= st.size || start > end) { res.writeHead(416, { 'content-range': `bytes */${st.size}` }); return res.end(); }
        res.writeHead(206, { 'content-type': type, 'content-length': end - start + 1, 'content-range': `bytes ${start}-${end}/${st.size}`, 'accept-ranges': 'bytes', 'cache-control': 'private, max-age=3600', 'x-content-type-options': 'nosniff' }); return require('fs').createReadStream(full, { start, end }).pipe(res); }
      res.writeHead(200, { 'content-type': type, 'content-length': st.size, 'accept-ranges': 'bytes', 'cache-control': 'private, max-age=3600', 'x-content-type-options': 'nosniff' }); require('fs').createReadStream(full).pipe(res);
    }, true);
    this.add('GET', '/api/files/out/:id', ({ params, res }) => { const f = c.filegen.get(params.id); if (!f) { res.writeHead(404); return res.end('not found'); } const b = c.filegen.read(f); res.writeHead(200, { 'content-type': f.mime, 'content-length': b.length, 'content-disposition': `attachment; filename*=UTF-8''${encodeURIComponent(f.name)}` }); res.end(b); }, true);
    // ---- 瀏覽器（AI 與管理員共用）----
    const B = c.browser;
    g('/api/browser/state', async () => { const st = B.status(); let tabs = []; let google = null; if (st.connected) { tabs = await B.tabs(); try { google = await Promise.race([c.google.status(), new Promise((r) => setTimeout(() => r(null), 2500))]); } catch { /* ignore */ } } return { ...st, tabs, google, vault: c.vault.list(), page: st.connected ? await B.pageInfo() : null }; });
    po('/api/browser/start', async () => { await B.run(async () => {}, 'start'); return B.status(); });
    po('/api/browser/stop', async () => { await B.shutdown(); return B.status(); });
    po('/api/browser/takeover', () => { B.takeOver(); return B.status(); });
    po('/api/browser/giveback', async () => B.giveBack());
    g('/api/browser/frame', async ({ res }) => {
      try { const buf = await B.frame(); res.writeHead(200, { 'content-type': 'image/jpeg', 'cache-control': 'no-store', 'content-length': buf.length }); res.end(buf); }
      catch (e) { if (!res.headersSent) this.json(res, 503, { error: e.message }); }
    });
    // 26.11.3 Revise6：步驟串流（SSE）＋每一步的截圖（Manus 式時間軸，可回放）
    g('/api/browser/events', ({ req, res }) => {
      this.sseStart(res); const w = (ev, d) => res.write(`event: ${ev}\ndata: ${JSON.stringify(d)}\n\n`);
      w('hello', { step: B.stepMeta(B.lastStep()), control: B.control, connected: !!(B.cdp && B.cdp.open) });
      const onStep = (m) => { if (B.showSteps()) w('step', m); }; const onClear = (m) => w('cleared', m); const onAt = (m) => w('clear_at', m); B.ev.on('step', onStep); B.ev.on('cleared', onClear); B.ev.on('clear_at', onAt); const ka = setInterval(() => res.write(':ka\n\n'), 20000);
      req.on('close', () => { B.ev.off('step', onStep); B.ev.off('cleared', onClear); B.ev.off('clear_at', onAt); clearInterval(ka); });
    });
    g('/api/browser/steps', () => ({ items: B.showSteps() ? B.steps.map((x) => B.stepMeta(x)) : [], show: B.showSteps(), clear_at: B._clearAt || 0 }));
    // 26.11.3 pro2.1：刪除／隱藏圖片紀錄
    po('/api/browser/steps/clear', () => B.clearSteps({ reason: 'manual' }));
    de('/api/browser/step/:seq', ({ params }) => B.deleteStep(params.seq));
    po('/api/browser/steps/settings', ({ body }) => { if (body.show !== undefined) c.settings.set('browser.show_steps', !!body.show, 'human'); if (body.clear_after_min !== undefined) c.settings.set('browser.clear_after_task_min', Math.max(0, Math.min(1440, Math.floor(+body.clear_after_min || 0))), 'human'); B.ev.emit('cleared', { reason: 'settings' }); return { show: B.showSteps(), clear_after_min: B.status().clear_after_min }; });
    g('/api/browser/step/:seq', ({ params, res }) => {
      const x = params.seq === 'last' ? B.lastStep() : B.steps.find((s) => s.seq === +params.seq); if (!x) throw new Error('這一步的畫面已經不在了（只保留最近 80 步）');
      res.writeHead(200, { 'content-type': 'image/jpeg', 'cache-control': 'private, max-age=3600', 'content-length': x.jpeg.length }); res.end(x.jpeg);
    });
    po('/api/browser/input', async ({ body }) => {
      if (B.control !== 'user') throw new Error('請先按「接手」才能操作畫面（AI 控制中）');
      return B.run(async () => {
        const vp = await B.viewport(); const X = (f) => Math.round(Math.min(1, Math.max(0, +f)) * vp.w), Y = (f) => Math.round(Math.min(1, Math.max(0, +f)) * vp.h);
        if (body.type === 'click') await B.clickAt(X(body.x), Y(body.y), { dbl: !!body.dbl, right: !!body.right });
        else if (body.type === 'scroll') await B.scroll(+body.dy > 0 ? 'down' : 'up', Math.abs(+body.dy) || 300, X(body.x ?? 0.5), Y(body.y ?? 0.5));
        else if (body.type === 'text') await B.insertText(String(body.text || ''));
        else if (body.type === 'key') await B.key(String(body.key));
        else if (body.type === 'goto') { const u = String(body.url || '').trim(); if (!u) throw new Error('網址不能空白'); await B.goto(/^[\w.-]+\.[a-z]{2,}|^[a-z]+:/i.test(u) ? u : 'https://www.google.com/search?q=' + encodeURIComponent(u)); }
        else if (body.type === 'back') await B.history(-1); else if (body.type === 'forward') await B.history(1); else if (body.type === 'reload') await B.reload();
        else if (body.type === 'tab') { if (body.action === 'new') await B.newTab(body.url || ''); else if (body.action === 'switch') await B.switchTab(body.id); else if (body.action === 'close') await B.closeTab(body.id); }
        else throw new Error('不認得的操作'); B.lastFrameAt = 0;
        // 你接手時：點、捲、按鍵、換頁都算一步；單純打字不算（按 Enter 才算）
        const lbl = { click: '你點擊畫面', scroll: '你捲動頁面', key: `你按 ${body.key}`, goto: '你開啟網址', back: '你回上一頁', forward: '你到下一頁', reload: '你重新整理', tab: '你切換分頁' }[body.type];
        if (lbl) await B.snapStep(lbl, body.type === 'click' ? B._mark : null); B._mark = null; B.taskDone(); return { ok: true };
      }, 'input');
    });
    // ---- Google Workspace API 通道（OAuth／Service Account；憑證加密，回傳不含任何 token）----
    const G = c.gws;
    g('/api/google/state', () => G.state());
    po('/api/google/config', ({ body }) => { for (const k of ['client_id', 'client_secret']) if (typeof body[k] === 'string' && body[k].trim() && !/^•/.test(body[k])) c.settings.set('google.' + k, body[k].trim()); for (const k of ['send_requires_approval']) if (typeof body[k] === 'boolean') c.settings.set('google.' + k, body[k]); if (body.daily_send_cap !== undefined) c.settings.set('google.daily_send_cap', Math.max(1, Math.min(500, +body.daily_send_cap || 50))); c.store.audit('app', 'google.config', ''); return G.state(); });
    po('/api/google/auth-url', () => G.authUrl());
    po('/api/google/auth-code', async ({ body }) => G.authExchange(body.code || body.url));
    po('/api/google/refresh-token', async ({ body }) => G.setRefreshToken(body.token));
    po('/api/google/service-account', async ({ body }) => G.setServiceAccount(body.json, body.subject));
    po('/api/google/disconnect', async () => G.disconnect());
    // ---- Termux 環境（完整 Linux＋真 Chromium）----
    const T = c.termux; const rawText = (res, text, type) => { const b = Buffer.from(text); res.writeHead(200, { 'content-type': type, 'content-length': b.length, 'cache-control': 'no-store' }); res.end(b); };
    g('/api/termux/state', () => T.state());
    g('/api/termux/setup.sh', ({ req, res }) => rawText(res, T.setupScript('http://' + String(req.headers.host || ''), c.token), 'text/x-shellscript; charset=utf-8'));
    g('/api/termux/bridge.js', ({ res }) => rawText(res, T.bridgeScript(), 'application/javascript; charset=utf-8'));
    po('/api/termux/register', ({ body }) => T.register(body.url, body.token));
    po('/api/termux/config', ({ body }) => { if (typeof body.url === 'string' && body.url.trim()) c.settings.set('termux.url', body.url.trim()); if (typeof body.token === 'string' && body.token.trim() && !/^•/.test(body.token)) c.settings.set('termux.token', body.token.trim()); if (typeof body.allow_remote === 'boolean') c.settings.set('termux.allow_remote', body.allow_remote); if (typeof body.full_access === 'boolean') c.settings.set('termux.full_access', body.full_access); c.store.audit('app', 'termux.config', ''); return T.state(); });
    po('/api/termux/test', async () => ({ ok: true, ...(await T.health()) }));
    po('/api/termux/exec', async ({ body }) => T.exec(String(body.cmd || ''), { timeout_s: +body.timeout_s || 60 }));
    po('/api/termux/chromium', async ({ body }) => { const a = body.action; if (a === 'use') return T.useAsBrowser(); if (a === 'restore') return T.restoreBrowser(); if (a === 'stop') return T.chromiumStop(); if (a === 'start') return T.chromiumStart(); return T.chromiumStatus(); });
    // 需要登入的別人表單：貼上你已登入 Google 的 Cookie（加密存放，AI 看不到，只會送給 google.com）
    g('/api/google/form-cookie', () => G.cookieState());
    po('/api/google/form-cookie', ({ body }) => G.setFormCookie(body.cookie));
    de('/api/google/form-cookie', () => G.clearFormCookie());
    po('/api/google/test', async () => { const me = await G.api('GET', 'https://gmail.googleapis.com/gmail/v1/users/me/profile'); return { ok: true, email: me.emailAddress, messages: me.messagesTotal }; });
    g('/api/vault', () => ({ items: c.vault.list() }));
    po('/api/vault', ({ body }) => { c.store.audit('app', 'vault.save', String(body.name || '')); return c.vault.upsert(body); });
    de('/api/vault/:id', ({ params }) => { c.store.audit('app', 'vault.delete', params.id); return { ok: c.vault.remove(params.id) }; });
    po('/api/image-test', async () => { const r = await c.imagegen.generate({ prompt: 'a small friendly robot waving, flat illustration, white background' }); return { ok: true, provider: r.provider, bytes: r.buf.length, mime: r.mime, data: r.buf.toString('base64') }; });
  }
  status() {
    const c = this.ctx; const mem = c.store.countMessages();
    return { version: VERSION, time: Date.now(), supervisor: c.supervisor.status(), platforms: c.hub.status(), tunnel: c.tunnel.info(), model: { provider: c.settings.get('model.provider'), label: ((llm.PROVIDERS[c.settings.get('model.provider')] || {}).label || ''), fallback_provider: c.settings.get('model.fallback_provider', ''), name: c.settings.get('model.name'), has_key: require('../llm').hasKey(c.settings) },
      usage: c.usage.summary(), memory: { ...mem, facts: c.store.db.facts.length, vectors: c.store.vec.length, persons: Object.keys(c.store.db.persons).length, sheets: c.store.db.sheets.length, disk_bytes: c.fsx.usage() },
      approvals_pending: c.approvals.pending().length, notifications_unread: c.store.db.notifications.filter((n) => !n.read).length, has_admin: c.users.hasAdmin(), tz: c.settings.get('tz') };
  }
}
module.exports = { Api };
