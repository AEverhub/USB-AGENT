'use strict';
/** 對外 Webhook 伺服器：只開 /hook/line、/health 與 /m/<隨機碼>（LINE 抓圖用），其餘一律 404。內網穿透的公開網址指向這裡。 */
const http = require('http');
const { logger } = require('../core/log');
const log = logger('hooks');

class Hooks {
  constructor(ctx) { this.ctx = ctx; this.name = 'hooks'; this.server = null; }
  async start() {
    const port = +this.ctx.settings.get('dev.hook_port', 8787), host = this.ctx.settings.get('dev.hook_bind', '127.0.0.1'); if (!port) return;
    this.server = http.createServer((req, res) => {
      const p = req.url.split('?')[0];
      if (p.startsWith('/net/deploy/') && this.ctx.deploy) return void this.ctx.deploy.serve(req, res, p);   // 伺服器安裝：一次性代碼下載
      if (p.startsWith('/net/') && !this.ctx.link) { res.writeHead(503); return res.end(); }
      if (p.startsWith('/net/')) return void this.ctx.link.handleHttp(req, res, p, new URL(req.url, 'http://x')).catch(() => { try { res.writeHead(500); res.end(); } catch { /* ignore */ } });
      if (p === '/health') { res.writeHead(200, { 'content-type': 'text/plain' }); return res.end('ok'); }
      if (p === '/hook/line' && req.method === 'POST') {
        const chunks = []; let n = 0; req.on('data', (d) => { n += d.length; if (n > 2e6) req.destroy(); else chunks.push(d); });
        req.on('end', () => { const raw = Buffer.concat(chunks).toString('utf8');
          this.ctx.hub.connectors.line.handleWebhook(raw, req.headers['x-line-signature']).then(() => { res.writeHead(200); res.end('ok'); }).catch((e) => { log.warn('LINE webhook：' + e.message); res.writeHead(/簽章/.test(e.message) ? 401 : 400); res.end(e.message); }); });
        return;
      }
      if (req.method === 'GET' && p.startsWith('/m/')) {        // 公開圖片（給 LINE 抓取）：32 字元隨機碼，24 小時後刪除
        const f = this.ctx.media && this.ctx.media.serve(p.slice(3));
        if (!f) { res.writeHead(404); return res.end('not found'); }
        const name = p.slice(3); const meta = this.ctx.media.meta(name); const dl = /[?&]dl=1/.test(req.url) || f.download;
        const disp = dl ? { 'content-disposition': `attachment; filename*=UTF-8''${encodeURIComponent((meta && meta.name) || name)}` } : {};
        // 26.11.3 Revise8：影片／音訊支援 Range（可以拖進度）
        const rg = /^bytes=(\d*)-(\d*)$/.exec(req.headers.range || '');
        if (rg && !dl) { const L = f.buf.length; const s = rg[1] ? +rg[1] : Math.max(0, L - +rg[2]); const e = rg[1] && rg[2] ? Math.min(+rg[2], L - 1) : L - 1; if (s >= L || s > e) { res.writeHead(416, { 'content-range': `bytes */${L}` }); return res.end(); } res.writeHead(206, { 'content-type': f.mime, 'content-length': e - s + 1, 'content-range': `bytes ${s}-${e}/${L}`, 'accept-ranges': 'bytes', 'x-content-type-options': 'nosniff' }); return res.end(f.buf.subarray(s, e + 1)); }
        res.writeHead(200, { 'content-type': f.mime, 'content-length': f.buf.length, 'cache-control': 'public, max-age=3600', 'accept-ranges': 'bytes', 'x-content-type-options': 'nosniff', ...disp }); return res.end(f.buf);
      }
      if (req.method === 'GET' && p.startsWith('/d/')) {        // 26.11.3 Revise8：「確認下載」頁（LINE 傳檔用）
        const html = this.ctx.media && this.ctx.media.downloadPage(p.slice(3)); if (!html) { res.writeHead(404, { 'content-type': 'text/plain; charset=utf-8' }); return res.end('檔案不存在或已過期（連結 24 小時內有效）'); }
        res.writeHead(200, { 'content-type': 'text/html; charset=utf-8', 'cache-control': 'no-store', 'x-content-type-options': 'nosniff', 'content-security-policy': "default-src 'none'; img-src 'self'; media-src 'self'; style-src 'unsafe-inline'", 'referrer-policy': 'no-referrer' }); return res.end(html);
      }
      if (p === '/' ) { res.writeHead(200, { 'content-type': 'text/plain; charset=utf-8' }); return res.end('Agent中控中心 webhook endpoint'); }
      res.writeHead(404); res.end('not found');
    });
    await new Promise((ok, bad) => { this.server.once('error', bad); this.server.listen(port, host, ok); }); log.info(`Webhook 伺服器 ${host}:${port}`);
  }
  async stop() { if (this.server) { await new Promise((r) => this.server.close(r)); this.server = null; } }
  health() { return !!this.server || !this.ctx.settings.get('dev.hook_port'); }
}
module.exports = { Hooks };
