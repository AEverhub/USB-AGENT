'use strict';
/**
 * Google Workspace「API 通道」：完全不經過瀏覽器／CDP，所以不會被網頁前端的自動化偵測、
 * WebView 登入封鎖（disallowed_useragent）、人機驗證、改版後的 DOM 變動擋下。
 *
 *  驗證：OAuth 2.0 使用者授權（refresh token，管理員在自己的真實瀏覽器同意一次）
 *        或 Service Account（Workspace 網域管理員啟用網域委派時可代表使用者）。
 *  服務：Gmail（寄／草稿／搜尋／讀／回覆）、Google 表單（免登入公開表單直接 HTTP 送出；自己的表單用 Forms API）、
 *        Sheets、Docs、Drive、Calendar、Tasks，以及 google_api 通用呼叫（任何 *.googleapis.com）。
 *  安全：憑證以保險箱同一把金鑰 AES-256-GCM 加密；AI 看不到 token／secret；寄信預設要管理員審批＋每日上限；
 *        通用呼叫只允許 googleapis.com，且非 GET 一律要審批。
 */
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { sleep, clip } = require('../core/util');
const { logger } = require('../core/log');
const log = logger('gws');

const S = 'https://www.googleapis.com/auth/';
const DEFAULT_SCOPES = ['openid', 'email', S + 'gmail.modify', S + 'gmail.compose', S + 'drive', S + 'spreadsheets', S + 'documents', S + 'calendar', S + 'tasks', S + 'forms.body', S + 'forms.responses.readonly'];
const REDIRECT = 'http://127.0.0.1:53682/';
const GOOGLE_HOST = /^([a-z0-9-]+\.)*googleapis\.com$/i;
const b64u = (b) => Buffer.from(b).toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
const pad = (n) => String(n).padStart(2, '0');
const today = () => { const d = new Date(Date.now() + 8 * 3600e3); return `${d.getUTCFullYear()}-${pad(d.getUTCMonth() + 1)}-${pad(d.getUTCDate())}`; };
const norm = (s) => String(s ?? '').normalize('NFKC').toLowerCase().replace(/[\s.,;:!?()（）、，。：；！？"'「」『』\-_/\\*＊]+/g, '');
function pick(labels, want) {
  const w = norm(want); if (!w) return -1; let i = labels.findIndex((l) => norm(l) === w); if (i >= 0) return i;
  i = labels.findIndex((l) => norm(l).length >= 2 && (norm(l).startsWith(w) || w.startsWith(norm(l)))); if (i >= 0) return i;
  return labels.findIndex((l) => norm(l).length >= 2 && (norm(l).includes(w) || w.includes(norm(l))));
}
/** 取出網址或純 ID 裡的檔案 ID（Docs／Sheets／Drive／Forms 編輯網址） */
function idFrom(s) { s = String(s || '').trim(); const m = /\/d\/(?:e\/)?([A-Za-z0-9_-]{10,})/.exec(s) || /[?&]id=([A-Za-z0-9_-]{10,})/.exec(s); return m ? m[1] : s; }
const noCRLF = (v, name) => { v = String(v ?? ''); if (/[\r\n]/.test(v)) throw new Error(`${name} 不能含換行`); return v; };
const encHeader = (v) => (/^[\x20-\x7e]*$/.test(v) ? v : `=?UTF-8?B?${Buffer.from(v, 'utf8').toString('base64')}?=`);
const wrap76 = (b64) => b64.replace(/.{1,76}/g, '$&\r\n').trimEnd();
/** 逗號／分號／換行分隔；沒有 <> 的純位址允許用空白分隔；"王小明 <w@x.com>" 這種顯示名稱不會被切開 */
const emailList = (v) => (Array.isArray(v) ? v : String(v || '').split(/[,;，；\n]+/)).flatMap((x) => { x = String(x).trim(); return x.includes('<') || !/\s/.test(x) ? [x] : x.split(/\s+/); }).filter(Boolean);
const addrHeader = (l) => l.map((a) => { noCRLF(a, '收件人'); const m = /^(.*)<([^<>]+)>$/.exec(a); if (m) return `${encHeader(m[1].trim().replace(/^"|"$/g, ''))} <${m[2].trim()}>`; if (!/^[^\s@<>]+@[^\s@<>]+$/.test(a)) throw new Error(`收件人格式不正確：${a}`); return a; }).join(', ');

class GWorkspace {
  constructor(ctx) {
    this.ctx = ctx; this.file = path.join(ctx.paths.data, 'google-auth.json'); this.metaFile = path.join(ctx.paths.data, 'google-meta.json'); this.cookieFile = path.join(ctx.paths.data, 'google-cookie.json');
    this._fetch = ctx.gwsFetch || ((...a) => fetch(...a)); this.auth = this._load(); this.meta = this._loadMeta(); this.tok = null; this._tokP = null; this.pendingAuth = null;
  }
  get cfg() { return this.ctx.settings.get('google') || {}; }
  enabled() { return this.cfg.enabled !== false; }
  // ---------- 憑證存取（加密） ----------
  _load() { try { return JSON.parse(this.ctx.vault.dec(fs.readFileSync(this.file, 'utf8'))); } catch { return null; } }
  _save() { if (!this.auth) { try { fs.rmSync(this.file, { force: true }); } catch { /* ignore */ } return; } fs.writeFileSync(this.file + '.tmp', this.ctx.vault.enc(JSON.stringify(this.auth)), { mode: 0o600 }); fs.renameSync(this.file + '.tmp', this.file); }
  _loadMeta() { try { return JSON.parse(fs.readFileSync(this.metaFile, 'utf8')); } catch { return { day: '', sent: 0 }; } }
  _saveMeta() { try { fs.writeFileSync(this.metaFile, JSON.stringify(this.meta)); } catch { /* ignore */ } }
  ready() { return this.enabled() && !!(this.auth && (this.auth.refresh_token || this.auth.sa)); }
  state() {
    const a = this.auth; const c = this.cfg;
    return { enabled: this.enabled(), connected: this.ready(), mode: a ? (a.sa ? 'service_account' : 'oauth') : '', email: a ? (a.email || (a.sa && a.sa.client_email) || '') : '', subject: a && a.sa ? a.subject || '' : '',
      client_id_set: !!c.client_id, client_secret_set: !!c.client_secret, connected_at: a ? a.at : 0, scopes: a ? (a.scopes || []).length : 0,
      send_requires_approval: c.send_requires_approval !== false, cookie: this.cookieState(), form_cookie: this.cookieState(), send_cap: +c.daily_send_cap || 50, sent_today: this.meta.day === today() ? this.meta.sent : 0, redirect: REDIRECT };
  }
  need() { if (!this.enabled()) throw new Error('管理員已關閉 Google API 通道'); if (!this.ready()) throw new Error('Google API 還沒連線。請管理員到 App「瀏覽器」頁的「Google Workspace API」卡片完成一次授權（不用瀏覽器自動登入）。'); }

  // ---------- OAuth：在「你自己的」瀏覽器同意一次，把網址貼回來 ----------
  authUrl() {
    const c = this.cfg; if (!c.client_id || !c.client_secret) throw new Error('請先填 OAuth 用戶端 ID 與密鑰（Google Cloud Console → API 和服務 → 憑證 → 建立 OAuth 用戶端 ID → 類型選「電腦版應用程式」）');
    const verifier = b64u(crypto.randomBytes(32)); const state = b64u(crypto.randomBytes(12)); this.pendingAuth = { verifier, state, ts: Date.now() };
    const q = new URLSearchParams({ client_id: c.client_id, redirect_uri: REDIRECT, response_type: 'code', scope: (c.scopes && c.scopes.length ? c.scopes : DEFAULT_SCOPES).join(' '), access_type: 'offline', prompt: 'consent', include_granted_scopes: 'true',
      state, code_challenge: b64u(crypto.createHash('sha256').update(verifier).digest()), code_challenge_method: 'S256' });
    return { url: 'https://accounts.google.com/o/oauth2/v2/auth?' + q, redirect: REDIRECT };
  }
  /** 收到的是「授權後那個打不開的網址」或單純的 code 都可以 */
  async authExchange(input) {
    const p = this.pendingAuth; if (!p || Date.now() - p.ts > 30 * 60e3) throw new Error('授權流程已逾時，請重新產生授權連結');
    let code = String(input || '').trim(); try { const u = new URL(code); if (u.searchParams.get('error')) throw new Error('Google 回報：' + u.searchParams.get('error')); const st = u.searchParams.get('state'); if (st && st !== p.state) throw new Error('state 不符，請重新產生授權連結'); code = u.searchParams.get('code') || code; } catch (e) { if (/Google 回報|state/.test(e.message)) throw e; }
    if (!code) throw new Error('沒有找到授權碼 code');
    const c = this.cfg; const r = await this._token({ grant_type: 'authorization_code', code, redirect_uri: REDIRECT, client_id: c.client_id, client_secret: c.client_secret, code_verifier: p.verifier });
    if (!r.refresh_token) throw new Error('Google 沒有給 refresh token。請到 https://myaccount.google.com/permissions 移除此 App 後重新授權。');
    this.auth = { refresh_token: r.refresh_token, at: Date.now(), scopes: String(r.scope || '').split(' ').filter(Boolean), email: '' }; this.tok = { v: r.access_token, exp: Date.now() + (r.expires_in - 60) * 1000 }; this.pendingAuth = null;
    try { const me = await this.api('GET', 'https://openidconnect.googleapis.com/v1/userinfo'); this.auth.email = me.email || ''; } catch { /* 沒有 email scope 也無妨 */ }
    this._save(); this.ctx.store.audit('app', 'google.connect', this.auth.email || 'oauth'); return this.state();
  }
  /** 直接貼 refresh token（例如在 OAuth Playground 取得） */
  async setRefreshToken(rt) { const c = this.cfg; if (!c.client_id || !c.client_secret) throw new Error('請先填 OAuth 用戶端 ID 與密鑰'); this.auth = { refresh_token: String(rt).trim(), at: Date.now(), scopes: [], email: '' }; this.tok = null; await this.token(true); try { this.auth.email = (await this.api('GET', 'https://openidconnect.googleapis.com/v1/userinfo')).email || ''; } catch { /* ignore */ } this._save(); return this.state(); }
  /** Service Account JSON（要代表真人帳號需 Workspace 網域委派，subject＝被代表的 email） */
  async setServiceAccount(json, subject = '') {
    const sa = typeof json === 'string' ? JSON.parse(json) : json; if (!sa || !sa.client_email || !sa.private_key) throw new Error('Service Account JSON 缺少 client_email／private_key');
    this.auth = { sa: { client_email: sa.client_email, private_key: sa.private_key, token_uri: sa.token_uri || 'https://oauth2.googleapis.com/token' }, subject: String(subject || '').trim(), at: Date.now(), scopes: DEFAULT_SCOPES.slice(2), email: '' }; this.tok = null;
    try { await this.token(true); } catch (e) { this.auth = null; throw e; } this._save(); return this.state();
  }
  async disconnect() { const a = this.auth; this.auth = null; this.tok = null; this._save(); if (a && a.refresh_token) { try { await this._fetch('https://oauth2.googleapis.com/revoke?token=' + encodeURIComponent(a.refresh_token), { method: 'POST' }); } catch { /* ignore */ } } this.ctx.store.audit('app', 'google.disconnect', ''); return this.state(); }

  async _token(form) {
    const r = await this._fetch('https://oauth2.googleapis.com/token', { method: 'POST', headers: { 'content-type': 'application/x-www-form-urlencoded' }, body: new URLSearchParams(form) });
    const t = await r.text(); let j = {}; try { j = JSON.parse(t); } catch { /* ignore */ }
    if (!r.ok) throw new Error(`Google 授權失敗：${j.error_description || j.error || r.status}${j.error === 'invalid_grant' ? '（授權已失效或被撤銷，請管理員重新授權）' : ''}`);
    return j;
  }
  async token(force = false) {
    this.need(); if (!force && this.tok && Date.now() < this.tok.exp) return this.tok.v; if (this._tokP) return this._tokP;
    this._tokP = (async () => {
      try {
        const a = this.auth; let r;
        if (a.sa) {
          const now = Math.floor(Date.now() / 1000); const claim = { iss: a.sa.client_email, scope: (a.scopes && a.scopes.length ? a.scopes : DEFAULT_SCOPES.slice(2)).join(' '), aud: a.sa.token_uri, iat: now, exp: now + 3300 }; if (a.subject) claim.sub = a.subject;
          const head = b64u(JSON.stringify({ alg: 'RS256', typ: 'JWT' })); const body = b64u(JSON.stringify(claim)); const sig = b64u(crypto.createSign('RSA-SHA256').update(head + '.' + body).sign(a.sa.private_key));
          r = await this._token({ grant_type: 'urn:ietf:params:oauth:grant-type:jwt-bearer', assertion: `${head}.${body}.${sig}` });
        } else { const c = this.cfg; r = await this._token({ grant_type: 'refresh_token', refresh_token: a.refresh_token, client_id: c.client_id, client_secret: c.client_secret }); }
        this.tok = { v: r.access_token, exp: Date.now() + Math.max(60, (r.expires_in || 3600) - 90) * 1000 }; return this.tok.v;
      } finally { this._tokP = null; }
    })();
    return this._tokP;
  }

  // ---------- 通用 REST 呼叫 ----------
  /** 只允許 *.googleapis.com；401 自動換 token 重試；429／5xx 退避重試 */
  async api(method, url, { query, body, headers = {}, raw = false, timeout = 60000 } = {}) {
    let u; try { u = new URL(url); } catch { throw new Error('網址格式不正確'); }
    if (u.protocol !== 'https:' || !GOOGLE_HOST.test(u.hostname)) throw new Error('只允許呼叫 https://*.googleapis.com');
    for (const [k, v] of Object.entries(query || {})) if (v !== undefined && v !== null && v !== '') u.searchParams.set(k, String(v));
    let opt = { method, headers: { ...headers } }; if (body !== undefined) { if (Buffer.isBuffer(body) || typeof body === 'string') opt.body = body; else { opt.body = JSON.stringify(body); opt.headers['content-type'] = opt.headers['content-type'] || 'application/json'; } }
    let refreshed = false;
    for (let attempt = 0; ; attempt++) {
      opt.headers.authorization = 'Bearer ' + await this.token(); const ctl = new AbortController(); const t = setTimeout(() => ctl.abort(), timeout);
      let r; try { r = await this._fetch(u.toString(), { ...opt, signal: ctl.signal }); } catch (e) { clearTimeout(t); if (attempt < 2) { await sleep(600 * (attempt + 1)); continue; } throw new Error('連不上 Google：' + e.message); }
      clearTimeout(t);
      if (r.status === 401 && !refreshed) { refreshed = true; this.tok = null; continue; }
      if ((r.status === 429 || r.status >= 500) && attempt < 3) { await sleep(800 * 2 ** attempt); continue; }
      if (raw && r.ok) return Buffer.from(await r.arrayBuffer());
      const text = await r.text(); let j = null; try { j = text ? JSON.parse(text) : {}; } catch { /* 非 JSON */ }
      if (!r.ok) throw new Error(this._explain(r.status, j, text));
      return j === null ? text : j;
    }
  }
  _explain(status, j, text) {
    const e = j && j.error; const msg = (e && (e.message || e.status)) || clip(text, 160); let hint = '';
    const disabled = e && JSON.stringify(e).match(/https:\/\/console\.(?:developers|cloud)\.google\.com\/[^\s"\\]+/);
    if (/SERVICE_DISABLED|has not been used|is disabled/i.test(JSON.stringify(e || ''))) hint = `（這個 Google API 還沒啟用，請管理員到 Cloud Console 啟用${disabled ? '：' + disabled[0] : ''}）`;
    else if (status === 403 && /insufficient|scope/i.test(JSON.stringify(e || ''))) hint = '（授權範圍不足，請管理員重新授權並勾選所有權限）';
    else if (status === 401) hint = '（授權失效，請管理員重新授權）'; else if (status === 404) hint = '（找不到：ID 錯了，或這個帳號沒有該檔案的存取權）';
    return `Google API ${status}：${msg}${hint}`;
  }

  // ---------- Gmail ----------
  _attachments(list) {
    const out = []; let total = 0; for (const p of list || []) {
      const f = this.ctx.fsx.resolve(p, 'workspace'); const st = fs.statSync(f); if (st.isDirectory()) throw new Error('附件不能是資料夾：' + p); total += st.size; if (total > 20 * 1024 * 1024) throw new Error('附件總量超過 20MB（Gmail 上限 25MB）');
      out.push({ name: path.basename(f), data: fs.readFileSync(f), mime: mimeOf(f) });
    } return out;
  }
  /** 組 RFC 5322 信件（UTF-8、Base64；擋掉標頭注入） */
  buildMime(o) {
    const to = emailList(o.to), cc = emailList(o.cc), bcc = emailList(o.bcc); if (!to.length && !cc.length && !bcc.length) throw new Error('沒有收件人');
    const atts = o.attachments && o.attachments.length && typeof o.attachments[0] === 'string' ? this._attachments(o.attachments) : (o.attachments || []);
    const subj = noCRLF(o.subject || '', '主旨'); const text = String(o.text ?? ''); const html = o.html ? String(o.html) : '';
    const H = []; if (o.from) H.push('From: ' + addrHeader(emailList(o.from))); if (to.length) H.push('To: ' + addrHeader(to)); if (cc.length) H.push('Cc: ' + addrHeader(cc)); if (bcc.length) H.push('Bcc: ' + addrHeader(bcc));
    H.push('Subject: ' + encHeader(subj), 'MIME-Version: 1.0'); if (o.inReplyTo) H.push('In-Reply-To: ' + noCRLF(o.inReplyTo, 'In-Reply-To')); if (o.references) H.push('References: ' + noCRLF(o.references, 'References'));
    const part = (type, content) => `Content-Type: ${type}; charset="UTF-8"\r\nContent-Transfer-Encoding: base64\r\n\r\n${wrap76(Buffer.from(content, 'utf8').toString('base64'))}`;
    const bnd = () => 'gws_' + crypto.randomBytes(12).toString('hex');
    const alt = html ? (() => { const b = bnd(); return { ct: `multipart/alternative; boundary="${b}"`, body: `--${b}\r\n${part('text/plain', text || html.replace(/<[^>]+>/g, ' '))}\r\n--${b}\r\n${part('text/html', html)}\r\n--${b}--` }; })() : null;
    let body;
    if (!atts.length) {
      if (alt) { H.push(`Content-Type: ${alt.ct}`); body = alt.body; }
      else { H.push('Content-Type: text/plain; charset="UTF-8"', 'Content-Transfer-Encoding: base64'); body = wrap76(Buffer.from(text, 'utf8').toString('base64')); }
    } else {
      const b = bnd(); H.push(`Content-Type: multipart/mixed; boundary="${b}"`); const first = alt ? `Content-Type: ${alt.ct}\r\n\r\n${alt.body}` : part('text/plain', text);
      body = `--${b}\r\n${first}\r\n` + atts.map((x) => { const n = encHeader(noCRLF(x.name, '附件名稱')); return `--${b}\r\nContent-Type: ${x.mime || 'application/octet-stream'}; name="${n}"\r\nContent-Disposition: attachment; filename="${n}"\r\nContent-Transfer-Encoding: base64\r\n\r\n${wrap76(Buffer.from(x.data).toString('base64'))}\r\n`; }).join('') + `--${b}--`;
    }
    return Buffer.from(H.join('\r\n') + '\r\n\r\n' + body, 'utf8');
  }
  _countSend() { const d = today(); if (this.meta.day !== d) this.meta = { day: d, sent: 0 }; const cap = +this.cfg.daily_send_cap || 50; if (this.meta.sent >= cap) throw new Error(`今天已寄 ${this.meta.sent} 封，達到每日上限 ${cap}（管理員可在設定調整 google.daily_send_cap）`); this.meta.sent++; this._saveMeta(); }
  async gmailSend(o) {
    this.need(); const mime = this.buildMime(o); if (mime.length > 25 * 1024 * 1024) throw new Error('信件超過 25MB'); this._countSend();
    try { const r = await this.api('POST', 'https://gmail.googleapis.com/gmail/v1/users/me/messages/send', { body: { raw: b64u(mime), threadId: o.threadId || undefined } }); this.ctx.store.audit('gws', 'gmail.send', `${emailList(o.to).join(',')} | ${clip(o.subject, 60)}`); return { id: r.id, threadId: r.threadId }; }
    catch (e) { this.meta.sent = Math.max(0, this.meta.sent - 1); this._saveMeta(); throw e; }
  }
  async gmailDraft(o) { this.need(); const r = await this.api('POST', 'https://gmail.googleapis.com/gmail/v1/users/me/drafts', { body: { message: { raw: b64u(this.buildMime(o)), threadId: o.threadId || undefined } } }); return { id: r.id, messageId: r.message && r.message.id }; }
  _hdr(m, n) { const h = (m.payload && m.payload.headers || []).find((x) => x.name.toLowerCase() === n.toLowerCase()); return h ? h.value : ''; }
  async gmailSearch(q, max = 10) {
    this.need(); max = Math.max(1, Math.min(+max || 10, 30)); const l = await this.api('GET', 'https://gmail.googleapis.com/gmail/v1/users/me/messages', { query: { q, maxResults: max } }); const ids = (l.messages || []).map((m) => m.id); const out = [];
    for (let i = 0; i < ids.length; i += 5) out.push(...await Promise.all(ids.slice(i, i + 5).map(async (id) => { const m = await this.api('GET', `https://gmail.googleapis.com/gmail/v1/users/me/messages/${id}`, { query: { format: 'metadata', metadataHeaders: ['From', 'To', 'Subject', 'Date'] } }).catch(() => null); return m && { id, threadId: m.threadId, from: this._hdr(m, 'From'), to: this._hdr(m, 'To'), subject: this._hdr(m, 'Subject'), date: this._hdr(m, 'Date'), snippet: m.snippet, labels: m.labelIds }; })));
    return out.filter(Boolean);
  }
  _bodyOf(p) {
    let plain = '', html = ''; const atts = []; const walk = (x) => { if (!x) return; const mt = x.mimeType || ''; if (x.filename && x.body && x.body.attachmentId) atts.push({ name: x.filename, id: x.body.attachmentId, size: x.body.size, mime: mt });
      else if (x.body && x.body.data) { const t = Buffer.from(x.body.data, 'base64url').toString('utf8'); if (mt === 'text/plain') plain += t; else if (mt === 'text/html') html += t; } (x.parts || []).forEach(walk); }; walk(p);
    if (!plain && html) plain = require('./web').htmlToText(html); return { text: plain.trim(), attachments: atts };
  }
  async gmailRead(id) { this.need(); const m = await this.api('GET', `https://gmail.googleapis.com/gmail/v1/users/me/messages/${id}`, { query: { format: 'full' } }); const b = this._bodyOf(m.payload); return { id, threadId: m.threadId, from: this._hdr(m, 'From'), to: this._hdr(m, 'To'), cc: this._hdr(m, 'Cc'), subject: this._hdr(m, 'Subject'), date: this._hdr(m, 'Date'), messageId: this._hdr(m, 'Message-ID'), labels: m.labelIds, ...b }; }
  async gmailReply(id, o) {
    this.need(); const m = await this.api('GET', `https://gmail.googleapis.com/gmail/v1/users/me/messages/${id}`, { query: { format: 'metadata', metadataHeaders: ['From', 'To', 'Cc', 'Reply-To', 'Subject', 'Message-ID', 'References'] } });
    const msgId = this._hdr(m, 'Message-ID'); const subj = this._hdr(m, 'Subject'); const me = (this.auth.email || '').toLowerCase();
    const to = o.to || this._hdr(m, 'Reply-To') || this._hdr(m, 'From'); let cc = o.cc || ''; if (o.all) cc = emailList([this._hdr(m, 'To'), this._hdr(m, 'Cc')].join(',')).filter((a) => !me || !a.toLowerCase().includes(me)).join(',');
    return { to, cc, subject: /^re:/i.test(subj) ? subj : 'Re: ' + subj, text: o.text, html: o.html, attachments: o.attachments, inReplyTo: msgId, references: [this._hdr(m, 'References'), msgId].filter(Boolean).join(' ').replace(/[\r\n]+/g, ' '), threadId: m.threadId };
  }
  gmailModify(id, add = [], remove = []) { this.need(); return this.api('POST', `https://gmail.googleapis.com/gmail/v1/users/me/messages/${id}/modify`, { body: { addLabelIds: add, removeLabelIds: remove } }); }
  gmailTrash(id) { this.need(); return this.api('POST', `https://gmail.googleapis.com/gmail/v1/users/me/messages/${id}/trash`); }
  async gmailAttachment(msgId, attId, saveAs) { this.need(); const r = await this.api('GET', `https://gmail.googleapis.com/gmail/v1/users/me/messages/${msgId}/attachments/${attId}`); const buf = Buffer.from(r.data || '', 'base64url'); const f = this.ctx.fsx.resolve(saveAs, 'workspace'); fs.mkdirSync(path.dirname(f), { recursive: true }); fs.writeFileSync(f, buf); return { path: saveAs, bytes: buf.length }; }

  // ---------- Google 表單（別人的公開表單：HTTP 直送；要登入的表單：帶你的 Google 工作階段 cookie）----------
  _cookieLoad() { try { return JSON.parse(this.ctx.vault.dec(fs.readFileSync(this.cookieFile, 'utf8'))); } catch { return null; } }
  /** 管理員貼上自己瀏覽器的 Cookie 字串（加密存放；AI 看不到；只會送給 google.com 網域） */
  setFormCookie(str) {
    str = String(str || '').trim().replace(/^cookie:\s*/i, '').replace(/[\r\n]+/g, ''); if (!/[\w.-]+=[^;]+/.test(str)) throw new Error('Cookie 格式不對：要像 SID=xxx; HSID=yyy; …（瀏覽器 DevTools → Network → 任一 google.com 請求 → Request Headers → cookie）');
    if (!/(^|;\s*)(SID|__Secure-1PSID|__Secure-3PSID|SAPISID|HSID)=/.test(str)) throw new Error('這串 Cookie 看起來不是已登入的 Google 工作階段（找不到 SID／__Secure-1PSID）。請在「已登入 Google」的分頁複製。');
    fs.writeFileSync(this.cookieFile + '.tmp', this.ctx.vault.enc(JSON.stringify({ cookie: str, at: Date.now() })), { mode: 0o600 }); fs.renameSync(this.cookieFile + '.tmp', this.cookieFile); this.ctx.store.audit('app', 'google.cookie.set', ''); return this.cookieState();
  }
  clearFormCookie() { try { fs.rmSync(this.cookieFile, { force: true }); } catch { /* ignore */ } this.ctx.store.audit('app', 'google.cookie.clear', ''); return this.cookieState(); }
  cookieState() { const c = this._cookieLoad(); const b = this.ctx.browser; return { saved: !!c, saved_at: c ? c.at : 0, browser: !!(b && b.cdp && b.cdp.open) }; }
  /** 取可用的 Google 工作階段 cookie：先用貼上的，沒有再看 App 內瀏覽器（管理員手動登入過就有） */
  async _sessionCookie() {
    const c = this._cookieLoad(); if (c && c.cookie) return c.cookie; const b = this.ctx.browser;
    try { if (b && b.cdp && b.cdp.open) { const r = await b.cdp.send('Network.getCookies', { urls: ['https://docs.google.com/', 'https://accounts.google.com/', 'https://www.google.com/'] }); const l = (r.cookies || []).filter((x) => /(^|\.)google\.com$/.test(String(x.domain).replace(/^\./, ''))); if (l.some((x) => /^(SID|__Secure-1PSID|SAPISID|HSID)$/.test(x.name))) return [...new Map(l.map((x) => [x.name, x])).values()].map((x) => `${x.name}=${x.value}`).join('; '); } } catch { /* 沒有瀏覽器登入 */ }
    return '';
  }
  /** 手動追轉址：Cookie 只會送給 google.com（fetch 跨網域轉址會把 cookie 丟掉，forms.gle 又一定會轉址） */
  async _page(url, cookie) {
    const UA = 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36';
    for (let hop = 0; hop < 8; hop++) {
      const h = new URL(url).hostname; const ck = (cookie && /(^|\.)google\.com$/.test(h) ? cookie + '; ' : '') + 'CONSENT=YES+cb; SOCS=CAI';
      const r = await this._fetch(url, { redirect: 'manual', headers: { 'user-agent': UA, 'accept-language': 'zh-TW,zh;q=0.9,en;q=0.8', accept: 'text/html,application/xhtml+xml', cookie: ck }, signal: AbortSignal.timeout(25000) });
      const loc = r.headers && r.headers.get && r.headers.get('location'); if (r.status >= 300 && r.status < 400 && loc) { url = new URL(loc, url).toString(); continue; }
      return { status: r.status, ok: r.ok, url: r.url && !/^$/.test(r.url) ? r.url : url, html: await r.text() };
    } throw new Error('轉址次數過多');
  }
  _normFormUrl(url) {
    url = String(url || '').trim(); if (this.ctx.gwsFormsBase) return url; const m = /https?:\/\/[^\s)>\]"']+/.exec(url); if (m) url = m[0];   // 允許整段貼上含文字的訊息
    if (!/^https:\/\/(docs\.google\.com\/(?:a\/[^/]+\/)?forms\/|forms\.gle\/|forms\.google\.com\/)/i.test(url)) throw new Error('只支援 https://docs.google.com/forms/… 或 https://forms.gle/… 網址');
    return url.replace(/\/forms\/u\/\d+\//, '/forms/').replace(/\/forms\/d\/(e\/)?([\w-]+)\/(edit|viewanalytics|prefill)\b/, (_, e, id) => `/forms/d/${e || ''}${id}/viewform`);
  }
  async formRead(url) {
    url = this._normFormUrl(url); let usedCookie = false; let p = await this._page(url, ''); let d = this._formData(p);
    if (!d) { const ck = await this._sessionCookie(); if (ck && (this._needLogin(p) || !p.ok)) { p = await this._page(url, ck); d = this._formData(p); usedCookie = !!d; } }
    if (!d) {
      if (this._needLogin(p)) return { needLogin: true, url: p.url, questions: [], text: '這份表單需要登入 Google 才能填（組織內部、或限制每人填一次／收集帳號）。\n處理方式（擇一）：\n① App「瀏覽器」頁 →「Google Workspace API」卡片 →「進階」貼上你已登入 Google 的 Cookie，AI 就能代你填；\n② 在 App 瀏覽器按「接手」自己登入 Google 一次，再叫 AI 重試；\n③ 直接請管理員自己填。' };
      throw new Error(p.ok ? '讀不到題目資料（可能表單已關閉、不是表單頁面，或 Google 改版）。回應片段：' + clip(String(p.html).replace(/<script[\s\S]*?<\/script>|<style[\s\S]*?<\/style>|<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim(), 120) : `HTTP ${p.status}`);
    }
    const f = this.parseForm(d); f.url = p.url; f.usedCookie = usedCookie; const html = p.html;
    f.fbzx = ((/<input[^>]*name="fbzx"[^>]*value="([^"]*)"/.exec(html) || /<input[^>]*value="([^"]*)"[^>]*name="fbzx"/.exec(html) || [])[1]) || (typeof d[14] === 'string' ? d[14] : '');
    const act = /<form[^>]*action="([^"]*formResponse[^"]*)"/.exec(html); f.action = act ? act[1].replace(/&amp;/g, '&') : p.url.replace(/[?#].*$/, '').replace(/\/(viewform|edit|prefill)$/, '') + '/formResponse';
    if (this.ctx.gwsFormsBase) f.action = f.action.replace(/^https?:\/\/[^/]+/, this.ctx.gwsFormsBase);
    f.needEmail = /emailAddress/.test(html) || !!(d[1] && Array.isArray(d[1][10]) && d[1][10][4] === 1); return f;
  }
  _needLogin(p) { return /^https:\/\/accounts\.google\.com\//.test(p.url) || (!require('./formsmart').extractArray(p.html) && /ServiceLogin|name="identifier"|accounts\.google\.com\/(?:v3\/)?signin/.test(String(p.html).slice(0, 40000))); }
  _formData(p) { if (/^https:\/\/accounts\.google\.com\//.test(p.url)) return null; const d = require('./formsmart').extractArray(p.html); return Array.isArray(d) && d[1] && Array.isArray(d[1][1]) ? d : null; }
  /** 題型代碼對不準也能運作：依結構（有沒有選項、有幾列）推斷，不認得的當文字題送出 */
  parseForm(d) {
    const root = d[1] || []; const items = root[1] || []; const TYPES = { 0: 'text', 1: 'paragraph', 2: 'radio', 3: 'dropdown', 4: 'checkbox', 5: 'scale', 7: 'grid', 9: 'date', 10: 'time', 13: 'file' };
    const qs = []; const pages = [{ id: 0, title: '', start: 0 }]; const unknown = []; let pi = 0;
    for (const it of items) {
      if (!Array.isArray(it)) continue; const code = it[3]; if (code === 8) { pages.push({ id: it[0], title: String(it[1] || ''), start: qs.length }); pi++; continue; }
      const sub = Array.isArray(it[4]) ? it[4].filter((s) => Array.isArray(s) && s[0] != null) : []; if (!sub.length) continue;   // 標題／圖片／影片沒有作答欄位
      const s0 = sub[0]; const hasOpts = Array.isArray(s0[1]) && s0[1].length > 0; let type = TYPES[code];
      if (code === 13) type = 'file'; else if (sub.length > 1 && hasOpts) type = 'grid'; else if (type === 'grid' && !hasOpts) type = 'datetime'; else if ((type === 'date' || type === 'time') && hasOpts) type = sub.length > 1 ? 'grid' : 'radio';
      else if (!type) type = hasOpts ? 'radio' : 'unknown'; else if (['radio', 'dropdown', 'checkbox', 'scale'].includes(type) && !hasOpts) type = 'text';
      const q = { i: qs.length, id: it[0], page: pi, code, title: String(it[1] || '').trim(), desc: String(it[2] || '').trim(), type, required: sub.some((s) => s[2] === 1) };
      if (type === 'grid') { q.rows = sub.map((s) => ({ entry: s[0], label: String((s[3] || [])[0] ?? ''), required: s[2] === 1 })); q.columns = (s0[1] || []).map((o) => String(Array.isArray(o) ? o[0] : o)); q.multi = sub.some((s) => Array.isArray(s[11]) && s[11][0] === 1) || false; q.required = q.rows.some((r) => r.required); }
      else { q.entry = s0[0]; if (hasOpts && ['radio', 'dropdown', 'checkbox', 'scale'].includes(type)) q.options = s0[1].map((o) => ({ label: String(Array.isArray(o) ? o[0] ?? '' : o), goto: Array.isArray(o) ? o[2] : undefined, other: Array.isArray(o) && o[4] === 1 })); if (type === 'scale') q.scaleLabels = s0[3] || null; if (type === 'date' || type === 'datetime') q.withTime = !!(s0[7] && s0[7][0]); if (type === 'unknown') unknown.push(q.i); }
      qs.push(q);
    }
    return { title: String(d[3] || root[8] || ''), description: String(root[0] || ''), questions: qs, pages, unknown };
  }
  fmtForm(f) {
    if (f.needLogin) return f.text;
    const L = [`表單：${f.title || '(無標題)'}${f.description ? '\n' + clip(f.description, 200) : ''}`, f.pages.length > 1 ? `共 ${f.pages.length} 頁（一次送出，系統依答案與分支自動計算走過的頁面）` : '', f.usedCookie ? '（已用你的 Google 登入狀態讀取；送出的回覆會記在你的帳號下）' : ''].filter(Boolean);
    if (f.needEmail) L.push('※ 這份表單會收集電子郵件：請在 email 參數提供。');
    for (const q of f.questions) { const o = q.options ? '｜選項：' + q.options.map((x) => x.label + (x.other ? '（其他：可自填）' : '')).join(' / ') : q.rows ? '｜列：' + q.rows.map((r) => r.label).join('、') + '｜欄：' + q.columns.join(' / ') + (q.multi ? '（可複選）' : '') : ''; const fmt = q.type === 'date' ? '｜格式 YYYY-MM-DD' + (q.withTime ? ' HH:mm' : '') : q.type === 'time' ? '｜格式 HH:mm' : q.type === 'datetime' ? '｜日期 YYYY-MM-DD 或 時間 HH:mm' : q.type === 'unknown' ? `｜未知題型(code ${q.code})，以文字送出` : ''; L.push(`[${q.i}] (第${q.page + 1}頁 ${q.type}${q.required ? '，必填' : ''}) ${q.title}${q.desc ? '（' + clip(q.desc, 60) + '）' : ''}${o}${fmt}`); }
    return L.join('\n');
  }
  /** answers: [{q:題號或題目文字, a:答案}] → { params, pageHistory, problems, notes, visited }；不送出 */
  planForm(f, answers, email, now = new Date()) {
    const fm = require('./formsmart'); const ans = new Map(); const problems = []; const notes = [];
    for (const x of answers || []) { try { ans.set(fm.findQuestion(f.questions, x.q).i, x.a); } catch (e) { problems.push(e.message); } }
    const P = []; const visited = []; let page = 0; const guard = new Set();
    // 依答案計算走過的頁面（選項的「前往某區段」分支；-2＝直接送出）
    while (page !== -1 && page < f.pages.length && !guard.has(page)) {
      guard.add(page); visited.push(page); let next = page + 1;
      for (const q of f.questions.filter((x) => x.page === page)) {
        if (!['radio', 'dropdown'].includes(q.type) || !q.options.some((o) => o.goto)) continue; const a = ans.get(q.i); if (a === undefined) continue; const m = fm.matchOption(q.options.map((o) => o.label), Array.isArray(a) ? a[0] : a);
        if (m.i >= 0 && q.options[m.i].goto) { const g = q.options[m.i].goto; if (g === -2) next = -1; else if (g > 0) { const pi = f.pages.findIndex((p) => p.id === g); if (pi >= 0) next = pi; } }
      }
      page = next >= f.pages.length ? -1 : next;
    }
    const label = (q) => `[${q.i}] ${q.title}`; const nm = (n) => `entry.${n}`;
    const choose = (q, labels, want, add) => {
      const real = q.options ? q.options.map((o, ix) => (o.other ? null : ix)).filter((x) => x !== null) : null; const L = real ? real.map((ix) => q.options[ix].label) : labels; const other = q.options && q.options.find((o) => o.other);
      const m = fm.matchOption(L, want, { scale: q.type === 'scale' });
      if (m.i >= 0) { add(L[m.i]); if (m.how !== 'exact' && norm0(L[m.i]) !== norm0(want)) notes.push(`${label(q)}：「${want}」→「${L[m.i]}」`); return; }
      if (other && m.how !== 'ambiguous') { P.push([nm(q.entry), '__other_option__'], [nm(q.entry) + '.other_option_response', String(want)]); notes.push(`${label(q)}：「${want}」填入「其他」`); return; }
      problems.push(m.how === 'ambiguous' ? `${label(q)}：「${want}」同時像這幾個選項：${m.ambiguous.join('／')}，請指定一個` : `${label(q)}：沒有「${want}」這個選項（可選：${L.join('／')}）`);
    };
    const norm0 = (s) => fm.norm(s);
    for (const q of f.questions) {
      if (!visited.includes(q.page)) continue; const a = ans.get(q.i); const empty = a === undefined || a === null || a === '' || (Array.isArray(a) && !a.length) || (a && typeof a === 'object' && !Array.isArray(a) && !Object.keys(a).length);
      if (q.type === 'file') { if (q.required) problems.push(`${label(q)}：檔案上傳題無法由 API 通道填寫，需要管理員接手`); continue; }
      if (empty) { if (q.required) problems.push(`${label(q)}：必填但沒有答案`); continue; }
      if (['text', 'paragraph', 'unknown'].includes(q.type)) P.push([nm(q.entry), Array.isArray(a) ? a.join('、') : String(a)]);
      else if (['date', 'time', 'datetime'].includes(q.type)) {
        const s = String(a); const d = q.type === 'time' ? null : fm.parseDate(s, now); const t = d ? (d.h != null ? { h: d.h, mi: d.mi } : null) : fm.parseTime(s);
        if (!d && !t) { problems.push(`${label(q)}：看不懂「${s}」，請給 ${q.type === 'time' ? 'HH:mm' : 'YYYY-MM-DD（民國年、3/5、明天 也可以）'}`); continue; }
        if (q.type === 'date' && !d) { problems.push(`${label(q)}：這題要的是日期（收到「${s}」）`); continue; }
        if (d) { P.push([nm(q.entry) + '_year', String(d.y)], [nm(q.entry) + '_month', String(d.mo)], [nm(q.entry) + '_day', String(d.d)]); if (d.h != null || q.withTime) P.push([nm(q.entry) + '_hour', String(d.h || 0)], [nm(q.entry) + '_minute', String(d.mi || 0)]); if (!/^\d{4}-\d{2}-\d{2}/.test(s)) notes.push(`${label(q)}：「${s}」→ ${d.y}-${String(d.mo).padStart(2, '0')}-${String(d.d).padStart(2, '0')}`); }
        else P.push([nm(q.entry) + '_hour', String(t.h)], [nm(q.entry) + '_minute', String(t.mi)]);
      } else if (q.type === 'grid') {
        let o = a; if (typeof o === 'string') { try { o = JSON.parse(o); } catch { o = null; } } if (!o || typeof o !== 'object' || Array.isArray(o)) { problems.push(`${label(q)}：格線題答案要寫成 {列名:選項}`); continue; }
        for (const r of q.rows) { const key = Object.keys(o).find((k) => fm.norm(k) === fm.norm(r.label)) || Object.keys(o).find((k) => fm.norm(k) && (fm.norm(r.label).includes(fm.norm(k)) || fm.norm(k).includes(fm.norm(r.label)))); if (key === undefined) { if (r.required) problems.push(`${label(q)}／${r.label}：必填但沒有答案`); continue; }
          for (const v of [].concat(o[key])) { const m = fm.matchOption(q.columns, v); if (m.i < 0) problems.push(`${label(q)}／${r.label}：找不到欄位「${v}」（可選：${q.columns.join('／')}）`); else P.push([nm(r.entry), q.columns[m.i]]); } }
      } else {
        const labels = q.options.map((o) => o.label); let want;
        if (Array.isArray(a)) want = a.map(String); else if (q.type === 'checkbox') { const whole = fm.matchOption(labels.filter((_, ix) => !q.options[ix].other), String(a)); want = whole.i >= 0 && whole.how !== 'similar' ? [String(a)] : String(a).split(/[、,，;；\n]+|\s*\/\s*|\s+(?:和|及|與|and)\s+/i).map((x) => x.trim()).filter(Boolean); } else want = [String(a)];
        if (q.type !== 'checkbox' && want.length > 1) { problems.push(`${label(q)}：只能選一個`); continue; }
        if (q.type === 'checkbox') P.push([nm(q.entry) + '_sentinel', '']);
        const seen = new Set(); for (const w of want) choose(q, labels, w, (lab) => { if (!seen.has(lab)) { seen.add(lab); P.push([nm(q.entry), lab]); } });
      }
    }
    if (f.needEmail) { if (email) P.push(['emailAddress', String(email)]); else problems.push('這份表單要收集電子郵件，請提供 email'); }
    return { params: P, pageHistory: visited.join(','), problems, notes, visited };
  }
  /** 從 Google 回傳的頁面抓出真正的原因（格式驗證、必填、已關閉、限填一次），讓使用者知道怎麼改，而不是只說「被退回」 */
  _formErrors(html) {
    const dec = (x) => x.replace(/&amp;/g, '&').replace(/&#39;/g, "'").replace(/&quot;/g, '"').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/\s+/g, ' ').trim(); const out = new Set(); const h = String(html);
    for (const m of h.matchAll(/(?:role="alert"|class="[^"]*[Ee]rror[^"]*")[^>]*>\s*([^<]{2,160}?)\s*</g)) { const t = dec(m[1]); if (t && !/^(必填|Required|\*)$/i.test(t)) out.add(t); }
    if (/不再接受回應|目前不接受回應|已停止接受回應|no longer accepting responses|isn.t accepting responses/i.test(h)) out.add('這份表單已停止接受回應');
    if (/已(經)?回覆過|只能回覆一次|只能填寫一次|already (responded|filled)|limit.{0,12}one response/i.test(h)) out.add('這份表單限制每人只能填一次，這個帳號可能已經填過');
    return [...out].slice(0, 5);
  }
  /** 依姓名／電話等推薦答案：用管理員的長期事實；身分證、帳密一律不自動填。facts: 字串陣列 */
  async formSuggest(url, facts) { const f = await this.formRead(url); if (f.needLogin) return { form: f, text: f.text }; const fm = require('./formsmart'); const s = fm.suggestFromFacts(f, facts); return { form: f, ...s, text: this.fmtForm(f) }; }
  async formSubmit(url, answers, { email, dry = false, now } = {}) {
    const f = await this.formRead(url); if (f.needLogin) return { ok: false, needLogin: true, text: f.text }; const plan = this.planForm(f, answers, email, now);
    if (plan.problems.length) return { ok: false, problems: plan.problems, text: '尚未送出，需要先處理：\n' + plan.problems.map((x) => '・' + x).join('\n') + (plan.notes.length ? '\n\n（已自動對應：\n' + plan.notes.map((x) => '・' + x).join('\n') + '）' : '') };
    const noteTxt = plan.notes.length ? '\n自動對應：\n' + plan.notes.map((x) => '・' + x).join('\n') : '';
    if (dry) return { ok: true, dry: true, notes: plan.notes, text: `（預覽，未送出）將送出 ${plan.params.length} 個欄位，走過頁面：${plan.visited.map((i) => i + 1).join('→')}。${noteTxt}` };
    const body = new URLSearchParams(); for (const [k, v] of plan.params) body.append(k, v);
    if (f.pages.length > 1) body.set('pageHistory', plan.pageHistory); body.set('fvv', '1'); if (f.fbzx) { body.set('fbzx', f.fbzx); body.set('partialResponse', JSON.stringify([null, null, f.fbzx])); body.set('draftResponse', JSON.stringify([null, null, f.fbzx])); }
    const ck = f.usedCookie ? await this._sessionCookie() : ''; let r, t;
    for (let attempt = 0; ; attempt++) {
      try { r = await this._fetch(f.action, { method: 'POST', redirect: 'follow', headers: { 'content-type': 'application/x-www-form-urlencoded', 'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36', referer: f.url, origin: 'https://docs.google.com', 'accept-language': 'zh-TW,zh;q=0.9', cookie: (ck ? ck + '; ' : '') + 'CONSENT=YES+cb; SOCS=CAI' }, body, signal: AbortSignal.timeout(30000) }); t = await r.text(); if (r.status >= 500 && attempt < 1) { await sleep(1200); continue; } break; }
      catch (e) { if (attempt < 1) { await sleep(1200); continue; } throw new Error('送出時連不上 Google：' + e.message); }
    }
    // 成功判斷：標準「已記錄回應」、自訂確認訊息頁（有「提交另一份回應」連結／確認訊息 class）；頁面又出現整份表單資料＝驗證失敗被退回
    const stdOk = /已記錄(您|你)的回應|response has been recorded|freebirdFormviewerViewResponseConfirmation|已提交|已送出/i.test(t); const confirmPage = /viewform\?[^"']*usp=form_confirm|提交另一份回應|Submit another response|vHW8K/i.test(t); const bounced = /FB_PUBLIC_LOAD_DATA_/.test(t) && !confirmPage && !stdOk;
    this.ctx.store.audit('gws', 'form.submit', `${f.title} → HTTP ${r.status}${stdOk || confirmPage ? ' ok' : bounced ? ' bounced' : ' ?'}${f.usedCookie ? ' (cookie)' : ''}`);
    if (r.ok && (stdOk || confirmPage) && !bounced) return { ok: true, notes: plan.notes, text: `已送出「${f.title}」，Google 已確認收到回應。${noteTxt}` };
    const snip = clip(String(t).replace(/<script[\s\S]*?<\/script>|<style[\s\S]*?<\/style>|<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim(), 140);
    const errs = this._formErrors(t); if (errs.length && !stdOk && !confirmPage) return { ok: false, errors: errs, text: `Google 沒有收下這份回覆，原因：${errs.join('；')}。請依訊息修正答案後再試（若是已關閉或限填一次，就沒辦法再填了）。` };
    if (bounced) return { ok: false, text: `Google 把表單退回了（通常是某必填題格式不符、選項被改過、或這份表單已關閉／每人限填一次）。請先 gform_read 重新確認題目再試。回應片段：${snip}` };
    return { ok: false, uncertain: r.ok, text: r.ok ? `已送出請求但沒看到確認頁，無法確定成功（可能漏了必填題、被限制只能填一次或表單已關閉）。請管理員查表單回覆確認；不要重複送出。回應片段：${snip}` : `Google 拒絕了送出（HTTP ${r.status}）。可能是表單已關閉、需要登入或題目有誤。回應片段：${snip}` };
  }
  // Forms API（只能讀寫「自己的」表單：建立、讀結構、讀回覆；API 本身不能代為提交答案）
  async formsApi(action, a = {}) {
    this.need(); const B = 'https://forms.googleapis.com/v1/forms';
    if (action === 'create') {
      const f = await this.api('POST', B, { body: { info: { title: a.title, documentTitle: a.title } } }); const reqs = (a.questions || []).map((q, i) => {
        const t = q.type || 'text'; const question = { required: !!q.required };
        if (t === 'text' || t === 'paragraph') question.textQuestion = { paragraph: t === 'paragraph' }; else if (['radio', 'checkbox', 'dropdown'].includes(t)) question.choiceQuestion = { type: { radio: 'RADIO', checkbox: 'CHECKBOX', dropdown: 'DROP_DOWN' }[t], options: (q.options || []).map((v) => ({ value: String(v) })) };
        else if (t === 'scale') question.scaleQuestion = { low: q.low ?? 1, high: q.high ?? 5, lowLabel: q.lowLabel, highLabel: q.highLabel }; else if (t === 'date') question.dateQuestion = { includeYear: true }; else if (t === 'time') question.timeQuestion = {}; else throw new Error('不支援的題型：' + t);
        return { createItem: { item: { title: q.title, description: q.description, questionItem: { question } }, location: { index: i } } }; });
      if (a.description) reqs.unshift({ updateFormInfo: { info: { description: a.description }, updateMask: 'description' } });
      if (reqs.length) await this.api('POST', `${B}/${f.formId}:batchUpdate`, { body: { requests: reqs } });
      return { formId: f.formId, editUrl: `https://docs.google.com/forms/d/${f.formId}/edit`, shareUrl: f.responderUri };
    }
    const id = idFrom(a.id); if (action === 'get') return this.api('GET', `${B}/${id}`); if (action === 'responses') return this.api('GET', `${B}/${id}/responses`, { query: { pageSize: Math.min(+a.max || 50, 500) } });
    throw new Error('action 要是 create｜get｜responses');
  }

  // ---------- Sheets ----------
  sheetsGet(id, range) { this.need(); return this.api('GET', `https://sheets.googleapis.com/v4/spreadsheets/${idFrom(id)}/values/${encodeURIComponent(range)}`, { query: { valueRenderOption: 'FORMATTED_VALUE' } }); }
  sheetsAppend(id, range, rows) { this.need(); return this.api('POST', `https://sheets.googleapis.com/v4/spreadsheets/${idFrom(id)}/values/${encodeURIComponent(range)}:append`, { query: { valueInputOption: 'USER_ENTERED', insertDataOption: 'INSERT_ROWS' }, body: { values: rows } }); }
  sheetsUpdate(id, range, rows) { this.need(); return this.api('PUT', `https://sheets.googleapis.com/v4/spreadsheets/${idFrom(id)}/values/${encodeURIComponent(range)}`, { query: { valueInputOption: 'USER_ENTERED' }, body: { values: rows } }); }
  sheetsInfo(id) { this.need(); return this.api('GET', `https://sheets.googleapis.com/v4/spreadsheets/${idFrom(id)}`, { query: { fields: 'spreadsheetId,properties.title,sheets.properties' } }); }
  async sheetsCreate(title, rows) { this.need(); const s = await this.api('POST', 'https://sheets.googleapis.com/v4/spreadsheets', { body: { properties: { title } } }); if (rows && rows.length) await this.sheetsUpdate(s.spreadsheetId, 'A1', rows); return { id: s.spreadsheetId, url: s.spreadsheetUrl }; }

  // ---------- Docs ----------
  _docText(doc) { const out = []; const walk = (els) => { for (const e of els || []) { if (e.paragraph) out.push((e.paragraph.elements || []).map((x) => (x.textRun ? x.textRun.content : '')).join('')); else if (e.table) for (const r of e.table.tableRows || []) for (const c of r.tableCells || []) walk(c.content); } }; walk(doc.body && doc.body.content); return out.join(''); }
  async docsCreate(title, text) { this.need(); const d = await this.api('POST', 'https://docs.googleapis.com/v1/documents', { body: { title } }); if (text) await this.docsAppend(d.documentId, text); return { id: d.documentId, url: `https://docs.google.com/document/d/${d.documentId}/edit` }; }
  async docsRead(id) { this.need(); const d = await this.api('GET', `https://docs.googleapis.com/v1/documents/${idFrom(id)}`); return { title: d.title, text: this._docText(d) }; }
  docsAppend(id, text) { this.need(); return this.api('POST', `https://docs.googleapis.com/v1/documents/${idFrom(id)}:batchUpdate`, { body: { requests: [{ insertText: { endOfSegmentLocation: {}, text: String(text) } }] } }); }
  docsReplace(id, find, repl) { this.need(); return this.api('POST', `https://docs.googleapis.com/v1/documents/${idFrom(id)}:batchUpdate`, { body: { requests: [{ replaceAllText: { containsText: { text: find, matchCase: true }, replaceText: String(repl) } }] } }); }

  // ---------- Drive ----------
  driveList(q, max = 20) { this.need(); return this.api('GET', 'https://www.googleapis.com/drive/v3/files', { query: { q: q || undefined, pageSize: Math.min(+max || 20, 100), fields: 'files(id,name,mimeType,modifiedTime,size,webViewLink,parents)', orderBy: 'modifiedTime desc', supportsAllDrives: true, includeItemsFromAllDrives: true } }); }
  async driveUpload(rel, { name, folder, mime, convert } = {}) {
    this.need(); const f = this.ctx.fsx.resolve(rel, 'workspace'); const data = fs.readFileSync(f); if (data.length > 50 * 1024 * 1024) throw new Error('檔案超過 50MB，請改用分段上傳');
    const meta = { name: name || path.basename(f) }; if (folder) meta.parents = [idFrom(folder)]; if (convert) meta.mimeType = { doc: 'application/vnd.google-apps.document', sheet: 'application/vnd.google-apps.spreadsheet', slides: 'application/vnd.google-apps.presentation' }[convert];
    const b = 'gws_' + crypto.randomBytes(10).toString('hex'); const body = Buffer.concat([Buffer.from(`--${b}\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n${JSON.stringify(meta)}\r\n--${b}\r\nContent-Type: ${mime || mimeOf(f)}\r\n\r\n`), data, Buffer.from(`\r\n--${b}--`)]);
    return this.api('POST', 'https://www.googleapis.com/upload/drive/v3/files', { query: { uploadType: 'multipart', fields: 'id,name,webViewLink', supportsAllDrives: true }, headers: { 'content-type': `multipart/related; boundary=${b}` }, body });
  }
  async driveDownload(id, saveAs, exportMime) {
    this.need(); id = idFrom(id); const info = await this.api('GET', `https://www.googleapis.com/drive/v3/files/${id}`, { query: { fields: 'id,name,mimeType', supportsAllDrives: true } }); let buf;
    if (/^application\/vnd\.google-apps\./.test(info.mimeType)) { const dflt = /spreadsheet/.test(info.mimeType) ? 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' : /presentation/.test(info.mimeType) ? 'application/vnd.openxmlformats-officedocument.presentationml.presentation' : 'application/pdf'; buf = await this.api('GET', `https://www.googleapis.com/drive/v3/files/${id}/export`, { query: { mimeType: exportMime || dflt }, raw: true }); }
    else buf = await this.api('GET', `https://www.googleapis.com/drive/v3/files/${id}`, { query: { alt: 'media', supportsAllDrives: true }, raw: true });
    const f = this.ctx.fsx.resolve(saveAs, 'workspace'); fs.mkdirSync(path.dirname(f), { recursive: true }); fs.writeFileSync(f, buf); return { name: info.name, path: saveAs, bytes: buf.length };
  }
  driveShare(id, email, role = 'reader', notify = true) { this.need(); const r = ['reader', 'commenter', 'writer'].includes(role) ? role : 'reader'; return this.api('POST', `https://www.googleapis.com/drive/v3/files/${idFrom(id)}/permissions`, { query: { sendNotificationEmail: notify, supportsAllDrives: true }, body: { type: 'user', role: r, emailAddress: email } }); }
  driveMkdir(name, parent) { this.need(); return this.api('POST', 'https://www.googleapis.com/drive/v3/files', { query: { fields: 'id,name,webViewLink' }, body: { name, mimeType: 'application/vnd.google-apps.folder', parents: parent ? [idFrom(parent)] : undefined } }); }
  driveTrash(id) { this.need(); return this.api('PATCH', `https://www.googleapis.com/drive/v3/files/${idFrom(id)}`, { query: { supportsAllDrives: true }, body: { trashed: true } }); }

  // ---------- Calendar ----------
  calList(timeMin, timeMax, max = 20, cal) { this.need(); return this.api('GET', `https://www.googleapis.com/calendar/v3/calendars/${encodeURIComponent(cal || this.cfg.default_calendar || 'primary')}/events`, { query: { timeMin, timeMax, maxResults: Math.min(+max || 20, 100), singleEvents: true, orderBy: 'startTime' } }); }
  calAdd(a) {
    this.need(); const tz = this.ctx.settings.get('tz'); const iso = (s) => { const m = /^(\d{4})[-/](\d{1,2})[-/](\d{1,2})(?:[ T](\d{1,2}):(\d{2}))?/.exec(String(s || '').trim()); if (!m) throw new Error(`時間格式要像 2026-11-20 14:30（收到：${s}）`); return { d: `${m[1]}-${pad(m[2])}-${pad(m[3])}`, t: m[4] == null ? null : `${pad(m[4])}:${m[5]}:00` }; };
    const s = iso(a.start); const allDay = a.all_day || s.t == null; let start, end;
    if (allDay) { const e = a.end ? iso(a.end).d : s.d; const nx = new Date(Date.UTC(+e.slice(0, 4), +e.slice(5, 7) - 1, +e.slice(8, 10) + 1)); start = { date: s.d }; end = { date: `${nx.getUTCFullYear()}-${pad(nx.getUTCMonth() + 1)}-${pad(nx.getUTCDate())}` }; }
    else { start = { dateTime: `${s.d}T${s.t}`, timeZone: tz }; if (a.end) { const e = iso(a.end); end = { dateTime: `${e.d}T${e.t || '00:00:00'}`, timeZone: tz }; } else { const dt = new Date(Date.UTC(+s.d.slice(0, 4), +s.d.slice(5, 7) - 1, +s.d.slice(8, 10), +s.t.slice(0, 2) + 1, +s.t.slice(3, 5))); end = { dateTime: `${dt.getUTCFullYear()}-${pad(dt.getUTCMonth() + 1)}-${pad(dt.getUTCDate())}T${pad(dt.getUTCHours())}:${pad(dt.getUTCMinutes())}:00`, timeZone: tz }; } }
    const body = { summary: a.title, location: a.location, description: a.details, start, end, attendees: emailList(a.guests).map((email) => ({ email })), recurrence: a.recur ? [String(a.recur).startsWith('RRULE') ? a.recur : 'RRULE:' + a.recur] : undefined };
    if (a.meet) body.conferenceData = { createRequest: { requestId: crypto.randomUUID(), conferenceSolutionKey: { type: 'hangoutsMeet' } } };
    return this.api('POST', `https://www.googleapis.com/calendar/v3/calendars/${encodeURIComponent(a.calendar || this.cfg.default_calendar || 'primary')}/events`, { query: { sendUpdates: body.attendees.length ? 'all' : 'none', conferenceDataVersion: a.meet ? 1 : 0 }, body });
  }
  calDelete(id, cal) { this.need(); return this.api('DELETE', `https://www.googleapis.com/calendar/v3/calendars/${encodeURIComponent(cal || 'primary')}/events/${id}`, { query: { sendUpdates: 'all' } }); }

  // ---------- Tasks ----------
  tasksList(list = '@default', all = false) { this.need(); return this.api('GET', `https://tasks.googleapis.com/tasks/v1/lists/${encodeURIComponent(list)}/tasks`, { query: { showCompleted: all, maxResults: 100 } }); }
  tasksAdd(title, { notes, due, list = '@default' } = {}) { this.need(); return this.api('POST', `https://tasks.googleapis.com/tasks/v1/lists/${encodeURIComponent(list)}/tasks`, { body: { title, notes, due: due ? new Date(due + 'T00:00:00Z').toISOString() : undefined } }); }
  tasksDone(id, list = '@default') { this.need(); return this.api('PATCH', `https://tasks.googleapis.com/tasks/v1/lists/${encodeURIComponent(list)}/tasks/${id}`, { body: { status: 'completed' } }); }
}
const MIMES = { '.pdf': 'application/pdf', '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.gif': 'image/gif', '.txt': 'text/plain', '.csv': 'text/csv', '.html': 'text/html', '.json': 'application/json', '.zip': 'application/zip',
  '.docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', '.xlsx': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', '.pptx': 'application/vnd.openxmlformats-officedocument.presentationml.presentation', '.md': 'text/markdown', '.mp3': 'audio/mpeg', '.mp4': 'video/mp4' };
const mimeOf = (f) => MIMES[path.extname(f).toLowerCase()] || 'application/octet-stream';
module.exports = { GWorkspace, idFrom, pick, DEFAULT_SCOPES, REDIRECT };
