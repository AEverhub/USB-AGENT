'use strict';
/**
 * 用講的改權限：管理員在 LINE／Discord／Telegram／App 說「讓小明可以用記帳」「AI 以後下載不用問我」，
 * AI 呼叫 permission_change → 這裡套用，App 的權限卡、設定頁同步變更（同一份資料）。
 *
 * 風險分級：
 *   低風險（收緊權限、給一般權限、短期開放）→ 立即生效
 *   高風險（拿掉審批、擴大 AI 檔案權限、給別人管理／終端機／寄信等權限）→ 產生 4 位數確認碼，
 *     管理員本人必須在 10 分鐘內親自回覆「確認 1234」才生效（AI 自己無法代為確認：確認碼只在使用者訊息裡才會被接受）
 *   永遠不開放（程式寫死）：簡訊／電話審批、密碼類設定、把別人升成管理員
 * 可以帶時限（until_minutes）：時間到自動恢復原狀。
 */
const crypto = require('crypto');
const { logger } = require('../core/log');
const log = logger('grants');

// AI 自己的行為政策（target='ai'）
const POLICIES = {
  shell: { label: 'AI 使用終端機（指令）', key: 'policy.ai_shell', allow: true, deny: false, risk: 'low' },
  manage_app: { label: 'AI 操作 App 設定與功能', key: 'policy.ai_can_manage_app', allow: true, deny: false, risk: 'low' },
  edit_rules: { label: 'AI 自己新增／修改系統規則', key: 'policy.ai_can_edit_rules', allow: true, deny: false, risk: 'low' },
  browser: { label: 'AI 使用瀏覽器', key: 'browser.enabled', allow: true, deny: false, risk: 'low' },
  group_all: { label: '群組裡不用 @ 也會回話', key: 'policy.group_trigger', allow: 'all', deny: 'mention', risk: 'low' },
  download_no_approval: { label: 'AI 下載檔案不用審批', key: 'policy.approve_downloads', allow: false, deny: true, risk: 'high' },
  mail_no_approval: { label: 'AI 寄信不用審批', key: 'google.send_requires_approval', allow: false, deny: true, risk: 'high' },
  new_user_no_approval: { label: '新用戶不用審核就能使用', key: 'policy.approve_new_users', allow: false, deny: true, risk: 'high' },
  fs_whole_app: { label: 'AI 檔案權限擴大到整個 App（含自己的程式）', key: 'policy.ai_fs_scope', allow: 'app', deny: 'workspace', risk: 'high' },
  linux_full: { label: 'AI 在 Linux 裡完整權限', key: 'termux.full_access', allow: true, deny: false, risk: 'high' },
};
// 給人的權限（target=某人或角色）；這些給「非管理員」屬於高風險
const HIGH_PERMS = new Set(['console_view', 'manage_users', 'manage_app', 'terminal', 'broadcast', 'google', 'phone', 'mcp', 'files', 'request_download']);
const NEVER = /簡訊|電話|sms|call|claim|密碼|password|token|金鑰|api[_ ]?key/i;
const CONFIRM_MS = 10 * 60e3;

class Grants {
  constructor(ctx) { this.ctx = ctx; }
  get db() { const d = this.ctx.store.db; if (!d.grants) d.grants = { pending: [], timed: [], log: [] }; return d.grants; }
  /** 描述給模型看 */
  static catalog(perms) { return `人或角色的權限：${perms.join(' ')}（其中 ${[...HIGH_PERMS].join('、')} 給非管理員要確認碼）。AI 政策（target=ai）：${Object.entries(POLICIES).map(([k, v]) => `${k}＝${v.label}${v.risk === 'high' ? '（高風險）' : ''}`).join('；')}`; }

  /** 解析成具體變更；不合法就丟錯 */
  plan({ target, perm, action, until_minutes }) {
    const { users, settings } = this.ctx; action = { allow: 'allow', grant: 'allow', 允許: 'allow', deny: 'deny', revoke: 'deny', 禁止: 'deny', default: 'default', reset: 'default', 恢復: 'default' }[String(action || '').toLowerCase()] || null;
    if (!action) throw new Error('action 要是 allow／deny／default');
    if (NEVER.test(String(perm))) throw new Error('這個項目（簡訊／電話審批、密碼、金鑰）不能用對話修改，請管理員到 App 內操作');
    const mins = Math.max(0, Math.min(+until_minutes || 0, 7 * 1440));
    const t = String(target || '').trim();
    if (/^(ai|AI|你|自己|助理)$/.test(t)) {
      const p = POLICIES[perm]; if (!p) throw new Error(`沒有「${perm}」這個 AI 政策。可用：${Object.keys(POLICIES).join('、')}`);
      const value = action === 'allow' ? p.allow : action === 'deny' ? p.deny : this._default(p.key);
      const loosen = action === 'allow' || (action === 'default' && JSON.stringify(this._default(p.key)) === JSON.stringify(p.allow));
      return { kind: 'policy', key: p.key, label: p.label, value, before: settings.get(p.key), risk: loosen ? p.risk : 'low', minutes: mins, desc: `${action === 'deny' ? '關閉' : action === 'allow' ? '開啟' : '恢復預設'}「${p.label}」` };
    }
    const perms = require('../core/settings').PERMS; if (!perms.includes(perm)) throw new Error(`沒有「${perm}」這個權限。可用：${perms.join(' ')}`);
    if (['staff', 'user', 'guest'].includes(t)) {
      const list = (settings.get('roles.' + t) || []).slice(); const next = action === 'allow' ? [...new Set([...list, perm])] : action === 'deny' ? list.filter((x) => x !== perm) : list;
      const risk = action === 'allow' && HIGH_PERMS.has(perm) ? 'high' : 'low';
      return { kind: 'role', role: t, key: 'roles.' + t, value: next, before: list, perm, risk, minutes: mins, desc: `${action === 'allow' ? '讓' : '不讓'}所有「${t}」使用 ${perm}` };
    }
    const p = users.find(t); if (!p) throw new Error(`找不到「${t}」這個人（用 list_users 查名稱）`);
    if (p.role === 'admin' && action === 'deny') throw new Error('不能限制管理員的權限');
    const allow = p.perms.allow.filter((x) => x !== perm); const deny = p.perms.deny.filter((x) => x !== perm);
    if (action === 'allow') allow.push(perm); if (action === 'deny') deny.push(perm);
    const risk = action === 'allow' && HIGH_PERMS.has(perm) && p.role !== 'admin' ? 'high' : 'low';
    return { kind: 'person', pid: p.id, name: users.label ? users.label(p) : p.name, value: { allow, deny }, before: { allow: p.perms.allow.slice(), deny: p.perms.deny.slice() }, perm, risk, minutes: mins, desc: `${action === 'allow' ? '允許' : action === 'deny' ? '禁止' : '恢復預設'}「${p.name || p.id}」使用 ${perm}` };
  }
  _default(key) { const D = require('../core/settings').DEFAULTS; return key.split('.').reduce((o, k) => (o == null ? undefined : o[k]), D); }
  _apply(c, who) {
    const { settings, users, store } = this.ctx;
    if (c.kind === 'person') { const p = users.byId(c.pid); if (!p) throw new Error('使用者已不存在'); p.perms.allow = c.value.allow; p.perms.deny = c.value.deny; store.touch(); }
    else settings.set(c.key, c.value, 'human');   // 已經過管理員本人（低風險直接／高風險確認碼）同意，用 human 身分寫入
    if (c.minutes) this.db.timed.push({ at: Date.now() + c.minutes * 60e3, change: { ...c, value: c.before, before: c.value, minutes: 0, desc: '時間到，恢復：' + c.desc } });
    this.db.log.push({ at: Date.now(), who, desc: c.desc, minutes: c.minutes }); if (this.db.log.length > 200) this.db.log.splice(0, this.db.log.length - 200);
    store.audit(who, 'grant', c.desc + (c.minutes ? `（${c.minutes} 分鐘）` : '')); log.info(`權限變更：${c.desc}`); store.touch();
  }
  /** AI 呼叫：低風險立即生效；高風險回傳確認碼 */
  request(args, person, chat) {
    if (!person || person.role !== 'admin') throw new Error('只有管理員可以用對話改權限');
    const c = this.plan(args); const until = c.minutes ? `，${c.minutes} 分鐘後自動恢復` : '';
    if (c.risk !== 'high') { this._apply(c, person.id); return { applied: true, text: `已生效：${c.desc}${until}。App 的權限頁也同步更新了。` }; }
    const code = String(crypto.randomInt(1000, 10000)); this.db.pending = this.db.pending.filter((x) => x.expires > Date.now()).slice(-20);
    this.db.pending.push({ code, pid: person.id, chat: chat || null, change: c, expires: Date.now() + CONFIRM_MS }); this.ctx.store.touch();
    return { applied: false, code, text: `這是高風險變更：${c.desc}${until}。請管理員本人在 10 分鐘內回覆「確認 ${code}」才會生效（不回覆就不會改）。` };
  }
  /** 平台層（不經 AI）：管理員親自回覆「確認 1234」 */
  confirm(person, code) {
    const i = this.db.pending.findIndex((x) => x.code === String(code) && x.pid === person.id && x.expires > Date.now());
    if (i < 0) return null; const p = this.db.pending.splice(i, 1)[0]; this._apply(p.change, person.id);
    this.ctx.notifier.push('warn', '高風險權限已變更', `${p.change.desc}（管理員以確認碼確認）`).catch(() => {});
    return `已確認並生效：${p.change.desc}${p.change.minutes ? `，${p.change.minutes} 分鐘後自動恢復` : ''}。`;
  }
  /** 一般用戶自己要權限 → 送管理員審批 */
  async ask(person, perm, reason, chat) {
    const perms = require('../core/settings').PERMS; if (!perms.includes(perm)) throw new Error(`沒有「${perm}」這個權限`);
    if (this.ctx.users.can(person, perm)) return { text: `你已經可以使用 ${perm} 了。` };
    const ap = await this.ctx.approvals.request({ kind: 'perm_request', summary: `${person.name || person.id} 想要「${perm}」權限${reason ? '：' + String(reason).slice(0, 80) : ''}`, payload: { pid: person.id, perm }, requester: person.id, chat });
    return { text: `已送給管理員審核（#${ap.id}），核准後就能用了。` };
  }
  /** 排程器每輪：到期的暫時權限恢復原狀 */
  tick() { const now = Date.now(); const due = this.db.timed.filter((x) => x.at <= now); if (!due.length) return 0; this.db.timed = this.db.timed.filter((x) => x.at > now); for (const d of due) { try { this._apply(d.change, 'system'); } catch (e) { log.warn('恢復權限失敗：' + e.message); } } return due.length; }
}
module.exports = { Grants, POLICIES, HIGH_PERMS };
