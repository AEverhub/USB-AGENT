'use strict';
/**
 * 生活查詢（26.11.3 Revise4）：地點、附近的店、路線時間、匯率。全部用免金鑰的公開服務：
 *   地點／地址：OpenStreetMap Nominatim　附近的店：Overpass API　路線：OSRM　匯率：open.er-api.com
 * 每個結果都附資料來源；路線另附 Google 地圖導航連結（大眾運輸時間以 Google 地圖為準）。
 */
const UA = 'AgentCenter/26.11 (personal assistant app)';
async function get(url, timeout = 15000, opt = {}) {
  const r = await fetch(url, { ...opt, headers: { 'user-agent': UA, 'accept-language': 'zh-TW,zh;q=0.9,en;q=0.8', ...(opt.headers || {}) }, signal: AbortSignal.timeout(timeout) });
  if (!r.ok) throw new Error(`${new URL(url).host} 回應 ${r.status}`); return r.json();
}
const LATLON = /^\s*(-?\d{1,2}(?:\.\d+)?)\s*,\s*(-?\d{1,3}(?:\.\d+)?)\s*$/;

/** 地名／地址 → 座標（可帶多個結果） */
async function geocode(q, limit = 5) {
  const m = LATLON.exec(String(q)); if (m) return [{ name: q, lat: +m[1], lon: +m[2], address: q }];
  const j = await get(`https://nominatim.openstreetmap.org/search?format=jsonv2&addressdetails=0&limit=${limit}&q=${encodeURIComponent(q)}`);
  return (j || []).map((x) => ({ name: x.name || String(x.display_name).split(',')[0], lat: +x.lat, lon: +x.lon, address: x.display_name, type: x.type }));
}
// 常用類別 → OpenStreetMap 標籤
const KINDS = [
  [/藥局|藥房|pharmacy/i, 'amenity=pharmacy', '藥局'], [/醫院|急診|hospital/i, 'amenity=hospital', '醫院'], [/診所|clinic|牙醫|dentist/i, 'amenity~"clinic|doctors|dentist"', '診所'],
  [/加油站|fuel|gas/i, 'amenity=fuel', '加油站'], [/便利商店|超商|7-?11|全家|萊爾富|ok超商|convenience/i, 'shop=convenience', '便利商店'], [/超市|量販|全聯|家樂福|supermarket/i, 'shop~"supermarket|hypermarket"', '超市'],
  [/咖啡|cafe|coffee/i, 'amenity=cafe', '咖啡店'], [/餐廳|吃飯|美食|restaurant|小吃/i, 'amenity~"restaurant|fast_food|food_court"', '餐廳'], [/早餐/i, 'amenity~"restaurant|fast_food|cafe"', '早餐店'],
  [/ATM|提款/i, 'amenity=atm', 'ATM'], [/銀行|bank/i, 'amenity=bank', '銀行'], [/停車|parking/i, 'amenity=parking', '停車場'], [/郵局|post/i, 'amenity=post_office', '郵局'],
  [/警察|派出所|police/i, 'amenity=police', '警察局'], [/廁所|洗手間|toilet/i, 'amenity=toilets', '廁所'], [/公園|park/i, 'leisure=park', '公園'], [/充電|charging/i, 'amenity=charging_station', '充電站'],
  [/捷運站|車站|火車站|station/i, 'railway=station', '車站'], [/公車站|bus/i, 'highway=bus_stop', '公車站'], [/健身|gym/i, 'leisure=fitness_centre', '健身房'], [/寵物|動物醫院|vet/i, 'amenity=veterinary', '動物醫院'],
];
function kindOf(s) { const k = KINDS.find(([re]) => re.test(String(s || ''))); return k ? { tag: k[1], label: k[2] } : null; }
function dist(a, b) { const R = 6371e3; const r = (x) => (x * Math.PI) / 180; const d = Math.sin(r(b.lat - a.lat) / 2) ** 2 + Math.cos(r(a.lat)) * Math.cos(r(b.lat)) * Math.sin(r(b.lon - a.lon) / 2) ** 2; return 2 * R * Math.asin(Math.sqrt(d)); }
const fmtD = (m) => (m >= 1000 ? (m / 1000).toFixed(m >= 10000 ? 0 : 1) + ' 公里' : Math.round(m / 10) * 10 + ' 公尺');
const fmtT = (s) => { const m = Math.round(s / 60); return m >= 60 ? `${Math.floor(m / 60)} 小時 ${m % 60} 分` : `${Math.max(1, m)} 分鐘`; };
const gmap = (q) => `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(q)}`;

/** 找地點：kind 是類別就找「附近的」，否則當地名／店名搜尋 */
async function search({ query, near, radius_m = 1500, limit = 8 }) {
  const k = kindOf(query);
  if (k && near) {
    const c = (await geocode(near, 1))[0]; if (!c) throw new Error(`找不到「${near}」在哪裡，請說更完整的地址或地標`);
    const r = Math.max(200, Math.min(+radius_m || 1500, 10000)); const [key, val] = k.tag.split(/(=|~)/).filter((x, i) => i !== 1);
    const op = k.tag.includes('~') ? '~' : '='; const qs = `[out:json][timeout:20];nwr["${key}"${op}${val.startsWith('"') ? val : `"${val}"`}](around:${r},${c.lat},${c.lon});out center 40;`;
    const j = await get('https://overpass-api.de/api/interpreter', 25000, { method: 'POST', body: 'data=' + encodeURIComponent(qs), headers: { 'content-type': 'application/x-www-form-urlencoded' } });
    const items = (j.elements || []).map((e) => { const p = { lat: e.lat ?? (e.center || {}).lat, lon: e.lon ?? (e.center || {}).lon }; const t = e.tags || {};
      return { name: t.name || t['name:zh'] || `（沒有名稱的${k.label}）`, d: dist(c, p), lat: p.lat, lon: p.lon, hours: t.opening_hours || '', phone: t.phone || t['contact:phone'] || '', addr: [t['addr:city'], t['addr:district'], t['addr:street'], t['addr:housenumber']].filter(Boolean).join('') }; })
      .filter((x) => x.lat).sort((a, b) => a.d - b.d).slice(0, limit);
    if (!items.length) return `「${c.name}」附近 ${fmtD(r)} 內，OpenStreetMap 上沒有登記的${k.label}（地圖資料不一定完整），可以看 Google 地圖：${gmap(k.label + ' near ' + c.address)}`;
    return `「${c.name}」附近的${k.label}（直線距離，由近到遠）：\n` + items.map((x, i) => `${i + 1}. ${x.name}｜${fmtD(x.d)}${x.addr ? '｜' + x.addr : ''}${x.hours ? '｜營業 ' + x.hours : ''}${x.phone ? '｜' + x.phone : ''}\n   ${gmap(x.name + ' ' + x.lat + ',' + x.lon)}`).join('\n')
      + '\n資料來源：OpenStreetMap（Overpass API）。營業時間可能過期，重要的請先打電話確認。';
  }
  const list = await geocode(near ? `${query} ${near}` : query, Math.min(limit, 8));
  if (!list.length) return `OpenStreetMap 找不到「${query}」。可以試試 Google 地圖：${gmap(query + (near ? ' ' + near : ''))}`;
  return list.map((x, i) => `${i + 1}. ${x.name}｜${x.address}\n   ${gmap(x.name + ' ' + x.lat + ',' + x.lon)}`).join('\n') + '\n資料來源：OpenStreetMap（Nominatim）';
}

/** 路線：開車用 OSRM 實算；走路／騎車用道路距離估算；大眾運輸給 Google 地圖連結 */
async function route({ from, to, mode = 'driving' }) {
  const [a, b] = await Promise.all([geocode(from, 1), geocode(to, 1)]); if (!a[0]) throw new Error(`找不到起點「${from}」`); if (!b[0]) throw new Error(`找不到終點「${to}」`);
  const A = a[0]; const B = b[0]; const link = `https://www.google.com/maps/dir/?api=1&origin=${encodeURIComponent(from)}&destination=${encodeURIComponent(to)}&travelmode=${{ walking: 'walking', cycling: 'bicycling', transit: 'transit' }[mode] || 'driving'}`;
  if (mode === 'transit') return `從「${A.name}」到「${B.name}」直線約 ${fmtD(dist(A, B))}。大眾運輸的班次與時間請看 Google 地圖（即時）：${link}`;
  const j = await get(`https://router.project-osrm.org/route/v1/driving/${A.lon},${A.lat};${B.lon},${B.lat}?overview=false`, 20000);
  const r = j.routes && j.routes[0]; if (!r) throw new Error('算不出路線（兩地之間可能沒有道路相連）');
  const sec = mode === 'walking' ? r.distance / 1.3 : mode === 'cycling' ? r.distance / 4.2 : r.duration;   // 走路約 4.7 km/h、騎車約 15 km/h
  const how = { driving: '開車', walking: '走路', cycling: '騎腳踏車' }[mode] || '開車';
  return `從「${A.name}」到「${B.name}」：道路距離 ${fmtD(r.distance)}，${how}約 ${fmtT(sec)}${mode === 'driving' ? '（不含塞車）' : '（依道路距離估算）'}。\n導航：${link}\n資料來源：OpenStreetMap＋OSRM`;
}

/** 匯率換算 */
const CUR = { 台幣: 'TWD', 新台幣: 'TWD', 元: 'TWD', 美金: 'USD', 美元: 'USD', 日幣: 'JPY', 日圓: 'JPY', 日元: 'JPY', 歐元: 'EUR', 人民幣: 'CNY', 港幣: 'HKD', 韓元: 'KRW', 韓幣: 'KRW', 英鎊: 'GBP', 澳幣: 'AUD', 加幣: 'CAD', 新加坡幣: 'SGD', 泰銖: 'THB', 越南盾: 'VND', 馬幣: 'MYR', 披索: 'PHP', 瑞士法郎: 'CHF' };
const code = (s) => { const t = String(s || '').trim(); return CUR[t] || t.toUpperCase(); };
async function fx({ amount = 1, from, to = 'TWD' }) {
  const f = code(from); const t = code(to); if (!/^[A-Z]{3}$/.test(f) || !/^[A-Z]{3}$/.test(t)) throw new Error('幣別請用 USD、JPY、TWD 這種代碼或「美金」「日幣」');
  const j = await get(`https://open.er-api.com/v6/latest/${f}`, 15000); if (j.result !== 'success' || !j.rates || !j.rates[t]) throw new Error('查不到這個幣別的匯率');
  const v = (+amount || 1) * j.rates[t]; const nf = (x) => x.toLocaleString('en-US', { maximumFractionDigits: x >= 100 ? 0 : 4 });
  return `${nf(+amount || 1)} ${f} ≈ ${nf(v)} ${t}（1 ${f} = ${j.rates[t]} ${t}）\n匯率時間：${j.time_last_update_utc}。這是國際參考匯率，銀行實際買賣價會有價差。\n資料來源：https://www.exchangerate-api.com`;
}
module.exports = { geocode, search, route, fx, kindOf, dist };
