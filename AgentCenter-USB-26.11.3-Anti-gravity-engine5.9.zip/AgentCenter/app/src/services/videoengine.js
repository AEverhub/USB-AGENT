'use strict';
/**
 * 26.11.3 Anti-gravity-engine4：專業影片引擎（在 Termux 裡跑 HyperFrames）
 *  HyperFrames（HeyGen 開源，Apache-2.0）：「寫 HTML、算出影片」——用無頭 Chromium 逐格 seek GSAP 時間軸、FFmpeg 編碼成 MP4，結果可重現。
 *  它需要 Node 22+、Chromium、FFmpeg，App 內建的 nodejs-mobile（Node 18、沒有瀏覽器）跑不動，所以裝在 Termux（App 已經有 Termux 橋接）。
 *  ・install()：在 Termux 背景安裝 nodejs-lts、ffmpeg、chromium、CJK 字型（從 Android 系統字型複製）、hyperframes、gsap、remotion（選用），
 *              並下載 7 個影片技能的官方檔案（HyperFrames、Remotion、GSAP、Pixel2Motion、Video Shotcraft、story-to-handdrawn-video、motion-design）
 *  ・check()／selfTest()：版本與 doctor 檢查、算一支 3 秒測試片；通過才會在 auto 模式下自動使用
 *  ・compile()：把分鏡規格編譯成 HyperFrames 組合（HTML＋暫停的 GSAP 時間軸，註冊在 window.__timelines；不用 Math.random／計時器，逐格可重現）
 *  ・render()：素材推進 Termux → 背景算圖 → 超過 24MB 先用 FFmpeg 壓小（橋接單檔上限 25MB）→ 取回 MP4
 * 手機（Android／Termux）不在 HyperFrames 官方支援清單：沒有 arm64 版 chrome-headless-shell，所以用 Termux 的 Chromium＋PRODUCER_FORCE_SCREENSHOT=true（官方提供的截圖模式）。
 * 做不出來時，影片工作室會自動改回 App 畫面算圖，不會讓使用者白等。
 */
const fs = require('fs');
const path = require('path');
const { clip } = require('../core/util');
const { musicWav } = require('./vidmedia');

const REMOTE = 'agent-video';
const MAX_PUT = 24 * 1024 * 1024;
/** 7 個影片技能的官方來源（install 時 git clone 到 Termux；匯入時標註授權） */
const SKILL_REPOS = [
  { repo: 'heygen-com/hyperframes', name: 'HyperFrames', license: 'Apache-2.0' },
  { repo: 'remotion-dev/skills', name: 'Remotion Agent Skills', license: '見該 repo（Remotion 本體：個人與小團隊免費，公司規模大要買授權）' },
  { repo: 'greensock/gsap-skills', name: 'GSAP AI Skills', license: 'MIT（GSAP 本體含所有外掛已免費，可商用）' },
  { repo: 'nolangz/pixel2motion', name: 'Pixel2Motion', license: 'MIT' },
  { repo: 'Vincentwei1021/video-shotcraft', name: 'Video Shotcraft', license: 'Apache-2.0（用到的 Remotion 另有授權；Freesound 音效各自授權）' },
  { repo: 'gnipbao/story-to-handdrawn-video', name: 'story-to-handdrawn-video', license: '未標示授權（僅供個人參考）' },
  { repo: 'LottieFiles/motion-design-skill', name: 'motion-design-skill（LottieFiles）', license: 'MIT' },
  { repo: 'rosby17/motion-design-skill', name: 'motion-design-skill（rosby17）', license: '未標示授權（僅供個人參考；部分工具需要 macOS 與 iziVoice）' },
];
const THEME = {
  dark: { bg: ['#0a0f1f', '#1c2452'], fg: '#f3f6ff', mute: '#aab5d3', ac: '#5b8cff', ac2: '#a78bfa' }, light: { bg: ['#f7f8fc', '#dfe6f6'], fg: '#131826', mute: '#56627a', ac: '#3b6cf6', ac2: '#8b5cf6' },
  vivid: { bg: ['#3a0ca3', '#c2185b'], fg: '#ffffff', mute: '#ffe0f0', ac: '#4cc9f0', ac2: '#ffd166' }, warm: { bg: ['#2a160d', '#7a3b1d'], fg: '#fff7ec', mute: '#f1cfae', ac: '#ffb454', ac2: '#ff7a59' },
  mono: { bg: ['#0e0e10', '#2a2a2e'], fg: '#fafafa', mute: '#b8b8be', ac: '#ffffff', ac2: '#9a9aa0' }, ocean: { bg: ['#022b3a', '#1f7a8c'], fg: '#f1fbff', mute: '#bfe4ef', ac: '#7ae7ff', ac2: '#ffd166' },
};
const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const r2 = (n) => Math.round(n * 1000) / 1000;
/** 旁白切成字幕段（≤ 22 字），依字數分配時間 */
function capSegments(text, start, dur) {
  const parts = String(text || '').split(/(?<=[，。！？；、,.!?;])/).map((x) => x.trim()).filter(Boolean); const segs = []; let cur = '';
  for (const p of parts) { if ((cur + p).length > 22 && cur) { segs.push(cur); cur = p; } else cur += p; } if (cur) segs.push(cur);
  const tot = segs.reduce((a, s) => a + s.length, 0) || 1; let t = start; return segs.map((s) => { const d = dur * s.length / tot; const o = { text: s, start: r2(t), dur: r2(d) }; t += d; return o; });
}
const SETUP = (repos) => `#!/data/data/com.termux/files/usr/bin/bash
# Agent中控中心：安裝影片引擎（HyperFrames＋GSAP＋FFmpeg＋Chromium＋Remotion）與 7 個影片技能的官方檔案
echo "STEP 1/7 安裝系統套件"; pkg update -y >/dev/null 2>&1; pkg install -y nodejs-lts ffmpeg git fontconfig fontconfig-utils || pkg install -y nodejs ffmpeg git fontconfig
NODE_MAJOR=$(node -p 'process.versions.node.split(".")[0]' 2>/dev/null || echo 0); if [ "$NODE_MAJOR" -lt 22 ]; then echo "Node $NODE_MAJOR 太舊，改裝最新版"; pkg install -y nodejs; fi
echo "STEP 2/7 安裝 Chromium"; command -v chromium >/dev/null 2>&1 || { pkg install -y x11-repo tur-repo; pkg install -y chromium || echo "WARN chromium 安裝失敗"; }
echo "STEP 3/7 中文字型（從 Android 系統複製，避免中文變方塊）"; mkdir -p ~/.fonts; for f in /system/fonts/NotoSansCJK*.ttc /system/fonts/NotoSerifCJK*.ttc /system/fonts/NotoColorEmoji.ttf; do [ -f "$f" ] && cp -f "$f" ~/.fonts/; done; fc-cache -f >/dev/null 2>&1 || true
echo "STEP 4/7 安裝 HyperFrames"; npm i -g hyperframes@latest || echo "WARN hyperframes 安裝失敗"
echo "STEP 5/7 安裝 GSAP 與 Remotion"; mkdir -p ~/${REMOTE} && cd ~/${REMOTE} && { [ -f package.json ] || npm init -y >/dev/null; }; npm i gsap@3 || echo "WARN gsap"; npm i remotion @remotion/cli @remotion/renderer >/dev/null 2>&1 && echo "OK remotion" || echo "WARN remotion 在 Android 上缺原生元件，請在電腦上用"
echo "STEP 6/7 下載影片技能"; mkdir -p ~/${REMOTE}/skills; cd ~/${REMOTE}/skills
${repos.map((r) => `d="${r.repo.replace('/', '__')}"; if [ -d "$d/.git" ]; then git -C "$d" pull --ff-only -q || true; else git clone -q --depth 1 "https://github.com/${r.repo}.git" "$d" && echo "OK skill ${r.repo}" || echo "WARN skill ${r.repo}"; fi`).join('\n')}
echo "STEP 7/7 檢查"; export PRODUCER_FORCE_SCREENSHOT=true PUPPETEER_EXECUTABLE_PATH="$(command -v chromium)" CHROME_PATH="$(command -v chromium)"; hyperframes doctor 2>&1 | tail -n 30 || true
echo "ALLDONE"
`;

const AV_LOOKS = [{ skin: '#f3cba5', hair: '#2b1d14', style: 'short', shirt: '#2f6fed' }, { skin: '#eab48c', hair: '#4a2c1a', style: 'long', shirt: '#d9467a', f: true }, { skin: '#c98e66', hair: '#141414', style: 'bun', shirt: '#1f9d74', f: true }, { skin: '#f6d6b8', hair: '#6b4a2e', style: 'glasses', shirt: '#7a5cff' }];
/** 虛擬主持人的 SVG（座標 -100～100；和 App 引擎畫的是同一個角色） */
function avatarSvg(L) {
  const fb = 'style="transform-box:fill-box;transform-origin:50% 50%"';
  return `<svg viewBox="-100 -100 200 200" width="100%" height="100%"><ellipse cx="0" cy="102" rx="78" ry="50" fill="${L.shirt}"/><path d="M-16 55 L0 75 L16 55Z" fill="#ffffff55"/><rect x="-12" y="28" width="24" height="30" fill="${L.skin}"/>
<g id="avh" style="transform-origin:0px 60px">${L.style === 'long' ? `<ellipse cx="-34" cy="8" rx="15" ry="44" transform="rotate(5 -34 8)" fill="${L.hair}"/><ellipse cx="34" cy="8" rx="15" ry="44" transform="rotate(-5 34 8)" fill="${L.hair}"/>` : ''}<ellipse cx="0" cy="-3" rx="38" ry="45" fill="${L.skin}"/><ellipse cx="-38" cy="-1" rx="6" ry="10" fill="${L.skin}"/><ellipse cx="38" cy="-1" rx="6" ry="10" fill="${L.skin}"/>
<path d="M-41 -31 A41 24 0 0 1 41 -31Z" fill="${L.hair}"/><ellipse cx="-12" cy="-33" rx="30" ry="14" transform="rotate(-20 -12 -33)" fill="${L.hair}"/>${L.style === 'bun' ? `<circle cx="0" cy="-55" r="15" fill="${L.hair}"/>` : ''}${L.style === 'short' ? `<ellipse cx="22" cy="-31" rx="20" ry="12" transform="rotate(23 22 -31)" fill="${L.hair}"/>` : ''}
<path d="M-22 -15 L-8 -17 M8 -17 L22 -15" stroke="${L.hair}" stroke-width="${L.f ? 2.2 : 4}" stroke-linecap="round"/><g id="ave" ${fb}><ellipse cx="-15" cy="-3" rx="4.5" ry="5.5" fill="#1d1a24"/><ellipse cx="15" cy="-3" rx="4.5" ry="5.5" fill="#1d1a24"/><circle cx="-13.5" cy="-5" r="1.4" fill="#fff"/><circle cx="16.5" cy="-5" r="1.4" fill="#fff"/></g>
${L.style === 'glasses' ? '<g fill="none" stroke="#2a2a2a" stroke-width="2.2"><circle cx="-15" cy="-3" r="10"/><circle cx="15" cy="-3" r="10"/><path d="M-5 -4 L5 -4"/></g>' : ''}<ellipse cx="-24" cy="11" rx="7" ry="4" fill="#ff7a8a44"/><ellipse cx="24" cy="11" rx="7" ry="4" fill="#ff7a8a44"/>
${L.f ? '<path d="M-18.5 -12 L-22 -15 M18.5 -12 L22 -15" stroke="#1d1a24" stroke-width="1.4"/>' : ''}<ellipse id="avm" cx="0" cy="21" rx="12" ry="3" fill="${L.f ? '#b8324a' : '#7a2633'}" ${fb}/></g></svg>`;
}
class VideoEngine {
  constructor(ctx) { this.ctx = ctx; }
  get T() { return this.ctx.termux; }
  get st() { const m = this.ctx.store.db.meta = this.ctx.store.db.meta || {}; if (!m.video_engine) m.video_engine = {}; return m.video_engine; }
  set(o) { Object.assign(this.st, o, { updated: Date.now() }); this.ctx.store.touch(); }
  ready() { try { return !!(this.T && this.T.ready()); } catch { return false; } }
  passed() { return this.ready() && this.st.passed === true; }
  /** 這支影片能不能交給 HyperFrames：主持人影片的聲音走 App 引擎；單一素材超過 24MB 推不進 Termux */
  usable(spec) {
    if (!this.ready() || !spec || spec.presenter) return false;
    const ws = this.ctx.paths.workspace; for (const s of spec.scenes || []) for (const k of ['image', 'footage', 'voice']) if (s[k]) { try { if (fs.statSync(path.join(ws, s[k])).size > MAX_PUT) return false; } catch { return false; } }
    return true;
  }
  state() { const s = this.st; return { termux: this.ready(), installing: !!s.install_job && !s.installed_at, install_job: s.install_job || '', installed_at: s.installed_at || 0, passed: !!s.passed, tested_at: s.tested_at || 0, test_error: s.test_error || '', versions: s.versions || {}, skills: s.skills || [], imported: s.imported || [], doctor: s.doctor || '', engine: this.ctx.settings.get('video.engine', 'auto') }; }
  async install() {
    if (!this.ready()) throw new Error('Termux 還沒設定：到 App「瀏覽器」頁的「Termux 環境」卡片完成安裝，再回來按「安裝影片引擎」');
    const script = SETUP(SKILL_REPOS); const local = path.join(this.ctx.paths.workspace, 'videos', 'engine-setup.sh'); fs.mkdirSync(path.dirname(local), { recursive: true }); fs.writeFileSync(local, script);
    await this.T.filePut(path.relative(this.ctx.paths.workspace, local).split(path.sep).join('/'), `${REMOTE}/setup.sh`);
    const r = await this.T.exec(`mkdir -p ~/${REMOTE} && bash ~/${REMOTE}/setup.sh`, { background: true, timeout_s: 3600 });
    this.set({ install_job: r.id, installed_at: 0, passed: false }); this.ctx.store.audit('app', 'video_engine.install', r.id || ''); return { job: r.id, text: '已在 Termux 背景安裝影片引擎（約 10～30 分鐘，看網路與手機速度）。裝好後按「檢查」再按「測試算圖」。' };
  }
  async installLog() { const id = this.st.install_job; if (!id) return { log: '', done: false }; const r = await this.T.jobLog(id, 6000); const log = String(r.out || r.log || r.text || ''); const done = /ALLDONE/.test(log); if (done && !this.st.installed_at) this.set({ installed_at: Date.now() }); return { log: clip(log, 6000), done }; }
  async check() {
    const cmd = `cd ~ ; echo "node=$(node -v 2>/dev/null)"; echo "ffmpeg=$(ffmpeg -version 2>/dev/null | head -n1 | cut -d' ' -f3)"; echo "chromium=$(command -v chromium 2>/dev/null)"; echo "hyperframes=$(hyperframes --version 2>/dev/null | tail -n1)"; echo "gsap=$( [ -f ~/${REMOTE}/node_modules/gsap/dist/gsap.min.js ] && echo yes)"; echo "remotion=$( [ -d ~/${REMOTE}/node_modules/remotion ] && echo yes)"; echo "fonts=$(ls ~/.fonts 2>/dev/null | grep -ci cjk)"; echo "skills=$(ls ~/${REMOTE}/skills 2>/dev/null | tr '\\n' ',')"`;
    const r = await this.T.exec(cmd, { timeout_s: 60 }); const out = String(r.out || r.text || ''); const kv = {}; for (const l of out.split('\n')) { const m = /^(\w+)=(.*)$/.exec(l.trim()); if (m) kv[m[1]] = m[2].trim(); }
    const versions = { node: kv.node || '', ffmpeg: kv.ffmpeg || '', chromium: kv.chromium ? 'yes' : '', hyperframes: kv.hyperframes || '', gsap: kv.gsap || '', remotion: kv.remotion || '', cjk_fonts: +kv.fonts || 0 };
    const skills = (kv.skills || '').split(',').filter(Boolean).map((d) => d.replace('__', '/'));
    let doctor = ''; if (versions.hyperframes) { try { const d = await this.T.exec(`export PRODUCER_FORCE_SCREENSHOT=true PUPPETEER_EXECUTABLE_PATH="$(command -v chromium)" CHROME_PATH="$(command -v chromium)"; hyperframes doctor 2>&1 | tail -n 25`, { timeout_s: 120 }); doctor = clip(String(d.out || d.text || ''), 3000); } catch (e) { doctor = '執行 doctor 失敗：' + e.message; } }
    const nodeOk = +(String(versions.node).replace(/^v/, '').split('.')[0]) >= 22;
    const missing = [!nodeOk && 'Node 22+', !versions.ffmpeg && 'FFmpeg', !versions.chromium && 'Chromium', !versions.hyperframes && 'HyperFrames', !versions.gsap && 'GSAP', !versions.cjk_fonts && '中文字型'].filter(Boolean);
    this.set({ versions, skills, doctor }); return { versions, skills, doctor, ok: !missing.length, missing };
  }
  /** 把下載的官方技能檔（SKILL.md）匯入 App 的技能庫，AI 用 skill_read 就讀得到 */
  async importSkills() {
    const list = await this.T.exec(`cd ~/${REMOTE}/skills 2>/dev/null && find . -name SKILL.md -size -200k 2>/dev/null | head -n 60`, { timeout_s: 60 });
    const files = String(list.out || list.text || '').split('\n').map((x) => x.trim().replace(/^\.\//, '')).filter((x) => x.endsWith('SKILL.md'));
    if (!files.length) throw new Error('Termux 裡還沒有技能檔：先按「安裝影片引擎」');
    const done = []; const tmp = 'videos/.skill-import.md';
    for (const f of files) {
      const repoDir = f.split('/')[0]; const meta = SKILL_REPOS.find((r) => r.repo.replace('/', '__') === repoDir); if (!meta) continue;
      const sub = f.split('/').slice(1, -1).filter((x) => x !== 'skills').join('-') || 'main';
      const name = ('vs-' + meta.repo.split('/')[1] + '-' + sub).toLowerCase().replace(/[^a-z0-9-_]+/g, '-').replace(/-+/g, '-').slice(0, 48).replace(/-$/, '');
      try { await this.T.fileGet(`${REMOTE}/skills/${f}`, tmp); let txt = fs.readFileSync(path.join(this.ctx.paths.workspace, tmp), 'utf8');
        const refs = await this.T.exec(`cd ~/${REMOTE}/skills/${path.posix.dirname(f)} && ls references 2>/dev/null | head -n 30`, { timeout_s: 30 }).then((r) => String(r.out || r.text || '').split('\n').filter(Boolean)).catch(() => []);
        txt = `# ${meta.name}：${sub}\n> 來源：https://github.com/${meta.repo}（${f}）｜授權：${meta.license}｜這份是官方原文，在 Termux 執行；檔案在 ~/${REMOTE}/skills/${f}${refs.length ? `\n> 參考檔（用 termux_exec cat 讀）：${refs.map((x) => `~/${REMOTE}/skills/${path.posix.dirname(f)}/references/${x}`).join('、')}` : ''}\n\n` + txt;
        this.ctx.skills.save(name, txt); done.push(name);
      } catch { /* 跳過這份 */ }
    }
    try { fs.unlinkSync(path.join(this.ctx.paths.workspace, tmp)); } catch { /* ignore */ }
    this.set({ imported: done }); this.ctx.store.audit('app', 'video_engine.import', String(done.length)); return { imported: done };
  }
  /** 算一支 3 秒測試片；成功才在 auto 模式下自動使用 */
  async selfTest() {
    const spec = require('./video').normalize({ title: '引擎測試', size: 'landscape', music: 'calm', scenes: [{ layout: 'title', title: '引擎測試', text: 'HyperFrames', duration: 1.6 }, { layout: 'bullets', title: '中文字', bullets: ['一', '二'], duration: 1.6 }] }, this.ctx.paths.workspace);
    const t0 = Date.now();
    try { const r = await this.render('selftest', spec, () => {}); if (!r.buf || r.buf.length < 2000) throw new Error('輸出檔太小'); this.set({ passed: true, tested_at: Date.now(), test_error: '', test_sec: Math.round((Date.now() - t0) / 1000) }); return { ok: true, sec: Math.round((Date.now() - t0) / 1000), size: r.buf.length }; }
    catch (e) { this.set({ passed: false, tested_at: Date.now(), test_error: clip(String(e.message || e), 400) }); return { ok: false, error: this.st.test_error }; }
  }
  /** 分鏡規格 → HyperFrames 組合；回傳 { html, assets:[{ local, name }], music } */
  compile(spec) {
    const th = { ...(THEME[spec.theme] || THEME.dark) }; if (spec.accent) th.ac = spec.accent; const W = spec.w, H = spec.h, k = W / 720, port = H > W * 1.2;
    const assets = []; const add = (rel, name) => { assets.push({ local: rel, name }); return name; };
    let t = 0; const parts = []; const tl = []; const audio = [];
    const hasVoice = spec.scenes.some((s) => s.voice);
    spec.scenes.forEach((s, i) => {
      const st = r2(t), d = r2(s.duration), en = r2(t + s.duration); const id = `s${i}`; const bg = s.bg && s.bg.length ? `linear-gradient(160deg,${s.bg[0]},${s.bg[1] || th.bg[1]})` : `linear-gradient(160deg,${th.bg[0]},${th.bg[1]})`;
      let media = '';
      if (s.footage) media = `<video class="media" src="${add(s.footage, `v${i}${path.extname(s.footage)}`)}" muted playsinline data-start="${st}" data-duration="${d}" data-track-index="1"></video>`;
      else if (s.image) media = `<img class="media${s.layout === 'screen' ? ' screen' : ''}" src="${add(s.image, `i${i}${path.extname(s.image)}`)}" alt="">`;
      const shade = media && ['image', 'footage'].includes(s.layout) ? '<div class="shade"></div>' : '';
      let inner = '';
      if (s.layout === 'bullets') inner = `${s.title ? `<h2 class="ttl">${esc(s.title)}</h2><i class="bar"></i>` : ''}<ul>${s.bullets.map((b, j) => `<li><b>${j + 1}</b><span>${esc(b)}</span></li>`).join('')}</ul>`;
      else if (s.layout === 'stat') inner = `<div class="num" data-v="${esc(s.stat.value)}">${esc(s.stat.value)}</div><p class="lbl">${esc(s.stat.label)}</p>${s.title ? `<p class="sub">${esc(s.title)}</p>` : ''}`;
      else if (s.layout === 'quote') inner = `<div class="qm">“</div><p class="qt">${esc(s.text || s.title)}</p>${s.title && s.text ? `<p class="sub">— ${esc(s.title)}</p>` : ''}`;
      else if (s.layout === 'title' || s.layout === 'end') inner = `<h1 class="ttl">${esc(s.title || s.text)}</h1><i class="bar c"></i>${s.title && s.text ? `<p class="sub">${esc(s.text)}</p>` : ''}${s.layout === 'end' && spec.credits && spec.credits.length ? `<p class="cred">素材：${esc(spec.credits.join('、'))}</p>` : ''}`;
      else inner = `${s.title ? `<h2 class="ttl">${esc(s.title)}</h2>` : ''}${s.text ? `<p class="txt">${esc(s.text)}</p>` : ''}`;
      const cls = `scene ${s.layout}${['image', 'footage'].includes(s.layout) ? ' over' : ''}${['title', 'end', 'stat'].includes(s.layout) ? ' center' : ''}`;
      const caps = s.narration ? capSegments(s.narration, st + 0.15, Math.max(0.5, d - 0.4)) : s.caption ? [{ text: s.caption, start: r2(st + 0.3), dur: r2(Math.max(0.5, d - 0.6)) }] : [];
      parts.push(`<section id="${id}" class="clip ${cls}" data-start="${st}" data-duration="${d}" data-track-index="0" style="background:${bg}">${media}${shade}<div class="inner">${inner}</div>${caps.map((c, j) => `<div class="cap" id="${id}c${j}">${esc(c.text)}</div>`).join('')}</section>`);
      tl.push(`tl.set('#${id}',{autoAlpha:1},${st});`);
      if (i < spec.scenes.length - 1) tl.push(`tl.set('#${id}',{autoAlpha:0},${en});`);
      if (s.image && ['image', 'footage', 'screen'].includes(s.layout) || s.footage) tl.push(`tl.fromTo('#${id} .media',{scale:${s.layout === 'screen' ? 1.0 : 1}},{scale:${s.layout === 'screen' ? 1.08 : 1.12},${s.layout === 'screen' ? 'rotationX:0,' : ''}duration:${d},ease:'none'},${st});`);
      if (s.anim === 'draw' && s.image) tl.push(`tl.fromTo('#${id} .media',{clipPath:'inset(0 100% 0 0)',filter:'grayscale(1) contrast(1.6)'},{clipPath:'inset(0 0% 0 0)',duration:${r2(Math.min(1.6, d * 0.4))},ease:'power2.inOut'},${st});tl.to('#${id} .media',{filter:'grayscale(0) contrast(1)',duration:${r2(Math.min(1.8, d * 0.4))},ease:'power1.inOut'},${r2(st + Math.min(1.6, d * 0.4))});`);
      const ent = s.anim === 'slide' ? '{autoAlpha:0,x:-60}' : s.anim === 'zoom' ? '{autoAlpha:0,scale:0.88}' : '{autoAlpha:0,y:40}';
      tl.push(`tl.fromTo('#${id} .ttl, #${id} .num, #${id} .qm',${ent},{autoAlpha:1,x:0,y:0,scale:1,duration:0.6,ease:'power3.out'},${r2(st + 0.1)});`);
      tl.push(`tl.fromTo('#${id} .sub, #${id} .txt, #${id} .lbl, #${id} .qt, #${id} .cred',{autoAlpha:0,y:24},{autoAlpha:1,y:0,duration:0.55,ease:'power3.out',stagger:0.12},${r2(st + 0.35)});`);
      tl.push(`tl.fromTo('#${id} .bar',{scaleX:0},{scaleX:1,duration:0.6,ease:'power2.out'},${r2(st + 0.25)});`);
      if (s.layout === 'bullets' && s.bullets.length) { const step = r2(Math.min(0.55, Math.max(0.2, (d - 1.2) / s.bullets.length))); tl.push(`tl.fromTo('#${id} li',{autoAlpha:0,x:-40},{autoAlpha:1,x:0,duration:0.45,ease:'power3.out',stagger:${step}},${r2(st + 0.35)});`); }
      if (s.layout === 'stat') { const m = /^([^\d-]*)(-?[\d,]*\.?\d+)(.*)$/.exec(String(s.stat.value)); if (m) { const num = Number(m[2].replace(/,/g, '')); const dec = (m[2].split('.')[1] || '').length; if (isFinite(num)) tl.push(`(function(){const o={v:0};const el=document.querySelector('#${id} .num');tl.to(o,{v:${num},duration:1.3,ease:'power2.out',onUpdate(){let s=o.v.toFixed(${dec});${m[2].includes(',') ? "s=s.replace(/\\B(?=(\\d{3})+(?!\\d))/g,',');" : ''}el.textContent=${JSON.stringify(m[1])}+s+${JSON.stringify(m[3])};}},${st});})();`); } }
      if (i < spec.scenes.length - 1) tl.push(`tl.to('#${id} .inner',{autoAlpha:0,duration:0.35,ease:'power2.in'},${r2(Math.max(st, en - 0.35))});`);
      caps.forEach((c, j) => { tl.push(`tl.fromTo('#${id}c${j}',{autoAlpha:0},{autoAlpha:1,duration:0.15},${c.start});`); if (j < caps.length - 1 || i < spec.scenes.length - 1) tl.push(`tl.to('#${id}c${j}',{autoAlpha:0,duration:0.12},${r2(c.start + c.dur - 0.12)});`); });
      if (s.voice) audio.push(`<audio src="${add(s.voice, `n${i}${path.extname(s.voice)}`)}" data-start="${r2(st + 0.15)}" data-duration="${r2(Math.min(d, (s.voice_dur || d) + 0.1))}" data-track-index="2" data-volume="1"></audio>`);
      t += s.duration;
    });
    const total = r2(t); let music = false;
    if (spec.music && spec.music !== 'none') { music = true; audio.push(`<audio src="music.wav" data-start="0" data-duration="${total}" data-track-index="3" data-volume="${hasVoice ? 0.32 : 0.8}"></audio>`); }
    tl.push(`tl.fromTo('#prog',{scaleX:0},{scaleX:1,duration:${total},ease:'none'},0);`);
    // engine4.5：免費虛擬主持人（虛構插畫角色）：嘴型照旁白音量逐格設定、定時眨眼、輕微擺頭——全部寫死在時間軸上，逐格可重現
    let avatar = ''; if (spec.avatar && !spec.presenter) {
      const L = AV_LOOKS[(spec.avatar.look || 0) % AV_LOOKS.length]; const big = spec.style === 'presenter'; const R = Math.round((port ? (big ? 130 : 100) : (big ? 95 : 75)) * k);
      avatar = `<div id="av" style="position:absolute;width:${R * 2}px;height:${R * 2}px;right:${Math.round(34 * k)}px;top:${Math.round((port ? 70 : 40) * k)}px;border-radius:50%;overflow:hidden;box-shadow:0 0 0 ${Math.round(R * 0.06)}px ${th.ac}aa;background:linear-gradient(180deg,${th.ac2},${th.ac})">${avatarSvg(L)}</div>`;
      let at = 0; for (const sc of spec.scenes) { const vt0 = at + 0.15; let last = -1; const m = sc.mouth || ''; const dur = sc.voice ? (sc.voice_dur || 0) : 0;
        const n = m ? m.length : sc.narration && dur ? Math.floor(dur * 15) : 0;
        for (let f = 0; f <= n; f++) { const vt = f / 15; let o = f === n ? 0 : m ? (+m[f] || 0) / 9 : Math.max(0, Math.min(1, 0.35 + 0.45 * Math.sin(vt * 17) * Math.sin(vt * 5.3 + 1))); o = Math.round(o * 10) / 10; if (o !== last) { tl.push(`tl.set('#avm',{scaleY:${r2(0.2 + o * 3)}},${r2(vt0 + vt)});`); last = o; } }
        at += sc.duration; }
      for (let b = 1.2; b < total; b += 3.7) tl.push(`tl.set('#ave',{scaleY:0.1},${r2(b)});tl.set('#ave',{scaleY:1},${r2(b + 0.12)});`);
      for (let b = 0, k2 = 0; b < total; b += 2.4, k2++) tl.push(`tl.to('#avh',{rotation:${k2 % 2 ? -2 : 2},duration:2.4,ease:'sine.inOut'},${r2(b)});`);
    }
    const css = `*{box-sizing:border-box;margin:0;padding:0}html,body{width:${W}px;height:${H}px;overflow:hidden;background:#000}
body{font-family:"Noto Sans CJK TC","Noto Sans CJK SC","Noto Sans TC","PingFang TC","Microsoft JhengHei",sans-serif;color:${th.fg}}
#root{position:relative;width:${W}px;height:${H}px;overflow:hidden}
.scene{position:absolute;inset:0;visibility:hidden;opacity:0;overflow:hidden}
.media{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;transform-origin:50% 50%}
.media.screen{inset:${Math.round(H * 0.1)}px ${Math.round(W * 0.07)}px auto;width:${Math.round(W * 0.86)}px;height:auto;max-height:${Math.round(H * 0.62)}px;object-fit:contain;border-radius:${Math.round(18 * k)}px;box-shadow:0 ${Math.round(30 * k)}px ${Math.round(80 * k)}px #000a;transform:perspective(1400px) rotateX(8deg)}
.shade{position:absolute;inset:0;background:linear-gradient(180deg,#0000 35%,#000000c8)}
.inner{position:absolute;left:${Math.round(56 * k)}px;right:${Math.round(56 * k)}px;top:${port ? '28%' : '20%'}}
.over .inner{top:auto;bottom:${Math.round((port ? 240 : 110) * k)}px}.screen .inner{top:auto;bottom:${Math.round((port ? 230 : 90) * k)}px}
.center .inner{text-align:center;top:${port ? '36%' : '30%'}}
h1{font-size:${Math.round((port ? 76 : 68) * k)}px;font-weight:800;line-height:1.2}h2{font-size:${Math.round(54 * k)}px;font-weight:800;line-height:1.25;margin-bottom:${Math.round(18 * k)}px}
.over h2,.over h1{color:#fff}.sub{font-size:${Math.round(32 * k)}px;color:${th.mute};margin-top:${Math.round(22 * k)}px;line-height:1.45}.over .sub,.over .txt{color:#e8ecf6}
.txt{font-size:${Math.round(36 * k)}px;line-height:1.5;color:${th.mute}}.cred{font-size:${Math.round(20 * k)}px;color:${th.mute};margin-top:${Math.round(30 * k)}px}
.bar{display:block;height:${Math.round(7 * k)}px;width:${Math.round(90 * k)}px;border-radius:9px;background:linear-gradient(90deg,${th.ac},${th.ac2});transform-origin:0 50%;margin:${Math.round(10 * k)}px 0 ${Math.round(24 * k)}px}.bar.c{margin:${Math.round(22 * k)}px auto 0;transform-origin:50% 50%}
ul{list-style:none}li{display:flex;gap:${Math.round(18 * k)}px;align-items:flex-start;font-size:${Math.round(38 * k)}px;font-weight:600;margin:${Math.round(22 * k)}px 0;line-height:1.35}
li b{flex:none;width:${Math.round(40 * k)}px;height:${Math.round(40 * k)}px;border-radius:${Math.round(11 * k)}px;background:${th.ac};color:${th.bg[0]};font-size:${Math.round(22 * k)}px;display:grid;place-items:center;margin-top:${Math.round(4 * k)}px}
.num{font-size:${Math.round(150 * k)}px;font-weight:900;line-height:1;background:linear-gradient(180deg,${th.ac},${th.ac2});-webkit-background-clip:text;background-clip:text;color:transparent}
.lbl{font-size:${Math.round(40 * k)}px;font-weight:700;margin-top:${Math.round(24 * k)}px}.qm{font-family:Georgia,serif;font-size:${Math.round(200 * k)}px;line-height:.8;color:${th.ac}}.qt{font-size:${Math.round(44 * k)}px;line-height:1.5;font-weight:600}
.cap{position:absolute;left:${Math.round(44 * k)}px;right:${Math.round(44 * k)}px;bottom:${Math.round((port ? 140 : 56) * k)}px;padding:${Math.round(12 * k)}px ${Math.round(18 * k)}px;border-radius:${Math.round(14 * k)}px;background:#000000b0;color:#fff;font-size:${Math.round(30 * k)}px;font-weight:600;line-height:1.35;text-align:center;visibility:hidden;opacity:0}
#prog{position:absolute;left:0;right:0;bottom:0;height:${Math.round(6 * k)}px;background:linear-gradient(90deg,${th.ac},${th.ac2});transform-origin:0 50%}
#wm{position:absolute;left:${Math.round(40 * k)}px;top:${Math.round(34 * k)}px;font-size:${Math.round(22 * k)}px;font-weight:600;opacity:.55;color:${th.fg}}
.handdrawn .media{background:#fff}`;
    const html = `<!doctype html>
<html lang="zh-Hant">
<head><meta charset="utf-8"><title>${esc(spec.title)}</title><style>${css}</style></head>
<body>
<div id="root" data-composition-id="main" data-start="0" data-duration="${total}" data-width="${W}" data-height="${H}" class="${esc(spec.style || 'motion')}">
${parts.join('\n')}
${avatar}
${spec.watermark && spec.title ? `<div id="wm">${esc(spec.title.slice(0, 24))}</div>` : ''}
<div id="prog"></div>
${audio.join('\n')}
</div>
<script src="gsap.min.js"></script>
<script>
// HyperFrames 規則：時間軸建立時暫停、註冊在 window.__timelines；不用亂數、系統時間或計時器，逐格 seek 結果可重現
const tl = gsap.timeline({ paused: true });
window.__timelines = window.__timelines || {};
window.__timelines["main"] = tl;
${tl.join('\n')}
tl.set({}, {}, ${total});
</script>
</body>
</html>
`;
    return { html, assets, music, total };
  }
  /** 素材推進 Termux、背景算圖、取回 MP4 */
  async render(id, spec, onProgress = () => {}) {
    if (!this.ready()) throw new Error('Termux 沒有連線');
    const ws = this.ctx.paths.workspace; const c = this.compile(spec); const dir = `${REMOTE}/projects/${String(id).replace(/[^\w-]/g, '')}`;
    const tmpDir = path.join(ws, 'videos', 'assets', String(id), 'hf'); fs.mkdirSync(tmpDir, { recursive: true });
    fs.writeFileSync(path.join(tmpDir, 'index.html'), c.html); const rel = (f) => path.relative(ws, f).split(path.sep).join('/');
    await this.T.exec(`rm -rf ~/${dir} && mkdir -p ~/${dir}`, { timeout_s: 30 });
    await this.T.filePut(rel(path.join(tmpDir, 'index.html')), `${dir}/index.html`);
    if (c.music) { fs.writeFileSync(path.join(tmpDir, 'music.wav'), musicWav(spec.music, c.total)); await this.T.filePut(rel(path.join(tmpDir, 'music.wav')), `${dir}/music.wav`); }
    for (const a of c.assets) await this.T.filePut(a.local, `${dir}/${a.name}`);
    onProgress(5);
    const cmd = `cd ~/${dir} && cp ~/${REMOTE}/node_modules/gsap/dist/gsap.min.js ./ && export PRODUCER_FORCE_SCREENSHOT=true PUPPETEER_EXECUTABLE_PATH="$(command -v chromium)" CHROME_PATH="$(command -v chromium)" && hyperframes render --output out.mp4 --fps 30 --quality standard 2>&1; code=$?; if [ $code -eq 0 ] && [ -f out.mp4 ]; then s=$(stat -c%s out.mp4); if [ "$s" -gt ${MAX_PUT} ]; then ffmpeg -y -loglevel error -i out.mp4 -c:v libx264 -preset veryfast -crf 30 -c:a aac -b:a 96k small.mp4 && mv small.mp4 out.mp4; fi; echo "RENDER_OK $(stat -c%s out.mp4)"; else echo "RENDER_FAIL $code"; fi`;
    const job = await this.T.exec(cmd, { background: true, timeout_s: Math.max(900, Math.round(c.total * 30)) });
    const t0 = Date.now(); const limit = Math.max(15 * 60e3, c.total * 30e3); let log = '';
    while (Date.now() - t0 < limit) {
      await new Promise((r) => setTimeout(r, this._pollMs || 4000));
      let running = true; try { const r = await this.T.jobLog(job.id, 3000); log = String(r.out || r.log || r.text || ''); running = r.running !== false; } catch { continue; }
      if (/RENDER_OK/.test(log)) break;
      if (!running && !/RENDER_FAIL/.test(log)) throw new Error('HyperFrames 算圖中斷：' + clip(log.slice(-300), 300)); if (/RENDER_FAIL/.test(log)) throw new Error('HyperFrames 算圖失敗：' + clip(log.split('\n').filter((l) => /error|Error|fail|找不到|not found/i.test(l)).slice(-3).join(' ／ ') || log.slice(-300), 300));
      const ps = [...log.matchAll(/(\d{1,3})(?:\.\d+)?\s*%/g)].map((m) => +m[1]).filter((x) => x <= 100); if (ps.length) onProgress(5 + ps[ps.length - 1] * 0.9);
    }
    if (!/RENDER_OK/.test(log)) throw new Error('HyperFrames 算圖逾時');
    const outRel = rel(path.join(tmpDir, 'out.mp4')); await this.T.fileGet(`${dir}/out.mp4`, outRel); const buf = fs.readFileSync(path.join(ws, outRel));
    this.T.exec(`rm -rf ~/${dir}`, { timeout_s: 30 }).catch(() => {}); try { fs.rmSync(tmpDir, { recursive: true, force: true }); } catch { /* ignore */ }
    onProgress(99); return { buf, mime: 'video/mp4' };
  }
}

module.exports = { VideoEngine, SKILL_REPOS, capSegments, SETUP };
