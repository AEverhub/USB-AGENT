'use strict';
/**
 * 內建 Linux（不需要另外安裝 Termux App）
 *
 * 原理（與 UserLAnd／Andronix／proot-distro 相同）：
 *   APK 的 jniLibs 帶 PRoot（libproot.so、libproot-loader.so）→ Android 會把它解到 nativeLibraryDir（唯一允許執行程式的位置）
 *   → App 第一次啟用時下載 Alpine Linux minirootfs（約 3MB，驗 SHA-256）解到自己的資料夾
 *   → 用 PRoot 在裡面執行 apk 安裝 node／python／git／Chromium…
 *   → 在 Linux 裡啟動原本的 agent-bridge.js（埠 8766），App 的 termux_* 工具、背景工作、檔案、Chromium 全部照用。
 * 全部跑在這個 App 的行程底下，資料都在 App 的資料夾裡；解除安裝 App 就一起清掉。
 */
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { spawn } = require('child_process');
const untar = require('../core/untar');
const { logger } = require('../core/log');
const { sleep } = require('../core/util');
const log = logger('linux');

const ARCH = { arm64: 'aarch64', x64: 'x86_64', arm: 'armv7', ia32: 'x86' };
const BASE_PKGS = ['bash', 'nodejs', 'npm', 'python3', 'py3-pip', 'git', 'curl', 'wget', 'ca-certificates', 'tmux', 'openssh-client', 'zip', 'unzip', 'procps', 'coreutils', 'tzdata'];
const CHROME_PKGS = ['chromium', 'nss', 'freetype', 'harfbuzz', 'ttf-freefont', 'font-noto-cjk'];
const PATH_IN = '/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin';
// 不同手機核心／廠商對 PRoot 的相容性不同：安裝前自動逐一試，找到能跑的模式就記住（settings linux.compat）
const MODES = [
  { id: 'default', label: '標準模式', seccomp: true, l2s: true, binds: 'full' },
  { id: 'noseccomp', label: '關閉 seccomp 加速', seccomp: false, l2s: true, binds: 'full' },
  { id: 'safe', label: '相容模式（關 seccomp、不轉換硬連結）', seccomp: false, l2s: false, binds: 'full' },
  { id: 'minimal', label: '最小模式（只掛 /dev、/proc）', seccomp: false, l2s: false, binds: 'min' },
];
const SIG_HINT = { SIGSYS: '：手機核心的 seccomp 擋下了系統呼叫', SIGSEGV: '：PRoot 崩潰（多半是和這支手機的核心不相容）', SIGBUS: '：PRoot 崩潰（記憶體存取錯誤）', SIGKILL: '：被 Android 強制結束（記憶體不足、省電機制，或逾時）', SIGABRT: '：PRoot 自行中止', SIGILL: '：CPU 指令不相容（APK 的架構和手機不符）' };
/** PRoot 需要、但 APK 裡只能用 lib*.so 命名的函式庫：[執行時要的名字, APK 裡的檔名]（scripts/fetch-proot-android.sh 的 apkname 對應） */
const LIB_ALIASES = [['libtalloc.so.2', 'libtalloc.so']];
const describe = (r) => `${r.signal ? `被系統以 ${r.signal} 結束${SIG_HINT[r.signal] || ''}` : `exit ${r.code}`}${r.timedOut ? '（逾時）' : ''}${r.out && r.out.trim() ? '｜輸出：' + r.out.trim().split('\n').slice(-3).join(' / ').slice(0, 240) : '｜沒有任何輸出'}`;

class LinuxEnv {
  constructor(ctx) {
    this.ctx = ctx; this.name = 'linux'; this.root = path.join(ctx.paths.data, 'linux'); this.rootfs = path.join(this.root, 'rootfs'); this.tmp = path.join(this.root, 'tmp');
    this.job = null; this.proc = null; this.procErr = ''; this.logBuf = [];
  }
  cfg() { return { enabled: true, autostart: true, port: 8766, mirror: 'https://dl-cdn.alpinelinux.org/alpine', branch: 'latest-stable', rootfs_url: '', rootfs_sha256: '', extra_packages: [], bind_storage: true, no_seccomp: false, ...(this.ctx.settings.get('linux', {}) || {}) }; }
  prootBin() { const p = this.ctx.settings.get('linux.proot_path') || process.env.PROOT_PATH || ''; return p && fs.existsSync(p) ? p : ''; }
  supported() { return !!this.prootBin() && !!ARCH[process.arch]; }
  arch() { return ARCH[process.arch] || process.arch; }
  meta() { try { return JSON.parse(fs.readFileSync(path.join(this.root, 'state.json'), 'utf8')); } catch { return {}; } }
  saveMeta(m) { fs.mkdirSync(this.root, { recursive: true }); fs.writeFileSync(path.join(this.root, 'state.json'), JSON.stringify({ ...this.meta(), ...m }, null, 1)); }
  installed() { return !!this.meta().installed && fs.existsSync(path.join(this.rootfs, 'bin')); }
  running() { return !!(this.proc && this.proc.exitCode === null && this.proc.signalCode === null); }   // 被訊號結束時 exitCode 仍是 null
  mode() { const c = this.cfg(); return MODES.find((m) => m.id === c.compat) || (c.no_seccomp ? MODES[1] : MODES[0]); }
  say(line) { const s = `[${new Date().toLocaleTimeString('en-GB', { hour12: false, timeZone: this.ctx.settings.get('tz') || 'Asia/Taipei' })}] ${line}`; this.logBuf.push(s); if (this.logBuf.length > 400) this.logBuf.splice(0, this.logBuf.length - 400); if (this.job) this.job.last = line; log.info(line); }
  state() {
    const m = this.meta();
    return { supported: this.supported(), arch: this.arch(), proot: this.prootBin() ? path.basename(this.prootBin()) : '', installed: this.installed(), version: m.version || '', chromium: !!m.chromium, installed_at: m.installed_at || 0,
      job: this.job ? { ...this.job } : null, bridge: { running: this.running(), pid: this.running() ? this.proc.pid : 0, port: this.cfg().port, error: this.procErr }, mode: this.ctx.settings.get('termux.mode'), log: this.logBuf.slice(-80) };
  }

  // ---------------- PRoot ----------------
  /**
   * PRoot（Termux 原檔，沒被改過）需要 libtalloc.so.2，但 APK 裡只能放 lib*.so → 在 App 資料夾建一個同名連結指向 nativeLibraryDir/libtalloc.so。
   * 連結的目標仍在 nativeLibraryDir，所以 Android 10+ 的 W^X 限制不影響載入。
   */
  libDir() {
    const bin = this.prootBin(); if (!bin) return ''; const dir = path.dirname(bin); const d = path.join(this.root, 'lib'); let any = false;
    for (const [want, have] of LIB_ALIASES) {
      const src = path.join(dir, have); if (!fs.existsSync(src)) continue; const ln = path.join(d, want);
      try { let cur = null; try { cur = fs.readlinkSync(ln); } catch { /* 沒有 */ } if (cur !== src) { fs.mkdirSync(d, { recursive: true }); try { fs.unlinkSync(ln); } catch { /* ignore */ } fs.symlinkSync(src, ln); } any = true; }
      catch (e) { log.warn(`建立 ${want} 連結失敗：${e.message}`); }
    }
    return any ? d : '';
  }
  /** 讀 ELF 動態段，看 PRoot 是不是被 patchelf 改過的舊打包（舊版 APK 會依賴 libtalloc.so 而不是 libtalloc.so.2） */
  packaging() {
    try { const b = fs.readFileSync(this.prootBin()); const s = b.toString('latin1'); return { patched: !/libtalloc\.so\.2/.test(s) && /libtalloc\.so/.test(s), size: b.length }; } catch { return { patched: false, size: 0 }; }
  }
  env(mode = this.mode()) {
    const bin = this.prootBin(); const dir = path.dirname(bin); const e = { ...process.env, PROOT_TMP_DIR: this.tmp };
    const l64 = path.join(dir, 'libproot-loader.so'); const l32 = path.join(dir, 'libproot-loader32.so');
    if (fs.existsSync(l64)) e.PROOT_LOADER = l64; if (fs.existsSync(l32)) e.PROOT_LOADER_32 = l32;   // Android 10+ 不能從資料夾執行程式 → loader 也要放在 nativeLibraryDir
    e.LD_LIBRARY_PATH = [this.libDir(), dir, process.env.LD_LIBRARY_PATH].filter(Boolean).join(':');
    if (!mode.seccomp) e.PROOT_NO_SECCOMP = '1'; else delete e.PROOT_NO_SECCOMP;
    return e;
  }
  args(argv, { cwd = '/root', env = {}, mode = this.mode() } = {}) {
    const c = this.cfg(); const a = ['--kill-on-exit', ...(mode.l2s ? ['--link2symlink'] : []), '-0', '-r', this.rootfs, '-b', '/dev', '-b', '/proc'];
    if (mode.binds === 'full') {
      a.push('-b', '/sys', '-b', `${this.tmp}:/dev/shm`);
      if (this.ctx.paths.workspace) a.push('-b', `${this.ctx.paths.workspace}:/root/workspace`);   // App 的工作區在 Linux 裡是 ~/workspace，兩邊共用檔案
      if (c.bind_storage) for (const s of ['/storage/emulated/0', '/sdcard']) if (fs.existsSync(s)) { a.push('-b', `${s}:/sdcard`); break; }
    }
    const ev = { HOME: '/root', USER: 'root', LOGNAME: 'root', PATH: PATH_IN, TERM: 'xterm-256color', LANG: 'C.UTF-8', TMPDIR: '/tmp', TZ: this.ctx.settings.get('tz') || 'Asia/Taipei', ...env };
    a.push('-w', cwd, '/usr/bin/env', '-i', ...Object.entries(ev).map(([k, v]) => `${k}=${v}`), ...argv);
    return a;
  }
  spawn(argv, o = {}) {
    if (!this.supported()) throw new Error('這個 App 版本沒有內建 PRoot（建置 APK 時要先執行 scripts/fetch-proot-android.sh）');
    fs.mkdirSync(this.tmp, { recursive: true });
    const mode = o.mode || this.mode();
    return spawn(this.prootBin(), this.args(argv, { ...o, mode }), { env: this.env(mode), stdio: o.stdio || ['ignore', 'pipe', 'pipe'], detached: !!o.detached });
  }
  /** 在 Linux 裡跑一段 shell；回傳 {code,out}。onLine：逐行輸出（安裝進度用） */
  run(cmd, { timeout_s = 600, onLine, cwd, mode } = {}) {
    return this._exec(() => this.spawn(['/bin/sh', '-c', cmd], { cwd, mode }), { timeout_s, onLine });
  }
  /** 直接跑 PRoot 本身（不進 Linux），用來確認 PRoot 程式能不能執行 */
  _raw(args, mode = MODES[1]) { return this._exec(() => spawn(this.prootBin(), args, { env: this.env(mode), stdio: ['ignore', 'pipe', 'pipe'] }), { timeout_s: 20 }); }
  _exec(mk, { timeout_s = 600, onLine } = {}) {
    return new Promise((resolve) => {
      let p; try { p = mk(); } catch (e) { return resolve({ code: -1, out: e.message }); }
      let out = ''; let part = ''; let timedOut = false; const t = setTimeout(() => { timedOut = true; try { p.kill('SIGKILL'); } catch { /* ignore */ } }, timeout_s * 1000);
      const on = (d) => { const s = d.toString('utf8'); out = (out + s).slice(-200000); if (onLine) { part += s; const ls = part.split(/\r?\n/); part = ls.pop(); for (const l of ls) if (l.trim()) onLine(l); } };
      p.stdout.on('data', on); p.stderr.on('data', on);
      p.on('error', (e) => { clearTimeout(t); resolve({ code: -1, out: out + e.message }); });
      p.on('close', (code, sig) => { clearTimeout(t); if (onLine && part.trim()) onLine(part); resolve({ code: sig ? -1 : code, out, signal: sig || null, timedOut }); });
    });
  }

  /**
   * 自我診斷：1) PRoot 程式本身能不能跑 2) 依序試各相容模式在 Linux 裡 echo，找到第一個能用的就記住。
   * 回傳 {ok, stage, mode, lines, hint}；不會丟錯。
   */
  async diagnose({ save = true } = {}) {
    const lines = []; const say = (s) => { lines.push(s); this.say(s); };
    if (!this.supported()) return { ok: false, stage: 'proot', lines, hint: '這個 App 版本沒有內建 PRoot（建置 APK 時要先執行 scripts/fetch-proot-android.sh）' };
    const bin = this.prootBin(); let size = 0; try { size = fs.statSync(bin).size; } catch { /* ignore */ }
    say(`診斷：PRoot ${path.basename(bin)}（${Math.round(size / 1024)} KB）、手機架構 ${process.arch}、loader ${this.env().PROOT_LOADER ? '有' : '沒有'}`);
    const v = await this._raw(['--version']); say('PRoot 本身 → ' + describe(v));
    // 26.11.3 pro5.1：「CANNOT LINK EXECUTABLE … library X not found」＝APK 少放了 PRoot 需要的函式庫（以前輸出裡有 libproot 字樣會被誤判成能跑，結果去試每個相容模式）
    const miss = /library "([^"]+)" not found/.exec(v.out || '');
    if (miss || /CANNOT LINK EXECUTABLE/.test(v.out || '')) {
      const lib = miss ? miss[1] : '（某個函式庫）';
      return { ok: false, stage: 'proot', missing: lib, lines, hint: `這個 APK 的 PRoot 少了函式庫 ${lib}，所以內建 Linux 無法啟動（換相容模式也沒用）。請用 26.11.3-pro5.1 以後的專案重新執行 scripts/fetch-proot-android.sh 再建置 APK（新腳本會自動把 ${lib} 這類相依一起放進去）；或用 GitHub Actions 自動建置（見 建置流程.md）。在那之前可以改用外部 Termux App（下方「外部 Termux」），瀏覽器會自動改用 App 內 WebView。` };
    }
    if (v.signal || (v.code !== 0 && !/^proot\b|PRoot v?\d/im.test(v.out || ''))) {
      const pk = this.packaging(); if (pk.patched) say('這個 APK 的 PRoot 是舊打包方式（用 patchelf 改過），會在部分手機一啟動就崩潰');
      return { ok: false, stage: 'proot', patched: pk.patched, lines, hint: pk.patched
        ? `PRoot 程式本身無法在這支手機執行（${describe(v)}）。原因是舊版 APK 打包時用 patchelf 改過 PRoot。請用 26.12.4 的專案重新執行 scripts/fetch-proot-android.sh 後重建 APK（新腳本不再修改 PRoot）。在那之前瀏覽器會自動改用 App 內 WebView。`
        : `PRoot 程式本身無法在這支手機執行（${describe(v)}）。請確認 APK 是用 26.12.4 的 scripts/fetch-proot-android.sh 打包；在那之前瀏覽器會自動改用 App 內 WebView。` };
    }
    if (!(() => { try { fs.lstatSync(path.join(this.rootfs, 'bin/sh')); return true; } catch { return false; } })()) return { ok: false, stage: 'rootfs', lines, hint: 'Linux 檔案系統不完整（找不到 /bin/sh），請按「重設」後重新安裝' };
    const cur = this.mode(); const order = [cur, ...MODES.filter((m) => m.id !== cur.id)];
    for (const m of order) {
      const r = await this.run('echo agent-ok; uname -m', { timeout_s: 45, mode: m }); say(`${m.label} → ${/agent-ok/.test(r.out) ? '可以執行' : describe(r)}`);
      if (/agent-ok/.test(r.out)) { if (save && m.id !== this.cfg().compat) this.ctx.settings.set('linux.compat', m.id, 'human'); return { ok: true, stage: 'ok', mode: m.id, label: m.label, lines, hint: `使用「${m.label}」` }; }
    }
    return { ok: false, stage: 'run', lines, hint: '所有相容模式都無法在這支手機執行 Linux。可以改用外部 Termux App（下方「外部 Termux」），功能相同。' };
  }

  // ---------------- 安裝 ----------------
  async _resolveRootfs() {
    const c = this.cfg(); if (c.rootfs_url) return { url: c.rootfs_url, sha256: c.rootfs_sha256 || '', version: 'custom' };
    const base = `${c.mirror.replace(/\/+$/, '')}/${c.branch}/releases/${this.arch()}`;
    const r = await fetch(`${base}/latest-releases.yaml`, { signal: AbortSignal.timeout(30000) }); if (!r.ok) throw new Error(`取不到 Alpine 版本清單（HTTP ${r.status}）`);
    const y = await r.text(); const blocks = y.split(/\n-\s+/);
    const b = blocks.find((x) => /flavor:\s*alpine-minirootfs/.test(x)); if (!b) throw new Error('Alpine 版本清單裡沒有 minirootfs');
    const get = (k) => ((new RegExp(`\\b${k}:\\s*([^\\s]+)`).exec(b)) || [])[1] || '';
    return { url: `${base}/${get('file')}`, sha256: get('sha256'), version: get('version') };
  }
  async install({ chromium = false } = {}) {
    if (this.job && this.job.running) throw new Error('正在安裝中，請等目前的工作完成');
    if (!this.supported()) throw new Error('這個 App 版本沒有內建 PRoot（建置 APK 時要先執行 scripts/fetch-proot-android.sh）');
    this.job = { running: true, phase: '準備', step: 0, steps: chromium ? 6 : 5, started: Date.now(), ok: null, error: '', last: '' };
    const step = (phase) => { this.job.step++; this.job.phase = phase; this.say(`▶ ${phase}`); };
    try {
      let m = this.meta();
      if (!this.installed()) {
        step('下載 Alpine Linux');
        const src = await this._resolveRootfs(); this.say(src.url);
        const r = await fetch(src.url, { signal: AbortSignal.timeout(300000) }); if (!r.ok) throw new Error(`下載失敗（HTTP ${r.status}）`);
        const buf = Buffer.from(await r.arrayBuffer());
        if (src.sha256) { const h = crypto.createHash('sha256').update(buf).digest('hex'); if (h !== src.sha256.toLowerCase()) throw new Error('下載的檔案 SHA-256 不符，已中止（可能被竄改或下載不完整）'); this.say('SHA-256 驗證通過'); }
        step('解壓縮');
        await this.stop().catch(() => {}); fs.rmSync(this.rootfs, { recursive: true, force: true }); fs.mkdirSync(this.rootfs, { recursive: true });
        const st = require('../core/slow').time('解壓 Linux', () => untar.extract(buf, this.rootfs)); this.say(`解出 ${st.files} 個檔案、${st.symlinks} 個連結`);
        this._configure(src.version); this.saveMeta({ version: src.version, rootfs_ok: true }); m = this.meta();
      } else { this.job.step += 2; this.say('Linux 已存在，略過下載'); }
      const d = await this.diagnose(); if (!d.ok) throw new Error(d.hint);
      if (d.mode !== 'default') this.say(`這支手機改用「${d.label}」執行 Linux`);
      step('安裝基本套件（node、python、git…，第一次約 3–10 分鐘）');
      const pkgs = [...BASE_PKGS, ...(this.cfg().extra_packages || [])].filter((x) => /^[a-z0-9][a-z0-9+._-]*$/i.test(x)).join(' ');
      await this._apk(`apk update && apk add --no-cache ${pkgs}`);
      if (chromium) { step('安裝 Chromium（約 200MB，請保持網路與螢幕）'); await this._apk(`apk add --no-cache ${CHROME_PKGS.join(' ')}`); this.saveMeta({ chromium: true }); }
      step('設定 AI 橋接');
      this._writeBridge(); const S = this.ctx.settings;
      const token = /^[0-9a-f]{32,}$/.test(S.get('termux.token') || '') && S.get('termux.mode') === 'embedded' ? S.get('termux.token') : crypto.randomBytes(24).toString('hex');
      S.set('termux.token', token, 'human'); S.set('termux.url', `http://127.0.0.1:${this.cfg().port}`, 'human'); S.set('termux.mode', 'embedded', 'human'); S.set('termux.enabled', true, 'human');
      this.saveMeta({ installed: true, installed_at: m.installed_at || Date.now() });
      step('啟動'); await this.start();
      this.job.ok = true; this.say('✅ 內建 Linux 已就緒'); return this.state();
    } catch (e) { this.job.ok = false; this.job.error = e.message; this.say('❌ ' + e.message); throw e; }
    finally { this.job.running = false; this.job.ended = Date.now(); }
  }
  async _apk(cmd) {
    const r = await this.run(cmd, { timeout_s: 3600, onLine: (l) => this.say(l.slice(0, 200)) });
    if (r.code === 0) return;
    if (r.signal && !r.timedOut) {   // 跑到一半被系統殺掉：重新診斷換模式再試一次（apk 可以重跑）
      this.say(`安裝中斷（${describe(r)}），重新檢查相容模式後再試一次`);
      const before = this.mode().id; const d = await this.diagnose();
      if (d.ok && d.mode !== before) { const r2 = await this.run(cmd, { timeout_s: 3600, onLine: (l) => this.say(l.slice(0, 200)) }); if (r2.code === 0) return; throw new Error('套件安裝失敗：' + describe(r2)); }
    }
    throw new Error('套件安裝失敗：' + describe(r) + (/temporary error|fetch|network|DNS|resolve/i.test(r.out) ? '（看起來是網路問題，請確認手機能上網後再試）' : ''));
  }
  _configure(version) {
    const f = (p, s, mode) => { const full = path.join(this.rootfs, p); fs.mkdirSync(path.dirname(full), { recursive: true }); try { fs.unlinkSync(full); } catch { /* ignore */ } fs.writeFileSync(full, s, mode ? { mode } : undefined); };
    const c = this.cfg(); const mm = /^(\d+)\.(\d+)/.exec(version || ''); const br = mm ? `v${mm[1]}.${mm[2]}` : c.branch === 'latest-stable' ? 'latest-stable' : c.branch;
    f('etc/resolv.conf', 'nameserver 1.1.1.1\nnameserver 8.8.8.8\n');
    f('etc/hosts', '127.0.0.1 localhost\n::1 localhost\n');
    f('etc/apk/repositories', `${c.mirror.replace(/\/+$/, '')}/${br}/main\n${c.mirror.replace(/\/+$/, '')}/${br}/community\n`);
    f('etc/profile.d/agent.sh', 'export PS1="linux:\\w# "\nexport LANG=C.UTF-8\n');
    fs.mkdirSync(path.join(this.rootfs, 'root/workspace'), { recursive: true }); fs.mkdirSync(path.join(this.rootfs, 'tmp'), { recursive: true }); fs.mkdirSync(path.join(this.rootfs, 'sdcard'), { recursive: true });
    try { fs.chmodSync(path.join(this.rootfs, 'tmp'), 0o1777); } catch { /* ignore */ }
  }
  _writeBridge() {
    const src = path.join(__dirname, '..', '..', 'termux', 'agent-bridge.js'); const dst = path.join(this.rootfs, 'opt/agent-bridge/agent-bridge.js');
    fs.mkdirSync(path.dirname(dst), { recursive: true }); fs.copyFileSync(src, dst);
  }

  // ---------------- 執行（給守護進程管）----------------
  async start() {
    if (!this.cfg().enabled || !this.supported() || !this.installed()) return false;   // 沒內建／沒裝：不算失敗
    if (this.running()) return true;
    this._writeBridge(); const S = this.ctx.settings; const port = this.cfg().port;
    if (S.get('termux.mode') !== 'embedded') return false;   // 管理員改用外部 Termux 時不啟動
    const logf = fs.openSync(path.join(this.root, 'bridge.log'), 'a');
    const p = this.spawn(['/usr/bin/node', '/opt/agent-bridge/agent-bridge.js'], { env: { BRIDGE_PORT: String(port), BRIDGE_TOKEN: S.get('termux.token'), BRIDGE_HOME: '/root/.agent-bridge' }, stdio: ['ignore', logf, logf], detached: true });   // 自成一個行程群組：停止時整組（含 Linux 裡的子行程）一起收掉
    fs.closeSync(logf); this.proc = p; this.procErr = '';
    p.on('error', (e) => { this.procErr = e.message; }); p.on('exit', (code, sig) => { if (this.proc === p) { this.procErr = this.procErr || `橋接結束（${sig || code}）`; this.say(`橋接已結束（${sig || code}）`); } });
    for (let i = 0; i < 60; i++) {   // 第一次啟動 node 可能要幾秒
      await sleep(500); if (!this.running()) break;
      try { await this.ctx.termux.health(); this.say(`橋接已啟動（pid ${p.pid}，埠 ${port}）`); return true; } catch { /* 還沒好 */ }
    }
    const tail = (() => { try { return fs.readFileSync(path.join(this.root, 'bridge.log'), 'utf8').trim().split('\n').slice(-3).join(' / '); } catch { return ''; } })();
    await this.stop(); throw new Error(`內建 Linux 的橋接沒有啟動成功${tail ? '：' + tail.slice(0, 300) : ''}`);
  }
  async stop() {
    const p = this.proc; this.proc = null; if (!p || p.exitCode !== null || p.signalCode !== null) return;
    const kill = (sig) => { try { process.kill(-p.pid, sig); } catch { try { p.kill(sig); } catch { /* ignore */ } } };
    kill('SIGTERM'); for (let i = 0; i < 20 && p.exitCode === null && p.signalCode === null; i++) await sleep(100);
    kill('SIGKILL');
  }
  health() { if (!this.cfg().enabled || !this.supported() || !this.installed() || this.ctx.settings.get('termux.mode') !== 'embedded') return true; return this.running(); }
  async reset() { await this.stop(); if (this.job && this.job.running) throw new Error('安裝中不能重設'); fs.rmSync(this.root, { recursive: true, force: true }); this.logBuf = []; this.job = null; if (this.ctx.settings.get('termux.mode') === 'embedded') { this.ctx.settings.set('termux.token', '', 'human'); } return this.state(); }
  /** 互動終端機（App 操作頁的終端機切到 Linux 時用） */
  shell() { return this.spawn([fs.existsSync(path.join(this.rootfs, 'bin/bash')) ? '/bin/bash' : '/bin/sh'], { stdio: ['pipe', 'pipe', 'pipe'], env: { PS1: 'linux:\\w# ' } }); }
}
module.exports = { MODES, describe, LinuxEnv, BASE_PKGS, CHROME_PKGS };
