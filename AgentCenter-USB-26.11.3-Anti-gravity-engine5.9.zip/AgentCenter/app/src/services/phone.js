'use strict';
/**
 * 手機能力：透過 Termux:API（安裝腳本已裝 termux-api 套件；手機還要裝「Termux:API」App 並給權限）。
 * 每個動作都是固定指令範本＋嚴格參數檢查，不讓 AI 組任意 shell。
 * 發簡訊、打電話＝對外、可能花錢、冒用你的身分 → 一律走管理員審批（AI 不能關掉）。
 */
const { clip } = require('../core/util');
const fs = require('fs');
const path = require('path');
const http = require('http');

const q = (s) => "'" + String(s ?? '').replace(/'/g, "'\\''") + "'";
const NUM = /^\+?[0-9][0-9 ()#*-]{2,24}$/;
const parse = (out) => { try { return JSON.parse(out); } catch { return null; } };

class Phone {
  constructor(ctx) { this.ctx = ctx; }
  /** 有 Termux:API 可用（簡訊、聯絡人、通話紀錄、拍照、剪貼簿還是要它） */
  termuxReady() { return !!(this.ctx.termux && this.ctx.termux.ready()) && this.ctx.settings.get('termux.mode') !== 'embedded'; }   // 內建 Linux 沒有 Termux:API
  ready() { return this.nativeReady() || this.termuxReady(); }

  // ---------- 26.11.3 pro2.1：App 自己讀（不用 Termux）：電量、定位、網路、機型／儲存空間、音量、手電筒、震動、通知、朗讀 ----------
  nativeEndpoint() { try { const j = JSON.parse(fs.readFileSync(path.join(this.ctx.paths.data, 'device_host.json'), 'utf8')); if (!j || !+j.port || typeof j.token !== 'string' || j.token.length < 32) return null; return j; } catch { return null; } }
  nativeReady() { return !!this.nativeEndpoint(); }
  native(method, p, body, timeout = 15000) {
    const e = this.nativeEndpoint(); if (!e) return Promise.reject(Object.assign(new Error('App 的手機資訊服務沒開（要在 Android App 裡）'), { noNative: true }));
    return new Promise((resolve, reject) => {
      // Anti-gravity-engine4.5：非 ASCII 字一律轉成 \uXXXX——Android 端用「字元數」讀 content-length（位元組數），中文會讀不滿而卡住到逾時
      const data = body !== undefined ? Buffer.from(JSON.stringify(body).replace(/[\u007f-\uffff]/g, (c) => '\\u' + c.charCodeAt(0).toString(16).padStart(4, '0'))) : null;
      const r = http.request({ host: '127.0.0.1', port: +e.port, path: p, method, timeout, headers: { 'x-agent-token': e.token, ...(data ? { 'content-type': 'application/json', 'content-length': data.length } : {}) } }, (res) => {
        const c = []; res.on('data', (d) => c.push(d)); res.on('end', () => { let j = null; try { j = JSON.parse(Buffer.concat(c).toString()); } catch { /* ignore */ } if (res.statusCode >= 400 || !j) return reject(new Error((j && j.error) || `手機資訊 HTTP ${res.statusCode}`)); resolve(j); });
      });
      r.on('timeout', () => r.destroy(new Error('手機沒有回應（逾時）'))); r.on('error', (er) => reject(/ECONNREFUSED/.test(er.message) ? Object.assign(new Error('App 的手機資訊服務沒在跑（App 可能被系統關掉，重新打開 App）'), { noNative: true }) : er));
      if (data) r.write(data); r.end();
    });
  }
  /** 先用 App 自己讀；App 那邊沒開（例如在電腦上跑）才退回 Termux:API */
  async either(nativeFn, termuxFn) {
    if (this.nativeReady()) { try { return await nativeFn(); } catch (e) { if (!e.noNative || !this.termuxReady()) throw e; } }
    return termuxFn();
  }
  need() { if (this.ctx.settings.get('termux.mode') === 'embedded') throw new Error('這項手機能力（簡訊、聯絡人、通話紀錄、拍照、剪貼簿）需要外部 Termux＋Termux:API App（電量、定位、網路、音量、手電筒、通知、朗讀不用，App 自己就讀得到）；目前用的是 App 內建 Linux，它沒有這些權限。'); if (!this.ready()) throw new Error('手機能力需要 Termux 橋接（App「瀏覽器」頁 → Termux 卡片完成安裝），並安裝「Termux:API」App。'); }
  async run(cmd, timeout_s = 30) {
    this.need(); const r = await this.ctx.termux.exec(cmd, { timeout_s });
    const out = String(r.out || '').trim();
    if (r.code === 127 || /command not found|No such file/i.test(out)) throw new Error('Termux 裡沒有 termux-api 指令：請在 Termux 執行 pkg install termux-api，並安裝「Termux:API」App。');
    if (r.timedOut) throw new Error('手機沒有回應（多半是「Termux:API」App 沒裝或沒給權限）');
    if (r.code) throw new Error(clip(out || `exit ${r.code}`, 300));
    return out;
  }
  async json(cmd, t) { const out = await this.run(cmd, t); const j = parse(out); if (j == null) throw new Error(clip(out || '沒有輸出', 300)); return j; }

  // ---- 讀取類（管理員專用）----
  async status() {
    if (this.nativeReady()) {
      try { const [battery, network] = await Promise.all([this.native('GET', '/battery'), this.native('GET', '/network').catch((e) => ({ error: e.message }))]); return { battery, network, source: 'app' }; } catch (e) { if (!e.noNative || !this.termuxReady()) throw e; }
    }
    const [bat, wifi] = await Promise.all([this.json('termux-battery-status', 15).catch((e) => ({ error: e.message })), this.json('termux-wifi-connectioninfo', 15).catch((e) => ({ error: e.message }))]);
    return { battery: bat, wifi: wifi && !wifi.error ? { ssid: wifi.ssid, ip: wifi.ip, rssi: wifi.rssi, link_speed_mbps: wifi.link_speed_mbps } : wifi, source: 'termux' };
  }
  location(precise = false) { return this.either(() => this.native('GET', '/location' + (precise ? '?precise=1' : ''), undefined, precise ? 60000 : 30000), () => this.json(precise ? 'termux-location -p gps -r once' : 'termux-location -p network -r last', precise ? 60 : 25)); }
  network() { return this.either(() => this.native('GET', '/network'), async () => this.json('termux-wifi-connectioninfo', 15)); }
  device() { return this.either(() => this.native('GET', '/device'), () => { throw new Error('機型、儲存空間、記憶體要在 Android App 裡才讀得到'); }); }
  nativeHealth() { return this.nativeReady() ? this.native('GET', '/health', undefined, 3000).catch((e) => ({ ok: false, error: e.message })) : Promise.resolve(null); }
  clipboardGet() { return this.run('termux-clipboard-get', 10); }
  clipboardSet(text) { return this.run(`printf %s ${q(clip(String(text), 20000))} | termux-clipboard-set`, 10).then(() => '已放到剪貼簿'); }
  async contacts(query = '') {
    const all = await this.json('termux-contact-list', 40); const k = String(query).trim().toLowerCase();
    return (Array.isArray(all) ? all : []).filter((c) => !k || String(c.name || '').toLowerCase().includes(k) || String(c.number || '').replace(/\D/g, '').includes(k.replace(/\D/g, '') || '\0')).slice(0, 30);
  }
  async sms(limit = 15, box = 'inbox') {
    if (!['inbox', 'sent', 'all'].includes(box)) box = 'inbox';
    const j = await this.json(`termux-sms-list -l ${Math.max(1, Math.min(+limit || 15, 50))} -t ${box}`, 30);
    return (Array.isArray(j) ? j : []).map((m) => ({ from: m.number, name: m.sender || '', at: m.received, body: clip(m.body || '', 500), type: m.type }));
  }
  async calls(limit = 15) { const j = await this.json(`termux-call-log -l ${Math.max(1, Math.min(+limit || 15, 50))}`, 30); return (Array.isArray(j) ? j : []).map((c) => ({ number: c.phone_number, name: c.name || '', type: c.type, at: c.date, duration: c.duration })); }
  async photo(camera = 0) {
    const f = `.agent-bridge/photo-${Date.now()}.jpg`; await this.run(`mkdir -p ~/.agent-bridge && termux-camera-photo -c ${+camera === 1 ? 1 : 0} ~/${f}`, 40);
    const r = await this.ctx.termux.call('GET', '/file/get?path=' + encodeURIComponent(f), undefined, 60000); await this.run(`rm -f ~/${f}`, 10).catch(() => {});
    if (!r.b64) throw new Error('拍照失敗（相機權限？）'); return { mime: 'image/jpeg', data: r.b64 };
  }
  // ---- 動作類 ----
  notify(title, text) { return this.either(() => this.native('POST', '/notify', { title: clip(title || 'Agent', 80), text: clip(text || '', 1000) }).then((r) => r.text), () => this.notifyT(title, text)); }
  /** Anti-gravity-engine4.5：用手機內建語音把文字錄成 WAV（免費旁白）。回傳 { file（相對 workspace）, voice } */
  ttsFile(text, name, { voice = '', rate = 1, pitch = 1 } = {}) { return this.native('POST', '/tts/file', { text: clip(String(text || ''), 1500), name: String(name || '').replace(/[^\w-]/g, '').slice(0, 64), voice, rate, pitch }, 75000); }
  ttsVoices() { return this.native('GET', '/tts/voices', undefined, 15000); }
  hasNative() { return !!this.nativeEndpoint(); }
  speak(text) { return this.either(() => this.native('POST', '/speak', { text: clip(text, 2000) }).then((r) => r.text), () => this.speakT(text)); }
  // 26.11.3 pro10：鬧鈴（計時器用）與本機音樂——只有 Android App 自己做得到
  ring(title, text, seconds = 30) { return this.native('POST', '/ring', { title: clip(title || '計時器', 80), text: clip(text || '時間到', 300), seconds: Math.max(3, Math.min(120, Math.round(+seconds || 30))), vibrate: true }).then((r) => r.text); }
  ringStop() { return this.native('POST', '/ring/stop', {}).then((r) => r.text); }
  musicList(q = '', limit = 50) { return this.native('POST', '/music/list', { q: clip(String(q || ''), 80), limit: Math.max(1, Math.min(500, +limit || 50)) }); }
  musicPlay({ id, q = '', shuffle = false } = {}) { return this.native('POST', '/music/play', { ...(id != null && id !== '' ? { id: +id } : {}), q: clip(String(q || ''), 80), shuffle: !!shuffle }, 30000); }
  musicControl(action) { if (!['pause', 'resume', 'stop', 'next', 'prev'].includes(action)) throw new Error('action：pause｜resume｜stop｜next｜prev'); return this.native('POST', '/music/control', { action }); }
  musicStatus() { return this.native('GET', '/music/status'); }
  torch(on) { return this.either(() => this.native('POST', '/torch', { on: !!on }).then((r) => r.text), () => this.torchT(on)); }
  vibrate(ms = 500) { return this.either(() => this.native('POST', '/vibrate', { ms: Math.max(50, Math.min(+ms || 500, 5000)) }).then((r) => r.text), () => this.vibrateT(ms)); }
  volume(stream, level) {
    const s = ['music', 'ring', 'alarm', 'notification', 'system', 'call'].includes(stream) ? stream : 'music'; const get = level === undefined || level === null || level === '';
    return this.either(() => (get ? this.native('GET', '/device').then((d) => d.volume) : this.native('POST', '/volume', { stream: s, level: Math.max(0, Math.min(+level || 0, 30)) }).then((r) => r.text)), () => this.volumeT(s, level));
  }
  // ---- Termux:API 版本（App 那邊沒開時用）----
  notifyT(title, text) { return this.run(`termux-notification --id agent-${Date.now() % 100000} --title ${q(clip(title || 'Agent', 80))} --content ${q(clip(text || '', 1000))}`, 15).then(() => '已在手機跳出通知'); }
  speakT(text) { return this.run(`termux-tts-speak ${q(clip(text, 2000))}`, 120).then(() => '已朗讀'); }
  torchT(on) { return this.run(`termux-torch ${on ? 'on' : 'off'}`, 10).then(() => (on ? '手電筒已開' : '手電筒已關')); }
  vibrateT(ms = 500) { return this.run(`termux-vibrate -d ${Math.max(50, Math.min(+ms || 500, 5000))}`, 10).then(() => '已震動'); }
  volumeT(stream, level) {
    const s = ['music', 'ring', 'alarm', 'notification', 'system', 'call'].includes(stream) ? stream : 'music';
    if (level === undefined || level === null || level === '') return this.json('termux-volume', 10);
    return this.run(`termux-volume ${s} ${Math.max(0, Math.min(+level || 0, 30))}`, 10).then(() => `${s} 音量已設為 ${level}`);
  }
  // 審批通過後才會被呼叫
  smsSend(number, text) { if (!NUM.test(String(number))) throw new Error('電話號碼格式不正確'); return this.run(`termux-sms-send -n ${q(String(number).replace(/[^0-9+]/g, ''))} ${q(clip(text, 1500))}`, 30).then(() => `已傳簡訊給 ${number}`); }
  call(number) { if (!NUM.test(String(number))) throw new Error('電話號碼格式不正確'); return this.run(`termux-telephony-call ${q(String(number).replace(/[^0-9+#*]/g, ''))}`, 20).then(() => `已撥號給 ${number}`); }
}
module.exports = { Phone, NUM, shq: q };
