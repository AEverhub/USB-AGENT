'use strict';
/**
 * 26.11.3 Anti-gravity-engine3：「一句話就生成」共用工具
 *  ・ask()：呼叫模型（不帶工具、關掉思考預算，讓輸出長度都留給內容）
 *  ・json()：從模型回覆抽出 JSON（容忍 ```json 包裝、前後多話）
 *  ・files()：解析「===FILE: 路徑===…===END===」格式的多檔輸出
 *  ・deliver()：把結果送回提出要求的聊天室（LINE／Telegram／Discord 傳訊息＋檔案；App 寫進對話紀錄＋通知）
 *  ・pickTemplate()／pickVideo()：從一句話判斷網站類型、影片尺寸風格音樂（模型沒說時的保底）
 */
const llm = require('../llm');

async function ask(ctx, system, text, { maxTokens = 8192 } = {}) {
  const r = await llm.generate(ctx, { system, messages: [{ role: 'user', text }], tools: [], maxTokens, fast: true });
  const out = String((r && r.text) || '').trim(); if (!out) throw new Error('模型沒有回應內容'); return out;
}
function json(text) {
  const s = String(text || '').replace(/^﻿/, ''); const fence = /```(?:json)?\s*([\s\S]*?)```/i.exec(s); const body = fence ? fence[1] : s;
  const a = body.indexOf('{'); const b = body.lastIndexOf('}'); if (a < 0 || b <= a) throw new Error('模型回覆不是 JSON');
  const raw = body.slice(a, b + 1);
  try { return JSON.parse(raw); } catch { /* 常見小毛病：結尾多逗號 */ }
  try { return JSON.parse(raw.replace(/,\s*([}\]])/g, '$1')); } catch (e) { throw new Error('模型回覆的 JSON 格式錯誤：' + e.message); }
}
/** 去掉模型常加的 ``` 包裝 */
function unfence(t) { const s = String(t || '').trim(); const m = /^```[\w-]*\s*\n([\s\S]*?)\n?```\s*$/.exec(s); return m ? m[1] : s; }
function files(text) {
  const out = []; const re = /===\s*FILE:\s*([^=\n]+?)\s*===\s*\n([\s\S]*?)(?:\n===\s*END(?:\s*FILE)?\s*===|(?=\n===\s*FILE:)|$)/g; let m;
  while ((m = re.exec(String(text || '')))) { const p = m[1].trim(); if (p) out.push({ path: p, content: unfence(m[2]).replace(/\s+$/, '') + '\n' }); }
  return out;
}
async function deliver(ctx, reply, text, recs = [], title = '完成') {
  const r = reply || {}; const list = (recs || []).filter(Boolean);
  if (r.platform && r.platform !== 'app' && r.chatId && ctx.hub) {
    try { await ctx.hub.send(r.platform, r.chatId, text); } catch { /* ignore */ }
    for (const f of list) { try { await ctx.hub.sendFile(r.platform, r.chatId, f); } catch { /* ignore */ } }
    return r.platform;
  }
  const p = (r.pid && ctx.users.byId && ctx.users.byId(r.pid)) || (ctx.users.admins && ctx.users.admins()[0]);
  if (p) { try { ctx.store.addMessage('dm_' + p.id, { role: 'assistant', text, ts: Date.now(), platform: 'app', files: list.map((f) => ({ id: f.id, name: f.name, size: f.size, mime: f.mime })) }); } catch { /* ignore */ } }
  try { await ctx.notifier.push('info', title, text.slice(0, 300), { force: true }); } catch { /* ignore */ }
  return 'app';
}
/** 網站類型（模型規劃失敗時的保底判斷） */
function pickTemplate(t) {
  const s = String(t || '');
  if (/後端|api|資料庫|database|登入|註冊|會員系統|多人|帳號|server|伺服器|node/i.test(s)) return 'fullstack';
  if (/儀表板|dashboard|報表|數據|統計|圖表|分析|監控|kpi/i.test(s)) return 'dashboard';
  if (/管理|系統|記帳|收支|待辦|清單|預約|庫存|進銷存|客戶|crm|後台|紀錄|記錄|追蹤|打卡|報名|名單|訂單|出缺勤|工具|計算機|app/i.test(s)) return 'app';
  return 'landing';
}
/** 影片尺寸／風格／音樂（模型沒給時的保底判斷） */
function pickVideo(t) {
  const s = String(t || '');
  const size = /橫式|橫的|16:9|youtube|簡報|會議|報告|投影|電腦|寬螢幕/i.test(s) ? 'landscape' : /方形|1:1|ig ?貼文|instagram 貼文|臉書貼文/i.test(s) ? 'square' : 'portrait';
  const theme = /科技|ai|程式|資安|未來|產品發表/i.test(s) ? 'dark' : /海|旅遊|夏天|清爽|環保/i.test(s) ? 'ocean' : /美食|咖啡|溫暖|秋|家|手作/i.test(s) ? 'warm' : /活動|派對|促銷|特價|潮|年輕/i.test(s) ? 'vivid' : /極簡|黑白|高級|精品/i.test(s) ? 'mono' : 'dark';
  const music = /不要音樂|無音樂|靜音|安靜/i.test(s) ? 'none' : /電影|史詩|震撼|預告|壯闊/i.test(s) ? 'cinematic' : /活動|促銷|派對|運動|輕快|熱鬧|開心|活力/i.test(s) ? 'upbeat' : 'calm';
  const sec = /(\d+)\s*(秒|s\b)/i.exec(s); const min = /(\d+(?:\.\d+)?)\s*分鐘/.exec(s); const want = sec ? +sec[1] : min ? Math.round(+min[1] * 60) : 0;
  return { size, theme, music, seconds: want ? Math.max(8, Math.min(180, want)) : 0 };
}

module.exports = { ask, json, files, unfence, deliver, pickTemplate, pickVideo };
