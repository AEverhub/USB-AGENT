'use strict';
/**
 * 帳密保險箱：讓 AI「用」帳號，但永遠「看不到」密碼。
 *  ・密碼／TOTP 種子用 AES-256-GCM 加密存在 data/vault.json；金鑰在 data/vault.key（權限 600）。
 *  ・AI 只能拿到「名稱／網站／帳號」，登入時由程式直接把密碼打進網頁欄位（browser_login），不經過模型。
 *  ・AI 的檔案工具讀不到這兩個檔案；App 的 API 回傳也不含密碼。
 *  ・誠實的限制：金鑰和密文在同一台手機上，能執行任意指令的人（含開了終端機權限的 AI）理論上仍能自己解密。
 *    要更嚴格：到設定頁關閉「AI 可使用終端機」，或只用「手動接手登入」不存帳密。
 */
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const seal = require('../core/seal');
const { logger } = require('../core/log');
const log = logger('vault');

function b32decode(s) {
  const A = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567'; s = String(s).toUpperCase().replace(/[^A-Z2-7]/g, ''); let bits = ''; for (const c of s) bits += A.indexOf(c).toString(2).padStart(5, '0');
  const out = []; for (let i = 0; i + 8 <= bits.length; i += 8) out.push(parseInt(bits.slice(i, i + 8), 2)); return Buffer.from(out);
}
/** RFC 6238 TOTP（SHA-1、6 位、30 秒）— 給「驗證器 App」那種兩步驟驗證用 */
function totp(secret, now = Date.now(), step = 30, digits = 6) {
  const key = b32decode(secret); if (!key.length) throw new Error('TOTP 種子格式不對（要 Base32）');
  const ctr = Buffer.alloc(8); ctr.writeBigUInt64BE(BigInt(Math.floor(now / 1000 / step)));
  const h = crypto.createHmac('sha1', key).update(ctr).digest(); const o = h[h.length - 1] & 15;
  const code = ((h[o] & 0x7f) << 24 | h[o + 1] << 16 | h[o + 2] << 8 | h[o + 3]) % 10 ** digits; return String(code).padStart(digits, '0');
}

class Vault {
  /** engine4.8：設定／拿掉 USB 密碼時，把保險箱金鑰以新的方式重存（資料本身不用重加密） */
  resealKey(k) { const tmp = this.keyFile + '.tmp'; fs.writeFileSync(tmp, seal.wrap(Buffer.from(k).toString('hex')), { mode: 0o600 }); fs.renameSync(tmp, this.keyFile); }
  constructor(ctx) {
    this.ctx = ctx; this.file = path.join(ctx.paths.data, 'vault.json'); this.keyFile = path.join(ctx.paths.data, 'vault.key'); this.items = [];
    try { this.items = JSON.parse(fs.readFileSync(this.file, 'utf8')); } catch { this.items = []; }
  }
  _key() {
    let raw = null; try { raw = fs.readFileSync(this.keyFile, 'utf8').trim(); } catch { /* 新建 */ }
    if (raw) { const k = Buffer.from(seal.unwrap(raw), 'hex'); if (k.length === 32) { if (seal.on() && !seal.isSealed(raw)) this.resealKey(k); return k; } }   // unwrap 失敗會丟錯（USB 密碼沒解鎖），不能當成「沒有金鑰」去覆蓋
    const k = crypto.randomBytes(32); fs.writeFileSync(this.keyFile, seal.wrap(k.toString('hex')), { mode: 0o600 }); return k;
  }
  enc(plain) { if (!plain) return ''; const iv = crypto.randomBytes(12); const c = crypto.createCipheriv('aes-256-gcm', this._key(), iv); const ct = Buffer.concat([c.update(String(plain), 'utf8'), c.final()]); return Buffer.concat([iv, c.getAuthTag(), ct]).toString('base64'); }
  dec(b64) { if (!b64) return ''; const b = Buffer.from(b64, 'base64'); const d = crypto.createDecipheriv('aes-256-gcm', this._key(), b.slice(0, 12)); d.setAuthTag(b.slice(12, 28)); return Buffer.concat([d.update(b.slice(28)), d.final()]).toString('utf8'); }
  save() { try { fs.writeFileSync(this.file + '.tmp', JSON.stringify(this.items), { mode: 0o600 }); fs.renameSync(this.file + '.tmp', this.file); } catch (e) { log.error('保險箱寫入失敗', e.message); } }
  /** 給 UI／AI 看的版本：沒有任何機密 */
  list() { return this.items.map((x) => ({ id: x.id, name: x.name, site: x.site, username: x.username, has_password: !!x.pw, has_totp: !!x.totp, note: x.note || '', updated: x.updated })); }
  find(nameOrId) { const q = String(nameOrId || '').toLowerCase(); return this.items.find((x) => x.id === nameOrId || x.name.toLowerCase() === q) || this.items.find((x) => x.name.toLowerCase().includes(q) || (x.site || '').toLowerCase().includes(q)); }
  upsert({ id, name, site, username, password, totp: t, note }) {
    name = String(name || '').trim().slice(0, 40); if (!name) throw new Error('要有名稱，例如「Google 主帳號」');
    if (t) totp(t);   // 先驗證格式
    let it = id ? this.items.find((x) => x.id === id) : this.items.find((x) => x.name === name);
    if (!it) { it = { id: crypto.randomBytes(6).toString('hex'), name, created: Date.now() }; this.items.push(it); }
    it.name = name; it.site = String(site || '').trim().slice(0, 120); it.username = String(username || '').trim().slice(0, 200); it.note = String(note || '').slice(0, 200); it.updated = Date.now();
    if (password) it.pw = this.enc(password); if (t) it.totp = this.enc(String(t).replace(/\s+/g, '')); this.save(); return this.list().find((x) => x.id === it.id);
  }
  remove(id) { const n = this.items.length; this.items = this.items.filter((x) => x.id !== id); this.save(); return n !== this.items.length; }
  /** 只給程式內部（browser_login）用；絕不能回傳給模型或 API */
  secrets(it) { return { username: it.username, password: this.dec(it.pw), totp: it.totp ? totp(this.dec(it.totp)) : '' }; }
}
module.exports = { Vault, totp };
