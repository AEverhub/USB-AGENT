'use strict';
const { spawn } = require('child_process');
const fs = require('fs');
const { EventEmitter } = require('events');
const { logger } = require('../core/log');
const { clip, rid } = require('../core/util');
const log = logger('terminal');

/** 判斷指令是否屬於「下載／安裝類」——AI 執行這類指令才需要管理員審批 */
const DOWNLOAD_RE = /(^|[\s;&|(`])(curl|wget|aria2c|axel|git\s+(clone|pull|fetch|submodule)|npm\s+(i|install|add|ci|update)|npx\s|yarn\s+(add|install)|pnpm\s+(add|install|i)|pip3?\s+(install|download)|python3?\s+-m\s+pip\s+install|pkg\s+(install|upgrade)|apt(-get)?\s+(install|update|upgrade)|apk\s+add|gem\s+install|cargo\s+(install|fetch)|go\s+(get|install)|scp|rsync|sftp|ftp|tftp|nc\s|ncat|youtube-dl|yt-dlp|gdown|download)(\s|$)/i;
const isDownload = (cmd) => DOWNLOAD_RE.test(String(cmd));

const SH = fs.existsSync('/system/bin/sh') ? '/system/bin/sh' : (fs.existsSync('/bin/sh') ? '/bin/sh' : 'sh');

class Terminal {
  constructor(ctx) { this.ctx = ctx; this.sessions = new Map(); }
  get cwd() { return this.ctx.paths.workspace; }
  open(owner = 'admin', o = {}) {
    const id = 's_' + rid(3); const ev = new EventEmitter(); ev.setMaxListeners(20);
    const linux = !!o.linux; if (linux && !(this.ctx.linux && this.ctx.linux.installed())) throw new Error('內建 Linux 還沒安裝（瀏覽器頁 → 內建 Linux → 安裝）');
    const env = { ...process.env, TERM: 'dumb', HOME: this.ctx.paths.home, PS1: '$ ', TMPDIR: this.ctx.paths.tmp, PATH: (process.env.PATH || '') + ':/system/bin:/system/xbin:/vendor/bin' };
    const p = linux ? this.ctx.linux.shell() : spawn(SH, [], { cwd: this.cwd, env, stdio: ['pipe', 'pipe', 'pipe'] });
    const s = { id, owner, p, ev, buf: '', started: Date.now(), closed: false };
    const onData = (d) => { const t = d.toString('utf8'); s.buf = (s.buf + t).slice(-60000); ev.emit('data', t); };
    p.stdout.on('data', onData); p.stderr.on('data', onData);
    p.on('close', (code) => { s.closed = true; ev.emit('data', `\n[終端機已結束 code=${code}]\n`); ev.emit('close'); });
    p.on('error', (e) => { ev.emit('data', `\n[無法啟動 shell：${e.message}]\n`); });
    this.sessions.set(id, s); this.ctx.store.audit(owner, 'terminal.open', id);
    onData(Buffer.from(linux ? 'Agent中控中心 終端機（內建 Alpine Linux）\n工作目錄：/root（~/workspace＝App 工作區）。裝套件：apk add 套件名\n' : `Agent中控中心 終端機（${SH}）\n工作目錄：${this.cwd}\n注意：這是 Android 系統 shell（toybox）；要完整 Linux 請切到「Linux」。\n`));
    s.linux = linux;
    return s;
  }
  input(id, text) { const s = this.sessions.get(id); if (!s || s.closed) throw new Error('終端機工作階段不存在或已結束'); s.p.stdin.write(text); this.ctx.store.audit(s.owner, 'terminal.input', text.slice(0, 200)); }
  close(id) { const s = this.sessions.get(id); if (s) { try { s.p.kill('SIGKILL'); } catch { /* ignore */ } this.sessions.delete(id); } }
  closeAll() { for (const id of [...this.sessions.keys()]) this.close(id); }

  /** 一次性執行（AI 的 run_shell 用）。who='ai' 時，下載類指令走審批。 */
  async exec(cmd, { who = 'ai', timeout = 120000, cwd = null, chat = null, requester = '' } = {}) {
    if (who === 'ai' && this.ctx.settings.get('policy.approve_downloads') && isDownload(cmd)) {
      const a = await this.ctx.approvals.request({ kind: 'download', summary: `執行下載類指令：${clip(cmd, 160)}`, payload: { cmd }, requester, chat });
      return { pending: true, approval: a.id, text: `這是下載／安裝類指令，已向管理員提出審批 #${a.id}。核准後會自動執行並回報結果。` };
    }
    return { pending: false, text: await this._run(cmd, timeout, cwd) };
  }
  _run(cmd, timeout, cwd) {
    return new Promise((resolve) => {
      let out = ''; const env = { ...process.env, TERM: 'dumb', HOME: this.ctx.paths.home, TMPDIR: this.ctx.paths.tmp, PATH: (process.env.PATH || '') + ':/system/bin:/system/xbin' };
      const p = spawn(SH, ['-c', cmd], { cwd: cwd || this.cwd, env, stdio: ['ignore', 'pipe', 'pipe'] });
      const t = setTimeout(() => { out += '\n[逾時，已終止]'; try { p.kill('SIGKILL'); } catch { /* ignore */ } }, timeout);
      p.stdout.on('data', (d) => { out += d; }); p.stderr.on('data', (d) => { out += d; });
      p.on('error', (e) => { clearTimeout(t); resolve(`無法執行：${e.message}`); });
      p.on('close', (code) => { clearTimeout(t); resolve(clip(out.trim() || '(沒有輸出)', 8000) + `\n[exit ${code}]`); });
    });
  }
}
module.exports = { Terminal, isDownload, DOWNLOAD_RE };
