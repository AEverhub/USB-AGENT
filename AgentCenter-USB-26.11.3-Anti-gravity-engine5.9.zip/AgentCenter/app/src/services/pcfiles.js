'use strict';
/**
 * engine5.8 開發版專用：USB／T-Dongle 上的 AI 可以看、找、複製、搬運「這台電腦」的檔案（用說的就好）
 *
 *  ・只有開發版（app/config/edition.json 的 edition = "dev"）預設開啟；一般版要在設定把 usb.pc_access 設成 true
 *  ・只在 USB 版、而且 AgentCenter 在 USB 根目錄時才有
 *  ・保護：系統資料夾（Windows、Program Files、AppData、/System、/usr…）不能讀也不能寫；
 *          USB 上的 AgentCenter（你的金鑰、記憶）不能被複製出去，也不能被覆蓋
 *  ・複製：不會蓋掉任何東西（同名就自動改名「(2)」），複製完比對大小
 *  ・搬運（move）：先複製、逐檔比對內容（SHA-1）一致，才刪掉原檔；一定要先預覽、再確認（confirm=true）
 *  ・很多檔案（>200 個）或很大（>2 GB）也要先確認；目的地空間不夠會直接拒絕
 *  ・每次複製／搬運都記在 AgentCenter/data/pc-transfer-log.jsonl；T-Dongle 小螢幕會顯示進度
 */
const fs = require('fs');
const os = require('os');
const path = require('path');
const crypto = require('crypto');
const { catOf, namedDir } = require('./usbfiles');

const EDITION_FILE = path.join(__dirname, '..', '..', 'config', 'edition.json');
const BIG_COUNT = 200, BIG_BYTES = 2 * 1024 ** 3, MAX_FILES = 20000, WALK_CAP = 60000;
const WORDS = { 文件: 'doc word pdf 文件 報告', 表格: 'excel xls 表格 試算表', 簡報: 'ppt 簡報 投影片', 圖片: '照片 圖片 相片 image photo', 影片: '影片 video', 音樂: '音樂 歌 audio', 壓縮檔: 'zip 壓縮', 程式: '程式 code', 其他: '' };
const human = (n) => (n >= 1024 ** 3 ? (n / 1024 ** 3).toFixed(1) + ' GB' : n >= 1048576 ? (n / 1048576).toFixed(1) + ' MB' : Math.max(1, Math.round(n / 1024)) + ' KB');

/** 不能碰的系統位置 */
function blocked(p, platform = process.platform) {
  if (platform === 'win32') {
    return /^[a-z]:\\(windows|program files( \(x86\))?|programdata|\$recycle\.bin|system volume information|recovery|perflogs|config\.msi|msocache)(\\|$)/i.test(p)
      || /\\appdata(\\|$)/i.test(p) || /^[a-z]:\\(pagefile|hiberfil|swapfile)\.sys$/i.test(p);
  }
  return /^\/(system|bin|sbin|usr|etc|var|private|dev|proc|sys|boot|lib|lib32|lib64|libx32|opt|snap|cores)(\/|$)/i.test(p) || /^\/run\/(?!media\/)/.test(p)
    || /^\/library(\/|$)/i.test(p) || /^\/(users|home)\/[^/]+\/library(\/|$)/i.test(p) || /\/\.(ssh|gnupg|aws|config\/google-chrome)(\/|$)/i.test(p);
}
function freeName(dir, name) { const ext = path.extname(name); const base = name.slice(0, name.length - ext.length); let n = name, i = 2; while (fs.existsSync(path.join(dir, n))) n = `${base} (${i++})${ext}`; return n; }
function sha1(f) { const h = crypto.createHash('sha1'); const fd = fs.openSync(f, 'r'); const buf = Buffer.alloc(1 << 20); try { let n; while ((n = fs.readSync(fd, buf, 0, buf.length, null)) > 0) h.update(buf.subarray(0, n)); } finally { fs.closeSync(fd); } return h.digest('hex'); }
const within = (p, root) => { const a = path.resolve(p), r = path.resolve(root); return a === r || a.startsWith(r.endsWith(path.sep) ? r : r + path.sep); };
const free = (dir) => { try { const s = fs.statfsSync(dir); return s.bavail * s.bsize; } catch { return null; } };

class PcFiles {
  constructor(ctx) { this.ctx = ctx; this._busy = false; }
  get S() { return this.ctx.settings; }
  edition() { try { return JSON.parse(fs.readFileSync(EDITION_FILE, 'utf8')).edition || 'normal'; } catch { return 'normal'; } }
  /** 開發版預設開；usb.pc_access 設 true／false 可以強制開關 */
  enabled() {
    if (!(this.ctx.usb && this.ctx.usb.active())) return false;
    const v = this.S.get('usb.pc_access', ''); return v === true || v === 'true' || ((v === '' || v == null) && this.edition() === 'dev');
  }
  usbRoot() { return this.ctx.usb.root(); }
  appDir() { const p = this.ctx.portable; return p && p.root ? path.resolve(p.root) : path.join(this.usbRoot() || '/', 'AgentCenter'); }
  _need() { if (!this.enabled()) throw new Error('存取電腦檔案只有開發版能用（或在設定把 usb.pc_access 打開）'); return this.usbRoot(); }

  /** 把使用者說的位置變成完整路徑：「USB」「USB:資料夾」「桌面」「D:」「D:\\照片」「~/Downloads」 */
  resolve(where, { forWrite = false } = {}) {
    const root = this._need(); let w = String(where == null ? '' : where).trim();
    let p;
    const um = /^(usb|tf|隨身碟|dongle)\s*[:：/\\]?\s*(.*)$/i.exec(w);
    if (um) p = path.resolve(root, um[2] || '.');
    else if (process.platform === 'win32' && /^[a-z]\s*[:：]?\s*(槽|磁碟)?$/i.test(w)) p = w[0].toUpperCase() + ':\\';
    else if (/^[a-z]:$/i.test(w)) p = w + path.sep;
    else p = namedDir(w);
    p = path.resolve(p);
    if (blocked(p)) throw new Error(`這是系統資料夾，不能${forWrite ? '寫入' : '讀取'}：${p}`);
    if (within(p, this.appDir())) throw new Error('USB 上的 AgentCenter（程式、金鑰、記憶）不能用這個功能動');
    return p;
  }

  /** 這台電腦的磁碟（不含這支 USB） */
  drives() {
    this._need(); const root = path.resolve(this.usbRoot()); const out = [];
    const add = (p, label) => { if (path.resolve(p) === root) return; let st; try { st = fs.statfsSync(p); } catch { return; } out.push({ path: p, label, size: st.blocks * st.bsize, free: st.bavail * st.bsize }); };
    if (process.platform === 'win32') { for (let c = 67; c <= 90; c++) { const d = String.fromCharCode(c) + ':\\'; try { if (fs.existsSync(d)) add(d, d.slice(0, 2)); } catch { /* 光碟機沒片 */ } } }
    else {
      add('/', '系統磁碟'); add(os.homedir(), '家目錄');
      for (const base of ['/Volumes', '/media/' + (os.userInfo().username || ''), '/run/media/' + (os.userInfo().username || ''), '/mnt']) { let ents = []; try { ents = fs.readdirSync(base); } catch { continue; } for (const n of ents) add(path.join(base, n), n); }
    }
    return out;
  }

  list(where, { limit = 200 } = {}) {
    const p = this.resolve(where); let ents;
    try { ents = fs.readdirSync(p, { withFileTypes: true }); } catch (e) { throw new Error(`打不開 ${p}：${e.code === 'ENOENT' ? '不存在' : e.code === 'EACCES' || e.code === 'EPERM' ? '沒有權限' : e.message}`); }
    const items = [];
    for (const e of ents) {
      const full = path.join(p, e.name); if (e.isSymbolicLink() || blocked(full) || within(full, this.appDir())) continue;
      if (e.isDirectory()) items.push({ name: e.name, dir: true });
      else if (e.isFile()) { let st; try { st = fs.statSync(full); } catch { continue; } items.push({ name: e.name, dir: false, size: st.size, mtime: st.mtimeMs }); }
    }
    items.sort((a, b) => (b.dir - a.dir) || a.name.localeCompare(b.name, 'zh-Hant'));
    return { path: p, total: items.length, items: items.slice(0, limit) };
  }

  /** 預設找的地方：桌面、文件、下載、圖片、影片、音樂、OneDrive */
  homeSpots() {
    const h = os.homedir(); const c = [namedDir('桌面'), namedDir('文件'), namedDir('下載'), namedDir('圖片'), path.join(h, 'Videos'), path.join(h, 'Music'), path.join(h, '影片'), path.join(h, '音樂')];
    if (process.env.OneDrive) c.push(process.env.OneDrive);
    return [...new Set(c.map((x) => path.resolve(x)))].filter((d) => { try { return fs.statSync(d).isDirectory(); } catch { return false; } });
  }
  find(query, { where, limit = 10, maxMs = 8000 } = {}) {
    this._need(); const toks = String(query || '').toLowerCase().split(/[\s,，、]+/).filter(Boolean); if (!toks.length) throw new Error('要說要找什麼');
    const starts = where ? [this.resolve(where)] : this.homeSpots(); const t0 = Date.now(); const hits = []; let seen = 0, cut = false;
    const q = starts.map((d) => [d, 0]);
    while (q.length) {
      const [dir, depth] = q.shift(); let ents; try { ents = fs.readdirSync(dir, { withFileTypes: true }); } catch { continue; }
      for (const e of ents) {
        if (++seen > WALK_CAP || Date.now() - t0 > maxMs) { cut = true; q.length = 0; break; }
        if (e.name.startsWith('.') || e.isSymbolicLink()) continue; const full = path.join(dir, e.name); if (blocked(full) || within(full, this.appDir())) continue;
        if (e.isDirectory()) { if (depth < 7 && !/^(node_modules|\$recycle\.bin|\.git)$/i.test(e.name)) q.push([full, depth + 1]); }
        const text = `${full} ${e.isFile() ? WORDS[catOf(e.name)] || '' : '資料夾 folder'}`.toLowerCase();
        const n = toks.filter((t) => text.includes(t)).length; if (!n) continue;
        let st; try { st = fs.statSync(full); } catch { continue; }
        hits.push({ path: full, dir: e.isDirectory(), size: e.isDirectory() ? null : st.size, mtime: st.mtimeMs, score: n / toks.length + (e.name.toLowerCase().includes(toks.join(' ')) ? 0.5 : 0) });
      }
    }
    hits.sort((a, b) => b.score - a.score || b.mtime - a.mtime);
    return { hits: hits.filter((x) => x.score >= Math.min(1, hits[0] ? hits[0].score : 1)).slice(0, limit), searched: starts, cut };
  }

  /** 列出要複製的檔案（資料夾會展開；系統資料夾、捷徑連結跳過） */
  _gather(src) {
    const st = fs.statSync(src); if (st.isFile()) return { files: [{ abs: src, rel: path.basename(src), size: st.size }], bytes: st.size, dir: false, skipped: 0 };
    const files = []; let bytes = 0, skipped = 0; const top = path.basename(src.replace(/[\\/]+$/, '')) || src.replace(/[:\\/]+/g, '') || 'disk';
    const walk = (d) => { let ents; try { ents = fs.readdirSync(d, { withFileTypes: true }); } catch { skipped++; return; }
      for (const e of ents) { const full = path.join(d, e.name);
        if (e.isSymbolicLink() || blocked(full) || within(full, this.appDir())) { skipped++; continue; }
        if (e.isDirectory()) walk(full); else if (e.isFile()) { if (files.length >= MAX_FILES) throw new Error(`檔案超過 ${MAX_FILES} 個，請分批（指定比較小的資料夾）`); let s; try { s = fs.statSync(full); } catch { skipped++; continue; } files.push({ abs: full, rel: path.join(top, path.relative(src, full)), size: s.size }); bytes += s.size; } } };
    walk(src); return { files, bytes, dir: true, top, skipped };
  }

  /**
   * 複製或搬運：from（完整路徑，或用 query 找）→ to（預設 USB:從電腦複製/<電腦名稱>）
   *   回傳 { need_confirm } 表示要先問使用者；確認後同樣參數加 confirm=true 再叫一次
   */
  async transfer({ from, query, where, to, move = false, confirm = false, onProgress } = {}) {
    const root = this._need();
    let src;
    if (from) src = this.resolve(from);
    else {
      const r = this.find(query, { where, limit: 6 }); if (!r.hits.length) throw new Error(`電腦上找不到跟「${query}」有關的檔案（找過：${r.searched.join('、')}）`);
      if (r.hits.length > 1 && r.hits[0].score === r.hits[1].score) { const e = new Error('有好幾個可能的，請用 from 指定完整路徑：\n' + r.hits.map((h, i) => `${i + 1}. ${h.path}${h.dir ? '（資料夾）' : `（${human(h.size)}）`}`).join('\n')); e.code = 'AMBIGUOUS'; throw e; }
      src = r.hits[0].path;
    }
    if (!fs.existsSync(src)) throw new Error('找不到：' + src);
    if (path.parse(src).root === src && move) throw new Error('不能把整個磁碟「搬走」，只能複製');
    const dstDir = to ? this.resolve(to, { forWrite: true }) : path.join(root, '從電腦複製', os.hostname().replace(/[\\/:*?"<>|]/g, '_'));
    if (within(dstDir, src)) throw new Error('目的地不能在來源裡面');
    const g = this._gather(src); if (!g.files.length) throw new Error('裡面沒有可以複製的檔案' + (g.skipped ? `（跳過 ${g.skipped} 個系統或沒權限的項目）` : ''));
    let near = dstDir; while (!fs.existsSync(near) && path.dirname(near) !== near) near = path.dirname(near);   // 預覽時不建資料夾
    const room = free(near); if (room != null && room < g.bytes + 50 * 1048576) throw new Error(`空間不夠：要 ${human(g.bytes)}，${dstDir} 只剩 ${human(room)}`);
    const toUsb = within(dstDir, root); const fromUsb = within(src, root);
    const summary = { from: src, to: dstDir, count: g.files.length, bytes: g.bytes, size: human(g.bytes), move, dir: g.dir, skipped: g.skipped, to_usb: toUsb, from_usb: fromUsb };
    if (!confirm && (move || g.files.length > BIG_COUNT || g.bytes > BIG_BYTES)) return { need_confirm: true, ...summary, sample: g.files.slice(0, 8).map((f) => f.rel) };
    if (this._busy) throw new Error('上一個複製還沒做完'); this._busy = true;
    fs.mkdirSync(dstDir, { recursive: true });
    const td = this.ctx.tdongle; const show = td && td.fd != null;
    if (show) td.screen({ state: 'busy', title: move ? '搬運檔案' : '複製檔案', l1: `${g.files.length} 個 ${human(g.bytes)}`, done: 0, total: g.files.length });
    const topName = freeName(dstDir, g.dir ? g.top : path.basename(src));
    const done = []; const fail = []; let bytes = 0;
    try {
      for (let i = 0; i < g.files.length; i++) {
        const f = g.files[i]; const rel = g.dir ? path.join(topName, path.relative(g.top, f.rel)) : topName; const to2 = path.join(dstDir, rel);
        try {
          fs.mkdirSync(path.dirname(to2), { recursive: true }); const final = fs.existsSync(to2) ? path.join(path.dirname(to2), freeName(path.dirname(to2), path.basename(to2))) : to2;
          await fs.promises.copyFile(f.abs, final, fs.constants.COPYFILE_EXCL);
          try { const st = fs.statSync(f.abs); fs.utimesSync(final, st.atime, st.mtime); } catch { /* 時間戳不重要 */ }
          if (fs.statSync(final).size !== f.size) throw new Error('複製後大小不一樣');
          if (move) { if (sha1(final) !== sha1(f.abs)) throw new Error('複製後內容不一樣，原檔保留'); fs.unlinkSync(f.abs); }
          done.push({ from: f.abs, to: final }); bytes += f.size;
        } catch (e) { fail.push(`${f.rel}：${e.code === 'EACCES' || e.code === 'EPERM' ? '沒有權限' : e.code === 'EBUSY' ? '檔案正在使用中' : e.message}`); }
        if (onProgress) onProgress(i + 1, g.files.length, f.rel);
        if (show && (i % 5 === 0 || i === g.files.length - 1)) td.progress(i + 1, g.files.length, path.basename(f.rel));
        if (i % 20 === 19) await new Promise((r) => setImmediate(r));
      }
      if (move && g.dir) { const rm = (d) => { let ents; try { ents = fs.readdirSync(d); } catch { return; } for (const n of ents) { const p = path.join(d, n); try { if (fs.lstatSync(p).isDirectory()) rm(p); } catch { /* ignore */ } } try { fs.rmdirSync(d); } catch { /* 還有檔案就留著 */ } }; rm(src); }
    } finally {
      this._busy = false;
      if (show) td.screen({ state: 'ready', title: fail.length ? `完成，${fail.length} 個失敗` : (move ? '搬運完成' : '複製完成'), l1: `${done.length} 個 ${human(bytes)}`, l2: '', total: 0 });
    }
    const rec = { at: new Date().toISOString(), host: os.hostname(), act: move ? 'move' : 'copy', from: src, to: dstDir, ok: done.length, fail: fail.length, bytes };
    try { fs.appendFileSync(path.join(this.ctx.paths.data, 'pc-transfer-log.jsonl'), JSON.stringify(rec) + '\n'); } catch { /* ignore */ }
    if (this.ctx.usb) this.ctx.usb._idx = null;
    return { ...summary, done: done.length, failed: fail, copied: human(bytes), top: path.join(dstDir, topName) };
  }
  history(n = 20) { try { return fs.readFileSync(path.join(this.ctx.paths.data, 'pc-transfer-log.jsonl'), 'utf8').split('\n').filter(Boolean).slice(-n).map((l) => JSON.parse(l)); } catch { return []; } }
}

module.exports = { PcFiles, blocked, human };
