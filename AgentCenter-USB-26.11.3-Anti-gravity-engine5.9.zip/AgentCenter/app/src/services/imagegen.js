'use strict';
/**
 * 圖片生成。供應商（image.provider）：
 *   gemini      用你已設定的 Gemini 金鑰池（沿用金鑰輪換），模型預設 gemini-2.5-flash-image（俗稱 Nano Banana），可「看著使用者傳的圖」改圖
 *   openai      OpenAI 圖像 API（需要 image.openai_key）
 *   pollinations 免金鑰的公開服務（品質普通，當最後備援）
 *   auto        依序嘗試：Gemini → OpenAI → Pollinations，前一個失敗就換下一個
 */
const { logger } = require('../core/log');
const { fetchJson, fetchBuf } = require('../core/util');
const llm = require('../llm');
const { sniff } = require('./media');
const log = logger('imagegen');

const RATIOS = { '1:1': [1024, 1024], '16:9': [1280, 720], '9:16': [720, 1280], '4:3': [1152, 864], '3:4': [864, 1152], '3:2': [1200, 800], '2:3': [800, 1200] };

class ImageGen {
  constructor(ctx) { this.ctx = ctx; }
  get cfg() { return this.ctx.settings.get('image') || {}; }
  providers() {
    const p = this.cfg.provider || 'auto'; if (p !== 'auto') return [p];
    const out = []; if (llm.keyCandidates(this.ctx.settings, 'gemini').some(llm.usable)) out.push('gemini'); if (this.cfg.openai_key) out.push('openai'); out.push('pollinations'); return out;
  }
  /** → {buf, mime, provider}；refs＝要參考／修改的圖片 [{mime,data}] */
  async generate({ prompt, aspect = '1:1', refs = [] }) {
    prompt = String(prompt || '').trim(); if (!prompt) throw new Error('缺少圖片描述');
    if (!RATIOS[aspect]) aspect = '1:1'; const errs = [];
    for (const p of this.providers()) {
      try {
        const r = p === 'gemini' ? await this.gemini(prompt, aspect, refs) : p === 'openai' ? await this.openai(prompt, aspect) : await this.pollinations(prompt, aspect);
        const mime = sniff(r.buf); if (!mime) throw new Error('回傳的不是圖片'); this.ctx.usage.add('image:' + p, { in: 0, out: 0 }); return { buf: r.buf, mime, provider: p };
      } catch (e) { log.warn(`${p} 生圖失敗：${e.message}`); errs.push(`${p}：${e.message}`); }
    }
    throw new Error('生成圖片失敗。' + errs.join('；'));
  }
  async gemini(prompt, aspect, refs) {
    const S = this.ctx.settings; const model = this.cfg.model || 'gemini-2.5-flash-image';
    const parts = [{ text: prompt }, ...refs.map((r) => ({ inlineData: { mimeType: r.mime, data: r.data } }))];
    const run = (withRatio) => llm.withKeyRotation(this.ctx, 'gemini', (c) => llm.post(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent`, { 'x-goog-api-key': c.key },
      { contents: [{ role: 'user', parts }], generationConfig: { responseModalities: ['TEXT', 'IMAGE'], ...(withRatio ? { imageConfig: { aspectRatio: aspect } } : {}) } }, 'Gemini', true));
    let j; try { j = await run(aspect !== '1:1'); } catch (e) { if (e.status === 400 && aspect !== '1:1') j = await run(false); else throw e; }
    const cand = j.candidates && j.candidates[0]; const ps = (cand && cand.content && cand.content.parts) || [];
    const img = ps.find((x) => x.inlineData && x.inlineData.data) || ps.find((x) => x.inline_data && x.inline_data.data);
    if (!img) { const why = (cand && cand.finishReason) || (j.promptFeedback && j.promptFeedback.blockReason) || ''; const txt = ps.filter((x) => x.text).map((x) => x.text).join('').slice(0, 160); throw new Error(`模型沒有產生圖片${why ? '（' + why + '）' : ''}${txt ? '：' + txt : ''}`); }
    return { buf: Buffer.from((img.inlineData || img.inline_data).data, 'base64') };
  }
  async openai(prompt, aspect) {
    const key = this.cfg.openai_key; if (!key) throw new Error('沒有設定 OpenAI 金鑰');
    const size = aspect === '1:1' ? '1024x1024' : RATIOS[aspect][0] > RATIOS[aspect][1] ? '1536x1024' : '1024x1536';
    const r = await fetchJson('https://api.openai.com/v1/images/generations', { method: 'POST', headers: { 'content-type': 'application/json', authorization: 'Bearer ' + key }, body: JSON.stringify({ model: this.cfg.openai_model || 'gpt-image-1', prompt, size, n: 1 }) }, 120000);
    if (!r.ok) throw new Error(`OpenAI ${r.status} ${((r.json && r.json.error && r.json.error.message) || r.text).slice(0, 160)}`);
    const d = r.json && r.json.data && r.json.data[0]; if (!d) throw new Error('OpenAI 沒有回傳圖片');
    if (d.b64_json) return { buf: Buffer.from(d.b64_json, 'base64') }; if (d.url) return { buf: (await fetchBuf(d.url, {}, 60000)).buf }; throw new Error('OpenAI 回傳格式不認得');
  }
  async pollinations(prompt, aspect) {
    const [w, h] = RATIOS[aspect]; const url = `https://image.pollinations.ai/prompt/${encodeURIComponent(prompt.slice(0, 900))}?width=${w}&height=${h}&nologo=true&model=flux&seed=${Math.floor(Math.random() * 1e6)}`;
    return { buf: (await fetchBuf(url, { headers: { 'user-agent': 'Mozilla/5.0 AgentHub' } }, 90000)).buf };
  }
}
module.exports = { ImageGen, RATIOS };
