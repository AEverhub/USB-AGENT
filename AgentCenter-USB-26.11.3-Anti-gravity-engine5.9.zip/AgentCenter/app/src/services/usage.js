'use strict';
const { taipei } = require('../core/util');
/** 模型消耗統計（每日、每模型），顯示在 App 操作頁 */
class Usage {
  constructor(ctx) { this.ctx = ctx; }
  add(model, u) {
    const d = taipei().iso; const days = this.ctx.store.db.usage.days; const day = days[d] || (days[d] = { in: 0, out: 0, calls: 0, byModel: {} });
    day.in += u.in; day.out += u.out; day.calls++; const m = day.byModel[model] || (day.byModel[model] = { in: 0, out: 0, calls: 0 }); m.in += u.in; m.out += u.out; m.calls++;
    const keys = Object.keys(days).sort(); while (keys.length > 120) delete days[keys.shift()]; this.ctx.store.touch();
  }
  /** 每一次對話（可能多輪模型呼叫）的總 token，給「監控」頁看省了多少 */
  turn(t) {
    const m = this.ctx.store.db.meta; const l = (m.turns ||= []); l.push({ at: Date.now(), in: t.tokens.in, out: t.tokens.out, rounds: t.rounds, tools: t.tools_sent || 0, ...(t.exp ? { exp: 1 } : {}) }); if (l.length > 60) l.splice(0, l.length - 60); this.ctx.store.touch();
  }
  turnStats() { const l = (this.ctx.store.db.meta.turns || []).slice(-20); if (!l.length) return null; const avg = (k) => Math.round(l.reduce((s, x) => s + x[k], 0) / l.length); return { n: l.length, avg_in: avg('in'), avg_out: avg('out'), avg_rounds: Math.round(l.reduce((s, x) => s + x.rounds, 0) / l.length * 10) / 10, avg_tools: avg('tools'), exp: l.filter((x) => x.exp).length, experience: this.ctx.experience ? this.ctx.experience.stats() : null, consolidate: this.ctx.consolidate ? this.ctx.consolidate.last() : null, skills: this.ctx.skills ? (() => { try { const L = this.ctx.skills.list(); return { total: L.length, usable: L.filter((e) => e.model && e.gate.ok).length, third: L.filter((e) => e.trust === 'imported' || e.trust === 'untrusted').length }; } catch { return null; } })() : null }; }
  summary() {
    const days = this.ctx.store.db.usage.days; const today = days[taipei().iso] || { in: 0, out: 0, calls: 0 };
    let tin = 0, tout = 0, calls = 0; for (const d of Object.values(days)) { tin += d.in; tout += d.out; calls += d.calls; }
    return { today, turns: this.turnStats(), total: { in: tin, out: tout, calls }, days: Object.entries(days).sort().slice(-14).map(([k, v]) => ({ day: k, in: v.in, out: v.out, calls: v.calls })) };
  }
}
module.exports = { Usage };
