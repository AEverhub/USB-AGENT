'use strict';
const fs = require('fs');
const path = require('path');
const { logger } = require('../core/log');
const log = logger('fs');

const MAX_READ = 400 * 1024;

class Fsx {
  constructor(ctx) { this.ctx = ctx; }
  /** scope：'workspace'（工作區）｜'app'（整個 App 沙盒，含 AI 自己的程式與資料）｜'data'（資料夾，給人類檔案管理頁） */
  root(scope) { const p = this.ctx.paths; return scope === 'app' ? p.appRoot : scope === 'data' ? p.data : p.workspace; }
  aiScope() { return this.ctx.settings.get('policy.ai_fs_scope') === 'app' ? 'app' : 'workspace'; }
  resolve(rel, scope) {
    const root = path.resolve(this.root(scope)); const full = path.resolve(root, String(rel || '.').replace(/^[/\\]+/, ''));
    if (full !== root && !full.startsWith(root + path.sep)) throw new Error('路徑超出允許範圍');
    return full;
  }
  /** AI 的檔案工具不能碰設定檔（金鑰、密碼雜湊）與 token 檔 */
  guardAI(rel, scope) {
    const full = this.resolve(rel || '.', scope); const base = path.basename(full);
    if (['settings.json', 'settings.json.tmp', 'settings.json.bak', 'ui_token', 'ui_token_native', 'vault.json', 'vault.json.tmp', 'vault.key'].includes(base) || full.split(path.sep).includes('browser-profile')) throw new Error('這個檔案含金鑰／憑證／登入資料，AI 不能讀寫（請管理員自己在 App 設定頁操作）');
    return full;
  }
  list(rel = '.', scope = 'data') {
    const dir = this.resolve(rel, scope); const root = path.resolve(this.root(scope));
    return fs.readdirSync(dir, { withFileTypes: true }).map((d) => { let st = null; try { st = fs.statSync(path.join(dir, d.name)); } catch { /* ignore */ }
      return { name: d.name, dir: d.isDirectory(), size: st ? st.size : 0, mtime: st ? st.mtimeMs : 0, path: path.relative(root, path.join(dir, d.name)) }; })
      .sort((a, b) => (b.dir - a.dir) || a.name.localeCompare(b.name));
  }
  read(rel, scope = 'data', asBuffer = false) {
    const f = this.resolve(rel, scope); const st = fs.statSync(f); if (st.isDirectory()) throw new Error('這是資料夾');
    if (asBuffer) return fs.readFileSync(f);
    if (st.size > MAX_READ) { const fd = fs.openSync(f, 'r'); const b = Buffer.alloc(MAX_READ); fs.readSync(fd, b, 0, MAX_READ, 0); fs.closeSync(fd); return b.toString('utf8') + `\n…（檔案 ${st.size} bytes，只顯示前 ${MAX_READ}）`; }
    return fs.readFileSync(f, 'utf8');
  }
  snapshot(full, who) {
    if (!this.ctx.settings.get('policy.snapshot_before_destructive') || !fs.existsSync(full)) return null;
    try {
      const st = fs.statSync(full); if (st.size > 30 * 1024 * 1024 && !st.isDirectory()) return null;
      const dest = path.join(this.ctx.paths.snapshots, String(Date.now()), path.basename(full));
      fs.mkdirSync(path.dirname(dest), { recursive: true }); fs.cpSync(full, dest, { recursive: true });
      fs.writeFileSync(path.join(path.dirname(dest), 'meta.json'), JSON.stringify({ orig: full, name: path.basename(full), who, ts: Date.now() }));
      this._pruneSnapshots(); return dest;
    } catch (e) { log.warn('快照失敗', e.message); return null; }
  }
  _pruneSnapshots() {
    try { const d = this.ctx.paths.snapshots; const l = fs.readdirSync(d).sort(); while (l.length > 40) fs.rmSync(path.join(d, l.shift()), { recursive: true, force: true }); } catch { /* ignore */ }
  }
  write(rel, content, scope = 'data', who = 'human', append = false) {
    const f = this.resolve(rel, scope); fs.mkdirSync(path.dirname(f), { recursive: true });
    if (!append) this.snapshot(f, who);
    (append ? fs.appendFileSync : fs.writeFileSync)(f, content); this.ctx.store.audit(who, 'fs.write', f); return f;
  }
  mkdir(rel, scope = 'data') { fs.mkdirSync(this.resolve(rel, scope), { recursive: true }); }
  remove(rel, scope = 'data', who = 'human') {
    const f = this.resolve(rel, scope); const root = path.resolve(this.root(scope)); if (f === root) throw new Error('不能刪除根目錄');
    const snap = this.snapshot(f, who); fs.rmSync(f, { recursive: true, force: true }); this.ctx.store.audit(who, 'fs.delete', f); return snap;
  }
  move(from, to, scope = 'data', who = 'human') {
    const a = this.resolve(from, scope), b = this.resolve(to, scope); fs.mkdirSync(path.dirname(b), { recursive: true }); fs.renameSync(a, b); this.ctx.store.audit(who, 'fs.move', `${a} -> ${b}`);
  }
  snapshots() {
    try { return fs.readdirSync(this.ctx.paths.snapshots).sort().reverse().map((id) => { try { return { id, ...JSON.parse(fs.readFileSync(path.join(this.ctx.paths.snapshots, id, 'meta.json'), 'utf8')) }; } catch { return null; } }).filter(Boolean); } catch { return []; }
  }
  restoreSnapshot(id, who = 'human') {
    const dir = path.join(this.ctx.paths.snapshots, String(id).replace(/[^\d]/g, '')); const meta = JSON.parse(fs.readFileSync(path.join(dir, 'meta.json'), 'utf8'));
    fs.mkdirSync(path.dirname(meta.orig), { recursive: true }); fs.cpSync(path.join(dir, meta.name), meta.orig, { recursive: true, force: true });
    this.ctx.store.audit(who, 'fs.restore', meta.orig); return meta.orig;
  }
  usage() { const sum = (d) => { let n = 0; try { for (const e of fs.readdirSync(d, { withFileTypes: true })) { const p = path.join(d, e.name); n += e.isDirectory() ? sum(p) : fs.statSync(p).size; } } catch { /* ignore */ } return n; }; return sum(this.ctx.paths.data); }
}
module.exports = { Fsx };
