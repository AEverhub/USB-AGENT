'use strict';
/**
 * 每日簡報：天氣＋今天行事曆＋未讀重要信＋今日提醒＋待審批＋24 小時內哨兵觸發＋手機電量。
 * 每一段都獨立取得，哪一段失敗（沒連 Google、沒 Termux…）就略過，不影響其他段。
 * 有模型金鑰時讓模型整理成好讀的訊息；沒有就直接送條列。
 */
const llm = require('../llm');
const weather = require('./weather');
const { zoned, fromZoned, clip } = require('../core/util');
const { logger } = require('../core/log');
const log = logger('brief');

class Brief {
  constructor(ctx) { this.ctx = ctx; }
  cfg() { return { enabled: false, at: '07:30', city: 'Taipei', gmail_query: 'is:unread newer_than:1d -category:promotions -category:social', ...(this.ctx.settings.get('brief', {}) || {}) }; }
  /** 收集事實（不經模型）；回傳 {sections:[{title,lines}], date} */
  async facts(person) {
    const { ctx } = this; const c = this.cfg(); const tz = ctx.settings.get('tz'); const z = zoned(Date.now(), tz);
    const [y, mo, d] = z.iso.split('-').map(Number); const start = fromZoned(y, mo, d, 0, 0, tz); const end = start + 86400e3;
    const boss = !person || person.role === 'admin';   // 信件、行程、手機、待審批只給管理員
    const sec = []; const add = (title, lines) => { if (lines && lines.length) sec.push({ title, lines }); };
    const jobs = [
      c.city ? weather.forecast(c.city, 1).then((w) => { const n = w.now; const t = w.daily[0] || {}; add('天氣', [`${w.place}：現在 ${n.desc} ${n.temp}°C（體感 ${n.feels}°C）`, `今天 ${t.desc || ''} ${t.min}～${t.max}°C${t.rain != null ? `，降雨機率 ${t.rain}%` : ''}${t.uv != null && t.uv >= 6 ? `，紫外線 ${t.uv} 偏高` : ''}`]); }) : null,
      boss && ctx.gws && ctx.gws.ready() ? ctx.gws.calList(new Date(start).toISOString(), new Date(end).toISOString(), 15).then((r) => add('今天行程', (r.items || []).map((e) => { const s = e.start || {}; const hm = s.dateTime ? zoned(Date.parse(s.dateTime), tz).time : '整天'; return `${hm} ${e.summary || '(無標題)'}${e.location ? ' @' + e.location : ''}`; }))) : null,
      boss && ctx.gws && ctx.gws.ready() ? ctx.gws.gmailSearch(c.gmail_query, 8).then((l) => add(`未讀信件（${l.length}${l.length >= 8 ? '+' : ''}）`, l.map((m) => `${clip(String(m.from || '').replace(/<.*>/, '').trim(), 24)}：${clip(m.subject || '(無主旨)', 60)}`))) : null,
      boss && ctx.phone && ctx.phone.ready() ? ctx.phone.status().then((s) => { const b = s.battery || {}; if (b.percentage != null) add('手機', [`電量 ${b.percentage}%${b.status ? `（${b.status === 'CHARGING' ? '充電中' : b.status === 'FULL' ? '已充滿' : '未充電'}）` : ''}`]); }) : null,
    ].filter(Boolean).map((p) => p.catch((e) => log.warn('簡報段落略過：' + e.message)));
    await Promise.all(jobs);
    const mine = (ctx.store.db.tasks || []).filter((t) => t.status === 'pending' && t.run_at >= start && t.run_at < end && (boss || t.pid === person.id));
    add('今天的提醒／排程', mine.sort((a, b) => a.run_at - b.run_at).map((t) => `${zoned(t.run_at, tz).time} ${clip(t.instruction, 60)}`));
    const appr = (ctx.store.db.approvals || []).filter((a) => a.status === 'pending'); if (boss) add('待你審批', appr.slice(0, 6).map((a) => `#${a.id} ${clip(a.summary, 60)}`));
    if (ctx.watch) add('哨兵（24 小時內觸發）', ctx.watch.firedSince(Date.now() - 86400e3).filter((w) => boss || w.pid === person.id).map((w) => `${w.name}：${clip(w.last_value, 60)}`));
    return { date: `${z.iso}（${'日一二三四五六'[new Date(z.iso + 'T12:00:00Z').getUTCDay()]}）`, sections: sec };
  }
  plain(f) { return [`☀️ ${f.date} 每日簡報`, ...f.sections.map((s) => `\n【${s.title}】\n` + s.lines.map((l) => '・' + l).join('\n'))].join('\n') + (f.sections.length ? '' : '\n今天沒有需要特別注意的事。'); }
  async build(person) {
    const f = await this.facts(person); const base = this.plain(f);
    if (!llm.hasKey(this.ctx.settings) || !f.sections.length) return base;
    try {
      const t = await llm.simple(this.ctx, `以下是今天的事實清單。請整理成給${person && person.name ? '「' + person.name + '」' : '主人'}的早晨簡報：開頭一句問候，接著依重要性條列（行程與待審批優先），天氣給一句穿著／帶傘建議，最後一句提醒今天最重要的一件事。只能用清單裡的事實，不要編造；繁體中文、精簡、手機好讀，不用 Markdown 標題。\n\n${base}`);
      return t && t.trim() ? t.trim() : base;
    } catch (e) { log.warn('模型整理簡報失敗，改送條列：' + e.message); return base; }
  }
  /** 排程器到點呼叫：送給所有管理員 */
  async send() {
    const admins = this.ctx.users.list().filter((p) => p.role === 'admin' && p.status === 'active'); let n = 0;
    for (const p of admins) { try { await this.ctx.hub.sendToPerson(p, await this.build(p)); n++; } catch (e) { log.warn(`簡報送不出去（${p.name || p.id}）：${e.message}`); } }
    return n;
  }
}
module.exports = { Brief };
