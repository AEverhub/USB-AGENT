'use strict';
/** 天氣：Open-Meteo（免金鑰、免註冊）。地名先查座標，再取現況＋未來幾天預報。 */
const { fetchJson, TTLCache } = require('../core/util');

const WMO = { 0: '晴', 1: '大致晴朗', 2: '局部多雲', 3: '陰', 45: '霧', 48: '霧凇', 51: '毛毛雨', 53: '毛毛雨', 55: '濃毛毛雨', 56: '凍毛毛雨', 57: '凍毛毛雨', 61: '小雨', 63: '中雨', 65: '大雨', 66: '凍雨', 67: '強凍雨', 71: '小雪', 73: '中雪', 75: '大雪', 77: '雪粒', 80: '陣雨', 81: '較強陣雨', 82: '豪大陣雨', 85: '陣雪', 86: '強陣雪', 95: '雷雨', 96: '雷雨伴冰雹', 99: '強雷雨伴冰雹' };
const desc = (c) => WMO[c] || `天氣代碼 ${c}`;
const geoCache = new TTLCache(7 * 86400e3, 200);

async function geocode(place) {
  const name = String(place || '').trim(); if (!name) throw new Error('要給地名（例如：台北、高雄市、Tokyo）');
  const m = /^\s*(-?\d+(?:\.\d+)?)\s*,\s*(-?\d+(?:\.\d+)?)\s*$/.exec(name); if (m) return { name, lat: +m[1], lon: +m[2] };
  const tries = [...new Set([name, name.replace(/臺/g, '台'), name.replace(/台/g, '臺'), name.replace(/[市縣區鄉鎮]$/, '')])].filter(Boolean);
  for (const n of tries) {
    const hit = geoCache.get(n); if (hit) return hit;
    const r = await fetchJson(`https://geocoding-api.open-meteo.com/v1/search?count=1&language=zh&format=json&name=${encodeURIComponent(n)}`, {}, 15000);
    const g = r.json && r.json.results && r.json.results[0];
    if (g) { const o = { name: [g.name, g.admin1, g.country].filter(Boolean).filter((x, i, a) => a.indexOf(x) === i).join('，'), lat: g.latitude, lon: g.longitude, tz: g.timezone }; geoCache.set(n, o); return o; }
  }
  throw new Error(`找不到「${name}」這個地點（可改用英文地名或「緯度,經度」）`);
}

async function forecast(place, days = 3) {
  const g = await geocode(place); days = Math.max(1, Math.min(+days || 3, 7));
  const u = `https://api.open-meteo.com/v1/forecast?latitude=${g.lat}&longitude=${g.lon}&timezone=auto&forecast_days=${days}`
    + '&current=temperature_2m,apparent_temperature,relative_humidity_2m,weather_code,wind_speed_10m,precipitation'
    + '&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max,uv_index_max';
  const r = await fetchJson(u, {}, 15000); if (!r.ok || !r.json) throw new Error(`天氣服務錯誤（${r.status}）`);
  const c = r.json.current || {}; const d = r.json.daily || {};
  const daily = (d.time || []).map((t, i) => ({ date: t, desc: desc(d.weather_code[i]), max: d.temperature_2m_max[i], min: d.temperature_2m_min[i], rain: d.precipitation_probability_max ? d.precipitation_probability_max[i] : null, uv: d.uv_index_max ? d.uv_index_max[i] : null }));
  return { place: g.name, now: { temp: c.temperature_2m, feels: c.apparent_temperature, humidity: c.relative_humidity_2m, desc: desc(c.weather_code), wind: c.wind_speed_10m, rain_mm: c.precipitation }, daily };
}
function text(w) {
  const n = w.now; const lines = [`📍 ${w.place}`, `現在 ${n.desc} ${n.temp}°C（體感 ${n.feels}°C）濕度 ${n.humidity}% 風速 ${n.wind} km/h`];
  for (const d of w.daily) lines.push(`${d.date.slice(5)} ${d.desc} ${d.min}～${d.max}°C${d.rain != null ? ` 降雨 ${d.rain}%` : ''}${d.uv != null ? ` UV ${d.uv}` : ''}`);
  return lines.join('\n');
}
module.exports = { forecast, geocode, text, desc };
