'use strict';
/**
 * 26.11.3 Revise7 手機代理：AI 依管理員的指示操作手機上的其他 App。
 *
 * 架構（和瀏覽器代理同一套思路）：
 *   Android 無障礙服務 PhoneAgentService（使用者自己在系統設定開啟）
 *     ・讀畫面：無障礙節點樹（文字、按鈕、輸入框、可捲動區…）＋ 截圖（Android 11 以上）
 *     ・操作：點擊、長按、滑動、捲動、輸入文字、返回／主畫面／多工、開 App
 *     ・在 127.0.0.1 隨機埠開一個小 HTTP 介面（每次啟動換一組 token），寫到 data/phone_agent.json
 *     ・畫一個像 OPPO 遊戲助手那樣的「側邊懸浮面板」：從螢幕邊緣拉出來下指令、看 AI 進度、按停止、允許／拒絕
 *   這裡（Node 後台）：給 AI 的 phone_* 工具、每一步截圖（只放記憶體，過期自動刪）、高風險動作的強制確認。
 *
 * 安全：
 *   ・只有管理員能用（工具 admin 限定；懸浮面板在管理員自己的手機上）。
 *   ・付款、轉帳、刪除、解除安裝、安裝、授權／允許權限、重設、登出、傳送訊息／發文… 這類按鈕，
 *     以及在輸入框按 Enter 送出，一律先跳「允許／拒絕」給管理員按（懸浮面板或 App），AI 不能自己確認，也不能透過 app_api 確認。
 *   ・密碼欄位不打字（交給管理員自己輸入）；讀到的密碼欄位只顯示「(密碼欄)」。
 */
const fs = require('fs');
const path = require('path');
const http = require('http');
const crypto = require('crypto');
const { EventEmitter } = require('events');
const { logger } = require('../core/log');
const log = logger('phoneagent');
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

const RISKY = /(付款|支付|付費|購買|結帳|下單|訂購|轉帳|匯款|儲值|確認付款|立即支付|pay|purchase|buy now|checkout|transfer|刪除|移除|清除資料|解除安裝|卸載|uninstall|delete|remove|恢復原廠|重設|重置|格式化|reset|erase|安裝|install|授權|允許|allow|authorize|grant|登出|sign out|log ?out|封鎖|block|解除好友|退出群組|leave group)/i;
const SEND = /(傳送|發送|送出|發佈|發布|發文|分享|回覆|留言|send|post|publish|share|reply|tweet)/i;

// 26.11.3 pro10 遊戲協助模式的指令開頭
const GAME = '【手機代理・遊戲協助模式：幫管理員操作目前畫面上的遊戲。做法：①遊戲畫面通常讀不到元素，直接 phone_screenshot 看圖，用圖上的 x,y 呼叫 phone_tap／phone_swipe；每做一步再截圖確認結果。②重複的固定動作（刷關、收獎勵、連點）不要一步一步點，改用 phone_macro（固定順序）或 phone_autoclick（同一點連點），省時間也省 token。③任何會花錢或不可逆的按鈕（儲值、購買、抽卡付費、刪除角色、解除綁定）一律停下來問管理員，不要點。④遇到登入、驗證碼、人機驗證，或遊戲跳出禁止自動操作的警告，就停下來回報。⑤不做也不教任何規避遊戲偵測、修改記憶體或封包的事。⑥完成目標、卡住或做了 40 步就停，簡短回報目前狀況。目標：】';
class PhoneAgent {
  constructor(ctx) {
    this.ctx = ctx; this.steps = []; this.seq = 0; this.ev = new EventEmitter(); this.ev.setMaxListeners(50);
    this.pending = null; this.task = null; this.cancel = false; this.lastScreen = null; this.history = [];
  }
  /** confirm_risky 寫死為 true（付款、刪除…一定要人確認，誰都關不掉）；confirm_send 管理員可以在 App 關 */
  cfg() { return { confirm_send: true, step_ttl_min: 30, settle_ms: 700, ...(this.ctx.settings.get('phone_agent', {}) || {}), confirm_risky: true }; }
  endpoint() { try { const j = JSON.parse(fs.readFileSync(path.join(this.ctx.paths.data, 'phone_agent.json'), 'utf8')); if (!j || !+j.port || typeof j.token !== 'string' || j.token.length < 32) return null; return j; } catch { return null; } }
  /** 呼叫 Android 無障礙服務 */
  call(method, p, body, { timeout = 15000, raw = false } = {}) {
    const e = this.endpoint(); if (!e) return Promise.reject(new Error('手機代理還沒開啟：到 App「更多 → 手機代理」按「開啟無障礙設定」，打開「Agent中控中心 手機代理」。'));
    return new Promise((resolve, reject) => {
      const data = body !== undefined ? Buffer.from(JSON.stringify(body)) : null;
      const r = http.request({ host: '127.0.0.1', port: +e.port, path: p, method, timeout, headers: { 'x-agent-token': e.token, ...(data ? { 'content-type': 'application/json', 'content-length': data.length } : {}) } }, (res) => {
        const c = []; res.on('data', (d) => c.push(d)); res.on('end', () => { const b = Buffer.concat(c); if (res.statusCode >= 400) { let m = ''; try { m = JSON.parse(b.toString()).error; } catch { m = b.toString().slice(0, 200); } return reject(new Error(m || `手機代理 HTTP ${res.statusCode}`)); } if (raw) return resolve({ buf: b, type: res.headers['content-type'] || '', headers: res.headers }); try { resolve(JSON.parse(b.toString() || '{}')); } catch { reject(new Error('手機代理回應格式錯誤')); } });
      });
      r.on('timeout', () => r.destroy(new Error('手機代理沒有回應（逾時）'))); r.on('error', (er) => reject(/ECONNREFUSED/.test(er.message) ? new Error('手機代理服務沒在跑：系統可能把它關掉了，請到「設定 → 無障礙」重新開啟，並把 App 電池設定改成「不受限制」。') : er));
      if (data) r.write(data); r.end();
    });
  }
  async status() {
    const e = this.endpoint(); let health = null; if (e) { try { health = await this.call('GET', '/health', undefined, { timeout: 3000 }); } catch (er) { health = { ok: false, error: er.message }; } }
    return { enabled: !!(health && health.ok), endpoint: !!e, health, running: !!this.task, task: this.task ? { text: this.task.text, since: this.task.since, doing: this.task.doing } : null, pending: this.pending ? { id: this.pending.id, text: this.pending.text, ts: this.pending.ts } : null,
      step: this.meta(this.steps[this.steps.length - 1]), steps: this.steps.length, settings: this.cfg(), history: this.history.slice(-8) };
  }
  meta(x) { return x ? { seq: x.seq, ts: x.ts, label: x.label, pkg: x.pkg, tap: x.tap || null, w: x.w, h: x.h, by: x.by, img: !!x.jpeg } : null; }

  // ---------- 讀畫面 ----------
  async screen() { const s = await this.call('GET', '/screen'); this.lastScreen = s; return s; }
  /** 給 AI 看的文字版畫面：[編號] 種類「文字」(可點/可輸入/可捲動) */
  fmt(s, max = 120) {
    const rows = []; for (const n of (s.nodes || []).slice(0, max)) {
      const kind = n.edit ? '輸入框' : n.scroll && !n.click ? '捲動區' : n.check ? (n.checked ? '已勾選' : '未勾選') : n.click ? '按鈕' : '文字';
      const label = n.pwd ? '(密碼欄)' : [n.text, n.desc && n.desc !== n.text ? n.desc : '', n.hint && !n.text ? '提示:' + n.hint : ''].filter(Boolean).join('｜');
      const flags = [n.click && kind !== '按鈕' ? '可點' : '', n.long ? '可長按' : '', n.focused ? '焦點' : '', n.sel ? '已選' : ''].filter(Boolean).join('/');
      rows.push(`[${n.id}] ${kind}${label ? '「' + String(label).slice(0, 80) + '」' : ''}${n.res ? ' #' + n.res : ''}${flags ? ' (' + flags + ')' : ''}`);
    }
    return `App：${s.label || s.pkg || '?'}（${s.pkg || ''}）${s.ime ? '・鍵盤開著' : ''}\n螢幕 ${s.w}×${s.h}\n${rows.join('\n') || '（這個畫面讀不到元素：可能是遊戲、影片或受保護的畫面，用 phone_screenshot 看）'}${(s.nodes || []).length > max ? `\n…還有 ${(s.nodes || []).length - max} 個元素（捲動後再讀）` : ''}`;
  }
  nodeById(id) { const n = this.lastScreen && (this.lastScreen.nodes || []).find((x) => x.id === +id); if (!n) throw new Error('沒有這個元素編號（畫面可能變了），請先 phone_screen 重新讀取'); return n; }
  nodeAt(x, y) { const ns = (this.lastScreen && this.lastScreen.nodes) || []; let best = null; for (const n of ns) { const [l, t, r, b] = n.b || []; if (x >= l && x <= r && y >= t && y <= b && (n.click || n.edit) && (!best || (r - l) * (b - t) < (best.b[2] - best.b[0]) * (best.b[3] - best.b[1]))) best = n; } return best; }
  labelOf(n) { return n ? [n.text, n.desc, n.ctext, n.res].filter(Boolean).join(' ') : ''; }

  // ---------- 高風險確認（只有人能按）----------
  async confirm(text) {
    if (this.pending) throw new Error('還有一個動作在等管理員確認');
    const id = crypto.randomBytes(6).toString('hex'); let done; const p = new Promise((r) => { done = r; });
    this.pending = { id, text: String(text).slice(0, 200), ts: Date.now(), done }; this.ev.emit('pending', { id, text: this.pending.text });
    this.ctx.notifier.push('warn', 'AI 要操作手機，需要你確認', this.pending.text, { force: true }).catch(() => {});
    const t = setTimeout(() => done('timeout'), 90000); const r = await p; clearTimeout(t); this.pending = null;
    if (r !== 'allow') throw new Error(r === 'timeout' ? '管理員 90 秒內沒有確認，這個動作沒有執行。' : '管理員拒絕了這個動作，沒有執行。請改做別的或問管理員要怎麼處理。');
    return true;
  }
  /** 管理員在懸浮面板／App 按允許或拒絕（AI 的 app_api 不能呼叫這個） */
  decide(id, allow) { if (!this.pending || this.pending.id !== String(id)) throw new Error('沒有這個待確認的動作'); this.pending.done(allow ? 'allow' : 'deny'); return { ok: true }; }
  async guardTap(n, why) {
    const c = this.cfg(); const label = this.labelOf(n);
    if (c.confirm_risky !== false && RISKY.test(label)) await this.confirm(`${why}：「${label.slice(0, 60)}」（${(this.lastScreen && this.lastScreen.label) || ''}）`);
    else if (c.confirm_send !== false && SEND.test(label) && !/取消|cancel/i.test(label)) await this.confirm(`${why}：「${label.slice(0, 60)}」（會送出內容給別人）`);
  }

  // ---------- 動作 ----------
  checkCancel() { if (this.cancel) throw new Error('管理員按了「停止」，請立刻停下來，簡短回報做到哪裡。'); }
  async act(body, label, tap) { this.checkCancel(); const r = await this.call('POST', '/act', body, { timeout: 20000 }); await sleep(+this.cfg().settle_ms || 700); await this.snap(label, tap); return r; }
  async tap({ id, x, y, text, long = false } = {}) {
    let n = null;
    if (id != null) n = this.nodeById(id);
    else if (text) { const s = await this.screen(); const q = String(text).toLowerCase(); const c = (s.nodes || []).filter((k) => (k.click || k.long) && this.labelOf(k).toLowerCase().includes(q)); n = c.find((k) => (k.text || k.desc || '').toLowerCase() === q) || c[0]; if (!n) throw new Error(`畫面上找不到可以點的「${text}」，先 phone_screen 看看實際的文字`); }
    else if (x != null && y != null) { const k = this.scale || 1; x = Math.round(+x * k); y = Math.round(+y * k); if (!this.lastScreen) await this.screen(); n = this.nodeAt(x, y); }   // x,y＝截圖上的座標
    else throw new Error('要給 id、text 或 x,y');
    if (n && n.pwd) { /* 點密碼欄沒關係，但不會幫忙打字 */ }
    await this.guardTap(n || { text: '' }, long ? '長按' : '點擊');
    const [l, t, r, b] = (n && n.b) || [x, y, x, y]; const cx = Math.round((+l + +r) / 2), cy = Math.round((+t + +b) / 2);
    const body = n && id != null ? { type: long ? 'longpress' : 'tap', node: n.id, x: cx, y: cy } : { type: long ? 'longpress' : 'tap', x: n ? cx : +x, y: n ? cy : +y };
    const what = n ? (n.text || n.desc || n.res || '元素') : `座標 ${x},${y}`;
    await this.act(body, `${long ? '長按' : '點擊'}「${String(what).slice(0, 40)}」`, { x: body.x, y: body.y }); return what;
  }
  async type({ id, text, submit = false, clear = true } = {}) {
    let n = id != null ? this.nodeById(id) : ((this.lastScreen && this.lastScreen.nodes) || []).find((k) => k.edit && k.focused) || ((this.lastScreen && this.lastScreen.nodes) || []).find((k) => k.edit);
    if (!n) throw new Error('畫面上沒有輸入框（先點一下輸入框，或 phone_screen 看編號）');
    if (n.pwd) throw new Error('這是密碼欄位：AI 不幫忙輸入密碼。請管理員自己輸入（懸浮面板會提示），或改用 App 內的保險箱流程。');
    if (submit && this.cfg().confirm_send !== false) await this.confirm(`在「${(this.lastScreen && this.lastScreen.label) || ''}」輸入並送出：「${String(text).slice(0, 80)}」`);
    // 打字不算一步（跟瀏覽器一樣，按 Enter／送出才算）
    this.checkCancel(); await this.call('POST', '/act', { type: 'type', node: n.id, text: String(text), clear: clear !== false }, { timeout: 15000 });
    if (submit) { await this.act({ type: 'enter', node: n.id }, '輸入完成並送出'); }
    return n;
  }
  swipe({ direction = 'up', x1, y1, x2, y2, ms = 350 } = {}) {
    const s = this.lastScreen || { w: 1080, h: 2340 }; const W = s.w || 1080, H = s.h || 2340;
    if (x1 == null) { const d = { up: [W / 2, H * 0.72, W / 2, H * 0.28], down: [W / 2, H * 0.3, W / 2, H * 0.74], left: [W * 0.85, H / 2, W * 0.15, H / 2], right: [W * 0.15, H / 2, W * 0.85, H / 2] }[direction]; if (!d) throw new Error('direction 只能是 up／down／left／right'); [x1, y1, x2, y2] = d; }
    return this.act({ type: 'swipe', x1: Math.round(x1), y1: Math.round(y1), x2: Math.round(x2), y2: Math.round(y2), ms: Math.min(3000, Math.max(80, +ms || 350)) }, { up: '往上滑', down: '往下滑', left: '往左滑', right: '往右滑' }[direction] || '滑動');
  }
  key(k) { const map = { back: '返回', home: '回主畫面', recents: '多工畫面', notifications: '通知欄', quick_settings: '快速設定', enter: 'Enter' }; if (!map[k]) throw new Error('key 只能是 back／home／recents／notifications／quick_settings／enter'); return this.act({ type: 'global', key: k }, '按' + map[k]); }
  async apps() { const r = await this.call('GET', '/apps'); return r.apps || []; }
  async openApp(name) {
    const q = String(name || '').trim().toLowerCase(); if (!q) throw new Error('要給 App 名稱'); const list = await this.apps();
    const hit = list.find((a) => a.label.toLowerCase() === q || a.pkg === q) || list.find((a) => a.label.toLowerCase().includes(q)) || list.find((a) => a.pkg.toLowerCase().includes(q));
    if (!hit) throw new Error(`找不到 App「${name}」。已安裝的有：${list.slice(0, 40).map((a) => a.label).join('、')}`);
    if (hit.pkg === 'com.lineagent.app' || /lineagent/.test(hit.pkg)) throw new Error('不能用手機代理操作這個 App 本身');
    await this.act({ type: 'open', pkg: hit.pkg }, `開啟 ${hit.label}`); return hit;
  }
  /** 截圖（Android 11 以上）。圖會縮小，記下縮放比例：AI 用截圖上的座標點擊時換算回螢幕座標 */
  async shot() { const r = await this.call('GET', '/shot', undefined, { timeout: 8000, raw: true }); if (!/jpeg/.test(r.type)) throw new Error('截圖失敗'); const iw = +r.headers['x-img-w'] || 0, sw = +r.headers['x-screen-w'] || 0; if (iw && sw) this.scale = sw / iw; this.shotSize = { w: iw, h: +r.headers['x-img-h'] || 0 }; return r.buf; }
  async waitText(text, sec = 10) { const end = Date.now() + Math.min(30, Math.max(1, +sec || 10)) * 1000; while (Date.now() < end) { this.checkCancel(); const s = await this.screen(); if ((s.nodes || []).some((n) => this.labelOf(n).includes(text))) return true; await sleep(700); } return false; }

  // ---------- 連點器（真正連點的是 Android 端，這裡只下指令）----------
  /** points：[{id}|{x,y}]（x,y＝截圖上的座標）；interval_ms ≥ 40；count 0＝不限（最長 max_s 秒） */
  async autoclick({ points = [], interval_ms = 200, count = 0, max_s = 600 } = {}) {
    if (!Array.isArray(points) || !points.length) throw new Error('至少要一個點'); if (points.length > 10) throw new Error('最多 10 個點');
    if (!this.lastScreen) await this.screen(); const k = this.scale || 1; const xy = [];
    for (const p of points) {
      let n = null, x, y; if (p.id != null) { n = this.nodeById(p.id); x = Math.round((n.b[0] + n.b[2]) / 2); y = Math.round((n.b[1] + n.b[3]) / 2); } else { x = Math.round(+p.x * k); y = Math.round(+p.y * k); n = this.nodeAt(x, y); }
      if (!Number.isFinite(x) || !Number.isFinite(y)) throw new Error('座標不正確'); await this.guardTap(n || { text: '' }, '連點'); xy.push([x, y]);
    }
    this.checkCancel(); const r = await this.call('POST', '/clicker', { action: 'start', points: xy, interval_ms: Math.max(40, +interval_ms || 200), count: Math.max(0, Math.floor(+count || 0)), max_s: Math.min(3600, Math.max(1, +max_s || 600)) });
    await this.snap(`開始連點 ${xy.length} 個點，每 ${Math.max(40, +interval_ms || 200)} 毫秒${+count ? `，共 ${+count} 下` : ''}`, { x: xy[0][0], y: xy[0][1] }); return r;
  }
  clickerStop() { return this.call('POST', '/clicker', { action: 'stop' }); }

  // ---------- 26.11.3 pro10 巨集（固定的一串點擊／滑動／等待，可重複；不看畫面、不花 token）----------
  /** 文字格式一行一步：tap 540 1200｜long 540 1200｜swipe up｜swipe 100 800 900 800 300｜wait 500｜key back。x,y 是「螢幕」座標。 */
  parseMacro(src) {
    const steps = Array.isArray(src) ? src : String(src || '').split(/\n|;/).map((l) => l.replace(/(#|\/\/).*$/, '').trim()).filter(Boolean).map((l) => {
      const p = l.split(/[\s,]+/); const k = p[0].toLowerCase(); const n = p.slice(1).map(Number);
      if (k === 'tap' || k === 'long') { if (n.length < 2 || n.some((v) => !Number.isFinite(v))) throw new Error(`「${l}」：tap 要兩個數字（x y）`); return { type: k === 'long' ? 'longpress' : 'tap', x: n[0], y: n[1] }; }
      if (k === 'swipe') { if (/^(up|down|left|right)$/.test(p[1] || '')) return { type: 'swipe', direction: p[1], ms: +p[2] || 350 }; if (n.length < 4 || n.slice(0, 4).some((v) => !Number.isFinite(v))) throw new Error(`「${l}」：swipe 要方向（up／down／left／right）或四個數字（x1 y1 x2 y2）`); return { type: 'swipe', x1: n[0], y1: n[1], x2: n[2], y2: n[3], ms: n[4] || 350 }; }
      if (k === 'wait') { if (!(n[0] >= 0)) throw new Error(`「${l}」：wait 要毫秒數`); return { type: 'wait', ms: n[0] }; }
      if (k === 'key') return { type: 'key', key: p[1] };
      throw new Error(`看不懂「${l}」：每行是 tap x y｜long x y｜swipe 方向｜swipe x1 y1 x2 y2｜wait 毫秒｜key back`);
    });
    if (!steps.length) throw new Error('巨集是空的'); if (steps.length > 200) throw new Error('巨集最多 200 步');
    for (const s of steps) { if (s.type === 'wait') s.ms = Math.max(0, Math.min(60000, Math.round(+s.ms || 0))); if (s.type === 'key' && !['back', 'home', 'recents', 'enter'].includes(s.key)) throw new Error('key 只能是 back／home／recents／enter'); if (!['tap', 'longpress', 'swipe', 'wait', 'key'].includes(s.type)) throw new Error('步驟種類不對'); }
    return steps;
  }
  macros() { const d = this.ctx.store.db; if (!d.phone_macros || typeof d.phone_macros !== 'object') d.phone_macros = {}; return d.phone_macros; }
  macroSave(name, src) { const n = String(name || '').trim().slice(0, 30); if (!n) throw new Error('要給名稱'); const steps = this.parseMacro(src); const m = this.macros(); if (!m[n] && Object.keys(m).length >= 30) throw new Error('最多存 30 組巨集'); m[n] = { steps, ts: Date.now() }; this.ctx.store.touch(); return { name: n, steps: steps.length }; }
  macroDelete(name) { const m = this.macros(); if (!m[name]) throw new Error('沒有這組巨集'); delete m[name]; this.ctx.store.touch(); return { ok: true }; }
  macroState() { return this.macroRun ? { running: true, ...this.macroRun, elapsed_s: Math.round((Date.now() - this.macroRun.since) / 1000) } : { running: false, last: this.macroLast || null }; }
  macroStop() { if (this.macroRun) this.macroRun.stop = true; return { ok: true }; }
  /** 執行巨集（背景跑）。每一個點擊位置都先過「危險按鈕」檢查（付款、刪除…會跳確認），只在開始前檢查一次。 */
  async macroStart({ name, steps, repeat = 1, gap_ms = 300, max_s = 1800 } = {}) {
    if (this.macroRun) throw new Error('已經有巨集在跑，先停止'); const list = name ? ((this.macros()[name] || {}).steps) : this.parseMacro(steps); if (!list) throw new Error(`沒有巨集「${name}」`);
    const rep = Math.max(1, Math.min(100000, Math.floor(+repeat || 1))); const gap = Math.max(60, Math.min(10000, Math.round(+gap_ms || 300))); const limit = Math.max(1, Math.min(7200, +max_s || 1800)) * 1000;
    await this.screen(); for (const s of list) if (s.type === 'tap' || s.type === 'longpress') await this.guardTap(this.nodeAt(s.x, s.y) || { text: '' }, '巨集點擊');
    const st = this.macroRun = { name: name || '', steps: list.length, repeat: rep, round: 0, done: 0, since: Date.now(), stop: false };
    const W = (this.lastScreen && this.lastScreen.w) || 1080, H = (this.lastScreen && this.lastScreen.h) || 2340;
    const body = (s) => { if (s.type === 'swipe' && s.x1 == null) { const d = { up: [W / 2, H * 0.72, W / 2, H * 0.28], down: [W / 2, H * 0.3, W / 2, H * 0.74], left: [W * 0.85, H / 2, W * 0.15, H / 2], right: [W * 0.15, H / 2, W * 0.85, H / 2] }[s.direction]; return { type: 'swipe', x1: Math.round(d[0]), y1: Math.round(d[1]), x2: Math.round(d[2]), y2: Math.round(d[3]), ms: s.ms || 350 }; } if (s.type === 'key') return { type: s.key === 'enter' ? 'enter' : 'global', key: s.key }; return { ...s }; };
    await this.snap(`開始巨集${name ? '「' + name + '」' : ''}：${list.length} 步 × ${rep} 次`);
    (async () => {
      let err = '';
      try { outer: for (let r = 0; r < rep; r++) { st.round = r + 1; for (const s of list) { if (st.stop || this.cancel) break outer; if (Date.now() - st.since > limit) { err = '到達時間上限'; break outer; } if (s.type === 'wait') { await sleep(s.ms); continue; } await this.call('POST', '/act', body(s), { timeout: 20000 }); st.done++; await sleep(gap); } } }
      catch (e) { err = e.message; }
      this.macroLast = { name: st.name, done: st.done, rounds: st.round, stopped: st.stop || this.cancel, error: err, at: Date.now() }; this.macroRun = null;
      try { await this.snap(`巨集結束：做了 ${st.done} 個動作${err ? '（' + err + '）' : ''}`); } catch { /* ignore */ } this.ev.emit('macro', this.macroLast);
    })();
    return { ok: true, steps: list.length, repeat: rep };
  }
  clickerState() { return this.call('GET', '/clicker'); }

  // ---------- 每一步截圖（只放記憶體，過期自動刪）----------
  async snap(label, tap) {
    let jpeg = null; let s = null; try { jpeg = await this.shot(); } catch { /* Android 10 以下或受保護畫面：只記文字 */ }
    try { s = await this.screen(); } catch { /* ignore */ }
    const st = { seq: ++this.seq, ts: Date.now(), label: String(label).slice(0, 120), pkg: s ? (s.label || s.pkg) : '', w: s ? s.w : 0, h: s ? s.h : 0, tap: tap || null, by: 'ai', jpeg };
    this.steps.push(st); while (this.steps.length > 60) this.steps.shift(); if (this.task) this.task.doing = st.label; this.ev.emit('step', this.meta(st)); return st;
  }
  sweep() { const ttl = (+this.cfg().step_ttl_min || 30) * 60000; const before = this.steps.length; this.steps = this.steps.filter((x) => Date.now() - x.ts < ttl); return before - this.steps.length; }

  // ---------- 懸浮面板下指令 ----------
  /** game=true：遊戲協助模式（看截圖、點座標、重複動作用巨集／連點器；付費一律停下來問） */
  async runTask(text, { game = false } = {}) {
    const t = String(text || '').trim(); if (!t) throw new Error('請說要做什麼'); if (this.task) throw new Error('上一個指令還在做，先按「停止」或等它完成');
    this.cancel = false; this.task = { text: t.slice(0, 500), since: Date.now(), doing: '思考中' }; this.history.push({ ts: Date.now(), text: this.task.text, reply: '' });
    const h = this.history[this.history.length - 1];
    (async () => {
      try { const r = await this.ctx.api.invoke('POST', '/api/chat', { text: (game ? GAME : '【手機懸浮面板指令：請用 phone_* 工具操作手機上的 App 完成；先 phone_screen 看目前畫面】') + t }); h.reply = String((r && r.text) || '').slice(0, 1000); }
      catch (e) { h.reply = '發生問題：' + e.message; }
      finally { this.task = null; this.cancel = false; this.ev.emit('done', h); }
    })();
    return { ok: true };
  }
  stop() { this.cancel = true; if (this.macroRun) this.macroRun.stop = true; if (this.pending) this.pending.done('deny'); return { ok: true }; }
}
module.exports = { PhoneAgent, RISKY, SEND };
