'use strict';
/**
 * 監控哨兵：定時檢查網頁／API，條件成立就推播給設定的人。
 *   取值方式 extract：text（整頁文字）、regex（第一個括號或整段比對）、json（a.b[0].c 路徑）
 *   條件 cond：changed（內容變了）、contains／missing（出現／消失關鍵字）、lt／gt（數字低於／高於）
 * 「條件成立」只在由不成立 → 成立的那一刻通知一次（邊緣觸發），不會每次檢查都吵；changed 則是每次變動都通知。
 */
const crypto = require('crypto');
const web = require('./web');
const { logger } = require('../core/log');
const { clip } = require('../core/util');
const log = logger('watch');

const UA = 'Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/124 Mobile Safari/537.36';
const CONDS = ['changed', 'contains', 'missing', 'lt', 'gt'];
const EXTRACT = ['text', 'regex', 'json'];
const MAX = 50;

function jsonPath(o, p) {
  for (const k of String(p || '').replace(/\[(\d+)\]/g, '.$1').split('.').filter(Boolean)) { if (o == null) return undefined; o = o[k]; }
  return o;
}
function toNum(v) { if (typeof v === 'number') return v; const m = /-?\d[\d,]*(?:\.\d+)?/.exec(String(v ?? '')); return m ? Number(m[0].replace(/,/g, '')) : NaN; }

class Watch {
  constructor(ctx) { this.ctx = ctx; this.running = new Set(); }
  get list() { const db = this.ctx.store.db; if (!Array.isArray(db.watches)) db.watches = []; return db.watches; }
  all() { return this.list.map((w) => ({ ...w })); }
  get(id) { return this.list.find((w) => w.id === +id); }
  add(o, pid) {
    const url = String(o.url || '').trim(); const b = web.blocked(url); if (b) throw new Error(b);
    const cond = CONDS.includes(o.cond) ? o.cond : 'changed'; const extract = EXTRACT.includes(o.extract) ? o.extract : (o.path ? 'json' : o.pattern ? 'regex' : 'text');
    if ((cond === 'lt' || cond === 'gt') && !Number.isFinite(toNum(o.value))) throw new Error('lt／gt 條件要給數字門檻 value');
    if ((cond === 'contains' || cond === 'missing') && !String(o.value || '').trim()) throw new Error('contains／missing 條件要給關鍵字 value');
    if (extract === 'regex') { try { new RegExp(o.pattern); } catch (e) { throw new Error('regex 格式錯誤：' + e.message); } }
    if (this.list.length >= MAX) throw new Error(`最多 ${MAX} 個哨兵，請先刪掉不用的`);
    const w = { id: this.ctx.store.nextId('watch'), name: clip(String(o.name || url), 60), url, extract, pattern: extract === 'regex' ? String(o.pattern) : '', path: extract === 'json' ? String(o.path || '') : '',
      cond, value: cond === 'lt' || cond === 'gt' ? toNum(o.value) : String(o.value || ''), every_min: Math.max(5, Math.min(+o.every_min || 30, 1440)), once: !!o.once, enabled: true, pid: pid || '',
      created: Date.now(), last_at: 0, last_value: '', last_hash: '', last_ok: null, last_error: '', active: false, fired: 0, fired_at: 0 };
    this.list.push(w); this.ctx.store.touch(); return w;
  }
  update(id, patch) {
    const w = this.get(id); if (!w) throw new Error('找不到這個哨兵');
    for (const k of ['name', 'enabled', 'every_min', 'once', 'value']) if (patch[k] !== undefined) w[k] = k === 'every_min' ? Math.max(5, Math.min(+patch[k] || 30, 1440)) : k === 'enabled' || k === 'once' ? !!patch[k] : k === 'value' && (w.cond === 'lt' || w.cond === 'gt') ? toNum(patch[k]) : patch[k];
    this.ctx.store.touch(); return w;
  }
  remove(id) { const i = this.list.findIndex((w) => w.id === +id); if (i < 0) throw new Error('找不到這個哨兵'); this.list.splice(i, 1); this.ctx.store.touch(); return true; }

  /** 取值（不判斷條件） */
  async read(w) {
    const b = web.blocked(w.url); if (b) throw new Error(b);
    const r = await fetch(w.url, { headers: { 'user-agent': UA, 'accept-language': 'zh-TW,zh;q=0.9' }, redirect: 'follow', signal: AbortSignal.timeout(25000) });
    if (!r.ok) throw new Error(`HTTP ${r.status}`); const raw = await r.text();
    if (w.extract === 'json') { let j; try { j = JSON.parse(raw); } catch { throw new Error('回應不是 JSON'); } const v = jsonPath(j, w.path); if (v === undefined) throw new Error(`JSON 裡找不到 ${w.path}`); return typeof v === 'object' ? JSON.stringify(v) : String(v); }
    const text = /<html|<body|<div/i.test(raw.slice(0, 2000)) ? web.htmlToText(raw) : raw;
    if (w.extract === 'regex') { const m = new RegExp(w.pattern, 'i').exec(text); if (!m) return ''; return String(m[1] !== undefined ? m[1] : m[0]).trim(); }
    return clip(text, 20000);
  }
  /** 檢查一個哨兵；回傳 {fired, value, message} */
  async check(w, { notify = true } = {}) {
    if (this.running.has(w.id)) return { fired: false, skipped: true }; this.running.add(w.id);
    try {
      let value; try { value = await this.read(w); } catch (e) { w.last_at = Date.now(); w.last_ok = false; w.last_error = clip(e.message, 200); this.ctx.store.touch(); return { fired: false, error: e.message }; }
      const hash = crypto.createHash('sha1').update(value).digest('hex'); const first = !w.last_hash;
      let hit = false; let why = '';
      if (w.cond === 'changed') { hit = !first && hash !== w.last_hash; why = '內容有變動'; }
      else if (w.cond === 'contains') { hit = value.toLowerCase().includes(String(w.value).toLowerCase()); why = `出現「${w.value}」`; }
      else if (w.cond === 'missing') { hit = !value.toLowerCase().includes(String(w.value).toLowerCase()); why = `「${w.value}」不見了`; }
      else { const n = toNum(value); hit = Number.isFinite(n) && (w.cond === 'lt' ? n < w.value : n > w.value); why = `數值 ${Number.isFinite(n) ? n : '（讀不到數字）'} ${w.cond === 'lt' ? '低於' : '高於'} ${w.value}`; }
      const fire = w.cond === 'changed' ? hit : hit && !w.active;   // 狀態型條件：只在「剛成立」時通知
      const prev = w.last_value;
      Object.assign(w, { last_at: Date.now(), last_ok: true, last_error: '', last_hash: hash, last_value: clip(value, 300), active: w.cond === 'changed' ? false : hit });
      let message = '';
      if (fire) {
        w.fired++; w.fired_at = Date.now(); if (w.once) w.enabled = false;
        message = `🔔 哨兵「${w.name}」：${why}\n${w.cond === 'changed' && prev ? `之前：${clip(prev, 120)}\n現在：${clip(value, 160)}` : `目前：${clip(value, 200)}`}\n${w.url}${w.once ? '\n（單次哨兵，已自動停用）' : ''}`;
        if (notify) await this.notify(w, message);
      }
      this.ctx.store.touch(); return { fired: fire, value: clip(value, 300), message };
    } finally { this.running.delete(w.id); }
  }
  async notify(w, message) {
    const p = w.pid && this.ctx.users.byId(w.pid);
    let sent = false; if (p) { try { await this.ctx.hub.sendToPerson(p, message); sent = true; } catch (e) { log.warn('哨兵通知送不出去：' + e.message); } }
    await this.ctx.notifier.push(sent ? 'info' : 'warn', `哨兵：${w.name}`, message, { force: !sent }).catch(() => {});
  }
  /** 排程器每輪呼叫：到期的才檢查；一輪最多 5 個，避免手機一次發太多請求 */
  async tick() {
    const now = Date.now(); const due = this.list.filter((w) => w.enabled && now - (w.last_at || 0) >= w.every_min * 60e3).slice(0, 5);
    for (const w of due) { try { await this.check(w); } catch (e) { log.error(`哨兵 #${w.id} 失敗：${e.message}`); } }
    return due.length;
  }
  firedSince(ts) { return this.list.filter((w) => w.fired_at && w.fired_at >= ts); }
}
module.exports = { Watch, jsonPath, toNum };
