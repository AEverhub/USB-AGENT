'use strict';
/**
 * 26.11.3 pro7：程式碼工具的共用狀態（App 頁面和 AI 操作同一份）。存在 store.db.code_state。
 * { files:[{name, lang, code}], cur:0, out:{text, code, lang, name, at, where}, ts, by }
 * 執行：
 *  ・JavaScript 在 App 畫面裡用 Web Worker 跑（跟 App 資料隔開、5 秒逾時），不經過主機
 *  ・其他語言（Python、C、C++、Bash、Go、Java、Rust、PHP、Ruby、Lua，或 JS 用 Node）送到 App 內建 Linux／Termux 執行（要先裝好環境；權限跟 termux_exec 一樣）
 */
const path = require('path');
const { clip } = require('../core/util');

const LANGS = {
  javascript: { name: 'JavaScript', ext: 'js', run: (f) => `node ${f}`, need: 'node', pkg: 'nodejs' },
  python: { name: 'Python', ext: 'py', run: (f) => `python3 ${f}`, need: 'python3', pkg: 'python3（Termux：pkg install python）' },
  c: { name: 'C', ext: 'c', run: (f) => `CC=$(command -v clang || command -v gcc || command -v cc) && $CC -O2 -o main ${f} -lm && ./main`, need: 'clang gcc cc', pkg: 'build-base（Termux：pkg install clang）' },
  cpp: { name: 'C++', ext: 'cpp', run: (f) => `CXX=$(command -v clang++ || command -v g++) && $CXX -O2 -std=c++17 -o main ${f} && ./main`, need: 'clang++ g++', pkg: 'build-base（Termux：pkg install clang）' },
  bash: { name: 'Bash', ext: 'sh', run: (f) => `bash ${f} 2>&1 || sh ${f}`, need: 'sh', pkg: '' },
  go: { name: 'Go', ext: 'go', run: (f) => `go run ${f}`, need: 'go', pkg: 'go（Termux：pkg install golang）' },
  java: { name: 'Java', ext: 'java', run: (f) => `java ${f}`, need: 'java', pkg: 'openjdk17（Termux：pkg install openjdk-17）' },
  rust: { name: 'Rust', ext: 'rs', run: (f) => `rustc -O -o main ${f} && ./main`, need: 'rustc', pkg: 'rust' },
  php: { name: 'PHP', ext: 'php', run: (f) => `php ${f}`, need: 'php', pkg: 'php' },
  ruby: { name: 'Ruby', ext: 'rb', run: (f) => `ruby ${f}`, need: 'ruby', pkg: 'ruby' },
  lua: { name: 'Lua', ext: 'lua', run: (f) => `lua ${f} 2>/dev/null || lua5.4 ${f}`, need: 'lua lua5.4', pkg: 'lua5.4' },
  html: { name: 'HTML', ext: 'html', run: null }, css: { name: 'CSS', ext: 'css', run: null }, json: { name: 'JSON', ext: 'json', run: null }, sql: { name: 'SQL', ext: 'sql', run: null }, text: { name: '純文字', ext: 'txt', run: null },
};
const ALIAS = { js: 'javascript', node: 'javascript', py: 'python', python3: 'python', 'c++': 'cpp', cxx: 'cpp', cc: 'cpp', sh: 'bash', shell: 'bash', golang: 'go', rs: 'rust', rb: 'ruby', txt: 'text', htm: 'html' };
const lang = (l) => { const k = String(l || '').toLowerCase().trim(); return LANGS[k] ? k : ALIAS[k] || null; };
const byExt = (name) => { const e = String(name || '').split('.').pop().toLowerCase(); return Object.keys(LANGS).find((k) => LANGS[k].ext === e) || ALIAS[e] || null; };
const MAXF = 10, MAXC = 200 * 1024;
const SAMPLE = { name: 'main.py', lang: 'python', code: '# 範例：費氏數列\ndef fib(n):\n    a, b = 0, 1\n    for _ in range(n):\n        a, b = b, a + b\n    return a\n\nfor i in range(10):\n    print(i, fib(i))\n' };
const safeName = (n, l) => { let s = String(n || '').replace(/[\\/:*?"<>|\0]/g, '').replace(/^\.+/, '').trim().slice(0, 60); if (!s) s = 'main.' + LANGS[l || 'text'].ext; return s; };

class CodeState {
  constructor(ctx) { this.ctx = ctx; }
  get() { const s = this.ctx.store.db.code_state; return s && Array.isArray(s.files) && s.files.length ? { cur: 0, out: null, ...s } : { files: [{ ...SAMPLE }], cur: 0, out: null, ts: 0 }; }
  clean(s) {
    if (!s || !Array.isArray(s.files) || !s.files.length) throw new Error('至少要一個檔案');
    if (s.files.length > MAXF) throw new Error(`最多 ${MAXF} 個檔案`);
    const names = new Set(); const files = s.files.map((f) => { const l = lang(f.lang) || byExt(f.name) || 'text'; const name = safeName(f.name, l); if (names.has(name.toLowerCase())) throw new Error('檔名重複：' + name); names.add(name.toLowerCase()); const code = String(f.code ?? ''); if (Buffer.byteLength(code) > MAXC) throw new Error(`${name} 超過 200KB`); return { name, lang: l, code }; });
    const out = s.out && typeof s.out === 'object' ? { text: clip(String(s.out.text || ''), 20000), code: s.out.code ?? null, lang: String(s.out.lang || ''), name: String(s.out.name || ''), at: +s.out.at || Date.now(), where: String(s.out.where || '') } : null;
    return { files, cur: Math.max(0, Math.min(files.length - 1, +s.cur || 0)), out };
  }
  put(s, who = 'app') { const out = { ...this.clean(s), ts: Date.now(), by: who }; this.ctx.store.db.code_state = out; this.ctx.store.touch(); return out; }
  file(st, name) { if (name == null || name === '') return st.files[st.cur] || st.files[0]; const f = st.files.find((x) => x.name.toLowerCase() === String(name).toLowerCase()); if (!f) throw new Error(`沒有 ${name}（有：${st.files.map((x) => x.name).join('、')}）`); return f; }
  /** 給 AI 看的：每個檔案（加行號）＋上次執行結果 */
  describe(st = this.get(), { name, full = true } = {}) {
    const L = [`程式碼工具：${st.files.length} 個檔案（目前打開 ${st.files[st.cur].name}）`];
    const show = name ? [this.file(st, name)] : full ? st.files : [st.files[st.cur]];
    for (const f of show) { const lines = f.code.split('\n'); L.push('', `── ${f.name}（${LANGS[f.lang].name}，${lines.length} 行）──`, ...clip(lines.map((l, i) => `${String(i + 1).padStart(3)}| ${l}`).join('\n'), 30000).split('\n')); }
    if (st.out) L.push('', `上次執行（${st.out.name}，${st.out.where || ''}，結束碼 ${st.out.code ?? '?'}）：`, clip(st.out.text || '(沒有輸出)', 4000));
    return L.join('\n');
  }
  /** AI 操作：file（檔名，沒有就新增）、lang、code（整個換掉）、replace（[{find, with}] 局部取代，find 要剛好出現一次）、insert（{line, text}）、open、rename、remove、reset */
  apply(op = {}) {
    let st = JSON.parse(JSON.stringify(this.get()));
    if (op.reset) st = { files: [{ ...SAMPLE }], cur: 0, out: null };
    if (op.remove) { const f = this.file(st, op.remove); if (st.files.length === 1) throw new Error('至少要留一個檔案'); st.files = st.files.filter((x) => x !== f); st.cur = 0; }
    let f = null;
    if (op.file || op.code != null || op.replace || op.insert || op.lang || op.rename) {
      const nm = op.file ? String(op.file) : null; f = nm ? st.files.find((x) => x.name.toLowerCase() === nm.toLowerCase()) : st.files[st.cur];
      if (!f) { if (st.files.length >= MAXF) throw new Error(`最多 ${MAXF} 個檔案`); const l = lang(op.lang) || byExt(nm) || 'text'; f = { name: safeName(nm, l), lang: l, code: '' }; st.files.push(f); }
      st.cur = st.files.indexOf(f);
      if (op.lang) { const l = lang(op.lang); if (!l) throw new Error('語言：' + Object.keys(LANGS).join('、')); f.lang = l; }
      if (op.rename) { const n = safeName(op.rename, f.lang); if (st.files.some((x) => x !== f && x.name.toLowerCase() === n.toLowerCase())) throw new Error('檔名重複'); f.name = n; const l = byExt(n); if (l && !op.lang) f.lang = l; }
      if (op.code != null) f.code = String(op.code);
      for (const r of [].concat(op.replace || [])) { const a = String(r.find ?? ''); if (!a) throw new Error('replace 要有 find'); const n = f.code.split(a).length - 1; if (n !== 1) throw new Error(`「${clip(a, 40)}」在 ${f.name} 出現 ${n} 次（要剛好 1 次；多給一點前後文）`); f.code = f.code.replace(a, () => String(r.with ?? '')); }
      if (op.insert) { const lines = f.code.split('\n'); const at = Math.max(0, Math.min(lines.length, Math.floor(op.insert.line != null && op.insert.line !== '' ? +op.insert.line : lines.length))); lines.splice(at, 0, ...String(op.insert.text ?? '').split('\n')); f.code = lines.join('\n'); }
    } else if (op.open) { const g = this.file(st, op.open); st.cur = st.files.indexOf(g); }
    return this.put(st, 'ai');
  }
  /** 送到內建 Linux／Termux 執行。stdin 選填；逾時預設 30 秒 */
  async run({ name, lang: l0, code, stdin = '', timeout_s = 30, save = true } = {}) {
    const st = this.get(); const f = code != null ? { name: safeName(name || 'main', lang(l0) || 'text'), lang: lang(l0) || byExt(name) || 'text', code: String(code) } : this.file(st, name);
    const L = LANGS[f.lang]; if (!L || !L.run) throw new Error(`${L ? L.name : f.lang} 不是可以直接執行的語言${f.lang === 'html' ? '（HTML 用「預覽」）' : ''}`);
    const T = this.ctx.termux; if (!T || !T.ready || !T.ready()) throw new Error('執行 ' + L.name + ' 需要 App 內建 Linux 或 Termux：到「瀏覽器」頁的「內建 Linux」卡片安裝（JavaScript 可以直接在 App 畫面裡執行，不需要 Linux）');
    if (Buffer.byteLength(f.code) > MAXC) throw new Error('程式太大（超過 200KB）');
    const file = /^[\w.-]+$/.test(f.name) && f.name.endsWith('.' + L.ext) ? f.name : (f.lang === 'java' ? 'Main.java' : 'main.' + L.ext);
    const dir = `$HOME/.la-code/${Date.now().toString(36)}`; const b64 = Buffer.from(f.code, 'utf8').toString('base64'); const inb = Buffer.from(String(stdin || ''), 'utf8').toString('base64');
    const cmd = `mkdir -p ${dir} && cd ${dir} && echo '${b64}' | base64 -d > ${file} && echo '${inb}' | base64 -d > .stdin && ( ${L.run(file)} ) < .stdin 2>&1; c=$?; cd / && rm -rf ${dir}; exit $c`;
    const t = Math.max(3, Math.min(120, +timeout_s || 30)); const r = await T.exec(cmd, { timeout_s: t });
    let text = String(r.out ?? '').replace(/\s+$/, ''); if (/command not found|not found: (python3|node|go|java|rustc|php|ruby|lua)|clang: not found|CC=$|: No such file or directory$/m.test(text) && r.code === 127) text += `\n\n（Linux 裡還沒有 ${L.name} 的執行環境：用 termux_exec 安裝 ${L.pkg || L.need}）`;
    const out = { text: clip(text || '(沒有輸出)', 20000), code: r.code ?? null, lang: f.lang, name: f.name, at: Date.now(), where: 'Linux', timedOut: !!r.timedOut };
    if (save) { const cur = this.get(); this.ctx.store.db.code_state = { ...cur, out, ts: Date.now() }; this.ctx.store.touch(); }
    this.ctx.store.audit('code', 'run', `${f.name}（${L.name}）`);
    return out;
  }
  /** 存到工作區 code/ 資料夾（AI 的檔案工具也看得到） */
  save({ name, dir = 'code' } = {}) {
    const st = this.get(); const list = name ? [this.file(st, name)] : st.files; const d = String(dir || 'code').replace(/\.\.+/g, '').replace(/^[/\\]+/, '') || 'code'; const saved = [];
    for (const f of list) { const rel = path.posix.join(d, f.name); this.ctx.fsx.write(rel, f.code, 'workspace', 'code-tool'); saved.push(rel); }
    return { saved, text: '已存到工作區：' + saved.join('、') };
  }
}
module.exports = { CodeState, LANGS, lang, byExt };
