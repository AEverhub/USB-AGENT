'use strict';
/** 遠端除錯（瓶頸 3）：① /api/debug/* 即時狀態與 AI 執行追蹤；② 可選 Node Inspector（Chrome DevTools / VS Code 連線）；③ 可選 eval（預設關閉，只有人類能開）。 */
const v8 = require('v8');
const { logger, ring } = require('../core/log');
const log = logger('debug');

class Debug {
  constructor(ctx) { this.ctx = ctx; this.traces = []; this.inspectorOpen = false; this.errors = []; }
  /** agent 每次執行結束時記錄：輸入、工具呼叫（參數/結果/耗時）、錯誤 */
  /** 每次回覆送到 LINE／Discord／TG 花多久（送出本身 vs 從收到訊息到送達） */
  delivery(d) { (this.deliveries = this.deliveries || []).push(d); if (this.deliveries.length > 40) this.deliveries.shift(); }
  trace(t) { this.traces.push({ ts: Date.now(), ...t }); if (this.traces.length > 60) this.traces.shift(); }
  recordError(where, e) { this.errors.push({ ts: Date.now(), where, message: e && e.message ? e.message : String(e), stack: e && e.stack ? String(e.stack).split('\n').slice(0, 6).join('\n') : '' }); if (this.errors.length > 100) this.errors.shift(); }
  /**
   * 26.11.3 錯誤代碼：同一種錯誤永遠得到同一個代碼（E-區域-4碼），方便複製給開發者／AI 查。
   * 代碼由「區域＋去掉數字與編號後的訊息」算出，所以時間、ID 不同的同類錯誤會合併。
   */
  static code(where, message) {
    const area = String(where || 'APP').replace(/^tool:/, 'T-').replace(/[^\w-]/g, '').toUpperCase().slice(0, 14) || 'APP';
    const norm = String(message || '').replace(/https?:\/\/\S+/g, 'URL').replace(/[0-9a-f]{8,}/gi, 'H').replace(/\d+/g, 'N').slice(0, 160);
    return `E-${area}-${require('crypto').createHash('sha1').update(area + '|' + norm).digest('hex').slice(0, 4).toUpperCase()}`;
  }
  /** 把各處的問題整理成一份清單（同代碼合併、附次數），給開發者頁顯示與複製 */
  issues() {
    const c = this.ctx; const map = new Map(); const add = (where, message, ts, detail = '') => { if (!message) return; const code = Debug.code(where, message); const x = map.get(code) || { code, where, message: redact(message), count: 0, first: ts, last: ts, detail: redact(detail) }; x.count++; x.last = Math.max(x.last, ts); x.first = Math.min(x.first, ts); map.set(code, x); };
    for (const e of this.errors) add(e.where, e.message, e.ts, e.stack);
    try { for (const b of require('../app').BOOT_ERRORS || []) add('boot-' + b.name, b.message, this.ctx.startedAt || Date.now(), b.stack); } catch { /* ignore */ }
    try { for (const s of c.supervisor.status().services) if (s.error && s.state !== 'running') add('svc-' + s.name, s.error, s.since || Date.now()); } catch { /* ignore */ }
    try { const d = c.hub && c.hub.connectors.discord; if (d && d.fatal) add('discord', d.fatal, Date.now()); } catch { /* ignore */ }
    try { const j = c.linux && c.linux.job; if (j && j.ok === false && j.error) add('linux', j.error, j.at || Date.now()); } catch { /* ignore */ }
    for (const l of ring.slice(-300)) { const m = /^(\S+) \[(error|warn)\] ([\w-]+): (.*)$/.exec(l); if (m && m[2] === 'error') add(m[3], m[4].split('\n')[0], Date.parse(m[1]) || Date.now()); }
    return [...map.values()].sort((a, b) => b.last - a.last).slice(0, 60);
  }
  /** 26.11.3 Revise4：回覆速度分析（最近 20 次）：總時間、模型時間、工具時間、回合數，找出慢在哪 */
  speed() {
    const t = this.traces.slice(-20).filter((x) => x.ms); if (!t.length) return null; const avg = (f) => Math.round(t.reduce((s, x) => s + (f(x) || 0), 0) / t.length);
    const tool = (x) => (x.calls || []).reduce((s, c) => s + (c.ms || 0), 0); const slowTools = {}; for (const x of t) for (const c of x.calls || []) if (c.ms > 3000) slowTools[c.name] = Math.max(slowTools[c.name] || 0, c.ms);
    const r = { turns: t.length, avg_ms: avg((x) => x.ms), llm_ms: avg((x) => x.llm_ms), tool_ms: avg(tool), rounds: +(t.reduce((s, x) => s + (x.rounds || 0), 0) / t.length).toFixed(1), tokens_in: avg((x) => x.tokens && x.tokens.in), slow_tools: Object.entries(slowTools).sort((a, b) => b[1] - a[1]).slice(0, 4).map(([n, ms]) => `${n} ${Math.round(ms / 1000)}s`) };
    const llmPerRound = r.rounds ? r.llm_ms / r.rounds : 0;
    r.hint = r.avg_ms < 6000 ? '速度正常' : llmPerRound > 8000 ? '模型本身回得慢（每回合超過 8 秒）：可以到「模型與金鑰」換成 flash／mini 類較快的模型，或把思考量設成「關」' : r.tool_ms > r.llm_ms ? `主要慢在工具：${r.slow_tools.join('、') || '（工具）'}` : r.rounds > 4 ? '每次要來回很多回合：問題可能太複雜，或工具一直失敗重試' : r.tokens_in > 30000 ? '送給模型的內容太長（對話歷史、工具說明），可以減少「對話歷史則數」' : '主要時間在模型回應';
    return r;
  }
  /** 一鍵複製的偵錯報告（純文字、機密已遮蔽） */
  report() {
    const s = this.state(); const iss = this.issues(); const t = (ts) => new Date(ts).toLocaleString('zh-TW', { hour12: false, timeZone: this.ctx.settings.get('tz') || 'Asia/Taipei' });
    const lines = [`Agent中控中心 偵錯報告 ${t(Date.now())}`, `版本 ${s.version}｜Node ${s.node}｜${s.platform}/${s.arch}｜已運行 ${s.uptime_s}s｜記憶體 ${s.rss_mb}MB｜事件迴圈延遲 ${s.event_loop_lag_ms}ms`,
      '', '【服務】', ...s.supervisor.services.map((x) => `- ${x.name}: ${x.state}${x.error ? '｜' + redact(x.error) : ''}${x.restarts ? `｜重啟 ${x.restarts} 次` : ''}`),
      '', `【問題】${iss.length ? '' : '沒有'}`, ...iss.map((x) => `- ${x.code}｜${x.where}｜×${x.count}｜最後 ${t(x.last)}\n  ${x.message}`),
      '', '【回覆速度】', ...(() => { const sp = this.speed(); return sp ? [`最近 ${sp.turns} 次平均 ${(sp.avg_ms / 1000).toFixed(1)} 秒（模型 ${(sp.llm_ms / 1000).toFixed(1)}s、工具 ${(sp.tool_ms / 1000).toFixed(1)}s、平均 ${sp.rounds} 回合、輸入 ${sp.tokens_in} tokens）`, '判斷：' + sp.hint] : ['還沒有資料']; })(),
      '', '【慢操作】', ...(s.slow_ops || []).slice(-8).map((x) => `- ${x.label} ${x.ms}ms ${x.extra || ''}`),
      '', '【送達時間】', ...(s.deliveries || []).slice(-8).map((x) => `- ${x.platform} 送出 ${x.send_ms}ms／總共 ${x.total_ms}ms`),
      '', '【最近日誌】', ...s.recent_log.slice(-30).map(redact)];
    return lines.join('\n');
  }
  /**
   * 26.11.3 pro10 運行記錄（給開發者下載）：摘要＋錯誤記錄＋執行記錄（AI 每次執行的工具呼叫、耗時、token）＋系統日誌＋操作稽核。
   * 所有內容都先遮蔽金鑰／token／密碼；對話輸入只留開頭 120 字。
   */
  exportLog({ logLines = 3000 } = {}) {
    const c = this.ctx; const tz = c.settings.get('tz') || 'Asia/Taipei'; const t = (ts) => { try { return new Date(ts).toLocaleString('zh-TW', { hour12: false, timeZone: tz }); } catch { return String(ts); } };
    const { maskSecrets } = require('./secaudit'); const safe = (x) => maskSecrets(redact(String(x == null ? '' : x)));
    const one = (x, n = 300) => { const s = safe(x).replace(/\s+/g, ' ').trim(); return s.length > n ? s.slice(0, n) + '…' : s; };
    const L = []; const H = (title) => L.push('', '='.repeat(70), title, '='.repeat(70));
    L.push(`Agent中控中心 運行記錄`, `產生時間：${t(Date.now())}（${tz}）`, '說明：金鑰、token、密碼已自動遮蔽；對話內容只保留開頭一小段。要回報問題時把這個檔案交給開發者即可。');
    H('一、摘要'); try { L.push(safe(this.report())); } catch (e) { L.push('（摘要產生失敗：' + e.message + '）'); }
    H(`二、錯誤記錄（最近 ${this.errors.length} 筆，新的在下面）`);
    if (!this.errors.length) L.push('（沒有錯誤）'); for (const e of this.errors) L.push(`[${t(e.ts)}] ${Debug.code(e.where, e.message)}｜${e.where}｜${one(e.message, 500)}${e.stack ? '\n' + safe(e.stack).split('\n').map((x) => '    ' + x.trim()).join('\n') : ''}`);
    H(`三、執行記錄（AI 最近 ${this.traces.length} 次執行）`);
    if (!this.traces.length) L.push('（還沒有執行記錄）');
    for (const x of this.traces) {
      L.push(`[${t(x.ts)}] ${x.who || '?'}（${x.role || '?'}）｜${x.ms != null ? (x.ms / 1000).toFixed(1) + ' 秒' : ''}｜${x.rounds || 0} 輪｜token 進 ${(x.tokens && x.tokens.in) || 0}／出 ${(x.tokens && x.tokens.out) || 0}${x.tools_sent != null ? `｜送出 ${x.tools_sent} 個工具定義、系統提示 ${x.system_chars || 0} 字` : ''}${x.light ? '｜輕量' : ''}${x.deep ? '｜深思' : ''}${x.self_check ? '｜自我檢查：' + x.self_check.join('、') : ''}${x.error ? '｜錯誤：' + one(x.error, 200) : ''}`);
      L.push(`    輸入：${one(x.input, 120)}`);
      for (const k of x.calls || []) L.push(`    → ${k.name}（${k.ms || 0} ms）參數：${one(k.args, 200)}\n      結果：${one(k.result, 240)}`);
    }
    H('四、系統日誌');
    let lines = []; try { const fs = require('fs'); const path = require('path'); const f = path.join(c.paths.logs, 'app.log'); for (const p of [f + '.1', f]) if (fs.existsSync(p)) lines = lines.concat(fs.readFileSync(p, 'utf8').split('\n')); } catch { /* 用記憶體裡的 */ }
    if (!lines.length) lines = ring.slice(); lines = lines.filter(Boolean).slice(-Math.max(100, Math.min(20000, +logLines || 3000)));
    L.push(`（最後 ${lines.length} 行）`, ...lines.map(safe));
    H('五、操作稽核（最近 200 筆）');
    const au = (c.store.db.audit || []).slice(-200); if (!au.length) L.push('（沒有）'); for (const a of au) L.push(`[${t(a.ts)}] ${a.who}｜${a.action}｜${one(a.detail, 200)}`);
    const stamp = new Date().toISOString().replace(/[-:T]/g, '').slice(0, 12);
    return { name: `agent-log-${stamp}.txt`, text: L.join('\n') + '\n', errors: this.errors.length, traces: this.traces.length, lines: lines.length };
  }
  state() {
    const m = process.memoryUsage(); const h = v8.getHeapStatistics(); const c = this.ctx;
    let handles = -1; try { handles = process._getActiveHandles().length; } catch { /* ignore */ }
    return {
      version: require('../core/settings').VERSION, node: process.version, platform: process.platform, arch: process.arch, pid: process.pid,
      uptime_s: Math.round(process.uptime()), rss_mb: +(m.rss / 1048576).toFixed(1), heap_used_mb: +(m.heapUsed / 1048576).toFixed(1), heap_limit_mb: +(h.heap_size_limit / 1048576).toFixed(0),
      external_mb: +(m.external / 1048576).toFixed(1), event_loop_lag_ms: c.supervisor.lag, speed: this.speed(), lag: c.supervisor.lagReport ? c.supervisor.lagReport(Date.now() - 3600e3) : null, slow_ops: require('../core/slow').recent().slice(-15), deliveries: (this.deliveries || []).slice(-15), db_bytes: c.store.dbBytes || 0, active_handles: handles,
      supervisor: c.supervisor.status(), inspector: { open: this.inspectorOpen, port: c.settings.get('dev.debug_port') },
      queues: { approvals_pending: c.approvals.pending().length, tasks: c.store.db.tasks.filter((t) => t.status === 'pending').length, terminals: c.terminal.sessions.size },
      db: { persons: Object.keys(c.store.db.persons).length, facts: c.store.db.facts.length, vectors: c.store.vec.length, ledger: c.store.db.ledger.length, sheets: c.store.db.sheets.length },
      recent_errors: this.errors.slice(-10), recent_log: ring.slice(-40),
    };
  }
  applyInspector() {
    const on = !!this.ctx.settings.get('dev.debug_inspector'); const port = +this.ctx.settings.get('dev.debug_port', 9229) || 9229;
    try {
      const insp = require('inspector');
      if (on && !this.inspectorOpen) { insp.open(port, '127.0.0.1', false); this.inspectorOpen = true; log.warn(`Inspector 已開啟 127.0.0.1:${port}（adb forward tcp:${port} tcp:${port}，再用 chrome://inspect 連線）`); }
      else if (!on && this.inspectorOpen) { insp.close(); this.inspectorOpen = false; log.info('Inspector 已關閉'); }
      return { ok: true, open: this.inspectorOpen };
    } catch (e) { return { ok: false, error: '此執行環境不支援 inspector：' + e.message }; }
  }
  /** 開發者專用：在 Node 行程內執行一段 JS（可讀 ctx 裡的任何變數）。只有 dev.debug_eval 為 true（人類在 F 頁開）才可用。 */
  async evalCode(code) {
    if (!this.ctx.settings.get('dev.debug_eval')) throw new Error('eval 未開啟（開發者頁 → 允許遠端 eval）');
    const AsyncFunction = Object.getPrototypeOf(async function () {}).constructor;
    const fn = new AsyncFunction('ctx', 'require', `return (${code.trim().replace(/;$/, '')});`);
    let r; try { r = await fn(this.ctx, require); } catch { const f2 = new AsyncFunction('ctx', 'require', code); r = await f2(this.ctx, require); }
    this.ctx.store.audit('developer', 'debug.eval', code.slice(0, 200));
    const seen = new WeakSet();
    return JSON.stringify(r, (k, v) => { if (typeof v === 'bigint') return String(v); if (typeof v === 'function') return '[Function]'; if (v && typeof v === 'object') { if (seen.has(v)) return '[Circular]'; seen.add(v); } return v; }, 1)?.slice(0, 20000) ?? 'undefined';
  }
}
/** 偵錯資料遮蔽：各家金鑰、token、密碼樣式一律換成 *** */
function redact(s) {
  return String(s || '').replace(/AIza[\w-]{20,}/g, 'AIza***').replace(/sk-[\w-]{16,}/g, 'sk-***').replace(/gsk_[\w]{16,}/g, 'gsk_***').replace(/nvapi-[\w-]{16,}/g, 'nvapi-***')
    .replace(/[\w-]{20,}\.[\w-]{4,}\.[\w-]{20,}/g, '***token***').replace(/\b\d{6,12}:[\w-]{30,}\b/g, '***tg-token***').replace(/(bot|token|key|secret|password|authorization)(["'\s:=]+)(Bot |Bearer )?[^\s"',&]{8,}/gi, '$1$2***')
    .replace(/[?&](t|token|key)=[^&\s]+/gi, (m, k) => m[0] + k + '=***');
}
module.exports = { Debug, redact };
