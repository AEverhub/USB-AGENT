'use strict';
/**
 * engine5：記憶整理（參考 OpenClaw 的夜間整理；但不呼叫模型，零額度）。
 *  ・長期事實：同一個人、幾乎一樣的兩則（文字相似度 ≥ 0.85 而且裡面的數字完全相同）→ 只留最新的一則
 *    數字不同（生日 3/5 vs 6/2、電話不同）一律當成不同的事，不合併——寧可多留，不可以刪錯
 *  ・語意記憶：同一個人、同一來源、文字完全相同的 → 只留最新的
 *  ・經驗記憶：只用過一次、而且超過 90 天沒再用到的做法 → 刪掉
 *  ・每天一次（預設 03:30，App 時區），也可以手動執行；dry=true 只回報不刪
 */
const { dice } = require('../core/textsim');
const { logger } = require('../core/log');
const log = logger('consolidate');

const nums = (s) => (String(s).match(/\d+/g) || []).join(',');
const normText = (s) => String(s || '').toLowerCase().replace(/\s+/g, '').replace(/[，。！？、,.!?;；:：「」"'（）()]/g, '');

/** 這兩則是不是在講同一件事（保守判斷） */
function same(a, b) {
  if (nums(a) !== nums(b)) return false;
  const x = normText(a), y = normText(b); if (!x || !y) return false; if (x === y) return true;
  const short = x.length < y.length ? x : y; const long = x.length < y.length ? y : x;
  if (short.length >= 6 && long.includes(short) && short.length / long.length >= 0.6) return true;   // 「喜歡喝拿鐵」⊂「喜歡喝拿鐵咖啡」
  return dice(a, b) >= 0.85;
}

class Consolidator {
  constructor(ctx) { this.ctx = ctx; }
  run({ dry = false } = {}) {
    const db = this.ctx.store.db; const rep = { at: new Date().toISOString(), dry, facts: 0, vectors: 0, experience: 0, merged: [] };
    // ---- 長期事實 ----
    const byP = new Map(); for (const f of db.facts) { if (!byP.has(f.pid)) byP.set(f.pid, []); byP.get(f.pid).push(f); }
    const drop = new Set(); const dropText = [];
    for (const list of byP.values()) {
      const sorted = [...list].sort((a, b) => (b.ts || 0) - (a.ts || 0));   // 新的在前：留新的
      const kept = [];
      for (const f of sorted) { const k = kept.find((x) => same(x.text, f.text)); if (k) { drop.add(f); dropText.push([f.pid, f.text]); if (rep.merged.length < 20) rep.merged.push(`「${f.text}」→ 保留「${k.text}」`); } else kept.push(f); }
    }
    rep.facts = drop.size;
    // ---- 語意記憶 ----
    const vec = this.ctx.store.vec || []; const seen = new Set(); const vdrop = new Set();
    for (let i = vec.length - 1; i >= 0; i--) { const v = vec[i]; const key = `${v.pid}|${v.source}|${normText(v.text)}`; if (seen.has(key)) vdrop.add(v); else seen.add(key); }
    for (const [pid, t] of dropText) { const v = vec.find((x) => x.pid === pid && x.source === 'fact' && x.text === t && !vdrop.has(x)); if (v) vdrop.add(v); }
    rep.vectors = vdrop.size;
    // ---- 經驗 ----
    const exp = (db.meta && db.meta.experience) || {}; const old = Date.now() - 90 * 86400e3; let ex = 0;
    const keepE = {}; for (const [pid, l] of Object.entries(exp)) { keepE[pid] = l.filter((e) => { const k = (e.n || 1) > 1 || (e.ts || 0) >= old; if (!k) ex++; return k; }); }
    rep.experience = ex;
    if (!dry) {
      if (drop.size) db.facts = db.facts.filter((f) => !drop.has(f));
      if (vdrop.size) { const keep = vec.filter((v) => !vdrop.has(v)); vec.length = 0; vec.push(...keep); this.ctx.store.touchVec && this.ctx.store.touchVec(); }
      if (ex) db.meta.experience = keepE;
      db.meta.consolidate = { at: rep.at, facts: rep.facts, vectors: rep.vectors, experience: rep.experience };
      this.ctx.store.touch();
      if (rep.facts + rep.vectors + rep.experience) log.info(`記憶整理：事實 -${rep.facts}、語意記憶 -${rep.vectors}、經驗 -${rep.experience}`);
    }
    return rep;
  }
  /** 存新事實前：有幾乎一樣的舊事實 → 回傳那一則（呼叫端改成更新它） */
  similarFact(pid, text) { return this.ctx.store.db.facts.filter((f) => f.pid === pid).find((f) => same(f.text, text)) || null; }
  last() { return (this.ctx.store.db.meta || {}).consolidate || null; }
}
module.exports = { Consolidator, same };
