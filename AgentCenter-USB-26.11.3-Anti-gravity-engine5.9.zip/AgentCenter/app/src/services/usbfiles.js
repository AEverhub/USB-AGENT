'use strict';
/**
 * engine5.5 USB 專版：插上 USB、有網路 → 自動整理 USB 上散落的檔案；找不到檔案 → 叫 AI 搬出來，改完再存回去。
 *
 * 整理規則（保守）：
 *  ・只動 USB「根目錄」散落的檔案，和根目錄的「收件匣」資料夾裡的檔案；你自己建的資料夾一律不動
 *  ・依類型和月份歸到「整理好的檔案/<類別>/<年-月>/」；同名但內容不同 → 加 (2)；內容完全一樣 → 放到「_重複的檔案」（不刪）
 *  ・剛改過（2 分鐘內）、隱藏檔、Office 暫存檔（~$）、系統檔 → 不動
 *  ・每次整理都有紀錄，可以整批復原（usb_undo）
 *  ・只在真的是 USB 時整理：Windows 要是非系統磁碟的根目錄、Mac 要在 /Volumes/、Linux 要在 /media 或 /run/media；
 *    AgentCenter 放在硬碟一般資料夾時不會整理（避免把你的 C 槽整理掉）。設定 usb.root 可以手動指定。
 *
 * 搬出來／存回去：
 *  ・usb_file_out：在 USB 上找檔案，預設「複製」到這台電腦的桌面（可以指定位置、或改成移出來），並記下「借出」紀錄
 *  ・usb_file_back：把借出去改過的檔案存回 USB 原位置（直接覆蓋；被蓋掉的舊版先備份到 AgentCenter/data/usb-backup）
 *  ・你自己把改好的檔案丟回 USB 根目錄 → 下次整理時認出是借出去的那個，自動覆蓋回原位置（不會變成「檔名 (2)」）
 */
const fs = require('fs');
const os = require('os');
const path = require('path');
const crypto = require('crypto');
const { Ranker } = require('../core/textsim');
const { logger } = require('../core/log');
const log = logger('usbfiles');

const LIB = '整理好的檔案';
const INBOX = '收件匣';
const DUP = '_重複的檔案';
const CATS = [
  ['文件', /\.(docx?|odt|rtf|txt|md|pages|hwp)$/i, '文件 word 文書 報告'],
  ['試算表', /\.(xlsx?|xlsm|ods|csv|tsv|numbers)$/i, '試算表 excel 表格 報表'],
  ['簡報', /\.(pptx?|odp|key)$/i, '簡報 powerpoint ppt 投影片'],
  ['PDF', /\.pdf$/i, 'pdf 文件'],
  ['圖片', /\.(jpe?g|png|gif|webp|heic|heif|bmp|tiff?|svg|raw|cr2|nef|arw|dng)$/i, '圖片 照片 相片 截圖'],
  ['影片', /\.(mp4|mov|m4v|avi|mkv|wmv|webm|flv|3gp|mts)$/i, '影片 影音 錄影'],
  ['音樂', /\.(mp3|m4a|wav|flac|aac|ogg|wma|opus)$/i, '音樂 音檔 錄音 歌'],
  ['壓縮檔', /\.(zip|rar|7z|tar|gz|tgz|bz2|xz)$/i, '壓縮檔 zip'],
  ['安裝檔', /\.(exe|msi|dmg|pkg|apk|deb|rpm|appimage|iso)$/i, '安裝檔 程式 安裝'],
  ['程式碼', /\.(js|ts|py|java|c|cpp|h|cs|go|rs|rb|php|html?|css|json|xml|ya?ml|sh|bat|ps1|ipynb|sql)$/i, '程式碼 原始碼 code'],
  ['電子書', /\.(epub|mobi|azw3?)$/i, '電子書 書'],
];
const catOf = (name) => (CATS.find(([, re]) => re.test(name)) || ['其他'])[0];
const wordsOf = (cat) => (CATS.find(([c]) => c === cat) || [, , '其他'])[2];
/** 永遠不動的東西 */
const SKIP_NAME = /^(\.|~\$|\$RECYCLE\.BIN$|System Volume Information$|autorun\.inf$|desktop\.ini$|thumbs\.db$|AgentCenter$|使用說明-USB\.txt$|啟動-|設定USB密碼-|安裝自動啟動-|移除自動啟動-|usb-id$)/i;
// engine5.8：找檔案／讀檔案時整支 USB 都看（隱藏資料夾也看），只跳過系統資料夾、程式本身（AgentCenter：金鑰、記憶）、太大的開發資料夾
const INDEX_SKIP_DIR = /^(\$RECYCLE\.BIN|System Volume Information|AgentCenter|\.Trashes|\.Spotlight-V100|\.fseventsd|\.TemporaryItems|\.DocumentRevisions-V100|lost\+found|\.git|node_modules)$/i;
const READABLE = /\.(txt|md|markdown|csv|tsv|json|jsonl|xml|html?|log|ini|cfg|conf|ya?ml|toml|js|ts|jsx|tsx|py|java|c|cc|cpp|h|hpp|cs|go|rs|rb|php|sh|bat|ps1|sql|tex|srt|vtt|docx|xlsx|pptx|pdf)$/i;
const SKIP_DIR = /^(\.|\$RECYCLE\.BIN$|System Volume Information$|AgentCenter$|\.Trashes$|\.Spotlight-V100$|\.fseventsd$|lost\+found$)/i;

function sha1(f) { const h = crypto.createHash('sha1'); const fd = fs.openSync(f, 'r'); const buf = Buffer.alloc(1 << 20); try { let n; while ((n = fs.readSync(fd, buf, 0, buf.length, null)) > 0) h.update(buf.subarray(0, n)); } finally { fs.closeSync(fd); } return h.digest('hex'); }
function sameFile(a, b) { try { const x = fs.statSync(a), y = fs.statSync(b); return x.size === y.size && sha1(a) === sha1(b); } catch { return false; } }
function freeName(dir, name) { const ext = path.extname(name); const base = name.slice(0, name.length - ext.length); let n = name, i = 2; while (fs.existsSync(path.join(dir, n))) n = `${base} (${i++})${ext}`; return n; }
/** 移動：同一個磁碟用 rename；跨磁碟（USB → 電腦）就複製再刪 */
function moveFile(from, to) { fs.mkdirSync(path.dirname(to), { recursive: true }); try { fs.renameSync(from, to); } catch (e) { if (e.code !== 'EXDEV') throw e; fs.copyFileSync(from, to); fs.unlinkSync(from); } }
function copyFile(from, to) { fs.mkdirSync(path.dirname(to), { recursive: true }); fs.copyFileSync(from, to); try { const st = fs.statSync(from); fs.utimesSync(to, st.atime, st.mtime); } catch { /* ignore */ } }
const ym = (ms) => { const d = new Date(ms); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`; };
const human = (n) => (n >= 1 << 30 ? (n / (1 << 30)).toFixed(1) + ' GB' : n >= 1 << 20 ? (n / (1 << 20)).toFixed(1) + ' MB' : n >= 1024 ? Math.round(n / 1024) + ' KB' : n + ' B');

/** 判斷 AgentCenter 所在的位置是不是一支 USB 的根目錄；不是就回 null（不整理） */
function detectRoot(appRoot, platform = process.platform) {
  const P = platform === 'win32' ? path.win32 : path.posix; const parent = P.dirname(P.resolve(appRoot));
  if (platform === 'win32') {
    const r = P.parse(parent).root; const sys = (process.env.SystemDrive || 'C:').toUpperCase();
    if (parent.replace(/[\\/]+$/, '') + '\\' !== r && parent !== r) return null;
    if (r.toUpperCase().startsWith(sys)) return null; return r;
  }
  if (platform === 'darwin') return /^\/Volumes\/[^/]+$/.test(parent) ? parent : null;
  return /^\/(media\/[^/]+(\/[^/]+)?|run\/media\/[^/]+\/[^/]+|mnt\/[^/]+)$/.test(parent) ? parent : null;
}

/** 這台電腦的桌面（Windows 桌面常被 OneDrive 接管） */
function desktopDir() {
  const h = os.homedir(); const c = [];
  if (process.platform === 'win32') { if (process.env.OneDrive) c.push(path.join(process.env.OneDrive, 'Desktop'), path.join(process.env.OneDrive, '桌面')); c.push(path.join(h, 'Desktop'), path.join(h, '桌面')); }
  else { try { const ud = fs.readFileSync(path.join(h, '.config', 'user-dirs.dirs'), 'utf8'); const m = /XDG_DESKTOP_DIR="([^"]+)"/.exec(ud); if (m) c.push(m[1].replace('$HOME', h)); } catch { /* 沒有 */ } c.push(path.join(h, 'Desktop'), path.join(h, '桌面')); }
  return c.find((d) => { try { return fs.statSync(d).isDirectory(); } catch { return false; } }) || h;
}
function namedDir(word) {
  const h = os.homedir(); const w = String(word || '').trim();
  if (!w || /^(桌面|desktop)$/i.test(w)) return desktopDir();
  if (/^(下載|downloads?)$/i.test(w)) return [path.join(h, 'Downloads'), path.join(h, '下載')].find((d) => fs.existsSync(d)) || path.join(h, 'Downloads');
  if (/^(文件|我的文件|documents?)$/i.test(w)) return [path.join(h, 'Documents'), path.join(h, '文件')].find((d) => fs.existsSync(d)) || path.join(h, 'Documents');
  if (/^(圖片|pictures?)$/i.test(w)) return [path.join(h, 'Pictures'), path.join(h, '圖片')].find((d) => fs.existsSync(d)) || path.join(h, 'Pictures');
  return path.resolve(w.replace(/^~(?=$|[\\/])/, h));
}

class UsbFiles {
  constructor(ctx) { this.ctx = ctx; this._idx = null; this._running = false; }
  get S() { return this.ctx.settings; }
  /** USB 根目錄（null＝不是 USB 模式或位置不安全） */
  root() {
    const set = this.S.get('usb.root', ''); if (set) return path.resolve(set);
    const p = this.ctx.portable; if (!p || !p.on || !p.root) return null; return detectRoot(p.root);
  }
  active() { return !!this.root(); }
  _need() { const r = this.root(); if (!r) throw new Error('這個功能只在 USB 版、而且 AgentCenter 放在 USB 根目錄時才能用'); if (!fs.existsSync(r)) throw new Error('找不到 USB（可能已經拔掉了）'); return r; }
  _f(n) { return path.join(this.ctx.paths.data, n); }
  _read(n, d) { try { return JSON.parse(fs.readFileSync(this._f(n), 'utf8')); } catch { return d; } }
  _write(n, j) { const f = this._f(n); fs.writeFileSync(f + '.tmp', JSON.stringify(j, null, 1)); fs.renameSync(f + '.tmp', f); }
  checkouts() { return this._read('usb-checkouts.json', []); }
  _saveCo(l) { this._write('usb-checkouts.json', l); }
  _log(entries) { if (!entries.length) return; fs.appendFileSync(this._f('usb-sort-log.jsonl'), entries.map((e) => JSON.stringify(e)).join('\n') + '\n'); }
  _logRead() { try { return fs.readFileSync(this._f('usb-sort-log.jsonl'), 'utf8').split('\n').filter(Boolean).map((l) => JSON.parse(l)); } catch { return []; } }
  /** 被覆蓋前的舊版本備份（總共最多 usb.backup_mb MB，超過就刪最舊的） */
  _backup(file) {
    if (!fs.existsSync(file)) return '';
    const d = path.join(this._f('usb-backup'), new Date().toISOString().slice(0, 10)); fs.mkdirSync(d, { recursive: true });
    const to = path.join(d, freeName(d, path.basename(file))); fs.copyFileSync(file, to);
    try {
      const cap = (+this.S.get('usb.backup_mb', 500) || 500) * 1048576; const all = [];
      for (const day of fs.readdirSync(this._f('usb-backup'))) { const dd = path.join(this._f('usb-backup'), day); for (const n of fs.readdirSync(dd)) { const p = path.join(dd, n); const st = fs.statSync(p); all.push({ p, s: st.size, m: st.mtimeMs }); } }
      let tot = all.reduce((a, b) => a + b.s, 0); for (const x of all.sort((a, b) => a.m - b.m)) { if (tot <= cap || x.p === to) break; fs.unlinkSync(x.p); tot -= x.s; }
    } catch { /* ignore */ }
    return to;
  }

  // ---------- 整理 ----------
  /** 要整理的檔案：根目錄散落的、收件匣裡的 */
  _candidates(root) {
    const out = []; const young = Date.now() - 2 * 60e3;
    const take = (dir) => { let ents = []; try { ents = fs.readdirSync(dir, { withFileTypes: true }); } catch { return; }
      for (const e of ents) { if (!e.isFile() || SKIP_NAME.test(e.name)) continue; const p = path.join(dir, e.name); let st; try { st = fs.statSync(p); } catch { continue; } if (st.mtimeMs > young) continue; out.push({ p, name: e.name, st }); } };
    take(root); take(path.join(root, INBOX));
    return out;
  }
  async online() {
    if (this.S.get('usb.organize.require_online', true) === false) return true;
    try { const r = await fetch(this.S.get('usb.online_url', 'https://www.gstatic.com/generate_204'), { method: 'HEAD', signal: AbortSignal.timeout(5000) }); return r.status < 500; } catch { return false; }
  }
  /** 整理一次；dry=true 只回報會怎麼搬 */
  organize({ dry = false } = {}) {
    const root = this._need(); if (this._running) throw new Error('正在整理中'); this._running = true;
    const run = new Date().toISOString() + '#' + crypto.randomBytes(3).toString('hex'); const rep = { run, dry, moved: [], dup: [], returned: [], skipped: [] };   // 加亂數：同一毫秒跑兩次也分得開（復原只復原一次）
    try {
      const lib = path.join(root, LIB); const co = this.checkouts(); const logs = [];
      const td = !dry && this.ctx.tdongle && this.ctx.tdongle.fd != null ? this.ctx.tdongle : null; const cands = this._candidates(root); let ci = 0;   // engine5.6：小螢幕顯示整理進度
      if (td && cands.length) td.screen({ state: 'busy', title: '整理檔案中', l1: `共 ${cands.length} 個`, done: 0, total: cands.length });
      for (const c of cands) {
        if (td) td.progress(++ci, cands.length, c.name);
        // 1) 借出去的檔案被丟回來 → 覆蓋回原位置
        const back = co.find((x) => !x.closed && x.name.toLowerCase() === c.name.toLowerCase() && x.usbPath && path.resolve(path.join(root, x.usbPath)) !== path.resolve(c.p));
        if (back) {
          const orig = path.join(root, back.usbPath);
          if (fs.existsSync(orig) && sameFile(orig, c.p)) { rep.returned.push({ name: c.name, to: back.usbPath, same: true }); if (!dry) { fs.unlinkSync(c.p); logs.push({ run, act: 'drop-same', from: path.relative(root, c.p), to: back.usbPath }); } continue; }
          rep.returned.push({ name: c.name, to: back.usbPath });
          if (!dry) { const bk = this._backup(orig); moveFile(c.p, orig); back.hash = sha1(orig); back.returnedAt = Date.now(); logs.push({ run, act: 'return', from: path.relative(root, c.p), to: back.usbPath, backup: bk }); }
          continue;
        }
        // 2) 一般檔案 → 依類型與月份歸檔
        const cat = catOf(c.name); const dir = path.join(lib, cat, ym(c.st.mtimeMs));
        const exist = path.join(dir, c.name);
        if (fs.existsSync(exist) && sameFile(exist, c.p)) {
          const dd = path.join(lib, DUP); const to = path.join(dd, freeName(dd, c.name)); rep.dup.push({ name: c.name, to: path.relative(root, to), same_as: path.relative(root, exist) });
          if (!dry) { moveFile(c.p, to); logs.push({ run, act: 'dup', from: path.relative(root, c.p), to: path.relative(root, to) }); } continue;
        }
        const to = path.join(dir, fs.existsSync(dir) ? freeName(dir, c.name) : c.name);
        rep.moved.push({ name: c.name, cat, to: path.relative(root, to), size: c.st.size });
        if (!dry) { try { moveFile(c.p, to); logs.push({ run, act: 'move', from: path.relative(root, c.p), to: path.relative(root, to) }); } catch (e) { rep.skipped.push({ name: c.name, why: e.code === 'EBUSY' || e.code === 'EPERM' ? '檔案正在被使用' : e.message }); rep.moved.pop(); } }
      }
      if (td && cands.length) td.screen({ state: 'ready', title: '整理完成', l1: `歸檔 ${rep.moved.length} 重複 ${rep.dup.length}`, l2: rep.returned.length ? `存回 ${rep.returned.length} 個` : '', total: 0 });
      if (!dry) { this._log(logs); if (rep.returned.length) this._saveCo(co); this._idx = null; this._write('usb-last.json', { at: run.split('#')[0], moved: rep.moved.length, dup: rep.dup.length, returned: rep.returned.length, skipped: rep.skipped.length }); }
      return rep;
    } finally { this._running = false; }
  }
  /** 插上 USB 啟動後自動跑一次（有開、是 USB、有網路） */
  async autoRun() {
    if (this.S.get('usb.organize.enabled', true) === false || !this.active()) return null;
    if (!(await this.online())) { log.info('沒有網路，這次不自動整理'); return null; }
    const r = this.organize();
    const n = r.moved.length + r.dup.length + r.returned.length;
    if (n) { const msg = `已自動整理 USB：歸檔 ${r.moved.length} 個${r.dup.length ? `、重複 ${r.dup.length} 個` : ''}${r.returned.length ? `、存回 ${r.returned.length} 個借出的檔案` : ''}（都在「${LIB}」資料夾；要復原跟 AI 說「復原整理」）`; log.info(msg); try { process.stdout.write('\n' + msg + '\n'); } catch { /* ignore */ } }
    return r;
  }
  /** 復原最近一次整理 */
  undo() {
    const root = this._need(); const all = this._logRead(); const last = [...all].reverse().find((e) => e.act && !e.undone); if (!last) return { run: null, back: 0, fail: [] };
    const run = last.run; const done = []; const fail = [];
    for (const e of all.filter((x) => x.run === run && !x.undone).reverse()) {
      const from = path.join(root, e.from), to = path.join(root, e.to);
      try {
        if (e.act === 'move' || e.act === 'dup') { if (!fs.existsSync(to)) throw new Error('已經不在整理後的位置'); if (fs.existsSync(from)) throw new Error('原位置已經有同名檔案'); moveFile(to, from); }
        else if (e.act === 'return' && e.manual) { if (!e.backup || !fs.existsSync(e.backup)) throw new Error('沒有舊版備份'); fs.copyFileSync(e.backup, to); }   // AI 存回去的：放回舊版（電腦上那份不動）
        else if (e.act === 'return') { if (fs.existsSync(from)) throw new Error('原位置已經有同名檔案'); copyFile(to, from); if (e.backup && fs.existsSync(e.backup)) fs.copyFileSync(e.backup, to); }
        else if (e.act === 'drop-same') { copyFile(to, from); }
        e.undone = true; done.push(e.from);
      } catch (err) { fail.push(`${e.from}：${err.message}`); }
    }
    fs.writeFileSync(this._f('usb-sort-log.jsonl'), all.map((x) => JSON.stringify(x)).join('\n') + '\n'); this._idx = null;
    return { run, back: done.length, fail };
  }

  // ---------- 找檔案 ----------
  index(force = false) {
    const root = this._need(); if (!force && this._idx && Date.now() - this._idx.at < 60e3) return this._idx;   // 60 秒內重用（剛放進去的檔案很快就找得到）
    const files = []; const cap = +this.S.get('usb.index_max', 100000) || 100000;
    const walk = (dir, depth) => { if (depth > 40 || files.length >= cap) return; let ents = []; try { ents = fs.readdirSync(dir, { withFileTypes: true }); } catch { return; }
      for (const e of ents) { if (files.length >= cap) return; const p = path.join(dir, e.name);
        if (e.isDirectory()) { if (!INDEX_SKIP_DIR.test(e.name) && !e.isSymbolicLink()) walk(p, depth + 1); continue; }
        if (!e.isFile() || /^~\$/.test(e.name) || (depth === 0 && SKIP_NAME.test(e.name) && !/^\.[^.]/.test(e.name))) continue;
        let st; try { st = fs.statSync(p); } catch { continue; } files.push({ rel: path.relative(root, p), name: e.name, size: st.size, mtime: st.mtimeMs }); } };
    walk(root, 0);
    // 搬過的檔案記得原本的名字與位置（「我原本放在根目錄的那個」也找得到）
    const orig = new Map(); for (const e of this._logRead()) if (!e.undone && e.to) orig.set(e.to, e.from);
    const docs = files.map((f, i) => ({ id: i, text: `${f.name.replace(/[._\-()[\]]+/g, ' ')} ${f.name} ${f.rel.split(/[\\/]/).slice(0, -1).join(' ')} ${wordsOf(catOf(f.name))} ${orig.get(f.rel) || ''}` }));
    this._idx = { at: Date.now(), files, ranker: new Ranker(docs) }; return this._idx;
  }
  find(query, { limit = 8 } = {}) {
    const q = String(query || '').trim(); if (!q) throw new Error('要說要找什麼');
    if (this._idx) { const r = this._find(q, limit); if (r.length) return r; this.index(true); }   // 沒找到：可能是剛放進去的 → 重新掃一次
    return this._find(q, limit);
  }
  _find(q, limit) {
    const idx = this.index(); const low = q.toLowerCase();
    const exact = idx.files.filter((f) => f.name.toLowerCase() === low || f.rel.toLowerCase() === low.replace(/\//g, path.sep).toLowerCase());
    if (exact.length) return exact.slice(0, limit).map((f) => ({ ...f, score: 99 }));
    const sub = idx.files.filter((f) => f.name.toLowerCase().includes(low)).map((f) => ({ ...f, score: 50 + Math.min(10, low.length) }));
    const ranked = idx.ranker.rank(q, { top: limit * 2 }).filter((r) => r.rel >= 0.12).map((r) => ({ ...idx.files[r.id], score: +r.score.toFixed(2), relv: r.rel }));
    const seen = new Set(); const out = [];
    for (const f of [...sub.sort((a, b) => b.mtime - a.mtime), ...ranked]) { if (seen.has(f.rel)) continue; seen.add(f.rel); out.push(f); if (out.length >= limit) break; }
    return out;
  }
  _pick(a) {
    const root = this._need();
    if (a.path) { const p = path.resolve(root, String(a.path)); if (!p.startsWith(path.resolve(root) + path.sep)) throw new Error('只能拿 USB 裡的檔案'); if (!fs.existsSync(p) || !fs.statSync(p).isFile()) throw new Error('USB 上沒有這個檔案：' + a.path); return { rel: path.relative(root, p), name: path.basename(p), size: fs.statSync(p).size, mtime: fs.statSync(p).mtimeMs }; }
    const hits = this.find(a.query, { limit: 6 }); if (!hits.length) throw new Error(`USB 上找不到跟「${a.query}」有關的檔案`);
    const [x, y] = hits; const clear = hits.length === 1 || x.score === 99 || (x.score >= 50 && !(y && y.score >= 50)) || (x.relv != null && y && y.relv != null && x.score >= y.score * 1.5);
    if (!clear) { const e = new Error(`有 ${hits.length} 個可能的檔案，請指定是哪一個（用 path）：\n` + hits.map((f, i) => `${i + 1}. ${f.rel}（${human(f.size)}，${new Date(f.mtime).toLocaleDateString('zh-TW')}）`).join('\n')); e.code = 'AMBIGUOUS'; throw e; }
    return x;
  }

  // ---------- engine5.8：USB 上任何位置的檔案都能看、能讀 ----------
  /** USB 上的路徑 → 完整路徑（不能跑出 USB、不能碰 AgentCenter） */
  _abs(rel) {
    const root = path.resolve(this._need()); const p = path.resolve(root, String(rel || '.').replace(/^[\\/]+/, ''));
    if (p !== root && !p.startsWith(root + path.sep)) throw new Error('只能看 USB 裡面的東西');
    const first = path.relative(root, p).split(path.sep)[0];
    if (/^(AgentCenter|System Volume Information|\$RECYCLE\.BIN)$/i.test(first)) throw new Error('這是程式和系統用的資料夾（裡面有金鑰），不能看');
    return p;
  }
  list(rel = '', { limit = 300 } = {}) {
    const root = this._need(); const p = this._abs(rel); let ents;
    try { ents = fs.readdirSync(p, { withFileTypes: true }); } catch (e) { throw new Error(e.code === 'ENOENT' ? 'USB 上沒有這個資料夾：' + rel : e.code === 'ENOTDIR' ? '這是檔案，不是資料夾：' + rel : e.message); }
    const items = [];
    for (const e of ents) {
      if (p === path.resolve(root) && /^(AgentCenter|System Volume Information|\$RECYCLE\.BIN)$/i.test(e.name)) continue;
      const full = path.join(p, e.name);
      if (e.isDirectory()) items.push({ name: e.name, dir: true });
      else if (e.isFile()) { let st; try { st = fs.statSync(full); } catch { continue; } items.push({ name: e.name, dir: false, size: st.size, mtime: st.mtimeMs }); }
    }
    items.sort((a, b) => (b.dir - a.dir) || a.name.localeCompare(b.name, 'zh-Hant'));
    return { rel: path.relative(root, p) || '（根目錄）', total: items.length, items: items.slice(0, limit) };
  }
  /** 讀檔案內容：文字檔、程式碼、Word、Excel、PowerPoint、PDF（文字型）。很長的分段讀（offset） */
  read(a = {}) {
    const root = this._need(); let rel;
    if (a.path) { const p = this._abs(a.path); if (!fs.existsSync(p) || !fs.statSync(p).isFile()) throw new Error('USB 上沒有這個檔案：' + a.path); rel = path.relative(root, p); }
    else rel = this._pick({ query: a.query }).rel;
    const full = path.join(root, rel); const size = fs.statSync(full).size;
    if (size > 50 * 1048576) throw new Error(`檔案太大（${human(size)}），只能讀 50 MB 以下的`);
    if (/\.(jpe?g|png|gif|webp|heic|bmp|mp4|mov|avi|mkv|mp3|m4a|wav|zip|rar|7z|exe|msi|iso|dmg)$/i.test(rel)) throw new Error(`「${path.basename(rel)}」是圖片／影音／壓縮檔，沒有文字可以讀。要拿出來看就用 usb_file_out`);
    const { kind, text } = require('./docread').extract(fs.readFileSync(full), rel);
    const max = Math.min(Math.max(+a.max || 12000, 1000), 30000); const off = Math.max(0, +a.offset || 0);
    const part = text.slice(off, off + max); const next = off + max < text.length ? off + max : null;
    return { rel, kind, size, chars: text.length, offset: off, text: part, next };
  }
  /** 找「內容」有這些字的檔案（文字檔、程式碼、Office、PDF；單檔 10 MB 以下；最多找 20 秒） */
  grep(query, { limit = 15, maxMs = 20000 } = {}) {
    const q = String(query || '').trim().toLowerCase(); if (!q) throw new Error('要說要找什麼字');
    const root = this._need(); const idx = this.index(); const t0 = Date.now(); const out = []; let looked = 0, cut = false;
    const { extract } = require('./docread');
    for (const f of [...idx.files].sort((a, b) => b.mtime - a.mtime)) {
      if (!READABLE.test(f.name) || f.size > 10 * 1048576) continue;
      if (Date.now() - t0 > maxMs) { cut = true; break; }
      let text; try { text = extract(fs.readFileSync(path.join(root, f.rel)), f.name).text; } catch { continue; } looked++;
      const i = text.toLowerCase().indexOf(q); if (i < 0) continue;
      out.push({ ...f, snippet: text.slice(Math.max(0, i - 60), i + q.length + 80).replace(/\s+/g, ' ').trim() });
      if (out.length >= limit) break;
    }
    return { hits: out, looked, cut };
  }

  // ---------- 搬出來／存回去 ----------
  /** 把 USB 上的檔案拿到這台電腦（預設複製到桌面） */
  fileOut(a) {
    const root = this._need(); const f = this._pick(a); const src = path.join(root, f.rel);
    const dir = namedDir(a.dest); if (path.resolve(dir).startsWith(path.resolve(root) + path.sep) || path.resolve(dir) === path.resolve(root)) throw new Error('目的地要是這台電腦上的資料夾，不能是 USB 本身');
    const co = this.checkouts(); const prev = co.find((x) => !x.closed && x.usbPath === f.rel && path.dirname(x.hostPath) === path.resolve(dir));
    const to = prev ? prev.hostPath : path.join(dir, fs.existsSync(path.join(dir, f.name)) ? freeName(dir, f.name) : f.name);
    copyFile(src, to); const hash = sha1(to);
    const move = !!a.move; if (move) fs.unlinkSync(src);
    const rec = { id: crypto.randomBytes(4).toString('hex'), name: f.name, usbPath: f.rel, hostPath: path.resolve(to), host: os.hostname(), at: Date.now(), hash, moved: move };
    if (prev) Object.assign(prev, rec, { id: prev.id }); else co.push(rec);
    this._saveCo(co.slice(-500)); this._idx = null;
    return { ...rec, size: f.size };
  }
  /** 借出去的檔案現在的狀態（有沒有改過、還在不在） */
  status() {
    const root = this.root(); const me = os.hostname();
    return this.checkouts().filter((x) => !x.closed).map((x) => {
      const here = x.host === me; let changed = null, exists = null;
      if (here) { exists = fs.existsSync(x.hostPath); if (exists) { try { changed = sha1(x.hostPath) !== x.hash; } catch { changed = null; } } }
      return { ...x, here, exists, changed, usbExists: root ? fs.existsSync(path.join(root, x.usbPath)) : null };
    });
  }
  /** 把借出去的檔案存回 USB 原位置（覆蓋；舊版先備份）。query 省略＝這台電腦上所有改過的 */
  fileBack(a = {}) {
    const root = this._need(); const me = os.hostname(); const co = this.checkouts();
    let list = co.filter((x) => !x.closed && x.host === me);
    if (a.query) { const q = String(a.query).toLowerCase(); list = list.filter((x) => x.name.toLowerCase().includes(q) || x.usbPath.toLowerCase().includes(q)); }
    if (!list.length) throw new Error(a.query ? `沒有借出去的「${a.query}」` : '這台電腦上沒有從 USB 借出去的檔案');
    const done = []; const fail = []; const same = [];
    for (const x of list) {
      if (!fs.existsSync(x.hostPath)) { fail.push(`${x.name}：電腦上的檔案已經不在了（${x.hostPath}）`); continue; }
      const dst = path.join(root, x.usbPath); const h = sha1(x.hostPath);
      if (!a.query && h === x.hash && fs.existsSync(dst)) { same.push(x.name); continue; }
      if (fs.existsSync(dst) && sameFile(dst, x.hostPath)) { same.push(x.name); x.hash = h; continue; }
      const bk = this._backup(dst); copyFile(x.hostPath, dst); x.hash = h; x.returnedAt = Date.now(); done.push({ name: x.name, to: x.usbPath, backup: bk });
      this._log([{ run: new Date().toISOString() + '#' + crypto.randomBytes(3).toString('hex'), act: 'return', from: '(電腦)' + x.hostPath, to: x.usbPath, backup: bk, manual: true }]);
    }
    this._saveCo(co); this._idx = null;
    return { done, same, fail };
  }
  /** 不再追蹤（例如電腦上的那份已經不要了） */
  close(query) { const co = this.checkouts(); let n = 0; for (const x of co) if (!x.closed && (!query || x.name.toLowerCase().includes(String(query).toLowerCase()))) { x.closed = true; n++; } this._saveCo(co); return n; }
  last() { return this._read('usb-last.json', null); }
}

module.exports = { UsbFiles, detectRoot, catOf, desktopDir, namedDir, LIB, INBOX };
