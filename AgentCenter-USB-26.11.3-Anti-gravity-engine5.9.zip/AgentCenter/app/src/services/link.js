'use strict';
/**
 * 聯機（26.11.3）：讓兩台在不同地方的手機連在一起用同一個 AI。
 *
 *  主機模式：這台當伺服器。產生一組「固定不變的聯機碼」（可設聯機密碼），主機的使用者自動是管理員。
 *           主機透過內網穿透（Cloudflare）拿到公開網址，定時把「聯機碼 → 公開網址」登記到聯機目錄。
 *  聯機模式：輸入（或從下拉選單選）聯機碼 → 連到主機，自動成為主機上的「一般用戶」，權限、次數由主機管理員分配。
 *           聯機模式下這台 App 的對話頁直接跟主機的 AI 說話（本機後台只當安全的轉送站，token 不會給畫面）。
 *
 *  身分：使用聯機功能的每個人都要註冊「4 個英文字母＋11 位數字」的自動 ID（例：QKZM04718263915）和一個中文或英文名字。
 *
 *  聯機目錄（下拉選單的來源）：relay/cloudflare-worker.mjs 的 /net/*。所有用同一個目錄網址的手機都看得到彼此公開的聯機碼。
 *    目錄網址：設定 link.directory_url → 沒填就用 LINE 中繼的 Worker 網址 → 再沒有就讀 APK 內建的 config/link-directory.txt。
 *    沒有目錄時仍可手動輸入「聯機碼@主機網址」。
 *
 *  安全：主機對外只開 /net/*（加入、以該用戶身分對話、讀自己的紀錄與檔案）；管理 API 仍只在本機。
 *        聯機 token 只存雜湊；加入有次數限制；聯機密碼只存 scrypt 雜湊；目錄登記用主機私鑰防止別人搶用同一個聯機碼。
 */
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { logger } = require('../core/log');
const { fetchJson } = require('../core/util');
const log = logger('link');

const VIEW_OK = /^\/api\/(status|notifications|approvals|usage|debug\/issues|supervisor|ops)(\/|$)/;   // 只能看監控的人可以讀的
const LETTERS = 'ABCDEFGHJKLMNPQRSTUVWXYZ'; const CODE_CH = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
const ID_RE = /^[A-Z]{4}\d{11}$/; const CODE_RE = /^[A-Z2-9]{6}$/;
const rnd = (set, n) => { const b = crypto.randomBytes(n); let s = ''; for (let i = 0; i < n; i++) s += set[b[i] % set.length]; return s; };
const digits = (n) => { let s = ''; while (s.length < n) s += String(crypto.randomInt(0, 1e9)).padStart(9, '0'); return s.slice(0, n); };
const sha = (s) => crypto.createHash('sha256').update(String(s)).digest('hex');
const cleanName = (s) => String(s || '').replace(/[\u0000-\u001f<>]/g, '').trim().slice(0, 24);
// 手機上的 nodejs-mobile 沒有完整的 Unicode 資料庫，不支援 \p{Script=Han} 這類寫法（整個檔案會載入失敗）→ 用明確的中文字範圍
const HAN = '\\u3400-\\u4DBF\\u4E00-\\u9FFF\\uF900-\\uFAFF';
const NAME_RE = new RegExp(`^[${HAN}A-Za-z][${HAN}A-Za-z0-9 ._-]{0,23}$`);

function newId() { return rnd(LETTERS, 4) + digits(11); }
function newCode() { return rnd(CODE_CH, 6); }
/** 「CODE」或「CODE@https://主機網址」或直接主機網址 */
function parseTarget(s) {
  const t = String(s || '').trim(); const m = /^([A-Za-z2-9]{6})\s*@\s*(https?:\/\/\S+)$/.exec(t); if (m) return { code: m[1].toUpperCase(), url: m[2].replace(/\/+$/, '') };
  if (/^https?:\/\//.test(t)) return { code: '', url: t.replace(/\/+$/, '') };
  if (/^[A-Za-z2-9]{6}$/.test(t)) return { code: t.toUpperCase(), url: '' };
  throw new Error('聯機碼是 6 個英數字（例：K7P2QX），或「聯機碼@主機網址」');
}

class Link {
  constructor(ctx) { this.ctx = ctx; this.name = 'net'; this.timer = null; this.lastAnnounce = null; this.tries = new Map(); this.waiters = new Map(); }
  get S() { return this.ctx.settings; }
  get cfg() { return this.S.get('link') || {}; }
  get mode() { return this.cfg.mode || ''; }
  get db() { const d = this.ctx.store.db; if (!d.link_tokens) d.link_tokens = {}; return d.link_tokens; }

  /** 這台對外的網址：內網穿透 → 沒有就用設定的公開網址（伺服器安裝時設定） */
  publicUrl() { const t = this.ctx.tunnel && this.ctx.tunnel.info ? this.ctx.tunnel.info() : {}; const fixed = String(this.S.get('dev.public_base_url') || '').replace(/\/+$/, ''); return (this.S.get('link.server') && fixed) || (t && t.url) || fixed; }   // 伺服器有固定網址就優先用（連結才不會變）
  /** 伺服器模式初始化（安裝腳本用）：新的伺服器身分、新的聯機碼與邀請；不建立管理員（用 /claim 取得） */
  serverInit({ name = 'AI 伺服器', public_url = '' } = {}) {
    if (public_url) this.S.set('dev.public_base_url', String(public_url).replace(/\/+$/, ''), 'human');
    this.S.set('link.me', { id: newId(), name: cleanName(name) || 'AI 伺服器' }, 'human');
    this.S.set('link.host', { code: newCode(), key: crypto.randomBytes(24).toString('hex'), invite: newInvite(), public: true }, 'human');
    this.S.set('link.client', {}, 'human'); this.S.set('link.mode', 'host', 'human'); this.S.set('link.server', true, 'human');
    return this.state();
  }

  // ---------- 身分與模式 ----------
  me() { return this.cfg.me || null; }
  directory() {
    const d = String(this.cfg.directory_url || this.S.get('platforms.line.relay_url') || '').trim();
    if (d) return d.replace(/\/+$/, '');
    try { return fs.readFileSync(path.join(__dirname, '../../config/link-directory.txt'), 'utf8').trim().replace(/\/+$/, ''); } catch { return ''; }
  }
  register(name) {
    const n = cleanName(name); if (!NAME_RE.test(n)) throw new Error('名字要用中文或英文開頭（最多 24 個字）');
    const cur = this.me(); const me = { id: cur && ID_RE.test(cur.id) ? cur.id : newId(), name: n };
    this.S.set('link.me', me, 'human'); return me;
  }
  state() {
    const c = this.cfg; const t = this.ctx.tunnel && this.ctx.tunnel.info ? this.ctx.tunnel.info() : {};
    const out = { mode: this.mode, me: this.me(), directory: this.directory(), web_entry: this.cfg.web_entry || '', id_format: '4 個英文字母＋11 位數字' };
    if (this.mode === 'host') {
      const members = Object.values(this.ctx.store.db.persons || {}).filter((p) => (p.identities || []).some((i) => i.platform === 'net')).map((p) => ({ pid: p.id, name: p.name, id: (p.identities.find((i) => i.platform === 'net') || {}).uid, role: p.role, status: p.status, last_seen: p.last_seen || 0 }));
      out.host = { code: c.host && c.host.code, locked: !!(c.host && c.host.password_hash), public: !(c.host && c.host.public === false), url: this.publicUrl(), announced: this.lastAnnounce, members, invite: this.inviteLink() };
    }
    if (this.mode === 'client') out.client = { code: c.client && c.client.code, url: c.client && c.client.url, host_name: c.client && c.client.host_name, joined: !!(c.client && c.client.token), role: c.client && c.client.role, console: (c.client && c.client.console) || '' };
    return out;
  }
  /** 第一次選模式：主機 */
  async setupHost({ name, password = '', public: pub = true } = {}) {
    const me = this.register(name); const h = { ...(this.cfg.host || {}) };
    if (!h.code) h.code = newCode(); if (!h.key) h.key = crypto.randomBytes(24).toString('hex');   // key：向目錄證明「這個聯機碼是我的」
    if (!h.invite) h.invite = newInvite();   // 連線連結裡的邀請碼：拿到連結的人按「同意」就能加入（不用打聯機碼、密碼）
    if (password) { if (String(password).length < 4) throw new Error('聯機密碼至少 4 個字'); h.password_hash = require('../core/settings').Settings.hashSecret(password); }
    h.public = pub !== false; this.S.set('link.host', h, 'human'); this.S.set('link.mode', 'host', 'human');
    // 主機這台的使用者＝管理員（App 本機身分）
    const users = this.ctx.users; let p = users.admins()[0];
    if (!p) { p = users.create({ platform: 'app', uid: 'local', name: me.name, role: 'admin', status: 'active' }); }
    if (!p.identities.some((i) => i.platform === 'app')) users.attach(p.id, 'app', 'local', me.name);
    if (!p.identities.some((i) => i.platform === 'net')) users.attach(p.id, 'net', me.id, me.name);   // 群組裡主機管理員也用聯機 ID 發言
    if (!p.name) p.name = me.name; this.ctx.store.touch();
    this.announce().catch(() => {}); return this.state();
  }
  async hostUpdate({ password, clear_password, public: pub, reset_invite, web_entry } = {}) {
    if (this.mode !== 'host') throw new Error('不是主機模式'); const h = { ...(this.cfg.host || {}) };
    if (web_entry !== undefined) {   // engine5.7：聯機碼產生器用的固定入口（GitHub Pages）
      const e = String(web_entry || '').trim().replace(/[#?].*$/, '');
      if (e && !/^https:\/\/[^\s"'<>]+$/.test(e)) throw new Error('網頁入口要是 https:// 開頭的網址（例如 https://你的帳號.github.io/agent/）');
      this.S.set('link.web_entry', e, 'human');
    }
    if (reset_invite || !h.invite) h.invite = newInvite();   // 重設後舊連結失效
    if (clear_password) delete h.password_hash; else if (password) { if (String(password).length < 4) throw new Error('聯機密碼至少 4 個字'); h.password_hash = require('../core/settings').Settings.hashSecret(password); }
    if (pub !== undefined) h.public = !!pub; this.S.set('link.host', h, 'human');
    if (h.public === false) this.unannounce().catch(() => {}); else this.announce().catch(() => {}); return this.state();
  }

  /**
   * 連線連結（26.11.3 Revise3）：點開 → 網頁上按「同意」→ 打開 App → 再按一次「同意並連線」就連上，不用打任何代碼。
   *   有聯機目錄：https://目錄/j/聯機碼-邀請碼（固定不變，主機換網址也不會失效）
   *   沒有目錄：https://主機目前的公開網址/net/j/聯機碼-邀請碼（主機重開、網址變了就要重新分享）
   */
  inviteLink() {
    const h = this.cfg.host || {}; if (this.mode !== 'host' || !h.code || !h.invite) return null;
    const dir = this.directory(); const url = this.publicUrl();
    const base = dir ? `${dir}/j/` : url ? `${url}/net/j/` : ''; if (!base) return { url: '', stable: false, note: '還沒有公開網址：到「監控」啟動 Bot（內網穿透）後才能產生連結' };
    return { url: `${base}${h.code}-${h.invite}`, stable: !!dir, web: url ? `${url}/net/app/#i=${h.invite}` : '', ...this.entryLinks(), app: appLink({ c: h.code, k: h.invite, n: (this.me() || {}).name || '', ...(dir ? { d: dir } : { u: url }) }) };
  }
  /**
   * engine5.7 聯機碼產生器：固定入口（GitHub Pages 的 web/index.html）的分享連結
   *   gh：邀請連結（不用密碼）  gh_code：只帶聯機碼（有設密碼的話要輸入）
   *   有目錄 → 連結永久有效；沒有目錄 → 帶主機目前的網址（u=），主機換網址就要重新產生
   */
  entryLinks() {
    const h = this.cfg.host || {}; const e = String(this.cfg.web_entry || '').trim(); if (!e || this.mode !== 'host' || !h.code) return { entry: e };
    const dir = this.directory(); const url = this.publicUrl(); const where = dir ? `&d=${encodeURIComponent(dir)}` : url ? `&u=${encodeURIComponent(url)}` : '';
    return { entry: e, gh: `${e}#c=${h.code}${h.invite ? `&k=${h.invite}` : ''}${where}`, gh_code: `${e}#c=${h.code}${where}`, gh_stable: !!dir, gh_reach: !!(dir || url) };
  }
  /** 主機的公開埠：連結打開後的網頁（沒有目錄時用） */
  landing(code, invite) {
    const h = this.cfg.host || {}; if (this.mode !== 'host' || code !== h.code || invite !== h.invite) return null;
    const url = this.publicUrl();
    return landingHtml({ name: (this.me() || {}).name || '', web: url ? `${url}/net/app/#i=${h.invite}` : '', app: appLink({ c: h.code, k: h.invite, n: (this.me() || {}).name || '', u: url }) });
  }

  // ---------- 目錄 ----------
  async announce() {
    if (this.mode !== 'host') return null; const h = this.cfg.host || {}; const dir = this.directory(); const url = this.publicUrl();
    if (!dir || !url || !h.code || h.public === false) return null;
    const r = await fetchJson(dir + '/net/announce', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ code: h.code, key: h.key, url, name: (this.me() || {}).name || '', locked: !!h.password_hash, version: require('../core/settings').VERSION }) }, 12000);
    if (!r.ok) throw new Error('聯機目錄登記失敗：' + ((r.json && r.json.error) || r.status));
    this.lastAnnounce = { at: Date.now(), url }; return this.lastAnnounce;
  }
  async unannounce() { const h = this.cfg.host || {}; const dir = this.directory(); if (!dir || !h.code) return; await fetchJson(`${dir}/net/announce?code=${h.code}&key=${h.key}`, { method: 'DELETE' }, 8000).catch(() => {}); this.lastAnnounce = null; }
  async list() {
    const dir = this.directory(); if (!dir) return { directory: '', items: [], note: '還沒有聯機目錄：請手動輸入「聯機碼@主機網址」，或請主機設定目錄網址' };
    const r = await fetchJson(dir + '/net/list', {}, 10000); if (!r.ok) throw new Error('讀不到聯機目錄（' + r.status + '）');
    return { directory: dir, items: ((r.json && r.json.items) || []).map((x) => ({ code: x.code, name: x.name, locked: !!x.locked, online: !!x.online, at: x.at })) };
  }
  async resolve(t) {
    if (t.url) return t; const dir = this.directory(); if (!dir) throw new Error('沒有聯機目錄，請輸入「聯機碼@主機網址」');
    const r = await fetchJson(`${dir}/net/resolve?code=${encodeURIComponent(t.code)}`, {}, 10000);
    if (r.status === 404) throw new Error('找不到這個聯機碼（主機可能沒開、或沒有公開）'); if (!r.ok || !r.json || !r.json.url) throw new Error('聯機目錄回應錯誤');
    return { code: t.code, url: r.json.url };
  }

  // ---------- 聯機（加入別人的主機）----------
  async join({ target, password = '', name, invite = '', directory = '' } = {}) {
    if (name) this.register(name); const me = this.me(); if (!me) throw new Error('請先填名字（會自動產生你的 ID）');
    // 從連線連結來的：連結裡帶了目錄網址 → 這台沒設目錄就順便記下來（之後下拉選單也看得到）
    if (directory && /^https?:\/\/\S+$/.test(directory) && !this.cfg.directory_url) this.S.set('link.directory_url', directory.replace(/\/+$/, ''), 'human');
    const t = await this.resolve(parseTarget(target));
    const r = await fetchJson(t.url + '/net/join', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ code: t.code, password, invite, id: me.id, name: me.name }) }, 15000).catch((e) => { throw new Error('連不到主機：' + e.message); });
    if (!r.ok) throw new Error((r.json && r.json.error) || `主機拒絕（${r.status}）`);
    const j = r.json; this.S.set('link.client', { code: j.code, url: t.url, token: j.token, host_name: j.host_name || '', role: j.role, console: j.console || '', joined_at: Date.now() }, 'human'); this.S.set('link.mode', 'client', 'human');
    return { ok: true, host_name: j.host_name, role: j.role, status: j.status };
  }
  leave() { if (this.mode === 'host') this.unannounce().catch(() => {}); this.S.set('link.client', {}, 'human'); this.S.set('link.mode', '', 'human'); return { ok: true }; }   // 改回單機
  /** 聯機模式：畫面的 /api/link/c/… 轉送到主機的 /net/u/…（帶這台的聯機 token） */
  async proxy(req, res, sub) {
    const c = this.cfg.client || {}; if (this.mode !== 'client' || !c.token || !c.url) { res.writeHead(409, { 'content-type': 'application/json' }); return res.end(JSON.stringify({ error: '還沒有聯機到主機' })); }
    const chunks = []; for await (const d of req) { chunks.push(d); if (chunks.reduce((s, x) => s + x.length, 0) > 30e6) { res.writeHead(413); return res.end(); } }
    const ctl = new AbortController(); const tm = setTimeout(() => ctl.abort(), /\/api\/(chat|services\/run)$/.test(sub.split('?')[0]) ? 6 * 60e3 : 30000);
    try {
      const r = await fetch(c.url + '/net/u' + sub, { method: req.method, headers: { authorization: 'Bearer ' + c.token, 'content-type': req.headers['content-type'] || 'application/json' }, body: ['GET', 'HEAD'].includes(req.method) ? undefined : Buffer.concat(chunks), signal: ctl.signal });
      const buf = Buffer.from(await r.arrayBuffer()); const h = { 'content-type': r.headers.get('content-type') || 'application/octet-stream' }; const cd = r.headers.get('content-disposition'); if (cd) h['content-disposition'] = cd;
      if (r.status === 401) { this.S.set('link.client', { ...c, token: '' }, 'human'); res.writeHead(409, { 'content-type': 'application/json' }); return res.end(JSON.stringify({ error: '聯機已失效（主機可能移除了你），請到「聯機」頁重新加入' })); }
      if (sub.split('?')[0] === '/api/me' && r.ok) { try { const me = JSON.parse(buf.toString('utf8')); if (me.role !== c.role || (me.console || '') !== (c.console || '')) this.S.set('link.client', { ...c, role: me.role, console: me.console || '' }, 'human'); } catch { /* ignore */ } }
      res.writeHead(r.status, h); res.end(buf);
    } catch (e) { res.writeHead(502, { 'content-type': 'application/json' }); res.end(JSON.stringify({ error: e.name === 'AbortError' ? '主機太久沒回應' : '連不到主機（主機手機可能關機、沒網路或沒開 Bot）：' + e.message })); }
    finally { clearTimeout(tm); }
  }

  // ---------- 主機端：對外的 /net/* ----------
  _limit(key) { const now = Date.now(); const a = (this.tries.get(key) || []).filter((t) => now - t < 10 * 60e3); a.push(now); this.tries.set(key, a); if (this.tries.size > 2000) this.tries.delete(this.tries.keys().next().value); return a.length > 10; }
  _person(req, url) {
    let tok = String(req.headers.authorization || '').replace(/^Bearer\s+/i, '');
    // 26.11.3 pro5 網頁版：<img>／<video> 沒辦法帶標頭，圖片與檔案的 GET 可以把 token 放在 ?t=
    if (!tok && url && req.method === 'GET' && /^\/net\/u\/api\/(chat\/media|files\/(out|view))\//.test(url.pathname)) tok = String(url.searchParams.get('t') || '');
    if (!tok) return null; const pid = this.db[sha(tok)]; if (!pid) return null;
    const p = this.ctx.users.byId(pid); return p && p.status !== 'blocked' ? p : null;
  }
  async handleHttp(req, res, p, url) {
    // engine5.7：固定入口網頁（例如放在 GitHub Pages 的 index.html）要能跨網域加入與確認身分 → 只有這幾個開放 CORS
    //   不用 cookie，身分只靠 Authorization 標頭裡的聯機 token，所以開放給任何網域不會讓別的網站冒用你的身分
    const cors = /^\/net\/(info|terms|join|u\/api\/me)$/.test(p) ? { 'access-control-allow-origin': '*', 'access-control-allow-methods': 'GET, POST, OPTIONS', 'access-control-allow-headers': 'authorization, content-type', 'access-control-max-age': '600' } : {};
    if (req.method === 'OPTIONS' && cors['access-control-allow-origin']) { res.writeHead(204, cors); return res.end(); }
    const send = (code, o) => { res.writeHead(code, { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store', ...cors }); res.end(JSON.stringify(o)); };
    if (this.mode !== 'host') return send(404, { error: '這台不是聯機主機' });
    const h = this.cfg.host || {}; const ip = String(req.headers['cf-connecting-ip'] || req.headers['x-forwarded-for'] || req.socket.remoteAddress || '').split(',')[0].trim();
    try {
      if (p === '/net/app' || p.startsWith('/net/app/')) return this.webApp(req, res, p);   // 26.11.3 pro5：網頁版（iPhone／電腦）
      const jm = /^\/net\/j\/([A-Z2-9]{6})-([A-Za-z0-9]{8,40})$/.exec(p);
      if (jm && req.method === 'GET') { const html = this.landing(jm[1], jm[2]); res.writeHead(html ? 200 : 404, { 'content-type': 'text/html; charset=utf-8', 'cache-control': 'no-store' }); return res.end(html || landingHtml({ gone: true })); }
      if (p === '/net/terms' && req.method === 'GET') return send(200, { version: this.ctx.terms.version, text: this.ctx.terms.text });   // 26.11.3 pro10：加入前可以先看條款
      if (p === '/net/info' && req.method === 'GET') return send(200, { terms: this.ctx.terms ? this.ctx.terms.version : '', code: h.code, name: (this.me() || {}).name || '', locked: !!h.password_hash, version: require('../core/settings').VERSION });
      if (p === '/net/join' && req.method === 'POST') {
        const b = JSON.parse((await readBody(req, 64 * 1024)).toString('utf8') || '{}');
        if (this._limit('ip:' + ip) || this._limit('id:' + b.id)) return send(429, { error: '嘗試太多次，請 10 分鐘後再試' });
        if (h.code && b.code && String(b.code).toUpperCase() !== h.code) return send(403, { error: '聯機碼不對' });
        const viaInvite = !!(h.invite && b.invite && crypto.timingSafeEqual(Buffer.from(sha(b.invite)), Buffer.from(sha(h.invite))));   // 連線連結＝主機發的邀請，不用再輸密碼
        if (h.password_hash && !viaInvite && !require('../core/settings').Settings.verifySecret(String(b.password || ''), h.password_hash)) return send(403, { error: '聯機密碼不對' });
        if (!ID_RE.test(String(b.id || ''))) return send(400, { error: 'ID 格式不對（要 4 個英文字母＋11 位數字）' });
        const name = cleanName(b.name); if (!NAME_RE.test(name)) return send(400, { error: '名字要用中文或英文' });
        const { users } = this.ctx; let person = users.byIdentity('net', b.id);
        if (person && person.status === 'blocked') return send(403, { error: '主機已封鎖這個 ID' });
        if (!person) {   // 聯機進來的人：自動是一般用戶，之後由主機管理員分配權限與次數
          const approve = !!h.approve; person = users.create({ platform: 'net', uid: b.id, name, role: approve ? 'guest' : 'user', status: approve ? 'pending' : 'active' });
          if (approve) await this.ctx.approvals.request({ kind: 'new_user', summary: `「${name}」（聯機 ID ${b.id}）想加入`, payload: { pid: person.id, role: 'user' }, requester: person.id }).catch(() => {});
          this.ctx.notifier.push('info', '有人聯機加入', `${name}（${b.id}）以一般用戶加入`).catch(() => {});
        } else { users.attach(person.id, 'net', b.id, name); if (!person.name) person.name = name; }
        const token = crypto.randomBytes(32).toString('base64url'); for (const [k, v] of Object.entries(this.db)) if (v === person.id) delete this.db[k]; this.db[sha(token)] = person.id; this.ctx.store.touch();
        if (b.agree === true && this.ctx.terms) this.ctx.terms.accept(person.id, 'web');   // 26.11.3 pro10：網頁版加入時勾選同意條款
        this.ctx.store.audit(person.id, 'link_join', `${name} ${b.id}`);
        return send(200, { ok: true, token, code: h.code, host_name: (this.me() || {}).name || '', role: person.role, status: person.status, console: this.consoleLevel(person) });
      }
      if (!p.startsWith('/net/u/')) return send(404, { error: 'not found' });
      const person = this._person(req, url); if (!person) return send(401, { error: '聯機已失效，請重新加入' });
      const sub = p.slice('/net/u'.length); return await this._user(person, req, res, sub, url, send);
    } catch (e) { return send(400, { error: e.message }); }
  }
  /**
   * 26.11.3 pro5 網頁版：給不能裝 APK 的人（iPhone、iPad、電腦）。送出和 App 同一套畫面（ui/），加上 web.js 把 API 接到 /net/u/…。
   * 這裡只送靜態檔（程式碼與圖示，沒有任何資料或金鑰）；要用任何功能都得先 /net/join 拿到聯機 token。
   */
  webApp(req, res, p) {
    if (req.method !== 'GET' && req.method !== 'HEAD') { res.writeHead(405); return res.end(); }
    const sec = { 'x-content-type-options': 'nosniff', 'referrer-policy': 'no-referrer', 'x-frame-options': 'DENY' };
    if (p === '/net/app') { res.writeHead(302, { location: '/net/app/' }); return res.end(); }
    const rel = p.slice('/net/app/'.length); const UI = path.join(__dirname, '..', '..', 'ui');
    if (rel === '' || rel === 'index.html') {
      let html = fs.readFileSync(path.join(UI, 'index.html'), 'utf8');
      html = html.replace('<link rel="icon" href="icon-192.png">', '<link rel="icon" href="icon-192.png">\n<link rel="manifest" href="manifest.webmanifest">\n<link rel="apple-touch-icon" href="icon-192.png">\n<meta name="apple-mobile-web-app-capable" content="yes">\n<meta name="mobile-web-app-capable" content="yes">\n<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">\n<meta name="apple-mobile-web-app-title" content="AI 助理">')
        .replace('<script src="core.js"></script>', '<script src="core.js"></script>\n<script src="web.js"></script>');
      res.writeHead(200, { 'content-type': 'text/html; charset=utf-8', 'cache-control': 'no-cache', ...sec }); return res.end(req.method === 'HEAD' ? '' : html);
    }
    if (rel === 'manifest.webmanifest') {
      const name = ((this.me() || {}).name || '') + ' AI 助理';
      res.writeHead(200, { 'content-type': 'application/manifest+json; charset=utf-8', 'cache-control': 'no-cache', ...sec });
      return res.end(JSON.stringify({ name: name.trim(), short_name: 'AI 助理', start_url: '/net/app/', scope: '/net/app/', display: 'standalone', orientation: 'portrait', background_color: '#000000', theme_color: '#000000', lang: 'zh-Hant', icons: [{ src: 'icon-192.png', sizes: '192x192', type: 'image/png', purpose: 'any' }, { src: 'logo.png', sizes: '512x512', type: 'image/png', purpose: 'any' }] }));
    }
    const TYPES = { js: 'text/javascript; charset=utf-8', css: 'text/css; charset=utf-8', png: 'image/png', svg: 'image/svg+xml', woff2: 'font/woff2', woff: 'font/woff', ttf: 'font/ttf', ico: 'image/x-icon' };
    const ext = (/\.([a-z0-9]+)$/.exec(rel) || [])[1]; const file = path.join(UI, rel);
    if (!/^[A-Za-z0-9._/-]+$/.test(rel) || rel.includes('..') || !TYPES[ext] || !file.startsWith(UI + path.sep) || !fs.existsSync(file) || !fs.statSync(file).isFile()) { res.writeHead(404, sec); return res.end('not found'); }
    const buf = fs.readFileSync(file); res.writeHead(200, { 'content-type': TYPES[ext], 'content-length': buf.length, 'cache-control': /^vendor\//.test(rel) || ext === 'png' ? 'public, max-age=604800' : 'no-cache', ...sec }); return res.end(req.method === 'HEAD' ? '' : buf);
  }
  /** 網頁版的網址（主機有公開網址才有）；帶邀請碼的那個點開不用輸入密碼 */
  webLink() { const h = this.cfg.host || {}; const url = this.publicUrl(); if (this.mode !== 'host' || !url) return null; return { url: `${url}/net/app/`, invite: h.invite ? `${url}/net/app/#i=${h.invite}` : '' }; }
  async _user(person, req, res, sub, url, send) {
    const c = this.ctx; const scope = 'dm_' + person.id; const q = Object.fromEntries(url.searchParams); const uid = (person.identities.find((i) => i.platform === 'net') || {}).uid;
    c.users.touchSeen && c.users.touchSeen(person);
    if (sub === '/api/me') return send(200, { name: person.name, id: uid, role: person.role, status: person.status, quota: c.users.summary(person).quota, host_name: (this.me() || {}).name || '', console: this.consoleLevel(person) });
    // 26.11.3 Revise4 操作端（遠端管理）：管理員＝完整；有 console_view 權限的人＝只能看監控；其他人看不到
    if (sub.startsWith('/admin/')) {
      const lv = this.consoleLevel(person); const ap = sub.slice('/admin'.length); const pathOnly = ap.split('?')[0];
      if (!lv) return send(403, { error: '主機管理員沒有開放你看操作端' });
      if (/^\/api\/(transfer|deploy)/.test(pathOnly) || (req.method !== 'GET' && /^\/api\/link\//.test(pathOnly))) return send(403, { error: '這個功能只能在主機本機操作' });
      if (lv === 'view' && (req.method !== 'GET' || !VIEW_OK.test(pathOnly))) return send(403, { error: '你只有「看監控」的權限' });
      const body = req.method === 'GET' ? {} : JSON.parse((await readBody(req, 30e6)).toString('utf8') || '{}');
      c.store.audit(person.id, 'remote_console', `${req.method} ${pathOnly}`);
      try { return send(200, await c.api.invoke(req.method, ap, body)); } catch (e) { return send(/沒有這個 API/.test(e.message) ? 404 : 400, { error: e.message }); }
    }
    if (sub === '/api/chat/progress') return send(200, require('../platforms/hub').Hub.progress(this.busy && this.busy.get(person.id)) || { idle: true });
    if (sub === '/api/persona') { const ps = c.settings.get('persona') || {}; return send(200, { name: ps.name || '', identity: '' }); }
    if (sub === '/api/services' && req.method === 'GET') return send(200, { items: c.tiles.list().map((t) => ({ id: t.id, name: t.name, icon: t.icon, input: t.input, action: t.action, hint: t.hint })) });
    if (sub === '/api/chat/history') { const n = Math.max(1, Math.min(+q.limit || 40, 200)); const rows = q.before ? c.store.page(scope, +q.before, n) : c.store.tail(scope, n); return send(200, { admin: true, name: person.name, more: rows.length >= n, items: rows.map((m) => ({ role: m.role, text: m.text, ts: m.ts, platform: m.platform || '', imgs: m.imgs || [], files: m.files || [], ...(m.quote ? { quote: m.quote } : {}) })) }); }
    if (sub === '/api/chat/search') return send(200, { items: String(q.q || '').trim() ? c.store.searchMessages(scope, String(q.q).trim(), 30).map((m) => ({ role: m.role, text: m.text, ts: m.ts })) : [] });
    let m = /^\/api\/chat\/media\/([^/?]+)$/.exec(sub);
    if (m) { const f = c.chatmedia.get(decodeURIComponent(m[1])); if (!f) return send(404, { error: 'not found' }); res.writeHead(200, { 'content-type': f.mime, 'content-length': f.buf.length, 'cache-control': 'private, max-age=86400' }); return res.end(f.buf); }
    m = /^\/api\/files\/out\/([^/?]+)$/.exec(sub);
    if (m) { const f = c.filegen.get(decodeURIComponent(m[1])); if (!f || (f.owner && f.owner !== person.id)) return send(404, { error: 'not found' }); const b = c.filegen.read(f); res.writeHead(200, { 'content-type': f.mime, 'content-length': b.length, 'content-disposition': `attachment; filename*=UTF-8''${encodeURIComponent(f.name)}` }); return res.end(b); }
    m = /^\/api\/files\/view\/([^/?]+)$/.exec(sub);   // 26.11.3 Revise8：影片／圖片在 App 裡直接播放
    if (m) { const f = c.filegen.get(decodeURIComponent(m[1])); if (!f || (f.owner && f.owner !== person.id)) return send(404, { error: 'not found' }); const b = c.filegen.read(f); const L = b.length; const rg = /^bytes=(\d*)-(\d*)$/.exec(req.headers.range || ''); const type = /^(video|audio|image)\//.test(f.mime) || f.mime === 'application/pdf' ? f.mime : 'application/octet-stream';
      if (rg) { const st = rg[1] ? +rg[1] : Math.max(0, L - +rg[2]); const en = rg[1] && rg[2] ? Math.min(+rg[2], L - 1) : L - 1; if (st >= L || st > en) { res.writeHead(416); return res.end(); } res.writeHead(206, { 'content-type': type, 'content-length': en - st + 1, 'content-range': `bytes ${st}-${en}/${L}`, 'accept-ranges': 'bytes' }); return res.end(b.subarray(st, en + 1)); }
      res.writeHead(200, { 'content-type': type, 'content-length': L, 'accept-ranges': 'bytes' }); return res.end(b); }
    if (sub === '/api/ngroups' && req.method === 'GET') return send(200, { items: this.groupList(person) });
    if (sub === '/api/ngroups/people') return send(200, { items: this.people().filter((x) => x.pid !== person.id) });
    let gm = /^\/api\/ngroups\/(g[0-9a-f]{10})\/history$/.exec(sub); if (gm) return send(200, this.groupHistory(person, gm[1], q));
    if (req.method !== 'POST') return send(404, { error: 'not found' });
    const body = JSON.parse((await readBody(req, 30e6)).toString('utf8') || '{}');
    if (sub === '/api/ngroups') return send(200, this.groupCreate(person, body));
    gm = /^\/api\/ngroups\/(g[0-9a-f]{10})\/(send|members|leave)$/.exec(sub);
    if (gm) return send(200, gm[2] === 'send' ? await this.groupSend(person, gm[1], body) : gm[2] === 'members' ? this.groupAdd(person, gm[1], body.pids || []) : this.groupLeave(person, gm[1]));
    if (sub === '/api/services/run') {
      if (person.status !== 'active' || !c.users.can(person, 'chat')) return send(403, { error: '主機還沒開放你使用' });
      if (c.users.quotaLeft(person) <= 0) return send(429, { error: '可以使用的次數已經用完了' }); c.users.quotaUse(person);
      return send(200, await c.tiles.run(String(body.id || ''), { text: body.text || '', image: body.image || null, qr: body.qr || [] }, person));
    }
    if (sub === '/api/chat') {
      // 走和 LINE／Discord／TG 一樣的入口：審核、封鎖、權限、次數、勿擾都照主機設定
      const replies = []; const img = body.image && body.image.data ? [{ mime: /^image\/(png|jpeg|webp)$/.test(body.image.mime) ? body.image.mime : 'image/jpeg', data: String(body.image.data) }] : [];
      // 26.11.3 Revise8：聯機的人也能傳檔案（圖片照舊直接顯示）
      const bf = body.file && body.file.data ? body.file : null; const bfMime = bf ? String(bf.mime || require('../platforms/common').mimeOf(bf.name)) : '';
      if (bf && /^image\/(png|jpeg|webp)$/.test(bfMime) && !img.length) img.push({ mime: bfMime, data: String(bf.data) });
      const doc = bf && !/^image\/(png|jpeg|webp)$/.test(bfMime) ? { name: String(bf.name || 'file'), mime: bfMime, buf: Buffer.from(String(bf.data), 'base64') } : null;
      const qt = body.quote && body.quote.text ? { id: String(body.quote.ts || ''), text: String(body.quote.text).slice(0, 1500), name: body.quote.role === 'assistant' ? 'AI' : person.name, fromBot: body.quote.role === 'assistant' } : null;
      const msg = { platform: 'net', chatId: uid, chatType: 'dm', uid, userName: person.name, text: String(body.text || ''), quote: qt, mentioned: true, ts: Date.now(), hasImage: img.length > 0, fetchImages: async () => img, ...(doc ? { hasDoc: true, docName: doc.name, fetchDoc: async () => doc } : {}), reply: async (t) => { replies.push(String(t || '')); } };
      msg._t0 = Date.now(); this.busy = this.busy || new Map(); this.busy.set(person.id, msg);
      try { await c.hub.incoming(msg); } finally { if (this.busy.get(person.id) === msg) this.busy.delete(person.id); }
      return send(200, { text: replies.filter(Boolean).join('\n\n'), images: [], files: (msg._files || []).map((f) => ({ id: f.id, name: f.name, size: f.size, mime: f.mime })), user_files: msg._userFiles || [] });
    }
    return send(404, { error: 'not found' });
  }

  // ---------- 26.11.3 Revise4：聯機群組（主機上的多人聊天室，AI 被叫到才回話，和 LINE 群組一樣） ----------
  get groups() { const d = this.ctx.store.db; if (!d.net_groups) d.net_groups = {}; return d.net_groups; }
  _netId(p) { const i = (p.identities || []).find((x) => x.platform === 'net'); return i ? i.uid : null; }
  _g(person, gid) { const g = this.groups[gid]; if (!g || (!g.members.includes(person.id) && person.role !== 'admin')) throw new Error('找不到這個群組，或你不在群組裡'); return g; }
  /** 可以拉進群組的人：聯機進來的人＋主機管理員 */
  people() { return Object.values(this.ctx.store.db.persons || {}).filter((p) => this._netId(p) && p.status === 'active').map((p) => ({ pid: p.id, name: p.name, id: this._netId(p), admin: p.role === 'admin' })); }
  groupList(person) {
    return Object.values(this.groups).filter((g) => g.members.includes(person.id) || person.role === 'admin').map((g) => { const last = this.ctx.store.tail('chat_net_' + g.id, 1)[0];
      return { id: g.id, name: g.name, members: g.members.map((pid) => { const p = this.ctx.users.byId(pid); return p ? p.name : '?'; }), mine: g.members.includes(person.id), last: last ? { text: String(last.text || '').slice(0, 60), name: last.role === 'assistant' ? 'AI' : last.name || '', ts: last.ts } : null }; })
      .sort((a, b) => ((b.last && b.last.ts) || 0) - ((a.last && a.last.ts) || 0));
  }
  groupCreate(person, { name, members = [] } = {}) {
    if (this.mode !== 'host') throw new Error('要在主機上建立群組'); if (!this._netId(person)) throw new Error('你還沒有聯機身分');
    const n = cleanName(name); if (!n) throw new Error('請給群組取個名字');
    const ok = new Set(this.people().map((x) => x.pid)); const mem = [...new Set([person.id, ...members.filter((x) => ok.has(x))])];
    const id = 'g' + crypto.randomBytes(5).toString('hex'); this.groups[id] = { id, name: n, owner: person.id, members: mem, created: Date.now() };
    this.ctx.store.db.chats[`net:${id}`] = { platform: 'net', chatId: id, type: 'group', name: n, last_seen: Date.now(), members: Object.fromEntries(mem.map((pid) => { const p = this.ctx.users.byId(pid); return [this._netId(p), p.name]; })) };
    this.ctx.store.addMessage('chat_net_' + id, { role: 'system', text: `${person.name} 建立了群組「${n}」`, name: '系統' }); this.ctx.store.touch();
    return { id, name: n, members: mem.length };
  }
  groupAdd(person, gid, pids = []) { const g = this._g(person, gid); const ok = new Set(this.people().map((x) => x.pid)); const add = pids.filter((x) => ok.has(x) && !g.members.includes(x)); g.members.push(...add); this.ctx.store.touch(); if (add.length) this.ctx.store.addMessage('chat_net_' + gid, { role: 'system', text: `${person.name} 邀請了 ${add.map((x) => this.ctx.users.byId(x).name).join('、')}`, name: '系統' }); return { added: add.length }; }
  groupLeave(person, gid) { const g = this._g(person, gid); g.members = g.members.filter((x) => x !== person.id); this.ctx.store.addMessage('chat_net_' + gid, { role: 'system', text: `${person.name} 離開了群組`, name: '系統' }); if (!g.members.length) delete this.groups[gid]; this.ctx.store.touch(); return { ok: true }; }
  groupHistory(person, gid, { before, limit } = {}) {
    const g = this._g(person, gid); const n = Math.max(1, Math.min(+limit || 50, 200)); const rows = before ? this.ctx.store.page('chat_net_' + gid, +before, n) : this.ctx.store.tail('chat_net_' + gid, n);
    return { id: g.id, name: g.name, me: person.name, more: rows.length >= n, members: g.members.map((pid) => (this.ctx.users.byId(pid) || {}).name), ai: (this.ctx.settings.get('persona') || {}).name || 'AI',
      items: rows.map((m) => ({ role: m.role, name: m.role === 'assistant' ? 'AI' : m.name || '', mine: m.pid === person.id || (m.uid && m.uid === this._netId(person)), text: m.text, ts: m.ts, imgs: m.imgs || [], files: m.files || [], ...(m.quote ? { quote: m.quote } : {}) })) };
  }
  /** 在群組發言：和 LINE 群組一樣——@AI、叫 AI 名字、或剛跟 AI 說完話接著問，AI 才回 */
  async groupSend(person, gid, { text = '', image = null, quote = null } = {}) {
    const g = this._g(person, gid); if (!g.members.includes(person.id)) throw new Error('你不在這個群組裡'); const uid = this._netId(person); const t = String(text || '').slice(0, 4000);
    const ai = /(^|\s)@(AI|ai|機器人|助理)\b|@AI/.test(t); const scope = 'chat_net_' + gid; const img = image && image.data ? [{ mime: /^image\/(png|jpeg|webp)$/.test(image.mime) ? image.mime : 'image/jpeg', data: String(image.data) }] : [];
    const qt = quote && quote.text ? { id: String(quote.ts || ''), text: String(quote.text).slice(0, 1500), name: quote.name || '', fromBot: quote.role === 'assistant' } : null;
    const replies = [];
    const msg = { platform: 'net', chatId: gid, chatType: 'group', chatName: g.name, uid, userName: person.name, text: t.replace(/@(AI|ai)\b/g, '').trim() || t, mentioned: ai || !!(qt && qt.fromBot), quote: qt, ts: Date.now(), hasImage: img.length > 0, fetchImages: async () => img,
      reply: async (x) => { const s = String(x || ''); if (!s) return; const last = this.ctx.store.tail(scope, 1)[0]; if (!(last && last.role === 'assistant' && last.text === s)) this.ctx.store.addMessage(scope, { role: 'assistant', text: s, name: 'AI' }); replies.push(s); } };
    await this.ctx.hub.incoming(msg);
    return { ok: true, ai: replies.length > 0 };
  }

  consoleLevel(p) { return p.role === 'admin' ? 'admin' : this.ctx.users.can(p, 'console_view') ? 'view' : ''; }

  // ---------- 給 hub 用的「平台」介面：AI 主動傳訊息給聯機用戶 → 放進他的對話紀錄，對方畫面 15 秒內會看到 ----------
  enabled() { return this.mode === 'host'; }
  health() { return true; }
  async start() { clearInterval(this.timer); if (this.mode !== 'host') return; const tick = () => this.announce().catch((e) => log.warn(e.message)); setTimeout(tick, 5000); this.timer = setInterval(tick, 3 * 60e3); if (this.timer.unref) this.timer.unref(); }
  async stop() { clearInterval(this.timer); this.timer = null; }
  _pidOf(uid) { const p = this.ctx.users.byIdentity('net', uid); if (!p) throw new Error('找不到這位聯機用戶'); return p; }
  async send(uid, text) { if (this.groups[uid]) { this.ctx.store.addMessage('chat_net_' + uid, { role: 'assistant', text: String(text || ''), name: 'AI' }); return { id: String(Date.now()) }; } const p = this._pidOf(uid); this.ctx.store.addMessage('dm_' + p.id, { role: 'assistant', text: String(text || ''), platform: 'net' }); return { id: String(Date.now()) }; }
  async sendFile(uid, f) { const p = this._pidOf(uid); if (!f || !f.id) return; this.ctx.store.addMessage('dm_' + p.id, { role: 'assistant', text: '', platform: 'net', files: [{ id: f.id, name: f.name, size: f.size }] }); }
  async sendImage(uid, img, caption) { const p = this._pidOf(uid); const n = this.ctx.chatmedia.save({ mime: img.mime, data: (img.buf || Buffer.from(img.data || '', 'base64')).toString('base64') }); this.ctx.store.addMessage('dm_' + p.id, { role: 'assistant', text: caption || '', imgs: [n], platform: 'net' }); }
  async sendToUser(uid, text) { return this.send(uid, text); }
}
function newInvite() { return rnd('ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789', 16); }
/** App 的連結：agentcenter://join?c=聯機碼&k=邀請碼&n=主機名稱&d=目錄 或 &u=主機網址（Android 會打開 App） */
function appLink(q) { return 'agentcenter://join?' + Object.entries(q).filter(([, v]) => v).map(([k, v]) => `${k}=${encodeURIComponent(v)}`).join('&'); }
/** 連結打開後的網頁（主機與聯機目錄 Worker 共用同一個樣子） */
function landingHtml({ name = '', app = '', gone = false, web = '' }) {
  const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const intent = app ? 'intent://' + app.slice('agentcenter://'.length) + '#Intent;scheme=agentcenter;end' : '';
  return `<!doctype html><html lang="zh-Hant"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>加入 AI 助理</title>
<style>body{margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;background:#0b1020;color:#edf3ff;font-family:system-ui,"Noto Sans TC",sans-serif;padding:24px;box-sizing:border-box}.b{max-width:420px;width:100%;text-align:center}h1{font-size:22px;margin:0 0 8px}p{color:#8b95a8;line-height:1.7}a.btn{display:block;margin:22px 0 10px;padding:16px;border-radius:14px;background:#8ab4ff;color:#0b1020;font-weight:700;text-decoration:none;font-size:18px}a.sub{color:#8ab4ff;font-size:14px}</style></head><body><div class="b">
${gone ? '<h1>這個連結已失效</h1><p>請跟主機要新的連線連結。</p>' : `<h1>加入「${esc(name || '主機')}」的 AI 助理</h1><p>按下面的按鈕會打開 Agent中控中心 App，再按一次「同意並連線」就完成了。<br>你會成為主機上的一般用戶，可以使用的功能由主機決定。</p>
<a class="btn" href="${esc(intent)}">同意，用 App 開啟</a><a class="sub" href="${esc(app)}">按了沒反應？點這裡</a>${web ? `<a class="btn" style="background:#1b2232;color:#edf3ff;border:1px solid #33405a" href="${esc(web)}">iPhone／電腦：用網頁版開啟</a>` : ''}<p style="font-size:13px;margin-top:24px">Android 可以裝 App（跟主機要安裝檔）；iPhone、iPad、電腦不用安裝，按「用網頁版開啟」就能用。</p>`}
</div></body></html>`;
}
function readBody(req, limit) { return new Promise((ok, bad) => { const c = []; let n = 0; req.on('data', (d) => { n += d.length; if (n > limit) { bad(new Error('內容太大')); req.destroy(); } else c.push(d); }); req.on('end', () => ok(Buffer.concat(c))); req.on('error', bad); }); }
module.exports = { Link, newId, newCode, parseTarget, ID_RE, CODE_RE, landingHtml, appLink };
