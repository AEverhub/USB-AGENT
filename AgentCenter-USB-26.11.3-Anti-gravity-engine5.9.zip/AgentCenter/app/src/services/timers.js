'use strict';
/**
 * 26.11.3 pro10 計時器（手機代理）：倒數到時間 → 手機響鈴（鬧鐘音量）＋震動＋通知，並在對話裡說一聲。
 * 計時器存在 store.db.timers（App 重開後還在；重開時已經過期的會立刻補響一次並註明晚了多久）。
 * 和「排程」不同：排程是到時間叫 AI 做事；計時器只是響鈴提醒，精確到秒、不花 token。
 */
const { logger } = require('../core/log');
const log = logger('timers');
const CN = { 零: 0, 一: 1, 二: 2, 兩: 2, 三: 3, 四: 4, 五: 5, 六: 6, 七: 7, 八: 8, 九: 9, 十: 10, 半: 0.5 };
const cnNum = (s) => { if (/^\d+(\.\d+)?$/.test(s)) return +s; if (s === '半') return 0.5; let n = 0; const m = /^(?:([一二兩三四五六七八九])?十)?([一二兩三四五六七八九])?$/.exec(s); if (!m || !s) return NaN; if (s.includes('十')) n += (m[1] ? CN[m[1]] : 1) * 10; if (m[2]) n += CN[m[2]]; return n; };
/** 「90」「5m」「1h30m」「1:30」「2:00:00」「5 分鐘」「一個半小時」「三分半」→ 秒 */
function parseDuration(v) {
  if (typeof v === 'number') return Math.round(v); let s = String(v == null ? '' : v).trim().toLowerCase().replace(/\s+/g, ''); if (!s) return NaN;
  if (/^\d+(\.\d+)?$/.test(s)) return Math.round(+s);
  let m = /^(\d+):(\d{1,2})(?::(\d{1,2}))?$/.exec(s); if (m) return m[3] != null ? +m[1] * 3600 + +m[2] * 60 + +m[3] : +m[1] * 60 + +m[2];
  s = s.replace(/個/g, '').replace(/鐘頭/g, '小時').replace(/([一二兩三四五六七八九十\d]+)半(小時|分鐘|分)/g, '$1$2半');
  let total = 0, hit = false; const re = /(\d+(?:\.\d+)?|[一二兩三四五六七八九十]+|半)(小時|hours?|hrs?|h|分鐘|分|minutes?|mins?|m|秒鐘|秒|seconds?|secs?|s)(半)?/g; let last = 0;
  for (let x; (x = re.exec(s));) { if (x.index !== last) return NaN; last = re.lastIndex; const n = cnNum(x[1]); if (!Number.isFinite(n)) return NaN; const u = /^(小時|h)/.test(x[2]) ? 3600 : /^(分|m)/.test(x[2]) ? 60 : 1; total += (n + (x[3] ? 0.5 : 0)) * u; hit = true; }
  return hit && last === s.length ? Math.round(total) : NaN;
}
const fmt = (sec) => { sec = Math.max(0, Math.round(sec)); const h = Math.floor(sec / 3600), m = Math.floor((sec % 3600) / 60), s = sec % 60; return [h ? h + ' 小時' : '', m ? m + ' 分' : '', s || (!h && !m) ? s + ' 秒' : ''].filter(Boolean).join(' '); };

class Timers {
  constructor(ctx) { this.ctx = ctx; this.name = 'timers'; this.h = new Map(); }
  get db() { const d = this.ctx.store.db; if (!Array.isArray(d.timers)) d.timers = []; return d.timers; }
  start() { for (const t of this.db.filter((x) => x.status === 'running')) this.arm(t); }
  stop() { for (const h of this.h.values()) clearTimeout(h); this.h.clear(); }
  health() { return true; }
  arm(t) { clearTimeout(this.h.get(t.id)); const ms = t.due - Date.now(); const h = setTimeout(() => this.fire(t.id).catch((e) => log.warn('計時器響鈴失敗：' + e.message)), Math.max(0, Math.min(ms, 2 ** 31 - 1))); if (h.unref) h.unref(); this.h.set(t.id, h); }
  create({ duration, seconds, label = '', ring_s = 30 } = {}, person = null) {
    const sec = seconds != null && seconds !== '' ? Math.round(+seconds) : parseDuration(duration);
    if (!Number.isFinite(sec) || sec < 1) throw new Error('要給時間，例：90（秒）、5m、1h30m、1:30、5 分鐘、一個半小時'); if (sec > 24 * 3600) throw new Error('計時器最長 24 小時；更久的請用排程（schedule_task）');
    if (this.db.filter((x) => x.status === 'running').length >= 20) throw new Error('同時最多 20 個計時器');
    const t = { id: this.ctx.store.nextId('timer'), label: String(label || '').trim().slice(0, 40), seconds: sec, due: Date.now() + sec * 1000, created: Date.now(), pid: person ? person.id : null, status: 'running', ring_s: Math.max(3, Math.min(120, Math.round(+ring_s || 30))) };
    this.db.push(t); this.ctx.store.touch(); this.arm(t); return t;
  }
  view(t, now = Date.now()) { return { id: t.id, label: t.label, seconds: t.seconds, due: t.due, left_s: Math.max(0, Math.round((t.due - now) / 1000)), status: t.status, text: `#${t.id}${t.label ? '「' + t.label + '」' : ''} ${fmt(t.seconds)}，${t.status === 'running' ? '還有 ' + fmt((t.due - now) / 1000) : t.status === 'done' ? '已響' : '已取消'}` }; }
  list(all = false) { const now = Date.now(); return this.db.filter((t) => all || t.status === 'running').sort((a, b) => a.due - b.due).map((t) => this.view(t, now)); }
  cancel(id) { const run = this.db.filter((x) => x.status === 'running'); const list = id == null || id === '' || id === 'all' ? run : run.filter((x) => x.id === +id); if (!list.length) throw new Error(id == null || id === 'all' ? '沒有正在跑的計時器' : `沒有計時器 #${id}`); for (const t of list) { t.status = 'cancelled'; clearTimeout(this.h.get(t.id)); this.h.delete(t.id); } this.ctx.store.touch(); return list.length; }
  async stopRing() { try { await this.ctx.phone.ringStop(); } catch { /* 沒在響 */ } return true; }
  async fire(id) {
    const t = this.db.find((x) => x.id === id); if (!t || t.status !== 'running') return; t.status = 'done'; t.fired = Date.now(); this.h.delete(id); this.ctx.store.touch();
    const late = Math.round((t.fired - t.due) / 1000); const title = t.label ? `計時器：${t.label}` : '計時器'; const text = `${fmt(t.seconds)}到了${late > 30 ? `（App 剛才沒在執行，晚了 ${fmt(late)}）` : ''}`;
    let rang = false; try { await this.ctx.phone.ring(title, text, t.ring_s); rang = true; } catch (e) { log.warn('響鈴失敗（改用通知）：' + e.message); try { await this.ctx.phone.notify(title, text); } catch { /* 連通知都不行就只在對話裡說 */ } }
    try { const p = (t.pid && this.ctx.users.byId(t.pid)) || this.ctx.users.admins()[0]; if (p) await this.ctx.hub.sendToPerson(p, `${title}——${text}`); } catch (e) { log.warn('計時器通知訊息沒送出：' + e.message); }
    // 清掉一天前的舊紀錄
    const cut = Date.now() - 86400e3; this.ctx.store.db.timers = this.db.filter((x) => x.status === 'running' || (x.fired || x.created) > cut);
    return { rang };
  }
}
module.exports = { Timers, parseDuration, fmt };
