'use strict';
/** 不使用 eval 的算式／Excel 風格公式計算器。數字用「十進位修正」避免 0.1+0.2 的浮點誤差。 */
const fix = (x) => (Number.isFinite(x) ? parseFloat(x.toPrecision(14)) : x);

function tokenize(src) {
  const t = []; let i = 0; const s = String(src);
  while (i < s.length) {
    const c = s[i];
    if (/\s/.test(c)) { i++; continue; }
    let m;
    if ((m = /^(\d+\.?\d*|\.\d+)(e[+-]?\d+)?/i.exec(s.slice(i)))) { t.push({ k: 'num', v: parseFloat(m[0]) }); i += m[0].length; continue; }
    if ((m = /^\$?[A-Za-z]{1,3}\$?\d+(:\$?[A-Za-z]{1,3}\$?\d+)?/.exec(s.slice(i))) && !/^[A-Za-z_][A-Za-z0-9_]*\(/.test(s.slice(i))) { t.push({ k: 'ref', v: m[0].replace(/\$/g, '').toUpperCase() }); i += m[0].length; continue; }
    if ((m = /^[A-Za-z_][A-Za-z0-9_.]*/.exec(s.slice(i)))) { t.push({ k: 'id', v: m[0].toUpperCase() }); i += m[0].length; continue; }
    if ((m = /^(<=|>=|<>|!=|==)/.exec(s.slice(i)))) { t.push({ k: 'op', v: m[0] }); i += 2; continue; }
    if ('+-*/^%(),<>=&!'.includes(c)) { t.push({ k: 'op', v: c }); i++; continue; }
    if (c === '"') { const j = s.indexOf('"', i + 1); if (j < 0) throw new Error('字串沒有結尾'); t.push({ k: 'str', v: s.slice(i + 1, j) }); i = j + 1; continue; }
    throw new Error(`無法辨識的符號「${c}」`);
  }
  return t;
}

const flat = (a) => a.flat(Infinity);
const nums = (a) => flat(a).filter((x) => typeof x === 'number' || (typeof x === 'string' && x.trim() !== '' && !isNaN(x))).map(Number);
const FN = {
  SUM: (...a) => nums(a).reduce((x, y) => x + y, 0),
  AVERAGE: (...a) => { const n = nums(a); if (!n.length) throw new Error('AVERAGE 沒有數字'); return n.reduce((x, y) => x + y, 0) / n.length; },
  AVG: (...a) => FN.AVERAGE(...a), MIN: (...a) => Math.min(...nums(a)), MAX: (...a) => Math.max(...nums(a)),
  COUNT: (...a) => nums(a).length, ABS: (x) => Math.abs(x), SQRT: (x) => Math.sqrt(x),
  ROUND: (x, n = 0) => { const f = 10 ** n; return Math.round((x + Number.EPSILON * Math.sign(x)) * f) / f; },
  FLOOR: (x) => Math.floor(x), CEILING: (x) => Math.ceil(x), POWER: (x, y) => x ** y, MOD: (x, y) => x % y,
  IF: (c, a, b = '') => (c ? a : b), AND: (...a) => flat(a).every(Boolean), OR: (...a) => flat(a).some(Boolean),
  PMT: (r, n, pv) => (r === 0 ? -pv / n : -(pv * r) / (1 - (1 + r) ** -n)),
  STDEV: (...a) => { const n = nums(a); const m = n.reduce((x, y) => x + y, 0) / n.length; return Math.sqrt(n.reduce((x, y) => x + (y - m) ** 2, 0) / (n.length - 1)); },
  PI: () => Math.PI, LEN: (x) => String(x).length, CONCAT: (...a) => flat(a).join(''),
  // 26.11.3 pro9 理工函式：三角（弧度；角度用 SIND／COSD／TAND 或 RAD()）、指數對數、階乘、排列組合、統計、物理常數
  SIN: Math.sin, COS: Math.cos, TAN: Math.tan, ASIN: Math.asin, ACOS: Math.acos, ATAN: Math.atan, ATAN2: (y, x) => Math.atan2(y, x),
  SIND: (d) => Math.sin(d * Math.PI / 180), COSD: (d) => Math.cos(d * Math.PI / 180), TAND: (d) => Math.tan(d * Math.PI / 180),
  SINH: Math.sinh, COSH: Math.cosh, TANH: Math.tanh, RAD: (d) => d * Math.PI / 180, DEG: (r) => r * 180 / Math.PI,
  EXP: Math.exp, LN: (x) => { if (x <= 0) throw new Error('LN 的值要大於 0'); return Math.log(x); }, LOG: (x, b = 10) => { if (x <= 0 || b <= 0 || b === 1) throw new Error('LOG 的值與底數要大於 0，底數不能是 1'); return Math.log(x) / Math.log(b); },
  LOG10: (x) => FN.LOG(x, 10), LOG2: (x) => FN.LOG(x, 2), CBRT: Math.cbrt, HYPOT: (...a) => Math.hypot(...nums(a)), SIGN: Math.sign, TRUNC: Math.trunc, INT: Math.floor,
  FACT: (n) => { if (!Number.isInteger(n) || n < 0 || n > 170) throw new Error('階乘要 0～170 的整數'); let r = 1; for (let i = 2; i <= n; i++) r *= i; return r; },
  COMB: (n, k) => { if (k < 0 || k > n) return 0; k = Math.min(k, n - k); let r = 1; for (let i = 1; i <= k; i++) r = r * (n - k + i) / i; return Math.round(r); }, PERM: (n, k) => { let r = 1; for (let i = 0; i < k; i++) r *= n - i; return r; },
  GCD: (...a) => nums(a).map(Math.abs).reduce((x, y) => { while (y) [x, y] = [y, x % y]; return x; }), LCM: (...a) => nums(a).map(Math.abs).reduce((x, y) => (x && y ? x / FN.GCD(x, y) * y : 0)),
  MEDIAN: (...a) => { const n = nums(a).sort((x, y) => x - y); if (!n.length) throw new Error('MEDIAN 沒有數字'); const m = n.length >> 1; return n.length % 2 ? n[m] : (n[m - 1] + n[m]) / 2; },
  VAR: (...a) => FN.STDEV(...a) ** 2, E: () => Math.E,
  CONST: (name) => { const c = CONSTS[String(name).toLowerCase()]; if (!c) throw new Error('常數：' + Object.entries(CONSTS).map(([k, v]) => `${k}（${v[1]}）`).join('、')); return c[0]; },
};
/** 物理常數（SI，CODATA 2018 定義值／建議值） */
const CONSTS = { c: [299792458, '光速 m/s'], g: [9.80665, '標準重力 m/s²'], G: [6.6743e-11, '萬有引力常數'], h: [6.62607015e-34, '普朗克常數 J·s'], hbar: [1.054571817e-34, '約化普朗克常數'], k: [1.380649e-23, '波茲曼常數 J/K'], na: [6.02214076e23, '亞佛加厥數'],
  e: [1.602176634e-19, '基本電荷 C'], eps0: [8.8541878128e-12, '真空電容率 F/m'], mu0: [1.25663706212e-6, '真空磁導率'], r: [8.314462618, '氣體常數 J/(mol·K)'], me: [9.1093837015e-31, '電子質量 kg'], mp: [1.67262192369e-27, '質子質量 kg'], sigma: [5.670374419e-8, '史蒂芬-波茲曼常數'], atm: [101325, '標準大氣壓 Pa'], f: [96485.33212, '法拉第常數 C/mol'] };
CONSTS.g_grav = CONSTS.G; delete CONSTS.G;

/** vars：變數表（鍵用大寫），例 { X: 2 }——給 math_solve 代入用 */
function evaluate(src, resolve = null, vars = null) {
  const t = tokenize(String(src).replace(/^=/, '')); let p = 0;
  const peek = () => t[p], next = () => t[p++];
  const isOp = (v) => peek() && peek().k === 'op' && peek().v === v;
  const num = (v) => { if (typeof v === 'number') return v; if (v === '' || v == null) return 0; const n = Number(v); if (Number.isNaN(n)) throw new Error(`「${v}」不是數字`); return n; };
  function cmp() {
    let l = concat();
    while (peek() && peek().k === 'op' && ['<', '>', '=', '==', '<=', '>=', '<>', '!='].includes(peek().v)) {
      const o = next().v; const r = concat(); const a = typeof l === 'string' ? l : num(l), b = typeof r === 'string' ? r : num(r);
      l = o === '<' ? a < b : o === '>' ? a > b : (o === '=' || o === '==') ? a === b : o === '<=' ? a <= b : o === '>=' ? a >= b : a !== b;
    }
    return l;
  }
  function concat() { let l = add(); while (isOp('&')) { next(); l = String(l) + String(add()); } return l; }
  function add() { let l = mul(); while (isOp('+') || isOp('-')) { const o = next().v; const r = mul(); l = o === '+' ? fix(num(l) + num(r)) : fix(num(l) - num(r)); } return l; }
  // 26.11.3 pro10：一般算式用數學慣例（−x^2 ＝ −(x²)、2^-3 可以寫）；試算表公式（有 resolve）維持 Excel 的算法（=-2^2 是 4）
  const mathMode = !resolve; const lvl = () => (mathMode ? munary() : pow());
  function munary() { if (isOp('-')) { next(); return -num(munary()); } if (isOp('+')) { next(); return num(munary()); } return mpow(); }
  function mpow() { const b = post(); if (isOp('^')) { next(); const e = munary(); return fix(num(b) ** num(e)); } return b; }
  function mul() { let l = lvl(); while (isOp('*') || isOp('/')) { const o = next().v; const r = lvl();
    if (o === '/') { if (num(r) === 0) throw new Error('除以 0'); l = fix(num(l) / num(r)); } else l = fix(num(l) * num(r)); } return l; }
  function pow() { let b = unary(); if (isOp('^')) { next(); const e = pow(); return fix(num(b) ** num(e)); } return b; }
  function unary() { if (isOp('-')) { next(); return -num(unary()); } if (isOp('+')) { next(); return num(unary()); } return post(); }
  function post() { let v = atom(); while (isOp('%') || isOp('!')) { if (next().v === '!') v = FN.FACT(num(v)); else v = fix(num(v) / 100); } return v; }
  function atom() {
    const k = next(); if (!k) throw new Error('算式不完整');
    if (k.k === 'num') return k.v; if (k.k === 'str') return k.v;
    if (k.k === 'op' && k.v === '(') { const v = cmp(); if (!isOp(')')) throw new Error('少了右括號'); next(); return v; }
    if (k.k === 'ref') { if (vars && vars[k.v] !== undefined) return vars[k.v]; if (!resolve) throw new Error('這裡不能用儲存格參照'); return resolve(k.v); }
    if (k.k === 'id') {
      if (!isOp('(')) { if (vars && vars[k.v] !== undefined) return vars[k.v]; if (k.v === 'TRUE') return true; if (k.v === 'FALSE') return false; if (k.v === 'PI') return Math.PI; if (k.v === 'E') return Math.E; throw new Error(`不認得「${k.v}」`); }
      next(); const args = []; if (!isOp(')')) { do { args.push(cmp()); if (isOp(',')) next(); else break; } while (true); }
      if (!isOp(')')) throw new Error('函式少了右括號'); next();
      const f = FN[k.v]; if (!f) throw new Error(`不支援函式 ${k.v}`); const r = f(...args); return typeof r === 'number' ? fix(r) : r;
    }
    throw new Error('語法錯誤');
  }
  const v = cmp(); if (p < t.length) throw new Error('算式後面多出內容'); return v;
}
module.exports = { evaluate, FN, CONSTS };
