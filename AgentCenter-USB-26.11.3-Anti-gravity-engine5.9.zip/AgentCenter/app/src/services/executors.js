'use strict';
const fs = require('fs');
const path = require('path');
const { Readable } = require('stream');
const { pipeline } = require('stream/promises');
const web = require('./web');
const { clip } = require('../core/util');

/** 審批核准後真正去做的事 */
function register(ctx) {
  ctx.approvals.register('download', async (p) => {
    if (p.cmd) return ctx.terminal._run(p.cmd, 600000, null);
    const b = web.blocked(p.url); if (b) throw new Error(b);
    const dest = ctx.fsx.resolve(p.path, 'workspace'); fs.mkdirSync(path.dirname(dest), { recursive: true });
    const res = await fetch(p.url, { redirect: 'follow', headers: { 'user-agent': 'LineAgent/1.4' }, signal: AbortSignal.timeout(600000) }); if (!res.ok) throw new Error('HTTP ' + res.status);
    let n = 0; const MAX = 200 * 1024 * 1024; const src = Readable.fromWeb(res.body);
    src.on('data', (c) => { n += c.length; if (n > MAX) src.destroy(new Error('檔案超過 200MB 上限')); });
    await pipeline(src, fs.createWriteStream(dest)); ctx.store.audit('system', 'download', `${p.url} -> ${dest} (${n}B)`); return `已下載 ${n} bytes 到 workspace/${p.path}`;
  });
  // Google API 通道：審批核准後才真的寄信／執行有副作用的 API 呼叫
  ctx.approvals.register('perm_request', async (p) => { const u = ctx.users.byId(p.pid); if (!u) throw new Error('使用者已不存在'); if (!u.perms.allow.includes(p.perm)) u.perms.allow.push(p.perm); u.perms.deny = u.perms.deny.filter((x) => x !== p.perm); ctx.store.touch(); await ctx.hub.sendToPerson(u, `管理員已開放「${p.perm}」給你，現在可以用了。`).catch(() => {}); return `已開放 ${p.perm} 給 ${u.name || u.id}`; });
  ctx.approvals.register('phone_sms', async (p) => ctx.phone.smsSend(p.number, p.text));
  ctx.approvals.register('phone_call', async (p) => ctx.phone.call(p.number));
  ctx.approvals.register('gmail_send', async (p) => { const r = await ctx.gws.gmailSend(p); return `已寄出（messageId ${r.id}）`; });
  ctx.approvals.register('google_api', async (p) => { const r = await ctx.gws.api(p.method, p.url, { query: p.query, body: p.body }); ctx.store.audit('system', 'google.api', `${p.method} ${p.url}`); return clip(typeof r === 'string' ? r : JSON.stringify(r), 1500); });
  ctx.approvals.register('skill_import', async (p) => {
    // engine5：GitHub 網頁網址 → 原始檔；技能資料夾網址 → 資料夾裡的 SKILL.md
    let url = String(p.url).trim(); const gh = /^https?:\/\/github\.com\/([^/]+)\/([^/]+)\/(blob|tree)\/([^/]+)\/(.+?)\/?$/.exec(url);
    if (gh) url = `https://raw.githubusercontent.com/${gh[1]}/${gh[2]}/${gh[4]}/${gh[5]}${gh[3] === 'tree' && !/\.md$/i.test(gh[5]) ? '/SKILL.md' : ''}`;
    const pg = await web.fetchPage(url, 60000); const isSkill = /^﻿?---\r?\n[\s\S]*?\r?\n---/.test(pg.text);
    const r = ctx.skills.importText(isSkill ? pg.text : `# ${p.name || '匯入的技能'}\n> 來源：${p.url}\n\n${pg.text}`, { source: p.url, name: p.name });
    return `已匯入技能「${r.name}」（第三方，AI 讀的時候會附警語，不會被自動套用）${r.risks.length ? `。⚠ 掃描到：${r.risks.join('、')}，請先用 skill_read 看過內容` : ''}`;
  });
}
module.exports = { register };
