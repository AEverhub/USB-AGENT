'use strict';
/**
 * 26.11.3 Anti-gravity-engine4：影片素材（讓 AI 做的影片有「人聲」與「真人影像」）
 *  ・narrate()：用 App 現有的雲端語音包（Gemini TTS／OpenAI TTS）把每格旁白念成音檔；精準量出長度（WAV 讀檔頭、MP3 讀影格）
 *  ・stock()：Pexels 實拍影片（免費金鑰；Pexels 授權可商用、不強制標示，我們仍在片尾列出攝影者）
 *  ・presenter()：HeyGen v3 數位主持人（真人外觀＋口型同步＋人聲；付費、選用）
 *  ・aiClip()：Gemini Omni Flash 文字生成實景影片（付費、預設關閉；依公開文件實作，未實測）
 *  ・capture()：把網址截成畫面（產品宣傳片用，像 Video Shotcraft 的「抓真實頁面」）
 *  ・musicWav()：在 Node 端合成背景音樂 WAV（給 HyperFrames 引擎用；手機內建引擎用 Web Audio 即時合成）
 * 所有金鑰只從設定讀、不進提示、不寫進紀錄。
 */
const fs = require('fs');
const path = require('path');
const { rid, clip } = require('../core/util');
const llm = require('../llm');

const UA = 'AgentControlCenter/26.11 (Android personal assistant; video maker)';
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
async function fetchBuf(url, { headers = {}, max = 60 * 1024 * 1024, timeout = 120000 } = {}) {
  const r = await fetch(url, { headers, signal: AbortSignal.timeout(timeout) }); if (!r.ok) throw new Error(`下載失敗 HTTP ${r.status}`);
  const len = +r.headers.get('content-length') || 0; if (len > max) throw new Error(`檔案太大（${Math.round(len / 1048576)} MB）`);
  const buf = Buffer.from(await r.arrayBuffer()); if (buf.length > max) throw new Error('檔案太大'); return buf;
}
/** WAV 長度（秒）：讀 fmt 的 byteRate 與 data 長度 */
function wavDuration(buf) {
  if (!buf || buf.length < 44 || buf.toString('latin1', 0, 4) !== 'RIFF' || buf.toString('latin1', 8, 12) !== 'WAVE') return 0;
  let p = 12, byteRate = 0; while (p + 8 <= buf.length) { const id = buf.toString('latin1', p, p + 4); const sz = buf.readUInt32LE(p + 4); if (id === 'fmt ') byteRate = buf.readUInt32LE(p + 16); if (id === 'data') return byteRate ? Math.min(sz, buf.length - p - 8) / byteRate : 0; p += 8 + sz + (sz % 2); }
  return 0;
}
/** MP3 長度（秒）：逐格讀 MPEG 影格標頭（CBR／VBR 都準） */
function mp3Duration(buf) {
  if (!buf || buf.length < 4) return 0; let p = 0;
  if (buf.toString('latin1', 0, 3) === 'ID3') p = 10 + ((buf[6] & 0x7f) << 21 | (buf[7] & 0x7f) << 14 | (buf[8] & 0x7f) << 7 | (buf[9] & 0x7f));
  const BR = { 1: [0, 32, 40, 48, 56, 64, 80, 96, 112, 128, 160, 192, 224, 256, 320], 2: [0, 8, 16, 24, 32, 40, 48, 56, 64, 80, 96, 112, 128, 144, 160] };
  const SR = { 3: [44100, 48000, 32000], 2: [22050, 24000, 16000], 0: [11025, 12000, 8000] }; let sec = 0, frames = 0;
  while (p + 4 <= buf.length) {
    if (buf[p] !== 0xff || (buf[p + 1] & 0xe0) !== 0xe0) { p++; continue; }
    const ver = (buf[p + 1] >> 3) & 3, layer = (buf[p + 1] >> 1) & 3, bri = (buf[p + 2] >> 4) & 15, sri = (buf[p + 2] >> 2) & 3, pad = (buf[p + 2] >> 1) & 1;
    if (ver === 1 || layer !== 1 || bri === 0 || bri === 15 || sri === 3) { p++; continue; }   // 只算 Layer III
    const br = BR[ver === 3 ? 1 : 2][bri] * 1000, sr = SR[ver][sri], spf = ver === 3 ? 1152 : 576; const len = Math.floor((spf / 8) * br / sr) + pad; if (len < 4) { p++; continue; }
    sec += spf / sr; frames++; p += len;
  }
  return frames ? sec : 0;
}
/** 嘴型軌跡（免費主持人對嘴用）：WAV 每 1/15 秒的音量 → 0～9 的字串；不是 WAV 回空字串（改用假對嘴） */
function mouthTrack(buf, fps = 15) {
  if (!buf || buf.length < 44 || buf.toString('latin1', 0, 4) !== 'RIFF') return '';
  let p = 12, ch = 1, sr = 0, bits = 16, data = -1, len = 0; while (p + 8 <= buf.length) { const id = buf.toString('latin1', p, p + 4); const sz = buf.readUInt32LE(p + 4); if (id === 'fmt ') { ch = buf.readUInt16LE(p + 10); sr = buf.readUInt32LE(p + 12); bits = buf.readUInt16LE(p + 22); } if (id === 'data') { data = p + 8; len = Math.min(sz, buf.length - data); break; } p += 8 + sz + (sz % 2); }
  if (data < 0 || !sr || bits !== 16) return ''; const step = Math.max(1, Math.round(sr / fps)) * ch * 2; const rms = [];
  for (let o = data; o + 2 <= data + len && rms.length < 4000; o += step) { let sum = 0, n = 0; for (let k = o; k + 2 <= Math.min(o + step, data + len); k += 2 * ch) { const v = buf.readInt16LE(k) / 32768; sum += v * v; n++; } rms.push(n ? Math.sqrt(sum / n) : 0); }
  const sorted = rms.slice().sort((a, b) => a - b); const ref = sorted[Math.floor(sorted.length * 0.95)] || 0; if (ref < 0.003) return '0'.repeat(rms.length);
  return rms.map((r) => { const x = r / ref; return x < 0.12 ? '0' : String(Math.min(9, Math.round(x * 9))); }).join('');
}
const audioDuration = (buf, mime) => (/wav/.test(mime || '') ? wavDuration(buf) : mp3Duration(buf)) || wavDuration(buf) || mp3Duration(buf);

/** 背景音樂 WAV（16 位元單聲道 22.05kHz）：和手機內建引擎同一組和弦（I–V–vi–IV） */
function musicWav(kind, seconds) {
  const sr = 22050; const n = Math.max(1, Math.round(sr * Math.min(200, Math.max(1, seconds)))); const out = new Float32Array(n);
  const CH = [[261.63, 329.63, 392.0], [196.0, 246.94, 293.66], [220.0, 261.63, 329.63], [174.61, 220.0, 261.63]];
  const add = (f, t0, dur, vol, atk, rel, wave = 'sine') => { const a = Math.floor(t0 * sr), b = Math.min(n, Math.floor((t0 + dur) * sr)); for (let i = Math.max(0, a); i < b; i++) { const t = (i - a) / sr; const env = Math.min(1, t / atk) * Math.min(1, (dur - t) / rel); const ph = 2 * Math.PI * f * t; const w = wave === 'tri' ? (2 / Math.PI) * Math.asin(Math.sin(ph)) : Math.sin(ph); out[i] += w * vol * Math.max(0, env); } };
  if (kind === 'upbeat') { for (let b = 0; b * 0.5 < seconds; b++) { const t = b * 0.5; const c = CH[Math.floor(b / 4) % 4]; c.forEach((f) => add(f, t, 0.3, 0.06, 0.01, 0.2, 'tri')); const a = Math.floor(t * sr); for (let i = 0; i < 0.16 * sr && a + i < n; i++) { const tt = i / sr; out[a + i] += Math.sin(2 * Math.PI * (130 - 500 * tt) * tt) * 0.45 * Math.exp(-tt * 22); } } }
  else if (kind === 'cinematic') { add(65.41, 0, seconds, 0.1, 2, 2); add(98.0, 0, seconds, 0.06, 2, 2); for (let b = 0; b * 8 < seconds; b++) CH[(b * 2) % 4].forEach((f) => add(f, b * 8, 8.5, 0.09, 3, 3)); }
  else if (kind !== 'none') { for (let b = 0; b * 4 < seconds; b++) { const c = CH[b % 4]; c.forEach((f) => { add(f, b * 4, 4.6, 0.14, 0.9, 1.2); add(f * 2, b * 4, 4.6, 0.025, 1.2, 1.2, 'tri'); }); add(c[0] / 2, b * 4, 4, 0.18, 0.4, 0.8); } }
  const fade = Math.min(n, Math.round(1.5 * sr)); for (let i = 0; i < fade; i++) out[n - 1 - i] *= i / fade;
  let peak = 0; for (let i = 0; i < n; i++) peak = Math.max(peak, Math.abs(out[i])); const g = peak > 0 ? 0.55 / peak : 0;
  const buf = Buffer.alloc(44 + n * 2); buf.write('RIFF', 0, 'latin1'); buf.writeUInt32LE(36 + n * 2, 4); buf.write('WAVE', 8, 'latin1'); buf.write('fmt ', 12, 'latin1'); buf.writeUInt32LE(16, 16); buf.writeUInt16LE(1, 20); buf.writeUInt16LE(1, 22); buf.writeUInt32LE(sr, 24); buf.writeUInt32LE(sr * 2, 28); buf.writeUInt16LE(2, 32); buf.writeUInt16LE(16, 34); buf.write('data', 36, 'latin1'); buf.writeUInt32LE(n * 2, 40);
  for (let i = 0; i < n; i++) buf.writeInt16LE(Math.max(-32767, Math.min(32767, Math.round(out[i] * g * 32767))), 44 + i * 2); return buf;
}

class VidMedia {
  constructor(ctx) { this.ctx = ctx; }
  get S() { return this.ctx.settings; }
  get cfg() { return { engine: 'auto', narration: true, voice_pack: '', auto_images: true, footage: true, pexels_key: '', heygen_key: '', heygen_avatar: '', heygen_voice: '', ai_clips: false, omni_model: 'gemini-omni-1.1-flash', free_stock: true, avatar: 'auto', device_voice: '', device_rate: 1.05, ...(this.S.get('video', {}) || {}) }; }
  dir(id) { const d = path.join(this.ctx.paths.workspace, 'videos', 'assets', id); fs.mkdirSync(d, { recursive: true }); return d; }
  save(id, name, buf) { const f = path.join(this.dir(id), name); fs.writeFileSync(f, buf); return path.relative(this.ctx.paths.workspace, f).split(path.sep).join('/'); }
  /** 哪些素材能用（給 UI 與 AI 看）；不回傳金鑰本身 */
  caps() {
    const c = this.cfg; const v = this.ctx.voice; const pack = this.voicePack();
    const dev = this.deviceVoice(); const usePack = c.voice_pack === 'device' ? null : pack;
    return { narration: !!(c.narration !== false && (usePack || dev)), voice: usePack ? usePack.name : dev ? '手機內建語音（免費）' : '', device_voice: dev, stock: c.footage !== false && (!!c.pexels_key || c.free_stock !== false), stock_source: c.footage === false ? '' : c.pexels_key ? 'Pexels＋Wikimedia Commons' : c.free_stock !== false ? 'Wikimedia Commons（免費）' : '', presenter: !!c.heygen_key, avatar: c.avatar !== 'off', ai_clips: !!c.ai_clips && !!this.geminiKey(), images: c.auto_images !== false && !!this.ctx.imagegen, has_voice_service: !!v, web_shot: !!(this.ctx.browser && this.ctx.browser.enabled && this.ctx.browser.enabled()), app_shot: this.appShotReady() };
  }
  /** 旁白用的語音包：設定指定的 → 目前語音包 → 第一個可用的雲端語音包；手機內建的聲音沒辦法錄進影片，所以不用 */
  voicePack() {
    const v = this.ctx.voice; if (!v) return null; let list = []; try { list = v.packs().filter((p) => p.available && p.provider !== 'device'); } catch { return null; }
    const want = this.cfg.voice_pack; let cur = null; try { cur = v.current(); } catch { /* ignore */ }
    return list.find((p) => p.id === want) || (cur && list.find((p) => p.id === cur.id)) || list[0] || null;
  }
  /** 免費旁白：手機內建語音（Android TextToSpeech 錄成 WAV）。只有在 Android App 裡才有 */
  deviceVoice() { try { return !!(this.ctx.phone && this.ctx.phone.hasNative && this.ctx.phone.hasNative()) && this.cfg.voice_pack !== 'cloud-only'; } catch { return false; } }
  /** 挑最自然的手機聲音：已安裝、台灣中文優先、quality 最高 */
  /** 挑手機聲音；指定男／女時，先找名稱看得出性別的聲音（例如 …male…、#m、-m1）；找不到就用預設聲音＋音高（男 0.82、女 1.1）模擬 */
  async pickDeviceVoice(gender = '') {
    const key = gender || '-'; this._dv = this._dv || {}; if (this._dv[key]) return this._dv[key];
    let out = { voice: this.cfg.device_voice || '', pitch: 1, gender: '' };
    try { const r = await this.ctx.phone.ttsVoices(); const vs = (r.voices || []).filter((v) => v.installed !== false && /^(zh|cmn)/i.test(v.locale || ''));
      const g = (v) => (/female|#f|[-_]f\d|woman/i.test(v.name) ? 'female' : /(^|[^e])male|#m|[-_]m\d|man\b/i.test(v.name) ? 'male' : '');
      const score = (v) => (/TW|Hant/i.test(v.locale) ? 1000 : /CN|Hans/i.test(v.locale) ? 500 : 0) + (+v.quality || 0) - (v.network ? 50 : 0) + (gender && g(v) === gender ? 5000 : 0);
      vs.sort((a, b) => score(b) - score(a)); const best = vs[0];
      if (!this.cfg.device_voice && best) out.voice = best.name; out.guess = best && !this.cfg.device_voice ? g(best) : '';
      if (gender) { if (best && g(best) === gender && !this.cfg.device_voice) out.gender = gender; else { out.pitch = gender === 'male' ? 0.82 : 1.1; out.gender = gender; } }
    } catch { if (gender) out = { ...out, pitch: gender === 'male' ? 0.82 : 1.1, gender }; }
    this._dv[key] = out; return out;
  }
  async deviceLine(id, i, text, gender = '') {
    const dv = await this.pickDeviceVoice(gender); const r = await this.ctx.phone.ttsFile(text, `${id}-${i}`, { voice: dv.voice, rate: +this.cfg.device_rate || 1.05, pitch: dv.pitch });
    const src = path.join(this.ctx.paths.workspace, r.file); const buf = fs.readFileSync(src); try { fs.unlinkSync(src); } catch { /* ignore */ }
    const dur = audioDuration(buf, 'audio/wav') || Math.max(1, text.length * 0.24); return { file: this.save(id, `voice-${i}.wav`, buf), dur, mouth: mouthTrack(buf) };
  }
  /** 逐格錄旁白：有雲端語音包先用（Gemini／OpenAI）；沒有、或某格失敗（額度用完、限流）→ 改用手機內建語音（免費、離線也能用） */
  async narrate(id, scenes, { gender = '' } = {}) {
    const pack = this.cfg.voice_pack === 'device' ? null : this.voicePack(); const dev = this.deviceVoice();
    const VO = require('./voice'); let voiceOverride = '';
    if (pack && gender && VO.VOICE_GENDER[pack.voice] !== gender) voiceOverride = (VO.GENDER_VOICE[pack.provider] || {})[gender] || '';
    const usedGender = gender || (pack ? VO.VOICE_GENDER[pack.voice] || '' : '');
    if (!pack && !dev) return { ok: false, why: '沒有可錄進影片的語音：在 Android App 裡會自動用手機內建語音（免費）；也可以在模型頁加 Gemini 或 OpenAI 金鑰' };
    let n = 0, nd = 0; const fail = []; let cloudDown = !pack, switched = '';
    for (let i = 0; i < scenes.length; i++) {
      const t = clip(String(scenes[i].narration || '').trim(), 300); if (!t) continue;
      if (!cloudDown) { try { const r = await this.ctx.voice.tts(t, pack.id, voiceOverride ? { voice: voiceOverride } : {}); if (!r || !r.buf) throw new Error('沒有音檔'); const ext = /wav/.test(r.mime) ? 'wav' : 'mp3'; scenes[i].voice = this.save(id, `voice-${i}.${ext}`, r.buf); scenes[i].voice_dur = Math.round(audioDuration(r.buf, r.mime) * 100) / 100; scenes[i].mouth = mouthTrack(r.buf); n++; continue; }
        catch (e) { if (!dev) { fail.push(`第 ${i + 1} 格：${e.message}`); continue; } cloudDown = true; switched = `雲端語音失敗（${clip(e.message, 80)}），其餘改用手機內建語音`; } }
      try { const r = await this.deviceLine(id, i, t, gender || usedGender); scenes[i].voice = r.file; scenes[i].voice_dur = Math.round(r.dur * 100) / 100; scenes[i].mouth = r.mouth; n++; nd++; } catch (e) { fail.push(`第 ${i + 1} 格：${e.message}`); }
    }
    const devG = nd && !usedGender ? ((this._dv && this._dv['-'] && this._dv['-'].guess) || 'female') : '';   // 手機預設中文聲音大多是女聲
    return { ok: n > 0, count: n, switched, gender: usedGender || devG, voice: nd === n && n ? '手機內建語音（免費）' : nd ? `${pack.name}＋手機內建語音` : pack ? pack.name : '', device: nd, fail };
  }
  /** 實拍素材：有 Pexels 金鑰先用 Pexels；沒有或失敗 → Wikimedia Commons（不用金鑰、自由授權） */
  async stock(id, i, query, size) {
    if (this.cfg.footage === false) return null;
    if (this.cfg.pexels_key) { try { const r = await this.pexels(id, i, query, size); if (r) return r; } catch (e) { if (this.cfg.free_stock === false) throw e; } }
    if (this.cfg.free_stock === false) return null;
    return this.commons(id, i, query, size);
  }
  /** Wikimedia Commons 影片（免費、免金鑰）：只收自由授權（CC0／公有領域／CC BY／CC BY-SA），片尾列作者與授權 */
  async commons(id, i, query, size) {
    const q = clip(String(query || '').replace(/[^\w\s\u3400-\u9fff-]/g, ' ').trim(), 80); if (!q) return null;
    const u = 'https://commons.wikimedia.org/w/api.php?' + new URLSearchParams({ action: 'query', format: 'json', formatversion: '2', generator: 'search', gsrnamespace: '6', gsrsearch: `filetype:video ${q}`, gsrlimit: '12', prop: 'videoinfo', viprop: 'url|size|mime|derivatives|extmetadata', origin: '*' });
    const r = await fetch(u, { headers: { 'user-agent': UA, 'api-user-agent': UA }, signal: AbortSignal.timeout(20000) }); if (!r.ok) throw new Error(`Wikimedia Commons HTTP ${r.status}`);
    const j = await r.json(); const pages = ((j.query && j.query.pages) || []).slice().sort((a, b) => (a.index || 0) - (b.index || 0));
    const want = size === 'portrait' ? 'p' : size === 'square' ? 's' : 'l';
    for (const p of pages) {
      const vi = (p.videoinfo || [])[0]; if (!vi) continue; const em = vi.extmetadata || {}; const val = (k) => String((em[k] && em[k].value) || '').replace(/<[^>]*>/g, '').replace(/&amp;/g, '&').replace(/&quot;/g, '"').replace(/&#0?39;/g, "'").replace(/\s+/g, ' ').trim();
      const lic = val('LicenseShortName'); if (!/^(cc0|cc[- ]by(-sa)?\b|public domain|pd\b|pd-)/i.test(lic) || /nc|nd/i.test(lic.replace(/^cc[- ]by(-sa)?/i, ''))) continue;
      const dur = +(vi.duration || 0); if (dur && dur < 3) continue;
      const cand = [...(vi.derivatives || []), { src: vi.url, type: vi.mime, width: vi.width, height: vi.height, size: vi.size }].filter((d) => d && d.src && /video\/(webm|mp4)/.test(d.type || '') && +d.width && +d.height && !/\.(ogv|ogg)$/i.test(d.src));
      if (!cand.length) continue;
      const orient = (d) => (d.height > d.width * 1.1 ? 'p' : d.width > d.height * 1.1 ? 'l' : 's');
      cand.sort((a, b) => (orient(a) === want ? 0 : 1) - (orient(b) === want ? 0 : 1) || Math.abs(Math.max(a.width, a.height) - 1280) - Math.abs(Math.max(b.width, b.height) - 1280) || (/mp4/.test(a.type) ? -1 : 1));
      for (const d of cand.slice(0, 2)) {
        try { const buf = await fetchBuf(d.src, { headers: { 'user-agent': UA }, max: 40 * 1024 * 1024, timeout: 120000 }); const ext = /mp4/.test(d.type) ? 'mp4' : 'webm';
          const who = clip(val('Artist') || '作者', 40); return { file: this.save(id, `stock-${i}.${ext}`, buf), credit: `Wikimedia Commons／${who}（${lic}）`, url: vi.descriptionurl || '', duration: dur, free: true };
        } catch { /* 試下一個 */ }
      }
    }
    return null;
  }
  /** Pexels 實拍：挑最接近 720p 的 mp4 */
  async pexels(id, i, query, size) {
    const key = this.cfg.pexels_key; if (!key) return null;
    const ori = { portrait: 'portrait', landscape: 'landscape', square: 'square' }[size] || 'portrait';
    const r = await fetch(`https://api.pexels.com/videos/search?query=${encodeURIComponent(clip(query, 80))}&orientation=${ori}&size=medium&per_page=8`, { headers: { authorization: key }, signal: AbortSignal.timeout(20000) });
    if (!r.ok) throw new Error(r.status === 401 || r.status === 403 ? 'Pexels 金鑰無效' : `Pexels HTTP ${r.status}`);
    const j = await r.json(); const vids = (j.videos || []).filter((v) => v && Array.isArray(v.video_files) && v.duration >= 3);
    for (const v of vids) {
      const files = v.video_files.filter((f) => /mp4/.test(f.file_type || '') && f.link && f.width && f.height).sort((a, b) => Math.abs(Math.max(a.width, a.height) - 1280) - Math.abs(Math.max(b.width, b.height) - 1280));
      if (!files.length) continue;
      try { const buf = await fetchBuf(files[0].link, { max: 40 * 1024 * 1024, timeout: 90000 }); return { file: this.save(id, `stock-${i}.mp4`, buf), credit: `Pexels／${clip(String((v.user && v.user.name) || '攝影者'), 40)}`, url: v.url || '', duration: v.duration }; } catch { /* 試下一支 */ }
    }
    return null;
  }
  geminiKey() { try { const c = llm.keyCandidates(this.S, 'gemini').find(llm.usable); return c && c.key; } catch { return ''; } }
  /** Gemini Omni Flash：文字 → 實景影片（付費）。依公開文件格式；回應格式寬鬆處理（inline base64 或 uri） */
  async aiClip(id, i, prompt, size) {
    if (!this.cfg.ai_clips) return null; const key = this.geminiKey(); if (!key) throw new Error('沒有 Gemini 金鑰');
    const base = 'https://generativelanguage.googleapis.com/v1beta'; const H = { 'x-goog-api-key': key, 'content-type': 'application/json' };
    const body = { model: this.cfg.omni_model || 'gemini-omni-1.1-flash', input: clip(String(prompt), 800) + '. Realistic, no text overlays, no logos, fictional people only.', response_format: { type: 'video', aspect_ratio: size === 'landscape' ? '16:9' : '9:16', resolution: '720p' } };
    let r = await fetch(`${base}/interactions`, { method: 'POST', headers: H, body: JSON.stringify(body), signal: AbortSignal.timeout(420000) });
    let j = await r.json().catch(() => ({})); if (!r.ok) throw new Error(`Gemini Omni ${r.status}：${clip(String((j.error && j.error.message) || ''), 200)}`);
    const t0 = Date.now(); while (!findVideo(j) && (j.status === 'in_progress' || j.status === 'running' || j.done === false) && j.id && Date.now() - t0 < 480000) { await sleep(8000); r = await fetch(`${base}/interactions/${encodeURIComponent(j.id)}`, { headers: H, signal: AbortSignal.timeout(30000) }); j = await r.json().catch(() => ({})); }
    const v = findVideo(j); if (!v) throw new Error('Gemini Omni 沒有回傳影片');
    const buf = v.data ? Buffer.from(v.data, 'base64') : await fetchBuf(v.uri + (v.uri.includes('?') ? '&' : '?') + 'alt=media', { headers: { 'x-goog-api-key': key }, max: 60 * 1024 * 1024 });
    return { file: this.save(id, `ai-${i}.mp4`, buf), credit: 'AI 生成影像（Gemini Omni）' };
  }
  /** HeyGen v3：數位主持人念完整旁白（口型同步）。回傳 { file, duration } */
  async presenter(id, script, size, onStage = () => {}) {
    const key = this.cfg.heygen_key; if (!key) throw new Error('沒有設定 HeyGen 金鑰'); const H = { 'x-api-key': key, 'content-type': 'application/json' }; const B = 'https://api.heygen.com';
    let avatar = this.cfg.heygen_avatar;
    if (!avatar) { for (const u of ['/v3/avatars/looks?ownership=public&limit=1', '/v3/avatars?ownership=public&limit=1']) { try { const r = await fetch(B + u, { headers: H, signal: AbortSignal.timeout(20000) }); const j = await r.json(); const d = (j.data || [])[0]; if (d && d.id) { avatar = d.id; break; } } catch { /* 試下一個 */ } } }
    if (!avatar) throw new Error('找不到可用的 HeyGen 主持人，請在影片設定填入 avatar id');
    const body = { type: 'avatar', avatar_id: avatar, script: clip(String(script), 4800), aspect_ratio: size === 'landscape' ? '16:9' : size === 'square' ? '1:1' : '9:16', resolution: '720p', title: 'agent-' + id, ...(this.cfg.heygen_voice ? { voice_id: this.cfg.heygen_voice } : {}) };
    let r = await fetch(B + '/v3/videos', { method: 'POST', headers: { ...H, 'idempotency-key': 'agent-' + id }, body: JSON.stringify(body), signal: AbortSignal.timeout(60000) }); let j = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(`HeyGen ${r.status}：${clip(String((j.error && (j.error.message || j.error)) || j.message || ''), 200)}`);
    const vid = j.data && (j.data.video_id || j.data.id); if (!vid) throw new Error('HeyGen 沒有回傳影片 id');
    const t0 = Date.now(); onStage('數位主持人製作中');
    while (Date.now() - t0 < 25 * 60e3) {
      await sleep(this._pollMs || 10000); r = await fetch(`${B}/v3/videos/${encodeURIComponent(vid)}`, { headers: H, signal: AbortSignal.timeout(30000) }); j = await r.json().catch(() => ({})); const d = j.data || {};
      if (d.status === 'failed') throw new Error('HeyGen 製作失敗：' + clip(String(d.failure_message || d.failure_code || ''), 200));
      if (d.status === 'completed' && d.video_url) { const buf = await fetchBuf(d.video_url, { max: 120 * 1024 * 1024, timeout: 180000 }); return { file: this.save(id, 'presenter.mp4', buf), duration: +d.duration || 0, credit: 'HeyGen 數位主持人' }; }
    }
    throw new Error('HeyGen 超過 25 分鐘還沒做好');
  }
  /** 不知道網址：用網路搜尋找第一個公開網址 */
  async findUrl(query) {
    const web = require('./web'); const r = await web.search(clip(String(query || ''), 80), 5); const hit = (r || []).find((x) => x && publicUrl(x.url));
    if (!hit) throw new Error(`搜尋「${clip(String(query), 30)}」找不到可以截圖的網頁`); return hit.url;
  }
  /** 手機上其他 App 的畫面（手機代理）：打開 App → 依序點按鈕文字（只瀏覽）→ 等某段文字出現 → 截圖 → 回主畫面。只給管理員的影片用 */
  appShotReady() { const P = this.ctx.phoneagent; try { return !!(P && P.endpoint()); } catch { return false; } }
  async appShot(id, i, { app, taps = [], find = '' } = {}) {
    const P = this.ctx.phoneagent; if (!this.appShotReady()) throw new Error('手機代理沒有開（要在 App 的「手機代理」打開無障礙服務）');
    if (P.task) throw new Error('手機代理正在做別的事');
    const hit = await P.openApp(String(app || '')); await sleep(2500);
    for (const t of (Array.isArray(taps) ? taps : []).slice(0, 3)) { const x = clip(String(t || '').trim(), 30); if (!x) continue; if (/送出|發送|傳送|付款|購買|刪除|確認|send|pay|buy|delete|submit/i.test(x)) throw new Error(`為了安全，截圖時不點「${x}」這類按鈕`); await P.tap({ text: x }); await sleep(1500); }
    if (find) await P.waitText(clip(String(find), 40), 8);
    const buf = await P.shot(); try { await P.key('home'); } catch { /* ignore */ }
    if (!buf || buf.length < 1000) throw new Error('截圖失敗（要 Android 11 以上）'); return { file: this.save(id, `app-${i}.jpg`, buf), app: hit.label };
  }
  /** 把網址截成圖（產品宣傳片：真實頁面當素材） */
  async capture(id, i, url, { find = '' } = {}) {
    if (!publicUrl(url)) throw new Error('只能截公開網站（不截本機、區網、內部位址）');
    const B = this.ctx.browser; if (!B || !B.run) throw new Error('瀏覽器服務沒有啟動');
    const buf = await B.run(async () => { await B.goto(url); await sleep(1200);
      // 要截「某個地方」：找到含這段文字的元素，捲到畫面中間再截
      if (find && B.evalPage) { try { await B.evalPage(FIND_SCROLL, clip(String(find), 60)); await sleep(700); } catch { /* 找不到就截頁首 */ } }
      return B.screenshot({ quality: 82, maxW: 1280 }); }, 'video');
    if (!buf || !buf.length) throw new Error('截圖失敗'); return { file: this.save(id, `page-${i}.jpg`, Buffer.isBuffer(buf) ? buf : Buffer.from(buf)) };
  }
}
const FIND_SCROLL = `(t) => { const w = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT); let n; while ((n = w.nextNode())) { if (n.nodeValue && n.nodeValue.includes(t)) { const el = n.parentElement; if (el && el.getBoundingClientRect().height > 0) { el.scrollIntoView({ block: 'center' }); el.style.outline = '4px solid rgba(91,140,255,.85)'; el.style.outlineOffset = '6px'; return true; } } } return false; }`;
/** 只允許公開網址：任何人都能叫 AI 做影片，不能借截圖看到手機本機或區網的頁面（例如 App 自己的後台、路由器） */
function publicUrl(u) {
  let x; try { x = new URL(String(u)); } catch { return false; } if (!/^https?:$/.test(x.protocol) || x.username || x.password) return false;
  const h = x.hostname.toLowerCase().replace(/^\[|\]$/g, '');
  if (!h || h === 'localhost' || /\.(localhost|local|internal|lan|home|arpa)$/.test(h) || !h.includes('.') && !h.includes(':')) return false;
  if (h.includes(':')) return !/^(::|::1|fe[89ab]|f[cd]|::ffff:)/.test(h);
  const m = /^(\d+)\.(\d+)\.(\d+)\.(\d+)$/.exec(h); if (/^[\d.]+$/.test(h) && !m) return false;
  if (m) { const [a, b] = [+m[1], +m[2]]; if (a === 0 || a === 10 || a === 127 || a >= 224 || (a === 169 && b === 254) || (a === 172 && b >= 16 && b <= 31) || (a === 192 && b === 168) || (a === 100 && b >= 64 && b <= 127)) return false; }
  if (/^0x|^\d+$/.test(h)) return false; return true;
}
/** 在回應裡找影片（{data|bytes|uri, mime}），容忍不同層級的欄位名稱 */
function findVideo(o, depth = 0) {
  if (!o || typeof o !== 'object' || depth > 6) return null;
  const mime = o.mime_type || o.mimeType || ''; const data = o.data || o.bytes || o.video_bytes; const uri = o.uri || o.file_uri || o.fileUri || o.url;
  if ((/video/.test(mime) || /video/i.test(Object.keys(o).join(','))) && (typeof data === 'string' && data.length > 1000)) return { data };
  if (typeof uri === 'string' && /^https?:/.test(uri) && (/video/.test(mime) || /video|files\//i.test(uri))) return { uri };
  for (const k of ['output_video', 'video', 'outputs', 'output', 'response', 'result', 'generated_videos', 'candidates', 'parts', 'content', 'inline_data', 'inlineData', 'file']) { const v = o[k]; if (Array.isArray(v)) { for (const x of v) { const f = findVideo(x, depth + 1); if (f) return f; } } else if (v && typeof v === 'object') { const f = findVideo(v, depth + 1); if (f) return f; } }
  return null;
}

module.exports = { mouthTrack, publicUrl, VidMedia, wavDuration, mp3Duration, audioDuration, musicWav, findVideo, rid };
