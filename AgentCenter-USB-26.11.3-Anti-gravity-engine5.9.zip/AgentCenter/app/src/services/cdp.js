'use strict';
/**
 * 極簡 Chrome DevTools Protocol 用戶端（只靠 ws）。
 * 一條連線＝一個分頁（page-level websocket），所以同一份程式碼可以同時操作：
 *   ・桌機／伺服器上的 Chrome／Chromium／Edge（TCP，--remote-debugging-port）
 *   ・遠端的 CDP 端點（cdp_url）
 *   ・Android App 內的 WebView（走抽象 unix socket：@webview_devtools_remote_<pid>）
 */
const http = require('http');
const net = require('net');

function headersFor(tp) {
  const headers = { ...(tp.headers || {}) };
  for (const k of Object.keys(headers)) if (k.toLowerCase() === 'host') delete headers[k];
  headers.host = tp.hostHeader || tp.host || 'localhost';
  return headers;
}

/** transport: {host, port} 走 TCP；{sock} 走 unix socket（抽象 socket 以 \0 開頭） */
function httpGet(tp, path, method = 'GET', timeout = 6000) {
  return new Promise((resolve, reject) => {
    const opt = { method, path, headers: headersFor(tp), timeout };
    if (tp.sock) opt.createConnection = () => net.connect({ path: tp.sock }); else { opt.host = tp.host || '127.0.0.1'; opt.port = tp.port; }
    const req = http.request(opt, (res) => { const c = []; res.on('data', (d) => c.push(d)); res.on('end', () => { const t = Buffer.concat(c).toString('utf8'); if (res.statusCode >= 400) return reject(new Error(`HTTP ${res.statusCode} ${t.slice(0, 100)}`)); try { resolve(JSON.parse(t)); } catch { resolve(t); } }); });
    req.on('timeout', () => req.destroy(new Error('連線逾時'))); req.on('error', reject); req.end();
  });
}

class CDP {
  constructor() { this.ws = null; this.id = 0; this.pending = new Map(); this.handlers = new Map(); this.open = false; this.onclose = null; }
  connect(tp, wsPath, timeout = 8000) {
    const WebSocket = require('ws');
    return new Promise((resolve, reject) => {
      const opt = { perMessageDeflate: false, maxPayload: 64 * 1024 * 1024, handshakeTimeout: timeout, headers: headersFor(tp) };
      let url;
      if (tp.sock) { opt.createConnection = () => net.connect({ path: tp.sock }); url = 'ws://localhost' + wsPath; }
      else url = `ws://${tp.host || '127.0.0.1'}:${tp.port}${wsPath}`;
      const ws = new WebSocket(url, opt); this.ws = ws;
      ws.once('open', () => { this.open = true; resolve(); });
      ws.once('error', (e) => { if (!this.open) reject(e); });
      ws.on('message', (d) => this._msg(d));
      ws.on('close', () => { this.open = false; for (const [, p] of this.pending) { clearTimeout(p.t); p.rej(new Error('瀏覽器連線已中斷')); } this.pending.clear(); if (this.onclose) this.onclose(); });
    });
  }
  _msg(d) {
    let m; try { m = JSON.parse(d.toString()); } catch { return; }
    if (m.id && this.pending.has(m.id)) { const p = this.pending.get(m.id); this.pending.delete(m.id); clearTimeout(p.t); if (m.error) p.rej(new Error(`${p.method}：${m.error.message}`)); else p.res(m.result || {}); }
    else if (m.method) for (const f of this.handlers.get(m.method) || []) { try { f(m.params || {}); } catch { /* ignore */ } }
  }
  send(method, params = {}, timeout = 15000) {
    return new Promise((res, rej) => {
      if (!this.open) return rej(new Error('瀏覽器尚未連線')); const id = ++this.id;
      const t = setTimeout(() => { this.pending.delete(id); rej(new Error(`${method} 逾時（${Math.round(timeout / 1000)} 秒）`)); }, timeout);
      this.pending.set(id, { res, rej, t, method });
      try { this.ws.send(JSON.stringify({ id, method, params })); } catch (e) { clearTimeout(t); this.pending.delete(id); rej(e); }
    });
  }
  on(ev, fn) { if (!this.handlers.has(ev)) this.handlers.set(ev, []); this.handlers.get(ev).push(fn); }
  close() { this.open = false; try { this.ws && this.ws.close(); } catch { /* ignore */ } }
}
module.exports = { CDP, httpGet };
