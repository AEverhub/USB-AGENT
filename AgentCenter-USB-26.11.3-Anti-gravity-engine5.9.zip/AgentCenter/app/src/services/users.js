'use strict';
const { rid, hhmmToMin, zoned } = require('../core/util');

const ROLE_LABEL = { admin: '管理員', staff: '員工', user: '用戶', guest: '訪客' };

class Users {
  constructor(ctx) { this.ctx = ctx; }
  get db() { return this.ctx.store.db; }
  get S() { return this.ctx.settings; }

  list() { return Object.values(this.db.persons); }
  byId(id) { return this.db.persons[id] || null; }
  find(q) {
    const s = String(q || '').trim(); if (!s) return null; if (this.db.persons[s]) return this.db.persons[s];
    const low = s.toLowerCase(); const l = this.list();
    // 26.11.3 pro6：名字「部分相符」只在剛好一個人時才算——以前「明」會配到第一個名字含「明」的人，訊息就送錯人
    const exact = l.find((p) => p.name && p.name.toLowerCase() === low) || l.find((p) => p.identities.some((i) => i.uid === s || `${i.platform}:${i.uid}` === s || (i.name && i.name.toLowerCase() === low))); if (exact) return exact;
    const part = l.filter((p) => p.name && p.name.toLowerCase().includes(low)); return part.length === 1 ? part[0] : null;
  }
  /** 名字相符的人（給錯誤訊息列候選用） */
  matches(q) { const low = String(q || '').trim().toLowerCase(); if (!low) return []; return this.list().filter((p) => (p.name && p.name.toLowerCase().includes(low)) || p.identities.some((i) => i.name && i.name.toLowerCase().includes(low))); }
  byIdentity(platform, uid) { const pid = this.db.idmap[`${platform}:${uid}`]; return pid ? this.db.persons[pid] : null; }
  /** 使用次數限制（管理員設定「小明每天只能叫 5 次」）；管理員不受限 */
  quotaWindow(per) { const z = require('../core/util').zoned(Date.now(), this.ctx.settings.get('tz')); return per === 'hour' ? `${z.iso} ${z.hh}` : per === 'week' ? `${z.y}-W${Math.floor((Date.parse(z.iso) / 86400e3 + 4) / 7)}` : per === 'total' ? 'all' : z.iso; }
  quotaLeft(p) { const q = p && p.quota; if (!q || !q.limit || p.role === 'admin') return Infinity; const w = this.quotaWindow(q.per); if (q.window !== w) return q.limit; return Math.max(0, q.limit - (q.used || 0)); }
  quotaUse(p) { const q = p && p.quota; if (!q || !q.limit || p.role === 'admin') return; const w = this.quotaWindow(q.per); if (q.window !== w) { q.window = w; q.used = 0; } q.used = (q.used || 0) + 1; this.ctx.store.touch(); }
  admins() { return this.list().filter((p) => p.role === 'admin' && p.status === 'active'); }
  hasAdmin() { return this.admins().length > 0; }

  create({ platform, uid, name = '', role = 'guest', status = 'pending' }) {
    const id = 'p_' + rid(4);
    const p = { id, name: name || '', role, status, identities: [], perms: { allow: [], deny: [] },
      prefs: { news: true, greet: true, night_ok: false }, instructions: '', created: Date.now(), last_seen: Date.now(),
      profile: { style: '', notes: [], updated: 0 }, usage: { messages: 0, tokens: 0 } };
    this.db.persons[id] = p; if (platform) this.attach(id, platform, uid, name); this.ctx.store.touch(); return p;
  }
  attach(pid, platform, uid, name = '') {
    const p = this.db.persons[pid]; if (!p) throw new Error('no such person');
    const key = `${platform}:${uid}`; this.db.idmap[key] = pid;
    const ex = p.identities.find((i) => i.platform === platform && i.uid === uid);
    if (ex) { if (name) ex.name = name; } else p.identities.push({ platform, uid, name });
    if (!p.name && name) p.name = name; this.ctx.store.touch();
  }
  /** 把 src 合併進 dst（跨平台連結帳號用）：記憶、事實、記帳、設定全部併過去 */
  merge(dstId, srcId) {
    if (dstId === srcId) return;
    const d = this.db.persons[dstId], s = this.db.persons[srcId]; if (!d || !s) throw new Error('person not found');
    for (const i of s.identities) { this.db.idmap[`${i.platform}:${i.uid}`] = dstId; if (!d.identities.some((x) => x.platform === i.platform && x.uid === i.uid)) d.identities.push(i); }
    for (const f of this.db.facts) if (f.pid === srcId) f.pid = dstId;
    for (const e of this.db.ledger) if (e.owner === srcId) e.owner = dstId;
    for (const sh of this.db.sheets) if (sh.owner === srcId) sh.owner = dstId;
    for (const t of this.db.tasks) if (t.pid === srcId) t.pid = dstId;
    d.profile.notes.push(...s.profile.notes); d.usage.messages += s.usage.messages; d.usage.tokens += s.usage.tokens;
    if (s.role === 'admin' && d.role !== 'admin') d.role = 'admin';
    if (!d.name) d.name = s.name;
    // 對話紀錄：把來源的個人紀錄附到目標
    try { for (const r of this.ctx.store.tail('dm_' + srcId, 100000)) this.ctx.store.addMessage('dm_' + dstId, { ...r, merged_from: srcId }); } catch { /* ignore */ }
    for (const v of this.ctx.store.vec) if (v.pid === srcId) v.pid = dstId;
    delete this.db.persons[srcId]; this.ctx.store.touch();
  }
  setRole(pid, role) {
    const p = this.byId(pid); if (!p) throw new Error('找不到使用者');
    if (!ROLE_LABEL[role]) throw new Error('角色只能是 admin / staff / user / guest');
    if (p.role === 'admin' && role !== 'admin' && this.admins().length <= 1) throw new Error('至少要保留一位管理員');
    p.role = role; p.status = role === 'guest' ? p.status : 'active'; this.ctx.store.touch(); return p;
  }
  /** 權限：個別 deny > 個別 allow > 角色預設 */
  can(p, perm) {
    if (!p || p.status === 'blocked') return false;
    if (p.perms.deny.includes(perm)) return false;
    if (p.role === 'admin') return true;
    if (p.perms.allow.includes(perm)) return true;
    return this.S.roleHas(p.role, perm);
  }
  /** 21:00–07:00 之間：只有管理員／員工（或被特別允許）可用 */
  quietBlocked(p, ts = Date.now()) {
    const q = this.S.get('quiet'); if (!q.enabled) return false;
    if (this.can(p, 'night') || p.prefs.night_ok) return false;
    const t = zoned(ts, this.S.get('tz')); const cur = t.hh * 60 + t.mm;
    const a = hhmmToMin(q.start), b = hhmmToMin(q.end); if (a == null || b == null) return false;
    return a > b ? (cur >= a || cur < b) : (cur >= a && cur < b);
  }
  label(p) { return `${p.name || '未命名'}（${ROLE_LABEL[p.role] || p.role}）`; }
  touchSeen(p) { p.last_seen = Date.now(); p.usage.messages++; this.ctx.store.touch(); }
  summary(p) {
    return { id: p.id, name: p.name, role: p.role, status: p.status, identities: p.identities, perms: p.perms, prefs: p.prefs,
      instructions: p.instructions, last_seen: p.last_seen, usage: p.usage, created: p.created,
      quota: p.quota && p.quota.limit ? { limit: p.quota.limit, per: p.quota.per || 'day', left: this.quotaLeft(p) } : null };
  }
}
module.exports = { Users, ROLE_LABEL };
