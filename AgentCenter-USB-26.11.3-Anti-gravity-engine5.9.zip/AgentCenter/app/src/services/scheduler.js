'use strict';
const fs = require('fs');
const path = require('path');
const { logger } = require('../core/log');
const { zoned, hhmmToMin, sleep, clip, pad } = require('../core/util');
const llm = require('../llm');
const web = require('./web');
const log = logger('scheduler');

const GREET = {
  morning: ['早安，{n}！新的一天開始了，今天也請多指教。', '{n} 早安～今天是 {d}，有需要隨時叫我。', '早安 {n}！祝你今天順順利利。'],
  night: ['晚安，{n}。今天辛苦了，好好休息。', '{n} 晚安！夜間（21:00–07:00）我只服務管理員與員工，明早 7 點見。', '晚安 {n}，祝你有個好夢。'],
};
const pick = (a) => a[Math.floor(Math.random() * a.length)];
const STEP = { hourly: 3600e3, daily: 86400e3, weekly: 7 * 86400e3 };

class Scheduler {
  constructor(ctx) { this.ctx = ctx; this.name = 'scheduler'; this.timer = null; this.lastTick = 0; this.busy = false; }
  async start() { this.lastTick = Date.now(); clearInterval(this.timer); this.timer = setInterval(() => this.tick().catch((e) => log.error(e)), 20000); setTimeout(() => this.tick().catch((e) => log.error(e)), 3000); }
  async stop() { clearInterval(this.timer); this.timer = null; }
  health() { return !!this.timer && Date.now() - this.lastTick < 180000; }

  async tick() {
    this.lastTick = Date.now(); if (this.busy) return; this.busy = true;
    try { await this.runTasks(); await this.runSystemJobs(); if (this.ctx.grants) this.ctx.grants.tick(); if (this.ctx.watch) await this.ctx.watch.tick().catch((e) => log.error('哨兵', e)); } finally { this.busy = false; }
  }
  async runTasks() {
    const { store, users, agent, hub } = this.ctx; const now = Date.now();
    for (const t of store.db.tasks) {
      if (t.status !== 'pending' || t.run_at > now) continue;
      const p = users.byId(t.pid);
      // 26.11.3 pro8：交給 tasks.advance（照 App 時區算；每週可以指定好幾天、每 N 天；一次的標成 done）
      if (this.ctx.tasks) this.ctx.tasks.advance(t, now); else if (STEP[t.repeat]) { while (t.run_at <= now) t.run_at += STEP[t.repeat]; } else t.status = 'done';
      store.touch(); if (!p || p.status === 'blocked') continue;
      try {
        const text = await agent.handle({ person: p, msg: { platform: 'system', chatId: '', uid: p.id, userName: p.name, text: `[排程任務到期，請執行並用簡短訊息回報給使用者] ${t.instruction}` }, images: [], group: false, scope: 'dm_' + p.id });
        if (t.target) await hub.send(t.target.platform, t.target.chatId, text); else await hub.sendToPerson(p, text);
      } catch (e) { log.error(`任務 #${t.id} 失敗：${e.message}`); this.ctx.notifier.warn(`排程 #${t.id} 執行失敗`, e.message).catch(() => {}); }
    }
    store.db.tasks = store.db.tasks.filter((t) => t.status === 'pending' || t.status === 'paused' || Date.now() - t.created < 7 * 86400e3);
  }
  async runSystemJobs() {
    const S = this.ctx.settings; const t = zoned(Date.now(), S.get('tz')); const cur = t.hh * 60 + t.mm; const last = (this.ctx.store.db.meta.last_job ||= {});
    for (const job of ['diary', 'good_morning', 'news', 'good_night']) {
      const c = S.get('schedule.' + job); if (!c || !c.enabled) continue; const at = hhmmToMin(c.at); if (at == null) continue;
      if (cur >= at && cur < at + 90 && last[job] !== t.iso) {            // 90 分鐘內補跑（手機休眠錯過整點）
        last[job] = t.iso; this.ctx.store.touch(); log.info('執行排程：' + job);
        try { await this[job === 'good_morning' ? 'greet' : job === 'good_night' ? 'greet' : job](job === 'good_night' ? 'night' : 'morning'); } catch (e) { log.error(job + ' 失敗：' + e.message); this.ctx.notifier.warn(`排程 ${job} 失敗`, e.message).catch(() => {}); }
      }
    }
    // engine5：每日記憶整理（不呼叫模型）
    const mc = S.get('memory.consolidate'); const mat = mc && mc.enabled !== false ? hhmmToMin(mc.at || '03:30') : null;
    if (mat != null && cur >= mat && cur < mat + 90 && last.consolidate !== t.iso && this.ctx.consolidate) {
      last.consolidate = t.iso; this.ctx.store.touch();
      try { this.ctx.consolidate.run(); } catch (e) { log.error('記憶整理失敗：' + e.message); }
    }
    // 每日簡報（brief.* 設定）
    const b = S.get('brief'); const bat = b && b.enabled ? hhmmToMin(b.at) : null;
    if (bat != null && cur >= bat && cur < bat + 90 && last.brief !== t.iso && this.ctx.brief) {
      last.brief = t.iso; this.ctx.store.touch(); log.info('執行排程：每日簡報');
      try { await this.ctx.brief.send(); } catch (e) { log.error('簡報失敗：' + e.message); this.ctx.notifier.warn('每日簡報失敗', e.message).catch(() => {}); }
    }
  }
  /** 早安／晚安：所在群組＋所有用戶 */
  async greet(kind) {
    const { hub, users, settings } = this.ctx; const t = zoned(Date.now(), settings.get('tz')); const d = `${t.m}/${t.d}`;
    for (const g of hub.groups()) { try { await hub.send(g.platform, g.chatId, kind === 'morning' ? '大家早安！新的一天開始了。' : '大家晚安，好好休息。'); } catch (e) { log.warn('群組問候失敗：' + e.message); } await sleep(400); }
    for (const p of users.list()) {
      if (p.status !== 'active' || p.role === 'guest' || p.prefs.greet === false) continue;
      try { await hub.sendToPerson(p, pick(GREET[kind]).replace('{n}', p.name || '').replace('{d}', d).replace('，！', '！')); } catch { /* 沒有可用平台就略過 */ } await sleep(400);
    }
  }
  /** 06:30 系統日記（給管理員） */
  async diary() {
    const { store, hub, users, settings } = this.ctx; const since = Date.now() - 24 * 3600e3; const t = zoned(Date.now(), settings.get('tz'));
    const audit = store.db.audit.filter((a) => a.ts >= since); const by = {}; for (const a of audit) by[a.action] = (by[a.action] || 0) + 1;
    const u = this.ctx.usage.summary(); const dbg = this.ctx.debug.state(); const notes = store.db.notifications.filter((n) => n.ts >= since);
    const facts = [`日期：${t.date}`, `過去 24 小時操作紀錄 ${audit.length} 筆：${Object.entries(by).sort((a, b) => b[1] - a[1]).slice(0, 12).map(([k, v]) => `${k}×${v}`).join('、') || '無'}`,
      `模型：${settings.get('model.provider')}/${settings.get('model.name')}；今日呼叫 ${u.today.calls} 次，token 輸入 ${u.today.in}／輸出 ${u.today.out}；累計 ${u.total.calls} 次`,
      `使用者 ${users.list().length} 人，待審批 ${this.ctx.approvals.pending().length} 件`, `通知 ${notes.length} 則（錯誤以上 ${notes.filter((n) => n.level === 'error' || n.level === 'critical').length}）：${notes.slice(-5).map((n) => n.title).join('、') || '無'}`,
      `服務：${dbg.supervisor.services.map((s) => `${s.name}=${s.state}`).join('、')}；記憶體 ${dbg.rss_mb}MB，事件迴圈延遲 ${dbg.event_loop_lag_ms}ms；公開網址 ${this.ctx.tunnel.state.url || '無'}`,
      `最近錯誤：${dbg.recent_errors.slice(-3).map((e) => `${e.where}: ${e.message}`).join('；') || '無'}`];
    let text = `📓 系統日記 ${t.date}\n` + facts.map((f) => '・' + f).join('\n');
    if (llm.hasKey(settings)) { try { text = '📓 系統日記 ' + t.date + '\n' + await llm.simple(this.ctx, `請把下面的系統事實寫成給管理員看的「系統日記」：先一句話總結今天狀態（正常/需注意），再條列重點，有異常要明確指出並建議處理。不要編造沒有的數字，繁體中文，300 字內，純文字不用 Markdown。\n\n${facts.join('\n')}`); } catch { /* 用模板 */ } }
    fs.mkdirSync(this.ctx.paths.diary, { recursive: true }); fs.writeFileSync(path.join(this.ctx.paths.diary, t.iso + '.md'), text);
    for (const a of users.admins()) { try { await hub.sendToPerson(a, text); } catch (e) { log.warn('日記傳送失敗：' + e.message); } }
    await this.ctx.notifier.push('info', '系統日記已產生', clip(text, 400));
  }
  /** 08:00 新聞日報（給所有用戶；可口頭拒收） */
  async news() {
    const { hub, users, settings } = this.ctx; const t = zoned(Date.now(), settings.get('tz'));
    const feed = settings.get('schedule.news.feed'); const r = await fetch(feed, { headers: { 'user-agent': 'Mozilla/5.0 LineAgent/1.4' }, signal: AbortSignal.timeout(20000) }); const items = web.parseRss(await r.text(), 12);
    if (!items.length) throw new Error('新聞來源沒有內容');
    const list = items.map((i, n) => `${n + 1}. ${i.title}${i.source ? '（' + i.source + '）' : ''}`).join('\n'); let body = list;
    if (llm.hasKey(settings)) { try { body = await llm.simple(this.ctx, `以下是今天的新聞標題。請整理成給一般用戶看的「早晨日報」：挑 6 則最重要的，每則一句話白話重點（不要加入標題以外的事實）。純文字、不用 Markdown，繁體中文。\n\n${list}`); } catch { /* 用標題清單 */ } }
    const text = `📰 ${t.m}/${t.d} 新聞日報\n${body}\n\n（不想收日報？跟我說「不要再傳日報」就好）`;
    fs.mkdirSync(this.ctx.paths.news, { recursive: true }); fs.writeFileSync(path.join(this.ctx.paths.news, t.iso + '.md'), text);
    for (const p of users.list()) { if (p.status !== 'active' || p.role === 'guest' || p.prefs.news === false || !users.can(p, 'news')) continue; try { await hub.sendToPerson(p, text); } catch { /* skip */ } await sleep(400); }
  }
}
module.exports = { Scheduler };
