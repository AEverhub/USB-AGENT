'use strict';
/**
 * 26.11.3 pro6 群組訊息的保存規則（只管群組；私訊、App 對話不受影響）：
 *  ・廢話不存：hi、hello、哈哈、ok、貼圖、只有表情符號…（沒叫 AI 的時候直接不寫進紀錄）
 *  ・其他的先「精簡」再存：多餘空白、重複字（哈哈哈哈哈→哈哈）、網址的追蹤參數拿掉，別人的閒聊最多留 400 字
 *  ・只留最近 memory.group_keep_h 小時（預設 32）：每小時清一次，過時的刪掉
 *  ・刪之前，重要的（有日期時間、金額、地址電話、決定事項、「記得／重要／截止」…）存進向量記憶（只屬於那個群組，不會出現在別人的私訊裡）
 *  ・你特別要它記的（group_note 群組備忘、規則、設定、長期事實）本來就存在別的地方，不會被刪
 */
const fs = require('fs');
const path = require('path');
const { clip } = require('../core/util');
const { logger } = require('../core/log');
const log = logger('groupmem');

const JUNK = /^(?:h+i+|he+l+o+|hey|yo|嗨+|哈囉|哈摟|安安|早安?|午安|晚安|早+|你好|大家好|ok+|okay|k+|好+|好的|好喔|嗯+|恩+|喔+|哦+|噢+|欸+|耶+|收到|了解|讚+|讚啦|nice|cool|lol+|lmao|xd+|w+|哈+|呵+|嘻+|嘿+|笑死|草+|\+1|1|對|對啊|是喔|真的|真假|謝+|謝啦|謝謝|感謝|3q|thx|thanks?|ty|bye|掰+|88|886|\?+|？+|!+|！+|\.+|。+|~+|～+)[\s!！。.~～?？]*$/i;
const PLACEHOLDER = /^\[(貼圖|sticker|圖片|語音|影片|檔案)\]$/i;
/** 這句話是不是廢話（沒有資訊、刪掉也不影響理解前後文） */
function junk(text) {
  const t = String(text || '').trim(); if (!t) return true;
  if (PLACEHOLDER.test(t)) return /貼圖|sticker/i.test(t);   // 貼圖丟掉；圖片／語音／檔案留著（可能有內容）
  if (JUNK.test(t)) return true;
  const noEmoji = t.replace(/[☀-➿️‍]|[\uD83C-\uDBFF][\uDC00-\uDFFF]|<a?:\w+:\d+>|:[a-z0-9_+-]+:/gi, '').trim();
  return !noEmoji;   // 只有表情符號／Discord 表情
}
/** 精簡：空白、重複字、網址追蹤參數；別人的閒聊最多 max 字 */
function compact(text, max = 400) {
  let t = String(text || '').replace(/\r/g, '').replace(/[ \t　]+/g, ' ').replace(/\n{3,}/g, '\n\n').trim();
  t = t.replace(/(.)\1{3,}/gu, '$1$1');   // 哈哈哈哈哈 → 哈哈、!!!!! → !!
  t = t.replace(/https?:\/\/[^\s<>"']+/g, (u) => { try { const x = new URL(u); for (const k of [...x.searchParams.keys()]) if (/^(utm_|fbclid|gclid|igshid|si$|feature$|ref$|ref_src|mc_)/i.test(k)) x.searchParams.delete(k); return x.toString().replace(/\?$/, ''); } catch { return u; } });
  return clip(t, max);
}
/** 值得在刪除前存進向量記憶的（0～）：分數 >= 2 才存 */
function score(rec) {
  const t = String(rec.text || ''); if (t.length < 8 || rec.role === 'assistant') return 0; let s = 0;
  if (/\d{1,2}[\/月]\d{1,2}|\d{1,2}[:：]\d{2}|星期|週[一二三四五六日天]|禮拜|明天|後天|下週|下禮拜|今晚|幾點/.test(t)) s += 1;
  if (/\$|NT|元|塊|萬|千|預算|價格|多少錢|費用|付款|轉帳|匯款/.test(t)) s += 1;
  if (/地址|路\d|號|樓|電話|0\d{1,2}-?\d{6,8}|09\d{2}-?\d{6}|@\w+\.\w+/.test(t)) s += 1;
  if (/決定|確定|定案|結論|就這樣|說好|約好|改成|取消|延期|截止|deadline|期限|規定|規則|記得|重要|注意|千萬|不要忘|提醒/i.test(t)) s += 2;
  if (rec.role === 'user' && rec.pid && rec.admin) s += 1;
  if (t.length >= 60) s += 1;
  return s;
}

class GroupMem {
  constructor(ctx) { this.ctx = ctx; this.name = 'groupmem'; this.timer = null; this.last = null; }
  cfg() { const S = this.ctx.settings; return { keepH: Math.max(1, +S.get('memory.group_keep_h', 32) || 32), dropJunk: S.get('memory.group_drop_junk', true) !== false, saveImportant: S.get('memory.group_save_important', true) !== false }; }
  /** 寫進群組紀錄前的處理：回傳要存的紀錄，或 null（廢話，不存） */
  prepare(rec, { addressed = false } = {}) {
    if (!rec || rec.role !== 'user') return rec; const c = this.cfg();
    if (!addressed && c.dropJunk && junk(rec.text) && !(rec.imgs && rec.imgs.length) && !rec.files) return null;
    return { ...rec, text: compact(rec.text, addressed ? 2000 : 400) };
  }
  start() { clearInterval(this.timer); this.timer = setInterval(() => this.sweep().catch((e) => log.warn('清理群組紀錄失敗：' + e.message)), 3600e3); if (this.timer.unref) this.timer.unref(); setTimeout(() => this.sweep().catch(() => {}), 60e3).unref?.(); }
  stop() { clearInterval(this.timer); }
  health() { return true; }
  /** 在群組裡回想以前的重要訊息：先用向量搜尋；本地嵌入（沒有雲端 API）對中文分數偏低 → 再用關鍵字（兩字詞）重疊補上 */
  async recall(text, gpid, k = 3) {
    const V = this.ctx.vector; if (!V) return []; let out = []; try { out = await V.search(text, { pid: gpid, source: 'group', k }); } catch { out = []; } if (out.length) return out;
    const grams = (s) => { const g = new Set(); for (const w of String(s).toLowerCase().replace(/[^\u4e00-\u9fffa-z0-9]+/g, ' ').split(' ').filter(Boolean)) { if (/^[a-z0-9]+$/.test(w)) { if (w.length >= 2) g.add(w); continue; } for (let i = 0; i + 2 <= w.length; i++) g.add(w.slice(i, i + 2)); } return g; };
    const q = grams(text); const STOP = new Set(['來著', '什麼', '哪裡', '怎麼', '我們', '大家', '一下', '那個', '這個', '可以']); for (const s of STOP) q.delete(s); if (!q.size) return [];
    return V.items.filter((it) => it.source === 'group' && it.pid === gpid).map((it) => { const g = grams(it.text.replace(/^［[^］]*］/, '')); let n = 0; for (const x of q) if (g.has(x)) n++; return { id: it.id, score: n, text: it.text, source: it.source, pid: it.pid, ts: it.ts, meta: it.meta }; })
      .filter((x) => x.score >= 2).sort((a, b) => b.score - a.score || b.ts - a.ts).slice(0, k);
  }
  /** 刪掉超過保存時間的群組訊息；刪之前把重要的存進向量記憶 */
  async sweep(now = Date.now()) {
    const c = this.cfg(); const cut = now - c.keepH * 3600e3; const dir = this.ctx.store.msgDir; const res = { files: 0, removed: 0, kept: 0, saved: 0 };
    let names = []; try { names = fs.readdirSync(dir).filter((f) => /^chat_.+\.jsonl$/.test(f)); } catch { return res; }
    const tz = this.ctx.settings.get('tz') || 'Asia/Taipei'; const admins = new Set(this.ctx.users.admins().map((p) => p.id));
    for (const f of names) {
      const file = path.join(dir, f); let lines; try { lines = fs.readFileSync(file, 'utf8').split('\n').filter(Boolean); } catch { continue; }
      const keep = []; const old = [];
      for (const l of lines) { let m; try { m = JSON.parse(l); } catch { continue; } if ((m.ts || 0) >= cut) keep.push(l); else old.push(m); }
      if (!old.length) continue; res.files++; res.removed += old.length; res.kept += keep.length;
      if (c.saveImportant && this.ctx.vector) {
        const key = f.replace(/^chat_/, '').replace(/\.jsonl$/, ''); const chat = Object.values(this.ctx.store.db.chats || {}).find((x) => `${x.platform}_${x.chatId}`.replace(/[^\w.-]/g, '_') === key);
        const gpid = chat ? `g:${chat.platform}:${chat.chatId}` : 'g:' + key; const gname = (chat && chat.name) || key;
        for (const m of old) {
          if (score({ ...m, admin: admins.has(m.pid) }) < 2) continue;
          const when = (() => { try { return new Date(m.ts).toLocaleString('zh-TW', { timeZone: tz, month: 'numeric', day: 'numeric', hour: '2-digit', minute: '2-digit', hour12: false }); } catch { return ''; } })();
          try { await this.ctx.vector.add({ pid: gpid, source: 'group', text: `［${gname}｜${when}］${m.name || m.uid || '成員'}${m.bot ? '（機器人）' : ''}：${clip(m.text, 500)}`, meta: { chat: gpid, mid: m.mid || '', ts: m.ts } }); res.saved++; } catch (e) { log.warn('存向量記憶失敗：' + e.message); }
        }
      }
      try { const tmp = file + '.tmp'; fs.writeFileSync(tmp, keep.length ? keep.join('\n') + '\n' : ''); fs.renameSync(tmp, file); } catch (e) { log.warn(`改寫 ${f} 失敗：${e.message}`); }
    }
    // 滾動摘要也是群組內容：太舊的一併清掉
    const sums = this.ctx.store.db.summaries || {}; for (const [k, v] of Object.entries(sums)) if (/^chat_/.test(k) && v && v.until && v.until < cut) { delete sums[k]; this.ctx.store.touch(); }
    this.last = { at: now, ...res }; if (res.removed) log.info(`群組紀錄：刪掉 ${res.removed} 則超過 ${c.keepH} 小時的訊息，重要的 ${res.saved} 則存進向量記憶`);
    return res;
  }
}
module.exports = { GroupMem, junk, compact, score };
