'use strict';
/**
 * 26.11.3 pro8：排程任務（一次）與長期任務（會重複）的共用邏輯。資料仍在 store.db.tasks。
 * 任務：{ id, pid, run_at, instruction, repeat, days?, every?, status: pending|paused|done|cancelled, target, created, last_run?, runs? }
 * repeat：none（一次）｜hourly 每小時｜daily 每天｜weekly 每週（days＝[0..6] 星期日～六，可以一週好幾天，例如每週一、四）｜monthly 每月｜every 每 N 天（every＝N）
 * 時間都照 App 時區算（換日、跨月不會漂移）。
 */
const { zoned, fromZoned, pad } = require('../core/util');
const WD = ['日', '一', '二', '三', '四', '五', '六'];
const REPEATS = ['none', 'hourly', 'daily', 'weekly', 'monthly', 'every'];
const tzOf = (ctx) => (ctx && ctx.settings && ctx.settings.get('tz')) || 'Asia/Taipei';

/** 「1,4」「一、四」「週一 週四」「mon thu」→ [1,4] */
function parseDays(v) {
  if (v == null || v === '') return null; const out = new Set(); const EN = { sun: 0, mon: 1, tue: 2, wed: 3, thu: 4, fri: 5, sat: 6 };
  const list = Array.isArray(v) ? v : String(v).split(/[\s,，、/]+|(?=[週周星期禮拜])/);
  for (let x of list) { x = String(x).trim().toLowerCase().replace(/^(週|周|星期|禮拜)/, ''); if (!x) continue;
    if (/^[0-7]$/.test(x)) out.add(+x % 7); else if (WD.includes(x) || x === '天') out.add(x === '天' ? 0 : WD.indexOf(x)); else if (EN[x.slice(0, 3)] != null) out.add(EN[x.slice(0, 3)]);
    else if (/^[一二三四五六日天]+$/.test(x)) for (const c of x) out.add(c === '天' ? 0 : WD.indexOf(c)); else throw new Error(`看不懂的星期「${x}」（例：1,4 或 一、四）`); }
  return out.size ? [...out].sort((a, b) => a - b) : null;
}
/** 下一次執行時間（嚴格晚於 after） */
function nextRun(t, after = Date.now(), tz = 'Asia/Taipei') {
  const base = zoned(t.run_at, tz); const hh = base.hh, mm = base.mm;
  if (t.repeat === 'hourly') { let r = t.run_at; if (r <= after) r += Math.ceil((after - r + 1) / 3600e3) * 3600e3; return r; }
  if (t.repeat === 'every') { const n = Math.max(1, Math.floor(+t.every || 1)); let r = t.run_at; let k = 0; while (r <= after && k++ < 4000) { const z = zoned(r, tz); r = fromZoned(z.y, z.m, z.d + n, hh, mm, tz); } return r; }
  if (t.repeat === 'monthly') { const day = t.dom || base.d; let y = base.y, m = base.m; for (let k = 0; k < 200; k++) { const last = new Date(Date.UTC(y, m, 0)).getUTCDate(); const r = fromZoned(y, m, Math.min(day, last), hh, mm, tz); if (r > after) return r; m++; if (m > 12) { m = 1; y++; } } return null; }
  if (t.repeat === 'daily' || t.repeat === 'weekly') {
    const days = t.repeat === 'daily' ? [0, 1, 2, 3, 4, 5, 6] : (t.days && t.days.length ? t.days : [base.wd]);
    const a = zoned(Math.max(after, t.run_at - 1), tz);
    for (let i = 0; i <= 8; i++) { const z = zoned(fromZoned(a.y, a.m, a.d + i, 12, 0, tz), tz); if (!days.includes(z.wd)) continue; const r = fromZoned(z.y, z.m, z.d, hh, mm, tz); if (r > after && r >= t.run_at) return r; }
    return null;
  }
  return null;
}
/** 「每週一、四 09:00」 */
function repeatText(t, tz = 'Asia/Taipei') {
  const z = zoned(t.run_at, tz); const hm = `${pad(z.hh)}:${pad(z.mm)}`;
  switch (t.repeat) {
    case 'hourly': return `每小時（${pad(z.mm)} 分）`;
    case 'daily': return `每天 ${hm}`;
    case 'weekly': { const d = t.days && t.days.length ? t.days : [z.wd]; return d.length === 7 ? `每天 ${hm}` : d.join() === '1,2,3,4,5' ? `平日（週一～五）${hm}` : d.join() === '0,6' ? `週末 ${hm}` : `每週${d.map((x) => WD[x]).join('、')} ${hm}`; }
    case 'monthly': return `每月 ${t.dom || z.d} 號 ${hm}`;
    case 'every': return `每 ${t.every || 1} 天 ${hm}`;
    default: return '一次';
  }
}
/** 給人看的時間：「今天 21:00」「明天 09:00」「11/14（五）09:00」 */
function whenText(ts, tz = 'Asia/Taipei', now = Date.now()) {
  if (!ts) return '—'; const z = zoned(ts, tz), n = zoned(now, tz); const dd = Math.round((Date.UTC(z.y, z.m - 1, z.d) - Date.UTC(n.y, n.m - 1, n.d)) / 86400e3);
  const hm = `${pad(z.hh)}:${pad(z.mm)}`; if (dd === 0) return `今天 ${hm}`; if (dd === 1) return `明天 ${hm}`; if (dd === 2) return `後天 ${hm}`; if (dd === -1) return `昨天 ${hm}`;
  return `${z.y !== n.y ? z.y + '/' : ''}${z.m}/${z.d}（${WD[z.wd]}）${hm}`;
}
function leftText(ts, now = Date.now()) { const s = Math.round((ts - now) / 1000); if (s <= 0) return '快到了'; const min = Math.max(1, Math.round(s / 60)); if (min < 60) return `${min} 分鐘後`; if (min < 1440) { const h = Math.floor(min / 60), m = min % 60; return `${h} 小時${m ? ' ' + m + ' 分' : ''}後`; } const d = Math.floor(min / 1440), h = Math.floor((min % 1440) / 60); return `${d} 天${h ? ' ' + h + ' 小時' : ''}後`; }

class Tasks {
  constructor(ctx) { this.ctx = ctx; }
  get db() { const d = this.ctx.store.db; if (!Array.isArray(d.tasks)) d.tasks = []; return d.tasks; }
  tz() { return tzOf(this.ctx); }
  /** 解析「YYYY-MM-DD HH:mm」或 datetime-local 的「YYYY-MM-DDTHH:mm」 */
  at(s) { const m = /(\d{4})-(\d{1,2})-(\d{1,2})[ T](\d{1,2}):(\d{2})/.exec(String(s || '')); if (!m) throw new Error('時間格式：YYYY-MM-DD HH:mm'); return fromZoned(+m[1], +m[2], +m[3], +m[4], +m[5], this.tz()); }
  /** 依重複方式把第一次執行時間調到「符合規則的第一個時間」（例如每週一、四，但指定的日期是週二 → 改到週四） */
  normalize(t) { if (t.repeat === 'weekly' && t.days && t.days.length) { const z = zoned(t.run_at, this.tz()); if (!t.days.includes(z.wd)) { const r = nextRun({ ...t }, t.run_at - 60e3, this.tz()); if (r) t.run_at = r; } } return t; }
  create(a, person, target = null) {
    const repeat = a.repeat || 'none'; if (!REPEATS.includes(repeat)) throw new Error('repeat 只能是 ' + REPEATS.join('｜'));
    const instruction = String(a.instruction || '').trim(); if (!instruction) throw new Error('要寫到時候做什麼'); if (instruction.length > 1000) throw new Error('內容太長（最多 1000 字）');
    let run = null; if (a.delay_seconds) run = Date.now() + Math.max(1, +a.delay_seconds) * 1000; else if (a.at) run = this.at(a.at); if (!run) throw new Error('要給時間（at）或幾秒後（delay_seconds）');
    const days = parseDays(a.days); if (days && repeat !== 'weekly') throw new Error('指定星期幾要用 repeat=weekly');
    const t = this.normalize({ id: this.ctx.store.nextId('task'), pid: person.id, run_at: run, instruction, repeat, status: 'pending', target, created: Date.now(), ...(days ? { days } : {}), ...(repeat === 'every' ? { every: Math.max(1, Math.min(365, Math.floor(+a.every || 1))) } : {}) });
    if (repeat === 'monthly') t.dom = zoned(t.run_at, this.tz()).d;
    if (t.run_at < Date.now() - 60000) { if (repeat === 'none') throw new Error('這個時間已經過了'); t.run_at = nextRun(t, Date.now(), this.tz()); }
    this.db.push(t); this.ctx.store.touch(); return t;
  }
  /** 到期後：一次的標成 done，重複的排到下一次 */
  advance(t, now = Date.now()) { if (t.repeat === 'monthly' && !t.dom) t.dom = zoned(t.run_at, this.tz()).d; t.last_run = now; t.runs = (t.runs || 0) + 1; if (t.repeat === 'none' || !t.repeat) { t.status = 'done'; return t; } const r = nextRun(t, now, this.tz()); if (r) t.run_at = r; else t.status = 'done'; return t; }
  can(t, person) { return person && (person.role === 'admin' || t.pid === person.id); }
  find(id, person) { const t = this.db.find((x) => x.id === +id && this.can(x, person) && ['pending', 'paused'].includes(x.status)); if (!t) throw new Error(`找不到排程 #${id}`); return t; }
  act(id, action, person, a = {}) {
    const t = this.find(id, person);
    if (action === 'cancel') t.status = 'cancelled';
    else if (action === 'pause') { if (t.repeat === 'none') throw new Error('一次性的排程不能暫停（要取消就按取消）'); t.status = 'paused'; }
    else if (action === 'resume') { t.status = 'pending'; if (t.run_at <= Date.now()) t.run_at = nextRun(t, Date.now(), this.tz()) || Date.now() + 60e3; }
    else if (action === 'edit') {
      if (a.instruction != null) { const s = String(a.instruction).trim(); if (!s) throw new Error('內容不能空白'); t.instruction = s.slice(0, 1000); }
      if (a.repeat) { if (!REPEATS.includes(a.repeat)) throw new Error('repeat 只能是 ' + REPEATS.join('｜')); t.repeat = a.repeat; if (a.repeat !== 'weekly') delete t.days; if (a.repeat !== 'every') delete t.every; }
      if (a.days !== undefined) { const d = parseDays(a.days); if (d) { t.repeat = 'weekly'; t.days = d; } else delete t.days; }
      if (a.every != null && t.repeat === 'every') t.every = Math.max(1, Math.min(365, Math.floor(+a.every || 1)));
      if (a.at) { const r = this.at(a.at); if (r < Date.now() - 60000 && t.repeat === 'none') throw new Error('這個時間已經過了'); t.run_at = r; }
      if (t.repeat === 'monthly') t.dom = zoned(t.run_at, this.tz()).d; else delete t.dom;
      this.normalize(t); if (t.run_at < Date.now() - 60000) t.run_at = nextRun(t, Date.now(), this.tz()) || t.run_at;
    } else throw new Error('動作只能是 cancel、pause、resume、edit');
    this.ctx.store.touch(); return t;
  }
  view(t, now = Date.now()) {
    const tz = this.tz(); const p = this.ctx.users && this.ctx.users.byId(t.pid);
    return { id: t.id, instruction: t.instruction, kind: t.repeat && t.repeat !== 'none' ? 'recurring' : 'once', repeat: t.repeat || 'none', days: t.days || null, every: t.every || null, status: t.status, run_at: t.run_at,
      when: whenText(t.run_at, tz, now), left: t.status === 'paused' ? '已暫停' : leftText(t.run_at, now), repeat_text: repeatText(t, tz), owner: p ? p.name : '', target: t.target ? `${t.target.platform} 群組` : '', runs: t.runs || 0, last_run: t.last_run || null, last_text: t.last_run ? whenText(t.last_run, tz, now) : '' };
  }
  /** App 系統自己的長期工作（早安、晚安、日記、新聞、每日簡報） */
  system() {
    const S = this.ctx.settings; const N = { good_morning: '早安問候', good_night: '晚安問候', diary: 'AI 日記', news: '每日新聞' }; const out = [];
    for (const k of Object.keys(N)) { const c = S.get('schedule.' + k); if (c) out.push({ key: 'schedule.' + k, name: N[k], at: c.at, enabled: !!c.enabled, repeat_text: `每天 ${c.at}` }); }
    const b = S.get('brief'); if (b) out.push({ key: 'brief', name: '每日簡報', at: b.at, enabled: !!b.enabled, repeat_text: `每天 ${b.at}` });
    return out;
  }
  list(person, now = Date.now()) {
    const mine = this.db.filter((t) => ['pending', 'paused'].includes(t.status) && this.can(t, person)).sort((a, b) => (a.status === 'paused') - (b.status === 'paused') || a.run_at - b.run_at).map((t) => this.view(t, now));
    return { tz: this.tz(), once: mine.filter((x) => x.kind === 'once'), recurring: mine.filter((x) => x.kind === 'recurring'), system: person && person.role === 'admin' ? this.system() : [] };
  }
  text(person) { const l = this.list(person); const f = (x) => `#${x.id} ${x.status === 'paused' ? '［已暫停］' : ''}${x.kind === 'recurring' ? x.repeat_text + '，下次 ' + x.when : x.when}：${x.instruction}`; return [l.once.length ? '排程（一次）：\n' + l.once.map(f).join('\n') : '', l.recurring.length ? '長期任務（重複）：\n' + l.recurring.map(f).join('\n') : ''].filter(Boolean).join('\n\n') || '（沒有排程）'; }
}
module.exports = { Tasks, nextRun, repeatText, whenText, parseDays, REPEATS };
