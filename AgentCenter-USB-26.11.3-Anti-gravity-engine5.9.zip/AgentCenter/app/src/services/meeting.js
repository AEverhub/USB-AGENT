'use strict';
/**
 * 26.11.3 Revise6 會議監聽：聽整場演講／會議 → 逐段轉文字 → 隨時整理重點 → 結束時產出完整會議記錄。
 *  ・來源 app：App 用麥克風錄，每段約 30 秒上傳（/api/meetings/:id/audio）；沒有雲端辨識金鑰時用手機內建辨識送文字（/text）。
 *  ・來源 discord：Bot 進語音頻道，voice-worker 依講者把 Opus 封包送來（/api/meeting-ingest/:id），這裡包成 Ogg 再轉文字，講者名字照 Discord。
 *  ・重點每多約 1200 字就增量更新一次（摘要、重點、決議、待辦、待確認問題）；結束時整場再整理一次。
 *  ・資料存在 data/meetings/<id>.json。只有管理員能開始／結束 Discord 監聽（AI 工具也是管理員限定）。
 */
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { logger } = require('../core/log');
const llm = require('../llm');
const { oggOpus } = require('./ogg');
const log = logger('meeting');

// Whisper 在安靜或雜音時常見的「幻覺」字幕：短句且符合就丟掉
const HALLU = /^(謝謝(大家|各位)?(的)?(收看|觀看|聆聽|收聽)|請不吝(點贊|點讚)|(請)?訂閱|字幕(由|提供|製作|:|：)|中文字幕|明鏡與點點|Amara\.org|by 索兰娅|感謝觀看|thank you( for watching)?\.?|you\.?|嗯+|啊+|\.+|…+)/i;
const fmtT = (ms) => { const s = Math.max(0, Math.round(ms / 1000)); const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), x = s % 60; return (h ? h + ':' + String(m).padStart(2, '0') : String(m).padStart(2, '0')) + ':' + String(x).padStart(2, '0'); };
const EMPTY = () => ({ summary: '', points: [], decisions: [], actions: [], questions: [], updatedAt: 0 });

class Meetings {
  constructor(ctx) { this.ctx = ctx; this.dir = path.join(ctx.paths.data, 'meetings'); fs.mkdirSync(this.dir, { recursive: true }); this.live = new Map(); this.cache = new Map(); this._recover(); }
  cfg() { return { summarize_every_chars: 1200, max_hours: 6, announce: true, ...(this.ctx.settings.get('meeting', {}) || {}) }; }
  file(id) { if (!/^m[0-9a-z]{6,20}$/.test(String(id))) throw new Error('會議編號不正確'); return path.join(this.dir, id + '.json'); }
  get(id) { if (this.cache.has(id)) return this.cache.get(id); let m; try { m = JSON.parse(fs.readFileSync(this.file(id), 'utf8')); } catch { throw new Error('找不到這場會議'); } this.cache.set(id, m); return m; }
  save(m, now = false) {
    this.cache.set(m.id, m); const L = this.live.get(m.id);
    const w = () => { try { fs.writeFileSync(this.file(m.id) + '.tmp', JSON.stringify(m)); fs.renameSync(this.file(m.id) + '.tmp', this.file(m.id)); } catch (e) { log.error('會議存檔失敗：' + e.message); } };
    if (now || !L) return w(); clearTimeout(L.saveT); L.saveT = setTimeout(w, 1500);
  }
  /** App 重開時：還在「進行中」的會議改成「中斷」（錄音已經停了），已有的逐字稿保留，可以手動整理 */
  _recover() { for (const f of fs.readdirSync(this.dir).filter((x) => x.endsWith('.json'))) { try { const m = JSON.parse(fs.readFileSync(path.join(this.dir, f), 'utf8')); if (m.status === 'live' || m.status === 'processing') { m.status = 'interrupted'; m.endedAt = m.endedAt || Date.now(); fs.writeFileSync(path.join(this.dir, f), JSON.stringify(m)); } } catch { /* ignore */ } } }
  list() {
    return fs.readdirSync(this.dir).filter((x) => /^m[0-9a-z]+\.json$/.test(x)).map((f) => { try { return this.get(f.slice(0, -5)); } catch { return null; } }).filter(Boolean)
      .map((m) => ({ id: m.id, title: m.title, source: m.source, status: m.status, startedAt: m.startedAt, endedAt: m.endedAt, segments: m.segments.length, chars: m.segments.reduce((a, s) => a + s.text.length, 0), summary: (m.notes.summary || '').slice(0, 140), channel: m.discord ? m.discord.channel_name : '' }))
      .sort((a, b) => b.startedAt - a.startedAt);
  }
  start({ title = '', source = 'app', by = '', discord = null } = {}) {
    const running = [...this.live.keys()].map((k) => this.get(k)).filter((m) => m.status === 'live');
    if (source === 'discord' && discord && running.some((m) => m.discord && m.discord.guild_id === discord.guild_id)) throw new Error('這個 Discord 伺服器已經在記錄一場會議了（一個伺服器同時只能進一個語音頻道）');
    const id = 'm' + Date.now().toString(36) + crypto.randomBytes(2).toString('hex');
    const m = { id, title: String(title || '').slice(0, 80) || `會議 ${new Date().toLocaleString('zh-TW', { hour12: false, timeZone: this.ctx.settings.get('timezone', 'Asia/Taipei') })}`, autoTitle: !title, source, by, status: 'live', startedAt: Date.now(), endedAt: null, segments: [], notes: EMPTY(), discord, errors: [], worker: null };
    this.live.set(id, { token: crypto.randomBytes(24).toString('hex'), busy: 0, queue: [], sumLen: 0, summarizing: null, events: [], stop: false, timer: setInterval(() => this._tick(id), 60000) });
    if (this.live.get(id).timer.unref) this.live.get(id).timer.unref();
    this.save(m, true); this.ctx.store.audit('app', 'meeting.start', `${source} ${m.title}`); return m;
  }
  ingestToken(id) { const L = this.live.get(id); return L ? L.token : ''; }
  checkIngest(id, tok) { const L = this.live.get(id); if (!L || !tok) return false; const a = Buffer.from(String(tok)), b = Buffer.from(L.token); return a.length === b.length && crypto.timingSafeEqual(a, b); }
  _tick(id) {
    let m; try { m = this.get(id); } catch { return; } if (m.status !== 'live') return;
    if (Date.now() - m.startedAt > this.cfg().max_hours * 3600e3) { log.warn('會議超過時間上限，自動結束'); this.stop(id).catch(() => {}); return; }
    this.maybeSummarize(id).catch(() => {});
  }
  /** 一段聲音 → 排隊轉文字（同一場最多同時 2 段） */
  audio(id, { mime = 'audio/wav', data, buf, at, speaker = '', speaker_id = '' } = {}) {
    const m = this.get(id); const L = this.live.get(id); if (!L || m.status !== 'live') throw new Error('這場會議已經結束');
    const b = buf || Buffer.from(String(data || ''), 'base64'); if (b.length < 1200) return { queued: false, reason: 'too_short' };
    if (b.length > 20 * 1024 * 1024) throw new Error('單段聲音超過 20MB');
    L.queue.push({ mime, buf: b, at: +at || Date.now(), speaker, speaker_id }); this._pump(id); return { queued: true, pending: L.queue.length + L.busy };
  }
  /** Discord：一位講者的一串 Opus 封包 */
  async opus(id, { packets = [], channels = 2, at, speaker_id = '' } = {}) {
    const m = this.get(id); const pk = packets.map((x) => Buffer.from(String(x), 'base64')); if (pk.length < 25) return { queued: false, reason: 'too_short' };   // 不到半秒：多半是雜音
    let speaker = speaker_id; const d = this.ctx.hub && this.ctx.hub.connectors && this.ctx.hub.connectors.discord;
    if (d && m.discord && speaker_id) { try { speaker = await d.userName(m.discord.guild_id, speaker_id); } catch { /* 用 ID */ } }
    return this.audio(id, { mime: 'audio/ogg', buf: oggOpus(pk, { channels: +channels || 2 }), at, speaker, speaker_id });
  }
  text(id, { text, at, speaker = '' } = {}) { const m = this.get(id); if (m.status !== 'live') throw new Error('這場會議已經結束'); this._add(m, { at: +at || Date.now(), text, speaker }); return { ok: true }; }
  _pump(id) {
    const L = this.live.get(id); if (!L) return;
    while (L.busy < 2 && L.queue.length) {
      const job = L.queue.shift(); L.busy++;
      (async () => {
        try { const r = await this.ctx.speech.transcribe({ mime: job.mime, buf: job.buf }); this._add(this.get(id), { at: job.at, text: r.text, speaker: job.speaker }); }
        catch (e) { const m = this.get(id); if (!/沒有辨識出內容/.test(e.message)) { m.errors.push({ ts: Date.now(), msg: String(e.message).slice(0, 200) }); m.errors = m.errors.slice(-20); this.save(m); log.warn('會議轉文字失敗：' + e.message); } }
        finally { L.busy--; this._pump(id); if (!L.busy && !L.queue.length && L.idle) { const f = L.idle; L.idle = null; f(); } }
      })();
    }
  }
  _add(m, { at, text, speaker }) {
    const t = String(text || '').replace(/\s+/g, ' ').trim(); if (!t || (t.length < 30 && HALLU.test(t))) return;
    const seg = { at: Math.max(0, at - m.startedAt), text: t.slice(0, 4000), speaker: String(speaker || '').slice(0, 40) };
    let i = m.segments.length; while (i > 0 && m.segments[i - 1].at > seg.at) i--; m.segments.splice(i, 0, seg);
    this.save(m); this.maybeSummarize(m.id).catch(() => {});
  }
  transcript(m, from = 0) { return m.segments.slice(from).map((s) => `[${fmtT(s.at)}]${s.speaker ? ' ' + s.speaker + '：' : ' '}${s.text}`).join('\n'); }
  /** 新增的逐字稿夠多了就增量更新重點 */
  async maybeSummarize(id, force = false) {
    const L = this.live.get(id); const m = this.get(id); if (L && L.summarizing) return L.summarizing;
    const total = m.segments.reduce((a, s) => a + s.text.length, 0); const done = (L && L.sumLen) || m.notes.sumLen || 0;
    if (!force && total - done < this.cfg().summarize_every_chars) return null; if (!m.segments.length) return null;
    const run = (async () => {
      const from = m.notes.sumSeg || 0; const fresh = this.transcript(m, from);
      try { const n = await this._summarize(m, fresh, m.notes); Object.assign(m.notes, n, { updatedAt: Date.now(), sumLen: total, sumSeg: m.segments.length }); if (L) L.sumLen = total; this.save(m); }
      catch (e) { log.warn('會議重點整理失敗：' + e.message); m.errors.push({ ts: Date.now(), msg: '整理重點失敗：' + String(e.message).slice(0, 160) }); this.save(m); }
    })();
    if (L) { L.summarizing = run; run.finally(() => { L.summarizing = null; }); } return run;
  }
  async _summarize(m, fresh, prev, final = false) {
    const sys = '你是專業的會議記錄員。只根據逐字稿整理，不編造沒說過的內容；逐字稿是語音辨識結果，可能有錯字，請依上下文修正明顯的專有名詞。使用繁體中文。只輸出 JSON。';
    const had = prev && (prev.summary || (prev.points || []).length) ? `目前已整理的重點（JSON，請在這個基礎上更新、合併重複、修正）：\n${JSON.stringify({ summary: prev.summary, points: prev.points, decisions: prev.decisions, actions: prev.actions, questions: prev.questions })}\n\n` : '';
    const prompt = `會議：${m.title}${m.discord ? `（Discord 語音頻道「${m.discord.channel_name || ''}」）` : ''}\n${had}${final ? '這是整場會議的逐字稿' : '新的逐字稿'}（[時間] 講者：內容）：\n${fresh.slice(-60000)}\n\n請${final ? '產出整場會議的完整記錄' : '更新會議重點'}，只輸出一個 JSON：{"title":"${m.autoTitle ? '依內容取的會議標題（20 字內）' : ''}","summary":"3～6 句總結","points":["重點（每點一句，必要時附講者）"],"decisions":["已經做出的決定"],"actions":[{"who":"負責人（沒說就空白）","what":"要做的事","due":"期限（沒說就空白）"}],"questions":["還沒有結論、待確認的問題"]}。沒有的項目給空陣列。`;
    const raw = await llm.simple(this.ctx, prompt, sys); const j = parseJson(raw);
    const arr = (x, n = 30) => (Array.isArray(x) ? x : []).slice(0, n);
    const out = { summary: String(j.summary || '').slice(0, 2000), points: arr(j.points).map(String), decisions: arr(j.decisions).map(String), actions: arr(j.actions).map((a) => (typeof a === 'string' ? { who: '', what: a, due: '' } : { who: String(a.who || ''), what: String(a.what || ''), due: String(a.due || '') })).filter((a) => a.what), questions: arr(j.questions).map(String) };
    if (m.autoTitle && j.title && String(j.title).trim()) { m.title = String(j.title).trim().slice(0, 40); }
    return out;
  }
  /** 結束：等轉文字做完 → 整場整理 → 通知 */
  async stop(id, { reason = '' } = {}) {
    const m = this.get(id); const L = this.live.get(id); if (!L) { if (m.status === 'interrupted' || m.status === 'live') { m.status = 'done'; this.save(m, true); } return m; }
    if (m.status !== 'live') return m; L.stop = true; m.status = 'processing'; m.endedAt = Date.now(); m.stopReason = reason; this.save(m, true);
    clearInterval(L.timer);
    if (m.source === 'discord') { try { if (this.ctx.dvoice) await this.ctx.dvoice.stop(id); } catch (e) { log.warn(e.message); } }
    if (L.busy || L.queue.length) await Promise.race([new Promise((r) => { L.idle = r; }), new Promise((r) => setTimeout(r, 120000))]);
    if (L.summarizing) await L.summarizing.catch(() => {});
    try { if (m.segments.length) { const all = this.transcript(m); const n = all.length <= 60000 ? await this._summarize(m, all, null, true) : await this._summarize(m, this.transcript(m, m.notes.sumSeg || 0), m.notes); Object.assign(m.notes, n, { updatedAt: Date.now(), final: true }); } }
    catch (e) { m.errors.push({ ts: Date.now(), msg: '最後整理失敗：' + String(e.message).slice(0, 160) }); }
    m.status = 'done'; this.save(m, true); this.live.delete(id); this.ctx.store.audit('app', 'meeting.stop', m.title);
    this._announce(m).catch(() => {}); return m;
  }
  async summarizeNow(id) { const m = this.get(id); if (!m.segments.length) throw new Error('還沒有逐字稿'); const n = await this._summarize(m, this.transcript(m), null, true); Object.assign(m.notes, n, { updatedAt: Date.now(), final: m.status !== 'live' }); if (m.status === 'interrupted') m.status = 'done'; this.save(m, true); return m; }
  async _announce(m) {
    const md = this.markdown(m, { short: true });
    try { await this.ctx.notifier.push('info', `會議記錄完成：${m.title}`, md.slice(0, 1400), { force: true }); } catch { /* ignore */ }
    const d = this.ctx.hub && this.ctx.hub.connectors && this.ctx.hub.connectors.discord;
    if (m.discord && m.discord.reply_channel && d) { try { await d.send(m.discord.reply_channel, md.slice(0, 3800)); } catch (e) { log.warn('會議記錄傳回 Discord 失敗：' + e.message); } }
  }
  remove(id) { const L = this.live.get(id); if (L) throw new Error('會議還在進行中，請先結束'); fs.rmSync(this.file(id), { force: true }); this.cache.delete(id); return { ok: true }; }
  rename(id, title) { const m = this.get(id); m.title = String(title || '').trim().slice(0, 80) || m.title; m.autoTitle = false; this.save(m, true); return m; }
  /** 會議記錄（Markdown） */
  markdown(m, { short = false, transcript = !short } = {}) {
    if (typeof m === 'string') m = this.get(m); const n = m.notes; const tz = this.ctx.settings.get('timezone', 'Asia/Taipei');
    const when = new Date(m.startedAt).toLocaleString('zh-TW', { hour12: false, timeZone: tz }); const dur = fmtT((m.endedAt || Date.now()) - m.startedAt);
    const L = [`# ${m.title}`, `${when}・長度 ${dur}${m.discord ? `・Discord「${m.discord.channel_name || ''}」` : ''}${[...new Set(m.segments.map((s) => s.speaker).filter(Boolean))].length ? '・與會：' + [...new Set(m.segments.map((s) => s.speaker).filter(Boolean))].join('、') : ''}`, ''];
    if (n.summary) L.push('## 摘要', n.summary, '');
    if (n.points.length) L.push('## 重點', ...n.points.map((x) => '- ' + x), '');
    if (n.decisions.length) L.push('## 決議', ...n.decisions.map((x) => '- ' + x), '');
    if (n.actions.length) L.push('## 待辦', ...n.actions.map((a) => `- ${a.who ? a.who + '：' : ''}${a.what}${a.due ? `（${a.due}）` : ''}`), '');
    if (n.questions.length) L.push('## 待確認', ...n.questions.map((x) => '- ' + x), '');
    if (!n.summary && !n.points.length) L.push(m.segments.length ? '（重點還在整理中）' : '（還沒有聽到內容）', '');
    if (transcript && m.segments.length) L.push('## 逐字稿', this.transcript(m));
    return L.join('\n').trim();
  }
  state(id) { const m = this.get(id); const L = this.live.get(id); return { ...m, worker: m.worker, pending: L ? L.busy + L.queue.length : 0 }; }
  /** voice-worker 的心跳：回傳要不要停、以及要轉給它的 gateway 事件 */
  workerPing(id) { const L = this.live.get(id); if (!L) return { stop: true }; const ev = L.events.splice(0); return { stop: !!L.stop, events: ev }; }
  workerStatus(id, st) { const m = this.get(id); m.worker = { ...(m.worker || {}), ...st, ts: Date.now() }; if (st.error) { m.errors.push({ ts: Date.now(), msg: 'Discord 語音：' + String(st.error).slice(0, 200) }); m.errors = m.errors.slice(-20); } this.save(m); }
  pushEvent(id, ev) { const L = this.live.get(id); if (L) { L.events.push(ev); L.events = L.events.slice(-10); } }
}
function parseJson(t) { const s = String(t || ''); const a = s.indexOf('{'), b = s.lastIndexOf('}'); if (a < 0 || b <= a) throw new Error('模型沒有回傳 JSON'); return JSON.parse(s.slice(a, b + 1)); }
module.exports = { Meetings, fmtT, HALLU, parseJson };
