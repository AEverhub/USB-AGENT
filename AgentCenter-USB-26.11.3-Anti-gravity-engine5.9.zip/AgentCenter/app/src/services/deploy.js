'use strict';
/**
 * 伺服器安裝（26.11.3 Revise4）：把這台的 AI 後台（程式＋資料庫）用「一串指令」部署到另一台主機上
 * （Linux 伺服器、VPS、樹莓派，或另一支手機的 Termux），讓 AI 24 小時在那裡跑，手機只當遙控器。
 *
 * 兩種方式：
 *   1. 一行指令：curl -fsSL '<這台的公開網址>/net/deploy/<一次性代碼>/install.sh' | bash
 *      → 伺服器從這台手機（透過內網穿透）下載程式與資料。代碼 60 分鐘內有效、最多下載 6 次。
 *   2. 下載安裝檔：一個自帶程式與資料的 .sh 檔，複製到伺服器後 bash agent-center-install.sh（不需要手機在線上）。
 *
 * 安裝腳本會：偵測環境（Termux／Debian／Ubuntu／Alpine／Fedora／Arch）→ 需要時安裝 Node.js 18+ → 解開程式 →
 *   匯入資料（可選；金鑰只有設了密碼才會帶）→ 設定 /claim 密碼、伺服器名稱、公開網址 → 設成「主機」→ 建立開機自動啟動（systemd／Termux:Boot／crontab）→
 *   印出：連線連結（App 點了就連上）、/claim 用法、本機管理介面網址。
 * 伺服器上沒有人用 App 本機，所以「管理員」靠 /claim：連上伺服器後在對話裡傳「/claim 密碼」就成為管理員
 * （有帶資料過去時，原本的管理員用同一台手機連上就直接是管理員）。
 */
const fs = require('fs');
const path = require('path');
const zlib = require('zlib');
const crypto = require('crypto');

const ROOT = path.join(__dirname, '../..');
const SKIP = /^(data|test|\.git)(\/|$)|(^|\/)(\.DS_Store|.*\.log|package-lock\.json)$/;

/** 最小的 tar 打包（ustar），再 gzip */
function tarGz(baseDir, filter = () => true) {
  const blocks = []; const pad = (b) => { const r = b.length % 512; return r ? Buffer.concat([b, Buffer.alloc(512 - r)]) : b; };
  const header = (name, size, mode, type = '0') => {
    const h = Buffer.alloc(512); let prefix = ''; let nm = name;
    if (Buffer.byteLength(nm) > 100) { const i = nm.lastIndexOf('/', nm.length - 1); prefix = nm.slice(0, i); nm = nm.slice(i + 1); if (Buffer.byteLength(prefix) > 155 || Buffer.byteLength(nm) > 100) throw new Error('檔名太長：' + name); }
    h.write(nm, 0, 100, 'utf8'); h.write(mode.toString(8).padStart(7, '0') + '\0', 100); h.write('0000000\0', 108); h.write('0000000\0', 116);
    h.write(size.toString(8).padStart(11, '0') + '\0', 124); h.write(Math.floor(Date.now() / 1000).toString(8).padStart(11, '0') + '\0', 136); h.write('        ', 148); h.write(type, 156);
    h.write('ustar\0', 257); h.write('00', 263); h.write(prefix, 345, 155, 'utf8');
    let sum = 0; for (const b of h) sum += b; h.write(sum.toString(8).padStart(6, '0') + '\0 ', 148); return h;
  };
  let count = 0; let bytes = 0;
  const walk = (dir, rel) => {
    for (const e of fs.readdirSync(dir, { withFileTypes: true }).sort((a, b) => a.name.localeCompare(b.name))) {
      const r = rel ? `${rel}/${e.name}` : e.name; if (SKIP.test(r) || !filter(r)) continue; const abs = path.join(dir, e.name);
      if (e.isDirectory()) walk(abs, r);
      else if (e.isFile()) { const buf = fs.readFileSync(abs); blocks.push(header(r, buf.length, /\.sh$/.test(r) ? 0o755 : 0o644), pad(buf)); count++; bytes += buf.length; }
    }
  };
  walk(baseDir, ''); blocks.push(Buffer.alloc(1024));
  return { buf: zlib.gzipSync(Buffer.concat(blocks), { level: 9 }), files: count, bytes };
}

const shq = (s) => `'${String(s).replace(/'/g, `'\\''`)}'`;

/** 安裝腳本本體（兩種方式共用；FETCH 決定怎麼拿到 bundle.tgz／data.json） */
function script({ fetchBundle, fetchData, hasData, opts }) {
  const setup = { server_name: opts.name || '伺服器', settings: { 'dev.claim_password': opts.claim_password || '', 'dev.hook_bind': '0.0.0.0', 'dev.hook_port': +opts.port || 8787, ...(opts.public_url ? { 'dev.public_base_url': opts.public_url } : {}) } };
  return `#!/usr/bin/env bash
# Agent中控中心 伺服器安裝腳本（由 App 的「開發者 → 伺服器」產生）。可在 Linux 伺服器、VPS、樹莓派、Termux 執行。
set -euo pipefail
APP_DIR="\${AGENT_DIR:-$HOME/agent-center}"; DATA="$APP_DIR/data"; PORT_UI="\${AGENT_UI_PORT:-8765}"; PORT_PUBLIC=${+opts.port || 8787}
say(){ printf '\\n\\033[1;36m▶ %s\\033[0m\\n' "$*"; }; die(){ printf '\\n\\033[1;31m✖ %s\\033[0m\\n' "$*"; exit 1; }
SUDO=""; if [ "$(id -u)" != "0" ] && command -v sudo >/dev/null 2>&1; then SUDO="sudo"; fi
IS_TERMUX=0; case "\${PREFIX:-}" in *com.termux*) IS_TERMUX=1;; esac

say "1/6 檢查 Node.js（需要 18 以上）"
need_node(){ ! command -v node >/dev/null 2>&1 || [ "$(node -p 'process.versions.node.split(".")[0]')" -lt 18 ]; }
if need_node; then
  if [ $IS_TERMUX = 1 ]; then pkg update -y && (pkg install -y nodejs-lts || pkg install -y nodejs)
  elif command -v apt-get >/dev/null; then $SUDO apt-get update -y && $SUDO apt-get install -y curl ca-certificates && curl -fsSL https://deb.nodesource.com/setup_20.x | $SUDO bash - && $SUDO apt-get install -y nodejs
  elif command -v apk >/dev/null; then $SUDO apk add --no-cache nodejs npm
  elif command -v dnf >/dev/null; then $SUDO dnf install -y nodejs
  elif command -v yum >/dev/null; then curl -fsSL https://rpm.nodesource.com/setup_20.x | $SUDO bash - && $SUDO yum install -y nodejs
  elif command -v pacman >/dev/null; then $SUDO pacman -Sy --noconfirm nodejs npm
  else die "找不到套件管理員，請先自己安裝 Node.js 18 以上再重跑"; fi
fi
need_node && die "Node.js 版本還是太舊（$(node -v)）"
echo "Node $(node -v)"

say "2/6 下載並解開程式到 $APP_DIR"
mkdir -p "$APP_DIR/app" "$DATA"; TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT
${fetchBundle}
tar -xzf "$TMP/bundle.tgz" -C "$APP_DIR/app"
if [ ! -d "$APP_DIR/app/node_modules/ws" ]; then (cd "$APP_DIR/app" && npm install --omit=dev --no-audit --no-fund); fi

say "3/6 匯入資料"
${hasData ? `if [ -f "$DATA/db.json" ] && [ "\${AGENT_OVERWRITE:-0}" != "1" ]; then echo "這台已經有資料，略過匯入（要覆蓋請加 AGENT_OVERWRITE=1）"; else
${fetchData}
  node "$APP_DIR/app/main.js" --data="$DATA" --import="$TMP/data.json" \${AGENT_IMPORT_PASSWORD:+--import-password="$AGENT_IMPORT_PASSWORD"}
fi` : 'echo "不帶資料：全新的 AI（之後在對話裡用 /claim 成為管理員）"'}

say "4/6 設定伺服器（/claim 密碼、主機模式、公開網址）"
PUB="\${AGENT_PUBLIC_URL:-${opts.public_url || ''}}"
if [ -z "$PUB" ]; then IP="$(curl -fsS --max-time 6 https://api.ipify.org 2>/dev/null || hostname -I 2>/dev/null | awk '{print $1}' || echo 127.0.0.1)"; PUB="http://$IP:$PORT_PUBLIC"; fi
cat > "$TMP/setup.json" <<'JSON'
${JSON.stringify(setup)}
JSON
node "$APP_DIR/app/main.js" --data="$DATA" --setup="$TMP/setup.json" --public-url="$PUB" > "$TMP/setup.out"
cat "$TMP/setup.out"

say "5/6 設定開機自動啟動"
TOKEN="$(node -e 'console.log(require("crypto").randomBytes(16).toString("hex"))')"; echo "$TOKEN" > "$APP_DIR/.ui_token"; chmod 600 "$APP_DIR/.ui_token"
cat > "$APP_DIR/start.sh" <<EOF
#!/usr/bin/env bash
cd "$APP_DIR/app" && exec node main.js --data="$DATA" --port=$PORT_UI --token=\\$(cat "$APP_DIR/.ui_token")
EOF
chmod +x "$APP_DIR/start.sh"
if [ $IS_TERMUX = 0 ] && command -v systemctl >/dev/null 2>&1 && [ -d /run/systemd/system ] && { [ "$(id -u)" = "0" ] || [ -n "$SUDO" ]; }; then
  $SUDO tee /etc/systemd/system/agent-center.service >/dev/null <<EOF
[Unit]
Description=Agent中控中心 AI 後台
After=network-online.target
[Service]
User=$(id -un)
ExecStart=$APP_DIR/start.sh
Restart=always
RestartSec=5
[Install]
WantedBy=multi-user.target
EOF
  $SUDO systemctl daemon-reload && $SUDO systemctl enable --now agent-center && echo "已用 systemd 啟動（systemctl status agent-center）"
else
  pkill -f "$APP_DIR/app/main.js" 2>/dev/null || true
  nohup "$APP_DIR/start.sh" > "$APP_DIR/server.log" 2>&1 &
  if [ $IS_TERMUX = 1 ]; then mkdir -p "$HOME/.termux/boot"; printf '#!/data/data/com.termux/files/usr/bin/sh\\ntermux-wake-lock\\n%s/start.sh > %s/server.log 2>&1 &\\n' "$APP_DIR" "$APP_DIR" > "$HOME/.termux/boot/agent-center"; chmod +x "$HOME/.termux/boot/agent-center"; echo "Termux：已設定開機啟動（需安裝 Termux:Boot），建議執行 termux-wake-lock 避免被休眠"
  elif command -v crontab >/dev/null 2>&1; then (crontab -l 2>/dev/null | grep -v agent-center; echo "@reboot $APP_DIR/start.sh > $APP_DIR/server.log 2>&1 # agent-center") | crontab -; echo "已用 crontab 設定開機啟動"; fi
fi

say "6/6 完成"
sleep 3
echo "公開網址（App 連線用，防火牆要開 $PORT_PUBLIC 埠，建議用 HTTPS 反向代理或 cloudflared）：$PUB"
echo "本機管理介面（只限伺服器本機，可用 ssh -L $PORT_UI:127.0.0.1:$PORT_UI 轉過來）：http://127.0.0.1:$PORT_UI/#t=$TOKEN"
echo "成為管理員：App 連上這台伺服器後，在對話裡傳「/claim 你設定的密碼」。"
`;
}

class Deploy {
  constructor(ctx) { this.ctx = ctx; this.jobs = new Map(); this.dir = path.join(ctx.paths.tmp, 'deploy'); }
  /** 準備一次安裝：打包程式（＋可選資料），產生一行指令與可下載的安裝檔 */
  async prepare({ include_data = true, password = '', claim_password = '', name = '', port = 8787, public_url = '' } = {}) {
    if (!claim_password || String(claim_password).length < 6) throw new Error('請設定伺服器的 /claim 密碼（至少 6 個字），之後用它在伺服器上取得管理員');
    if (password && String(password).length < 6) throw new Error('資料保護密碼至少 6 個字');
    if (public_url && !/^https?:\/\/[\w.-]+(:\d+)?\/?$/.test(public_url)) throw new Error('伺服器公開網址格式像 https://ai.example.com 或 http://1.2.3.4:8787');
    fs.mkdirSync(this.dir, { recursive: true }); for (const f of fs.readdirSync(this.dir)) { const p = path.join(this.dir, f); try { if (Date.now() - fs.statSync(p).mtimeMs > 3 * 3600e3) fs.rmSync(p, { recursive: true, force: true }); } catch { /* ignore */ } }
    const token = crypto.randomBytes(18).toString('base64url'); const d = path.join(this.dir, token); fs.mkdirSync(d);
    const b = tarGz(ROOT); fs.writeFileSync(path.join(d, 'bundle.tgz'), b.buf);
    let data = null; if (include_data) { const ex = await this.ctx.transfer.export({ password, media: true, workspace: true }); fs.renameSync(this.ctx.transfer.path(ex.id), path.join(d, 'data.json')); data = { size: ex.size_text, secrets: !!password }; }
    const opts = { name: name || ((this.ctx.settings.get('link.me') || {}).name ? (this.ctx.settings.get('link.me').name + ' 的伺服器') : 'AI 伺服器'), claim_password, port: +port || 8787, public_url: (public_url || '').replace(/\/+$/, '') };
    const base = (this.ctx.tunnel && this.ctx.tunnel.info && this.ctx.tunnel.info().url) || this.ctx.settings.get('dev.public_base_url') || '';
    const job = { token, dir: d, opts, hasData: !!data, expires: Date.now() + 60 * 60e3, downloads: 0 }; this.jobs.set(token, job);
    // 自帶程式與資料的安裝檔（不需要手機在線上）
    const embed = (file) => `base64 -d > "$TMP/${file}" <<'B64'\n${fs.readFileSync(path.join(d, file)).toString('base64').replace(/.{1,76}/g, '$&\n')}B64`;
    fs.writeFileSync(path.join(d, 'standalone.sh'), script({ fetchBundle: embed('bundle.tgz'), fetchData: data ? '  ' + embed('data.json') : '', hasData: !!data, opts }), { mode: 0o755 });
    this.ctx.store.audit('app', 'deploy_prepare', `${b.files} 個檔案${data ? '＋資料' : ''}`);
    const url = base ? `${base.replace(/\/+$/, '')}/net/deploy/${token}/install.sh` : '';
    return { token, files: b.files, bundle_size: Math.round(b.buf.length / 1024) + ' KB', data, expires: job.expires,
      command: url ? `curl -fsSL ${shq(url)} | bash` : '', termux: url ? `pkg install -y curl && curl -fsSL ${shq(url)} | bash` : '',
      with_password: data && data.secrets ? `curl -fsSL ${shq(url)} | AGENT_IMPORT_PASSWORD='你的資料保護密碼' bash` : '',
      note: url ? '' : '這台還沒有公開網址（到「監控」啟動 Bot、內網穿透連上後才能用一行指令）。可以先用「下載安裝檔」。',
      standalone: `/api/deploy/${token}/standalone.sh` };
  }
  /** 公開埠：伺服器用一次性代碼下載 install.sh／bundle.tgz／data.json */
  serve(req, res, p) {
    const m = /^\/net\/deploy\/([\w-]{20,40})\/(install\.sh|bundle\.tgz|data\.json)$/.exec(p); const job = m && this.jobs.get(m[1]);
    if (!job || Date.now() > job.expires || job.downloads >= 6 * 3) { res.writeHead(404, { 'content-type': 'text/plain; charset=utf-8' }); return res.end('echo "這個安裝指令已過期，請到 App 重新產生"; exit 1\n'); }
    job.downloads++;
    if (m[2] === 'install.sh') {
      const base = `${(req.headers['x-forwarded-proto'] || 'https')}://${req.headers.host}/net/deploy/${m[1]}`;
      const body = script({ fetchBundle: `curl -fsSL "${base}/bundle.tgz" -o "$TMP/bundle.tgz"`, fetchData: `  curl -fsSL "${base}/data.json" -o "$TMP/data.json"`, hasData: job.hasData, opts: job.opts });
      res.writeHead(200, { 'content-type': 'text/x-shellscript; charset=utf-8', 'cache-control': 'no-store' }); return res.end(body);
    }
    const f = path.join(job.dir, m[2]); if (!fs.existsSync(f)) { res.writeHead(404); return res.end(); }
    res.writeHead(200, { 'content-type': m[2].endsWith('.tgz') ? 'application/gzip' : 'application/json', 'content-length': fs.statSync(f).size, 'cache-control': 'no-store' }); fs.createReadStream(f).pipe(res);
  }
  standalonePath(token) { const job = this.jobs.get(String(token)); if (!job) throw new Error('已過期，請重新產生'); return path.join(job.dir, 'standalone.sh'); }
}
module.exports = { Deploy, tarGz, script };
