'use strict';
/**
 * 內網穿透：讓手機上的 Webhook 伺服器（hook server）有公開 https 網址，給 LINE 等平台回呼。
 * App 的「操作頁／設定頁／開發者頁」都會顯示目前網址、LINE Webhook URL、連線狀態。
 *
 * provider：
 *  auto               有 cloudflared 執行檔就用 cloudflared，否則退回 cloudflare-worker（若已填中繼網址）或 localtunnel
 *  cloudflared        手機上直接跑 Cloudflare Tunnel（二進位檔隨 APK，見 建置流程.md）
 *                       ‧ 沒填 token → Quick Tunnel：隨機 *.trycloudflare.com，每次重連網址會變（App 會自動更新 LINE Webhook）
 *                       ‧ 有填 token → 具名隧道：固定網址（在 Cloudflare Zero Trust 建立，Public Hostname 指向 http://127.0.0.1:<hook_port>）
 *  cloudflare-worker  不需要任何二進位檔：LINE → 你的 Cloudflare Worker（固定網址）→ App 每幾秒輪詢拉取事件（relay/ 資料夾）
 *  localtunnel        純 JS 備援（網址不固定、穩定度普通）
 *  manual             你自己有網址（Tailscale Funnel／自家主機），只做顯示與健康檢查
 */
const net = require('net');
const { spawn } = require('child_process');
const fs = require('fs');
const { logger } = require('../core/log');
const { fetchJson } = require('../core/util');
const log = logger('tunnel');

class Tunnel {
  constructor(ctx) { this.ctx = ctx; this.name = 'tunnel'; this.state = { status: 'off', provider: '', url: '', since: 0, error: '', lastOk: 0, changes: 0, note: '' }; this.socks = new Set(); this.proc = null; this.active = false; this.prevUrl = ''; }
  get cfg() { return this.ctx.settings.get('tunnel'); }
  get port() { return +this.ctx.settings.get('dev.hook_port', 8787) || 8787; }
  cfBin() { const p = this.cfg.cloudflared_path || process.env.CLOUDFLARED_PATH || ''; return p && fs.existsSync(p) ? p : ''; }
  resolveProvider() {
    const p = this.cfg.provider; if (p !== 'auto') return p;
    if (this.cfBin()) return 'cloudflared';
    if (this.ctx.settings.get('platforms.line.relay_url')) return 'cloudflare-worker';
    return 'localtunnel';
  }
  info() {
    const url = this.state.url; const prov = this.state.provider;
    return { ...this.state, configured_provider: this.cfg.provider, enabled: !!this.cfg.enabled, local: `http://127.0.0.1:${this.port}`, hook_bind: this.ctx.settings.get('dev.hook_bind'),
      webhooks: url ? { line: url + '/hook/line', health: url + '/health' } : null, mode: prov === 'cloudflare-worker' ? '中繼輪詢（LINE→Cloudflare Worker→App 拉取）' : prov === 'cloudflared' ? (this.cfg.cloudflare_token ? 'Cloudflare 具名隧道（固定網址）' : 'Cloudflare Quick Tunnel（網址會變）') : prov };
  }
  async start() {
    this.active = true; if (!this.cfg.enabled) { this.state = { ...this.state, status: 'off', url: '', error: '' }; return; }
    const prov = this.resolveProvider(); this.state = { ...this.state, status: 'starting', provider: prov, error: '', note: '' };
    try {
      if (prov === 'manual') { if (!this.cfg.manual_url) throw new Error('尚未填寫手動網址'); this._up(this.cfg.manual_url.replace(/\/+$/, '')); }
      else if (prov === 'cloudflare-worker') { const u = this.ctx.settings.get('platforms.line.relay_url'); if (!u) throw new Error('尚未填寫 Cloudflare Worker 網址（設定頁 → LINE → relay 網址）'); this._up(u.replace(/\/+$/, '')); }
      else if (prov === 'cloudflared') await this._cloudflared();
      else await this._localtunnel();
    } catch (e) { this.state.status = 'error'; this.state.error = e.message; log.warn('穿透啟動失敗：' + e.message); throw e; }
  }
  async stop() { this.active = false; for (const s of this.socks) { try { s.destroy(); } catch { /* ignore */ } } this.socks.clear(); if (this.proc) { try { this.proc.kill(); } catch { /* ignore */ } this.proc = null; } this.state = { ...this.state, status: 'off' }; }
  _up(url, note = '') {
    const changed = url !== this.prevUrl; this.state = { ...this.state, status: 'up', url, since: Date.now(), error: '', lastOk: Date.now(), note, changes: this.state.changes + (changed && url ? 1 : 0) };
    if (changed && url) { this.prevUrl = url; log.info('公開網址：' + url); this.ctx.store.db.meta.tunnel_url = url; this.ctx.store.touch(); this.onUrl(url).catch((e) => log.warn('onUrl：' + e.message)); }
  }
  async onUrl(url) {
    const line = this.ctx.settings.get('platforms.line');
    if (line.enabled && line.auto_webhook && line.token) {
      try { const r = await fetchJson('https://api.line.me/v2/bot/channel/webhook/endpoint', { method: 'PUT', headers: { 'content-type': 'application/json', authorization: 'Bearer ' + line.token }, body: JSON.stringify({ endpoint: url + '/hook/line' }) }, 15000);
        if (r.ok) log.info('已自動更新 LINE Webhook URL'); else log.warn('自動更新 LINE Webhook 失敗 ' + r.status + ' ' + r.text.slice(0, 120)); } catch (e) { log.warn('自動更新 LINE Webhook 失敗：' + e.message); }
    }
    await this.ctx.notifier.info('公開網址已更新', `${url}\nLINE Webhook：${url}/hook/line`);
  }
  async health() {
    if (!this.cfg.enabled) return true; if (this.state.status !== 'up') return false;
    if (!this.state.url) return !!this.proc;                       // 具名隧道沒填主機名稱時，只能看行程是否還活著
    try { const r = await fetch(this.state.url + '/health', { signal: AbortSignal.timeout(10000), headers: { 'bypass-tunnel-reminder': '1' } }); if (r.ok) { this.state.lastOk = Date.now(); return true; } } catch { /* fallthrough */ }
    return Date.now() - this.state.lastOk < 150000;                // 容忍短暫失敗；連續 2.5 分鐘失敗才交給守護進程重啟
  }

  // ---- Cloudflare Tunnel（cloudflared）----
  _cloudflared() {
    return new Promise((resolve, reject) => {
      const bin = this.cfBin(); if (!bin) return reject(new Error('找不到 cloudflared 執行檔（APK 需內含 libcloudflared.so；見 建置流程.md §6）。可改選「Cloudflare Worker 中繼」。'));
      const token = this.cfg.cloudflare_token; const host = (this.cfg.cloudflare_hostname || '').replace(/^https?:\/\//, '').replace(/\/+$/, '');
      const args = token ? ['tunnel', '--no-autoupdate', '--protocol', 'http2', 'run', '--token', token] : ['tunnel', '--no-autoupdate', '--protocol', 'http2', '--url', `http://127.0.0.1:${this.port}`];
      // Android 沒有 /etc/resolv.conf：強制使用 cgo（bionic）解析器；HOME/TMPDIR 指到 App 可寫目錄
      const env = { ...process.env, GODEBUG: 'netdns=cgo', HOME: this.ctx.paths.home, TMPDIR: this.ctx.paths.tmp, TUNNEL_ORIGIN_CERT: '' };
      const p = spawn(bin, args, { stdio: ['ignore', 'pipe', 'pipe'], env }); this.proc = p; let done = false; let tail = '';
      const scan = (d) => {
        const t = d.toString(); tail = (tail + t).slice(-600);
        for (const l of t.split('\n')) if (l.trim()) log.debug('[cloudflared] ' + l.trim());
        if (!done && !token) { const m = /https:\/\/[a-z0-9-]+\.trycloudflare\.com/.exec(t); if (m) { done = true; this._up(m[0], 'Quick Tunnel：網址每次重連都會變'); resolve(); } }
        if (!done && token && /Registered tunnel connection|Connection [0-9a-f-]+ registered/i.test(t)) { done = true; this._up(host ? 'https://' + host : '', host ? '' : '隧道已連線，但沒填「公開主機名稱」，請到設定頁補上（Cloudflare 後台 Public Hostname）'); this.state.status = 'up'; resolve(); }
        if (/failed to (?:parse|unmarshal) tunnel token|Unauthorized|invalid token/i.test(t) && !done) { done = true; reject(new Error('Cloudflare token 無效')); }
      };
      p.stdout.on('data', scan); p.stderr.on('data', scan);
      p.on('error', (e) => { if (!done) { done = true; reject(e); } });
      p.on('close', (c) => { this.proc = null; if (this.active) { this.state.status = 'error'; this.state.error = 'cloudflared 結束 code=' + c + (tail ? '：' + tail.split('\n').slice(-2).join(' ').slice(0, 200) : ''); } if (!done) { done = true; reject(new Error(this.state.error || 'cloudflared 結束 code=' + c)); } });
      setTimeout(() => { if (!done) { done = true; reject(new Error('cloudflared 連線逾時（45 秒）。網路可能擋 7844 埠；已使用 http2 協定。')); } }, 45000);
    });
  }

  // ---- localtunnel（純 JS 備援）----
  async _localtunnel() {
    const server = (this.cfg.server || 'https://localtunnel.me').replace(/\/+$/, ''); const sub = (this.cfg.subdomain || '').replace(/[^a-z0-9-]/gi, '').toLowerCase();
    const r = await fetchJson(`${server}/${sub || '?new'}`, { headers: { 'bypass-tunnel-reminder': '1' } }, 20000);
    if (!r.ok || !r.json || !r.json.port) throw new Error(`localtunnel 伺服器回應異常 ${r.status} ${String(r.text).slice(0, 100)}`);
    const { port, url } = r.json; const host = new URL(server).hostname; const n = Math.min(r.json.max_conn_count || 4, 6);
    const open = () => {
      if (!this.active) return; const remote = net.connect({ host, port }); this.socks.add(remote); remote.setKeepAlive(true, 20000);
      const retry = () => { this.socks.delete(remote); if (this.active && this.state.provider === 'localtunnel') setTimeout(open, 1500); };
      remote.once('error', () => { try { remote.destroy(); } catch { /* ignore */ } }); remote.once('close', retry);
      remote.once('data', (first) => { remote.pause(); const local = net.connect({ host: '127.0.0.1', port: this.port });
        local.once('connect', () => { local.write(first); remote.pipe(local); local.pipe(remote); remote.resume(); });
        local.once('error', () => { try { remote.destroy(); } catch { /* ignore */ } }); local.once('close', () => { try { remote.destroy(); } catch { /* ignore */ } }); });
    };
    for (let i = 0; i < n; i++) open(); this._up(url, 'localtunnel 備援：網址不固定');
  }
}
module.exports = { Tunnel };
