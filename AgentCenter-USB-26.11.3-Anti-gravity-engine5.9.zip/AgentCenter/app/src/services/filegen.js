'use strict';
/**
 * AI 產檔案：txt／md／csv／json／html／xlsx／docx／pdf。
 *   docx：自己組 Office Open XML（標題、段落、條列、表格），不靠外部套件
 *   xlsx：沿用 services/xlsx.js
 *   pdf：用瀏覽器（內建 Linux 的 Chromium 或本機 Chrome）開一個「獨立的隱藏分頁」列印成 PDF，不會打擾 AI 正在用的分頁
 * 檔案存在工作區 exports/，並記在 db.files_out（App 對話裡可下載；LINE／Telegram／Discord 由平台送出）。
 */
const fs = require('fs');
const path = require('path');
const { zip, buildXlsx } = require('./xlsx');
const { rid } = require('../core/util');

const MIME = { txt: 'text/plain; charset=utf-8', md: 'text/markdown; charset=utf-8', csv: 'text/csv; charset=utf-8', json: 'application/json', html: 'text/html; charset=utf-8', xlsx: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', docx: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', pdf: 'application/pdf', tex: 'application/x-tex; charset=utf-8' };
const FORMATS = Object.keys(MIME);
const x = (s) => String(s ?? '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c])).replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/g, '');

/** 把「類 Markdown」文字拆成區塊：# 標題、- 條列、| 表格 |、一般段落 */
function blocks(text) {
  const out = []; const lines = String(text || '').replace(/\r/g, '').split('\n');
  for (let i = 0; i < lines.length; i++) {
    const l = lines[i];
    if (/^\s*\|.*\|\s*$/.test(l)) { const rows = []; while (i < lines.length && /^\s*\|.*\|\s*$/.test(lines[i])) { const r = lines[i].trim().slice(1, -1).split('|').map((c) => c.trim()); if (!r.every((c) => /^:?-{2,}:?$/.test(c))) rows.push(r); i++; } i--; out.push({ t: 'table', rows }); continue; }
    const h = /^(#{1,3})\s+(.*)$/.exec(l); if (h) { out.push({ t: 'h', level: h[1].length, text: h[2] }); continue; }
    const b = /^\s*(?:[-*・•]|\d+[.)、])\s+(.*)$/.exec(l); if (b) { out.push({ t: 'li', text: b[1], num: /^\s*\d/.test(l) }); continue; }
    out.push({ t: 'p', text: l });
  }
  return out;
}
const inline = (s) => String(s).replace(/\*\*(.+?)\*\*/g, '$1').replace(/`([^`]+)`/g, '$1');

function docx(title, text) {
  const run = (s, bold) => `<w:r><w:rPr>${bold ? '<w:b/>' : ''}<w:rFonts w:eastAsia="Microsoft JhengHei"/></w:rPr><w:t xml:space="preserve">${x(s)}</w:t></w:r>`;
  const para = (s, style) => `<w:p>${style ? `<w:pPr><w:pStyle w:val="${style}"/></w:pPr>` : ''}${String(s).split(/(\*\*.+?\*\*)/).filter(Boolean).map((seg) => (/^\*\*.+\*\*$/.test(seg) ? run(seg.slice(2, -2), true) : run(seg.replace(/`([^`]+)`/g, '$1')))).join('')}</w:p>`;
  const body = [];
  if (title) body.push(para(title, 'Title'));
  for (const bk of blocks(text)) {
    if (bk.t === 'h') body.push(para(bk.text, 'Heading' + bk.level));
    else if (bk.t === 'li') body.push(para((bk.num ? '' : '• ') + bk.text, 'ListParagraph'));
    else if (bk.t === 'table') {
      const cols = Math.max(...bk.rows.map((r) => r.length)); const cell = (c, head) => `<w:tc><w:tcPr><w:tcW w:w="${Math.floor(9000 / cols)}" w:type="dxa"/></w:tcPr>${para(head ? `**${c}**` : c)}</w:tc>`;
      body.push(`<w:tbl><w:tblPr><w:tblStyle w:val="TableGrid"/><w:tblW w:w="5000" w:type="pct"/><w:tblBorders>${['top', 'left', 'bottom', 'right', 'insideH', 'insideV'].map((s) => `<w:${s} w:val="single" w:sz="4" w:color="999999"/>`).join('')}</w:tblBorders></w:tblPr><w:tblGrid>${Array.from({ length: cols }, () => `<w:gridCol w:w="${Math.floor(9000 / cols)}"/>`).join('')}</w:tblGrid>${bk.rows.map((r, i) => `<w:tr>${Array.from({ length: cols }, (_, j) => cell(r[j] || '', i === 0)).join('')}</w:tr>`).join('')}</w:tbl>`);
      body.push('<w:p/>');
    } else body.push(para(bk.text));
  }
  const W = 'xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"';
  const style = (id, name, size, bold) => `<w:style w:type="paragraph" w:styleId="${id}"><w:name w:val="${name}"/><w:basedOn w:val="Normal"/><w:pPr><w:spacing w:before="240" w:after="120"/></w:pPr><w:rPr>${bold ? '<w:b/>' : ''}<w:sz w:val="${size}"/></w:rPr></w:style>`;
  const files = {
    '[Content_Types].xml': '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/><Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/></Types>',
    '_rels/.rels': '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/></Relationships>',
    'word/_rels/document.xml.rels': '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>',
    'word/styles.xml': `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:styles ${W}><w:docDefaults><w:rPrDefault><w:rPr><w:rFonts w:ascii="Calibri" w:hAnsi="Calibri" w:eastAsia="Microsoft JhengHei"/><w:sz w:val="22"/></w:rPr></w:rPrDefault><w:pPrDefault><w:pPr><w:spacing w:after="80" w:line="300" w:lineRule="auto"/></w:pPr></w:pPrDefault></w:docDefaults><w:style w:type="paragraph" w:default="1" w:styleId="Normal"><w:name w:val="Normal"/></w:style>${style('Title', 'Title', 40, true)}${style('Heading1', 'heading 1', 32, true)}${style('Heading2', 'heading 2', 28, true)}${style('Heading3', 'heading 3', 24, true)}${style('ListParagraph', 'List Paragraph', 22, false)}<w:style w:type="table" w:styleId="TableGrid"><w:name w:val="Table Grid"/></w:style></w:styles>`,
    'word/document.xml': `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:document ${W}><w:body>${body.join('')}<w:sectPr><w:pgSz w:w="11906" w:h="16838"/><w:pgMar w:top="1200" w:right="1200" w:bottom="1200" w:left="1200" w:header="600" w:footer="600" w:gutter="0"/></w:sectPr></w:body></w:document>`,
  };
  return zip(Object.entries(files).map(([name, data]) => [name, Buffer.from(data, 'utf8')]));
}
/**
 * 26.11.3 Revise4 數學公式（LaTeX）：$…$、$$…$$、\(…\)、\[…\] → MathML（瀏覽器與 PDF 直接顯示，不需要字型檔）。
 * 用 App 內建的 KaTeX（ui/vendor/katex）；載入失敗就保留原始 LaTeX 文字。
 */
let katex = null; try { katex = require('../../ui/vendor/katex/katex.min.js'); } catch { /* 沒有就不轉 */ }
const MATH_RE = /\$\$([\s\S]+?)\$\$|\\\[([\s\S]+?)\\\]|\\\(([\s\S]+?)\\\)|\$(?!\s)([^\n$]+?)(?<!\s)\$(?!\d)/g;
function mathX(s) {   // 跳脫 HTML，但公式轉成 MathML
  const str = String(s ?? ''); if (!katex) return x(str); let out = ''; let last = 0;
  for (const m of str.matchAll(MATH_RE)) {
    const tex = m[1] ?? m[2] ?? m[3] ?? m[4]; const display = m[1] !== undefined || m[2] !== undefined;
    out += x(str.slice(last, m.index)); last = m.index + m[0].length;
    try { out += katex.renderToString(tex, { displayMode: display, output: 'mathml', throwOnError: false, strict: 'ignore' }); } catch { out += x(m[0]); }
  }
  return out + x(str.slice(last));
}
/** LaTeX 原始檔（.tex）：把類 Markdown 轉成 LaTeX；公式原樣保留。中文用 xeCJK（請用 XeLaTeX 編譯） */
function tex(title, text) {
  const s = String(text || ''); if (/\\documentclass/.test(s)) return s;   // 已經是完整 LaTeX
  const esc = (t) => { let out = ''; let last = 0; for (const m of t.matchAll(MATH_RE)) { out += t.slice(last, m.index).replace(/\\/g, '\\textbackslash{}').replace(/([&%#_{}])/g, '\\$1').replace(/~/g, '\\textasciitilde{}').replace(/\^/g, '\\textasciicircum{}').replace(/\*\*(.+?)\*\*/g, '\\textbf{$1}'); out += m[0]; last = m.index + m[0].length; } return out + t.slice(last).replace(/\\/g, '\\textbackslash{}').replace(/([&%#_{}])/g, '\\$1').replace(/~/g, '\\textasciitilde{}').replace(/\^/g, '\\textasciicircum{}').replace(/\*\*(.+?)\*\*/g, '\\textbf{$1}'); };
  const lines = []; let inList = false; let inTable = false; let cols = 0;
  for (const b of blocks(s)) {
    if (b.t !== 'li' && inList) { lines.push('\\end{itemize}'); inList = false; }
    if (b.t === 'h') lines.push(`\\${['section', 'subsection', 'subsubsection'][Math.min(b.level - 1, 2)]}{${esc(b.text)}}`);
    else if (b.t === 'li') { if (!inList) { lines.push('\\begin{itemize}'); inList = true; } lines.push(`  \\item ${esc(b.text)}`); }
    else if (b.t === 'table') { cols = Math.max(...b.rows.map((r) => r.length)); lines.push(`\\begin{tabular}{${'|l'.repeat(cols)}|}\\hline`, ...b.rows.map((r) => r.map(esc).join(' & ') + ' \\\\ \\hline'), '\\end{tabular}'); void inTable; }
    else lines.push(esc(b.text), '');
  }
  if (inList) lines.push('\\end{itemize}');
  return ['% 由 Agent中控中心 產生。含中文請用 XeLaTeX 編譯（例：Overleaf 選 XeLaTeX）', '\\documentclass[12pt]{article}', '\\usepackage{amsmath,amssymb}', '\\usepackage{xeCJK}', '\\usepackage[margin=2.5cm]{geometry}',
    title ? `\\title{${esc(title)}}` : '', '\\date{}', '\\begin{document}', title ? '\\maketitle' : '', ...lines, '\\end{document}', ''].filter((l, i, a) => l !== '' || a[i - 1] !== '').join('\n');
}
function html(title, text) {
  const parts = blocks(text).map((b) => (b.t === 'h' ? `<h${b.level + 1}>${mathX(inline(b.text))}</h${b.level + 1}>` : b.t === 'li' ? `<li>${mathX(inline(b.text))}</li>` : b.t === 'table' ? `<table>${b.rows.map((r, i) => `<tr>${r.map((c) => `<${i ? 'td' : 'th'}>${mathX(inline(c))}</${i ? 'td' : 'th'}>`).join('')}</tr>`).join('')}</table>` : b.text.trim() ? `<p>${mathX(inline(b.text))}</p>` : ''));
  const bodyHtml = parts.join('\n').replace(/(<li>[\s\S]*?<\/li>\n?)+/g, (m) => `<ul>${m}</ul>`);
  return `<!doctype html><html lang="zh-Hant"><head><meta charset="utf-8"><title>${x(title || '文件')}</title><style>body{font-family:"Noto Sans TC","Microsoft JhengHei",sans-serif;max-width:780px;margin:32px auto;padding:0 20px;line-height:1.7;color:#1b1f27}h1{font-size:26px}h2{font-size:21px;margin-top:28px}table{border-collapse:collapse;width:100%;margin:12px 0}th,td{border:1px solid #bbb;padding:6px 8px;text-align:left}th{background:#f1f3f7}@media print{body{margin:0}}</style></head><body>${title ? `<h1>${x(title)}</h1>` : ''}${bodyHtml}</body></html>`;
}
const csvCell = (v) => { const s = String(v ?? ''); return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s; };

class FileGen {
  constructor(ctx) { this.ctx = ctx; }
  get dir() { return path.join(this.ctx.paths.workspace, 'exports'); }
  get list() { const db = this.ctx.store.db; if (!Array.isArray(db.files_out)) db.files_out = []; return db.files_out; }
  /** 依名稱取（下載用） */
  get(id) { return this.list.find((f) => f.id === id) || null; }
  /** 26.11.3 Revise8：把工作區裡已有的檔案（例如使用者傳來的 inbox/…）登記成可下載的檔案卡 */
  register(rel, name, mime, owner = '') { const full = path.join(this.ctx.paths.workspace, rel); const rec = { id: rid(8), name: String(name || path.basename(rel)).slice(0, 120), path: rel, mime: mime || 'application/octet-stream', size: fs.statSync(full).size, at: Date.now(), owner, from: 'user' }; this.list.push(rec); if (this.list.length > 300) this.list.splice(0, this.list.length - 300); this.ctx.store.touch(); return rec; }
  async make({ name, format, title = '', content = '', rows = null, sheets = null }, owner = '') {
    format = String(format || (name && path.extname(name).slice(1)) || 'txt').toLowerCase(); if (format === 'markdown') format = 'md'; if (format === 'word') format = 'docx'; if (format === 'excel') format = 'xlsx';
    if (!FORMATS.includes(format)) throw new Error(`不支援 ${format}，可用：${FORMATS.join('、')}`);
    const base = String(name || title || '檔案').replace(/\.[a-z0-9]+$/i, '').replace(/[\\/:*?"<>|\u0000-\u001f]/g, '_').slice(0, 60) || '檔案';
    let buf;
    const tableRows = Array.isArray(rows) ? rows.map((r) => (Array.isArray(r) ? r : Object.values(r || {}))) : null;
    if (format === 'xlsx') {
      const list = Array.isArray(sheets) && sheets.length ? sheets : [{ name: title || base, rows: tableRows || blocks(content).filter((b) => b.t === 'table').flatMap((b) => b.rows) }];
      if (!list[0].rows || !list[0].rows.length) throw new Error('xlsx 需要 rows（二維陣列，第一列是標題）');
      const s = list[0]; buf = buildXlsx({ name: String(s.name || base).slice(0, 31), rows: s.rows.map((r, i) => r.map((v) => ({ v: typeof v === 'string' && v.trim() !== '' && !isNaN(v) && !/^0\d/.test(v) ? Number(v) : v, s: i === 0 ? 2 : 6 }))), widths: (s.rows[0] || []).map(() => 16) });
    } else if (format === 'csv') {
      const r = tableRows || blocks(content).filter((b) => b.t === 'table').flatMap((b) => b.rows); if (!r.length && !content) throw new Error('csv 需要 rows 或表格內容');
      buf = Buffer.from('﻿' + (r.length ? r.map((row) => row.map(csvCell).join(',')).join('\r\n') : content), 'utf8');
    } else if (format === 'json') { let v = content; try { v = JSON.stringify(typeof content === 'string' ? JSON.parse(content) : (rows || content), null, 2); } catch { v = JSON.stringify(rows || content, null, 2); } buf = Buffer.from(v, 'utf8'); }
    else if (format === 'docx') buf = docx(title, content || (tableRows ? tableRows.map((r) => `| ${r.join(' | ')} |`).join('\n') : ''));
    else if (format === 'html') buf = Buffer.from(html(title, content), 'utf8');
    else if (format === 'tex') buf = Buffer.from(tex(title, content), 'utf8');
    else if (format === 'pdf') buf = await this.pdf(html(title, content || (tableRows ? tableRows.map((r) => `| ${r.join(' | ')} |`).join('\n') : '')));
    else buf = Buffer.from((title ? (format === 'md' ? `# ${title}\n\n` : `${title}\n\n`) : '') + String(content || ''), 'utf8');
    if (buf.length > 20 * 1024 * 1024) throw new Error('檔案超過 20MB');
    fs.mkdirSync(this.dir, { recursive: true }); const file = `${base}.${format}`; let fn = file; for (let i = 2; fs.existsSync(path.join(this.dir, fn)); i++) fn = `${base}-${i}.${format}`;
    fs.writeFileSync(path.join(this.dir, fn), buf);
    const rec = { id: rid(8), name: fn, path: 'exports/' + fn, mime: MIME[format], size: buf.length, at: Date.now(), owner };
    this.list.push(rec); if (this.list.length > 300) this.list.splice(0, this.list.length - 300); this.ctx.store.touch(); return rec;
  }
  read(rec) { return fs.readFileSync(path.join(this.ctx.paths.workspace, rec.path)); }
  /** 用瀏覽器開「獨立分頁」列印 PDF；沒有瀏覽器就明講 */
  async pdf(htmlText) {
    const B = this.ctx.browser; if (!B || !B.enabled()) throw new Error('做 PDF 需要瀏覽器（內建 Linux 的 Chromium）；可先改用 docx 或 html');
    await B.ensure(); if (!B.tp || B.provider === 'android') throw new Error('目前的瀏覽器不能列印 PDF（App 內 WebView 不支援）；請安裝內建 Linux 的 Chromium，或改用 docx');
    const { httpGet, CDP } = require('./cdp');
    const t = await httpGet(B.tp, '/json/new?about:blank', 'PUT').catch(() => httpGet(B.tp, '/json/new?about:blank'));
    const c = new CDP(); try {
      await c.connect(B.tp, new URL(t.webSocketDebuggerUrl).pathname); await c.send('Page.enable');
      const tree = await c.send('Page.getFrameTree'); await c.send('Page.setDocumentContent', { frameId: tree.frameTree.frame.id, html: htmlText });
      await new Promise((r) => setTimeout(r, 400));
      const r = await c.send('Page.printToPDF', { printBackground: true, paperWidth: 8.27, paperHeight: 11.69, marginTop: 0.5, marginBottom: 0.5, marginLeft: 0.5, marginRight: 0.5 }, 60000);
      return Buffer.from(r.data, 'base64');
    } finally { try { c.close(); } catch { /* ignore */ } httpGet(B.tp, '/json/close/' + t.id).catch(() => {}); }
  }
}
module.exports = { FileGen, FORMATS, MIME, docx, html, blocks, tex, mathX };
