'use strict';
/**
 * 26.11.3 Anti-gravity-engine2：影片工作室——讓 AI 自己做影片。
 *   AI（video_make）寫「分鏡腳本」→ 這裡驗證、補預設、排進佇列（store.db.videos）→
 *   App 畫面（ui/video.js）在背景把每一格畫在 canvas 上，用 MediaRecorder 即時錄成 MP4／WebM（含合成的背景音樂）→
 *   上傳回來存到工作區 videos/ → 自動傳回提出要求的那個聊天室（LINE／Telegram／Discord／App）。
 * 手機上的 Node 沒有 ffmpeg，所以算圖交給 App 畫面（WebView 的 Chromium）；App 畫面要開著（任何一頁都行）才會開始做。
 * Anti-gravity-engine4：旁白人聲（雲端 TTS）、實拍素材（Pexels／你自己的影片／Gemini Omni）、數位主持人（HeyGen）、網頁截圖；
 *   Termux 裝好 HyperFrames 且自我測試通過時，改用 HyperFrames（HTML＋GSAP 逐格算圖＋FFmpeg）在背景做，不需要 App 畫面開著。
 */
const fs = require('fs');
const path = require('path');
const { rid, clip } = require('../core/util');
const AG = require('./autogen');

/** 一句話 → 分鏡（給模型的規則；輸出 JSON）。Anti-gravity-engine4：加上旁白（人聲）、實拍素材、風格（動態圖像／手繪故事／電影感實拍／產品宣傳／主持人） */
const VIDEO_SYS = `你是影片編導（融合 HyperFrames／GSAP 動態設計、Video Shotcraft 鏡頭語言、手繪故事動畫、motion design 原則）。依使用者的一句話，直接規劃一支影片，只輸出 JSON，不要任何說明文字。不要反問：資訊不足就用合理、通用、正確的內容。
格式：{"title":"影片標題（12 字內）","style":"motion|handdrawn|cinematic|product|presenter","size":"portrait|landscape|square","theme":"dark|light|vivid|warm|mono|ocean","music":"calm|upbeat|cinematic|none","presenter":false,"gender":"",
"scenes":[{"layout":"title|text|bullets|image|footage|screen|quote|stat|end","title":"","text":"","bullets":[""],"stat":{"value":"","label":""},"narration":"","duration":4,"anim":"fade|slide|zoom|type|draw","image_prompt":"","footage_query":"","ai_clip":""}]}
風格：一般知識／教學／資訊 → motion；說故事、童話、繪本、寓言 → handdrawn；旅遊、美食、生活、情緒、品牌形象 → cinematic；介紹網站／App／軟體產品 → product；使用者要主持人、真人講解、數位人、虛擬主播 → presenter（並把 presenter 設 true）。
規則：
- 5～8 格。第一格 2 秒內抓住注意；最後一格 layout=end 收尾或行動呼籲。每格只講一件事。全部繁體中文。
- narration：這一格要「念出來」的旁白，口語自然、每格 12～60 字，像真人講解；畫面文字（title／text／bullets）要比旁白更短，是重點摘要，不要逐字重複旁白。
- 畫面文字：title ≤12 字、text ≤40 字、bullets 3～4 條每條 ≤14 字。
- 只寫確定正確的事：stat 只能用使用者給的數字或廣為人知的常識，不確定就改 bullets；不要捏造統計、價格、日期、地址、評價、人名。
- footage_query：需要「真實影像」的格（cinematic 風格多數格、其他風格最多 3 格）用 layout=footage，填 2～4 個英文關鍵字搜尋實拍影片（例："barista pouring latte art"）；畫面裡的人是素材裡的路人，不要指定真實名人。
- image_prompt：需要插圖的格用 layout=image（英文、具體描述主體、場景、光線、構圖；不要文字、名人、商標）。handdrawn 風格每一格都用 image＋anim=draw，image_prompt 結尾加 "black ink line art on white paper, hand-drawn illustration, simple, consistent character"，同一個角色每格用同樣的外型描述。
- web_shot：需要「真實網頁畫面」的格（介紹網站、服務、官方資訊）用 layout=screen，填 {"url":"確定存在的公開網址","search":"不確定網址時的搜尋關鍵字","find":"要截頁面上某一段時，那段的文字"}；url 和 search 擇一。
- app_shot：只有「可用素材」說可以截手機 App 時才用：需要某個 App 畫面的格用 layout=screen，填 {"app":"App 名稱","taps":["依序要點的按鈕文字，最多 3 個，只瀏覽、不送出不付款"],"find":"等它出現再截的文字"}。
- ai_clip：只有真的需要「特定動作的實景」而素材庫找不到時才填（英文描述，最多 2 格）；一般留空。
- gender：使用者有指定旁白／主持人是男或女才填 male 或 female，沒說就留空；使用者說不要虛擬人物或主持人，presenter 一律 false、style 不要用 presenter。
- duration（秒）：大約等於旁白念完的時間（約每 4 個字 1 秒）再加 0.6 秒；總長照使用者要求，沒說就 25～50 秒。`;

/** engine4.6：旁白聲音與虛擬人物的性別。使用者原話最優先 → 影片設定 → 分鏡的 gender → 空字串（跟著語音包） */
function pickGender(request, specGender, setting) {
  const r = String(request || '');
  if (/男(生|性|聲|的|人|主持|主播|配音|旁白|老師|講者)|男聲/.test(r) && !/女(生|性|聲|的|主持|主播|配音|旁白)/.test(r)) return 'male';
  if (/女(生|性|聲|的|人|主持|主播|配音|旁白|老師|講者)|女聲/.test(r) && !/男(生|性|聲|的|主持|主播|配音|旁白)/.test(r)) return 'female';
  if (setting === 'male' || setting === 'female') return setting;
  return specGender === 'male' || specGender === 'female' ? specGender : '';
}
/** 使用者說不要虛擬人物／主持人 */
const NO_AVATAR = /不要(用)?(虛擬)?(人物|主持人|人像|角色|虛擬人|數位人|主播|真人)|不用(虛擬)?(人物|主持人|角色|虛擬人)|不需要(虛擬)?(人物|主持人)|沒有(人物|主持人)/;
const LOOKS_BY = { male: [0, 3], female: [1, 2] };
const SIZES = { portrait: [720, 1280], landscape: [1280, 720], square: [720, 720] };
const THEMES = ['dark', 'light', 'vivid', 'warm', 'mono', 'ocean'];
const LAYOUTS = ['title', 'text', 'bullets', 'image', 'footage', 'screen', 'logo', 'quote', 'stat', 'end'];
const ANIMS = ['fade', 'slide', 'zoom', 'type', 'draw'];
const MUSIC = ['none', 'calm', 'upbeat', 'cinematic'];
const STYLES = ['motion', 'handdrawn', 'cinematic', 'product', 'presenter'];
const IMG_EXT = /\.(png|jpe?g|webp|gif)$/i, VID_EXT = /\.(mp4|webm|mov|m4v)$/i, AUD_EXT = /\.(wav|mp3|m4a|ogg|aac)$/i;
const MAX_SCENES = 30, MAX_TOTAL = 180, LEASE = 6 * 60e3;
const color = (c) => (typeof c === 'string' && /^#[0-9a-f]{3,8}$/i.test(c.trim()) ? c.trim() : '');
/** 工作區內的檔案路徑（防路徑穿越、檢查副檔名與存在） */
function wsFile(ws, p, re, what, i) {
  if (!p) return ''; const rel = String(p).replace(/\\/g, '/').replace(/^\/+/, ''); const full = path.resolve(ws, rel);
  if (!full.startsWith(path.resolve(ws) + path.sep) || !re.test(rel)) throw new Error(`第 ${i + 1} 格的${what}只能用工作區裡的檔案：${p}`);
  if (!fs.existsSync(full)) throw new Error(`第 ${i + 1} 格找不到${what}：${p}`); return path.relative(ws, full).split(path.sep).join('/');
}

/** 把腳本整理成可以算圖的規格（補預設、限制長度、檔案路徑只允許工作區內的檔案） */
function normalize(spec, ws) {
  const s = spec && typeof spec === 'object' ? spec : {}; const scenesIn = Array.isArray(s.scenes) ? s.scenes : [];
  if (!scenesIn.length) throw new Error('scenes 至少要一格（每格可以有 title、text、bullets、image、stat…）');
  if (scenesIn.length > MAX_SCENES) throw new Error(`最多 ${MAX_SCENES} 格`);
  const size = SIZES[s.size] ? s.size : 'portrait'; const [w, h] = SIZES[size];
  const style = STYLES.includes(s.style) ? s.style : 'motion';
  const out = { title: clip(String(s.title || '').trim(), 60) || '我的影片', style, size, w, h, fps: 30, theme: THEMES.includes(s.theme) ? s.theme : style === 'handdrawn' ? 'light' : 'dark', accent: color(s.accent), music: MUSIC.includes(s.music) ? s.music : 'calm', watermark: s.watermark !== false, scenes: [], credits: (Array.isArray(s.credits) ? s.credits : []).map((c) => clip(String(c), 60)).filter(Boolean).slice(0, 12) };
  if (s.avatar && typeof s.avatar === 'object' && !(s.presenter && s.presenter.file)) out.avatar = { look: Math.max(0, Math.min(3, Math.floor(+s.avatar.look || 0))), name: clip(String(s.avatar.name || ''), 12), gender: s.avatar.gender === 'male' || s.avatar.gender === 'female' ? s.avatar.gender : '' };   // engine4.5：免費虛擬主持人（虛構插畫角色）
  if (s.presenter && typeof s.presenter === 'object' && s.presenter.file) out.presenter = { file: wsFile(ws, s.presenter.file, VID_EXT, '主持人影片', 0), duration: Math.max(0, +s.presenter.duration || 0) };
  let total = 0;
  scenesIn.forEach((x, i) => {
    const sc = x && typeof x === 'object' ? x : { text: String(x) };
    const bullets = (Array.isArray(sc.bullets) ? sc.bullets : []).map((b) => clip(String(b), 60)).filter(Boolean).slice(0, 6);
    const image = wsFile(ws, sc.image, IMG_EXT, '圖片', i); const footage = wsFile(ws, sc.footage, VID_EXT, '影片素材', i); const voice = wsFile(ws, sc.voice, AUD_EXT, '旁白音檔', i);
    let layout = LAYOUTS.includes(sc.layout) ? sc.layout : footage ? 'footage' : image ? 'image' : bullets.length ? 'bullets' : sc.stat ? 'stat' : i === 0 ? 'title' : 'text';
    if (layout === 'footage' && !footage) layout = image ? 'image' : bullets.length ? 'bullets' : 'text';
    if (['image', 'screen', 'logo'].includes(layout) && !image) layout = footage ? 'footage' : bullets.length ? 'bullets' : 'text';
    const text = clip(String(sc.text || ''), 220); const title = clip(String(sc.title || ''), 60); const narration = clip(String(sc.narration || '').trim(), 300);
    const stat = sc.stat && typeof sc.stat === 'object' ? { value: clip(String(sc.stat.value == null ? '' : sc.stat.value), 16), label: clip(String(sc.stat.label || ''), 40) } : null;
    if (layout === 'stat' && !(stat && stat.value)) layout = 'text';
    const vd = voice ? Math.max(0, +sc.voice_dur || 0) : 0;
    const words = (title + text + bullets.join('')).length; const auto = layout === 'title' || layout === 'end' ? 3.5 : ['image', 'footage', 'screen', 'logo'].includes(layout) ? 4.5 : Math.min(12, 2.8 + words * 0.11 + bullets.length * 0.6);
    let dur = Math.max(1.5, Math.min(20, Number(sc.duration) > 0 ? Number(sc.duration) : auto)); if (vd) dur = Math.max(dur, Math.min(30, vd + 0.6));   // 旁白一定念得完
    total += dur; if (total > MAX_TOTAL) throw new Error(`影片總長最多 ${MAX_TOTAL} 秒`);
    out.scenes.push({ layout, title, text, bullets, image, footage, voice, voice_dur: vd, narration, stat, caption: clip(String(sc.caption || ''), 80), bg: [color(sc.bg), color(sc.bg2)].filter(Boolean), mouth: voice && typeof sc.mouth === 'string' && /^[0-9]{1,4000}$/.test(sc.mouth) ? sc.mouth : '', anim: ANIMS.includes(sc.anim) ? sc.anim : style === 'handdrawn' && layout === 'image' ? 'draw' : layout === 'bullets' ? 'slide' : ['image', 'footage', 'screen'].includes(layout) ? 'zoom' : 'fade', duration: Math.round(dur * 10) / 10 });
  });
  if (!out.scenes.some((x) => x.title || x.text || x.bullets.length || x.image || x.footage || x.stat || x.narration)) throw new Error('每一格都是空的：至少要有標題、文字、條列、圖片、影片、數字或旁白');
  out.duration = Math.round(out.scenes.reduce((a, x) => a + x.duration, 0) * 10) / 10; return out;
}

class Videos {
  constructor(ctx) { this.ctx = ctx; }
  get db() { const d = this.ctx.store.db; if (!Array.isArray(d.videos)) d.videos = []; return d.videos; }
  get ws() { return this.ctx.paths.workspace; }
  pub(v) { const { spec, reply, ...rest } = v; return { ...rest, title: spec.title, duration: spec.duration, size: spec.size, scenes: spec.scenes.length }; }
  list() { this.sweep(); return this.db.slice().sort((a, b) => b.created - a.created).map((v) => this.pub(v)); }
  get(id) { const v = this.db.find((x) => x.id === id); if (!v) throw new Error('找不到這支影片'); return v; }
  get drafts() { if (!this._drafts) this._drafts = new Map(); return this._drafts; }
  /** 重開 App 後還卡在「寫分鏡中」的（背景工作已經不在了）→ 標失敗，請使用者再說一次 */
  sweep() { for (const v of this.db) if (v.status === 'drafting' && !this.drafts.has(v.id) && Date.now() - v.updated > 5 * 60e3) { v.status = 'error'; v.error = '分鏡沒寫完就中斷了（App 重開？），再說一次就好'; this.ctx.store.touch(); } }
  /** 一句話 → AI 寫分鏡（自動選風格、尺寸、配色、音樂、長度）→ 自動備齊素材（旁白人聲、實拍、插圖、主持人、網頁截圖）→ 算圖 → 做好自動傳回。立刻回傳（狀態 drafting）。
   *  opts.media＝使用者自己的影片／照片（工作區路徑），opts.urls＝要介紹的網頁（會截圖） */
  auto(request, { by = 'app', reply = null, images, media = [], urls = [] } = {}) {
    const req = clip(String(request || '').trim(), 800); if (!req) throw new Error('說說想做什麼影片，一句話就好');
    const llm = require('../llm'); if (!llm.hasKey(this.ctx.settings)) throw new Error('還沒設定 AI 模型金鑰（更多 → 模型），沒辦法自動寫分鏡');
    this.sweep(); if (this.db.filter((v) => ['drafting', 'queued', 'rendering'].includes(v.status)).length >= 5) throw new Error('進行中的影片太多（最多 5 支），等前面的做完');
    const own = (Array.isArray(media) ? media : []).slice(0, 12).map((m, i) => { try { return wsFile(this.ws, m, /\.(png|jpe?g|webp|gif|mp4|webm|mov|m4v)$/i, '素材', i); } catch { return ''; } }).filter(Boolean);   // 不在工作區、格式不對的直接略過
    const pages = (Array.isArray(urls) ? urls : []).map((u) => String(u).trim()).filter((u) => /^https?:\/\/[^\s]+$/i.test(u) && require('./vidmedia').publicUrl(u)).slice(0, 4);
    const hint = AG.pickVideo(req);
    const v = { id: rid(8).toLowerCase(), status: 'drafting', progress: 0, created: Date.now(), updated: Date.now(), by, request: req, spec: { title: clip(req, 24), size: hint.size, duration: hint.seconds || 0, scenes: [] }, reply, error: '', file: null, notes: [] };
    this.db.push(v); this.ctx.store.touch(); this.ctx.store.audit(by, 'video.auto', clip(req, 80)); this.emit();
    const job = this.draft(v, hint, { images, media: own, urls: pages }).catch((e) => { v.status = 'error'; v.error = clip(String(e.message || e), 300); v.updated = Date.now(); this.ctx.store.touch(); this.emit(); this.tell(v, `影片「${v.spec.title}」沒做成：${v.error}`).catch(() => {}); });
    this.drafts.set(v.id, job); job.finally(() => this.drafts.delete(v.id)); return v;   // 要等分鏡寫完：await this.drafts.get(v.id)
  }
  async draft(v, hint, opts = {}) {
    const VM = this.ctx.vidmedia; const caps = VM ? VM.caps() : {}; const notes = v.notes = v.notes || [];
    const stage = (t) => { v.stage = t; v.updated = Date.now(); this.ctx.store.touch(); this.emit(); };
    const avail = [caps.narration ? `旁白人聲（${caps.voice}）` : '沒有雲端語音（narration 照寫，但只會變字幕）', caps.stock ? '實拍影片庫（footage_query 有效）' : '沒有實拍影片庫（不要用 footage，改用 image）', caps.presenter ? '可用 HeyGen 真人數位主持人' : '可用免費虛擬主持人（插畫角色、會對嘴；要主持人時 presenter 設 true、style 用 presenter）'];
    if (opts.media && opts.media.length) avail.push(`使用者給了 ${opts.media.length} 個自己的影片／照片，會依序放進 footage／image 格（請至少安排 ${opts.media.length} 格 footage 或 image）`);
    avail.push('可以自己截網頁畫面（web_shot）');
    if (caps.app_shot && (v.by === 'app' || (() => { try { const p = this.ctx.users.byId(v.by); return !!(p && p.role === 'admin'); } catch { return false; } })())) avail.push('可以截手機上其他 App 的畫面（app_shot，手機代理已開）');
    if (opts.urls && opts.urls.length) avail.push(`要介紹的網頁 ${opts.urls.length} 個（${opts.urls.join('、')}），會截圖放進 layout=screen 的格（請安排 ${opts.urls.length} 格 screen，style 用 product）`);
    const user = `需求：${v.request}\n建議（需求裡有明講就以需求為準）：尺寸 ${hint.size}、配色 ${hint.theme}、音樂 ${hint.music}、總長 ${hint.seconds ? `約 ${hint.seconds} 秒` : '25～50 秒'}\n可用素材：${avail.join('；')}`;
    stage('寫分鏡與旁白');
    let spec; try { spec = AG.json(await AG.ask(this.ctx, VIDEO_SYS, user, { maxTokens: 6000 })); } catch { spec = AG.json(await AG.ask(this.ctx, VIDEO_SYS + '\n再強調一次：只輸出 JSON 物件本身。', user, { maxTokens: 6000 })); }
    if (!this.db.includes(v)) return;   // 等的時候被刪掉了
    spec.size = SIZES[spec.size] ? spec.size : hint.size; if (!THEMES.includes(spec.theme)) spec.theme = hint.theme; if (!MUSIC.includes(spec.music)) spec.music = hint.music; if (!STYLES.includes(spec.style)) spec.style = 'motion';
    if (/不要音樂|無音樂|靜音/.test(v.request)) spec.music = 'none';
    const scenes = (Array.isArray(spec.scenes) ? spec.scenes : []).filter((x) => x && typeof x === 'object').slice(0, MAX_SCENES);
    scenes.forEach((x) => { delete x.image; delete x.footage; delete x.voice; delete x.voice_dur; });   // 模型自己寫的檔案路徑不可信，只用我們備好的素材
    if (hint.seconds) { const tot = scenes.reduce((a, x) => a + (Number(x.duration) || 4), 0); const k = hint.seconds / Math.max(1, tot); if (k < 0.85 || k > 1.15) scenes.forEach((x) => { x.duration = Math.max(1.5, Math.min(20, (Number(x.duration) || 4) * k)); }); }
    const credits = []; const visual = (x) => x.image || x.footage; const body = scenes.map((x, i) => i).filter((i) => i > 0 && i < scenes.length - 1);
    // 1) 使用者自己的素材：照順序放進需要畫面的格
    const slots = [...scenes.map((x, i) => i).filter((i) => ['footage', 'image'].includes(scenes[i].layout)), ...body, 0, scenes.length - 1].filter((i, k, a) => a.indexOf(i) === k);
    for (const m of opts.media || []) { const i = slots.find((j) => !visual(scenes[j])); if (i == null) break; if (/\.(mp4|webm|mov|m4v)$/i.test(m)) { scenes[i].footage = m; scenes[i].layout = 'footage'; } else { scenes[i].image = m; if (!['title', 'end', 'stat', 'quote'].includes(scenes[i].layout)) scenes[i].layout = 'image'; } }
    // 2a) AI 自己決定的截圖：網頁（web_shot：網址或搜尋）、手機 App（app_shot：手機代理，只限管理員要求的影片）
    const admin = v.by === 'app' || (() => { try { const p = this.ctx.users.byId(v.by); return !!(p && p.role === 'admin'); } catch { return false; } })();
    if (VM) for (let i = 0; i < scenes.length; i++) { const x = scenes[i]; if (visual(x)) continue;
      const w = x.web_shot && typeof x.web_shot === 'object' ? x.web_shot : null; const ap = x.app_shot && typeof x.app_shot === 'object' ? x.app_shot : null;
      try {
        if (w && (w.url || w.search)) { stage('擷取網頁畫面'); const url = w.url && require('./vidmedia').publicUrl(w.url) ? String(w.url) : w.search ? await VM.findUrl(w.search) : ''; if (!url) continue; const r = await VM.capture(v.id, 100 + i, url, { find: w.find }); x.image = r.file; x.layout = 'screen'; }
        else if (ap && ap.app && admin && caps.app_shot) { stage(`擷取手機畫面（${clip(String(ap.app), 12)}）`); const r = await Promise.race([VM.appShot(v.id, i, ap), new Promise((_, no) => { const t = setTimeout(() => no(new Error('超過 90 秒')), 90000); if (t.unref) t.unref(); })]); x.image = r.file; x.layout = 'screen'; }
      } catch (e) { notes.push(`截圖失敗（${w ? (w.url || w.search) : ap.app}）：${clip(String(e.message || e), 120)}`); }
    }
    // 2) 網頁截圖（產品宣傳片）
    if (VM && opts.urls && opts.urls.length) { stage('擷取網頁畫面'); let k = 0; for (const u of opts.urls) { const i = [...scenes.map((x, j) => j).filter((j) => scenes[j].layout === 'screen' && !visual(scenes[j])), ...body.filter((j) => !visual(scenes[j]))][0]; if (i == null) break; try { const r = await VM.capture(v.id, k++, u); scenes[i].image = r.file; scenes[i].layout = 'screen'; } catch (e) { notes.push(`網頁截圖失敗（${u}）：${e.message}`); } } }
    // 3) 實拍（Pexels）、AI 實景、插圖：同時進行
    const jobs = []; const style = spec.style;
    if (VM && caps.stock) { const want = scenes.map((x, i) => i).filter((i) => !visual(scenes[i]) && (scenes[i].layout === 'footage' || (style === 'cinematic' && scenes[i].footage_query)) && String(scenes[i].footage_query || '').trim()).slice(0, style === 'cinematic' ? 6 : 3);
      if (want.length) jobs.push((async () => { for (const i of want) { try { const r = await VM.stock(v.id, i, scenes[i].footage_query, spec.size); if (r) { scenes[i].footage = r.file; scenes[i].layout = 'footage'; if (!credits.includes(r.credit)) credits.push(r.credit); } } catch (e) { notes.push('實拍素材：' + e.message); break; } } })()); }
    if (VM && caps.ai_clips) { const want = scenes.map((x, i) => i).filter((i) => !visual(scenes[i]) && String(scenes[i].ai_clip || '').trim()).slice(0, 2);
      for (const i of want) jobs.push(VM.aiClip(v.id, i, scenes[i].ai_clip, spec.size).then((r) => { if (r && !scenes[i].footage) { scenes[i].footage = r.file; scenes[i].layout = 'footage'; if (!credits.includes(r.credit)) credits.push(r.credit); } }).catch((e) => notes.push('AI 實景影片：' + e.message))); }
    if (!caps.ai_clips) scenes.forEach((x) => { if (String(x.ai_clip || '').trim() && !String(x.image_prompt || '').trim()) x.image_prompt = String(x.ai_clip) + ', cinematic film still, shallow depth of field'; });   // engine4.5：沒開付費 AI 影片 → 免費出圖＋鏡頭推移代替
    const useImg = opts.images !== false && this.ctx.settings.get('video.auto_images', true) !== false && this.ctx.imagegen && this.ctx.media;
    const idx = useImg ? scenes.map((x, i) => i).filter((i) => !visual(scenes[i]) && String(scenes[i].image_prompt || '').trim()).slice(0, style === 'handdrawn' ? 8 : 3) : [];
    const aspect = { portrait: '9:16', landscape: '16:9', square: '1:1' }[spec.size];
    for (const i of idx) jobs.push(Promise.race([this.ctx.imagegen.generate({ prompt: String(scenes[i].image_prompt).slice(0, 600) + ', high quality, no text', aspect }), new Promise((_, no) => { const t = setTimeout(() => no(new Error('逾時')), 70000); if (t.unref) t.unref(); })]).then((r) => { if (scenes[i].footage) return; scenes[i].image = this.ctx.media.saveWorkspace(r.buf, r.mime, 'video'); if (!['title', 'end', 'stat', 'quote'].includes(scenes[i].layout)) scenes[i].layout = 'image'; }).catch(() => { /* 沒圖就用文字版型 */ }));
    if (jobs.length) { stage(`準備畫面素材（${jobs.length} 項）`); await Promise.all(jobs); }
    if (!this.db.includes(v)) return;
    // 4) 人聲：數位主持人（整段旁白一次念完、口型同步）或逐格 TTS 旁白
    const script = scenes.map((x) => String(x.narration || '').trim()).filter(Boolean);
    spec.presenter_wanted = spec.presenter === true || style === 'presenter';
    if (VM && (spec.presenter === true || style === 'presenter') && caps.presenter && script.length) {
      stage('數位主持人製作中（約 2～10 分鐘）');
      try { const r = await VM.presenter(v.id, script.join('\n'), spec.size, stage); spec.presenter = { file: r.file, duration: r.duration }; credits.push(r.credit);
        const w = scenes.map((x) => Math.max(8, String(x.narration || '').length)); const tot = r.duration > 0 ? r.duration : w.reduce((a, b) => a + b, 0) / 4.2; const sw = w.reduce((a, b) => a + b, 0);
        scenes.forEach((x, i) => { x.duration = Math.max(1.5, Math.min(20, tot * w[i] / sw)); });
      } catch (e) { notes.push('數位主持人沒做成，改用旁白人聲：' + e.message); spec.presenter = false; }
    } else spec.presenter = false;
    // 免費虛擬主持人：要主持人但沒有 HeyGen（或 HeyGen 失敗）→ 虛構插畫角色＋依旁白音量對嘴（不需要任何付費服務）
    const avMode = this.ctx.settings.get('video.avatar', 'auto'); const noAv = NO_AVATAR.test(v.request);
    let gender = pickGender(v.request, spec.gender, this.ctx.settings.get('video.gender', 'auto'));
    let h = 0; for (const ch of String(v.request)) h = (h * 31 + ch.charCodeAt(0)) >>> 0;
    if (!spec.presenter && !noAv && script.length && avMode !== 'off' && (avMode === 'always' || style === 'presenter' || spec.presenter_wanted)) spec.avatar = { look: 0 };
    if (VM && !spec.presenter && caps.narration && script.length && this.ctx.settings.get('video.narration', true) !== false) {
      stage('錄製旁白人聲'); const r = await VM.narrate(v.id, scenes, { gender }); if (!gender && r.gender) gender = r.gender; if (!r.ok) notes.push('旁白沒錄成：' + (r.why || r.fail.join('；'))); else if (r.fail.length) notes.push('部分旁白沒錄成：' + r.fail.slice(0, 2).join('；')); if (r.switched) notes.push(r.switched);
    } else if (script.length && !spec.presenter && !caps.narration) notes.push('沒有雲端語音金鑰，旁白只顯示成字幕');
    // 虛擬人物跟旁白同性別（男聲配男生、女聲配女生）；完全不知道就照需求文字固定挑一個
    if (spec.avatar) { const g = gender || (h % 2 ? 'female' : 'male'); const pool = LOOKS_BY[g]; spec.avatar = { look: pool[h % pool.length], gender: g }; }
    scenes.forEach((x) => { delete x.image_prompt; delete x.footage_query; delete x.ai_clip; delete x.web_shot; delete x.app_shot; });
    if (!this.db.includes(v)) return;
    spec.credits = credits;
    const n = normalize(spec, this.ws);
    v.spec = n; v.stage = ''; v.updated = Date.now();
    this.ctx.store.audit(v.by, 'video.drafted', `${v.id} ${n.style} ${n.scenes.length} 格 ${n.duration}s 圖 ${n.scenes.filter((x) => x.image).length} 實拍 ${n.scenes.filter((x) => x.footage).length} 旁白 ${n.scenes.filter((x) => x.voice).length}${n.presenter ? ' 主持人' : ''}`);
    this.dispatch(v);
  }
  /** 選引擎：HyperFrames（Termux）可用且通過自我測試 → 在背景用它做；否則交給 App 畫面 */
  dispatch(v) {
    const E = this.ctx.vengine; const want = this.ctx.settings.get('video.engine', 'auto');
    if (E && want !== 'app' && E.usable(v.spec) && (want === 'hyperframes' || E.passed())) {
      v.engine = 'hyperframes'; v.status = 'rendering'; v.worker = 'hyperframes'; v.progress = 0; v.tries = (v.tries || 0) + 1; this.ctx.store.touch(); this.emit();
      E.render(v.id, v.spec, (p) => { v.progress = Math.max(0, Math.min(99, Math.round(p))); v.updated = Date.now(); }).then((out) => this.upload(v.id, out.buf, out.mime)).catch((e) => {
        v.notes = [...(v.notes || []), 'HyperFrames 沒做成，改用 App 畫面算圖：' + clip(String(e.message || e), 160)]; v.engine = 'app'; v.status = 'queued'; v.progress = 0; v.worker = ''; this.ctx.store.touch(); this.emit();
      });
      return;
    }
    v.engine = 'app'; v.status = 'queued'; this.ctx.store.touch(); this.emit();
  }
  /** 建立工作：reply＝做好之後要傳回哪裡 {platform, chatId, pid} */
  make(spec, { by = 'app', reply = null } = {}) {
    const n = normalize(spec, this.ws); if (this.db.filter((v) => v.status === 'queued' || v.status === 'rendering').length >= 5) throw new Error('排隊中的影片太多（最多 5 支），等前面的做完');
    const v = { id: rid(8).toLowerCase(), status: 'queued', progress: 0, created: Date.now(), updated: Date.now(), by, spec: n, reply, error: '', file: null };
    this.db.push(v); while (this.db.length > 40) { const old = this.db.shift(); if (old.file) { try { fs.unlinkSync(path.join(this.ws, old.file.path)); } catch { /* ignore */ } } }
    this.ctx.store.audit(by, 'video.make', `${v.id} ${n.scenes.length} 格 ${n.duration}s`); this.dispatch(v); return v;
  }
  /** App 畫面來領下一個工作（租約 6 分鐘；畫面關掉沒做完，過期會回到佇列） */
  claim(worker = '') {
    const now = Date.now(); for (const v of this.db) if (v.status === 'rendering' && v.engine !== 'hyperframes' && now - (v.lease || 0) > LEASE) { v.status = 'queued'; v.progress = 0; }
    const v = this.db.find((x) => x.status === 'queued'); if (!v) return null;
    v.status = 'rendering'; v.lease = now; v.worker = String(worker).slice(0, 40); v.updated = now; v.tries = (v.tries || 0) + 1; this.ctx.store.touch(); this.emit();
    v.engine = 'app'; return { id: v.id, spec: v.spec, assets: this.assets(v) };
  }
  /** 給算圖器的素材網址（每格的圖、實拍、旁白；主持人影片） */
  assets(v) {
    const u = (k, i) => `/api/video/${v.id}/asset?k=${k}${i == null ? '' : '&i=' + i}`;
    return { scenes: v.spec.scenes.map((s, i) => ({ image: s.image ? u('image', i) : '', footage: s.footage ? u('footage', i) : '', voice: s.voice ? u('voice', i) : '' })), presenter: v.spec.presenter ? u('presenter') : '' };
  }
  progress(id, p) { const v = this.get(id); if (v.status !== 'rendering') throw new Error('這支影片不在製作中'); v.progress = Math.max(0, Math.min(99, Math.round(+p || 0))); v.lease = Date.now(); v.updated = Date.now(); this.ctx.store.touch(); this.emit(); return { ok: true }; }
  fail(id, msg, requeue = false) { const v = this.get(id); if (requeue) { v.tries = Math.max(0, (v.tries || 1) - 1); v.status = 'queued'; v.progress = 0; v.updated = Date.now(); this.ctx.store.touch(); this.emit(); return this.pub(v); }   // App 切到背景＝不算失敗，回佇列等下次
    v.status = (v.tries || 0) < 2 ? 'queued' : 'error'; v.error = clip(String(msg || '算圖失敗'), 300); v.progress = 0; v.updated = Date.now(); this.ctx.store.touch(); this.emit(); if (v.status === 'error') this.tell(v, `影片「${v.spec.title}」做不出來：${v.error}`).catch(() => {}); return this.pub(v); }
  /** 素材檔：k＝image／footage／voice／presenter（回傳完整路徑與 mime，路由負責串流與 Range） */
  asset(id, i, k = 'image') {
    const v = this.get(id); let rel = '';
    if (k === 'presenter') rel = v.spec.presenter && v.spec.presenter.file; else { const s = v.spec.scenes[+i]; if (!s) throw new Error('沒有這一格'); rel = s[k === 'footage' ? 'footage' : k === 'voice' ? 'voice' : 'image']; }
    if (!rel) throw new Error('沒有這個素材'); const full = path.join(this.ws, rel); if (!full.startsWith(path.resolve(this.ws) + path.sep) || !fs.existsSync(full)) throw new Error('素材檔不見了');
    const e = path.extname(full).toLowerCase(); const mime = { '.png': 'image/png', '.webp': 'image/webp', '.gif': 'image/gif', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.mp4': 'video/mp4', '.m4v': 'video/mp4', '.mov': 'video/quicktime', '.webm': 'video/webm', '.wav': 'audio/wav', '.mp3': 'audio/mpeg', '.m4a': 'audio/mp4', '.ogg': 'audio/ogg', '.aac': 'audio/aac' }[e] || 'application/octet-stream';
    return { file: full, mime, size: fs.statSync(full).size };
  }
  /** 收到算好的影片：檢查檔頭（MP4 的 ftyp／WebM 的 EBML），存檔，傳回聊天室 */
  async upload(id, buf, mime) {
    const v = this.get(id); if (v.status !== 'rendering') throw new Error('這支影片不在製作中');
    if (!buf || buf.length < 1000) throw new Error('影片檔太小，可能錄製失敗'); if (buf.length > 80 * 1024 * 1024) throw new Error('影片超過 80MB');
    const isMp4 = buf.slice(4, 8).toString('latin1') === 'ftyp'; const isWebm = buf.readUInt32BE(0) === 0x1A45DFA3; if (!isMp4 && !isWebm) throw new Error('不是 MP4／WebM 影片檔');
    const ext = isMp4 ? 'mp4' : 'webm'; const safe = v.spec.title.replace(/[\\/:*?"<>|\s]+/g, '_').slice(0, 40) || 'video';
    const rel = `videos/${safe}-${v.id}.${ext}`; const full = path.join(this.ws, rel); fs.mkdirSync(path.dirname(full), { recursive: true }); fs.writeFileSync(full, buf);
    const rec = { id: rid(8), name: `${safe}.${ext}`, path: rel, mime: isMp4 ? 'video/mp4' : 'video/webm', size: buf.length, at: Date.now(), owner: (v.reply && v.reply.pid) || '' };
    if (this.ctx.filegen && Array.isArray(this.ctx.filegen.list)) this.ctx.filegen.list.push(rec);
    v.status = 'done'; v.progress = 100; v.file = rec; v.updated = Date.now(); v.mime = String(mime || rec.mime).slice(0, 60); this.ctx.store.touch(); this.emit();
    this.ctx.store.audit('app', 'video.done', `${v.id} ${rec.size}B`); await this.deliver(v).catch(() => {}); return this.pub(v);
  }
  /** 傳回提出要求的地方：平台聊天室直接傳檔；App 對話則寫進對話紀錄（畫面上會出現檔案卡） */
  async deliver(v) {
    const extra = []; if (v.spec.presenter) extra.push('數位主持人'); else if (v.spec.scenes.some((x) => x.voice)) extra.push('旁白人聲'); if (v.spec.scenes.some((x) => x.footage)) extra.push('實拍畫面'); if (v.engine === 'hyperframes') extra.push('HyperFrames 算圖');
    const text = `影片「${v.spec.title}」做好了（${v.spec.duration} 秒，${Math.max(1, Math.round(v.file.size / 1024))} KB${extra.length ? '，' + extra.join('、') : ''}），可以直接播放或下載。${(v.notes || []).length ? '\n備註：' + v.notes.slice(0, 3).join('；') : ''}${v.spec.credits && v.spec.credits.length ? '\n素材：' + v.spec.credits.join('、') : ''}`;
    v.delivered = await AG.deliver(this.ctx, v.reply, text, [v.file], '影片做好了'); this.ctx.store.touch();
  }
  async tell(v, text) { const r = v.reply || {}; if (r.platform && r.platform !== 'app' && r.chatId && this.ctx.hub) return this.ctx.hub.send(r.platform, r.chatId, text); return this.ctx.notifier.push('warn', '影片', text, { force: true }); }
  remove(id) { const v = this.get(id); if (v.file) { try { fs.unlinkSync(path.join(this.ws, v.file.path)); } catch { /* ignore */ } } this.ctx.store.db.videos = this.db.filter((x) => x !== v); this.ctx.store.touch(); this.emit(); return { ok: true }; }
  retry(id) { const v = this.get(id); if (v.status === 'rendering' || v.status === 'drafting') throw new Error('正在製作中'); if (!v.spec.scenes.length) { if (!v.request) throw new Error('沒有分鏡可以重做'); this.ctx.store.db.videos = this.db.filter((x) => x !== v); return this.pub(this.auto(v.request, { by: v.by, reply: v.reply })); } v.status = 'queued'; v.progress = 0; v.error = ''; v.tries = 0; v.updated = Date.now(); this.ctx.store.touch(); this.emit(); return this.pub(v); }
  pending() { return this.db.filter((v) => v.status === 'queued' || v.status === 'rendering').length; }
  drafting() { return this.db.filter((v) => v.status === 'drafting').length; }
  emit() { try { if (this.ctx.api && this.ctx.api.broadcast) this.ctx.api.broadcast('video', { pending: this.pending() }); } catch { /* ignore */ } }
}

module.exports = { pickGender, NO_AVATAR, LOOKS_BY, Videos, normalize, SIZES, LAYOUTS, THEMES, MUSIC, STYLES, VIDEO_SYS };
