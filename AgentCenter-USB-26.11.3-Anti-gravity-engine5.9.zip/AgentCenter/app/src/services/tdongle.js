'use strict';
/**
 * engine5.6：LilyGO T-Dongle-S3 狀態螢幕（只顯示狀態與進度）。
 *  電腦上的程式透過 USB 序列埠把狀態傳給 Dongle：小螢幕顯示中文、LED 變色。
 *  ・找序列埠：Windows 找 VID_303A（Espressif）的 COM 埠；Linux 找 /dev/serial/by-id 裡的 Espressif／ttyACM；Mac 找 /dev/cu.usbmodem
 *  ・只寫不讀（不需要原生序列埠套件，USB 版直接能用）；寫失敗就當成拔掉了，30 秒後再找
 *  ・螢幕 160×80：每行約 10 個中文字；韌體裡沒有的字換成 □
 *  協定（一行一則）：T 標題｜1 第一行｜2 第二行｜P 完成 總數｜S boot/ready/busy/error/safe/off
 *  ctx 可以是 null（啟動程式還沒開 AI 之前也能用）
 */
const fs = require('fs');
const path = require('path');
const { execFile } = require('child_process');

let CHARS = null;
function charset() { if (!CHARS) { try { CHARS = new Set(fs.readFileSync(path.join(__dirname, 'tdongle-chars.txt'), 'utf8')); } catch { CHARS = new Set(); } } return CHARS; }
/** 換成螢幕顯示得出來的字、截到一行寬（中文 16px、英數 8px，共 156px） */
function fit(text, px = 156) {
  const cs = charset(); let w = 0; const out = [];   // [字, 寬]
  for (const ch of String(text == null ? '' : text).replace(/[\r\n\t]+/g, ' ')) {
    const cp = ch.codePointAt(0); let c = ch; let cw;
    if (cp >= 0x20 && cp < 0x7f) cw = 8; else if (cs.has(ch)) cw = 16; else if (cp < 0x20) continue; else { c = '□'; cw = 16; }
    if (w + cw > px) { while (out.length && w + 16 > px) w -= out.pop()[1]; out.push(['…', 16]); break; }   // 「…」本身要 16px：先退到放得下
    out.push([c, cw]); w += cw;
  }
  return out.map((x) => x[0]).join('');
}
function sh(cmd, args, timeout = 8000) { return new Promise((ok) => { execFile(cmd, args, { timeout, windowsHide: true }, (e, so) => ok(e ? '' : String(so || ''))); }); }

class TDongle {
  constructor(ctx, { platform = process.platform, finder = null, opener = null } = {}) {
    this.ctx = ctx; this.platform = platform; this.port = ''; this.fd = null; this.last = {}; this.timer = null; this._finder = finder; this._opener = opener;
  }
  _get(k, d) { try { return this.ctx && this.ctx.settings ? this.ctx.settings.get(k, d) : d; } catch { return d; } }
  enabled() { const v = this._get('tdongle.enabled', 'auto'); if (v === false) return false; return v === true || !this.ctx || !!(this.ctx.portable && this.ctx.portable.on); }
  async find() {
    if (this._finder) return this._finder();
    const set = this._get('tdongle.port', '') || process.env.LA_TDONGLE_PORT || ''; if (set) return set;
    if (this.platform === 'win32') {
      const out = await sh('powershell.exe', ['-NoProfile', '-Command', "Get-CimInstance Win32_PnPEntity | Where-Object { $_.PNPDeviceID -match 'VID_303A' -and $_.Name -match '\\(COM\\d+\\)' } | ForEach-Object { $_.Name }"]);
      const m = /\((COM\d+)\)/.exec(out); return m ? '\\\\.\\' + m[1] : '';
    }
    if (this.platform === 'darwin') { try { const l = fs.readdirSync('/dev').filter((n) => /^cu\.usbmodem/.test(n)).sort(); return l.length ? '/dev/' + l[0] : ''; } catch { return ''; } }
    try { const d = '/dev/serial/by-id'; const l = fs.readdirSync(d).filter((n) => /espressif|303a|t-dongle|agentcenter/i.test(n)); if (l.length) return fs.realpathSync(path.join(d, l[0])); } catch { /* 沒有 */ }
    try { const l = fs.readdirSync('/dev').filter((n) => /^ttyACM\d+$/.test(n)).sort(); return l.length ? '/dev/' + l[0] : ''; } catch { return ''; }
  }
  async connect() {
    if (this.fd != null) return true; const p = await this.find(); if (!p) return false;
    try {
      if (this._opener) this.fd = this._opener.open(p);
      else {
        if (this.platform === 'linux') await sh('stty', ['-F', p, 'raw', '-echo', '115200']); else if (this.platform === 'darwin') await sh('stty', ['-f', p, 'raw', '-echo', '115200']);
        this.fd = fs.openSync(p, fs.constants.O_WRONLY | (fs.constants.O_NOCTTY || 0) | (fs.constants.O_NONBLOCK || 0));
      }
      this.port = p;
      for (const k of ['S', 'T', '1', '2', 'P']) if (this.last[k] != null) this._raw(k, this.last[k]);   // 重新連上：把目前畫面再送一次
      return true;
    } catch { this.fd = null; return false; }
  }
  _raw(k, v) {
    if (this.fd == null) return false;
    try { const b = Buffer.from(`${k} ${v}\n`, 'utf8'); if (this._opener) this._opener.write(this.fd, b); else fs.writeSync(this.fd, b); return true; }
    catch { try { if (!this._opener) fs.closeSync(this.fd); } catch { /* ignore */ } this.fd = null; this.port = ''; return false; }
  }
  send(k, v, force = false) { const val = k === 'T' || k === '1' || k === '2' ? fit(v) : String(v); if (!force && this.last[k] === val) return; this.last[k] = val; this._raw(k, val); }
  /** 一次設定整個畫面（沒給的欄位不變；total=0 會收起進度條） */
  screen({ state, title, l1, l2, done, total } = {}) {
    if (state) this.send('S', state); if (title != null) this.send('T', title); if (l1 != null) this.send('1', l1); if (l2 != null) this.send('2', l2);
    if (total != null) this.send('P', `${done || 0} ${total}`);
  }
  progress(done, total, name) { this.send('P', `${done} ${total}`); if (name != null) this.send('2', name); }
  async start() {
    if (!this.enabled()) return false; await this.connect();
    this.timer = setInterval(() => { (this.fd == null ? this.connect() : Promise.resolve(this._raw('S', this.last.S || 'ready'))).catch(() => {}); }, 30000);
    if (this.timer.unref) this.timer.unref(); return this.fd != null;
  }
  stop(msg = '可以安全拔除') { if (this.fd != null) { this.screen({ state: 'safe', title: '已存檔', l1: msg, l2: '', total: 0 }); try { if (!this._opener) fs.closeSync(this.fd); } catch { /* ignore */ } this.fd = null; } if (this.timer) clearInterval(this.timer); }
  /** 只關掉序列埠、畫面不變（Windows 的 COM 埠同時只能一個程式開：啟動程式交棒給 AI 前要先關） */
  close() { if (this.fd != null) { try { if (!this._opener) fs.closeSync(this.fd); } catch { /* ignore */ } this.fd = null; } if (this.timer) clearInterval(this.timer); }
  status() { return { enabled: this.enabled(), connected: this.fd != null, port: this.port }; }
}
module.exports = { TDongle, fit };
