'use strict';
/**
 * 26.11.3 pro10 數學求解（純計算、不連網、不用 eval）：讓理工題的「算」交給程式，模型只負責列式與解釋。
 *  solve     解方程（單變數，數值法：掃描變號＋二分＋牛頓），例 "x^3 - 2*x = 5"
 *  poly      多項式全部的根（含複數），coeffs 由高次到常數項
 *  linear    線性聯立 A x = b
 *  matrix    det｜inv｜mul｜transpose｜rank｜eig（特徵值）
 *  diff      數值微分 f'(x)（也可二階）
 *  integrate 定積分（自適應辛普森）
 *  regress   最小平方擬合（一次或多項式），回傳係數與 R²
 *  stats     平均、中位數、標準差、四分位
 *  base      進位轉換（2～36）
 *  factor    質因數分解
 *  ode       一階常微分方程 y' = f(x, y) 的數值解（RK4）
 * 算式語法同 calculate（乘號要寫 *，次方 ^，函式 sin／ln／exp…）；數字緊接變數（2x）會自動補乘號。
 */
const { evaluate } = require('./calc');
const sig = (x, n = 10) => { if (typeof x !== 'number' || !Number.isFinite(x)) return String(x); if (x === 0) return '0'; const a = Math.abs(x); const r = parseFloat(x.toPrecision(n)); return a >= 1e10 || a < 1e-5 ? r.toExponential().replace(/\.?0+e/, 'e') : String(r); };
const cstr = (re, im) => (Math.abs(im) < 1e-9 * Math.max(1, Math.abs(re)) ? sig(re) : `${sig(Math.abs(re) < 1e-12 ? 0 : re)} ${im < 0 ? '−' : '+'} ${sig(Math.abs(im))}i`);
const vname = (v) => { const s = String(v || 'x').trim(); if (!/^[A-Za-z_][A-Za-z0-9_]{0,10}$/.test(s)) throw new Error('變數名稱只能是英文字母開頭（例 x、t、v0）'); return s; };
/** 把字串算式做成函式 f(x)。"左 = 右" 會變成 左 − (右) */
function fn(expr, v = 'x') {
  let e = String(expr || '').trim(); if (!e) throw new Error('要給算式'); if (e.length > 500) throw new Error('算式太長');
  e = e.replace(/−/g, '-').replace(/×/g, '*').replace(/÷/g, '/').replace(/²/g, '^2').replace(/³/g, '^3');
  const parts = e.split('='); if (parts.length > 2) throw new Error('只能有一個等號'); if (parts.length === 2) e = `(${parts[0]})-(${parts[1]})`;
  const name = vname(v); e = e.replace(new RegExp('(\\d)\\s*(' + name + ')(?![A-Za-z0-9_])', 'g'), '$1*$2').replace(/\)\s*\(/g, ')*(');
  const K = name.toUpperCase(); const f = (x) => { const r = evaluate(e, null, { [K]: x }); return typeof r === 'number' ? r : NaN; };
  f(1.2345);   // 語法錯就現在報
  return f;
}
const safe = (f) => (x) => { try { const y = f(x); return Number.isFinite(y) ? y : NaN; } catch { return NaN; } };

function solve(expr, { variable = 'x', lo = -1000, hi = 1000, guess = null } = {}) {
  const f0 = fn(expr, variable); const f = safe(f0); const roots = [];
  const add = (r) => { if (!Number.isFinite(r)) return; const fr = f(r); const scale = Math.max(1, Math.abs(r)); if (!(Math.abs(fr) < 1e-6 * Math.max(1, Math.abs(f(r + 1e-3 * scale)) + Math.abs(f(r - 1e-3 * scale))))) return; if (!roots.some((q) => Math.abs(q - r) < 1e-7 * scale)) roots.push(r); };
  const bis = (a, b) => { let fa = f(a), fb = f(b); for (let i = 0; i < 200; i++) { const m = (a + b) / 2; const fm = f(m); if (Number.isNaN(fm)) return NaN; if (fm === 0) return m; if ((fa < 0) !== (fm < 0)) { b = m; fb = fm; } else { a = m; fa = fm; } if (Math.abs(b - a) < 1e-13 * Math.max(1, Math.abs(m))) break; } void fb; return (a + b) / 2; };
  const newton = (x) => { for (let i = 0; i < 80; i++) { const y = f(x); if (Number.isNaN(y)) return NaN; if (Math.abs(y) < 1e-14) return x; const h = 1e-6 * Math.max(1, Math.abs(x)); const d = (f(x + h) - f(x - h)) / (2 * h); if (!d || Number.isNaN(d)) return NaN; const nx = x - y / d; if (Math.abs(nx - x) < 1e-13 * Math.max(1, Math.abs(x))) return nx; x = nx; } return x; };
  lo = +lo; hi = +hi; if (!(hi > lo)) throw new Error('範圍要 lo < hi');
  // 掃描：範圍內均勻取點，再加上靠近 0 的對數取點（小數根、大數根都掃得到）
  const xs = new Set(); const N = 4000; for (let i = 0; i <= N; i++) xs.add(lo + (hi - lo) * i / N);
  for (let e = -9; e <= 9; e += 0.05) { const m = Math.pow(10, e); if (m <= hi && m >= lo) xs.add(m); if (-m <= hi && -m >= lo) xs.add(-m); }
  const pts = [...xs].sort((a, b) => a - b); let px = pts[0], py = f(px);
  for (let i = 1; i < pts.length; i++) { const x = pts[i], y = f(x); if (py === 0) add(px); else if (!Number.isNaN(py) && !Number.isNaN(y) && (py < 0) !== (y < 0)) add(bis(px, x)); else if (!Number.isNaN(py) && !Number.isNaN(y) && Math.abs(y) < 1e-3 && Math.abs(py) < 1e-3) add(newton((px + x) / 2)); px = x; py = y; }
  for (const g of [guess, 0, 1, -1, 10, -10, 0.1].filter((x) => x != null && Number.isFinite(+x))) { const r = newton(+g); if (r >= lo - 1e-9 && r <= hi + 1e-9) add(r); }
  roots.sort((a, b) => a - b);
  return { roots, text: roots.length ? `${variable} = ${roots.slice(0, 20).map((r) => sig(r)).join('、')}${roots.length > 20 ? ' …' : ''}\n（數值解，範圍 ${sig(lo)}～${sig(hi)} 內找到 ${roots.length} 個實根；驗算：代回後 |f| < 1e-6。超出範圍或複數根不在此列——多項式請用 kind=poly）` : `在 ${sig(lo)}～${sig(hi)} 內找不到實根（可能沒有實數解，或要調整 lo／hi；多項式的複數根用 kind=poly）` };
}
/** 多項式全部的根（Durand–Kerner）。coeffs：高次 → 常數 */
function poly(coeffs) {
  let c = (Array.isArray(coeffs) ? coeffs : String(coeffs || '').split(/[\s,，]+/)).filter((x) => x !== '').map(Number); if (c.some((x) => !Number.isFinite(x))) throw new Error('係數要是數字（高次到常數項，例 1,-3,2）');
  while (c.length && c[0] === 0) c.shift(); const n = c.length - 1; if (n < 1) throw new Error('至少要一次式'); if (n > 30) throw new Error('最高 30 次');
  const a = c.map((x) => x / c[0]); let z = Array.from({ length: n }, (_, k) => { const ang = 2 * Math.PI * k / n + 0.4; const r = 1 + Math.max(...a.slice(1).map(Math.abs)); return [r * Math.cos(ang) * 0.6, r * Math.sin(ang) * 0.6]; });
  const mul = (p, q) => [p[0] * q[0] - p[1] * q[1], p[0] * q[1] + p[1] * q[0]]; const div = (p, q) => { const d = q[0] * q[0] + q[1] * q[1]; return [(p[0] * q[0] + p[1] * q[1]) / d, (p[1] * q[0] - p[0] * q[1]) / d]; };
  const pv = (x) => { let r = [1, 0]; for (let i = 1; i <= n; i++) { r = mul(r, x); r[0] += a[i]; } return r; };
  for (let it = 0; it < 2000; it++) { let mx = 0; z = z.map((zi, i) => { let d = [1, 0]; for (let j = 0; j < n; j++) if (j !== i) d = mul(d, [zi[0] - z[j][0], zi[1] - z[j][1]]); const s = div(pv(zi), d); mx = Math.max(mx, Math.hypot(s[0], s[1])); return [zi[0] - s[0], zi[1] - s[1]]; }); if (mx < 1e-14) break; }
  // 實根用牛頓法再磨一次
  const P = (x) => c.reduce((r, k) => r * x + k, 0); const dP = (x) => c.slice(0, -1).reduce((r, k, i) => r * x + k * (n - i), 0);
  z = z.map(([re, im]) => { if (Math.abs(im) < 1e-7 * Math.max(1, Math.abs(re))) { let x = re; for (let i = 0; i < 20; i++) { const d = dP(x); if (!d) break; const nx = x - P(x) / d; if (!Number.isFinite(nx)) break; x = nx; } const rx = Math.round(x); return [Math.abs(x - rx) < 1e-9 && P(rx) === 0 ? rx : x, 0]; } return [re, im]; });
  z.sort((p, q) => p[0] - q[0] || p[1] - q[1]);
  return { roots: z, text: `${n} 次多項式的根：${z.map(([re, im]) => cstr(re, im)).join('、')}${n === 2 ? `\n判別式 Δ = ${sig(c[1] * c[1] - 4 * c[0] * c[2])}` : ''}` };
}
const M = (x, name = '矩陣') => { let m = x; if (typeof m === 'string') { try { m = JSON.parse(m); } catch { m = m.split(/[;\n]+/).filter((r) => r.trim()).map((r) => r.trim().split(/[\s,，]+/).map(Number)); } } if (!Array.isArray(m) || !m.length) throw new Error(`${name}格式：[[1,2],[3,4]] 或 "1 2; 3 4"`); if (!Array.isArray(m[0])) m = [m]; const w = m[0].length; if (!w || m.some((r) => !Array.isArray(r) || r.length !== w || r.some((v) => typeof v !== 'number' || !Number.isFinite(v)))) throw new Error(`${name}每一列要一樣長、都是數字`); if (m.length > 12 || w > 12) throw new Error('最大 12×12'); return m.map((r) => r.slice()); };
const mstr = (m) => m.map((r) => '[' + r.map((v) => sig(Math.abs(v) < 1e-12 ? 0 : v, 8)).join(', ') + ']').join('\n');
function gauss(A, B) {   // 回傳 { rank, det, X }；B 可為多欄
  const n = A.length, m = A[0].length; const a = A.map((r, i) => r.concat(B ? B[i] : [])); let det = 1, rank = 0; const piv = [];
  for (let c = 0, r = 0; c < m && r < n; c++) { let p = r; for (let i = r + 1; i < n; i++) if (Math.abs(a[i][c]) > Math.abs(a[p][c])) p = i; if (Math.abs(a[p][c]) < 1e-12) { det = 0; continue; } if (p !== r) { [a[p], a[r]] = [a[r], a[p]]; det = -det; } det *= a[r][c]; const d = a[r][c]; for (let k = c; k < a[r].length; k++) a[r][k] /= d; for (let i = 0; i < n; i++) if (i !== r && a[i][c]) { const f = a[i][c]; for (let k = c; k < a[r].length; k++) a[i][k] -= f * a[r][k]; } piv.push(c); r++; rank++; }
  if (rank < Math.min(n, m)) det = 0; return { rank, det: n === m ? det : null, a, piv };
}
function linear(A, b) {
  const a = M(A, 'A'); let bb = typeof b === 'string' ? b.split(/[\s,，;]+/).filter(Boolean).map(Number) : b; if (!Array.isArray(bb)) throw new Error('b 格式：[5, 6]'); bb = bb.map((v) => (Array.isArray(v) ? v[0] : v)); if (bb.length !== a.length || bb.some((v) => !Number.isFinite(v))) throw new Error(`b 要有 ${a.length} 個數字`);
  const n = a.length, m = a[0].length; const g = gauss(a, bb.map((v) => [v]));
  for (let i = g.rank; i < n; i++) if (Math.abs(g.a[i][m]) > 1e-9) return { x: null, text: '無解（方程式互相矛盾）' };
  if (g.rank < m) return { x: null, text: `有無限多組解（獨立的方程式只有 ${g.rank} 個，未知數 ${m} 個）` };
  const x = g.piv.map((_, i) => g.a[i][m]); return { x, text: `解：${x.map((v, i) => `x${i + 1} = ${sig(v)}`).join('、')}` };
}
function matrix(op, A, B) {
  const a = M(A, 'A'); const n = a.length, m = a[0].length; const sq = () => { if (n !== m) throw new Error('要方陣'); };
  switch (String(op || '').toLowerCase()) {
    case 'det': sq(); return { value: gauss(a).det, text: `det = ${sig(gauss(a).det)}` };
    case 'rank': return { value: gauss(a).rank, text: `rank = ${gauss(a).rank}` };
    case 'transpose': { const t = a[0].map((_, j) => a.map((r) => r[j])); return { value: t, text: mstr(t) }; }
    case 'inv': { sq(); const I = a.map((_, i) => a.map((__, j) => (i === j ? 1 : 0))); const g = gauss(a, I); if (g.rank < n) throw new Error('行列式為 0，沒有反矩陣'); const inv = g.a.map((r) => r.slice(n)); return { value: inv, text: '反矩陣：\n' + mstr(inv) }; }
    case 'mul': { const b = M(B, 'B'); if (b.length !== m) throw new Error(`A 是 ${n}×${m}，B 要有 ${m} 列`); const c = a.map((r) => b[0].map((_, j) => r.reduce((s, v, k) => s + v * b[k][j], 0))); return { value: c, text: mstr(c) }; }
    case 'eig': { sq(); // Faddeev–LeVerrier 求特徵多項式，再解根
      let Mk = a.map((r) => r.map(() => 0)); const c = [1]; const I = (k) => a.map((_, i) => a.map((__, j) => (i === j ? k : 0)));
      for (let k = 1; k <= n; k++) { const t = Mk.map((r, i) => r.map((v, j) => v + I(c[k - 1])[i][j])); Mk = a.map((r) => t[0].map((_, j) => r.reduce((s, v, q) => s + v * t[q][j], 0))); c.push(-Mk.reduce((s, r, i) => s + r[i], 0) / k); }
      const r = poly(c); return { value: r.roots, text: `特徵值：${r.roots.map(([re, im]) => cstr(re, im)).join('、')}\n（跡 = ${sig(a.reduce((s, row, i) => s + row[i], 0))}、行列式 = ${sig(gauss(a).det)}）` }; }
    default: throw new Error('op：det｜inv｜mul｜transpose｜rank｜eig');
  }
}
function diff(expr, at, { variable = 'x', order = 1 } = {}) {
  const f = safe(fn(expr, variable)); const x = +at; if (!Number.isFinite(x)) throw new Error('要給 at（在哪一點微分）'); const h0 = 1e-3 * Math.max(1, Math.abs(x));
  const d1 = (h) => (f(x + h) - f(x - h)) / (2 * h); const d2 = (h) => (f(x + h) - 2 * f(x) + f(x - h)) / (h * h); const D = +order === 2 ? d2 : d1;
  const v = (4 * D(h0 / 2) - D(h0)) / 3;   // Richardson 外推
  if (!Number.isFinite(v)) throw new Error('這一點算不出導數（函數在附近沒有定義？）'); const r = parseFloat(v.toPrecision(+order === 2 ? 6 : 9));
  return { value: r, text: `${+order === 2 ? "f''" : "f'"}(${sig(x)}) ≈ ${sig(r)}（數值微分）` };
}
function integrate(expr, a, b, { variable = 'x' } = {}) {
  const f = safe(fn(expr, variable)); a = +a; b = +b; if (!Number.isFinite(a) || !Number.isFinite(b)) throw new Error('要給積分上下限 a、b（有限的數）');
  const S = (x0, x2, f0, f1, f2) => (x2 - x0) / 6 * (f0 + 4 * f1 + f2); let evals = 0;
  const rec = (x0, x2, f0, f1, f2, whole, eps, depth) => { const x1 = (x0 + x2) / 2; const fa = f((x0 + x1) / 2), fb = f((x1 + x2) / 2); evals += 2; const L = S(x0, x1, f0, fa, f1), R = S(x1, x2, f1, fb, f2);
    if (depth <= 0 || evals > 200000 || Math.abs(L + R - whole) <= 15 * eps) return L + R + (L + R - whole) / 15; return rec(x0, x1, f0, fa, f1, L, eps / 2, depth - 1) + rec(x1, x2, f1, fb, f2, R, eps / 2, depth - 1); };
  const f0 = f(a), f2 = f(b), f1 = f((a + b) / 2); if ([f0, f1, f2].some(Number.isNaN)) throw new Error('函數在積分範圍的端點或中點沒有定義（瑕積分請避開奇異點）');
  const v = rec(a, b, f0, f1, f2, S(a, b, f0, f1, f2), 1e-10, 40); if (!Number.isFinite(v)) throw new Error('積分算不出來（範圍內有沒定義的點？）'); const r = parseFloat(v.toPrecision(10));
  return { value: r, text: `∫ 從 ${sig(a)} 到 ${sig(b)} ≈ ${sig(r)}（自適應辛普森法）` };
}
const numlist = (v, name) => { const a = (Array.isArray(v) ? v : String(v == null ? '' : v).split(/[\s,，;]+/)).filter((x) => x !== '').map(Number); if (!a.length || a.some((x) => !Number.isFinite(x))) throw new Error(`${name} 要是一串數字`); return a; };
function regress(xs, ys, degree = 1) {
  const x = numlist(xs, 'x'), y = numlist(ys, 'y'); const d = Math.max(1, Math.min(6, Math.floor(+degree || 1))); if (x.length !== y.length) throw new Error('x 與 y 個數要一樣'); if (x.length < d + 1) throw new Error(`${d} 次擬合至少要 ${d + 1} 個點`);
  const A = Array.from({ length: d + 1 }, (_, i) => Array.from({ length: d + 1 }, (__, j) => x.reduce((s, v) => s + Math.pow(v, i + j), 0))); const B = Array.from({ length: d + 1 }, (_, i) => x.reduce((s, v, k) => s + Math.pow(v, i) * y[k], 0));
  const sol = linear(A, B); if (!sol.x) throw new Error('資料點不足以決定這條曲線（x 值重複太多）'); const c = sol.x; const fit = (v) => c.reduce((s, k, i) => s + k * Math.pow(v, i), 0);
  const mean = y.reduce((s, v) => s + v, 0) / y.length; const ssT = y.reduce((s, v) => s + (v - mean) ** 2, 0); const ssR = y.reduce((s, v, k) => s + (v - fit(x[k])) ** 2, 0); const r2 = ssT ? 1 - ssR / ssT : 1;
  const eq = c.map((k, i) => (i === 0 ? sig(k, 6) : `${sig(k, 6)}·x${i > 1 ? '^' + i : ''}`)).reverse().join(' + ').replace(/\+ -/g, '− ');
  return { coeffs: c, r2, text: `擬合：y = ${eq}\nR² = ${sig(r2, 6)}（${x.length} 個點${d === 1 ? `；斜率 ${sig(c[1], 6)}、截距 ${sig(c[0], 6)}` : ''}）` };
}
function stats(list) {
  const a = numlist(list, '資料').sort((p, q) => p - q); const n = a.length; const sum = a.reduce((s, v) => s + v, 0); const mean = sum / n; const q = (p) => { const i = (n - 1) * p; const lo = Math.floor(i); return a[lo] + (a[Math.min(n - 1, lo + 1)] - a[lo]) * (i - lo); };
  const vp = a.reduce((s, v) => s + (v - mean) ** 2, 0); const sd = n > 1 ? Math.sqrt(vp / (n - 1)) : 0;
  return { n, mean, sd, text: `n = ${n}、總和 ${sig(sum)}、平均 ${sig(mean)}、中位數 ${sig(q(0.5))}\n樣本標準差 ${sig(sd)}（母體 ${sig(Math.sqrt(vp / n))}）、標準誤 ${sig(sd / Math.sqrt(n))}\n最小 ${sig(a[0])}、Q1 ${sig(q(0.25))}、Q3 ${sig(q(0.75))}、最大 ${sig(a[n - 1])}、全距 ${sig(a[n - 1] - a[0])}` };
}
function base(value, from = 10, to = 2) {
  const f = Math.floor(+from), t = Math.floor(+to); if (!(f >= 2 && f <= 36 && t >= 2 && t <= 36)) throw new Error('進位要 2～36'); let s = String(value == null ? '' : value).trim().toLowerCase().replace(/^0x/, f === 16 ? '' : '0x').replace(/^0b/, f === 2 ? '' : '0b').replace(/_/g, ''); const neg = s.startsWith('-'); if (neg) s = s.slice(1);
  if (!s || [...s].some((ch) => { const d = parseInt(ch, 36); return Number.isNaN(d) || d >= f; })) throw new Error(`「${value}」不是合法的 ${f} 進位整數`);
  let n = 0n; for (const ch of s) n = n * BigInt(f) + BigInt(parseInt(ch, 36)); const out = (neg ? '-' : '') + n.toString(t).toUpperCase();
  return { value: out, text: `${value}（${f} 進位）= ${out}（${t} 進位）${t !== 10 && f !== 10 ? `；十進位 ${(neg ? '-' : '') + n.toString(10)}` : ''}` };
}
function factor(nv) {
  let n; try { n = BigInt(String(nv).trim()); } catch { throw new Error('要給正整數'); } if (n < 2n) throw new Error('要大於 1 的整數'); if (n > 10n ** 15n) throw new Error('太大了（上限 10^15）');
  const fs = []; let m = n; for (let p = 2n; p * p <= m; p += (p === 2n ? 1n : 2n)) { let e = 0; while (m % p === 0n) { m /= p; e++; } if (e) fs.push([p, e]); } if (m > 1n) fs.push([m, 1]);
  const prime = fs.length === 1 && fs[0][1] === 1; const nd = fs.reduce((s, [, e]) => s * (e + 1), 1);
  return { factors: fs.map(([p, e]) => [Number(p), e]), text: prime ? `${n} 是質數` : `${n} = ${fs.map(([p, e]) => (e > 1 ? `${p}^${e}` : String(p))).join(' × ')}（共 ${nd} 個因數）` };
}
/** y' = f(x, y)，y(x0) = y0，算到 x1（RK4） */
function ode(expr, { x0 = 0, y0 = 0, x1 = 1, steps = 200 } = {}) {
  let e = String(expr || '').trim(); if (!e) throw new Error("要給 y' 的算式（可以用 x 與 y）"); e = e.replace(/−/g, '-').replace(/(\d)\s*([xy])(?![A-Za-z0-9_])/g, '$1*$2');
  const f = (x, y) => { const r = evaluate(e, null, { X: x, Y: y }); if (typeof r !== 'number' || !Number.isFinite(r)) throw new Error('算到沒有定義的值'); return r; };
  x0 = +x0; y0 = +y0; x1 = +x1; const n = Math.max(10, Math.min(20000, Math.floor(+steps || 200))); if (![x0, y0, x1].every(Number.isFinite) || x0 === x1) throw new Error('要給 x0、y0、x1（x1 ≠ x0）');
  const h = (x1 - x0) / n; let x = x0, y = y0; const pts = [[x, y]];
  for (let i = 0; i < n; i++) { const k1 = f(x, y), k2 = f(x + h / 2, y + h * k1 / 2), k3 = f(x + h / 2, y + h * k2 / 2), k4 = f(x + h, y + h * k3); y += h * (k1 + 2 * k2 + 2 * k3 + k4) / 6; x = x0 + (i + 1) * h; if (!Number.isFinite(y)) throw new Error(`解在 x ≈ ${sig(x)} 發散了`); if ((i + 1) % Math.ceil(n / 10) === 0 || i === n - 1) pts.push([x, y]); }
  return { value: y, points: pts, text: `y(${sig(x1)}) ≈ ${sig(y, 8)}（RK4，${n} 步）\n沿途：${pts.slice(0, 12).map(([px, py]) => `(${sig(px, 5)}, ${sig(py, 6)})`).join(' ')}` };
}
const KINDS = ['solve', 'poly', 'linear', 'matrix', 'diff', 'integrate', 'regress', 'stats', 'base', 'factor', 'ode'];
/** 統一入口（給 AI 工具用） */
function run(a = {}) {
  switch (String(a.kind || '').toLowerCase()) {
    case 'solve': return solve(a.expr, { variable: a.variable || 'x', lo: a.lo ?? -1000, hi: a.hi ?? 1000, guess: a.guess });
    case 'poly': return poly(a.coeffs);
    case 'linear': return linear(a.A, a.b);
    case 'matrix': return matrix(a.op, a.A, a.B);
    case 'diff': return diff(a.expr, a.at, { variable: a.variable || 'x', order: a.order || 1 });
    case 'integrate': return integrate(a.expr, a.a, a.b_, { variable: a.variable || 'x' });
    case 'regress': return regress(a.x, a.y, a.degree || 1);
    case 'stats': return stats(a.data);
    case 'base': return base(a.value, a.from || 10, a.to || 2);
    case 'factor': return factor(a.value);
    case 'ode': return ode(a.expr, { x0: a.x0, y0: a.y0, x1: a.x1, steps: a.steps });
    default: throw new Error('kind：' + KINDS.join('｜'));
  }
}
module.exports = { run, solve, poly, linear, matrix, diff, integrate, regress, stats, base, factor, ode, fn, KINDS };
