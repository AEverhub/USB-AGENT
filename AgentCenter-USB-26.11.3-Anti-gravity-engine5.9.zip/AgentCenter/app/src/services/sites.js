'use strict';
/**
 * 26.11.3 Anti-gravity-engine2：網站工作室——讓 AI 能自己開發一整個網頁系統（多檔案）。
 *   ・專案放在工作區 sites/<id>/，清單在 store.db.sites
 *   ・範本：blank 空白、landing 一頁式官網、app 資料管理系統（新增／編輯／刪除／搜尋／匯出，資料存瀏覽器）、
 *           dashboard 數據儀表板（純 JS 畫圖，不靠外部 CDN）、fullstack 前後端（Node 原生 http＋JSON 檔案資料庫＋REST API，零相依）
 *   ・check()：不執行程式的靜態檢查——JS 語法（只編譯不執行）、JSON、CSS 大括號、HTML 結構、找不到的本機引用、常見資安問題、無障礙小地方
 *   ・預覽：另開一個只綁 127.0.0.1 的小伺服器（預設 8767），和 App 控制介面是不同來源，網站裡的程式碰不到 App 的權杖與資料
 *   ・zip()：打包成 zip 給使用者下載
 */
const fs = require('fs');
const path = require('path');
const http = require('http');
const vm = require('vm');
const { rid, clip } = require('../core/util');
const AG = require('./autogen');

/* ---------------- Anti-gravity-engine3：一句話生成整個網站 ---------------- */
const PLAN_SYS = `你是資深全端工程師兼介面設計師。使用者用一句話描述想要的網站，你直接規劃，不要反問；資訊不足就用最合理的做法。只輸出 JSON，不要其他文字：
{"name":"網站名稱（12 字內）","type":"landing|app|dashboard|fullstack","summary":"一句話說明這個網站做什麼","sections":["主要區塊或畫面（4～8 個）"],"features":["具體功能（3～8 個，例：新增／編輯／刪除紀錄、依月份篩選、匯出 CSV、深色模式）"],"data":["要存的資料欄位（app／fullstack 才需要）"],"style":{"primary":"#RRGGBB","accent":"#RRGGBB","mood":"風格（例：溫暖手作、俐落科技、清新自然）"}}
type：介紹店家／公司／個人／作品／活動 → landing；記錄、管理、計算、追蹤、清單、預約類 → app；看數據、報表、圖表 → dashboard；明確要後端、API、資料庫、登入、多人共用 → fullstack。`;
const FILE_SYS = `你是資深前端／全端工程師。依需求與規劃寫出指定檔案的「完整內容」。
- 只輸出這個檔案的程式碼本身，不要說明、不要用 Markdown 包起來。
- 繁體中文介面，內容具體貼合需求，不要 lorem ipsum、不要「說明第一個特色」這種空泛佔位。真實資訊不知道的（電話、地址、價格、營業時間、人名、統計數字）用明顯的佔位，例如「（請填入電話）」，絕對不要捏造。
- 漂亮現代：手機優先 RWD、卡片、留白、圓角、柔和陰影、主色漸層按鈕、hover／focus 狀態、平滑過場；支援深淺色（prefers-color-scheme）。
- 語意化 HTML、label、alt、足夠對比、可用鍵盤操作。
- 不用任何外部 CDN、外部字型或外部圖片網址；圖示用內嵌 SVG。
- 原生 JavaScript（不用框架、不用 import），開頭 'use strict'；資料存 localStorage。把資料放進畫面一律用 textContent 或先跳脫，不要把沒跳脫的資料塞進 innerHTML。
- 有資料的畫面要有空狀態、表單驗證與錯誤提示；每個按鈕都要真的能用。儀表板沒有真實資料時，提供「匯入 CSV」或手動輸入，以及一個標明「範例資料」的載入按鈕。
- 各檔案之間的 id、class、檔名、函式要一致。`;
const FILES_BY_TYPE = { landing: ['index.html', 'style.css', 'app.js'], app: ['index.html', 'style.css', 'app.js'], dashboard: ['index.html', 'style.css', 'app.js'], fullstack: ['public/index.html', 'public/style.css', 'public/app.js', 'server.js', 'README.md'] };
const FILE_HINT = {
  'index.html': '完整 HTML 文件（<!doctype html>、lang="zh-Hant"、charset、viewport、title、description），引用 style.css 與 app.js（<script src="app.js"></script> 放在 body 最後）。',
  'public/index.html': '完整 HTML 文件，引用 style.css 與 app.js（相對路徑）。',
  'style.css': '完整 CSS：用 :root 變數放主色與輔色，包含深淺色、RWD（手機優先，min-width 斷點）。只用 HTML 裡真的有的 class／id。',
  'public/style.css': '完整 CSS（同上）。',
  'app.js': '完整前端程式，只操作 HTML 裡真的有的元素（先確認元素存在）。',
  'public/app.js': '完整前端程式：先試呼叫後端 /api/…，連不上就自動改用 localStorage（預覽時沒有後端）。',
  'server.js': '零相依 Node.js（只用 http、fs、path、crypto）：靜態檔放 public/、JSON REST API、資料存 data/*.json（寫入用暫存檔＋改名）、驗證輸入、限制 body 大小、錯誤回正確狀態碼、PORT 環境變數。',
  'README.md': '繁體中文說明：功能、怎麼執行（node server.js）、API 列表、上線前要做的事（登入驗證、HTTPS、備份）。',
};

const MAXF = 150, MAXB = 512 * 1024, MAXT = 8 * 1024 * 1024;
const TEXT_EXT = ['html', 'htm', 'css', 'js', 'mjs', 'cjs', 'json', 'svg', 'txt', 'md', 'xml', 'csv', 'webmanifest', 'map', 'ts', 'py', 'sql', 'yml', 'yaml', 'toml', 'ini', 'sh', 'gitignore', 'example', 'env', 'ejs', 'vue', 'jsx', 'tsx'];
const BIN_EXT = ['png', 'jpg', 'jpeg', 'gif', 'webp', 'ico', 'woff', 'woff2', 'ttf', 'mp3', 'wav', 'ogg', 'mp4', 'webm', 'pdf'];
const MIME = { html: 'text/html; charset=utf-8', htm: 'text/html; charset=utf-8', css: 'text/css; charset=utf-8', js: 'text/javascript; charset=utf-8', mjs: 'text/javascript; charset=utf-8', json: 'application/json; charset=utf-8', svg: 'image/svg+xml', txt: 'text/plain; charset=utf-8', md: 'text/plain; charset=utf-8', xml: 'application/xml', csv: 'text/csv; charset=utf-8', webmanifest: 'application/manifest+json', png: 'image/png', jpg: 'image/jpeg', jpeg: 'image/jpeg', gif: 'image/gif', webp: 'image/webp', ico: 'image/x-icon', woff: 'font/woff', woff2: 'font/woff2', ttf: 'font/ttf', mp3: 'audio/mpeg', wav: 'audio/wav', ogg: 'audio/ogg', mp4: 'video/mp4', webm: 'video/webm', pdf: 'application/pdf' };
const extOf = (p) => { const b = path.basename(p); if (b === '.gitignore') return 'gitignore'; return (b.includes('.') ? b.split('.').pop() : '').toLowerCase(); };
const VOID = new Set(['area', 'base', 'br', 'col', 'embed', 'hr', 'img', 'input', 'link', 'meta', 'param', 'source', 'track', 'wbr']);
const CHECK_TAGS = ['html', 'head', 'body', 'div', 'section', 'main', 'header', 'footer', 'nav', 'article', 'aside', 'form', 'ul', 'ol', 'table', 'thead', 'tbody', 'tr', 'button', 'select', 'textarea', 'label', 'a', 'span', 'h1', 'h2', 'h3', 'h4', 'canvas', 'svg', 'dialog', 'template'];

/** 安全的相對路徑：不能跳出專案、不能絕對路徑、不能有控制字元；回傳正規化後的 a/b/c */
function cleanPath(p) {
  let s = String(p == null ? '' : p).trim().replace(/\\/g, '/').replace(/^\.\/+/, '');
  if (!s || s.length > 200 || s.startsWith('/') || /[\u0000-\u001f<>:"|?*]/.test(s)) throw new Error(`檔名不合法：${p}`);
  const parts = s.split('/').filter((x) => x && x !== '.'); if (!parts.length || parts.some((x) => x === '..')) throw new Error(`檔名不合法：${p}`);
  if (parts.length > 8) throw new Error(`資料夾太深：${p}`);
  for (const x of parts) if (x.startsWith('.') && !['.gitignore', '.env.example', '.nojekyll', '.htaccess'].includes(x)) throw new Error(`不允許隱藏檔：${p}（.env 這類放祕密的檔案不要放進網站；可以用 .env.example）`);
  const e = extOf(s); if (e && !TEXT_EXT.includes(e) && !BIN_EXT.includes(e)) throw new Error(`不支援的檔案類型 .${e}：${p}`);
  return parts.join('/');
}
const slug = (name) => { const s = String(name || '').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 24); return (s || 'site') + '-' + rid(4).toLowerCase(); };

/* ---------------- 範本 ---------------- */
const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const BASE_CSS = `:root{--bg:#0b1020;--card:#141b2e;--line:#243049;--fg:#e8edf7;--mute:#9aa6bd;--ac:#5b8cff;--ac2:#8b5cf6;--ok:#22c55e;--bad:#ef4444;--r:14px}
@media (prefers-color-scheme:light){:root{--bg:#f6f7fb;--card:#fff;--line:#e3e7ef;--fg:#141824;--mute:#5d6b82}}
*{box-sizing:border-box}html,body{margin:0}body{font-family:system-ui,-apple-system,"Noto Sans TC","PingFang TC","Microsoft JhengHei",sans-serif;background:var(--bg);color:var(--fg);line-height:1.6}
a{color:var(--ac)}img{max-width:100%;height:auto}button,input,select,textarea{font:inherit}
.wrap{max-width:1080px;margin:0 auto;padding:0 20px}
.btn{display:inline-flex;align-items:center;gap:6px;border:0;border-radius:10px;padding:10px 16px;background:linear-gradient(135deg,var(--ac),var(--ac2));color:#fff;font-weight:600;cursor:pointer;text-decoration:none}
.btn.ghost{background:transparent;border:1px solid var(--line);color:var(--fg)}.btn.danger{background:var(--bad)}
.card{background:var(--card);border:1px solid var(--line);border-radius:var(--r);padding:18px}
input,select,textarea{width:100%;padding:10px 12px;border-radius:10px;border:1px solid var(--line);background:var(--bg);color:var(--fg)}
label{display:block;font-size:14px;color:var(--mute);margin:10px 0 4px}
.mute{color:var(--mute)}.grid{display:grid;gap:16px}
@media (min-width:760px){.g2{grid-template-columns:1fr 1fr}.g3{grid-template-columns:repeat(3,1fr)}.g4{grid-template-columns:repeat(4,1fr)}}
`;
const page = (title, body, { css = 'style.css', js = 'app.js', desc = '' } = {}) => `<!doctype html>
<html lang="zh-Hant">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>${esc(title)}</title>
<meta name="description" content="${esc(desc || title)}">
<link rel="stylesheet" href="${css}">
</head>
<body>
${body}
${js ? `<script src="${js}"></script>` : ''}
</body>
</html>
`;
const TEMPLATES = {
  blank: { name: '空白網站', files: (t) => ({
    'index.html': page(t, `<main class="wrap" style="padding:60px 20px">\n  <h1>${esc(t)}</h1>\n  <p class="mute">從這裡開始。</p>\n  <button class="btn" id="hello">按我</button>\n  <p id="out"></p>\n</main>`),
    'style.css': BASE_CSS,
    'app.js': `'use strict';\ndocument.getElementById('hello').addEventListener('click', () => {\n  document.getElementById('out').textContent = '你好！現在是 ' + new Date().toLocaleString();\n});\n`,
  }) },
  landing: { name: '一頁式官網', files: (t) => ({
    'index.html': page(t, `<header class="top"><div class="wrap nav"><b class="logo">${esc(t)}</b><nav><a href="#features">特色</a><a href="#pricing">方案</a><a href="#contact">聯絡</a></nav></div></header>
<section class="hero"><div class="wrap"><h1>${esc(t)}</h1><p class="lead">一句話說清楚你提供什麼價值。</p><a class="btn" href="#contact">立即聯絡</a> <a class="btn ghost" href="#features">了解更多</a></div></section>
<section id="features" class="wrap sec"><h2>特色</h2><div class="grid g3">
  <div class="card"><h3>快速</h3><p class="mute">說明第一個特色。</p></div>
  <div class="card"><h3>可靠</h3><p class="mute">說明第二個特色。</p></div>
  <div class="card"><h3>好用</h3><p class="mute">說明第三個特色。</p></div>
</div></section>
<section id="pricing" class="wrap sec"><h2>方案</h2><div class="grid g3">
  <div class="card plan"><h3>入門</h3><p class="price">NT$0</p><ul><li>基本功能</li><li>社群支援</li></ul></div>
  <div class="card plan hot"><h3>專業</h3><p class="price">NT$299<small>/月</small></p><ul><li>全部功能</li><li>優先支援</li></ul></div>
  <div class="card plan"><h3>企業</h3><p class="price">洽詢</p><ul><li>客製化</li><li>專屬窗口</li></ul></div>
</div></section>
<section id="contact" class="wrap sec"><h2>聯絡我們</h2><form class="card" id="cform" novalidate>
  <label for="cname">姓名</label><input id="cname" name="name" required autocomplete="name">
  <label for="cmail">Email</label><input id="cmail" name="email" type="email" required autocomplete="email">
  <label for="cmsg">想說的話</label><textarea id="cmsg" name="msg" rows="4" required></textarea>
  <p><button class="btn" type="submit">送出</button></p><p id="cres" class="mute" role="status"></p>
</form></section>
<footer class="wrap foot mute">© <span id="yr"></span> ${esc(t)}</footer>`),
    'style.css': BASE_CSS + `.top{position:sticky;top:0;backdrop-filter:blur(10px);background:color-mix(in srgb,var(--bg) 80%,transparent);border-bottom:1px solid var(--line);z-index:5}
.nav{display:flex;align-items:center;justify-content:space-between;height:60px}.nav a{margin-left:18px;color:var(--fg);text-decoration:none}.logo{font-size:18px}
.hero{padding:90px 0 70px;background:radial-gradient(80% 60% at 50% 0%,color-mix(in srgb,var(--ac) 25%,transparent),transparent)}
.hero h1{font-size:clamp(32px,6vw,56px);margin:0 0 10px}.lead{font-size:20px;color:var(--mute);margin:0 0 26px}
.sec{padding:60px 20px}.sec h2{font-size:28px;margin:0 0 20px}.price{font-size:30px;font-weight:700;margin:6px 0}.price small{font-size:14px;color:var(--mute)}
.plan.hot{border-color:var(--ac);box-shadow:0 0 0 1px var(--ac)}.foot{padding:30px 20px;border-top:1px solid var(--line)}
`,
    'app.js': `'use strict';
document.getElementById('yr').textContent = new Date().getFullYear();
const f = document.getElementById('cform'); const res = document.getElementById('cres');
f.addEventListener('submit', (e) => {
  e.preventDefault();
  const d = Object.fromEntries(new FormData(f));
  if (!d.name.trim() || !/^[^@\\s]+@[^@\\s]+\\.[^@\\s]+$/.test(d.email) || !d.msg.trim()) { res.textContent = '請把姓名、正確的 Email 和內容都填好。'; return; }
  // 這裡接你的後端或表單服務（例如 fetch('/api/contact', …)）；目前先存在瀏覽器示範
  try { const all = JSON.parse(localStorage.getItem('contact') || '[]'); all.push({ ...d, at: Date.now() }); localStorage.setItem('contact', JSON.stringify(all)); } catch (err) { /* 私密模式等情況存不了也沒關係 */ }
  f.reset(); res.textContent = '已收到，我們會盡快回覆你！';
});
`,
  }) },
  app: { name: '資料管理系統', files: (t) => ({
    'index.html': page(t, `<main class="wrap" style="padding:24px 20px 60px">
  <header class="bar"><h1>${esc(t)}</h1><div class="acts"><button class="btn ghost" id="exp">匯出 CSV</button><button class="btn" id="add">新增</button></div></header>
  <div class="grid g4 stats"><div class="card"><small class="mute">總筆數</small><b id="s-n">0</b></div><div class="card"><small class="mute">進行中</small><b id="s-a">0</b></div><div class="card"><small class="mute">已完成</small><b id="s-d">0</b></div><div class="card"><small class="mute">總金額</small><b id="s-m">0</b></div></div>
  <div class="tools"><input id="q" placeholder="搜尋名稱、分類、備註" aria-label="搜尋"><select id="fs" aria-label="狀態篩選"><option value="">全部狀態</option><option>進行中</option><option>已完成</option></select></div>
  <div class="card tbl"><table><thead><tr><th data-k="name">名稱</th><th data-k="cat">分類</th><th data-k="amount">金額</th><th data-k="status">狀態</th><th data-k="date">日期</th><th></th></tr></thead><tbody id="rows"></tbody></table><p id="empty" class="mute" hidden>還沒有資料，按「新增」開始。</p></div>
</main>
<dialog id="dlg"><form method="dialog" id="frm" class="card">
  <h2 id="dt">新增</h2>
  <label for="f-name">名稱</label><input id="f-name" required>
  <div class="grid g2"><div><label for="f-cat">分類</label><input id="f-cat"></div><div><label for="f-amount">金額</label><input id="f-amount" type="number" step="any" min="0"></div></div>
  <div class="grid g2"><div><label for="f-status">狀態</label><select id="f-status"><option>進行中</option><option>已完成</option></select></div><div><label for="f-date">日期</label><input id="f-date" type="date"></div></div>
  <label for="f-note">備註</label><textarea id="f-note" rows="3"></textarea>
  <p class="acts"><button class="btn ghost" value="cancel" formnovalidate>取消</button><button class="btn" id="save" value="ok">儲存</button></p>
</form></dialog>`),
    'style.css': BASE_CSS + `.bar{display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap}.bar h1{margin:0;font-size:26px}.acts{display:flex;gap:8px;justify-content:flex-end}
.stats{margin:18px 0}@media (max-width:759px){.stats{grid-template-columns:1fr 1fr;gap:10px}.stats .card{padding:12px}}.stats b{display:block;font-size:24px}.tools{display:flex;gap:10px;margin-bottom:12px}.tools select{max-width:160px}
.tbl{padding:0;overflow:auto}table{width:100%;border-collapse:collapse}th,td{padding:11px 12px;text-align:left;border-bottom:1px solid var(--line);white-space:nowrap}th{cursor:pointer;color:var(--mute);font-weight:600;font-size:14px}
tr:hover td{background:color-mix(in srgb,var(--ac) 6%,transparent)}.tag{padding:2px 8px;border-radius:99px;font-size:12px;background:color-mix(in srgb,var(--ac) 18%,transparent)}.tag.done{background:color-mix(in srgb,var(--ok) 20%,transparent)}
td .mini{border:0;background:none;color:var(--ac);cursor:pointer;padding:4px 6px}td .mini.del{color:var(--bad)}#empty{padding:20px;text-align:center}
dialog{border:0;padding:0;background:transparent;color:var(--fg);width:min(520px,92vw)}dialog::backdrop{background:#0008}dialog h2{margin-top:0}
`,
    'app.js': `'use strict';
// 資料存在瀏覽器（localStorage）。要多人共用時，把 load()/persist() 換成呼叫後端 API 即可。
const KEY = 'records_v1'; const $ = (s) => document.querySelector(s);
let items = load(); let sortK = 'date', sortD = -1; let editing = null;
function load() { try { return JSON.parse(localStorage.getItem(KEY) || '[]'); } catch (e) { return []; } }
function persist() { try { localStorage.setItem(KEY, JSON.stringify(items)); } catch (e) { alert('存不進去：' + e.message); } }
const money = (n) => (Number(n) || 0).toLocaleString('zh-TW');
const escapeHtml = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
function view() {
  const q = $('#q').value.trim().toLowerCase(); const fs = $('#fs').value;
  return items.filter((x) => (!fs || x.status === fs) && (!q || [x.name, x.cat, x.note].join(' ').toLowerCase().includes(q)))
    .sort((a, b) => (a[sortK] > b[sortK] ? 1 : a[sortK] < b[sortK] ? -1 : 0) * sortD);
}
function render() {
  const v = view();
  $('#rows').innerHTML = v.map((x) => '<tr><td>' + escapeHtml(x.name) + '</td><td>' + escapeHtml(x.cat) + '</td><td>' + money(x.amount) + '</td><td><span class="tag' + (x.status === '已完成' ? ' done' : '') + '">' + escapeHtml(x.status) + '</span></td><td>' + escapeHtml(x.date) + '</td><td><button class="mini" data-e="' + x.id + '">編輯</button><button class="mini del" data-d="' + x.id + '">刪除</button></td></tr>').join('');
  $('#empty').hidden = v.length > 0;
  $('#s-n').textContent = items.length; $('#s-a').textContent = items.filter((x) => x.status !== '已完成').length;
  $('#s-d').textContent = items.filter((x) => x.status === '已完成').length; $('#s-m').textContent = money(items.reduce((s, x) => s + (Number(x.amount) || 0), 0));
}
function open(x) {
  editing = x || null; $('#dt').textContent = x ? '編輯' : '新增';
  $('#f-name').value = x ? x.name : ''; $('#f-cat').value = x ? x.cat : ''; $('#f-amount').value = x ? x.amount : '';
  $('#f-status').value = x ? x.status : '進行中'; $('#f-date').value = x ? x.date : new Date().toISOString().slice(0, 10); $('#f-note').value = x ? x.note : '';
  $('#dlg').showModal(); $('#f-name').focus();
}
$('#dlg').addEventListener('close', () => {
  if ($('#dlg').returnValue !== 'ok') return; const name = $('#f-name').value.trim(); if (!name) return;
  const rec = { name, cat: $('#f-cat').value.trim(), amount: Number($('#f-amount').value) || 0, status: $('#f-status').value, date: $('#f-date').value, note: $('#f-note').value.trim() };
  if (editing) Object.assign(editing, rec); else items.push({ id: Date.now().toString(36) + Math.random().toString(36).slice(2, 6), ...rec });
  persist(); render();
});
$('#add').onclick = () => open();
$('#rows').onclick = (e) => {
  const ed = e.target.closest('[data-e]'); if (ed) return open(items.find((x) => x.id === ed.dataset.e));
  const del = e.target.closest('[data-d]'); if (del && confirm('確定刪除這筆？')) { items = items.filter((x) => x.id !== del.dataset.d); persist(); render(); }
};
document.querySelector('thead').onclick = (e) => { const th = e.target.closest('[data-k]'); if (!th) return; if (sortK === th.dataset.k) sortD = -sortD; else { sortK = th.dataset.k; sortD = 1; } render(); };
$('#q').oninput = render; $('#fs').onchange = render;
$('#exp').onclick = () => {
  const cols = ['name', 'cat', 'amount', 'status', 'date', 'note']; const head = ['名稱', '分類', '金額', '狀態', '日期', '備註'];
  const csv = [head, ...items.map((x) => cols.map((k) => x[k]))].map((r) => r.map((c) => '"' + String(c == null ? '' : c).replace(/"/g, '""') + '"').join(',')).join('\\r\\n');
  const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob(['\\ufeff' + csv], { type: 'text/csv' })); a.download = 'records.csv'; a.click(); setTimeout(() => URL.revokeObjectURL(a.href), 1000);
};
render();
`,
  }) },
  dashboard: { name: '數據儀表板', files: (t) => ({
    'index.html': page(t, `<main class="wrap" style="padding:24px 20px 60px">
  <header class="bar"><h1>${esc(t)}</h1><select id="range" aria-label="期間"><option value="7">近 7 天</option><option value="30" selected>近 30 天</option><option value="90">近 90 天</option></select></header>
  <div class="grid g4 kpis" id="kpis"></div>
  <div class="grid g2"><div class="card"><h3>每日趨勢</h3><canvas id="line" height="220" aria-label="每日趨勢圖"></canvas></div><div class="card"><h3>分類占比</h3><canvas id="bar" height="220" aria-label="分類長條圖"></canvas></div></div>
  <p class="mute small">資料來源：data.json（把它換成你的真實數據，或改成 fetch 你的 API）。</p>
</main>`),
    'style.css': BASE_CSS + `.bar{display:flex;align-items:center;justify-content:space-between;gap:12px}.bar h1{margin:0;font-size:26px}.bar select{max-width:140px}
.kpis{margin:18px 0}@media (max-width:759px){.kpis{grid-template-columns:1fr 1fr;gap:10px}.kpis .card{padding:12px}}.kpi b{display:block;font-size:26px}.kpi .d{font-size:13px}.up{color:var(--ok)}.down{color:var(--bad)}canvas{width:100%;display:block}h3{margin:0 0 10px}.small{font-size:13px}
`,
    'data.json': JSON.stringify({ daily: Array.from({ length: 90 }, (_, i) => ({ day: i, visits: Math.round(400 + 120 * Math.sin(i / 6) + i * 3), orders: Math.round(30 + 9 * Math.cos(i / 5) + i * 0.3) })), categories: [['服飾', 34], ['3C', 27], ['食品', 21], ['居家', 12], ['其他', 6]] }, null, 0) + '\n',
    'app.js': `'use strict';
const $ = (s) => document.querySelector(s); let data = null;
function css(v) { return getComputedStyle(document.documentElement).getPropertyValue(v).trim(); }
function setup(c) { const r = window.devicePixelRatio || 1; const w = c.clientWidth, h = Number(c.getAttribute('height')); c.width = w * r; c.height = h * r; c.style.height = h + 'px'; const g = c.getContext('2d'); g.setTransform(r, 0, 0, r, 0, 0); return { g, w, h }; }
function line(c, ys) {
  const { g, w, h } = setup(c); const p = 28, max = Math.max(...ys) * 1.1, min = Math.min(...ys) * 0.9; const X = (i) => p + (w - p * 2) * i / Math.max(1, ys.length - 1); const Y = (v) => h - p - (h - p * 2) * (v - min) / (max - min || 1);
  g.strokeStyle = css('--line'); g.lineWidth = 1; for (let k = 0; k <= 4; k++) { const y = p + (h - p * 2) * k / 4; g.beginPath(); g.moveTo(p, y); g.lineTo(w - p, y); g.stroke(); }
  const grad = g.createLinearGradient(0, p, 0, h - p); grad.addColorStop(0, css('--ac') + '55'); grad.addColorStop(1, css('--ac') + '00');
  g.beginPath(); ys.forEach((v, i) => (i ? g.lineTo(X(i), Y(v)) : g.moveTo(X(i), Y(v)))); g.lineTo(X(ys.length - 1), h - p); g.lineTo(X(0), h - p); g.fillStyle = grad; g.fill();
  g.beginPath(); ys.forEach((v, i) => (i ? g.lineTo(X(i), Y(v)) : g.moveTo(X(i), Y(v)))); g.strokeStyle = css('--ac'); g.lineWidth = 2.5; g.stroke();
}
function bars(c, rows) {
  const { g, w, h } = setup(c); const p = 28, max = Math.max(...rows.map((r) => r[1])); const bw = (w - p * 2) / rows.length;
  rows.forEach(([name, v], i) => { const bh = (h - p * 2.2) * v / max; const x = p + i * bw + bw * 0.18; const y = h - p - bh; const gr = g.createLinearGradient(0, y, 0, h - p); gr.addColorStop(0, css('--ac2')); gr.addColorStop(1, css('--ac')); g.fillStyle = gr; g.fillRect(x, y, bw * 0.64, bh); g.fillStyle = css('--mute'); g.font = '12px system-ui'; g.textAlign = 'center'; g.fillText(name, x + bw * 0.32, h - 8); g.fillText(v + '%', x + bw * 0.32, y - 6); });
}
function draw() {
  if (!data) return; const n = Number($('#range').value); const d = data.daily.slice(-n); const prev = data.daily.slice(-2 * n, -n);
  const sum = (a, k) => a.reduce((s, x) => s + x[k], 0); const pct = (a, b) => (b ? ((a - b) / b * 100).toFixed(1) : '0.0');
  const k = [['造訪', sum(d, 'visits'), sum(prev, 'visits')], ['訂單', sum(d, 'orders'), sum(prev, 'orders')]];
  const conv = (sum(d, 'orders') / Math.max(1, sum(d, 'visits')) * 100).toFixed(2); const avg = Math.round(sum(d, 'visits') / d.length);
  const card = (title, value, delta) => { const d = document.createElement('div'); d.className = 'card kpi'; const s = document.createElement('small'); s.className = 'mute'; s.textContent = title; const b = document.createElement('b'); b.textContent = value; d.append(s, b);
    if (delta != null) { const sp = document.createElement('span'); sp.className = 'd ' + (delta >= 0 ? 'up' : 'down'); sp.textContent = (delta >= 0 ? '+' : '') + delta + '% 與前期比'; d.append(sp); } return d; };
  $('#kpis').replaceChildren(...k.map(([t, v, p]) => card(t, v.toLocaleString(), pct(v, p))), card('轉換率', conv + '%'), card('日均造訪', avg.toLocaleString()));
  line($('#line'), d.map((x) => x.visits)); bars($('#bar'), data.categories);
}
$('#range').onchange = draw; window.addEventListener('resize', draw);
fetch('data.json').then((r) => r.json()).then((j) => { data = j; draw(); }).catch((e) => { $('#kpis').textContent = '讀不到 data.json：' + e.message; });
`,
  }) },
  fullstack: { name: '前後端系統（Node.js）', files: (t) => ({
    'README.md': `# ${t}\n\n前後端一起的網頁系統，**零相依**（只用 Node.js 內建模組）。\n\n## 執行\n\n\`\`\`bash\nnode server.js            # 預設 http://localhost:3000\nPORT=8080 node server.js  # 換埠\n\`\`\`\n\n- 前端：public/（index.html、app.js、style.css）\n- 後端：server.js（REST API＋靜態檔）\n- 資料：data/items.json（自動建立）\n\n## API\n\n| 方法 | 路徑 | 說明 |\n|---|---|---|\n| GET | /api/items | 列出 |\n| POST | /api/items | 新增 {name, note} |\n| PUT | /api/items/:id | 修改 |\n| DELETE | /api/items/:id | 刪除 |\n\n## 上線前\n\n- 加上登入驗證（目前任何人都能讀寫）\n- 放在反向代理（Nginx／Caddy）後面並開 HTTPS\n- 資料量大時改用 SQLite／PostgreSQL\n`,
    'package.json': JSON.stringify({ name: slug(t).replace(/-[a-z0-9]{4}$/, ''), version: '1.0.0', private: true, description: t, main: 'server.js', scripts: { start: 'node server.js' }, engines: { node: '>=18' } }, null, 2) + '\n',
    '.gitignore': 'node_modules/\ndata/\n.env\n',
    'server.js': `'use strict';
// 零相依的後端：靜態檔＋JSON REST API。資料存在 data/items.json（寫入用暫存檔＋改名，避免寫到一半壞掉）。
const http = require('http'); const fs = require('fs'); const path = require('path'); const crypto = require('crypto');
const PORT = Number(process.env.PORT) || 3000; const PUB = path.join(__dirname, 'public'); const DATA = path.join(__dirname, 'data', 'items.json');
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.json': 'application/json', '.svg': 'image/svg+xml', '.png': 'image/png', '.ico': 'image/x-icon' };
function load() { try { return JSON.parse(fs.readFileSync(DATA, 'utf8')); } catch (e) { return []; } }
function save(items) { fs.mkdirSync(path.dirname(DATA), { recursive: true }); const tmp = DATA + '.tmp'; fs.writeFileSync(tmp, JSON.stringify(items, null, 2)); fs.renameSync(tmp, DATA); }
function send(res, code, obj) { res.writeHead(code, { 'content-type': 'application/json; charset=utf-8', 'x-content-type-options': 'nosniff' }); res.end(JSON.stringify(obj)); }
function body(req) { return new Promise((ok, bad) => { let n = 0; const c = []; req.on('data', (d) => { n += d.length; if (n > 1e6) { bad(new Error('內容太大')); req.destroy(); } else c.push(d); }); req.on('end', () => { try { ok(c.length ? JSON.parse(Buffer.concat(c).toString('utf8')) : {}); } catch (e) { bad(new Error('JSON 格式錯誤')); } }); }); }
function clean(b) { const name = String(b.name || '').trim().slice(0, 200); if (!name) throw new Error('name 必填'); return { name, note: String(b.note || '').slice(0, 2000), done: !!b.done }; }
http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://x'); const p = decodeURIComponent(url.pathname);
  try {
    if (p === '/api/items' && req.method === 'GET') return send(res, 200, load());
    if (p === '/api/items' && req.method === 'POST') { const items = load(); const it = { id: crypto.randomUUID(), ...clean(await body(req)), created: Date.now() }; items.push(it); save(items); return send(res, 201, it); }
    const m = /^\\/api\\/items\\/([\\w-]+)$/.exec(p);
    if (m && req.method === 'PUT') { const items = load(); const it = items.find((x) => x.id === m[1]); if (!it) return send(res, 404, { error: '找不到' }); Object.assign(it, clean({ ...it, ...(await body(req)) })); save(items); return send(res, 200, it); }
    if (m && req.method === 'DELETE') { const items = load(); const n = items.filter((x) => x.id !== m[1]); if (n.length === items.length) return send(res, 404, { error: '找不到' }); save(n); return send(res, 200, { ok: true }); }
    if (p.startsWith('/api/')) return send(res, 404, { error: '沒有這個 API' });
    const f = path.join(PUB, p === '/' ? 'index.html' : p); if (!f.startsWith(PUB + path.sep) && f !== path.join(PUB, 'index.html')) return send(res, 403, { error: '禁止' });
    fs.readFile(f, (e, buf) => { if (e) { res.writeHead(404); return res.end('not found'); } res.writeHead(200, { 'content-type': MIME[path.extname(f)] || 'application/octet-stream', 'x-content-type-options': 'nosniff' }); res.end(buf); });
  } catch (e) { send(res, 400, { error: e.message }); }
}).listen(PORT, () => console.log('http://localhost:' + PORT));
`,
    'public/index.html': page(t, `<main class="wrap" style="padding:30px 20px 60px">
  <h1>${esc(t)}</h1><p class="mute" id="mode"></p>
  <form id="f" class="card row"><input id="name" placeholder="新增一個項目" required aria-label="項目名稱"><button class="btn">新增</button></form>
  <ul id="list" class="list"></ul>
</main>`),
    'public/style.css': BASE_CSS + `.row{display:flex;gap:10px}.list{list-style:none;padding:0}.list li{display:flex;align-items:center;gap:10px;background:var(--card);border:1px solid var(--line);border-radius:12px;padding:10px 14px;margin:8px 0}.list li.done span{text-decoration:line-through;color:var(--mute)}.list li span{flex:1}.list button{border:0;background:none;color:var(--bad);cursor:pointer}`,
    'public/app.js': `'use strict';
// 有後端（node server.js）就用 REST API；只開靜態預覽時自動改用瀏覽器儲存，畫面一樣能操作。
const $ = (s) => document.querySelector(s); let useApi = true;
const local = { all() { try { return JSON.parse(localStorage.getItem('items') || '[]'); } catch (e) { return []; } }, put(a) { localStorage.setItem('items', JSON.stringify(a)); } };
async function api(method, url, body) { const r = await fetch(url, { method, headers: body ? { 'content-type': 'application/json' } : {}, body: body ? JSON.stringify(body) : undefined }); if (!r.ok) throw new Error((await r.json().catch(() => ({}))).error || r.status); return r.json(); }
async function list() { if (useApi) { try { return await api('GET', '/api/items'); } catch (e) { useApi = false; } } return local.all(); }
async function add(name) { if (useApi) return api('POST', '/api/items', { name }); const a = local.all(); a.push({ id: Date.now().toString(36), name, done: false }); local.put(a); }
async function toggle(it) { if (useApi) return api('PUT', '/api/items/' + it.id, { done: !it.done }); local.put(local.all().map((x) => (x.id === it.id ? { ...x, done: !x.done } : x))); }
async function del(id) { if (useApi) return api('DELETE', '/api/items/' + id); local.put(local.all().filter((x) => x.id !== id)); }
async function render() {
  const items = await list(); $('#mode').textContent = useApi ? '已連上後端 API' : '預覽模式：資料存在這個瀏覽器（執行 node server.js 會改用後端）';
  const ul = $('#list'); ul.textContent = '';
  for (const it of items) { const li = document.createElement('li'); if (it.done) li.className = 'done'; const cb = document.createElement('input'); cb.type = 'checkbox'; cb.checked = !!it.done; cb.style.width = 'auto'; cb.onchange = async () => { await toggle(it); render(); };
    const sp = document.createElement('span'); sp.textContent = it.name; const b = document.createElement('button'); b.textContent = '刪除'; b.onclick = async () => { await del(it.id); render(); }; li.append(cb, sp, b); ul.append(li); }
}
$('#f').onsubmit = async (e) => { e.preventDefault(); const v = $('#name').value.trim(); if (!v) return; await add(v); $('#name').value = ''; render(); };
render();
`,
  }) },
};

/* ---------------- 檢查 ---------------- */
function lineOf(text, idx) { let n = 1; for (let i = 0; i < idx && i < text.length; i++) if (text.charCodeAt(i) === 10) n++; return n; }
function stripHtmlNoise(h) { return h.replace(/<!--[\s\S]*?-->/g, (m) => m.replace(/[^\n]/g, ' ')).replace(/<(script|style)\b[^>]*>[\s\S]*?<\/\1\s*>/gi, (m, t) => { const open = /^<[^>]*>/.exec(m)[0]; return open + m.slice(open.length, m.length - t.length - 3).replace(/[^\n]/g, ' ') + '</' + t + '>'; }); }
function checkJs(code, file) {
  const isModule = /^\s*(import\s[^(]|export\s)/m.test(code) || /\.mjs$/.test(file);
  let src = code;
  if (isModule) src = '(async function(){\n' + code.replace(/^\s*import\s+[\s\S]*?from\s*['"][^'"]+['"]\s*;?/gm, (m) => m.replace(/[^\n]/g, ' ')).replace(/^\s*import\s*['"][^'"]+['"]\s*;?/gm, (m) => m.replace(/[^\n]/g, ' ')).replace(/^(\s*)export\s+default\s+/gm, '$1void ').replace(/^(\s*)export\s+(?=(const|let|var|function|class|async)\b)/gm, '$1').replace(/^\s*export\s*\{[^}]*\}\s*(from\s*['"][^'"]+['"])?\s*;?/gm, (m) => m.replace(/[^\n]/g, ' ')) + '\n})';
  else if (/^#!/.test(src)) src = '//' + src;
  try { new vm.Script(src, { filename: file }); return null; } catch (e) {
    const m = new RegExp(file.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + ':(\\d+)').exec(String(e.stack || '')); let line = m ? +m[1] : 0; if (isModule && line) line -= 1;
    return { line, msg: 'JavaScript 語法錯誤：' + e.message };
  }
}
function checkCss(css) {
  const s = css.replace(/\/\*[\s\S]*?\*\//g, (m) => m.replace(/[^\n]/g, ' ')).replace(/"(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*'/g, (m) => m.replace(/[^\n]/g, ' '));
  let d = 0; for (let i = 0; i < s.length; i++) { if (s[i] === '{') d++; else if (s[i] === '}') { d--; if (d < 0) return { line: lineOf(s, i), msg: 'CSS 多了一個 }' }; } }
  return d ? { line: 0, msg: `CSS 少了 ${d} 個 }` } : null;
}
function checkHtml(html, rel, exists) {
  const errors = [], warnings = []; const h = stripHtmlNoise(html);
  if (!/^\s*<!doctype html>/i.test(html)) warnings.push({ file: rel, line: 1, msg: '開頭少了 <!doctype html>（瀏覽器會用相容模式，版面可能跑掉）' });
  if (/<html\b/i.test(h) && !/<html\b[^>]*\blang=/i.test(h)) warnings.push({ file: rel, line: 1, msg: '<html> 沒有 lang（螢幕閱讀器與翻譯會猜錯語言）' });
  if (/<head\b/i.test(h)) { if (!/<meta[^>]+name=["']?viewport/i.test(h)) warnings.push({ file: rel, line: 1, msg: '沒有 <meta name="viewport">，手機上會縮成一小塊' }); if (!/<title>[^<]+<\/title>/i.test(h)) warnings.push({ file: rel, line: 1, msg: '沒有 <title>' }); if (!/<meta[^>]+charset/i.test(h)) warnings.push({ file: rel, line: 1, msg: '沒有 <meta charset="utf-8">，中文可能變亂碼' }); }
  // 標籤配對
  const stack = []; const re = /<\/?([a-zA-Z][\w-]*)\b[^>]*?(\/?)>/g; let m;
  while ((m = re.exec(h))) {
    const tag = m[1].toLowerCase(); const closing = m[0][1] === '/'; if (VOID.has(tag) || m[2] === '/' || !CHECK_TAGS.includes(tag) && !['script', 'style'].includes(tag)) continue;
    if (!closing) stack.push({ tag, i: m.index });
    else { const k = stack.map((x) => x.tag).lastIndexOf(tag); if (k < 0) { (['script', 'style'].includes(tag) ? errors : warnings).push({ file: rel, line: lineOf(h, m.index), msg: `多了一個 </${tag}>（前面沒有對應的 <${tag}>）` }); continue; } const unclosed = stack.splice(k); for (const u of unclosed.slice(1)) warnings.push({ file: rel, line: lineOf(h, u.i), msg: `<${u.tag}> 沒有關閉` }); }
  }
  for (const u of stack) (['script', 'style', 'html', 'body', 'head'].includes(u.tag) ? errors : warnings).push({ file: rel, line: lineOf(h, u.i), msg: `<${u.tag}> 沒有關閉` });
  // 重複 id
  const ids = {}; for (const x of h.matchAll(/\sid=["']([^"']+)["']/g)) ids[x[1]] = (ids[x[1]] || 0) + 1; const dup = Object.keys(ids).filter((k) => ids[k] > 1); if (dup.length) warnings.push({ file: rel, line: 0, msg: `重複的 id：${dup.slice(0, 5).join('、')}（getElementById 只會拿到第一個）` });
  // 圖片 alt
  const noAlt = [...h.matchAll(/<img\b(?![^>]*\balt=)[^>]*>/gi)].length; if (noAlt) warnings.push({ file: rel, line: 0, msg: `${noAlt} 張 <img> 沒有 alt（無障礙與 SEO）` });
  // 本機引用
  const dir = path.posix.dirname(rel);
  for (const x of h.matchAll(/\s(?:src|href)=["']([^"'#?]+)(?:[?#][^"']*)?["']/gi)) {
    const u = x[1].trim(); if (!u || /^(https?:|\/\/|data:|mailto:|tel:|javascript:|blob:|#)/i.test(u) || u.includes('${') || u.includes('{{')) continue;
    const target = u.startsWith('/') ? u.slice(1) : path.posix.normalize(path.posix.join(dir === '.' ? '' : dir, u));
    const cand = [target, target.replace(/\/$/, '') + '/index.html']; if (!cand.some((c) => exists(c))) errors.push({ file: rel, line: lineOf(h, x.index), msg: `找不到引用的檔案：${u}` });
  }
  if (/<script\b[^>]*\bsrc=["']https?:/i.test(h)) warnings.push({ file: rel, line: 0, msg: '有載入外部 CDN 的程式：沒網路時會壞掉，也要信任該來源（建議加 integrity 或改成本機檔案）' });
  return { errors, warnings };
}

class Sites {
  constructor(ctx) { this.ctx = ctx; this.server = null; this.port = 0; this.jobs = new Map(); }
  get root() { return path.join(this.ctx.paths.workspace, 'sites'); }
  get db() { const d = this.ctx.store.db; if (!Array.isArray(d.sites)) d.sites = []; return d.sites; }
  templates() { return Object.entries(TEMPLATES).map(([id, t]) => ({ id, name: t.name })); }
  list() { return this.db.map((s) => ({ ...s })).sort((a, b) => b.updated - a.updated); }
  find(idOrName) {
    const k = String(idOrName || '').trim(); if (!k) throw new Error('要指定網站（id 或名稱）');
    const s = this.db.find((x) => x.id === k) || this.db.find((x) => x.name === k) || this.db.find((x) => x.name.toLowerCase().includes(k.toLowerCase()));
    if (!s) throw new Error(`找不到網站「${k}」。現有：${this.db.map((x) => `${x.name}（${x.id}）`).join('、') || '還沒有'}`); return s;
  }
  dir(s) { return path.join(this.root, s.id); }
  full(s, rel) { const p = path.join(this.dir(s), ...cleanPath(rel).split('/')); if (!p.startsWith(this.dir(s) + path.sep)) throw new Error('路徑不合法'); return p; }
  files(s) {
    const out = []; const base = this.dir(s);
    const walk = (d) => { let ents = []; try { ents = fs.readdirSync(d, { withFileTypes: true }); } catch { return; } for (const e of ents) { const f = path.join(d, e.name); if (e.isDirectory()) { if (e.name !== 'node_modules' && e.name !== 'data') walk(f); } else { const st = fs.statSync(f); out.push({ path: path.relative(base, f).split(path.sep).join('/'), size: st.size }); } } };
    walk(base); return out.sort((a, b) => a.path.localeCompare(b.path));
  }
  touch(s) { const fl = this.files(s); s.files = fl.length; s.bytes = fl.reduce((t, f) => t + f.size, 0); s.updated = Date.now(); this.ctx.store.touch(); }
  create({ name, template = 'blank', description = '' } = {}, by = 'app') {
    const nm = String(name || '').trim().slice(0, 60) || '我的網站'; const tp = TEMPLATES[template] ? template : 'blank';
    if (this.db.length >= 60) throw new Error('網站太多了（最多 60 個），先刪掉用不到的');
    const s = { id: slug(nm), name: nm, template: tp, description: String(description || '').slice(0, 500), created: Date.now(), updated: Date.now(), files: 0, bytes: 0, by };
    fs.mkdirSync(this.dir(s), { recursive: true }); this.db.push(s);
    for (const [rel, content] of Object.entries(TEMPLATES[tp].files(nm))) { const f = this.full(s, rel); fs.mkdirSync(path.dirname(f), { recursive: true }); fs.writeFileSync(f, content); }
    this.touch(s); this.ctx.store.audit(by, 'site.create', `${s.id} ${tp}`); return s;
  }
  /** files：[{path, content, base64?}]；content===null＝刪除。一次寫完才更新統計 */
  write(idOrName, files, by = 'app') {
    const s = this.find(idOrName); if (!Array.isArray(files) || !files.length) throw new Error('files 要給 [{path, content}]'); if (files.length > 60) throw new Error('一次最多寫 60 個檔案');
    const cur = new Map(this.files(s).map((f) => [f.path, f.size])); const done = [];
    for (const it of files) {
      const rel = cleanPath(it && it.path); const f = this.full(s, rel);
      if (it.content === null || it.delete) { if (fs.existsSync(f)) { fs.unlinkSync(f); cur.delete(rel); done.push('刪除 ' + rel); } continue; }
      const bin = BIN_EXT.includes(extOf(rel)); let buf;
      if (bin) { if (!it.base64) throw new Error(`${rel} 是二進位檔，要用 base64 給內容`); buf = Buffer.from(String(it.base64), 'base64'); } else buf = Buffer.from(String(it.content == null ? '' : it.content), 'utf8');
      if (buf.length > MAXB) throw new Error(`${rel} 太大（上限 ${MAXB / 1024} KB）`);
      const existed = cur.has(rel); cur.set(rel, buf.length); if (cur.size > MAXF) throw new Error(`檔案太多（上限 ${MAXF} 個）`); if ([...cur.values()].reduce((a, b) => a + b, 0) > MAXT) throw new Error(`整個網站超過 ${MAXT / 1024 / 1024} MB`);
      fs.mkdirSync(path.dirname(f), { recursive: true }); const tmp = f + '.tmp'; fs.writeFileSync(tmp, buf); fs.renameSync(tmp, f); done.push((existed ? '寫入 ' : '新增 ') + rel);
    }
    this.touch(s); this.ctx.store.audit(by, 'site.write', `${s.id}: ${done.length} 個檔案`); return { site: s, done };
  }
  read(idOrName, rel) {
    const s = this.find(idOrName); if (!rel) return { site: s, files: this.files(s) };
    const f = this.full(s, rel); if (!fs.existsSync(f)) throw new Error(`沒有 ${rel}`); if (BIN_EXT.includes(extOf(rel))) return { site: s, path: rel, binary: true, size: fs.statSync(f).size };
    return { site: s, path: rel, content: fs.readFileSync(f, 'utf8') };
  }
  remove(idOrName, by = 'app') { const s = this.find(idOrName); fs.rmSync(this.dir(s), { recursive: true, force: true }); this.ctx.store.db.sites = this.db.filter((x) => x !== s); this.ctx.store.touch(); this.ctx.store.audit(by, 'site.delete', s.id); return { ok: true }; }
  /** 靜態檢查（不執行任何網站程式） */
  check(idOrName) {
    const s = this.find(idOrName); const fl = this.files(s); const have = new Set(fl.map((f) => f.path)); const exists = (p) => have.has(p);
    const errors = [], warnings = []; let sec = null; try { sec = require('./secaudit'); } catch { /* ignore */ }
    const entry = ['index.html', 'public/index.html'].find(exists); if (!entry) errors.push({ file: '', line: 0, msg: '沒有 index.html（打開網站時的首頁）' });
    for (const f of fl) {
      const e = extOf(f.path); if (BIN_EXT.includes(e)) continue; let txt; try { txt = fs.readFileSync(this.full(s, f.path), 'utf8'); } catch { continue; }
      if (e === 'html' || e === 'htm') { const r = checkHtml(txt, f.path, exists); errors.push(...r.errors); warnings.push(...r.warnings); for (const sc of txt.matchAll(/<script(?![^>]*\bsrc=)(?![^>]*type=["'](?:application\/(?:ld\+)?json|text\/template|importmap)["'])[^>]*>([\s\S]*?)<\/script>/gi)) { const r2 = checkJs(sc[1], f.path + '（內嵌 script）'); if (r2) errors.push({ file: f.path, line: lineOf(txt, sc.index) + Math.max(0, r2.line - 1), msg: r2.msg }); } }
      else if (['js', 'mjs', 'cjs'].includes(e)) { const r = checkJs(txt, f.path); if (r) errors.push({ file: f.path, line: r.line, msg: r.msg }); }
      else if (e === 'json' || e === 'webmanifest') { try { JSON.parse(txt); } catch (er) { errors.push({ file: f.path, line: 0, msg: 'JSON 格式錯誤：' + er.message }); } }
      else if (e === 'css') { const r = checkCss(txt); if (r) errors.push({ file: f.path, ...r }); }
      if (sec && ['js', 'mjs', 'cjs', 'html', 'htm'].includes(e)) { try { for (const x of sec.analyze(txt, { lang: e.startsWith('htm') ? 'html' : 'js' }).findings) if (['crit', 'high'].includes(x.sev)) warnings.push({ file: f.path, line: x.line || 0, msg: `資安：${x.title}（${x.cwe}）—${x.fix}` }); } catch { /* ignore */ } }
      if (/(api[_-]?key|secret|password|passwd|token)\s*[:=]\s*["'][^"'\s]{12,}["']/i.test(txt) && !/example|your[_-]|xxx|placeholder|<.*>/i.test(txt.match(/(api[_-]?key|secret|password|passwd|token)\s*[:=]\s*["'][^"'\s]{12,}["']/i)[0])) errors.push({ file: f.path, line: 0, msg: '看起來把金鑰／密碼寫死在程式裡了：前端的東西任何人都看得到，請移到後端或環境變數' });
    }
    return { site: s, ok: !errors.length, errors: errors.slice(0, 60), warnings: warnings.slice(0, 60), files: fl.length, bytes: fl.reduce((t, f) => t + f.size, 0) };
  }
  report(r) {
    const L = [`網站「${r.site.name}」（${r.site.id}）：${r.files} 個檔案、${Math.max(1, Math.round(r.bytes / 1024))} KB`];
    L.push(r.ok ? '檢查通過：沒有錯誤。' : `有 ${r.errors.length} 個錯誤要修：`); for (const e of r.errors) L.push(`  ✗ ${e.file}${e.line ? ':' + e.line : ''}　${e.msg}`);
    if (r.warnings.length) { L.push(`建議修正（${r.warnings.length}）：`); for (const w of r.warnings.slice(0, 20)) L.push(`  ・${w.file}${w.line ? ':' + w.line : ''}　${w.msg}`); }
    return L.join('\n');
  }
  /** 預覽伺服器：另一個連接埠＝另一個來源，網站裡的程式拿不到 App 的權杖；只綁 127.0.0.1 */
  async preview(idOrName) {
    const s = this.find(idOrName); await this.startPreview();
    const entry = fs.existsSync(path.join(this.dir(s), 'index.html')) ? '' : fs.existsSync(path.join(this.dir(s), 'public', 'index.html')) ? 'public/' : '';
    return { site: s, url: `http://127.0.0.1:${this.port}/${s.id}/${entry}`, port: this.port };
  }
  startPreview() {
    if (this.server) return Promise.resolve(this.port);
    const srv = http.createServer((req, res) => {
      try {
        const u = new URL(req.url, 'http://x'); const parts = decodeURIComponent(u.pathname).split('/').filter(Boolean);
        const head = { 'x-content-type-options': 'nosniff', 'cache-control': 'no-store', 'referrer-policy': 'no-referrer' };
        if (req.method !== 'GET' && req.method !== 'HEAD') { res.writeHead(405, head); return res.end('只能預覽靜態檔（後端要另外用 node server.js 跑）'); }
        const s = parts.length ? this.db.find((x) => x.id === parts[0]) : null; if (!s) { res.writeHead(404, { ...head, 'content-type': 'text/plain; charset=utf-8' }); return res.end('找不到這個網站'); }
        if (parts.length === 1 && !u.pathname.endsWith('/')) { res.writeHead(302, { ...head, location: `/${s.id}/` }); return res.end(); }
        let rel = parts.slice(1).join('/'); if (!rel || u.pathname.endsWith('/')) rel = (rel ? rel + '/' : '') + 'index.html';
        let f; try { f = this.full(s, rel); } catch { res.writeHead(400, head); return res.end('bad path'); }
        if (!fs.existsSync(f) || fs.statSync(f).isDirectory()) { res.writeHead(404, { ...head, 'content-type': 'text/plain; charset=utf-8' }); return res.end('找不到 ' + rel); }
        res.writeHead(200, { ...head, 'content-type': MIME[extOf(f)] || 'application/octet-stream' }); if (req.method === 'HEAD') return res.end(); fs.createReadStream(f).pipe(res);
      } catch (e) { try { res.writeHead(500); res.end('error'); } catch { /* ignore */ } }
    });
    const want = Number(this.ctx.settings && this.ctx.settings.get('sites.preview_port', 8767)) || 8767;
    return new Promise((resolve, reject) => {
      const go = (port, retry) => { srv.once('error', (e) => { if (retry && e.code === 'EADDRINUSE') { srv.removeAllListeners('listening'); go(0, false); } else reject(e); }); srv.listen(port, '127.0.0.1', () => { this.server = srv; this.port = srv.address().port; srv.unref(); resolve(this.port); }); };
      go(want, true);
    });
  }
  /** Anti-gravity-engine3：一句話 → 完整網站（規劃 → 逐檔撰寫 → 檢查 → 自動修錯 → 打包 → 傳回聊天室）。立刻回傳工作，背景進行。 */
  build(request, { by = 'app', reply = null } = {}) {
    const req = clip(String(request || '').trim(), 1500); if (!req) throw new Error('說說想要什麼網站，一句話就好');
    const llm = require('../llm'); if (!llm.hasKey(this.ctx.settings)) throw new Error('還沒設定 AI 模型金鑰（更多 → 模型），沒辦法自動寫網站');
    if ([...this.jobs.values()].filter((j) => j.status === 'running').length >= 2) throw new Error('已經有 2 個網站在做了，等一下再請我做');
    const job = { id: rid(8).toLowerCase(), request: req, status: 'running', stage: '分析需求', steps: [], site: null, error: '', started: Date.now(), finished: 0, by, reply };
    this.jobs.set(job.id, job); while (this.jobs.size > 12) this.jobs.delete(this.jobs.keys().next().value);
    job.promise = this.runBuild(job).catch((e) => { job.status = 'error'; job.error = clip(String(e.message || e), 300); job.finished = Date.now(); AG.deliver(this.ctx, job.reply, `網站沒做成：${job.error}`, [], '網站').catch(() => {}); });
    this.ctx.store.audit(by, 'site.build', clip(req, 80)); return job;
  }
  jobList() { return [...this.jobs.values()].reverse().map((j) => this.jobPub(j)); }
  jobPub(j) { const { promise, reply, ...rest } = j; return { ...rest, site: j.site ? { id: j.site.id, name: j.site.name, template: j.site.template } : null }; }
  async runBuild(job) {
    const step = (t) => { job.stage = t; job.steps.push({ t, at: Date.now() }); };
    // 1) 規劃
    let plan = null; try { plan = AG.json(await AG.ask(this.ctx, PLAN_SYS, `需求：${job.request}`, { maxTokens: 2048 })); } catch { plan = null; }
    if (!plan || typeof plan !== 'object') plan = {};
    const type = FILES_BY_TYPE[plan.type] ? plan.type : AG.pickTemplate(job.request);
    plan.type = type; plan.name = clip(String(plan.name || '').trim(), 30) || clip(job.request.replace(/^(幫我|請|我想要|我要|想要)?\s*(做|建|弄|寫|生成|產生)?\s*(一個|一頁|個)?/, ''), 16) || '我的網站';
    const s = this.create({ name: plan.name, template: type, description: clip(`${plan.summary || ''}｜${job.request}`, 500) }, job.by); job.site = s;
    step(`規劃完成：${plan.name}（${TEMPLATES[type].name}）`);
    const planTxt = JSON.stringify({ name: plan.name, type, summary: plan.summary, sections: plan.sections, features: plan.features, data: plan.data, style: plan.style }, null, 1);
    // 2) 逐檔撰寫（每次一個檔案，輸出長度對所有供應商都安全；後面的檔案看得到前面寫好的，id／class 才會一致）
    const done = {};
    for (const f of FILES_BY_TYPE[type]) {
      step(`撰寫 ${f}`);
      const skel = (() => { try { return fs.readFileSync(this.full(s, f), 'utf8'); } catch { return ''; } })();
      const prev = Object.entries(done).map(([k, v]) => `--- ${k} ---\n${v}`).join('\n\n');
      const user = `需求：${job.request}\n\n規劃：\n${planTxt}\n\n${prev ? `已經寫好的檔案（請和它們一致）：\n${clip(prev, 24000)}\n\n` : ''}${skel ? `參考骨架（可以大幅改寫）：\n${clip(skel, 6000)}\n\n` : ''}請輸出「${f}」的完整內容。${FILE_HINT[f] || ''}`;
      let out = AG.unfence(await AG.ask(this.ctx, FILE_SYS, user, { maxTokens: 8192 }));
      if (/\.html$/.test(f) && !/<\/html>\s*$/i.test(out.trim())) out = AG.unfence(await AG.ask(this.ctx, FILE_SYS, user + '\n上次輸出被截斷了：這次寫精簡一點，但一定要完整到 </html>。', { maxTokens: 8192 }));
      done[f] = out.replace(/\s+$/, '') + '\n'; this.write(s.id, [{ path: f, content: done[f] }], job.by);
    }
    // 3) 檢查＋自動修錯（最多 2 輪）
    let r = this.check(s.id);
    for (let round = 1; round <= 2 && !r.ok; round++) {
      step(`修正錯誤（第 ${round} 輪，${r.errors.length} 個）`);
      const byFile = {}; for (const e of r.errors) if (e.file) (byFile[e.file] = byFile[e.file] || []).push(e);
      for (const [f, errs] of Object.entries(byFile)) {
        let cur = ''; try { cur = fs.readFileSync(this.full(s, f), 'utf8'); } catch { continue; }
        const fixed = AG.unfence(await AG.ask(this.ctx, FILE_SYS, `需求：${job.request}\n\n「${f}」檢查出這些錯誤：\n${errs.map((e) => `- ${e.line ? '第 ' + e.line + ' 行：' : ''}${e.msg}`).join('\n')}\n（引用了不存在的檔案就刪掉那個引用，或改成內嵌 SVG／CSS）\n\n目前內容：\n${clip(cur, 30000)}\n\n請輸出修正後的完整「${f}」。`, { maxTokens: 8192 }));
        if (fixed.trim()) this.write(s.id, [{ path: f, content: fixed.replace(/\s+$/, '') + '\n' }], job.by);
      }
      r = this.check(s.id);
    }
    // 4) 打包、交付
    step('打包'); const rec = this.zip(s.id, job.by); const pv = await this.preview(s.id).catch(() => null);
    job.check = { ok: r.ok, errors: r.errors.length, warnings: r.warnings.length }; job.zip = { id: rec.id, name: rec.name, size: rec.size }; job.url = pv ? pv.url : '';
    job.status = 'done'; job.stage = '完成'; job.finished = Date.now(); step('完成');
    const feats = (Array.isArray(plan.features) ? plan.features : []).slice(0, 6).map((x) => '・' + clip(String(x), 40)).join('\n');
    const text = `網站「${s.name}」做好了（${TEMPLATES[type].name}，${r.files} 個檔案，${Math.round((job.finished - job.started) / 1000)} 秒）。\n${plan.summary ? clip(String(plan.summary), 120) + '\n' : ''}${feats ? feats + '\n' : ''}`
      + `檢查：${r.ok ? '沒有錯誤' : `還有 ${r.errors.length} 個錯誤沒修好（在「網站工作室」按檢查可以看）`}${r.warnings.length ? `，${r.warnings.length} 個小建議` : ''}。\n`
      + `預覽：App「更多 → 網站工作室」（${pv ? pv.url + '，只在這支手機上能開' : '打開就能看'}）。\n附上 zip：解壓後${type === 'fullstack' ? '執行 node server.js' : '直接打開 index.html，或上傳到 GitHub Pages／Netlify'}。想改哪裡直接跟我說。`;
    await AG.deliver(this.ctx, job.reply, text, [rec], '網站做好了'); return job;
  }
  stop() { if (this.server) { try { this.server.close(); } catch { /* ignore */ } this.server = null; } }
  /** 打包成 zip，放到工作區 exports/，回傳檔案紀錄（和 make_file 同格式，可以直接傳給使用者） */
  zip(idOrName, owner = '') {
    const s = this.find(idOrName); const fl = this.files(s); if (!fl.length) throw new Error('網站是空的');
    const { zip } = require('./xlsx'); const top = s.id;
    const buf = zip(fl.map((f) => [`${top}/${f.path}`, fs.readFileSync(this.full(s, f.path))]));
    const rel = `exports/${s.id}.zip`; const full = path.join(this.ctx.paths.workspace, rel); fs.mkdirSync(path.dirname(full), { recursive: true }); fs.writeFileSync(full, buf);
    const rec = { id: rid(8), name: `${s.name}.zip`.replace(/[\\/:*?"<>|]/g, '_'), path: rel, mime: 'application/zip', size: buf.length, at: Date.now(), owner };
    if (this.ctx.filegen && Array.isArray(this.ctx.filegen.list)) { this.ctx.filegen.list.push(rec); this.ctx.store.touch(); }
    return rec;
  }
}

module.exports = { Sites, TEMPLATES, cleanPath, checkJs, checkCss, checkHtml };
