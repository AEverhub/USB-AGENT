'use strict';
/** 對話裡的圖片永久保存（像 LINE 一樣往回捲還看得到）：data/chatmedia/<時間>-<隨機>.<副檔名>；超過 3000 張刪最舊的 */
const fs = require('fs');
const path = require('path');
const { rid } = require('../core/util');
const EXT = { 'image/png': 'png', 'image/jpeg': 'jpg', 'image/jpg': 'jpg', 'image/webp': 'webp', 'image/gif': 'gif' };
const MIME = { png: 'image/png', jpg: 'image/jpeg', webp: 'image/webp', gif: 'image/gif' };
const NAME = /^\d{13}-[0-9a-f]{12}\.(png|jpg|webp|gif)$/;
class ChatMedia {
  constructor(ctx) { this.ctx = ctx; this.dir = path.join(ctx.paths.data, 'chatmedia'); }
  save(img) {
    try {
      const buf = Buffer.isBuffer(img.buf) ? img.buf : Buffer.from(String(img.data || ''), 'base64'); if (!buf.length || buf.length > 15e6) return null;
      fs.mkdirSync(this.dir, { recursive: true }); const name = `${Date.now()}-${rid(6)}.${EXT[img.mime] || 'jpg'}`; fs.writeFileSync(path.join(this.dir, name), buf);
      if (Math.random() < 0.02) this.prune(); return name;
    } catch { return null; }
  }
  get(name) { if (!NAME.test(String(name || ''))) return null; const p = path.join(this.dir, name); if (!fs.existsSync(p)) return null; return { buf: fs.readFileSync(p), mime: MIME[name.split('.').pop()] }; }
  prune(max = 3000) { try { const l = fs.readdirSync(this.dir).filter((f) => NAME.test(f)).sort(); for (const f of l.slice(0, Math.max(0, l.length - max))) fs.unlinkSync(path.join(this.dir, f)); } catch { /* ignore */ } }
}
module.exports = { ChatMedia };
