'use strict';
/**
 * 26.11.3 pro2.1：用手機的位置（App 自己讀，不用 Termux）幫你導航、提示附近的公車。
 *
 *  nearby()：你附近的公車站有哪些路線、往哪裡、（有 TDX 金鑰時）幾分鐘到站；可以帶目的地，標出「能到那邊」的路線
 *  plan()  ：從你現在的位置到目的地，比較大眾運輸／開車／騎車／走路哪個快
 *
 * 資料來源（每個結果都會寫出來，不編資料）：
 *  ・公車即時到站：交通部 TDX 運輸資料流通服務（要管理員在 App 填 TDX 的 Client ID／Secret，免費申請）
 *  ・沒有 TDX 金鑰：OpenStreetMap（Overpass）上登記的站牌與路線（沒有即時到站，資料不一定完整）
 *  ・大眾運輸路線比較：Google Routes API（要管理員自己的 Google Maps 金鑰，Google 會依用量收費）；沒有就只給 Google 地圖導航連結
 *  ・開車：OSRM；走路／騎車依道路距離估算
 * 金鑰只存在設定（加密欄位、不會出現在 AI 提示或紀錄）；位置是私人資料，只回答管理員本人。
 */
const places = require('./places');

const UA = 'AgentCenter/26.11 (personal assistant app)';
async function get(url, { timeout = 15000, ...opt } = {}) {
  const r = await fetch(url, { ...opt, headers: { 'user-agent': UA, 'accept-language': 'zh-TW,zh;q=0.9', ...(opt.headers || {}) }, signal: AbortSignal.timeout(timeout) });
  const text = await r.text(); let j = null; try { j = JSON.parse(text); } catch { /* not json */ }
  if (!r.ok) { const err = new Error(`${new URL(url).host} 回應 ${r.status}`); err.status = r.status; err.body = j; throw err; }
  return j;
}
const fmtD = (m) => (m >= 1000 ? (m / 1000).toFixed(m >= 10000 ? 0 : 1) + ' 公里' : Math.round(m / 10) * 10 + ' 公尺');
const fmtT = (s) => { const m = Math.round(s / 60); return m >= 60 ? `${Math.floor(m / 60)} 小時 ${m % 60} 分` : `${Math.max(1, m)} 分鐘`; };
const norm = (s) => String(s || '').replace(/臺/g, '台').replace(/\s+/g, '').toLowerCase();

// 縣市 → TDX City 代碼
const CITY = { 台北市: 'Taipei', 新北市: 'NewTaipei', 桃園市: 'Taoyuan', 台中市: 'Taichung', 台南市: 'Tainan', 高雄市: 'Kaohsiung', 基隆市: 'Keelung', 新竹市: 'Hsinchu', 新竹縣: 'HsinchuCounty', 苗栗縣: 'MiaoliCounty', 彰化縣: 'ChanghuaCounty', 南投縣: 'NantouCounty', 雲林縣: 'YunlinCounty', 嘉義縣: 'ChiayiCounty', 嘉義市: 'Chiayi', 屏東縣: 'PingtungCounty', 宜蘭縣: 'YilanCounty', 花蓮縣: 'HualienCounty', 台東縣: 'TaitungCounty', 金門縣: 'KinmenCounty', 澎湖縣: 'PenghuCounty', 連江縣: 'LienchiangCounty' };

// 台灣的機場（航班查詢用；TDX FIDS 用 IATA 代碼）
const AIRPORT = { 桃園機場: 'TPE', 桃園: 'TPE', 松山: 'TSA', 台北: 'TSA', 小港: 'KHH', 高雄: 'KHH', 台中: 'RMQ', 清泉崗: 'RMQ', 台南: 'TNN', 嘉義: 'CYI', 花蓮: 'HUN', 台東: 'TTT', 澎湖: 'MZG', 馬公: 'MZG', 金門: 'KNH', 南竿: 'LZN', 馬祖: 'LZN', 北竿: 'MFK', 綠島: 'GNI', 蘭嶼: 'KYD', 七美: 'CMJ', 望安: 'WOT', 恆春: 'HCN' };
const AIRPORT_NAME = { TPE: '桃園', TSA: '台北松山', KHH: '高雄', RMQ: '台中', TNN: '台南', CYI: '嘉義', HUN: '花蓮', TTT: '台東', MZG: '澎湖馬公', KNH: '金門', LZN: '馬祖南竿', MFK: '馬祖北竿', GNI: '綠島', KYD: '蘭嶼', CMJ: '七美', WOT: '望安', HCN: '恆春', HKG: '香港', NRT: '東京成田', HND: '東京羽田', KIX: '大阪關西', ICN: '首爾仁川', BKK: '曼谷', SIN: '新加坡', MNL: '馬尼拉', PVG: '上海浦東', OKA: '沖繩', FUK: '福岡', CTS: '札幌', SGN: '胡志明市', HAN: '河內', CXR: '芽莊', DPS: '峇里島', LAX: '洛杉磯', SFO: '舊金山', SEA: '西雅圖', YVR: '溫哥華' };

class Transit {
  constructor(ctx) { this.ctx = ctx; this._tok = null; }
  cfg() { return { tdx_id: '', tdx_secret: '', google_maps_key: '', ...(this.ctx.settings.get('transit', {}) || {}) }; }
  hasTdx() { const c = this.cfg(); return !!(c.tdx_id && c.tdx_secret); }
  hasGoogle() { return !!this.cfg().google_maps_key; }
  state() { return { tdx: this.hasTdx(), google: this.hasGoogle(), phone: !!(this.ctx.phone && this.ctx.phone.ready()) }; }

  /** 你現在在哪（App 讀手機定位）；也可以直接給地名／座標 */
  async here(at) {
    if (at) { const g = (await places.geocode(at, 1))[0]; if (!g) throw new Error(`找不到「${at}」在哪裡`); return { lat: g.lat, lon: g.lon, name: g.name, from: 'given' }; }
    if (!this.ctx.phone || !this.ctx.phone.ready()) throw new Error('讀不到手機位置：要在 Android App 裡，並在「更多 → 手機代理」允許「位置」；或直接告訴我你在哪裡。');
    const l = await this.ctx.phone.location(false); if (!l || l.latitude == null) throw new Error('定不到手機位置');
    return { lat: +l.latitude, lon: +l.longitude, accuracy: l.accuracy, age_s: l.age_s, name: '你現在的位置', from: 'phone' };
  }
  async cityOf(p) {
    const j = await get(`https://nominatim.openstreetmap.org/reverse?format=jsonv2&zoom=10&lat=${p.lat}&lon=${p.lon}`);
    const a = (j && j.address) || {}; for (const k of [a.city, a.county, a.state]) { const c = CITY[String(k || '').replace(/臺/g, '台')]; if (c) return c; } return null;
  }

  // ---------------- TDX ----------------
  async tdxToken() {
    if (this._tok && this._tok.exp > Date.now() + 60000) return this._tok.v; const c = this.cfg();
    const body = new URLSearchParams({ grant_type: 'client_credentials', client_id: c.tdx_id, client_secret: c.tdx_secret }).toString();
    let j; try { j = await get('https://tdx.transportdata.tw/auth/realms/TDXConnect/protocol/openid-connect/token', { method: 'POST', body, headers: { 'content-type': 'application/x-www-form-urlencoded' } }); } catch (e) { throw new Error(e.status === 401 || e.status === 400 ? 'TDX 金鑰不對：請到 App「更多 → 手機代理 → 交通資料」重新填 Client ID／Secret' : 'TDX 登入失敗：' + e.message); }
    if (!j || !j.access_token) throw new Error('TDX 沒有給 access token'); this._tok = { v: j.access_token, exp: Date.now() + (+j.expires_in || 3600) * 1000 }; return this._tok.v;
  }
  async tdx(p) { const t = await this.tdxToken(); return get('https://tdx.transportdata.tw/api/basic' + p + (p.includes('?') ? '&' : '?') + '$format=JSON', { headers: { authorization: 'Bearer ' + t }, timeout: 20000 }); }
  /** TDX：附近站牌（市區公車＋公路客運）→ 到站時間 → 路線起訖 */
  async tdxNearby(p, r) {
    const city = await this.cityOf(p).catch(() => null); const sp = `$spatialFilter=${encodeURIComponent(`nearby(${p.lat},${p.lon},${r})`)}`;
    const scopes = [...(city ? [{ k: `City/${city}`, label: '市區公車' }] : []), { k: 'InterCity', label: '公路客運' }]; const out = [];
    for (const s of scopes) {
      let stops = []; try { stops = (await this.tdx(`/v2/Bus/Stop/${s.k}?${sp}&$top=40`)) || []; } catch (e) { if (/401|403/.test(e.message)) throw e; continue; }
      if (!stops.length) continue; const byUid = new Map(stops.map((x) => [x.StopUID, x]));
      const f = encodeURIComponent([...byUid.keys()].slice(0, 30).map((u) => `StopUID eq '${u}'`).join(' or '));
      let eta = []; try { eta = (await this.tdx(`/v2/Bus/EstimatedTimeOfArrival/${s.k}?$filter=${f}&$top=200`)) || []; } catch { eta = []; }
      const routes = [...new Set(eta.map((e) => e.RouteUID).filter(Boolean))]; let info = new Map();
      if (routes.length) { try { const rf = encodeURIComponent(routes.slice(0, 30).map((u) => `RouteUID eq '${u}'`).join(' or ')); for (const x of (await this.tdx(`/v2/Bus/Route/${s.k}?$filter=${rf}`)) || []) info.set(x.RouteUID, x); } catch { info = new Map(); } }
      for (const e of eta) {
        const st = byUid.get(e.StopUID) || {}; const pos = st.StopPosition || {}; const ri = info.get(e.RouteUID) || {};
        const from = ri.DepartureStopNameZh || ''; const to = ri.DestinationStopNameZh || ''; const dir = +e.Direction === 1 ? `往${from}` : `往${to}`;
        out.push({ route: (e.RouteName || {}).Zh_tw || '', kind: s.label, dir: from || to ? dir : '', from, to, stop: (e.StopName || {}).Zh_tw || (st.StopName || {}).Zh_tw || '', d: pos.PositionLat ? places.dist(p, { lat: pos.PositionLat, lon: pos.PositionLon }) : null,
          eta_s: e.EstimateTime != null ? +e.EstimateTime : null, status: +e.StopStatus || 0, next: e.NextBusTime || '', op: ri.Operators && ri.Operators[0] ? (ri.Operators[0].OperatorName || {}).Zh_tw || '' : '' });
      }
    }
    return out;
  }
  // ---------------- OpenStreetMap ----------------
  async osmNearby(p, r) {
    const q = `[out:json][timeout:20];node(around:${r},${p.lat},${p.lon})[highway=bus_stop]->.s;.s out;rel(bn.s)[route=bus];out body;`;
    const j = await get('https://overpass-api.de/api/interpreter', { method: 'POST', body: 'data=' + encodeURIComponent(q), headers: { 'content-type': 'application/x-www-form-urlencoded' }, timeout: 25000 });
    const els = (j && j.elements) || []; const stops = new Map(els.filter((e) => e.type === 'node').map((e) => [e.id, e])); const out = [];
    for (const rel of els.filter((e) => e.type === 'relation')) {
      const t = rel.tags || {}; const near = (rel.members || []).filter((m) => m.type === 'node' && stops.has(m.ref)).map((m) => stops.get(m.ref)).map((n) => ({ n, d: places.dist(p, n) })).sort((a, b) => a.d - b.d)[0];
      if (!near) continue; out.push({ route: t.ref || t.name || '', kind: t.network || t.operator || '公車', dir: t.to ? `往${t.to}` : '', from: t.from || '', to: t.to || '', via: t.via || '', name: t.name || '', stop: (near.n.tags || {}).name || '（無名站牌）', d: near.d, eta_s: null, op: t.operator || '' });
    }
    return out;
  }

  /** 附近的公車（可帶目的地：標出能到那邊的路線） */
  async nearby({ at, radius_m = 500, dest } = {}) {
    const p = await this.here(at); const r = Math.max(100, Math.min(+radius_m || 500, 1500)); const tdx = this.hasTdx();
    let list = tdx ? await this.tdxNearby(p, r) : await this.osmNearby(p, r);
    // 同一條路線同方向只留最近、最快到站的那一站
    const best = new Map(); for (const x of list) { const k = `${x.route}|${x.dir}`; const o = best.get(k); const score = (y) => (y.eta_s != null && y.eta_s >= 0 ? y.eta_s : 1e6) + (y.d || 0); if (!o || score(x) < score(o)) best.set(k, x); }
    list = [...best.values()];
    const D = dest ? String(dest).split(/[、,，/或]|\s+/).map(norm).filter(Boolean) : [];
    const hits = (x) => D.filter((d) => [x.to, x.from, x.via, x.name, x.dir].some((v) => norm(v).includes(d)));
    for (const x of list) x.hit = hits(x);
    list.sort((a, b) => (b.hit.length ? 1 : 0) - (a.hit.length ? 1 : 0) || ((a.eta_s != null && a.eta_s >= 0 ? a.eta_s : 1e6) - (b.eta_s != null && b.eta_s >= 0 ? b.eta_s : 1e6)) || (a.d || 0) - (b.d || 0));
    const where = p.from === 'phone' ? `你現在的位置（${p.lat.toFixed(5)}, ${p.lon.toFixed(5)}${p.accuracy ? `，誤差約 ${Math.round(p.accuracy)} 公尺` : ''}）` : `「${p.name}」`;
    if (!list.length) return { text: `${where}附近 ${fmtD(r)} 內${tdx ? '沒有查到公車站牌的到站資料' : '在 OpenStreetMap 上沒有登記的公車路線（地圖資料不一定完整）'}。\nGoogle 地圖看附近公車站：https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(`公車站 ${p.lat},${p.lon}`)}`, items: [], here: p };
    const etaTxt = (x) => { if (x.eta_s != null && x.eta_s >= 0) return x.eta_s < 60 ? '即將進站' : `約 ${Math.round(x.eta_s / 60)} 分鐘到站`; if (x.status === 1) return x.next ? `尚未發車（下一班 ${String(x.next).slice(11, 16)}）` : '尚未發車'; if (x.status === 3) return '末班已過'; if (x.status === 4) return '今日未營運'; if (x.status === 2) return '交管不停靠'; return tdx ? '' : '（沒有即時到站資料）'; };
    const lines = list.slice(0, 12).map((x) => `・${x.route}${x.dir ? ` ${x.dir}` : ''}｜${x.stop}${x.d != null ? ` ${fmtD(x.d)}` : ''}｜${etaTxt(x)}${x.op ? `｜${x.op}` : ''}${x.hit.length ? `｜能到：${x.hit.join('、')}` : ''}`);
    const hitN = list.filter((x) => x.hit.length).length;
    const head = `${where}附近 ${fmtD(r)} 內的公車：${D.length ? (hitN ? `（有 ${hitN} 條路線往你要去的方向，排在最前面）` : '（附近路線的起訖站沒有看到你要去的地方，可以看下面的導航連結）') : ''}`;
    const src = tdx ? '資料來源：交通部 TDX 運輸資料流通服務（即時到站）' : '資料來源：OpenStreetMap（站牌與路線，沒有即時到站；填 TDX 金鑰後可以看幾分鐘到站）';
    return { text: [head, ...lines, src].join('\n'), items: list, here: p };
  }

  // ---------------- 捷運／高鐵／台鐵／機場 ----------------
  /** OpenStreetMap 找附近的車站（半徑內）與機場（60 公里內、有 IATA 代碼的） */
  async osmStations(p, r) {
    const q = `[out:json][timeout:25];(node(around:${r},${p.lat},${p.lon})[railway~"^(station|halt)$"];nwr(around:60000,${p.lat},${p.lon})[aeroway=aerodrome][iata];);out center 80;`;
    const j = await get('https://overpass-api.de/api/interpreter', { method: 'POST', body: 'data=' + encodeURIComponent(q), headers: { 'content-type': 'application/x-www-form-urlencoded' }, timeout: 30000 });
    const seen = new Set(); const out = [];
    for (const e of (j && j.elements) || []) {
      const t = e.tags || {}; const pos = { lat: e.lat ?? (e.center || {}).lat, lon: e.lon ?? (e.center || {}).lon }; if (pos.lat == null) continue; const name = t['name:zh'] || t.name || ''; if (!name) continue;
      const all = [name, t.operator, t.network, t.station, t.subway, t.light_rail].map((x) => String(x || '')).join(' ');
      const kind = t.aeroway ? '機場' : /高鐵|高速鐵路|THSR|High Speed/i.test(all) ? '高鐵' : /捷運|metro|subway|light_rail|輕軌|MRT/i.test(all) || t.station === 'subway' || t.station === 'light_rail' ? '捷運' : '火車';
      const k = kind + norm(name).replace(/(車站|站)$/, ''); if (seen.has(k)) continue; seen.add(k);
      out.push({ kind, name, d: places.dist(p, pos), lat: pos.lat, lon: pos.lon, iata: t.iata || '', line: t.line || t['railway:ref'] || t.network || '' });
    }
    return out.sort((a, b) => a.d - b.d);
  }
  async tdxCache(key, p, ttl = 12 * 3600e3) { this._c = this._c || {}; const c = this._c[key]; if (c && Date.now() - c.at < ttl) return c.v; const v = await this.tdx(p); this._c[key] = { at: Date.now(), v }; return v; }
  /** 台鐵：車站看板（接下來的車、誤點） */
  async traBoard(name) {
    const st = await this.tdxCache('tra', '/v3/Rail/TRA/Station'); const list = (st && st.Stations) || (Array.isArray(st) ? st : []);
    const n = norm(name).replace(/(車站|站)$/, ''); const hit = list.find((x) => norm((x.StationName || {}).Zh_tw) === n) || list.find((x) => norm((x.StationName || {}).Zh_tw).startsWith(n)); if (!hit) return null;
    const b = await this.tdx(`/v3/Rail/TRA/StationLiveBoard/Station/${hit.StationID}`); const rows = (b && b.StationLiveBoards) || (Array.isArray(b) ? b : []);
    return rows.slice(0, 8).map((x) => ({ no: x.TrainNo, type: (x.TrainTypeName || {}).Zh_tw || '', to: (x.EndingStationName || {}).Zh_tw || '', time: x.ScheduleDepartureTime || x.ScheduledDepartureTime || '', delay: +x.DelayTime || 0, dir: +x.Direction === 1 ? '逆行' : '順行' }));
  }
  /** 高鐵：今天這站接下來的班次 */
  async thsrBoard(name) {
    const st = await this.tdxCache('thsr', '/v2/Rail/THSR/Station'); const n = norm(name).replace(/高鐵|(車站|站)$/g, '');
    const hit = (st || []).find((x) => norm((x.StationName || {}).Zh_tw) === n) || (st || []).find((x) => n.includes(norm((x.StationName || {}).Zh_tw))); if (!hit) return null;
    const tz = this.ctx.settings.get('tz') || 'Asia/Taipei'; const now = new Date(); const day = now.toLocaleDateString('sv-SE', { timeZone: tz }); const hm = now.toLocaleTimeString('en-GB', { timeZone: tz, hour: '2-digit', minute: '2-digit' });
    const rows = (await this.tdx(`/v2/Rail/THSR/DailyTimetable/Station/${hit.StationID}/${day}`)) || [];
    return rows.map((x) => ({ no: (x.DailyTrainInfo || {}).TrainNo || x.TrainNo, to: ((x.DailyTrainInfo || {}).EndingStationName || {}).Zh_tw || '', dir: +((x.DailyTrainInfo || {}).Direction) === 1 ? '北上' : '南下', time: x.DepartureTime || '' })).filter((x) => x.time && x.time >= hm).sort((a, b) => a.time.localeCompare(b.time)).slice(0, 8);
  }
  /** 機場：今天接下來的國內／國際出發航班 */
  async flights(iata) {
    const rows = (await this.tdx(`/v2/Air/FIDS/Airport/Departure/${iata}`)) || []; const now = Date.now();
    return rows.map((x) => ({ no: `${x.AirlineID || ''}${x.FlightNumber || ''}`, to: x.ArrivalAirportID || '', time: x.ScheduleDepartureTime || '', est: x.EstimatedDepartureTime || '', remark: x.DepartureRemark || '', terminal: x.Terminal || '', gate: x.Gate || '' }))
      .filter((x) => !x.time || Date.parse(x.time) > now - 15 * 60000).sort((a, b) => String(a.time).localeCompare(String(b.time))).slice(0, 10);
  }
  /** 附近的捷運、高鐵、火車站與機場（有 TDX 金鑰：台鐵看板、高鐵時刻、機場航班即時） */
  async stations({ at, radius_m = 3000, dest } = {}) {
    const p = await this.here(at); const r = Math.max(300, Math.min(+radius_m || 3000, 20000)); const list = await this.osmStations(p, r); const tdx = this.hasTdx();
    const D = dest ? String(dest).split(/[、,，/或]|\s+/).map(norm).filter(Boolean) : []; const destIata = D.map((d) => Object.entries(AIRPORT).find(([k]) => d.includes(norm(k)))).filter(Boolean).map((x) => x[1]);
    const pick = [...['捷運', '火車', '高鐵'].flatMap((k) => list.filter((x) => x.kind === k).slice(0, 2)), ...list.filter((x) => x.kind === '機場').slice(0, 2)];
    const lines = []; const hm = (t) => { const m = /T?(\d{2}:\d{2})/.exec(String(t || '')); return m ? m[1] : String(t || ''); };
    for (const x of pick) {
      lines.push(`・${x.kind}｜${x.name}${x.iata ? `（${x.iata}）` : ''}｜${fmtD(x.d)}${x.line && x.kind === '捷運' ? `｜${x.line}` : ''}`);
      if (!tdx) continue;
      try {
        if (x.kind === '火車') { const b = await this.traBoard(x.name); if (b && b.length) { const f = D.length ? b.filter((t) => D.some((d) => norm(t.to).includes(d))) : []; lines.push(...(f.length ? f : b).slice(0, 4).map((t) => `   ${hm(t.time)} ${t.type}${t.no}次 往${t.to}${t.delay ? `｜{紅|誤點 ${t.delay} 分}` : '｜準點'}${f.includes(t) ? '｜能到你要去的地方' : ''}`)); } }
        if (x.kind === '高鐵') { const b = await this.thsrBoard(x.name); if (b && b.length) lines.push(...b.slice(0, 4).map((t) => `   ${hm(t.time)} ${t.no}車次 ${t.dir} 往${t.to}`)); }
        if (x.kind === '機場' && x.iata) { const b = await this.flights(x.iata); const f = destIata.length ? b.filter((t) => destIata.includes(t.to)) : b; lines.push(...f.slice(0, 5).map((t) => `   ${hm(t.time)} ${t.no} 飛 ${AIRPORT_NAME[t.to] || t.to}${t.est && hm(t.est) !== hm(t.time) ? `（預計 ${hm(t.est)}）` : ''}${t.remark ? `｜${t.remark}` : ''}${t.gate ? `｜登機門 ${t.gate}` : ''}`)); if (destIata.length && !f.length) lines.push(`   今天接下來沒有直飛${D.join('、')}的班機`); }
      } catch (e) { lines.push(`   （即時資料暫時查不到：${e.message}）`); }
    }
    const where = p.from === 'phone' ? '你現在的位置' : `「${p.name}」`;
    if (!pick.length) return { text: `${where}附近 ${fmtD(r)} 內在 OpenStreetMap 上沒有登記的捷運／火車／高鐵站，60 公里內也沒有機場。\nGoogle 地圖：https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(`車站 ${p.lat},${p.lon}`)}`, items: [], here: p };
    const src = tdx ? '資料來源：OpenStreetMap（車站位置）、交通部 TDX（台鐵看板、高鐵時刻、機場航班）' : '資料來源：OpenStreetMap（車站位置；填 TDX 金鑰後可以看台鐵誤點、高鐵班次、機場航班）';
    return { text: [`${where}附近的車站與機場（直線距離）：`, ...lines, src].join('\n'), items: pick, here: p };
  }

  // ---------------- 共享單車（YouBike 等） ----------------
  async bikes({ at, radius_m = 500 } = {}) {
    const p = at && typeof at === 'object' ? at : await this.here(at); const r = Math.max(100, Math.min(+radius_m || 500, 2000)); const tdx = this.hasTdx(); let list = [];
    if (tdx) {
      const city = await this.cityOf(p).catch(() => null);
      if (city) {
        const st = (await this.tdx(`/v2/Bike/Station/City/${city}?$spatialFilter=${encodeURIComponent(`nearby(${p.lat},${p.lon},${r})`)}&$top=20`)) || [];
        let av = []; if (st.length) { try { av = (await this.tdx(`/v2/Bike/Availability/City/${city}?$filter=${encodeURIComponent(st.map((x) => `StationUID eq '${x.StationUID}'`).join(' or '))}`)) || []; } catch { av = []; } }
        const A = new Map(av.map((x) => [x.StationUID, x]));
        list = st.map((x) => { const a = A.get(x.StationUID) || {}; const pos = x.StationPosition || {}; const det = a.AvailableRentBikesDetail || {};
          return { name: String((x.StationName || {}).Zh_tw || '').replace(/^YouBike\d(\.\d)?_/, ''), sys: /YouBike2/i.test((x.StationName || {}).Zh_tw || '') || +x.ServiceType === 2 ? 'YouBike 2.0' : 'YouBike', d: pos.PositionLat ? places.dist(p, { lat: pos.PositionLat, lon: pos.PositionLon }) : null, rent: a.AvailableRentBikes, ret: a.AvailableReturnBikes, ebike: det.ElectricBikes, open: a.ServiceStatus == null || +a.ServiceStatus === 1, live: a.AvailableRentBikes != null }; });
      }
    }
    if (!list.length) {
      const q = `[out:json][timeout:20];nwr(around:${r},${p.lat},${p.lon})[amenity=bicycle_rental];out center 30;`;
      const j = await get('https://overpass-api.de/api/interpreter', { method: 'POST', body: 'data=' + encodeURIComponent(q), headers: { 'content-type': 'application/x-www-form-urlencoded' }, timeout: 25000 });
      list = ((j && j.elements) || []).map((e) => { const t = e.tags || {}; const pos = { lat: e.lat ?? (e.center || {}).lat, lon: e.lon ?? (e.center || {}).lon }; return { name: String(t['name:zh'] || t.name || '（無名站）').replace(/^YouBike\d(\.\d)?_/, ''), sys: t.network || t.brand || t.operator || '共享單車', d: pos.lat != null ? places.dist(p, pos) : null, cap: t.capacity, live: false }; });
    }
    list.sort((a, b) => (a.d ?? 1e9) - (b.d ?? 1e9)); list = list.slice(0, 8);
    const where = p.from === 'phone' ? '你現在的位置' : `「${p.name}」`;
    if (!list.length) return { text: `${where}附近 ${fmtD(r)} 內沒有查到共享單車站。`, items: [], here: p };
    const lines = list.map((x) => `・${x.sys}｜${x.name}${x.d != null ? `｜${fmtD(x.d)}` : ''}｜${x.live ? (!x.open ? '{紅|暫停營運}' : `可借 ${x.rent}${x.ebike ? `（電輔 ${x.ebike}）` : ''}｜可還 ${x.ret}`) : x.cap ? `${x.cap} 個車位（沒有即時數量）` : '（沒有即時數量）'}`);
    return { text: [`${where}附近的共享單車：`, ...lines, list.some((x) => x.live) ? '資料來源：交通部 TDX（YouBike 即時車輛數）' : '資料來源：OpenStreetMap（站點位置；填 TDX 金鑰後可以看可借／可還數量）'].join('\n'), items: list, here: p };
  }

  /** 從現在位置到目的地：哪個方式最快 */
  async plan({ to, from, modes } = {}) {
    if (!to) throw new Error('要說去哪裡'); const p = await this.here(from); const dst = (await places.geocode(to, 1))[0]; if (!dst) throw new Error(`找不到「${to}」在哪裡`);
    const o = `${p.lat},${p.lon}`; const link = (m) => `https://www.google.com/maps/dir/?api=1&origin=${o}&destination=${encodeURIComponent(to)}&travelmode=${m}`;
    const want = new Set(String(modes || 'transit,driving,scooter,bike,walking').split(/[,，|\s]+/)); const opts = []; const notes = [];
    // 道路距離（OSRM）→ 開車／機車／走路
    try {
      const j = await get(`https://router.project-osrm.org/route/v1/driving/${p.lon},${p.lat};${dst.lon},${dst.lat}?overview=false`, { timeout: 20000 }); const r = j && j.routes && j.routes[0];
      if (r) {
        if (want.has('driving')) opts.push({ mode: '開車', sec: r.duration, note: `道路 ${fmtD(r.distance)}，不含塞車`, link: link('driving') });
        if (want.has('scooter')) opts.push({ mode: '騎機車', sec: r.duration * 1.1, note: `道路 ${fmtD(r.distance)}，估算`, link: link('two-wheeler') });
        if (want.has('bike') && r.distance < 15000) { try { const bk = await this.bikes({ at: p, radius_m: 600 }); const s1 = bk.items.find((x) => !x.live || (x.open && x.rent > 0)); if (s1) opts.push({ mode: `騎共享單車（${s1.sys}）`, sec: (s1.d || 0) / 1.3 + r.distance / 4.2, note: `先走 ${fmtD(s1.d || 0)} 到「${s1.name}」${s1.live ? `（可借 ${s1.rent}）` : ''}，再騎約 ${fmtD(r.distance)}；到了記得找有空位的站還車`, link: link('bicycling') }); } catch { /* 查不到單車站就不列 */ } }
        if (want.has('walking') && r.distance < 6000) opts.push({ mode: '走路', sec: r.distance / 1.3, note: `約 ${fmtD(r.distance)}，估算`, link: link('walking') });
      }
    } catch (e) { notes.push('道路距離暫時算不出來（' + e.message + '）'); }
    // 大眾運輸
    if (want.has('transit')) {
      if (this.hasGoogle()) {
        try {
          const j = await get('https://routes.googleapis.com/directions/v2:computeRoutes', { method: 'POST', timeout: 20000, headers: { 'content-type': 'application/json', 'X-Goog-Api-Key': this.cfg().google_maps_key, 'X-Goog-FieldMask': 'routes.duration,routes.distanceMeters,routes.legs.steps.travelMode,routes.legs.steps.staticDuration,routes.legs.steps.transitDetails' },
            body: JSON.stringify({ origin: { location: { latLng: { latitude: p.lat, longitude: p.lon } } }, destination: { location: { latLng: { latitude: dst.lat, longitude: dst.lon } } }, travelMode: 'TRANSIT', computeAlternativeRoutes: true, languageCode: 'zh-TW' }) });
          for (const r of (j && j.routes) || []) {
            const steps = (r.legs || []).flatMap((l) => l.steps || []); const rides = steps.filter((s) => s.travelMode === 'TRANSIT' && s.transitDetails).map((s) => { const t = s.transitDetails; const ln = t.transitLine || {}; const sd = t.stopDetails || {}; const dep = sd.departureTime ? new Date(sd.departureTime) : null;
              return `${ln.nameShort || ln.name || '車'}（${(sd.departureStop || {}).name || ''}${dep ? ` ${String(dep.getHours()).padStart(2, '0')}:${String(dep.getMinutes()).padStart(2, '0')} 上車` : ''} → ${(sd.arrivalStop || {}).name || ''}）`; });
            opts.push({ mode: '大眾運輸', sec: parseInt(r.duration, 10) || 0, note: rides.length ? rides.join(' 轉 ') : '步行為主', link: link('transit') });
          }
        } catch (e) { notes.push('Google 大眾運輸路線查詢失敗（' + (e.status === 403 ? '金鑰沒有開 Routes API 或沒有權限' : e.message) + '）'); }
      }
      if (!opts.some((x) => x.mode === '大眾運輸')) {
        try { const n = await this.nearby({ at: from, dest: to }); const hit = n.items.filter((x) => x.hit.length).slice(0, 3); if (hit.length) notes.push('附近能直達的公車：' + hit.map((x) => `${x.route} ${x.dir}（${x.stop}${x.eta_s != null && x.eta_s >= 0 ? `，約 ${Math.max(1, Math.round(x.eta_s / 60))} 分鐘到站` : ''}）`).join('、') + `（${this.hasTdx() ? 'TDX 即時' : 'OpenStreetMap，沒有即時到站'}）`); } catch (e) { notes.push('附近公車查不到（' + e.message + '）'); }
        try { const far = places.dist(p, dst) > 60000; const st = await this.osmStations(p, far ? 15000 : 3000); const near = ['捷運', '火車', '高鐵', ...(far ? ['機場'] : [])].map((k) => st.find((x) => x.kind === k)).filter(Boolean); if (near.length) notes.push('離你最近的' + near.map((x) => `${x.kind}：${x.name}（${fmtD(x.d)}）`).join('、') + (far ? '；距離比較遠，可以考慮高鐵或飛機' : '')); } catch { /* 查不到車站不影響其他結果 */ }
        notes.push(`大眾運輸（公車、捷運、火車、高鐵）的班次與總時間看 Google 地圖（即時）：${link('transit')}${this.hasGoogle() ? '' : '（管理員填 Google Maps 金鑰後，我可以直接幫你比較每種搭法要多久）'}`);
      }
    }
    opts.sort((a, b) => a.sec - b.sec);
    const where = p.from === 'phone' ? '你現在的位置' : `「${p.name}」`;
    const lines = opts.map((x, i) => `${i === 0 ? '{綠|最快}' : `${i + 1}.`} ${x.mode}：約 ${fmtT(x.sec)}｜${x.note}\n   導航：${x.link}`);
    const src = ['OpenStreetMap＋OSRM（道路）', this.hasGoogle() ? 'Google Routes API（大眾運輸）' : null, this.hasTdx() ? '交通部 TDX（公車到站、YouBike）' : null].filter(Boolean).join('、');
    return { text: [`從${where}到「${dst.name}」（直線 ${fmtD(places.dist(p, dst))}）：`, ...lines, ...notes, '資料來源：' + src].join('\n'), options: opts, here: p, dest: dst };
  }
}
module.exports = { Transit, CITY, AIRPORT, AIRPORT_NAME };
