'use strict';
/**
 * 資料轉移（換手機用）：舊手機「下載」一個 JSON 檔 → 新手機「上傳」→ 後台自動重啟就是原本的樣子。
 *
 * 檔案內容：data/ 底下的資料（資料庫、設定、對話紀錄、向量記憶、技能、背景工人、日記…，可選照片與工作區檔案）。
 * 不帶：備份、快照、暫存、日誌、內建 Linux（太大，新手機重裝即可）、瀏覽器設定檔、這台手機專用的 token。
 *
 * 金鑰與帳密（API 金鑰、Bot token、保險箱、Google／MCP 授權）：
 *   - 沒設密碼 → 完全不放進檔案（新手機要重新貼金鑰、重新登入）
 *   - 有設密碼 → 用 scrypt＋AES-256-GCM 加密放進檔案；匯入時要輸入同一組密碼才解得開
 *   檔案本身不會出現任何明文金鑰。
 * 匯入前會把目前的資料移到 backups/pre-transfer-<時間>，出問題可以還原。
 */
const fs = require('fs');
const usbSeal = require('../core/seal');
const path = require('path');
const crypto = require('crypto');
const { logger } = require('../core/log');
const log = logger('transfer');

const FORMAT = 'agent-center-transfer'; const SCHEMA = 1;
const SKIP_DIRS = new Set(['backups', 'snapshots', 'tmp', 'logs', 'linux', 'browser-profile', 'media', 'transfer']);
const SKIP_FILE = /^(browser_host\.json|ui_token)$|\.(bak|tmp|tmpa|lock)$/;
const SECRET_FILES = new Set(['vault.json', 'vault.key', 'google-auth.json', 'google-cookie.json', 'mcp-auth.json']);
const OPTIONAL = { media: 'chatmedia', workspace: 'workspace' };
const REPLACE_DIRS = ['messages', 'skills', 'workers', 'diary', 'news', 'home'];   // 匯入時整個換掉（避免新舊混在一起）
const KEEP_DEVICE = ['linux', 'termux'];   // 這台手機自己的設定（內建 Linux 路徑、Termux 連線）不被舊手機蓋掉
const TEXT = /\.(json|jsonl|md|txt|csv|js|mjs|cjs|py|sh|html|css|xml|yaml|yml|ini|log)$/i;
const ID = /^[a-z0-9-]{8,64}$/;

function kdf(password, salt) { return crypto.scryptSync(String(password), salt, 32, { N: 16384, r: 8, p: 1, maxmem: 64 * 1024 * 1024 }); }
function seal(obj, password) {
  const salt = crypto.randomBytes(16); const iv = crypto.randomBytes(12); const c = crypto.createCipheriv('aes-256-gcm', kdf(password, salt), iv);
  const data = Buffer.concat([c.update(JSON.stringify(obj), 'utf8'), c.final()]);
  return { alg: 'aes-256-gcm', kdf: 'scrypt-16384-8-1', salt: salt.toString('base64'), iv: iv.toString('base64'), tag: c.getAuthTag().toString('base64'), data: data.toString('base64') };
}
function open(box, password) {
  try {
    const d = crypto.createDecipheriv('aes-256-gcm', kdf(password, Buffer.from(box.salt, 'base64')), Buffer.from(box.iv, 'base64')); d.setAuthTag(Buffer.from(box.tag, 'base64'));
    return JSON.parse(Buffer.concat([d.update(Buffer.from(box.data, 'base64')), d.final()]).toString('utf8'));
  } catch { throw new Error('密碼不對（或檔案損壞），解不開金鑰。可以不填密碼，只轉移金鑰以外的資料。'); }
}
/** 把設定裡的機密值抽出來（回傳 {路徑: 值}），並在副本裡清空 */
function splitSecrets(obj, isSecret, pre = '', out = {}) {
  for (const [k, v] of Object.entries(obj || {})) {
    const p = pre ? pre + '.' + k : k;
    if (isSecret(p)) { if (v && (typeof v !== 'object' || Object.keys(v).length)) out[p] = v; obj[k] = Array.isArray(v) ? [] : v && typeof v === 'object' ? {} : ''; }
    else if (v && typeof v === 'object' && !Array.isArray(v)) splitSecrets(v, isSecret, p, out);
  }
  return out;
}
function setPath(o, p, v) { const ks = p.split('.'); let x = o; for (const k of ks.slice(0, -1)) { if (!x[k] || typeof x[k] !== 'object') x[k] = {}; x = x[k]; } x[ks[ks.length - 1]] = v; }
const human = (n) => (n > 1048576 ? (n / 1048576).toFixed(1) + ' MB' : Math.max(1, Math.round(n / 1024)) + ' KB');

class Transfer {
  constructor(ctx) { this.ctx = ctx; this.dir = path.join(ctx.paths.tmp, 'transfer'); this.restart = () => setTimeout(() => process.exit(75), 900); }
  get data() { return this.ctx.paths.data; }

  /** 列出要轉移的檔案 */
  files({ media = true, workspace = true } = {}) {
    const out = []; const root = this.data; const skip = new Set(SKIP_DIRS);
    if (!media) skip.add(OPTIONAL.media); if (!workspace) skip.add(OPTIONAL.workspace);
    const walk = (dir, rel) => {
      let list = []; try { list = fs.readdirSync(dir, { withFileTypes: true }); } catch { return; }
      for (const e of list) {
        const r = rel ? rel + '/' + e.name : e.name; const abs = path.join(dir, e.name);
        if (e.isDirectory()) { if (!rel && skip.has(e.name)) continue; walk(abs, r); continue; }
        if (!e.isFile() || SKIP_FILE.test(e.name)) continue;
        let size = 0; try { size = fs.statSync(abs).size; } catch { continue; }
        out.push({ rel: r, abs, size, secret: !rel && SECRET_FILES.has(e.name) });
      }
    };
    walk(root, ''); return out;
  }
  summary(opt) {
    try { this.ctx.store._dirty = true; this.ctx.store.flush(); } catch { /* ignore */ }
    const f = this.files(opt); const by = {}; for (const x of f) { const k = x.secret ? '金鑰與授權' : x.rel.includes('/') ? x.rel.split('/')[0] : x.rel; by[k] = (by[k] || 0) + x.size; }
    const db = this.ctx.store.db || {};
    return { files: f.length, bytes: f.reduce((s, x) => s + x.size, 0), size: human(f.reduce((s, x) => s + x.size, 0)), parts: Object.entries(by).sort((a, b) => b[1] - a[1]).map(([k, v]) => ({ name: k, size: human(v) })),
      counts: { users: Object.keys(db.persons || {}).length, ledger: (db.ledger || []).length, memories: (this.ctx.store.vec || []).length, chats: f.filter((x) => x.rel.startsWith('messages/')).length } };
  }

  /** 產生轉移檔（串流寫入，不把整包放進記憶體） */
  async export({ password = '', media = true, workspace = true, maxMB = 400 } = {}) {
    if (password && String(password).length < 6) throw new Error('密碼至少 6 個字');
    const { store, settings } = this.ctx; store._dirty = true; store.flush(); settings.save();
    const list = this.files({ media, workspace }); const total = list.reduce((s, x) => s + x.size, 0);
    if (total > maxMB * 1048576) throw new Error(`資料共 ${human(total)}，超過 ${maxMB} MB。請取消「照片」或「工作區檔案」再試。`);
    fs.mkdirSync(this.dir, { recursive: true }); this._clean();
    const id = `${Date.now().toString(36)}-${crypto.randomBytes(4).toString('hex')}`; const file = path.join(this.dir, id + '.json');
    const ws = fs.createWriteStream(file); const w = (s) => new Promise((ok, bad) => { if (ws.write(s)) ok(); else ws.once('drain', ok); ws.once('error', bad); });
    const Settings = settings.constructor; const secrets = { settings: {}, files: {} }; const summary = this.summary({ media, workspace });
    try {
      const head = { format: FORMAT, schema: SCHEMA, app_version: Settings.VERSION || require('../core/settings').VERSION, created: new Date().toISOString(), options: { media, workspace, secrets: !!password }, summary };
      await w(JSON.stringify(head).slice(0, -1) + ',"files":{'); let first = true;
      for (const f of list) {
        let entry;
        if (f.secret) { if (password) { let b = fs.readFileSync(f.abs); const t = b.toString('utf8'); if (usbSeal.isSealed(t.trim())) b = Buffer.from(usbSeal.unwrap(t.trim()), 'utf8'); secrets.files[f.rel] = b.toString('base64'); } continue; }   // USB 密碼封存的檔案先解開，換到別台才讀得到
        if (f.rel === 'settings.json') { const s0 = JSON.parse(fs.readFileSync(f.abs, 'utf8')); const s = Settings._unseal ? Settings._unseal(s0) : s0; secrets.settings = splitSecrets(s, (p) => Settings.isSecret(p)); entry = { enc: 'json', data: s }; }
        else { const b = fs.readFileSync(f.abs); entry = TEXT.test(f.rel) && !b.includes(0) ? { enc: 'utf8', data: b.toString('utf8') } : { enc: 'base64', data: b.toString('base64') }; }
        await w((first ? '' : ',') + JSON.stringify(f.rel) + ':' + JSON.stringify(entry)); first = false;
        await new Promise((r) => setImmediate(r));   // 不卡事件迴圈
      }
      await w('},"secrets":' + JSON.stringify(password ? seal(secrets, password) : null) + '}');
      await new Promise((ok, bad) => ws.end((e) => (e ? bad(e) : ok())));
    } catch (e) { ws.destroy(); try { fs.unlinkSync(file); } catch { /* ignore */ } throw e; }
    const d = new Date(); const p2 = (n) => String(n).padStart(2, '0');
    const name = `Agent中控中心-轉移-${d.getFullYear()}${p2(d.getMonth() + 1)}${p2(d.getDate())}-${p2(d.getHours())}${p2(d.getMinutes())}.json`;
    this.ctx.store.audit('app', 'transfer_export', `${summary.size}${password ? '（含加密金鑰）' : '（不含金鑰）'}`);
    log.info(`匯出轉移檔 ${human(fs.statSync(file).size)}`);
    return { id, name, size: fs.statSync(file).size, size_text: human(fs.statSync(file).size), secrets: !!password, summary };
  }
  path(id) { if (!ID.test(String(id))) throw new Error('檔案編號不對'); const f = path.join(this.dir, id + '.json'); if (!fs.existsSync(f)) throw new Error('檔案已過期，請重新產生'); return f; }
  _clean() { try { for (const f of fs.readdirSync(this.dir)) { const p = path.join(this.dir, f); if (Date.now() - fs.statSync(p).mtimeMs > 3600e3) fs.unlinkSync(p); } } catch { /* ignore */ } }

  /** 上傳：直接把請求本體串流存成檔案（可能上百 MB，不經過一般 5MB 的限制） */
  receive(req, limit = 600 * 1048576) {
    fs.mkdirSync(this.dir, { recursive: true }); this._clean();
    const id = `up-${Date.now().toString(36)}-${crypto.randomBytes(4).toString('hex')}`; const file = path.join(this.dir, id + '.json');
    return new Promise((resolve, reject) => {
      const ws = fs.createWriteStream(file); let n = 0;
      req.on('data', (d) => { n += d.length; if (n > limit) { req.destroy(); ws.destroy(); try { fs.unlinkSync(file); } catch { /* ignore */ } reject(new Error('檔案太大')); } });
      req.pipe(ws); ws.on('finish', () => resolve(id)); ws.on('error', reject); req.on('error', reject);
    });
  }
  _read(id) {
    let j; try { j = JSON.parse(fs.readFileSync(this.path(id), 'utf8')); } catch (e) { if (/過期|編號/.test(e.message)) throw e; throw new Error('不是有效的 JSON 檔'); }
    if (!j || j.format !== FORMAT) throw new Error('這不是 Agent中控中心 的轉移檔');
    if (+j.schema > SCHEMA) throw new Error('這個轉移檔是用比較新的版本做的，請先把這台的 App 更新'); if (!j.files || typeof j.files !== 'object') throw new Error('轉移檔內容不完整');
    return j;
  }
  /** 匯入前預覽：從哪個版本、什麼時候、有什麼 */
  preview(id) {
    const j = this._read(id); const names = Object.keys(j.files);
    return { id, app_version: j.app_version, created: j.created, summary: j.summary || null, files: names.length, has_secrets: !!j.secrets, options: j.options || {},
      chats: names.filter((n) => n.startsWith('messages/')).length, media: names.filter((n) => n.startsWith('chatmedia/')).length, workspace: names.filter((n) => n.startsWith('workspace/')).length };
  }
  _safe(rel) {
    const r = String(rel).replace(/\\/g, '/'); if (!r || r.startsWith('/') || r.split('/').some((s) => s === '..' || s === '' || s === '.')) return null;
    const top = r.split('/')[0]; if (SKIP_DIRS.has(top) || SKIP_FILE.test(path.basename(r))) return null;
    const abs = path.resolve(this.data, r); if (!abs.startsWith(path.resolve(this.data) + path.sep)) return null; return abs;
  }

  /** 匯入：備份目前資料 → 寫入 → 重啟後台 */
  async import(id, { password = '' } = {}) {
    const j = this._read(id); let sec = null;
    if (j.secrets && password) sec = open(j.secrets, password);
    const { store, settings } = this.ctx; store.flush(); settings.save();
    // 1. 備份：目前的資料搬到 backups/pre-transfer-<時間>（搬移很快，不用複製）
    const bk = path.join(this.ctx.paths.backups, 'pre-transfer-' + Date.now()); fs.mkdirSync(bk, { recursive: true });
    const incomingTop = new Set(Object.keys(j.files).map((r) => r.split('/')[0]));
    for (const d of [...REPLACE_DIRS, ...Object.values(OPTIONAL)]) if (incomingTop.has(d) && fs.existsSync(path.join(this.data, d))) fs.renameSync(path.join(this.data, d), path.join(bk, d));
    for (const f of fs.readdirSync(this.data)) { const p = path.join(this.data, f); if (fs.statSync(p).isFile() && !SKIP_FILE.test(f)) fs.copyFileSync(p, path.join(bk, f)); }
    // 2. 不再讓記憶體裡的舊資料寫回去（否則重啟前會把匯入的檔案蓋掉）
    store.frozen = true; settings.frozen = true;
    // 3. 寫入
    let n = 0; const curSettings = JSON.parse(JSON.stringify(settings.data));
    for (const [rel, e] of Object.entries(j.files)) {
      const abs = this._safe(rel); if (!abs || !e) continue; fs.mkdirSync(path.dirname(abs), { recursive: true });
      if (rel === 'settings.json') {
        const s = e.enc === 'json' ? e.data : JSON.parse(String(e.data));
        if (sec) for (const [p, v] of Object.entries(sec.settings || {})) setPath(s, p, v);
        else { const Settings = settings.constructor; for (const [p, v] of Object.entries(splitSecrets(JSON.parse(JSON.stringify(curSettings)), (x) => Settings.isSecret(x)))) setPath(s, p, v); }   // 沒解金鑰 → 保留這台原本的金鑰
        for (const k of KEEP_DEVICE) if (curSettings[k] !== undefined) s[k] = curSettings[k];
        fs.writeFileSync(abs, JSON.stringify(s, null, 1)); n++; continue;
      }
      fs.writeFileSync(abs, e.enc === 'base64' ? Buffer.from(String(e.data), 'base64') : e.enc === 'json' ? JSON.stringify(e.data) : String(e.data)); n++;
    }
    if (sec) for (const [rel, b64] of Object.entries(sec.files || {})) { if (!SECRET_FILES.has(rel)) continue; fs.writeFileSync(path.join(this.data, rel), Buffer.from(b64, 'base64'), { mode: 0o600 }); n++; }
    try { fs.unlinkSync(this.path(id)); } catch { /* ignore */ }
    fs.appendFileSync(path.join(this.ctx.paths.logs, 'transfer.log'), `${new Date().toISOString()} 匯入 ${n} 個檔案（來源 ${j.app_version}，${j.created}）${sec ? '含金鑰' : '不含金鑰'}，備份在 ${bk}\n`);
    log.warn(`已匯入轉移檔：${n} 個檔案，後台即將重啟`);
    this.restart();
    return { ok: true, files: n, secrets: !!sec, secrets_skipped: !!j.secrets && !sec, backup: path.relative(this.data, bk), restarting: true };
  }
}
module.exports = { Transfer, FORMAT, splitSecrets };
