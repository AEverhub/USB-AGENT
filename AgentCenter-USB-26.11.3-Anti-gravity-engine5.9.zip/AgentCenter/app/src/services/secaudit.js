'use strict';
/**
 * 26.11.3 pro9 資安稽核引擎（只做「防禦」：找出自己程式／設定裡的弱點，並給修法）
 *  ・analyze(code, {lang})：靜態掃描程式碼／設定，找常見弱點類型（紅隊視角：攻擊者會盯哪裡），每一條附 CWE、嚴重度、為什麼、怎麼修（綠隊視角）
 *  ・assess(desc)：給一段「系統描述」（例：Node + Express + MySQL 的 API，JWT 登入，部署在 VPS），產生紅隊檢查清單＋綠隊強化清單
 *  ・maskSecrets()：任何輸出都先遮罩掉像金鑰／密碼的字串，絕不把祕密原文留在報告或紀錄裡
 * 這支檔案不產生任何攻擊程式、exploit、payload；它只「指出問題＋給修法」。要攻擊第三方系統的要求一律不做。
 * 注意：nodejs-mobile 沒有完整 ICU，所有正則都不用 Unicode 屬性類別。
 */

const SEV = { high: ['高', 3], med: ['中', 2], low: ['低', 1], info: ['提醒', 0] };
const clip = (s, n = 200) => { s = String(s == null ? '' : s); return s.length > n ? s.slice(0, n) + '…' : s; };

/** 把看起來像祕密的東西遮掉（金鑰、token、密碼、私鑰、長的 hex／base64） */
function maskSecrets(text) {
  let s = String(text == null ? '' : text);
  // 1) key = "...." 形式：把引號內容遮掉
  s = s.replace(/((?:pass(?:word|wd)?|pwd|\bpw|secret|api[_-]?key|apikey|access[_-]?key|client[_-]?secret|token|auth|bearer|private[_-]?key)\s*[:=]\s*)(["'`])([^"'`\n]{4,})\2/gi,
    (m, pre, q, val) => pre + q + val.slice(0, 2) + '***(已遮罩 ' + val.length + ' 字)' + q);
  // 2) 已知前綴的金鑰
  s = s.replace(/\b(sk-|ghp_|gho_|github_pat_|xox[baprs]-|AIza|AKIA|ASIA|ya29\.|glpat-)[A-Za-z0-9_\-]{6,}/g, (m, p) => p + '***(已遮罩)');
  // 3) 私鑰區塊
  s = s.replace(/-----BEGIN [A-Z ]*PRIVATE KEY-----[\s\S]*?-----END [A-Z ]*PRIVATE KEY-----/g, '-----BEGIN PRIVATE KEY-----***(已遮罩)-----END PRIVATE KEY-----');
  // 4) 落單的長 token（32+ 字、同時含字母與數字，像隨機字串）
  s = s.replace(/\b(?=[A-Za-z0-9_\-]*[A-Za-z])(?=[A-Za-z0-9_\-]*[0-9])[A-Za-z0-9_\-]{32,}\b/g, (m) => m.slice(0, 4) + '***(已遮罩 ' + m.length + ' 字)');
  return s;
}

const JS = ['js', 'javascript', 'ts', 'typescript', 'node', 'jsx', 'tsx'];
const PY = ['py', 'python'];
const anyLang = null;

/**
 * 規則：id、嚴重度、cwe、標題、langs（null＝不限）、re（可陣列）、skip（這行有就跳過，減少誤判）、why、fix
 * re 以「每一行」測試（flags 不含 g）；多行規則用 multiline:true 對整份測。
 */
const RULES = [
  { id: 'hardcoded-secret', sev: 'high', cwe: 'CWE-798', title: '把密碼／金鑰寫死在程式裡',
    re: /(pass(?:word|wd)?|pwd|\bpw|secret|api[_-]?key|apikey|access[_-]?key|client[_-]?secret|token|private[_-]?key)\s*[:=]\s*["'`][^"'`\n]{5,}["'`]/i,
    skip: /process\.env|os\.getenv|getenv|System\.getenv|<[^>]+>|\{\{|\$\{|example|placeholder|dummy|xxxx|changeme|your[_-]?|\*\*\*|\.\.\./i,
    why: '原始碼會進版控、備份、容器映像，寫死的祕密等於公開；外洩後可直接被拿去登入。', fix: '改從環境變數或祕密管理（.env＋gitignore、Vault、雲端 Secret Manager）讀取；已外洩的金鑰立刻輪替。' },

  { id: 'sql-injection', sev: 'high', cwe: 'CWE-89', title: 'SQL 指令用字串拼接（SQL Injection）',
    re: [/(SELECT|INSERT|UPDATE|DELETE|FROM|WHERE)\b[^;'"\n]*["'`]\s*\+/i, /(query|execute|exec|rawQuery|prepare)\s*\(\s*["'`][^"'`]*(SELECT|INSERT|UPDATE|DELETE)[^"'`]*\$\{/i, /(SELECT|INSERT|UPDATE|DELETE)[^;\n]*%\s*\(?[\w'"]/i, /\.format\([^)]*\)[^;\n]*(FROM|WHERE|VALUES)/i],
    skip: /\?\s*[,)]|:\w+|@\w+|\$\d|placeholder|params\s*=|prepared/i,
    why: '把使用者輸入直接接進 SQL，攻擊者可改寫查詢、讀走整個資料庫或繞過登入。', fix: '一律用參數化查詢／預備語句（prepared statement）：值用 ?、:name、$1 綁定，不要字串相加；或用 ORM 的參數化介面。' },

  { id: 'command-injection', sev: 'high', cwe: 'CWE-78', title: 'Shell 指令帶入變數（Command Injection）',
    re: [/(exec|execSync|spawnSync|os\.system|subprocess\.(?:call|run|Popen)|popen|shell_exec|passthru|child_process\.\w+)\s*\([^)]*(\+|\$\{|`[^`]*\$\{|%\s|\.format\()/i, /shell\s*=\s*True/i, /\bsystem\(\s*["'`][^"'`]*\$/i],
    skip: /\[[^\]]*\]|execFile|args\s*[:=]\s*\[/i,
    why: '把輸入拼進 shell 指令，攻擊者用 ; | && $() 就能執行任意系統指令。', fix: '不要經過 shell：用參數陣列呼叫（execFile／spawn(cmd, [args])、subprocess.run([...], shell=False）；真的要過 shell 就嚴格允許清單＋跳脫。' },

  { id: 'weak-hash', sev: 'med', cwe: 'CWE-327', title: '用脆弱的雜湊／加密演算法',
    re: [/\b(md5|sha1|md4|des|rc4|blowfish)\b/i, /AES[^;\n]*ECB|["'`]ECB["'`]|MODE_ECB/i],
    skip: /sha1[0-9]|checksum|etag|cache|non[_-]?crypto|git|content[_-]?hash/i,
    why: 'MD5／SHA-1 可被碰撞、ECB 會洩漏明文樣式；拿來存密碼或保護機密已不安全。', fix: '密碼用 bcrypt／argon2／scrypt（加鹽）；一般雜湊用 SHA-256 以上；對稱加密用 AES-GCM 這類帶驗證的模式。' },

  { id: 'insecure-random', sev: 'med', cwe: 'CWE-338', title: '用非密碼學亂數產生機密',
    re: [/Math\.random\s*\(/i, /\brandom\.(random|randint|choice|randrange)\s*\(/i, /\bnew Random\s*\(/i],
    needCtx: /token|password|passwd|otp|secret|session|nonce|salt|csrf|reset|api[_-]?key|verify|驗證碼|金鑰|密碼/i,
    why: 'Math.random／一般 random 可被預測，拿來做 token／驗證碼／session 會被猜中。', fix: '安全隨機用 crypto.randomBytes／crypto.getRandomValues（JS）、secrets 模組（Python）、SecureRandom（Java）。' },

  { id: 'xss', sev: 'high', cwe: 'CWE-79', title: '把資料直接塞進 HTML（XSS）',
    re: [/\.innerHTML\s*=|\.outerHTML\s*=|document\.write\s*\(|insertAdjacentHTML\s*\(/i, /dangerouslySetInnerHTML|v-html|\{\{\{/i],
    skip: /textContent|innerText|DOMPurify|sanitize|escape|\.innerHTML\s*=\s*["'`]\s*["'`]|=\s*["'`][^${}<]*["'`]\s*;?\s*$/i,
    why: '把未跳脫的資料放進 HTML，攻擊者可注入 <script> 偷 cookie、冒用操作。', fix: '輸出用 textContent／框架自動跳脫；一定要放 HTML 先用 DOMPurify 之類淨化；再加 CSP 當第二道防線。' },

  { id: 'dynamic-eval', sev: 'high', cwe: 'CWE-95', title: '動態執行字串（eval／new Function）',
    re: [/\beval\s*\(/i, /new Function\s*\(/i, /\bexec\s*\(\s*[^)'"`]*(input|req|request|argv|params|query)/i, /set(?:Timeout|Interval)\s*\(\s*["'`]/i],
    skip: /\/\/|eval\s*\(\s*["'`][^)]*["'`]\s*\)/i,
    why: 'eval／new Function 會執行傳進來的字串，含使用者輸入就等於讓對方跑你的程式。', fix: '不要用 eval；要動態分派改用對照表（物件／switch）；解析資料用 JSON.parse。' },

  { id: 'unsafe-deserialize', sev: 'high', cwe: 'CWE-502', title: '不安全的反序列化',
    re: [/pickle\.loads?\s*\(|cPickle\.loads?\s*\(/i, /yaml\.load\s*\((?![^)]*Safe)/i, /unserialize\s*\(|Marshal\.load\s*\(|ObjectInputStream/i],
    skip: /SafeLoader|safe_load|Loader\s*=\s*yaml\.Safe/i,
    why: '反序列化不受信任的資料（pickle、yaml.load、unserialize）可被構造成任意程式執行。', fix: 'yaml 用 safe_load；跨程序資料用 JSON；真要物件序列化就簽章＋白名單類別。' },

  { id: 'path-traversal', sev: 'med', cwe: 'CWE-22', title: '檔案路徑帶入使用者輸入（路徑穿越）',
    re: /(readFile|readFileSync|createReadStream|sendFile|open|fopen|file_get_contents|include|require)\s*\([^)]*(req\.|request\.|params|query|body|input|argv|userInput|\$_(GET|POST|REQUEST))/i,
    skip: /path\.(resolve|normalize|basename)|startsWith|realpath|allow|白名單/i,
    why: '把輸入接進檔案路徑，攻擊者用 ../ 讀到 /etc/passwd、設定檔或別人的檔案。', fix: '用 path.basename 去掉目錄、或 resolve 後檢查有沒有在允許的根目錄底下（startsWith）；最好用白名單對照。' },

  { id: 'ssrf', sev: 'med', cwe: 'CWE-918', title: '對使用者給的網址發請求（SSRF）',
    re: /(?:fetch|axios|got|request|urllib\.\w+|HttpClient|curl_exec|(?:requests|http|https|session|client)\.(?:get|post|put|request|urlopen))(?:\.\w+)?\s*\([^)]*(?:req\.|request\.|params|query|body|input|target|userUrl|url\s*[,)])/i,
    skip: /allow|白名單|allowlist|new URL[^)]*host|isPrivate|127\.0\.0\.1/i,
    why: '讓伺服器去連使用者給的網址，可被導向內網服務、雲端 metadata（169.254.169.254）竊取憑證。', fix: '限制可連的網域（白名單）、擋掉內網／保留 IP、禁跟隨跳轉到內網、對 metadata 位址拒絕。' },

  { id: 'tls-disabled', sev: 'high', cwe: 'CWE-295', title: '關掉 TLS／憑證驗證',
    re: /rejectUnauthorized\s*:\s*false|NODE_TLS_REJECT_UNAUTHORIZED\s*=\s*['"]?0|verify\s*=\s*False|InsecureSkipVerify\s*:\s*true|CURLOPT_SSL_VERIFYPEER[^;\n]*(0|false)|check_hostname\s*=\s*False|ssl\._create_unverified/i,
    why: '關掉憑證驗證＝接受任何憑證，攻擊者可中間人（MITM）攔截、竄改你的連線。', fix: '保持驗證開啟；自簽憑證就把 CA 加進信任清單，不要整個關掉驗證。' },

  { id: 'cors-wildcard', sev: 'med', cwe: 'CWE-942', title: 'CORS 全開（*）',
    re: /Access-Control-Allow-Origin["'`\s:,]+\*|cors\s*\(\s*\{[^}]*origin\s*:\s*["'`]\*|origin\s*:\s*true[^}]*credentials\s*:\s*true/i,
    skip: /公開|public api|static|cdn/i,
    why: '允許任何網站帶憑證呼叫你的 API，會洩漏使用者資料、被跨站操作。', fix: '明確列出允許的來源網域；要帶 cookie（credentials）時絕不能用 *。' },

  { id: 'debug-on', sev: 'med', cwe: 'CWE-489', title: '正式環境開著除錯模式',
    re: /debug\s*=\s*True|app\.run\([^)]*debug\s*=\s*True|DEBUG\s*[:=]\s*true|FLASK_DEBUG\s*=\s*1|display_errors\s*=\s*On/i,
    skip: /if |env|development|local|process\.env|settings\.DEBUG\s*=\s*\(/i,
    why: '除錯模式會噴出堆疊、原始碼、設定，Flask 的 debug 甚至開放互動式執行，等於後門。', fix: '正式環境關掉 debug；用環境變數控制，預設關。' },

  { id: 'log-secret', sev: 'med', cwe: 'CWE-532', title: '把密碼／金鑰寫進 log',
    re: /(console\.(log|info|debug|error)|print|printf|System\.out|logger?\.\w+|logging\.\w+)\s*\([^)]*(password|passwd|pwd|secret|token|api[_-]?key|private[_-]?key|authorization)/i,
    skip: /mask|redact|\*\*\*|遮罩|has(Password|Token)|length|!=|===|==\s/i,
    why: '把祕密印到 log，log 會被收集、備份、給人看，等於多一個外洩點。', fix: '不要記祕密；需要時只記「有沒有／長度／前幾碼」，或先遮罩。' },

  { id: 'open-redirect', sev: 'low', cwe: 'CWE-601', title: '轉址目標來自使用者輸入（Open Redirect）',
    re: /(res\.redirect|sendRedirect|location\s*=|Location["'`\s:]+)\s*[(=]?\s*[^;)\n]*(req\.|request\.|params|query|body|\$_(GET|POST|REQUEST))/i,
    skip: /allow|白名單|startsWith\(["'`]\/|new URL[^)]*host/i,
    why: '把使用者帶到他指定的網址，常被用在釣魚：連結看起來是你的網站，卻跳到假站。', fix: '只允許站內相對路徑，或用允許清單核對外部網域。' },

  { id: 'jwt-weak', sev: 'med', cwe: 'CWE-347', title: 'JWT 設定不安全',
    re: /alg["'`\s:]+none|algorithm[s]?["'`\s:]+\[?\s*["'`]none|jwt\.verify\s*\([^)]*\)(?![^;]*algorithms)/i,
    skip: /algorithms\s*:\s*\[["'`](HS|RS|ES)/i,
    why: 'alg=none 等於不驗章；不指定允許演算法可被降級攻擊，攻擊者自簽 token 冒用任何人。', fix: '明確指定 algorithms（如 ["HS256"] 或 ["RS256"]）、拒絕 none；密鑰夠長且不寫死。' },

  { id: 'xxe', sev: 'med', cwe: 'CWE-611', title: 'XML 解析沒關外部實體（XXE）',
    re: /(DocumentBuilderFactory|SAXParser|XMLReader|libxml_|etree\.parse|lxml)/i,
    needCtx: /parse|external|entity|dtd|resolveEntity/i,
    skip: /disallow-doctype|FEATURE_SECURE|resolve_entities\s*=\s*False|defusedxml|no_network/i,
    why: 'XML 若允許外部實體，攻擊者可用 XXE 讀伺服器檔案、打內網（SSRF）。', fix: '關閉 DTD／外部實體（Java 設 disallow-doctype-decl；Python 用 defusedxml）。' },

  { id: 'ssti', sev: 'high', cwe: 'CWE-1336', title: '樣板引擎帶入使用者輸入（樣板注入 SSTI）',
    re: [/render_template_string\s*\([^)]*(\+|%|\.format\(|f["'`]|req\.|request\.|params|input)/i, /(Template|Environment\(\)\.from_string|Handlebars\.compile|new Function)\s*\([^)]*(req\.|request\.|params|body|input|\+)/i],
    skip: /autoescape\s*=\s*True|["'`][^"'`{]*["'`]\s*\)/i,
    why: '把輸入拼進樣板字串，攻擊者可用樣板語法執行伺服器端程式（Jinja2、Handlebars 等）甚至拿到系統權限。', fix: '樣板檔固定、只把資料當「變數」傳入；不要用使用者內容組樣板字串；開啟 autoescape。' },

  { id: 'zip-slip', sev: 'med', cwe: 'CWE-22', title: '解壓縮沒檢查路徑（Zip Slip）',
    re: [/\.(extractall|extract)\s*\(/i, /(ZipInputStream|getNextEntry|TarArchiveInputStream)/i, /unzip|tar\s+-?x/i],
    needCtx: /zip|tar|archive|entry|解壓|壓縮檔/i,
    skip: /realpath|startsWith|normalize|resolve\([^)]*\)\.startsWith|is_within|safe_extract|members\s*=/i,
    why: '壓縮檔裡的檔名若含 ../，解壓時會寫到預期目錄外，覆蓋系統或程式檔案。', fix: '解壓每個項目前，先把目標路徑 resolve 後確認仍在允許目錄內（startsWith）再寫；用有防護的解壓函式。' },

  { id: 'over-permissive-file', sev: 'med', cwe: 'CWE-732', title: '檔案／目錄權限過寬',
    re: [/chmod\s+-?R?\s*0?777|os\.chmod\([^)]*0o?777|FileMode\(0o?777|setReadable\(true,\s*false\)|umask\s*\(\s*0\s*\)/i],
    why: '0777／全域可寫讓同機器上任何人都能改你的檔案或程式，可被植入後門。', fix: '給最小必要權限（檔案 600／640、目錄 700／750）；只讓擁有者可寫。' },

  { id: 'csrf-disabled', sev: 'med', cwe: 'CWE-352', title: '關閉了 CSRF 防護',
    re: /@?csrf[._]exempt|WTF_CSRF_ENABLED\s*=\s*False|csrf\s*:\s*false|csrfProtection\s*=\s*false|@csrf_exempt/i,
    skip: /webhook|stateless|bearer|api[_-]?token.*only/i,
    why: '關掉 CSRF 後，攻擊者可誘使已登入的使用者在不知情下送出改狀態的請求。', fix: '保留 CSRF token 驗證；純 token（Authorization header）的 API 可用 SameSite cookie 取代，但別整個關掉。' },

  { id: 'insecure-cookie', sev: 'low', cwe: 'CWE-614', title: 'Cookie 沒設 HttpOnly／Secure',
    re: /(res\.cookie|set_cookie|setHeader\(["'`]Set-Cookie|cookie\.set|new Cookie)\s*\(/i,
    needCtx: /session|token|auth|login|sid|jwt/i,
    skip: /httpOnly\s*:\s*true|HttpOnly|secure\s*:\s*true|Secure|samesite|SameSite/i,
    why: '少了 HttpOnly，JS（XSS）就能偷走 session cookie；少了 Secure，明文連線會外洩。', fix: '登入／session cookie 設 HttpOnly＋Secure＋SameSite=Lax/Strict。' },
];

/** 單行預先清掉字串與註解以外的誤判（保留原行回報，比對用的是原行） */
function lineIsComment(line, lang) {
  const t = line.trim();
  if (JS.includes(lang)) return t.startsWith('//') || t.startsWith('*') || t.startsWith('/*');
  if (PY.includes(lang)) return t.startsWith('#');
  return t.startsWith('#') || t.startsWith('//');
}

/**
 * 掃描程式碼／設定。回傳 { findings:[{id,sev,cwe,title,line,evidence,why,fix}], summary, counts }
 */
function analyze(code, { lang = '', maxFindings = 60 } = {}) {
  const src = String(code == null ? '' : code);
  if (!src.trim()) throw new Error('沒有要稽核的內容');
  if (src.length > 400000) throw new Error('內容太大（超過 400KB），請分段或只貼關鍵檔案');
  const L = String(lang || '').toLowerCase();
  const lines = src.split(/\r?\n/);
  const findings = []; const seen = new Set();
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    if (!line.trim() || line.length > 2000) continue;
    const isCmt = lineIsComment(line, L);
    for (const rule of RULES) {
      if (rule.langs && L && !rule.langs.includes(L)) continue;
      if (isCmt && rule.sev !== 'high') continue;   // 註解行只抓高風險（例如註解裡的金鑰）
      const res = Array.isArray(rule.re) ? rule.re : [rule.re];
      let hit = false; for (const re of res) { re.lastIndex = 0; if (re.test(line)) { hit = true; break; } }
      if (!hit) continue;
      if (rule.skip && rule.skip.test(line)) continue;
      if (rule.needCtx) { const win = lines.slice(Math.max(0, i - 2), i + 3).join('\n'); if (!rule.needCtx.test(win)) continue; }
      const key = rule.id + ':' + i; if (seen.has(key)) continue; seen.add(key);
      findings.push({ id: rule.id, sev: rule.sev, cwe: rule.cwe, title: rule.title, line: i + 1, evidence: maskSecrets(clip(line.trim(), 160)), why: rule.why, fix: rule.fix });
      if (findings.length >= maxFindings) break;
    }
    if (findings.length >= maxFindings) break;
  }
  findings.sort((a, b) => SEV[b.sev][1] - SEV[a.sev][1] || a.line - b.line);
  const counts = { high: 0, med: 0, low: 0, info: 0 }; for (const f of findings) counts[f.sev]++;
  return { findings, counts, lines: lines.length, lang: L || '（未指定）' };
}

/** 文字報告（給 AI 原樣轉述；已遮罩祕密） */
function report(code, opt = {}) {
  const r = analyze(code, opt);
  if (!r.findings.length) return `資安靜態掃描（${r.lines} 行，${r.lang}）：這一輪的規則沒有掃到明顯弱點。\n注意：這是以樣式比對為主的初步檢查，不等於安全；仍建議做設計層面的威脅建模與相依套件掃描。`;
  const byId = {}; for (const f of r.findings) (byId[f.id] = byId[f.id] || []).push(f);
  const head = `資安靜態掃描（${r.lines} 行，${r.lang}）：${r.findings.length} 項｜高 ${r.counts.high}、中 ${r.counts.med}、低 ${r.counts.low}。嚴重度高的先修。`;
  const body = Object.values(byId).map((g) => {
    const f = g[0]; const where = g.slice(0, 6).map((x) => '第 ' + x.line + ' 行').join('、') + (g.length > 6 ? ' 等' : '');
    return `\n[${SEV[f.sev][0]}] ${f.title}（${f.cwe}）\n　位置：${where}\n　範例：${g[0].evidence}\n　風險：${f.why}\n　修法：${f.fix}`;
  }).join('\n');
  return head + '\n' + body + '\n\n（此為防禦性檢查：只指出弱點與修法，不含任何攻擊程式。修完建議重掃，並補上相依套件漏洞掃描與測試。）';
}

/* ---------------- 系統描述的紅隊／綠隊評估（不是攻擊，是檢查清單） ---------------- */
const TOPICS = {
  web: { re: /web|網站|網頁|前端|html|express|django|flask|rails|php|laravel|spring|api|rest|http/i,
    red: ['OWASP Top 10 逐項過：注入、認證、XSS、存取控制、設定錯誤、SSRF', '每個 API 都有身分驗證與「物件層級」授權（不能改 id 就看到別人資料，IDOR）', '輸入驗證與輸出跳脫是否一致', '錯誤訊息會不會洩漏堆疊／版本／路徑', '有沒有速率限制、防暴力破解'],
    green: ['集中式驗證與授權中介層，預設拒絕', '參數化查詢、輸出跳脫、CSP、安全標頭（HSTS、X-Content-Type-Options、CSRF token）', '輸入用結構化驗證（schema）', '統一錯誤處理，不外露細節', 'WAF／速率限制／帳號鎖定'] },
  auth: { re: /登入|認證|auth|login|密碼|password|session|jwt|oauth|token|sso|mfa|2fa/i,
    red: ['密碼是否用 bcrypt／argon2 加鹽雜湊（不是 MD5／明文）', 'session／JWT 會不會被竊取或偽造（alg=none、弱密鑰）', '有沒有防暴力破解、帳號列舉', '重設密碼、記住我、登出是否安全', '有沒有多因素（MFA）'],
    green: ['密碼 argon2id／bcrypt、長度政策、擋常見密碼', 'Session 用安全隨機、HttpOnly+Secure+SameSite cookie；JWT 指定演算法、短效期、可撤銷', '登入速率限制＋鎖定、登入通知', '重要操作要求重新驗證、支援 MFA（TOTP／passkey）'] },
  db: { re: /資料庫|database|sql|mysql|postgres|mongo|redis|oracle|sqlite/i,
    red: ['連線是否加密、帳號是否最小權限（不是 root）', '有沒有 SQL／NoSQL injection', '備份有沒有加密、存取控制', '機敏欄位（身分證、卡號）有沒有加密／遮罩'],
    green: ['最小權限帳號、分環境帳密、連線走 TLS', '一律參數化查詢', '靜態加密（at-rest）、機敏欄位欄位級加密、備份加密並定期演練還原', '稽核日誌'] },
  linux: { re: /linux|server|伺服器|vps|ubuntu|debian|nginx|apache|ssh|docker|kubernetes|k8s|雲|cloud|aws|gcp|azure/i,
    red: ['SSH 是否禁密碼登入、禁 root、改預設埠／限制來源', '對外開了哪些埠（最小曝露面）', '系統與套件是否即時更新、有無已知 CVE', '容器是否以非 root 跑、有無逃逸風險', '雲端 IAM 權限是否過大、儲存桶是否公開'],
    green: ['SSH 金鑰登入＋fail2ban、防火牆預設拒絕、只開必要埠', '自動安全更新、定期弱點掃描', '容器非 root、唯讀檔案系統、最小映像、掃描映像', 'IAM 最小權限、關閉公開儲存桶、開啟稽核日誌與告警'] },
  android: { re: /android|app|手機|mobile|apk|ios|行動/i,
    red: ['有沒有把金鑰／密碼寫死在 App 裡（可被反編譯）', '本機資料是否加密、有無存機敏到明文', '網路是否強制 TLS、有無憑證綁定', '元件（Activity／Service／Provider）有沒有不該匯出的被匯出', 'WebView 是否開了危險設定（JS 介面、載入不信任內容）'],
    green: ['機密不落地在 App；要存用 Keystore／EncryptedSharedPreferences', '全程 HTTPS＋network-security-config，必要時憑證綁定', '最小化 exported 元件並加權限', 'WebView 關掉不需要的 JS 介面、只載信任來源', '上架前做反編譯檢視與相依掃描'] },
  crypto: { re: /加密|密碼學|crypto|tls|ssl|憑證|certificate|金鑰|key|aes|rsa|hash|簽章/i,
    red: ['有沒有自製加密或用過時演算法（MD5／SHA1／DES／ECB）', '金鑰怎麼產生、保管、輪替', '亂數是不是密碼學安全', 'TLS 版本與套件是否夠新、有無關掉驗證'],
    green: ['用成熟函式庫，不自製；對稱 AES-GCM、雜湊 SHA-256+、密碼 argon2／bcrypt', '金鑰用 KMS／Vault 保管並定期輪替、不入版控', '安全亂數來源', 'TLS1.2+、停用弱套件、保持憑證驗證'] },
  secret: { re: /金鑰|密鑰|secret|api.?key|token|憑證|密碼|credential|\.env/i,
    red: ['金鑰有沒有進版控／前端／log／映像', '外洩後能不能快速輪替與撤銷', '不同環境是否共用同一把金鑰'],
    green: ['祕密放 Secret Manager／Vault／環境變數，.env 進 .gitignore', '前端不放任何長期祕密', '分環境、可輪替、最小權限、設到期', '用掃描工具（git-secrets／trufflehog）擋提交'] },
  supply: { re: /套件|相依|dependency|npm|pip|library|第三方|open.?source|供應鏈/i,
    red: ['相依套件有沒有已知漏洞（CVE）', '有沒有鎖版本、來源可信', '有無被植入惡意套件（typosquatting）風險'],
    green: ['鎖版本＋lockfile、定期 npm audit／pip-audit／SCA 掃描', '最小化相依、審核新套件來源', '啟用自動更新告警（Dependabot 類）'] },
};

/** 給一段系統描述，產生「紅隊檢查清單＋綠隊強化清單」（純檢查，不含攻擊步驟） */
function assess(desc) {
  const d = String(desc == null ? '' : desc).trim();
  if (!d) throw new Error('請描述要評估的系統（技術棧、部署方式、處理什麼資料）');
  const picked = Object.entries(TOPICS).filter(([, t]) => t.re.test(d)).map(([k]) => k);
  const keys = picked.length ? picked : ['web', 'auth', 'secret'];   // 看不出來時給最常見的三塊
  const names = { web: 'Web／API', auth: '身分驗證與授權', db: '資料庫', linux: '伺服器／雲端／容器', android: '行動 App', crypto: '密碼學', secret: '祕密管理', supply: '相依套件／供應鏈' };
  const red = []; const green = [];
  for (const k of keys) { red.push(`■ ${names[k]}\n` + TOPICS[k].red.map((x) => '　□ ' + x).join('\n')); green.push(`■ ${names[k]}\n` + TOPICS[k].green.map((x) => '　• ' + x).join('\n')); }
  return [
    `資安評估（紅隊檢查＋綠隊強化）—涵蓋：${keys.map((k) => names[k]).join('、')}`,
    '',
    '【紅隊視角：攻擊者會檢查的點（請逐項確認你的系統擋得住）】',
    red.join('\n'),
    '',
    '【綠隊視角：建議的強化措施】',
    green.join('\n'),
    '',
    '【通用基礎（所有系統都該做）】',
    '　• 最小權限：帳號、金鑰、網路、容器都只給必要權限',
    '　• 預設拒絕：存取控制、防火牆、CORS 都是白名單',
    '　• 縱深防禦：不靠單一防線；輸入驗證＋輸出跳脫＋監控同時做',
    '　• 可觀測：集中日誌、告警、保留稽核紀錄（但不記祕密）',
    '　• 事件應變：有備份（定期演練還原）、有通報與輪替金鑰的流程',
    '　• 定期：相依套件漏洞掃描、滲透測試（對自己的系統、取得授權）、更新修補',
    '',
    '（這是防禦性檢查清單，不含任何攻擊程式或入侵步驟。實際滲透測試請只對自己擁有或已獲書面授權的系統進行。）',
  ].join('\n');
}

/* ---------------- 攻擊面盤點／滲透測試計畫（紅隊視角的檢查清單，不含攻擊碼） ---------------- */
/**
 * recon(desc)：給一段系統／目標描述，產出「攻擊面地圖＋授權滲透測試計畫」。
 * 這是規劃用的檢查清單（要測哪些面向、看什麼算有問題、優先序），不是可執行的攻擊工具或入侵步驟。
 * 一律提醒：只能對自己擁有或有書面授權（談好 ROE）的系統做。
 */
function recon(desc) {
  const d = String(desc == null ? '' : desc).trim();
  if (!d) throw new Error('請描述要盤點的目標（技術棧、對外服務、處理的資料、部署方式）');
  const picked = Object.entries(TOPICS).filter(([, t]) => t.re.test(d)).map(([k]) => k);
  const keys = picked.length ? picked : ['web', 'auth', 'secret'];
  const names = { web: 'Web／API', auth: '身分驗證與授權', db: '資料庫', linux: '伺服器／雲端／容器', android: '行動 App', crypto: '密碼學', secret: '祕密管理', supply: '相依套件／供應鏈' };
  // 進入點（attack surface）與信任邊界：攻擊者會從哪裡接觸系統
  const ENTRY = {
    web: ['對外網址、API 端點、參數與隱藏欄位', '檔案上傳、匯入、Webhook', '錯誤頁／除錯頁、舊版或測試路徑'],
    auth: ['登入、註冊、忘記密碼、驗證碼、OAuth 回呼', 'session／JWT／API token 的發放與驗證', '角色與權限的每一個判斷點'],
    db: ['任何把輸入帶進查詢的地方', '對外可達的資料庫埠、管理介面', '備份檔與匯出檔的存放位置'],
    linux: ['對外開放的埠與服務版本', 'SSH／管理面板／雲端 Console', '容器與編排介面、metadata 服務'],
    android: ['匯出的 Activity／Service／Provider／Receiver 與自訂 scheme', '本機儲存、備份、log、剪貼簿', '與後端的 API 與憑證驗證'],
    crypto: ['金鑰的產生、傳輸、保管點', 'TLS 端點與版本／套件', '自製加密或簽章的環節'],
    secret: ['版控、CI/CD、映像、前端包裡可能夾帶的祕密', '環境變數、設定檔、log', '第三方整合的金鑰範圍'],
    supply: ['相依套件與其傳遞相依', '建置流程與套件來源', '預建映像與基底映像'],
  };
  const lines = [];
  lines.push(`攻擊面盤點＋滲透測試計畫（紅隊視角）—涵蓋：${keys.map((k) => names[k]).join('、')}`);
  lines.push('');
  lines.push('【第一步：先確認授權（最重要）】');
  lines.push('　□ 只測自己擁有或拿到書面授權的系統；先談定範圍、時間、聯絡人與禁止事項（ROE）');
  lines.push('　□ 準備好回滾與通報機制，避免影響正式服務或真實資料');
  lines.push('');
  lines.push('【攻擊面地圖：攻擊者會從哪些進入點／信任邊界接觸你（逐一列出並盤點）】');
  for (const k of keys) lines.push(`■ ${names[k]}\n` + (ENTRY[k] || []).map((x) => '　◦ ' + x).join('\n'));
  lines.push('');
  lines.push('【要驗證的點：攻擊者會嘗試哪類手法（檢查項，不是攻擊碼）】');
  for (const k of keys) lines.push(`■ ${names[k]}\n` + TOPICS[k].red.map((x) => '　□ ' + x).join('\n'));
  lines.push('');
  lines.push('【測試方法（授權範圍內、用現成合規工具，非入侵步驟）】');
  lines.push('　• 被動盤點：盤點資產、埠、服務版本、對外端點、相依套件（SBOM）');
  lines.push('　• 設定與相依掃描：弱點掃描器、SCA（npm audit／pip-audit）、雲端設定檢查（CIS Benchmark）');
  lines.push('　• 功能面驗證：對每個端點逐項過上面的檢查清單，確認授權、輸入驗證、錯誤處理、速率限制');
  lines.push('　• 記錄：每個發現記「位置、影響、重現條件、嚴重度」，交給綠隊修補後重測');
  lines.push('');
  lines.push('【修補與強化（綠隊，對應上面的風險）】');
  for (const k of keys) lines.push(`■ ${names[k]}\n` + TOPICS[k].green.map((x) => '　• ' + x).join('\n'));
  lines.push('');
  lines.push('【優先序】先處理「高影響×易觸發」：對外可達＋未驗證授權＋可達敏感資料的路徑最優先。');
  lines.push('');
  lines.push('（這是規劃與檢查清單，不含任何可執行的 exploit、payload 或入侵步驟。實際測試只對自己擁有或已獲書面授權的系統進行。）');
  return lines.join('\n');
}

module.exports = { analyze, report, assess, recon, maskSecrets, RULES, SEV };
