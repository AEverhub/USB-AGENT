'use strict';
/**
 * Termux 環境整合：讓 AI 擁有「完整 Linux（bash／python／git／node／pkg）」與「真正的 Chromium」。
 *  ・App 本身是 nodejs-mobile，只有 Android 的精簡 shell；完整 Linux 與 Chromium 由 Termux 提供，
 *    以 backend/termux/agent-bridge.js（跑在 Termux 內）當橋，這裡只透過 loopback HTTP + token 呼叫它。
 *  ・Termux 是另一個 App／另一個 Linux 使用者：AI 在裡面「讀不到」本 App 的資料夾（保險箱金鑰、設定檔），隔離比 App 內 shell 更好。
 *  ・Chromium 是真的 Chrome 引擎（不是 Android WebView），不會被 Google「不支援內嵌 WebView 登入」擋下，
 *    而且用 CDP 真實滑鼠鍵盤事件（isTrusted），Google 表單／Docs／Sheets 的元件才吃得到。
 */
const fs = require('fs');
const path = require('path');
const { clip } = require('../core/util');
const { logger } = require('../core/log');
const log = logger('termux');

const LOOPBACK = /^(127\.\d+\.\d+\.\d+|localhost|\[?::1\]?)$/i;
const DIR = path.join(__dirname, '..', '..', 'termux');

class Termux {
  constructor(ctx) { this.ctx = ctx; this._fetch = ctx.termuxFetch || ((...a) => fetch(...a)); }
  get cfg() { return this.ctx.settings.get('termux') || {}; }
  enabled() { return this.cfg.enabled !== false; }
  /** 完整權限模式（預設開）：管理員把 Termux 當成「專屬 AI 的獨立電腦」——路徑不限 HOME、可跑數小時的任務，AI 不必逐步詢問。仍然碰不到本 App 的資料（不同 Linux 使用者） */
  full() { return this.cfg.full_access !== false; }
  ready() { return this.enabled() && !!this.cfg.token && !!this.cfg.url; }
  /** 只允許 loopback（token 不能被送去別的主機），除非管理員明確開 allow_remote */
  _base() {
    let u; try { u = new URL(this.cfg.url); } catch { throw new Error('Termux 橋接網址格式不正確'); }
    if (!/^https?:$/.test(u.protocol)) throw new Error('只支援 http(s)'); if (!LOOPBACK.test(u.hostname) && !this.cfg.allow_remote) throw new Error('橋接網址必須是本機（127.0.0.1）。要連其他主機請先開啟 allow_remote（不建議）。');
    return u.origin;
  }
  need() { if (!this.enabled()) throw new Error('管理員已關閉 Termux 整合'); if (!this.ready()) throw new Error('Termux 環境還沒設定。請管理員到 App「瀏覽器」頁的「Termux 環境」卡片，複製安裝指令到 Termux 執行一次（約 10 分鐘）。'); }
  state() { const c = this.cfg; return { enabled: this.enabled(), configured: this.ready(), url: c.url || '', token_set: !!c.token, allow_remote: !!c.allow_remote, full_access: this.full(), chromium_port: +c.chromium_port || 9222, using_for_browser: this.ctx.settings.get('browser.provider') === 'linux' || (this.ctx.settings.get('browser.provider') === 'cdp' && !!this.ctx.settings.get('browser.cdp_url') && this._usingFlag === true) }; }

  async call(method, p, body, timeout = 30000) {
    this.need(); const ctl = new AbortController(); const t = setTimeout(() => ctl.abort(), timeout); let r;
    try { r = await this._fetch(this._base() + p, { method, headers: { authorization: 'Bearer ' + this.cfg.token, ...(body !== undefined ? { 'content-type': 'application/json' } : {}) }, body: body !== undefined ? JSON.stringify(body) : undefined, signal: ctl.signal }); }
    catch (e) { clearTimeout(t); throw new Error(e.name === 'AbortError' ? 'Termux 橋接逾時' : `連不上 Termux 橋接（${e.cause && e.cause.code ? e.cause.code : e.message}）。Termux 是否在背景被系統關掉了？開啟 Termux 執行 ~/.agent-bridge/start.sh，並把 Termux 的電池設定改成「不受限制」。`); }
    clearTimeout(t); const text = await r.text(); let j = {}; try { j = JSON.parse(text); } catch { /* ignore */ }
    if (!r.ok) throw new Error(r.status === 401 ? 'Termux 橋接拒絕了 token（重新執行安裝指令可重新註冊）' : (j.error || `HTTP ${r.status}`)); return j;
  }
  health() { return this.call('GET', '/health', undefined, 8000); }
  async exec(cmd, { cwd, timeout_s = 120, background = false } = {}) {
    const max = this.full() ? 21600 : 1800; const r = await this.call('POST', '/exec', { cmd, cwd, timeout_s, background: !!background, full: this.full() }, background ? 30000 : (Math.min(+timeout_s || 120, max) + 15) * 1000);
    this.ctx.store.audit('termux', background ? 'exec.bg' : 'exec', clip(cmd, 160)); if (background) return { ...r, text: `已在背景啟動（job ${r.id}，pid ${r.pid}）。用 termux_job 看輸出：list／log／kill。輸出寫在 Termux 的 ~/.agent-bridge/jobs/${r.id}.log` }; return { ...r, text: clip((r.out || '').trim() || '(沒有輸出)', 8000) + `\n[exit ${r.code}${r.timedOut ? '，逾時已終止' : ''}]` };
  }
  jobs() { return this.call('GET', '/jobs'); }
  jobLog(id, tail = 4000) { return this.call('GET', `/jobs/log?id=${encodeURIComponent(id)}&tail=${+tail || 4000}`); }
  jobKill(id) { return this.call('POST', '/jobs/kill', { id }); }
  chromiumStatus() { return this.call('GET', '/chromium/status'); }
  async chromiumStart(o = {}) { return this.call('POST', '/chromium/start', { port: +this.cfg.chromium_port || 9222, headless: true, ...o }, 4 * 80000); }   // 最多試 3 種模式，每種等 75 秒
  chromiumStop() { return this.call('POST', '/chromium/stop', {}); }
  /** 啟動 Termux 的 Chromium，並讓 browser_* 工具改用它（真 Chrome 引擎＋可信任的滑鼠鍵盤事件） */
  async useAsBrowser(o = {}) {
    const r = await this.chromiumStart(o); const S = this.ctx.settings; const B = this.ctx.browser;
    if (this._usingFlag !== true) this._prev = { provider: S.get('browser.provider'), cdp_url: S.get('browser.cdp_url') };
    // 26.11.3 Revise5：改成「受管理」(linux)：不再寫死 cdp_url，Chromium 掛掉時瀏覽器服務會自己重開（以前會卡在 ECONNREFUSED 127.0.0.1:9222）
    S.set('browser.provider', 'linux', 'human'); S.set('browser.cdp_url', '', 'human'); this._usingFlag = true; try { await B.shutdown(); } catch { /* ignore */ }
    this.ctx.store.audit('termux', 'browser.use', r.cdp_url || ''); return r;
  }
  async restoreBrowser() {
    const S = this.ctx.settings; const p = this._prev || { provider: 'auto', cdp_url: '' }; S.set('browser.provider', p.provider || 'auto', 'human'); S.set('browser.cdp_url', p.cdp_url || '', 'human'); this._usingFlag = false; try { await this.ctx.browser.shutdown(); } catch { /* ignore */ }
    try { await this.chromiumStop(); } catch { /* Termux 不在也沒關係 */ } return { ok: true };
  }
  async fileGet(remote, saveAs) { const r = await this.call('GET', '/file/get?path=' + encodeURIComponent(remote) + (this.full() ? '&full=1' : ''), undefined, 120000); const f = this.ctx.fsx.resolve(saveAs, 'workspace'); fs.mkdirSync(path.dirname(f), { recursive: true }); fs.writeFileSync(f, Buffer.from(r.b64, 'base64')); return { path: saveAs, bytes: r.size }; }
  async filePut(localRel, remote) { const f = this.ctx.fsx.resolve(localRel, 'workspace'); const st = fs.statSync(f); if (st.isDirectory()) throw new Error('不能傳資料夾'); if (st.size > 25 * 1024 * 1024) throw new Error('檔案超過 25MB'); const r = await this.call('POST', '/file/put', { path: remote, full: this.full(), b64: fs.readFileSync(f).toString('base64') }, 120000); return { path: r.path, bytes: r.size }; }
  /** Termux 內安裝腳本註冊回來 */
  register(url, token) {
    url = String(url || '').trim(); token = String(token || '').trim(); if (token.length < 16) throw new Error('token 太短'); let u; try { u = new URL(url); } catch { throw new Error('url 格式不正確'); } if (!LOOPBACK.test(u.hostname)) throw new Error('只接受本機位址註冊');
    this.ctx.settings.set('termux.url', u.origin, 'human'); this.ctx.settings.set('termux.token', token, 'human'); this.ctx.store.audit('app', 'termux.register', u.origin); return this.state();
  }
  /** 給 Termux 下載的安裝腳本／橋接程式 */
  setupScript(appUrl, appToken) {
    if (!/^https?:\/\/[\w.\-:[\]]+$/.test(appUrl)) throw new Error('Host 格式不正確'); if (!/^[\w-]+$/.test(appToken)) throw new Error('token 格式不正確');
    return fs.readFileSync(path.join(DIR, 'setup.sh.tpl'), 'utf8').replace('__APP_URL__', appUrl).replace('__APP_TOKEN__', appToken);
  }
  bridgeScript() { return fs.readFileSync(path.join(DIR, 'agent-bridge.js'), 'utf8'); }
}
module.exports = { Termux };
