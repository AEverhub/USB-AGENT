'use strict';
/**
 * 服務頁（App 第一頁）的「服務按鈕」：一個按鈕＝一件常做的事。
 *   input：none（直接執行）｜text（先打一句話）｜photo（拍照／選圖）｜qr（掃 QR）
 *   prompt：交給 AI 的指示，{input} 會換成使用者輸入；action=einvoice 是內建的「掃發票記帳」（不經 AI，離線也能用）
 * 使用者可以自己新增、修改、排序、刪除；沒改過就用內建清單。
 */
const { clip } = require('../core/util');
const { isInvoice } = require('./einvoice');

const BUILTIN = [
  // 26.11.3 pro2：口述記帳（第一個）、邏輯閘轉換器、連結其他帳號
  { id: 'voice_ledger', icon: 'mic', name: '口述記帳', input: 'voice', desc: '按一下直接用講的記帳', prompt: '幫我記帳（使用者用講的，語音辨識可能有錯字，金額與項目照常理判斷；一句話裡有好幾筆就分開記）：{input}' },
  { id: 'scan_invoice', icon: 'qr', name: '掃發票記帳', input: 'qr', action: 'einvoice', desc: '掃電子發票左邊的 QR，直接記一筆支出' },
  { id: 'photo_receipt', icon: 'camera', name: '拍照記帳', input: 'photo', desc: '發票、收據、帳單拍照就好', prompt: '這是一張發票／收據／帳單的照片。讀出日期、店家、品項與總金額，用 ledger_add 記成一筆（自己判斷必要或非必要支出；日期用照片上的）。記完用一句話告訴我記了什麼。真的看不清楚才問我。' },
  { id: 'quick_ledger', icon: 'pen', name: '記一筆', input: 'text', placeholder: '例：午餐 120、薪水 45000', desc: '用講的記帳', prompt: '幫我記帳：{input}' },
  { id: 'food', icon: 'food', name: '叫外送', input: 'text', placeholder: '想吃什麼、預算、幾個人', desc: 'AI 幫你挑店、備好訂單', prompt: '我想叫外送：{input}。用瀏覽器幫我找合適的店家和餐點，把訂單準備好；付款或送出前先跟我確認一次（品項、金額、地址）。' },
  { id: 'clinic', icon: 'hospital', name: '網路掛號', input: 'text', placeholder: '醫院、科別、醫師、想要的時段', desc: '自動登入、找時段、掛好號', prompt: '幫我網路掛號：{input}。用瀏覽器到那家醫院的網路掛號頁；需要的身分證字號、生日等從我的記憶或保險箱找（browser_login）；找到最符合的時段，送出前跟我確認一次。遇到驗證碼請我接手（browser_handoff）。掛好後把日期、時間、醫師、號碼告訴我，並用 schedule_task 在前一天晚上提醒我。' },
  { id: 'today', icon: 'sun', name: '今天有什麼事', input: 'none', desc: '天氣、行程、信件、提醒一次看', prompt: '幫我看一下今天有什麼事（daily_brief），講重點就好。' },
  { id: 'remind', icon: 'clock', name: '提醒我', input: 'text', placeholder: '例：明天早上八點吃藥', desc: '講一句話就排好提醒', prompt: '提醒我：{input}' },
  { id: 'logic_gates', icon: 'grid', name: '邏輯閘轉換器', input: 'none', action: 'open:logic', desc: '最簡 SOP／POS、NAND／NOR、IC 接線' },
  { id: 'circuit_tool', icon: 'circuit', name: '電路工具', input: 'none', action: 'open:circuit', desc: '電阻電容 IC 感測器：算電壓、電流、功率' },
  { id: 'code_tool', icon: 'code', name: '程式碼工具', input: 'none', action: 'open:code', desc: '寫程式、執行、AI 解釋與修 bug' },
  { id: 'site_tool', icon: 'web', name: '網站工作室', input: 'none', action: 'open:sites', desc: 'AI 自己開發網頁系統、預覽、打包' },
  { id: 'video_tool', icon: 'film', name: '影片工作室', input: 'none', action: 'open:video', desc: 'AI 寫分鏡、自動做短影音' },
  { id: 'link_account', icon: 'link', name: '連結其他帳號', input: 'none', action: 'link', desc: '產生驗證碼，把 LINE／Discord／TG 帳號連在一起' },
  { id: 'ask', icon: 'chat', name: '問 AI', input: 'text', placeholder: '想做什麼都可以直接說', desc: '什麼事都能交代', prompt: '{input}' },
];
const INPUTS = ['none', 'text', 'photo', 'qr', 'voice'];
const ACTIONS = ['einvoice', 'link', 'open:logic', 'open:circuit', 'open:code', 'open:sites', 'open:video'];
const ADDED = ['voice_ledger', 'logic_gates', 'link_account', 'circuit_tool', 'code_tool', 'site_tool', 'video_tool'];   // 26.11.3 pro2 新增：自訂過選單的人也補上一次

class Tiles {
  constructor(ctx) { this.ctx = ctx; }
  list() {
    const db = this.ctx.store.db; const t = db.service_tiles; if (!(Array.isArray(t) && t.length)) return BUILTIN.map((x) => ({ ...x, builtin: true }));
    const done = new Set(db.tiles_added || []); const miss = ADDED.filter((id) => !done.has(id) && !t.some((x) => x.id === id));
    if (miss.length) { for (const id of miss) { const b = BUILTIN.find((x) => x.id === id); if (id === 'voice_ledger') t.unshift({ ...b, builtin: true }); else t.push({ ...b, builtin: true }); } db.tiles_added = [...done, ...ADDED]; this.ctx.store.touch(); }
    return t;
  }
  get(id) { return this.list().find((t) => t.id === id); }
  save(items) {
    if (!Array.isArray(items)) throw new Error('格式錯誤'); if (items.length > 40) throw new Error('最多 40 個服務按鈕');
    const seen = new Set(); const out = [];
    for (const x of items) {
      const name = clip(String(x.name || '').trim(), 20); if (!name) throw new Error('每個按鈕都要有名稱');
      let id = String(x.id || '').replace(/[^\w-]/g, '').slice(0, 40) || 'svc_' + Date.now().toString(36) + out.length; while (seen.has(id)) id += '_'; seen.add(id);
      const input = INPUTS.includes(x.input) ? x.input : 'text'; const action = ACTIONS.includes(x.action) ? x.action : '';
      const prompt = clip(String(x.prompt || '').trim(), 2000); if (!action && !prompt) throw new Error(`「${name}」要寫給 AI 的指示`);
      out.push({ id, icon: /^[a-z]{2,16}$/.test(String(x.icon || '')) ? x.icon : 'spark', name, input, action, prompt, placeholder: clip(String(x.placeholder || ''), 60), desc: clip(String(x.desc || ''), 60), builtin: !!(BUILTIN.find((b) => b.id === id) && x.builtin) });
    }
    this.ctx.store.db.service_tiles = out; this.ctx.store.touch(); return out;
  }
  reset() { this.ctx.store.db.service_tiles = null; this.ctx.store.touch(); return this.list(); }

  /** 執行：回傳 {text, images, kind}。person＝App 管理員 */
  async run(id, { text = '', image = null, qr = [] } = {}, person) {
    const t = this.get(id); if (!t) throw new Error('找不到這個服務按鈕');
    const qrs = (Array.isArray(qr) ? qr : [qr]).map((x) => String(x || '').trim()).filter(Boolean);
    // 電子發票：不經 AI，直接解析記帳（離線也能記）
    if (t.action === 'link') { const code = this.ctx.hub.newLinkCode(person.id); const bots = ['line', 'discord', 'telegram'].filter((p) => this.ctx.hub.connectors[p] && this.ctx.hub.connectors[p].enabled()); return { kind: 'link', code, platforms: bots, text: `驗證碼：${code}（10 分鐘內有效）\n到要連結的 ${bots.length ? bots.map((p) => ({ line: 'LINE', discord: 'Discord', telegram: 'Telegram' }[p])).join('／') : 'LINE／Discord／Telegram'} 私訊機器人：驗證碼 ${code}\n連結後兩邊共用同一份記憶、記帳與權限。` }; }
    if (/^open:(logic|circuit|code)$/.test(t.action)) return { kind: 'open', page: t.action.slice(5), text: '' };
    if (t.action === 'einvoice' || (qrs.length && qrs.some(isInvoice))) {
      if (!qrs.length) throw new Error('沒有掃到 QR Code');
      const r = this.ctx.einvoice.record(qrs, person.id); this.ctx.store.audit(person.id, 'einvoice', r.invoice.number);
      return { kind: 'einvoice', text: r.text, duplicate: r.duplicate, invoice: r.invoice };
    }
    if ((t.input === 'text' || t.input === 'voice') && !String(text).trim() && /\{input\}/.test(t.prompt)) throw new Error(t.input === 'voice' ? '沒有聽到內容，請再說一次' : '請先輸入內容');
    if (t.input === 'photo' && !image) throw new Error('請先拍照或選一張照片');
    let msgText = t.prompt.includes('{input}') ? t.prompt.split('{input}').join(String(text).trim()) : (String(text).trim() ? `${t.prompt}\n補充：${String(text).trim()}` : t.prompt);
    if (qrs.length) msgText += `\n（掃到的 QR Code 內容：${qrs.map((q) => clip(q, 500)).join('｜')}）`;
    const images = image && image.data ? [{ mime: /^image\/(png|jpeg|webp|gif)$/.test(image.mime) ? image.mime : 'image/jpeg', data: String(image.data) }] : [];
    if (!person.identities.some((i) => i.platform === 'app')) this.ctx.users.attach(person.id, 'app', 'local', person.name);
    const msg = { platform: 'app', chatId: 'app', uid: 'local', userName: person.name, text: `【從 App 服務按鈕「${t.name}」】${msgText}`, appImages: [] };
    const out = await this.ctx.agent.handle({ person, msg, images, group: false, scope: 'dm_' + person.id });
    return { kind: 'ai', text: out, images: msg.appImages, files: (msg._files || []).map((f) => ({ id: f.id, name: f.name, size: f.size })) };
  }
}
module.exports = { Tiles, BUILTIN };
