'use strict';
/**
 * Google Workspace 自動化（全部走瀏覽器，用你給的帳號登入後的真實工作階段）：
 *  ・登入（帳密／兩步驟驗證碼 TOTP 由保險箱直接打進網頁，模型看不到）；遇到人機驗證會請你接手
 *  ・Google 表單：讀題目 → 填答（單選／複選／下拉／文字／段落／日期／時間／格線）→ 下一頁／提交 → 驗證是否送出成功
 *  ・Google 日曆：用「新增活動範本網址」開好編輯頁，補上時間、地點、賓客、重複，按儲存並確認
 *  ・Docs／Sheets／Drive／Gmail：用 browser_* 通用工具操作（提示詞裡有操作要領）
 * 注意：Google 改版時網頁結構會變；這裡盡量用 ARIA 角色與多語文字比對，不依賴會變動的 class 名稱。
 */
const { sleep } = require('../core/util');
const { PAGE } = require('./browser');
const { logger } = require('../core/log');
const log = logger('google');

const norm = (s) => String(s ?? '').normalize('NFKC').toLowerCase().replace(/[\s　.,;:!?()（）、，。：；！？"'「」『』\-_/\\]+/g, '');
function pickOption(labels, want) {
  const w = norm(want); if (!w) return -1; let i = labels.findIndex((l) => norm(l) === w); if (i >= 0) return i;
  i = labels.findIndex((l) => norm(l).startsWith(w) || w.startsWith(norm(l)) && norm(l).length >= 2); if (i >= 0) return i;
  i = labels.findIndex((l) => norm(l).includes(w) || (norm(l).length >= 2 && w.includes(norm(l)))); return i;
}
const pad = (n) => String(n).padStart(2, '0');
function parseLocal(s) { const m = /^(\d{4})[-/](\d{1,2})[-/](\d{1,2})(?:[ T](\d{1,2}):(\d{2}))?/.exec(String(s || '').trim()); if (!m) throw new Error(`時間格式要像 2026-11-20 14:30（收到：${s}）`); return { y: +m[1], mo: +m[2], d: +m[3], h: m[4] == null ? null : +m[4], mi: m[5] == null ? null : +m[5] }; }
function addDays(p, n) { const d = new Date(Date.UTC(p.y, p.mo - 1, p.d + n)); return { y: d.getUTCFullYear(), mo: d.getUTCMonth() + 1, d: d.getUTCDate() }; }
const ymd = (p) => `${p.y}${pad(p.mo)}${pad(p.d)}`;

class Google {
  constructor(ctx) { this.ctx = ctx; }
  get b() { return this.ctx.browser; }

  /** 目前瀏覽器裡有沒有登入 Google（看 cookie，不打擾頁面） */
  async status() {
    const r = await this.b.cdp.send('Network.getCookies', { urls: ['https://accounts.google.com/', 'https://www.google.com/', 'https://mail.google.com/'] }).catch(() => ({ cookies: [] }));
    const names = new Set((r.cookies || []).map((c) => c.name)); const signed = ['SID', '__Secure-1PSID', 'SAPISID', '__Secure-3PSID'].some((n) => names.has(n));
    const exp = Math.max(0, ...(r.cookies || []).filter((c) => c.name === 'SID' || c.name === '__Secure-1PSID').map((c) => c.expires || 0));
    return { signed_in: signed, session_until: exp > 0 ? new Date(exp * 1000).toISOString().slice(0, 10) : '' };
  }

  async login(item, vault, { google = true, url = '' } = {}) {
    const b = this.b; const sec = vault.secrets(item); const steps = [];
    if (!google) {   // 一般網站：到登入頁，用同一套「看到什麼欄位就填什麼」的流程
      if (url) await b.goto(url);
      for (let i = 0; i < 4; i++) { await sleep(500); const s = await b.snapshot(60); const v = s.els.filter((e) => e.inView && !e.disabled); const pw = v.find((e) => e.type === 'password'); const user = v.find((e) => ['email', 'text', 'tel'].includes(e.type) && e.tag === 'input');
        if (user && sec.username && !user.value) { await b.typeId(user.id, sec.username, { submit: !pw }); steps.push('已輸入帳號'); if (!pw) { await sleep(1200); continue; } }
        if (pw && sec.password) { await b.typeId(pw.id, sec.password, { submit: true }); steps.push('已輸入密碼'); await sleep(1500); const s2 = await b.snapshot(60); const code = s2.els.find((e) => e.inView && ['tel', 'text', 'number'].includes(e.type) && /驗證碼|code|otp|2fa/i.test(e.label)); if (code && sec.totp) { await b.typeId(code.id, sec.totp, { submit: true }); steps.push('已輸入驗證碼'); } break; }
        if (!pw && !user) break; }
      return { ok: steps.length > 0, text: steps.length ? `${steps.join('→')}。請用 browser_read 確認是否登入成功；若出現驗證碼／人機驗證，請 browser_handoff。` : '頁面上找不到帳號／密碼欄位，請先 browser_open 到登入頁。' };
    }
    const st0 = await this.status(); const cur = await b.pageInfo();
    if (st0.signed_in && !/accounts\.google\.com\/(v3\/)?signin|ServiceLogin/.test(cur.url)) { return { ok: true, text: '瀏覽器已經是登入 Google 的狀態（不需要重新登入）。' + (st0.session_until ? ` 登入有效到約 ${st0.session_until}。` : '') }; }
    if (!/accounts\.google\.com/.test(cur.url)) await b.goto('https://accounts.google.com/signin/v2/identifier?hl=zh-TW&flowName=GlifWebSignIn');
    let usedPw = false, usedCode = false, usedUser = false;
    for (let i = 0; i < 8; i++) {
      await sleep(600); const s = await b.snapshot(60); const inView = s.els.filter((e) => e.inView && !e.disabled);
      if (!/accounts\.google\.com/.test(s.url) && !inView.some((e) => e.type === 'password')) break;
      const text = s.text;
      if (/不是機器人|captcha|Verify it.s you|驗證您的身分|確認你的身分|異常活動|unusual activity|Couldn.?t sign you in|無法登入|This browser or app may not be secure|不安全/i.test(text) && !inView.some((e) => e.type === 'password' || /identifier/i.test(e.label + e.type))) { steps.push('Google 要求額外驗證或擋下此瀏覽器'); break; }
      const pw = inView.find((e) => e.type === 'password');
      if (pw && sec.password && !usedPw) { await b.typeId(pw.id, sec.password, { submit: true }); usedPw = true; steps.push('已輸入密碼'); await sleep(1500); continue; }
      const code = inView.find((e) => ['tel', 'text', 'number'].includes(e.type) && /驗證碼|驗證代碼|code|6 位數|6-digit|Authenticator/i.test(e.label + ' ' + text.slice(0, 400)) && !/email|電子郵件|identifier/i.test(e.label));
      if (code && sec.totp && !usedCode) { await b.typeId(code.id, sec.totp, { submit: true }); usedCode = true; steps.push('已輸入兩步驟驗證碼（TOTP）'); await sleep(1500); continue; }
      const acct = inView.find((e) => sec.username && e.label.toLowerCase().includes(sec.username.toLowerCase()) && /a|div|li/.test(e.tag + e.role));
      if (acct && !usedUser && /選擇帳戶|Choose an account/i.test(text)) { await b.clickId(acct.id); usedUser = true; steps.push('已選擇帳戶'); continue; }
      const user = inView.find((e) => ['email', 'text', 'tel'].includes(e.type) && (/identifier|電子郵件|email|手機|phone|帳號/i.test(e.label) || e.tag === 'input'));
      if (user && sec.username && !usedUser) { await b.typeId(user.id, sec.username, { submit: true }); usedUser = true; steps.push('已輸入帳號'); await sleep(1500); continue; }
      break;
    }
    await sleep(1200); const st = await this.status(); const info = await b.pageInfo();
    if (st.signed_in && !/accounts\.google\.com\/(v3\/)?signin|challenge/.test(info.url)) return { ok: true, text: `登入成功（${steps.join('→') || '已登入'}）。` + (st.session_until ? ` 登入有效到約 ${st.session_until}。` : '') };
    const brief = await b.readText(false).catch(() => '');
    return { ok: false, text: `尚未完成登入（${steps.join('→') || '沒有找到可填的欄位'}）。可能遇到：兩步驟驗證（簡訊／手機提示）、人機驗證、或 Google 擋下自動化瀏覽器。請用 browser_handoff 請管理員接手完成；登入一次後會長期保持。\n\n${brief.slice(0, 1200)}`, needHandoff: true };
  }

  // ---------- 日曆 ----------
  async calendarAdd(a) {
    const b = this.b; const tz = this.ctx.settings.get('tz') || 'Asia/Taipei'; const s = parseLocal(a.start); let dates;
    if (a.all_day || s.h == null) { const e = a.end ? parseLocal(a.end) : s; const endEx = addDays(e, 1); dates = `${ymd(s)}/${ymd(endEx)}`; }
    else { const e = a.end ? parseLocal(a.end) : { ...s, h: s.h + 1, mi: s.mi }; let ee = e; if (e.h == null) ee = { ...e, h: 23, mi: 59 }; if (ee.h >= 24) { const d = addDays(ee, 1); ee = { ...d, h: ee.h - 24, mi: ee.mi }; } dates = `${ymd(s)}T${pad(s.h)}${pad(s.mi)}00/${ymd(ee)}T${pad(ee.h)}${pad(ee.mi)}00`; }
    const q = new URLSearchParams({ action: 'TEMPLATE', text: a.title, dates, ctz: tz, hl: 'zh-TW' }); if (a.details) q.set('details', a.details); if (a.location) q.set('location', a.location); if (a.guests && a.guests.length) q.set('add', a.guests.join(',')); if (a.recur) q.set('recur', a.recur);
    await b.goto('https://calendar.google.com/calendar/render?' + q.toString()); await sleep(1500);
    let info = await b.pageInfo(); if (/accounts\.google\.com/.test(info.url)) return { ok: false, text: '還沒登入 Google。請先 browser_login（用保險箱帳號）或 browser_handoff 請管理員登入。', needLogin: true };
    const find = async (re) => { const c = await b.evalPage(PAGE.findButton, re); return c; };
    let save = null; for (let i = 0; i < 8 && !save; i++) { save = await find('^(儲存|保存|Save)$'); if (!save) await sleep(700); }
    if (!save) return { ok: false, text: '找不到「儲存」按鈕（Google 日曆版面可能改了）。目前頁面：\n' + (await b.readText(false)) };
    await b.clickAt(save.x, save.y); await sleep(1500);
    for (let i = 0; i < 3; i++) { const send = await find('^(傳送|發送|Send)$'); if (!send) break; await b.clickAt(send.x, send.y); await sleep(1200); }   // 有賓客時會問「要傳送邀請嗎」
    await sleep(1200); info = await b.pageInfo(); const txt = await b.evalPage('() => document.body.innerText.slice(0, 3000)');
    const closed = !/eventedit|render\?action=TEMPLATE/.test(info.url); const toast = /活動已儲存|已儲存|Event saved|已建立/.test(txt);
    if (closed || toast) return { ok: true, text: `已在 Google 日曆建立活動「${a.title}」（${a.all_day ? '全天 ' : ''}${a.start}${a.end ? ' ~ ' + a.end : ''}${a.location ? '，地點：' + a.location : ''}${a.guests && a.guests.length ? '，賓客：' + a.guests.join('、') : ''}）。` };
    return { ok: false, text: '按了儲存但無法確認是否成功，請 browser_screenshot 看一下畫面。' };
  }

  // ---------- 表單 ----------
  fmtForm(r) {
    if (r.done) return `✅ 表單「${r.formTitle}」已送出（頁面顯示已記錄回應）。`;
    if (r.needLogin) return '這份表單要先登入 Google。請先 browser_login 或 browser_handoff。';
    const lines = r.questions.map((q) => `Q${q.i} [${q.type}${q.required ? '，必填' : ''}] ${q.title}${q.desc ? '（' + q.desc + '）' : ''}${q.options ? '\n    選項：' + q.options.join(' ｜ ') : ''}${q.rows ? '\n    格線：' + q.rows.map((x) => `${x.row}：${x.choices.join('/')}`).join('；') : ''}${q.value ? '\n    目前已填：' + q.value : ''}`);
    return `表單：${r.formTitle}\n網址：${r.url}\n本頁題目 ${r.questions.length} 題：\n${lines.join('\n') || '（這一頁沒有題目）'}\n頁面按鈕：${r.buttons.join('、') || '無'}${r.alerts.length ? '\n提示：' + r.alerts.join('；') : ''}`;
  }
  async formRead(url) { const b = this.b; if (url) { await b.goto(url); await sleep(800); } const r = await b.evalPage(PAGE.formRead); return r; }
  async formFill(answers, then = 'none') {
    const b = this.b; const res = []; let r0 = await b.evalPage(PAGE.formRead); const Q = r0.questions;
    for (const an of answers) {
      const qi = Number(an.q); const q = Q[qi]; if (!q) { res.push(`Q${an.q}：沒有這題`); continue; } let a = an.a;
      try {
        if (q.type === 'file') throw new Error('這題要上傳檔案，目前不支援自動上傳，請請管理員接手');
        if (q.type === 'text' || q.type === 'paragraph') { const c = await b.evalPage(PAGE.formCenter, qi, -1); if (c.err) throw new Error(c.err); await b.clickAt(c.x, c.y); await b.key('Control+a'); await b.insertText(String(a)); await sleep(120); }
        else if (q.type === 'date' || q.type === 'time') { await b.evalPage(`(qi, v) => { const el = window.__lf[qi].control; const set = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set; set.call(el, v); el.dispatchEvent(new Event('input', { bubbles: true })); el.dispatchEvent(new Event('change', { bubbles: true })); }`, qi, String(a)); }
        else if (q.type === 'radio' || q.type === 'checkbox') {
          const labels = (q.options || []).map((x) => x.replace(/ ✓$/, '')); const wants = q.type === 'checkbox' ? (Array.isArray(a) ? a : String(a).split(/[、,，;；|\n]+/)).map((x) => x.trim()).filter(Boolean) : [Array.isArray(a) ? a[0] : a];
          const miss = [];
          for (const w of wants) {
            let oi = pickOption(labels, w); let other = false;
            if (oi < 0) { oi = (await b.evalPage(`(qi) => window.__lf[qi].opts.findIndex((o) => o.other)`, qi)); other = oi >= 0; }
            if (oi < 0) { miss.push(w); continue; }
            if (!other) other = await b.evalPage('(qi, oi) => !!window.__lf[qi].opts[oi].other', qi, oi);
            const c = await b.evalPage(PAGE.formCenter, qi, oi); if (c.err) throw new Error(c.err);
            if (!(q.type === 'checkbox' && c.checked)) { await b.clickAt(c.x, c.y); await sleep(200); }
            if (other) { const t = await b.evalPage(PAGE.formOtherInput, qi); const txt = String(w).replace(/^(其他|other)\s*[:：]?\s*/i, '').trim(); if (t && txt) { await b.clickAt(t.x, t.y); await b.insertText(txt); } }
          }
          if (miss.length) throw new Error(`選項裡沒有「${miss.join('、')}」（可選：${labels.join(' / ')}）`);
        }
        else if (q.type === 'dropdown') {
          const c = await b.evalPage(PAGE.formCenter, qi, -1); if (c.err) throw new Error(c.err); await b.clickAt(c.x, c.y); await sleep(500);
          const opts = await b.evalPage(PAGE.formDropdownOptions, qi).then((l) => l.filter((o) => o.label && !/^(選擇|Choose)$/i.test(o.label)));
          const oi = pickOption(opts.map((o) => o.label), a); if (oi < 0) { await b.key('Escape'); throw new Error(`下拉選單沒有「${a}」（可選：${opts.map((o) => o.label).join(' / ')}）`); }
          await b.clickAt(opts[oi].x, opts[oi].y); await sleep(350);
        }
        else if (q.type === 'grid') {
          const rows = q.rows; const pairs = Array.isArray(a) ? a.map((v, i) => [rows[i] && rows[i].row, v]) : Object.entries(a || {});
          for (const [rowLabel, choice] of pairs) { const ri = rows.findIndex((x) => norm(x.row) === norm(rowLabel) || norm(x.row).includes(norm(rowLabel))); if (ri < 0) throw new Error(`格線沒有列「${rowLabel}」`); const ci = pickOption(rows[ri].choices, choice); if (ci < 0) throw new Error(`列「${rowLabel}」沒有選項「${choice}」`); const c = await b.evalPage(PAGE.formCenter, qi, ci, ri); await b.clickAt(c.x, c.y); await sleep(150); }
        }
        else throw new Error('不支援的題型：' + q.type);
        const st = await b.evalPage(PAGE.formState, qi); res.push(`✓ Q${qi}「${q.title.slice(0, 30)}」→ ${st ? (st.value !== undefined ? st.value : (st.checked || []).join('、')) : '已填'}`);
      } catch (e) { res.push(`✗ Q${qi}「${(q.title || '').slice(0, 30)}」：${e.message}`); }
    }
    let nav = '';
    if (then === 'next' || then === 'submit') {
      const re = then === 'next' ? '^(下一頁|下一步|Next)$' : '^(提交|送出|Submit)$'; const btn = await b.evalPage(PAGE.findButton, re);
      if (!btn) nav = `找不到「${then === 'next' ? '下一頁' : '提交'}」按鈕。`;
      else { await b.clickAt(btn.x, btn.y); await sleep(1500); await b.waitLoad(8000); await b.afterAction(); nav = `已按「${btn.label}」。`; }
    }
    const r = await b.evalPage(PAGE.formRead).catch(() => null);
    let tail = ''; if (r) tail = r.done ? '\n\n' + this.fmtForm(r) : `\n\n${then === 'none' ? '（尚未翻頁／提交）' : ''}目前頁面：\n${this.fmtForm(r)}`;
    const failed = res.some((x) => x.startsWith('✗'));
    return { ok: !failed, done: !!(r && r.done), text: `${res.join('\n')}\n${nav}${tail}`.trim() };
  }
}
module.exports = { Google, pickOption, norm };
