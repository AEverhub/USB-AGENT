'use strict';
/** 重要事件即時推播（瓶頸 4）：App 內通知中心 ＋ Android 系統通知 ＋ 管理員私訊 ＋ 外部 webhook ＋ ntfy。 */
const { logger, bus } = require('../core/log');
const { fetchJson } = require('../core/util');
const log = logger('notify');
const LV = { info: 0, warn: 1, error: 2, critical: 3 };

class Notifier {
  constructor(ctx) { this.ctx = ctx; this.recent = new Map(); }
  async push(level, title, text = '', opt = {}) {
    const { settings, store } = this.ctx; const cfg = settings.get('notify');
    // 去重：同標題 60 秒內只發一次
    const k = level + title; const last = this.recent.get(k); if (last && Date.now() - last < 60000 && !opt.force) return null; this.recent.set(k, Date.now());
    const n = { id: store.nextId('notif'), ts: Date.now(), level, title, text: String(text).slice(0, 1500), read: false };
    store.db.notifications.push(n); if (store.db.notifications.length > 300) store.db.notifications.shift(); store.touch();
    bus.emit('notify', n);
    if (opt.quiet || (LV[level] ?? 0) < (LV[cfg.min_level] ?? 1)) return n;   // quiet：系統自我診斷類，只進通知中心，不私訊／不推外部       // 低於門檻：只進通知中心
    const body = `【${title}】\n${n.text}`;
    const jobs = [];
    if (cfg.to_admin_dm && this.ctx.hub) jobs.push(this.ctx.hub.notifyAdmins(`${level === 'critical' ? '🚨' : level === 'error' ? '❗' : '⚠️'} ${body}`).catch((e) => log.warn('DM 通知失敗', e.message)));
    if (cfg.webhook_url) jobs.push(fetchJson(cfg.webhook_url, { method: 'POST', headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ app: 'line-agent', level, title, text: n.text, ts: n.ts, content: body, text_plain: body }) }, 15000).catch((e) => log.warn('webhook 失敗', e.message)));
    if (cfg.ntfy_topic) jobs.push(fetchJson(`${(cfg.ntfy_server || 'https://ntfy.sh').replace(/\/$/, '')}/${encodeURIComponent(cfg.ntfy_topic)}`, { method: 'POST',
      headers: { Title: encodeURIComponent(title), Priority: level === 'critical' ? '5' : level === 'error' ? '4' : '3' }, body: n.text }, 15000).catch((e) => log.warn('ntfy 失敗', e.message)));
    await Promise.all(jobs); return n;
  }
  info(t, x) { return this.push('info', t, x); } warn(t, x) { return this.push('warn', t, x); }
  error(t, x) { return this.push('error', t, x); } critical(t, x) { return this.push('critical', t, x, { force: true }); }
  list(since = 0) { return this.ctx.store.db.notifications.filter((n) => n.id > since); }
}
module.exports = { Notifier };
