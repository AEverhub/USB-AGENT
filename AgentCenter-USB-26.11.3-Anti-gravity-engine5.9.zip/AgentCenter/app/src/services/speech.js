'use strict';
/**
 * 語音轉文字：LINE／Telegram／Discord 的語音訊息 → 文字，再交給 AI。
 * 順序（speech.provider=auto）：Groq Whisper（快又便宜）→ OpenAI → Gemini（直接聽音檔）。
 * 金鑰沿用「模型」頁的金鑰池，不需要另外設定。
 */
const llm = require('../llm');
const { logger } = require('../core/log');
const log = logger('speech');

const EXT = { 'audio/ogg': 'ogg', 'audio/opus': 'ogg', 'audio/mpeg': 'mp3', 'audio/mp3': 'mp3', 'audio/mp4': 'm4a', 'audio/m4a': 'm4a', 'audio/x-m4a': 'm4a', 'audio/aac': 'aac', 'audio/wav': 'wav', 'audio/x-wav': 'wav', 'audio/webm': 'webm', 'audio/flac': 'flac', 'video/mp4': 'mp4' };
// Gemini 吃的音訊類型；m4a（AAC in MP4）以 audio/aac 送
const GEM_MIME = { ogg: 'audio/ogg', mp3: 'audio/mp3', m4a: 'audio/aac', aac: 'audio/aac', wav: 'audio/wav', flac: 'audio/flac', webm: 'audio/webm', mp4: 'audio/aac' };
const MAX = 20 * 1024 * 1024;

class Speech {
  constructor(ctx) { this.ctx = ctx; }
  cfg() { return { provider: 'auto', language: 'zh', ...(this.ctx.settings.get('speech', {}) || {}) }; }
  enabled() { return this.cfg().enabled !== false; }
  _key(p) { const c = llm.keyCandidates(this.ctx.settings, p).find(llm.usable); return c && c.key; }
  /** 可用的轉寫管道（依優先順序） */
  routes() {
    const want = this.cfg().provider; const all = ['groq', 'openai', 'gemini'].filter((p) => this._key(p));
    return want && want !== 'auto' ? all.filter((p) => p === want) : all;
  }
  async transcribe(audio) {
    if (!this.enabled()) throw new Error('管理員已關閉語音轉文字');
    const buf = Buffer.isBuffer(audio.buf) ? audio.buf : Buffer.from(audio.data || '', 'base64');
    if (!buf.length) throw new Error('語音檔是空的'); if (buf.length > MAX) throw new Error('語音檔超過 20MB');
    const ext = EXT[String(audio.mime || '').split(';')[0].toLowerCase()] || 'ogg';
    const routes = this.routes(); if (!routes.length) throw new Error('沒有可用的語音轉文字金鑰（模型頁加入 Groq、OpenAI 或 Gemini 任一家的金鑰即可）');
    let last;
    for (const p of routes) {
      try { const t = p === 'gemini' ? await this._gemini(buf, ext) : await this._whisper(p, buf, ext); if (t && t.trim()) return { text: t.trim(), provider: p }; last = new Error('沒有辨識出內容'); }
      catch (e) { last = e; log.warn(`${p} 轉寫失敗：${e.message}`); }
    }
    throw last || new Error('語音轉文字失敗');
  }
  async _whisper(p, buf, ext) {
    const url = p === 'groq' ? 'https://api.groq.com/openai/v1/audio/transcriptions' : 'https://api.openai.com/v1/audio/transcriptions';
    const model = this.cfg()[p + '_model'] || (p === 'groq' ? 'whisper-large-v3-turbo' : 'whisper-1');
    const fd = new FormData(); fd.append('file', new Blob([buf]), `voice.${ext}`); fd.append('model', model); const lang = this.cfg().language; if (lang) fd.append('language', lang); fd.append('response_format', 'json');
    const r = await fetch(url, { method: 'POST', headers: { authorization: 'Bearer ' + this._key(p) }, body: fd, signal: AbortSignal.timeout(60000) });
    const j = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(`${p} ${r.status}：${(j.error && (j.error.message || j.error)) || ''}`.slice(0, 200));
    return String(j.text || '');
  }
  async _gemini(buf, ext) {
    const S = this.ctx.settings; const model = this.cfg().gemini_model || (S.get('model.provider') === 'gemini' ? S.get('model.name') : '') || llm.modelFor(S, 'gemini');
    const body = { contents: [{ role: 'user', parts: [{ inlineData: { mimeType: GEM_MIME[ext] || 'audio/ogg', data: buf.toString('base64') } }, { text: '把這段語音逐字轉寫成文字（中文用繁體）。只輸出轉寫內容，不要加任何說明；聽不清楚的地方用「…」。' }] }], generationConfig: { maxOutputTokens: 2048 } };
    const j = await llm.post(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent`, { 'x-goog-api-key': this._key('gemini') }, body, 'Gemini', true);
    const parts = (((j.candidates || [])[0] || {}).content || {}).parts || []; return parts.filter((x) => x.text && !x.thought).map((x) => x.text).join('');
  }
}
module.exports = { Speech };
