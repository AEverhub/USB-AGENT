'use strict';
const { evaluate } = require('./calc');
const { r2 } = require('../core/util');

const colName = (i) => { let s = ''; i++; while (i > 0) { const m = (i - 1) % 26; s = String.fromCharCode(65 + m) + s; i = Math.floor((i - 1) / 26); } return s; };
const colIndex = (s) => { let n = 0; for (const c of s) n = n * 26 + c.charCodeAt(0) - 64; return n - 1; };

/** 一般試算表：第 1 列是標題列（headers），資料列 rows 是二維陣列；以「=」開頭是公式。 */
class Sheets {
  constructor(ctx) { this.ctx = ctx; }
  get list_() { return this.ctx.store.db.sheets; }
  list(owner = null) { return this.list_.filter((s) => !owner || s.owner === owner || s.owner === '*').map((s) => ({ id: s.id, name: s.name, owner: s.owner, rows: s.rows.length, cols: s.headers.length, version: s.version, updated: s.updated })); }
  get(idOrName, owner = null) {
    const q = String(idOrName);
    return this.list_.find((s) => (String(s.id) === q || s.name === q) && (!owner || s.owner === owner || s.owner === '*')) || null;
  }
  create(name, headers, owner = '*', rows = []) {
    if (!name) throw new Error('要有表名');
    if (this.list_.some((s) => s.name === name && s.owner === owner)) throw new Error(`已經有「${name}」這張表`);
    const s = { id: this.ctx.store.nextId('sheet'), name, owner, headers: headers.map(String), rows: rows.map((r) => [...r]), version: 1, versions: [], created: Date.now(), updated: Date.now() };
    this.list_.push(s); this.ctx.store.touch(); return s;
  }
  _snap(s, note) { s.versions.push({ v: s.version, headers: [...s.headers], rows: JSON.parse(JSON.stringify(s.rows)), note, ts: Date.now() }); if (s.versions.length > 15) s.versions.shift(); s.version++; s.updated = Date.now(); this.ctx.store.touch(); }
  addRows(s, rows, who = '') { this._snap(s, `${who} 新增 ${rows.length} 列`); for (const r of rows) { const row = [...r]; while (row.length < s.headers.length) row.push(''); s.rows.push(row); } return s; }
  setCell(s, ref, value, who = '') {
    const m = /^([A-Za-z]{1,3})(\d+)$/.exec(String(ref).trim()); if (!m) throw new Error('儲存格格式像 B3');
    const c = colIndex(m[1].toUpperCase()), r = +m[2] - 2; // 第 1 列是標題，所以資料第 1 列是 2
    if (m[2] === '1') { this._snap(s, `${who} 改標題 ${ref}`); while (s.headers.length <= c) s.headers.push(''); s.headers[c] = String(value); return s; }
    if (r < 0 || r > s.rows.length + 500) throw new Error('列號超出範圍');
    this._snap(s, `${who} 改 ${ref}`); while (s.rows.length <= r) s.rows.push(new Array(s.headers.length).fill(''));
    while (s.headers.length <= c) { s.headers.push(''); for (const row of s.rows) row.push(''); }
    s.rows[r][c] = typeof value === 'string' && value.trim() !== '' && !value.startsWith('=') && !isNaN(value) ? Number(value) : value; return s;
  }
  deleteRows(s, from, to, who = '') { this._snap(s, `${who} 刪列 ${from}-${to}`); s.rows.splice(from - 2, to - from + 1); return s; }
  remove(s) { const i = this.list_.indexOf(s); if (i >= 0) this.list_.splice(i, 1); this.ctx.store.touch(); }
  restore(s, version) {
    const v = s.versions.find((x) => x.v === +version); if (!v) throw new Error('沒有這個版本');
    this._snap(s, `還原到 v${version}`); s.headers = [...v.headers]; s.rows = JSON.parse(JSON.stringify(v.rows)); return s;
  }
  /** 計算整張表：公式出錯只標那一格 */
  computed(s) {
    const cache = new Map(); const stack = new Set();
    const cell = (c, r) => (r === -1 ? s.headers[c] : (s.rows[r] || [])[c]);
    const val = (c, r) => {
      const key = c + ',' + r; if (cache.has(key)) return cache.get(key);
      let raw = cell(c, r); if (raw == null) raw = '';
      let out = raw;
      if (typeof raw === 'string' && raw.startsWith('=')) {
        if (stack.has(key)) { out = '#循環'; } else { stack.add(key);
          try { out = evaluate(raw, resolve); } catch (e) { out = '#錯誤:' + e.message; } finally { stack.delete(key); } }
      }
      cache.set(key, out); return out;
    };
    const resolve = (ref) => {
      const m = /^([A-Z]+)(\d+)(?::([A-Z]+)(\d+))?$/.exec(ref); if (!m) throw new Error('參照錯誤 ' + ref);
      const c1 = colIndex(m[1]), r1 = +m[2] - 2;
      if (!m[3]) { const v = val(c1, r1); if (typeof v === 'string' && v.startsWith('#')) throw new Error(v); return v === '' ? 0 : v; }
      const c2 = colIndex(m[3]), r2_ = +m[4] - 2; const out = [];
      for (let r = Math.min(r1, r2_); r <= Math.max(r1, r2_); r++) for (let c = Math.min(c1, c2); c <= Math.max(c1, c2); c++) out.push(val(c, r));
      return out;
    };
    return s.rows.map((row, r) => s.headers.map((_, c) => { const v = val(c, r); return typeof v === 'number' ? r2(v * 1e6) / 1e6 : v; }));
  }
  view(s, max = 60) {
    const comp = this.computed(s); const lines = [`# ${s.name}（v${s.version}，${s.rows.length} 列）`, '| # | ' + s.headers.map((h, i) => `${colName(i)}:${h}`).join(' | ') + ' |'];
    comp.slice(0, max).forEach((r, i) => lines.push(`| ${i + 2} | ${r.join(' | ')} |`));
    if (comp.length > max) lines.push(`…還有 ${comp.length - max} 列`);
    return lines.join('\n');
  }
  toCSV(s) {
    const esc = (v) => { v = v == null ? '' : String(v); return /[",\n]/.test(v) ? '"' + v.replace(/"/g, '""') + '"' : v; };
    const comp = this.computed(s); return '\ufeff' + [s.headers, ...comp].map((r) => r.map(esc).join(',')).join('\r\n');
  }
}
module.exports = { Sheets, colName, colIndex };
