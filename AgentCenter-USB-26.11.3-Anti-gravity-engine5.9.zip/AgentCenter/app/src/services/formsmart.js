'use strict';
/**
 * 表單「聰明層」：純函式（不連網路），給 gws.js 的表單通道使用。
 *  ・matchOption：把模型給的自然語言答案對到表單上的選項（同義詞、中文數字、數字區間、相似度、歧義偵測）
 *  ・parseDate／parseTime：2026/1/2、115年3月5日（民國）、3/5、明天、下午三點半、3:30pm …
 *  ・findQuestion：用題號或「題目文字」找題（模型常把題號記錯）
 *  ・suggestFromFacts：用管理員的長期事實自動推薦答案；身分證／帳號密碼一律不自動填
 *  ・extractArray：不靠脆弱的正規式，用括號配對從 HTML 抓出 FB_PUBLIC_LOAD_DATA_
 */

const norm = (s) => String(s ?? '').normalize('NFKC').toLowerCase().replace(/[\s　.,;:!?()（）、，。：；！？"'「」『』\-_/\\*＊·•]+/g, '');
const CN = { 零: 0, 〇: 0, 一: 1, 二: 2, 兩: 2, 三: 3, 四: 4, 五: 5, 六: 6, 七: 7, 八: 8, 九: 9 };
/** 一～九十九 的中文數字 → 數字；不是中文數字回 null */
function cn2num(s) {
  s = String(s || '').trim(); if (!s) return null; if (/^\d+$/.test(s)) return +s; if (!/^[零〇一二兩三四五六七八九十]+$/.test(s)) return null;
  if (s === '十') return 10; const m = /^([一二兩三四五六七八九])?十([一二三四五六七八九])?$/.exec(s); if (m) return (m[1] ? CN[m[1]] : 1) * 10 + (m[2] ? CN[m[2]] : 0);
  if (s.length === 1 && s in CN) return CN[s]; return null;
}
/** 把字串裡的中文數字換成阿拉伯數字（「第三名」→「第3名」、「二十人」→「20人」） */
const digitize = (s) => String(s).replace(/[零〇一二兩三四五六七八九十]+/g, (m) => { const n = cn2num(m); return n == null ? m : String(n); });

function bigrams(s) { s = norm(s); if (s.length < 2) return s ? [s] : []; const o = []; for (let i = 0; i < s.length - 1; i++) o.push(s.slice(i, i + 2)); return o; }
function similarity(a, b) {
  const A = bigrams(a), B = bigrams(b); if (!A.length || !B.length) return 0; const m = new Map(); for (const x of A) m.set(x, (m.get(x) || 0) + 1); let hit = 0;
  for (const x of B) { const c = m.get(x); if (c > 0) { hit++; m.set(x, c - 1); } } return (2 * hit) / (A.length + B.length);
}

// ---------- 同義詞：是／否、性別 ----------
const YES = ['是', '有', '對', '要', '好', '可以', '同意', '願意', '會', '參加', '出席', '需要', 'yes', 'y', 'true', 'ok', 'okay', '是的', '沒問題', '行'];
const NO = ['否', '沒有', '無', '不', '不是', '不要', '不用', '不需要', '不同意', '不願意', '不會', '不參加', '不出席', '不可以', '沒', '不行', 'no', 'n', 'false', '免'];
const GENDER = [['男', '男性', '男生', 'male', 'm', '先生', 'boy'], ['女', '女性', '女生', 'female', 'f', '小姐', '女士', 'girl']];
const inList = (list, n) => list.some((x) => norm(x) === n);
/** 傳回 'yes'｜'no'｜null（label 或答案屬於哪一邊） */
function polarity(s) {
  const n = norm(s); if (!n) return null; if (inList(NO, n)) return 'no'; if (inList(YES, n)) return 'yes';
  if (/^(不|沒|無|否|免)/.test(n)) return 'no'; const first = n.slice(0, 2); if (inList(YES, first) || inList(YES, n.slice(0, 1))) return 'yes'; return null;
}

/** 數字／區間（「3」「3-5人」「5人以上」「10以下」） */
function rangeOf(label) {
  const t = digitize(norm(label)); let m = /(\d+(?:\.\d+)?)[~\-–—到至](\d+(?:\.\d+)?)/.exec(t); if (m) return { lo: +m[1], hi: +m[2] };
  m = /(\d+(?:\.\d+)?)(?:[^\d]{0,2})(以上|\+|含以上|up)/.exec(t); if (m) return { lo: +m[1], hi: Infinity }; m = /(\d+(?:\.\d+)?)(?:[^\d]{0,2})(以下|含以下|以內|內)/.exec(t); if (m) return { lo: -Infinity, hi: +m[1] };
  m = /^[^\d]{0,2}(\d+(?:\.\d+)?)[^\d]{0,3}$/.exec(t); if (m) return { lo: +m[1], hi: +m[1], exact: true }; return null;
}

/**
 * labels: 選項文字陣列；want: 想選的字。回傳 { i, how, score, ambiguous? }；i=-1 表示對不到。
 * opts.scale: 量表（標籤多為數字）才啟用「很滿意→最高分」這類語意對應。
 */
function matchOption(labels, want, opts = {}) {
  const W = norm(want); if (!W) return { i: -1, how: 'empty' }; const L = labels.map(norm); let i = L.findIndex((l) => l === W); if (i >= 0) return { i, how: 'exact', score: 1 };
  const dW = digitize(W); const dL = L.map(digitize); i = dL.findIndex((l) => l === dW); if (i >= 0) return { i, how: 'digits', score: 0.98 };
  // 是／否、性別
  const pw = polarity(want); if (pw) { const hits = labels.map((l, k) => [k, polarity(l)]).filter(([, p]) => p === pw).map(([k]) => k); if (hits.length === 1) return { i: hits[0], how: 'yesno', score: 0.9 }; if (hits.length > 1) { const best = hits.map((k) => [k, similarity(labels[k], want)]).sort((a, b) => b[1] - a[1]); if (best[0][1] > best[1][1] + 0.15) return { i: best[0][0], how: 'yesno', score: 0.8 }; } }
  for (const g of GENDER) { if (inList(g, W)) { const k = L.findIndex((l) => inList(g, l) || g.some((x) => l.startsWith(norm(x)) && norm(x).length >= 1 && l.length <= 4)); if (k >= 0) return { i: k, how: 'gender', score: 0.9 }; } }
  // 量表語意
  if (opts.scale && labels.length >= 2) {
    const nums = labels.map((l) => parseFloat(l)); if (nums.every((x) => !isNaN(x))) {
      const hi = /(非常|很|十分|最).{0,2}(滿意|同意|好|棒|推薦|喜歡|高)|^(最高|最好|滿分)/, lo = /(非常|很|十分|最).{0,2}(不滿意|不同意|差|糟|不推薦|不喜歡|低)|^(最低|最差|零分)/, mid = /^(普通|中立|沒意見|還好|一般)$/;
      if (lo.test(W) || /不滿意|不同意|很差/.test(W)) return { i: nums.indexOf(Math.min(...nums)), how: 'scale-low', score: 0.7 }; if (hi.test(W)) return { i: nums.indexOf(Math.max(...nums)), how: 'scale-high', score: 0.7 }; if (mid.test(W)) return { i: Math.floor((labels.length - 1) / 2), how: 'scale-mid', score: 0.6 };
    }
  }
  // 數字落在區間
  const n = /^-?\d+(?:\.\d+)?$/.test(dW.replace(/[^\d.\-]/g, '')) && dW.replace(/[^\d.\-]/g, '') === dW ? +dW : null;
  if (n != null) { const hits = labels.map((l, k) => [k, rangeOf(l)]).filter(([, r]) => r && n >= r.lo && n <= r.hi); if (hits.length === 1) return { i: hits[0][0], how: 'range', score: 0.85 }; if (hits.length > 1) { const ex = hits.filter(([, r]) => r.exact); if (ex.length === 1) return { i: ex[0][0], how: 'range', score: 0.85 }; return { i: -1, how: 'ambiguous', ambiguous: hits.map(([k]) => labels[k]) }; } }
  // 包含（至少 2 字）
  const cont = L.map((l, k) => [k, l, dL[k]]).filter(([, l, d]) => (l.length >= 2 && (W.includes(l) || l.includes(W) && W.length >= 2)) || (d.length >= 2 && (dW.includes(d) || (d.includes(dW) && dW.length >= 2))));
  if (cont.length === 1) return { i: cont[0][0], how: 'contains', score: 0.8 };
  if (cont.length > 1) { const best = cont.map(([k, l]) => [k, similarity(l, W) + (W.includes(l) ? l.length / (W.length + 1) : 0)]).sort((a, b) => b[1] - a[1]); if (best[0][1] > best[1][1] + 0.1) return { i: best[0][0], how: 'contains', score: 0.75 }; return { i: -1, how: 'ambiguous', ambiguous: cont.map(([k]) => labels[k]) }; }
  // 相似度
  const sc = labels.map((l, k) => [k, similarity(l, want)]).sort((a, b) => b[1] - a[1]);
  if (sc[0] && sc[0][1] >= 0.5) { if (sc[1] && sc[1][1] >= sc[0][1] - 0.08 && sc[1][1] >= 0.5) return { i: -1, how: 'ambiguous', ambiguous: [labels[sc[0][0]], labels[sc[1][0]]] }; return { i: sc[0][0], how: 'similar', score: sc[0][1] }; }
  return { i: -1, how: 'none' };
}

// ---------- 日期／時間 ----------
const pad = (n) => String(n).padStart(2, '0');
const validDate = (y, m, d) => { const t = new Date(Date.UTC(y, m - 1, d)); return t.getUTCFullYear() === y && t.getUTCMonth() === m - 1 && t.getUTCDate() === d; };
/** 「下午三點半」「3:30pm」「15時30分」「晚上8點」「中午」→ {h,mi}；對不到回 null */
function parseTime(s) {
  let t = digitize(String(s || '').normalize('NFKC').trim().toLowerCase()); if (!t) return null;
  let period = ''; const pm = /(下午|晚上|晚間|傍晚|午後|pm|p\.m\.)/.exec(t), am = /(上午|早上|早晨|凌晨|清晨|am|a\.m\.)/.exec(t), noon = /(中午|正午)/.test(t); if (pm) period = 'pm'; else if (am) period = 'am'; else if (noon) period = 'noon';
  t = t.replace(/(下午|晚上|晚間|傍晚|午後|上午|早上|早晨|凌晨|清晨|中午|正午|pm|am|p\.m\.|a\.m\.)/g, ' ');
  let h = null, mi = 0, m;
  if ((m = /(\d{1,2})\s*[:：]\s*(\d{2})/.exec(t))) { h = +m[1]; mi = +m[2]; } else if ((m = /(\d{1,2})\s*[點时時h]\s*(半|(\d{1,2})\s*分?)?/.exec(t))) { h = +m[1]; mi = m[2] === '半' ? 30 : (m[3] ? +m[3] : 0); } else if ((m = /^\s*(\d{1,2})\s*$/.exec(t)) && period) { h = +m[1]; } else if (period === 'noon') { h = 12; } else return null;
  if (period === 'pm' && h < 12) h += 12; if (period === 'am' && h === 12) h = 0; if (period === 'noon' && h < 11) h += 12; if (h > 23 || mi > 59) return null; return { h, mi };
}
/** 回傳 {y,mo,d,h,mi}（h／mi 沒給＝null）；now 用來補年份與「明天」 */
function parseDate(s, now = new Date()) {
  let t = digitize(String(s || '').normalize('NFKC').trim()); if (!t) return null; const base = new Date(now.getTime() + 8 * 3600e3); const Y = base.getUTCFullYear(), M = base.getUTCMonth() + 1, D = base.getUTCDate(); let y = null, mo = null, d = null, rest = t, m;
  const rel = { 今天: 0, 今日: 0, 明天: 1, 明日: 1, 後天: 2, 昨天: -1, 大後天: 3 }; const rk = Object.keys(rel).find((k) => t.includes(k)); if (rk) { const x = new Date(Date.UTC(Y, M - 1, D + rel[rk])); y = x.getUTCFullYear(); mo = x.getUTCMonth() + 1; d = x.getUTCDate(); rest = t.replace(rk, ' '); }
  else if ((m = /(?:民國|民)?\s*(\d{1,4})\s*年\s*(\d{1,2})\s*月\s*(\d{1,2})\s*[日號号]?/.exec(t))) { y = +m[1]; mo = +m[2]; d = +m[3]; rest = t.replace(m[0], ' '); if (/民國|民/.test(m[0]) && y < 1911) y += 1911; }
  else if ((m = /(\d{1,4})\s*[-/.]\s*(\d{1,2})\s*[-/.]\s*(\d{1,2})/.exec(t))) { y = +m[1]; mo = +m[2]; d = +m[3]; rest = t.replace(m[0], ' '); }
  else if ((m = /(\d{1,2})\s*月\s*(\d{1,2})\s*[日號号]?/.exec(t)) || (m = /^\s*(\d{1,2})\s*[/.]\s*(\d{1,2})(?=\D|$)/.exec(t))) { mo = +m[1]; d = +m[2]; y = Y; rest = t.replace(m[0], ' '); }
  else if ((m = /^(\d{4})(\d{2})(\d{2})$/.exec(t.replace(/\s/g, '')))) { y = +m[1]; mo = +m[2]; d = +m[3]; rest = ''; }
  else return null;
  if (y < 1000 && y > 0) y += 1911;   // 115/3/5：三位數年份＝民國
  if (!validDate(y, mo, d)) return null; const tm = rest.trim() ? parseTime(rest) : null; return { y, mo, d, h: tm ? tm.h : null, mi: tm ? tm.mi : null };
}

// ---------- 找題 ----------
/** ref 可以是題號（0、"0"）或題目文字（「姓名」「聯絡電話」）；找不到或歧義丟錯 */
function findQuestion(questions, ref) {
  if (typeof ref === 'number' || /^\s*\d+\s*$/.test(String(ref))) { const q = questions[+ref]; if (q) return q; if (typeof ref === 'number') throw new Error(`題號 ${ref} 不存在（共 ${questions.length} 題，題號從 0 開始）`); }
  const R = norm(ref); if (!R) throw new Error('題號／題目文字是空的'); let c = questions.filter((q) => norm(q.title) === R); if (c.length === 1) return c[0];
  c = questions.filter((q) => norm(q.title).includes(R) || (norm(q.title).length >= 2 && R.includes(norm(q.title)))); if (c.length === 1) return c[0];
  const sc = questions.map((q) => [q, similarity(q.title, ref)]).sort((a, b) => b[1] - a[1]); if (sc[0] && sc[0][1] >= 0.5 && (!sc[1] || sc[0][1] > sc[1][1] + 0.1)) return sc[0][0];
  const cand = (c.length > 1 ? c : sc.slice(0, 3).map((x) => x[0])).map((q) => `[${q.i}]${q.title}`).join('、'); throw new Error(`找不到或不確定是哪一題：「${ref}」。可能是：${cand}`);
}

// ---------- 用長期事實推薦答案 ----------
const SENSITIVE = /身分證|身份證|統一編號|護照|居留證|銀行帳|帳戶|帳號.*密碼|密碼|信用卡|卡號|cvv|驗證碼|otp|national\s*id|passport|ssn|social security|bank account|password|credit card/i;
const INTENTS = [
  ['email', /e-?mail|電子郵件|電郵|信箱|郵件地址|email/i], ['phone', /電話|手機|行動|聯絡號碼|phone|mobile|cell|tel\b/i], ['birthday', /生日|出生|birth|dob/i], ['address', /地址|住址|居住|通訊處|address/i],
  ['studentid', /學號|student\s*id/i], ['company', /公司|任職|服務單位|工作單位|機構|單位名稱|company|employer|organi[sz]ation/i], ['jobtitle', /職稱|職位|職務|job\s*title|position|title\b/i], ['school', /學校|校名|就讀|畢業學校|school|university/i],
  ['line', /line\s*id|line\s*帳號|line$/i], ['gender', /性別|gender|sex\b/i], ['age', /年齡|幾歲|age\b/i], ['name', /姓名|名字|全名|本名|稱呼|name\b/i],
];
const intentOf = (title) => { const t = String(title || ''); if (SENSITIVE.test(t)) return 'sensitive'; const hit = INTENTS.find(([, re]) => re.test(t)); return hit ? hit[0] : ''; };
const EXTRACT = {
  email: (f) => (/[\w.+-]+@[\w-]+(?:\.[\w-]+)+/.exec(f) || [])[0],
  phone: (f) => (/(?:\+?886[- ]?)?0?9\d{2}[- ]?\d{3}[- ]?\d{3}|0\d{1,2}[- ]?\d{3,4}[- ]?\d{4}/.exec(f) || [])[0],
  name: (f) => { const m = /(?:姓名|全名|本名|名字|我叫|我的名字)\s*[:：是為为]?\s*([一-龥·]{2,6}|[A-Za-z][A-Za-z .'-]{1,40})/.exec(f); return m && m[1].trim(); },
  birthday: (f) => { const m = /(?:生日|出生(?:日期)?)\s*[:：是為为]?\s*([^，。,;；\n]+)/.exec(f); return m && m[1].trim(); },
  address: (f) => { const m = /(?:地址|住址|通訊地址|戶籍地址|住在|居住(?:地)?)\s*[:：是為为在]?\s*([^\n。;；]+)/.exec(f); return m && m[1].trim(); },
  company: (f) => { const m = /(?:公司|任職(?:於)?|服務單位|工作單位|雇主)\s*[:：是為为]?\s*([^，。,;；\n]+)/.exec(f); return m && m[1].trim(); },
  jobtitle: (f) => { const m = /(?:職稱|職位|職務)\s*[:：是為为]?\s*([^，。,;；\n]+)/.exec(f); return m && m[1].trim(); },
  school: (f) => { const m = /(?:學校|就讀|畢業(?:於|學校))\s*[:：是為为]?\s*([^，。,;；\n]+)/.exec(f); return m && m[1].trim(); },
  studentid: (f) => { const m = /學號\s*[:：是為为]?\s*([A-Za-z0-9]{5,15})/.exec(f); return m && m[1]; },
  line: (f) => { const m = /line\s*(?:id|帳號)?\s*[:：是為为]?\s*([A-Za-z0-9._-]{3,30})/i.exec(f); return m && m[1]; },
  gender: (f) => { const m = /性別\s*[:：是為为]?\s*(男|女)/.exec(f); return m && m[1]; },
  age: (f) => { const m = /(\d{1,3})\s*歲/.exec(f); return m && m[1]; },
};
/** 事實裡「題目關鍵字：值」或「題目關鍵字是值」的通用取值（上面專用規則對不到時） */
function genericFact(facts, title) {
  const T = norm(title); if (T.length < 2) return null;
  for (const f of facts) { const m = /^(.{1,20}?)\s*[:：=]\s*(.+)$/.exec(String(f).trim()); if (m) { const k = norm(m[1]); if (k.length >= 2 && (k === T || T.includes(k) || k.includes(T))) return m[2].trim(); } }
  return null;
}
/**
 * 回傳 { suggestions:[{q,a,how,confidence}], missing:[{q,title}], sensitive:[{q,title}], unknown:[...] }
 * 選擇題會用 matchOption 對到實際選項；對不到就不猜（留給模型或管理員）。
 */
function suggestFromFacts(form, facts, now = new Date()) {
  const text = facts.join('\n'); const out = { suggestions: [], missing: [], sensitive: [], unmatched: [] };
  for (const q of form.questions) {
    if (q.type === 'file') continue; const intent = intentOf(q.title + ' ' + (q.desc || '')); if (intent === 'sensitive') { out.sensitive.push({ q: q.i, title: q.title }); if (q.required) out.missing.push({ q: q.i, title: q.title, why: '敏感資料，需管理員提供' }); continue; }
    let v = intent && EXTRACT[intent] ? EXTRACT[intent](text) : null; let how = intent ? 'fact:' + intent : '';
    if (!v) { v = genericFact(facts, q.title); if (v) how = 'fact:title'; }
    if (!v) { if (q.required) out.missing.push({ q: q.i, title: q.title }); continue; }
    let a = v;
    if (q.options) { const m = matchOption(q.options.filter((o) => !o.other).map((o) => o.label), v, { scale: q.type === 'scale' }); if (m.i >= 0) a = q.options.filter((o) => !o.other)[m.i].label; else { out.unmatched.push({ q: q.i, title: q.title, value: v }); if (q.required) out.missing.push({ q: q.i, title: q.title, why: `事實「${v}」對不到選項` }); continue; } }
    else if (q.type === 'date') { const d = parseDate(v, now); if (!d) { out.unmatched.push({ q: q.i, title: q.title, value: v }); continue; } a = `${d.y}-${pad(d.mo)}-${pad(d.d)}`; }
    else if (q.type === 'time') { const t = parseTime(v); if (!t) continue; a = `${pad(t.h)}:${pad(t.mi)}`; }
    out.suggestions.push({ q: q.i, title: q.title, a, how, confidence: intent && how.startsWith('fact:' + intent) ? 'high' : 'medium' });
  }
  return out;
}

// ---------- 從 HTML 抓 FB_PUBLIC_LOAD_DATA_（括號配對，字串內的括號不算）----------
function extractArray(html, marker = 'FB_PUBLIC_LOAD_DATA_') {
  let from = 0; for (;;) {
    const at = html.indexOf(marker, from); if (at < 0) return null; const eq = html.indexOf('=', at + marker.length); const start = eq < 0 ? -1 : html.indexOf('[', eq);
    if (start < 0 || start - eq > 12) { from = at + marker.length; continue; }
    let depth = 0, inStr = false, esc = false; for (let i = start; i < html.length; i++) {
      const c = html[i]; if (inStr) { if (esc) esc = false; else if (c === '\\') esc = true; else if (c === '"') inStr = false; continue; }
      if (c === '"') inStr = true; else if (c === '[') depth++; else if (c === ']') { depth--; if (depth === 0) { try { return JSON.parse(html.slice(start, i + 1)); } catch { return null; } } }
    } return null;
  }
}

module.exports = { norm, cn2num, digitize, similarity, matchOption, polarity, parseDate, parseTime, findQuestion, suggestFromFacts, intentOf, extractArray, SENSITIVE };
