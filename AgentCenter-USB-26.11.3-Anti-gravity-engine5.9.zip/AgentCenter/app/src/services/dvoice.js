'use strict';
/**
 * 26.11.3 Revise6：Discord 語音會議監聽的「收音程式」管理。
 *
 * 為什麼要另外一支程式：Discord 從 2026-03-01 起所有語音通話都強制端對端加密（DAVE），
 * 要聽得到聲音必須用支援 DAVE 的函式庫（@discordjs/voice 0.19＋@snazzah/davey），它需要 Node.js 22.12 以上；
 * 手機 App 內的 Node 是 18 版，所以收音程式跑在：
 *   ・local：後台本身就是 Node ≥ 22.12 而且有 npm（伺服器安裝版）→ 直接開子行程
 *   ・linux：手機的內建 Linux（Alpine 的 node/npm）或外部 Termux → 透過橋接執行
 * 流程：Bot（主程式的 Discord 連線）送 op 4 進語音頻道 → 拿到 session_id／token／endpoint → 交給收音程式
 *      → 收音程式依講者把 Opus 封包 POST 到 /api/meeting-ingest/<會議>（每場一組隨機 token）→ meeting.js 轉文字、整理重點。
 */
const fs = require('fs');
const path = require('path');
const { spawn, spawnSync } = require('child_process');
const { logger } = require('../core/log');
const log = logger('dvoice');
const SRC = path.join(__dirname, '..', '..', 'voice-worker');
const REMOTE_DIR = '/opt/agent-voice';
const verOk = (v) => { const m = /v?(\d+)\.(\d+)/.exec(String(v || '')); return !!m && (+m[1] > 22 || (+m[1] === 22 && +m[2] >= 12)); };

class DVoice {
  constructor(ctx) { this.ctx = ctx; this.runs = new Map(); this.job = null; this.localDir = path.join(ctx.paths.data, 'voice-worker'); }
  canLocal() { if (!verOk(process.version) || process.platform === 'android') return false; try { return spawnSync(process.platform === 'win32' ? 'npm.cmd' : 'npm', ['-v'], { timeout: 8000 }).status === 0; } catch { return false; } }
  embedded() { const L = this.ctx.linux; try { return !!(L && L.supported() && L.installed() && this.ctx.settings.get('termux.mode') === 'embedded'); } catch { return false; } }
  where() { if (this.canLocal()) return 'local'; if (this.embedded() || (this.ctx.termux && this.ctx.termux.ready())) return 'linux'; return ''; }
  localInstalled() { return fs.existsSync(path.join(this.localDir, 'node_modules', '@discordjs', 'voice', 'package.json')) && fs.existsSync(path.join(this.localDir, 'discord-listen.mjs')); }
  meta() { try { return JSON.parse(fs.readFileSync(path.join(this.ctx.paths.data, 'voice-worker.json'), 'utf8')); } catch { return {}; } }
  setMeta(x) { fs.writeFileSync(path.join(this.ctx.paths.data, 'voice-worker.json'), JSON.stringify({ ...this.meta(), ...x })); }
  state() {
    const w = this.where(); const m = this.meta(); const d = this.ctx.hub && this.ctx.hub.connectors && this.ctx.hub.connectors.discord;
    return { where: w, installed: w === 'local' ? this.localInstalled() : !!(m.linux_ok && m.linux_ver === this.version()), node: m.node || (w === 'local' ? process.version : ''), job: this.job, discord_ready: !!(d && d.ready), runs: [...this.runs.entries()].map(([id, r]) => ({ meeting: id, where: r.where, since: r.since })), last_error: m.error || '' };
  }
  version() { try { return JSON.parse(fs.readFileSync(path.join(SRC, 'package.json'), 'utf8')).version; } catch { return '0'; } }
  /** 安裝收音程式（約 1～5 分鐘；需要網路下載 npm 套件） */
  async install() {
    if (this.job && this.job.running) throw new Error('正在安裝中');
    const w = this.where(); if (!w) throw new Error('這台沒有可以跑收音程式的環境：手機請先到「瀏覽器」頁安裝內建 Linux（或設定外部 Termux）；伺服器需要 Node.js 22.12 以上與 npm。');
    this.job = { running: true, where: w, started: Date.now(), log: [], ok: null };
    const say = (t) => { this.job.log.push(String(t).slice(0, 300)); this.job.log = this.job.log.slice(-40); log.info('[收音程式] ' + t); };
    (async () => {
      try {
        if (w === 'local') {
          fs.mkdirSync(this.localDir, { recursive: true }); for (const f of ['package.json', 'discord-listen.mjs']) fs.copyFileSync(path.join(SRC, f), path.join(this.localDir, f));
          say('npm install（@discordjs/voice、@snazzah/davey）…');
          await new Promise((res, rej) => { const p = spawn(process.platform === 'win32' ? 'npm.cmd' : 'npm', ['install', '--omit=dev', '--no-audit', '--no-fund'], { cwd: this.localDir }); p.stdout.on('data', (d) => say(d)); p.stderr.on('data', (d) => say(d)); p.on('exit', (c) => (c === 0 ? res() : rej(new Error('npm install 失敗（' + c + '）')))); p.on('error', rej); });
          if (!this.localInstalled()) throw new Error('安裝後找不到 @discordjs/voice');
          this.setMeta({ node: process.version, error: '' });
        } else {
          const T = this.ctx.termux; await this._linuxUp();
          const v = await T.exec('node -v; npm -v', { timeout_s: 60 }); const nodeV = (/v\d+\.\d+\.\d+/.exec(v.out || '') || [''])[0]; say('Linux 的 Node.js：' + (nodeV || '找不到'));
          if (!verOk(nodeV)) { say('Node.js 太舊，嘗試升級（apk add nodejs-current）…'); await T.exec('(apk add --no-cache nodejs-current npm || apk upgrade --no-cache nodejs npm) 2>&1 | tail -5', { timeout_s: 600 }); const v2 = await T.exec('node -v', { timeout_s: 30 }); if (!verOk(v2.out)) throw new Error(`內建 Linux 的 Node.js 是 ${String(v2.out).trim() || '未知'}，需要 22.12 以上。請在終端機執行 apk upgrade 後再試。`); }
          await this._putFiles(); say('npm install（@discordjs/voice、@snazzah/davey）…');
          const r = await T.exec(`cd ${REMOTE_DIR} && npm install --omit=dev --no-audit --no-fund 2>&1 | tail -15 && node -e "import('@discordjs/voice').then(()=>console.log('VOICE_OK')).catch(e=>console.log('VOICE_FAIL '+e.message))"`, { timeout_s: 900 });
          say(r.out || ''); if (!/VOICE_OK/.test(r.out || '')) throw new Error('收音程式的套件載入失敗：' + String(r.out || '').split('\n').filter((x) => /VOICE_FAIL|ERR/.test(x)).join(' ').slice(0, 300));
          const nv = await T.exec('node -v', { timeout_s: 30 }); this.setMeta({ linux_ok: true, linux_ver: this.version(), node: String(nv.out || '').trim(), error: '' });
        }
        this.job.ok = true; say('完成');
      } catch (e) { this.job.ok = false; this.job.error = e.message; say('失敗：' + e.message); this.setMeta({ error: e.message }); }
      finally { this.job.running = false; }
    })();
    return this.state();
  }
  async _linuxUp() { const L = this.ctx.linux; if (this.embedded() && !L.running()) await L.start(); await this.ctx.termux.health(); }
  /** 把收音程式放進 Linux：內建 Linux 直接寫進 rootfs；外部 Termux 用橋接傳檔 */
  async _putFiles(extra = {}) {
    const files = { 'package.json': fs.readFileSync(path.join(SRC, 'package.json')), 'discord-listen.mjs': fs.readFileSync(path.join(SRC, 'discord-listen.mjs')), ...extra };
    if (this.embedded()) { const dir = path.join(this.ctx.linux.rootfs, REMOTE_DIR.slice(1)); fs.mkdirSync(dir, { recursive: true }); for (const [n, b] of Object.entries(files)) fs.writeFileSync(path.join(dir, n), b, { mode: 0o600 }); return REMOTE_DIR; }
    const T = this.ctx.termux; await T.exec(`mkdir -p ${REMOTE_DIR} 2>/dev/null || mkdir -p ~/agent-voice`, { timeout_s: 30 });
    for (const [n, b] of Object.entries(files)) { const rel = `tmp/agent-voice-${n}`; const f = this.ctx.fsx.resolve(rel, 'workspace'); fs.mkdirSync(path.dirname(f), { recursive: true }); fs.writeFileSync(f, b); try { await T.filePut(rel, `${REMOTE_DIR}/${n}`); } finally { fs.rmSync(f, { force: true }); } }
    return REMOTE_DIR;
  }
  /** 開始收音：join＝voiceJoin 拿到的 {guild_id, channel_id, user_id, session_id, token, endpoint} */
  async start(meetingId, join) {
    const w = this.where(); const st = this.state(); if (!w) throw new Error('沒有可以跑收音程式的環境（手機要先裝內建 Linux）'); if (!st.installed) throw new Error('還沒安裝 Discord 收音程式：到「更多 → 會議監聽」按「安裝 Discord 收音程式」（只要一次）');
    const api = this.ctx.api && this.ctx.api.port ? `http://127.0.0.1:${this.ctx.api.port}` : 'http://127.0.0.1:8765';
    const cfg = { api, meeting: meetingId, token: this.ctx.meeting.ingestToken(meetingId), guild_id: join.guild_id, channel_id: join.channel_id, user_id: join.user_id, session_id: join.session_id, endpoint: join.endpoint, voice_token: join.token, silence_ms: 1200 };
    if (w === 'local') {
      const p = spawn(process.execPath, [path.join(this.localDir, 'discord-listen.mjs')], { cwd: this.localDir, env: { ...process.env, AGENT_VOICE_CFG: JSON.stringify(cfg) }, stdio: ['ignore', 'ignore', 'pipe'] });
      let err = ''; p.stderr.on('data', (d) => { err = (err + d).slice(-1000); }); p.on('exit', (c) => { this.runs.delete(meetingId); if (c) { log.warn('收音程式結束 ' + c + '：' + err.slice(-300)); try { this.ctx.meeting.workerStatus(meetingId, { state: 'exited', error: c ? `收音程式結束（${c}）${err.slice(-200)}` : '' }); } catch { /* ignore */ } } });
      this.runs.set(meetingId, { where: w, proc: p, since: Date.now(), guild: join.guild_id });
    } else {
      const T = this.ctx.termux; await this._linuxUp(); const name = `run-${meetingId}.json`; await this._putFiles({ [name]: Buffer.from(JSON.stringify(cfg)) });
      const r = await T.exec(`cd ${REMOTE_DIR} && node discord-listen.mjs ${REMOTE_DIR}/${name}`, { background: true }); this.runs.set(meetingId, { where: w, job: r.id, since: Date.now(), guild: join.guild_id });
    }
    return { where: w };
  }
  async stop(meetingId) {
    const r = this.runs.get(meetingId); const m = this.ctx.meeting.get(meetingId); const d = this.ctx.hub && this.ctx.hub.connectors && this.ctx.hub.connectors.discord;
    if (m.discord && d) d.voiceLeave(m.discord.guild_id);   // Bot 離開語音頻道（收音程式也會在下一次心跳看到 stop 自己結束）
    if (!r) return; this.runs.delete(meetingId);
    setTimeout(() => { try { if (r.proc && r.proc.exitCode === null) r.proc.kill('SIGTERM'); if (r.job) this.ctx.termux.jobKill(r.job).catch(() => {}); } catch { /* ignore */ } }, 8000).unref();
  }
  /**
   * 一鍵：找頻道 → 開會議 → Bot 進頻道 → 啟動收音程式 →（預設）在頻道文字區公告正在記錄。
   * channel：頻道名稱或 ID；guild_id：限定伺服器（從 Discord 訊息叫的就用那個伺服器）；reply_channel：結束時把會議記錄貼回哪個文字頻道
   */
  async joinAndListen({ channel, guild_id = '', title = '', by = '', reply_channel = '' } = {}) {
    const d = this.ctx.hub && this.ctx.hub.connectors && this.ctx.hub.connectors.discord; if (!d || !d.ready) throw new Error('Discord Bot 還沒連線（設定頁 → 平台 → Discord）');
    const st = this.state(); if (!st.installed) throw new Error('還沒安裝 Discord 收音程式：到「更多 → 會議監聽」按「安裝 Discord 收音程式」（只要一次，需要內建 Linux 或伺服器版）。原因：Discord 語音從 2026 年 3 月起強制端對端加密，要另外的收音程式才聽得到。');
    const list = await d.findVoiceChannel(channel, guild_id); if (!list.length) throw new Error(`找不到語音頻道「${channel}」（Bot 要在那個伺服器裡，而且看得到該頻道）`);
    const exact = list.filter((c) => c.id === String(channel) || c.name.toLowerCase() === String(channel).toLowerCase()); const pick = exact.length === 1 ? exact[0] : list.length === 1 ? list[0] : null;
    if (!pick) throw new Error('有好幾個符合的語音頻道，請說清楚是哪一個：' + list.slice(0, 8).map((c) => `${c.name}（${c.guild || c.guild_id}）`).join('、'));
    const m = this.ctx.meeting.start({ title, source: 'discord', by, discord: { guild_id: pick.guild_id, channel_id: pick.id, channel_name: pick.name, reply_channel: reply_channel || '' } });
    try {
      const join = await d.voiceJoin(pick.guild_id, pick.id); const r = await this.start(m.id, join); this.ctx.meeting.workerStatus(m.id, { state: 'starting', where: r.where });
      if (this.ctx.meeting.cfg().announce !== false) d.send(pick.id, 'AI 會議記錄已開始：這個語音頻道的發言會被轉成文字並整理重點（管理員要求）。管理員可以隨時結束。').catch(() => {});
    } catch (e) { d.voiceLeave(pick.guild_id); try { await this.ctx.meeting.stop(m.id, { reason: e.message }); } catch { /* ignore */ } throw e; }
    return this.ctx.meeting.get(m.id);
  }
  /** Discord 換語音伺服器（很少見）：轉給收音程式 */
  gatewayEvent(t, d) { for (const [id, r] of this.runs) if (String(r.guild) === String(d.guild_id)) this.ctx.meeting.pushEvent(id, { t, d }); }
}
module.exports = { DVoice, verOk, REMOTE_DIR };
