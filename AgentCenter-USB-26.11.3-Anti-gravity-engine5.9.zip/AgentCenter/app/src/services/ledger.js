'use strict';
const { taipei, pad, r2, fromTaipei } = require('../core/util');
const { buildXlsx } = require('./xlsx');

const TAGS = { expense: ['必要支出', '非必要支出'], income: ['固定收入', '非固定收入'] };
const NEED = /(房租|租金|水費|電費|瓦斯|網路|電話|保險|貸款|學費|醫|藥|餐|飯|早餐|午餐|晚餐|交通|捷運|公車|油|停車|日用|菜|超市|通勤|托育|稅)/;
const FIXED = /(薪|工資|月薪|津貼|獎金|租金收入|利息|股息|退休|年金|補助)/;

/** 後備分類（模型沒給 tag、或 App 手動記帳時使用）；AI 自己記帳時由模型判斷 */
function classify(kind, note) {
  if (kind === 'income') return FIXED.test(note || '') ? '固定收入' : '非固定收入';
  return NEED.test(note || '') ? '必要支出' : '非必要支出';
}

const HEAD = ['項次', '日期', '時間', '收入/支出', '金額', '備註', 'AI提示', '餘額'];
const COLOR = { green: '#1e9e4a', red: '#d92d20', blue: '#1d4ed8', black: '#111111' };

class Ledger {
  constructor(ctx) { this.ctx = ctx; }
  get all() { return this.ctx.store.db.ledger; }
  add({ owner, kind, amount, note = '', tag = '', ts = Date.now() }) {
    if (!['income', 'expense'].includes(kind)) throw new Error('kind 必須是 income 或 expense');
    amount = Number(amount); if (!Number.isFinite(amount) || amount <= 0) throw new Error('金額必須是大於 0 的數字');
    if (!TAGS[kind].includes(tag)) tag = classify(kind, note);
    const e = { id: this.ctx.store.nextId('ledger'), owner: owner || '*', kind, amount: r2(amount), note: String(note).slice(0, 200), tag, ts };
    this.all.push(e); this.ctx.store.touch(); return e;
  }
  update(id, patch) {
    const e = this.all.find((x) => x.id === +id); if (!e) throw new Error('找不到這筆');
    if (patch.kind) e.kind = patch.kind; if (patch.amount != null) e.amount = r2(Math.abs(Number(patch.amount)));
    if (patch.note != null) e.note = String(patch.note); if (patch.ts) e.ts = patch.ts;
    if (!TAGS[e.kind].includes(patch.tag || e.tag)) e.tag = classify(e.kind, e.note); else if (patch.tag) e.tag = patch.tag;
    this.ctx.store.touch(); return e;
  }
  remove(id) { const i = this.all.findIndex((x) => x.id === +id); if (i < 0) throw new Error('找不到這筆'); this.all.splice(i, 1); this.ctx.store.touch(); }
  /** owner=null：全部；否則只看某人（含共用） */
  rows(owner = null) {
    const list = this.all.filter((e) => !owner || e.owner === owner).sort((a, b) => a.ts - b.ts || a.id - b.id);
    let bal = 0;
    return list.map((e, i) => {
      bal = r2(bal + (e.kind === 'income' ? e.amount : -e.amount)); // 四捨五入到分，避免浮點誤差
      const t = taipei(e.ts); const green = e.kind === 'income';
      return { id: e.id, owner: e.owner, no: pad(i + 1, Math.max(2, String(list.length).length)), date: `${t.y}/${pad(t.m)}/${pad(t.d)}`, time: `${pad(t.hh)}:${pad(t.mm)}`,
        kind: green ? '收入' : '支出', amount: e.amount, note: e.note, tag: e.tag, balance: bal,
        kindColor: green ? COLOR.green : COLOR.red, amountColor: green ? COLOR.green : COLOR.red, tagColor: green ? COLOR.green : COLOR.red,
        balanceColor: bal > 0 ? COLOR.blue : bal < 0 ? COLOR.red : COLOR.black, balanceText: bal < 0 ? '-' + Math.abs(bal) : String(bal) };
    });
  }
  summary(owner = null, days = 30) {
    const since = Date.now() - days * 864e5; let inc = 0, exp = 0; const byTag = {};
    for (const e of this.all) { if ((owner && e.owner !== owner) || e.ts < since) continue; if (e.kind === 'income') inc += e.amount; else exp += e.amount; byTag[e.tag] = r2((byTag[e.tag] || 0) + e.amount); }
    const rows = this.rows(owner); return { days, income: r2(inc), expense: r2(exp), net: r2(inc - exp), balance: rows.length ? rows[rows.length - 1].balance : 0, byTag, count: rows.length };
  }
  /** 回給前端／匯出用的版面描述：1–2 列合併標題、第 3 列欄名、第 4 列起資料 */
  layout(owner = null, title = '記帳表') { return { title, merge: 'A1:H2', headerRow: 3, headers: HEAD, rows: this.rows(owner) }; }
  toXlsx(owner = null, title = '記帳表') {
    const L = this.layout(owner, title); const sty = { [COLOR.green]: 3, [COLOR.red]: 4, [COLOR.blue]: 5, [COLOR.black]: 6 };
    const rows = [[{ v: title, s: 1 }, ...Array(7).fill({ v: '', s: 1 })], Array(8).fill({ v: '', s: 1 }), HEAD.map((h) => ({ v: h, s: 2 }))];
    for (const r of L.rows) rows.push([{ v: r.no, s: 6 }, { v: r.date, s: 6 }, { v: r.time, s: 6 }, { v: r.kind, s: sty[r.kindColor] }, { v: r.amount, s: sty[r.amountColor] },
      { v: r.note, s: 6 }, { v: r.tag, s: sty[r.tagColor] }, { v: r.balance, s: sty[r.balanceColor] }]);
    return buildXlsx({ name: title, rows, merges: ['A1:H2'], widths: [8, 13, 9, 11, 12, 22, 13, 14] });
  }
  toCSV(owner = null) {
    const esc = (v) => { v = String(v ?? ''); return /[",\n]/.test(v) ? '"' + v.replace(/"/g, '""') + '"' : v; };
    return '\ufeff' + [HEAD, ...this.rows(owner).map((r) => [r.no, r.date, r.time, r.kind, r.amount, r.note, r.tag, r.balanceText])].map((r) => r.map(esc).join(',')).join('\r\n');
  }
  /** 解析「2026/11/07 14:30」之類（台北時間）→ epoch；失敗回 null */
  static parseWhen(s) {
    const m = /(\d{4})[-/.](\d{1,2})[-/.](\d{1,2})(?:[ T](\d{1,2}):(\d{2}))?/.exec(String(s || '')); if (!m) return null;
    return fromTaipei(+m[1], +m[2], +m[3], +(m[4] || 0), +(m[5] || 0));
  }
}
module.exports = { Ledger, TAGS, classify, HEAD, COLOR };
