'use strict';
/**
 * 讀文件（26.11.3 Revise4）：使用者在 LINE／Telegram／Discord 傳來的檔案、或網址上的文件 → 抽出文字給 AI 看。
 * 支援：Word（docx）、Excel（xlsx）、PowerPoint（pptx）、PDF（文字型）、純文字／CSV／Markdown／JSON／HTML。
 * 不用任何外部套件（手機上裝不了）：自己讀 ZIP（Office 檔）、自己解 PDF 的壓縮串流。
 * 掃描型 PDF、圖片型文件抽不出字時會明確說，並建議改傳截圖（AI 看得懂圖片）。
 */
const zlib = require('zlib');

/** 讀 ZIP：回傳 { 檔名: Buffer } */
function unzip(buf, want = () => true) {
  let eocd = -1; for (let i = buf.length - 22; i >= Math.max(0, buf.length - 65557); i--) if (buf.readUInt32LE(i) === 0x06054b50) { eocd = i; break; }
  if (eocd < 0) throw new Error('不是有效的 Office 檔（ZIP 結構壞了）');
  const n = buf.readUInt16LE(eocd + 10); let p = buf.readUInt32LE(eocd + 16); const out = {};
  for (let k = 0; k < n; k++) {
    if (buf.readUInt32LE(p) !== 0x02014b50) break;
    const method = buf.readUInt16LE(p + 10); const csize = buf.readUInt32LE(p + 20); const nlen = buf.readUInt16LE(p + 28); const elen = buf.readUInt16LE(p + 30); const clen = buf.readUInt16LE(p + 32); const off = buf.readUInt32LE(p + 42);
    const name = buf.slice(p + 46, p + 46 + nlen).toString('utf8'); p += 46 + nlen + elen + clen;
    if (!want(name)) continue;
    const lnl = buf.readUInt16LE(off + 26); const lel = buf.readUInt16LE(off + 28); const data = buf.slice(off + 30 + lnl + lel, off + 30 + lnl + lel + csize);
    try { out[name] = method === 0 ? data : method === 8 ? zlib.inflateRawSync(data) : null; } catch { out[name] = null; }
  }
  return out;
}
const ent = (s) => s.replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&apos;/g, "'").replace(/&#(\d+);/g, (_, d) => String.fromCodePoint(+d)).replace(/&#x([0-9a-f]+);/gi, (_, h) => String.fromCodePoint(parseInt(h, 16))).replace(/&amp;/g, '&');
const num = (a, b) => (parseInt(a.replace(/\D/g, ''), 10) || 0) - (parseInt(b.replace(/\D/g, ''), 10) || 0);

function docx(buf) {
  const z = unzip(buf, (n) => n === 'word/document.xml'); const x = z['word/document.xml']; if (!x) throw new Error('找不到 Word 內容');
  // 表格：每列一行、儲存格用「 | 」分隔（儲存格裡的段落用空白接起來）
  const cellText = (xml) => xml.split('</w:p>').map((p) => [...p.matchAll(/<w:t[^>]*>([^<]*)<\/w:t>/g)].map((m) => m[1]).join('')).filter(Boolean).join(' ');
  let raw = x.toString('utf8').replace(/<w:tbl>[\s\S]*?<\/w:tbl>/g, (tbl) => '<w:p><w:r><w:t>' + tbl.split('</w:tr>').filter((r) => /<w:tc[ >]/.test(r)).map((r) => r.split('</w:tc>').filter((c) => /<w:t[ >]/.test(c) || /<w:tc[ >]/.test(c)).map(cellText).filter((c, i, a) => i < a.length || c).join(' | ')).join('\u0003') + '</w:t></w:r></w:p>');
  let s = raw.replace(/<w:tab\/>/g, '\t').replace(/<w:br[^>]*\/>/g, '\n').replace(/<\/w:tc>/g, ' | ').replace(/<\/w:tr>/g, '\n').replace(/<\/w:p>/g, '\n');
  s = s.replace(/<w:t[^>]*>([^<]*)<\/w:t>/g, '\u0001$1\u0002').replace(/<[^>]+>/g, '').replace(/\u0001|\u0002/g, '');
  return ent(s).replace(/\u0003/g, '\n').replace(/\n{3,}/g, '\n\n').trim();
}
function xlsx(buf) {
  const z = unzip(buf, (n) => n === 'xl/sharedStrings.xml' || n === 'xl/workbook.xml' || /^xl\/worksheets\/sheet\d+\.xml$/.test(n));
  const shared = []; if (z['xl/sharedStrings.xml']) for (const si of z['xl/sharedStrings.xml'].toString('utf8').split('</si>')) { const t = [...si.matchAll(/<t[^>]*>([^<]*)<\/t>/g)].map((m) => m[1]).join(''); shared.push(ent(t)); }
  const names = z['xl/workbook.xml'] ? [...z['xl/workbook.xml'].toString('utf8').matchAll(/<sheet [^>]*name="([^"]+)"/g)].map((m) => ent(m[1])) : [];
  const sheets = Object.keys(z).filter((n) => /worksheets\/sheet\d+\.xml$/.test(n)).sort(num); const parts = [];
  sheets.forEach((n, i) => {
    const xml = z[n].toString('utf8'); const rows = [];
    for (const row of xml.split('</row>').slice(0, 300)) {
      const cells = []; for (const c of row.matchAll(/<c ([^>]*?)(?:\/>|>([\s\S]*?)<\/c>)/g)) {
        const attrs = c[1]; const inner = c[2] || ''; const ref = (/r="([A-Z]+)\d+"/.exec(attrs) || [])[1] || ''; const t = (/t="(\w+)"/.exec(attrs) || [])[1];
        let v = (/<v>([^<]*)<\/v>/.exec(inner) || [])[1]; if (t === 's') v = shared[+v]; else if (t === 'inlineStr') v = [...inner.matchAll(/<t[^>]*>([^<]*)<\/t>/g)].map((m) => m[1]).join(''); else if (v !== undefined) v = ent(v);
        if (v === undefined || v === '') continue; let col = 0; for (const ch of ref) col = col * 26 + ch.charCodeAt(0) - 64; cells[Math.max(0, col - 1)] = String(v).replace(/[\r\n]+/g, ' ');
      }
      if (cells.length) rows.push(Array.from(cells, (x) => x ?? '').join('\t'));
    }
    parts.push(`【工作表：${names[i] || '工作表' + (i + 1)}】（${rows.length} 列${rows.length >= 300 ? '，只列前 300 列' : ''}）\n${rows.join('\n')}`);
  });
  return parts.join('\n\n').trim();
}
function pptx(buf) {
  const z = unzip(buf, (n) => /^ppt\/slides\/slide\d+\.xml$/.test(n));
  return Object.keys(z).sort(num).map((n, i) => `【第 ${i + 1} 頁】\n` + ent(z[n].toString('utf8').replace(/<\/a:p>/g, '\n').replace(/<a:t>([^<]*)<\/a:t>/g, '\u0001$1').replace(/<[^>]+>/g, '').replace(/\u0001/g, '')).replace(/\n{2,}/g, '\n').trim()).join('\n\n');
}
/** PDF：解開 FlateDecode 串流，抓 Tj／TJ 的文字（文字型 PDF 有效；掃描檔、特殊編碼的中文 PDF 抽不出來） */
function pdf(buf) {
  const s = buf.toString('latin1'); const out = []; let m; const re = /stream\r?\n/g;
  while ((m = re.exec(s))) {
    const start = m.index + m[0].length; const end = s.indexOf('endstream', start); if (end < 0) break;
    const dict = s.slice(Math.max(0, m.index - 300), m.index); let data = buf.slice(start, end);
    if (/FlateDecode/.test(dict)) { try { data = zlib.inflateSync(data); } catch { try { data = zlib.inflateRawSync(data.slice(2)); } catch { continue; } } }
    else if (/\/Filter/.test(dict)) continue;   // 圖片等其他編碼
    const t = data.toString('latin1'); if (!/\b(Tj|TJ|')\b/.test(t)) continue;
    const dec = (x) => x.replace(/\\([nrtbf()\\]|\d{1,3})/g, (_, e) => ({ n: '\n', r: '\r', t: '\t', b: '', f: '', '(': '(', ')': ')', '\\': '\\' }[e] ?? String.fromCharCode(parseInt(e, 8))));
    const toStr = (lat) => { const b = Buffer.from(lat, 'latin1'); if (b.length >= 2 && b[0] === 0xfe && b[1] === 0xff) return b.slice(2).swap16().toString('utf16le'); return b.toString('utf8').includes('�') ? lat : b.toString('utf8'); };
    for (const blk of t.split(/\bET\b/)) {
      let line = ''; for (const mm of blk.matchAll(/\((?:\\.|[^\\)])*\)\s*(?:Tj|')|\[((?:\\.|[^\]])*)\]\s*TJ|(T\*|Td|TD)/g)) {
        if (mm[2]) { line += '\n'; continue; }
        const strs = mm[1] !== undefined ? [...mm[1].matchAll(/\(((?:\\.|[^\\)])*)\)|(-?\d{3,})/g)].map((x) => (x[2] && +x[2] < -200 ? ' ' : x[1] !== undefined ? dec(x[1]) : '')) : [dec(mm[0].replace(/\)\s*(Tj|')$/, '').slice(1))];
        line += toStr(strs.join(''));
      }
      if (line.trim()) out.push(line.trim());
    }
  }
  const text = out.join('\n').replace(/\n{3,}/g, '\n\n').trim();
  const readable = (text.match(/[\w一-鿿]/g) || []).length;
  if (readable < 20) throw new Error('這個 PDF 抽不出文字（可能是掃描檔，或使用特殊字型編碼的中文）。請改傳每一頁的截圖，我可以直接看圖片');
  return text;
}
function html(s) { return ent(String(s).replace(/<(script|style|noscript)[\s\S]*?<\/\1>/gi, '').replace(/<br\s*\/?>/gi, '\n').replace(/<\/(p|div|h\d|li|tr)>/gi, '\n').replace(/<[^>]+>/g, '')).replace(/[ \t]+/g, ' ').replace(/\n\s*\n+/g, '\n\n').trim(); }

/** 主函式：依副檔名／MIME／檔頭判斷格式 */
function extract(buf, name = '', mime = '') {
  const n = String(name).toLowerCase(); const head = buf.slice(0, 5).toString('latin1');
  const kind = /\.docx$/.test(n) || /wordprocessingml/.test(mime) ? 'docx' : /\.xlsx$/.test(n) || /spreadsheetml/.test(mime) ? 'xlsx' : /\.pptx$/.test(n) || /presentationml/.test(mime) ? 'pptx'
    : head === '%PDF-' || /\.pdf$/.test(n) || /pdf/.test(mime) ? 'pdf' : /\.(html?|xhtml)$/.test(n) || /html/.test(mime) ? 'html'
      : /\.(doc|xls|ppt)$/.test(n) ? 'old' : buf.slice(0, 2).toString('latin1') === 'PK' ? 'zip' : 'text';
  if (kind === 'old') throw new Error('這是舊版 Office 格式（.doc／.xls／.ppt），請另存成 .docx／.xlsx／.pptx 或 PDF 再傳');
  if (kind === 'zip') { const z = unzip(buf, () => false); void z; throw new Error('這是壓縮檔，不是文件；請解壓後傳裡面的檔案'); }
  let text = kind === 'docx' ? docx(buf) : kind === 'xlsx' ? xlsx(buf) : kind === 'pptx' ? pptx(buf) : kind === 'pdf' ? pdf(buf) : kind === 'html' ? html(buf.toString('utf8')) : null;
  if (text === null) { if (buf.includes(0)) throw new Error('看起來是二進位檔，不是文字文件'); text = buf.toString('utf8').replace(/^﻿/, ''); }
  return { kind, text, chars: text.length };
}
module.exports = { extract, unzip };
