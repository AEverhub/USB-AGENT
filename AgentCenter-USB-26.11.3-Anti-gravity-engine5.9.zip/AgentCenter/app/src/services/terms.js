'use strict';
/**
 * 26.11.3 pro10 用戶條款：內容在 knowledge/terms.md（版本寫在檔案第一段的「版本：」）。
 * 記錄誰在什麼時候同意了哪一版（store.db.terms）；條款版本更新後要重新同意。
 */
const fs = require('fs');
const path = require('path');
const FILE = path.join(__dirname, '..', '..', 'knowledge', 'terms.md');

class Terms {
  constructor(ctx) { this.ctx = ctx; this._c = null; }
  load() { if (!this._c) { let text = ''; try { text = fs.readFileSync(FILE, 'utf8'); } catch { text = '# 用戶條款\n\n（條款檔案讀取失敗）'; } const v = (/^版本[:：]\s*(\S+)/m.exec(text) || [])[1] || '0'; this._c = { text, version: v }; } return this._c; }
  get version() { return this.load().version; }
  get text() { return this.load().text; }
  get db() { const d = this.ctx.store.db; if (!d.terms || typeof d.terms !== 'object') d.terms = { app: null, people: {} }; if (!d.terms.people) d.terms.people = {}; return d.terms; }
  /** who：'app'（主機 App 的擁有者）或某個人的 id */
  accepted(who = 'app') { const r = who === 'app' ? this.db.app : this.db.people[who]; return !!(r && r.version === this.version); }
  accept(who = 'app', via = '') { const rec = { version: this.version, at: Date.now(), via: String(via || '').slice(0, 20) }; if (who === 'app') this.db.app = rec; else this.db.people[who] = rec; this.ctx.store.touch(); this.ctx.store.audit(who === 'app' ? 'app' : who, 'terms.accept', this.version); return rec; }
  state(who = 'app') { const r = who === 'app' ? this.db.app : this.db.people[who]; return { version: this.version, accepted: this.accepted(who), accepted_at: r ? r.at : null, accepted_version: r ? r.version : null, text: this.text }; }
  /** 給聊天平台用的短版（純文字，沒有 Markdown） */
  summary() {
    return ['【用戶條款重點】（版本 ' + this.version + '）',
      '・你對自己下的指令與使用結果負責；只對你有權使用的帳號、資料、系統使用。',
      '・不可用於違法、騷擾、詐騙、攻擊他人系統或違反其他平台條款。',
      '・AI 可能出錯：醫療、法律、財務、安全等重要決定請自行查證或問專業人士。',
      '・你的訊息會存在主機手機上（管理員可查看），並傳給所設定的 AI 模型供應商處理；請不要傳敏感個資。',
      '・自動操作（手機代理、巨集、遊戲協助、排程）有風險，後果由使用者自行承擔。',
      '・用量與費用由 API 金鑰持有人負擔；不保證任何免費額度。',
      '繼續使用即表示同意。完整條款請向管理員索取，或在 App「更多 → 用戶條款」查看。'].join('\n');
  }
}
module.exports = { Terms };
