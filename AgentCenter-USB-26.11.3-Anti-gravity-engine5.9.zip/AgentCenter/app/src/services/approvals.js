'use strict';
/** 審批佇列：只有「下載」與「新用戶」需要管理員點頭；可在 App 的待審批區核准／拒絕，也可用自然語言對 AI 說。 */
const { logger } = require('../core/log');
const log = logger('approvals');

class Approvals {
  constructor(ctx) { this.ctx = ctx; this.executors = {}; }
  register(kind, fn) { this.executors[kind] = fn; }
  get list_() { return this.ctx.store.db.approvals; }
  pending() { return this.list_.filter((a) => a.status === 'pending'); }
  get(id) { return this.list_.find((a) => a.id === +id) || null; }
  async request({ kind, summary, payload = {}, requester = '', chat = null }) {
    const a = { id: this.ctx.store.nextId('approval'), kind, status: 'pending', summary, payload, requester, chat, created: Date.now(), decided: 0, decider: '', result: '' };
    this.list_.push(a); if (this.list_.length > 500) this.list_.splice(0, this.list_.length - 500); this.ctx.store.touch();
    this.ctx.store.audit(requester || 'system', 'approval.request', `#${a.id} ${kind} ${summary}`);
    this.ctx.notifier.push('warn', `待審批 #${a.id}`, `${summary}\n請到 App「操作頁」或對我說「核准 ${a.id}」。`).catch(() => {});
    return a;
  }
  async decide(id, approve, who = 'admin') {
    const a = this.get(id); if (!a) throw new Error('找不到這個審批');
    if (a.status !== 'pending') throw new Error(`#${id} 已經處理過（${a.status}）`);
    a.status = approve ? 'approved' : 'rejected'; a.decided = Date.now(); a.decider = who; this.ctx.store.touch();
    this.ctx.store.audit(who, approve ? 'approval.approve' : 'approval.reject', `#${a.id} ${a.kind}`);
    if (approve) {
      const ex = this.executors[a.kind];
      try { a.result = ex ? String(await ex(a.payload, a)) : '（無執行器）'; a.status = 'done'; }
      catch (e) { a.result = '執行失敗：' + e.message; a.status = 'failed'; log.error(a.kind, e); }
      this.ctx.store.touch();
    }
    await this._tell(a, approve).catch(() => {});
    return a;
  }
  async _tell(a, approve) {
    if (!a.chat || !this.ctx.hub) return;
    const text = approve ? `✅ 管理員已核准你的${a.kind === 'download' ? '下載' : '申請'}：${a.summary}\n${a.result}` : `❌ 管理員沒有核准：${a.summary}`;
    await this.ctx.hub.send(a.chat.platform, a.chat.chatId, text);
  }
}
module.exports = { Approvals };
