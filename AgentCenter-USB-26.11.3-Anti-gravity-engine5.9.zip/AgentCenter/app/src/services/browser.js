'use strict';
/**
 * 瀏覽器服務（Manus 式「AI 與你共用的瀏覽器」）。
 *  ・AI 用 browser_* 工具操作；管理員在 App 的「瀏覽器」頁即時看到畫面，隨時「接手」（登入、驗證碼），再「交還給 AI」。
 *  ・登入狀態存在瀏覽器設定檔（data/browser-profile 或 App 的 WebView），重啟後仍在 → 可長時間使用。
 *  ・供應商：local（本機啟動 Chrome/Chromium/Edge）、cdp（連到別台機器的 Chrome）、android（App 內 WebView）。
 *  ・長時間運作：自動重連、Chrome 掛掉自動重開、心跳偵測、分頁整理、閒置回收（設定檔保留，登入不掉）。
 */
const fs = require('fs');
const os = require('os');
const path = require('path');
const net = require('net');
const { spawn } = require('child_process');
const { logger } = require('../core/log');
const { sleep, withTimeout } = require('../core/util');
const { CDP, httpGet } = require('./cdp');
const log = logger('browser');

const KEYS = {
  Enter: { key: 'Enter', code: 'Enter', vk: 13, text: '\r' }, Tab: { key: 'Tab', code: 'Tab', vk: 9 }, Backspace: { key: 'Backspace', code: 'Backspace', vk: 8 }, Escape: { key: 'Escape', code: 'Escape', vk: 27 },
  Delete: { key: 'Delete', code: 'Delete', vk: 46 }, ArrowUp: { key: 'ArrowUp', code: 'ArrowUp', vk: 38 }, ArrowDown: { key: 'ArrowDown', code: 'ArrowDown', vk: 40 }, ArrowLeft: { key: 'ArrowLeft', code: 'ArrowLeft', vk: 37 },
  ArrowRight: { key: 'ArrowRight', code: 'ArrowRight', vk: 39 }, PageDown: { key: 'PageDown', code: 'PageDown', vk: 34 }, PageUp: { key: 'PageUp', code: 'PageUp', vk: 33 }, Home: { key: 'Home', code: 'Home', vk: 36 }, End: { key: 'End', code: 'End', vk: 35 },
  Space: { key: ' ', code: 'Space', vk: 32, text: ' ' },
};
const CHROME_CANDIDATES = ['google-chrome-stable', 'google-chrome', 'chromium', 'chromium-browser', 'chrome', 'microsoft-edge', 'microsoft-edge-stable', 'brave-browser',
  '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome', '/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge', 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe', 'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe', 'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe'];

function which(cmd) {
  if (path.isAbsolute(cmd)) return fs.existsSync(cmd) ? cmd : '';
  for (const d of String(process.env.PATH || '').split(path.delimiter)) for (const ext of process.platform === 'win32' ? ['.exe', ''] : ['']) { const p = path.join(d, cmd + ext); try { if (fs.statSync(p).isFile()) return p; } catch { /* next */ } }
  return '';
}
function findChrome(custom) {
  if (custom && fs.existsSync(custom)) return custom; if (process.env.CHROME_PATH && fs.existsSync(process.env.CHROME_PATH)) return process.env.CHROME_PATH;
  for (const c of CHROME_CANDIDATES) { const p = which(c); if (p) return p; }
  try { const root = path.join(os.homedir(), '.cache', 'ms-playwright'); for (const d of fs.readdirSync(root).filter((x) => x.startsWith('chromium')).sort().reverse()) for (const rel of ['chrome-linux/chrome', 'chrome-linux64/chrome', 'chrome-win/chrome.exe', 'chrome-mac/Chromium.app/Contents/MacOS/Chromium']) { const p = path.join(root, d, rel); if (fs.existsSync(p)) return p; } } catch { /* none */ }
  return '';
}
const freePort = (pref) => new Promise((res) => { const s = net.createServer(); s.once('error', () => { const t = net.createServer(); t.listen(0, '127.0.0.1', () => { const p = t.address().port; t.close(() => res(p)); }); }); s.listen(pref, '127.0.0.1', () => s.close(() => res(pref))); });
const BLOCK_HOST = /^(localhost|.*\.localhost|0\.0\.0\.0|127\.\d+\.\d+\.\d+|\[?::1\]?|169\.254\.\d+\.\d+|metadata\.google\.internal)$/i;
function blockedUrl(u) { try { const x = new URL(u); if (x.protocol === 'about:' || x.protocol === 'data:') return null; if (!/^https?:$/.test(x.protocol)) return '只支援 http/https 網址'; if (BLOCK_HOST.test(x.hostname)) return '不允許用瀏覽器開本機位址（避免繞過 App 保護）'; return null; } catch { return '網址格式不正確'; } }

// ---------- 在網頁內執行的函式（以字串送進去） ----------
const PAGE = {
  snap: `(maxEls) => {
    const SEL = 'a[href],button,input,select,textarea,summary,[role=button],[role=link],[role=checkbox],[role=radio],[role=tab],[role=menuitem],[role=option],[role=switch],[role=combobox],[role=listbox],[contenteditable=""],[contenteditable=true],[onclick],[tabindex]:not([tabindex="-1"])';
    const cand = []; const vh = innerHeight, vw = innerWidth;
    const walk = (root, ox, oy) => {
      let list; try { list = root.querySelectorAll(SEL); } catch (e) { return; }
      for (const el of list) {
        const r = el.getBoundingClientRect(); if (r.width < 2 || r.height < 2) continue; const cs = (el.ownerDocument.defaultView || window).getComputedStyle(el); if (cs.visibility === 'hidden' || cs.display === 'none' || +cs.opacity === 0) continue;
        if (el.tagName === 'INPUT' && el.type === 'hidden') continue;
        const x = r.left + ox, y = r.top + oy; const inView = y + r.height > 0 && y < vh && x + r.width > 0 && x < vw;
        let label = el.getAttribute('aria-label') || (el.labels && el.labels[0] && el.labels[0].innerText) || '';
        if (!label) { const lb = el.getAttribute('aria-labelledby'); if (lb) label = lb.split(' ').map((i) => { const n = el.ownerDocument.getElementById(i); return n ? n.innerText : ''; }).join(' '); }
        if (!label) label = (el.innerText || '').trim(); if (!label) label = el.placeholder || el.getAttribute('title') || el.getAttribute('alt') || el.name || el.id || '';
        label = label.replace(/\\s+/g, ' ').trim().slice(0, 70);
        const type = (el.type || '').toLowerCase(); const tag = el.tagName.toLowerCase();
        cand.push({ el, tag, type, role: el.getAttribute('role') || '', label, href: tag === 'a' ? (el.getAttribute('href') || '').slice(0, 80) : '', value: type === 'password' ? (el.value ? '(已填)' : '') : (['input','textarea','select'].includes(tag) ? String(el.value || '').slice(0, 60) : ''),
          checked: el.checked === true || el.getAttribute('aria-checked') === 'true' || el.getAttribute('aria-selected') === 'true', disabled: !!el.disabled || el.getAttribute('aria-disabled') === 'true', inView, x: Math.round(x), y: Math.round(y), w: Math.round(r.width), h: Math.round(r.height) });
      }
      let all; try { all = root.querySelectorAll('*'); } catch (e) { all = []; }
      for (const n of all) { if (n.shadowRoot) walk(n.shadowRoot, ox, oy); if (n.tagName === 'IFRAME') { try { const d = n.contentDocument; if (d) { const fr = n.getBoundingClientRect(); walk(d, ox + fr.left, oy + fr.top); } } catch (e) { /* 跨網域 */ } } }
    };
    walk(document, 0, 0);
    const keep = new Set(); let n = 0; for (const c of cand) if (c.inView && n < maxEls) { keep.add(c); n++; } for (const c of cand) if (!c.inView && n < maxEls) { keep.add(c); n++; }
    const out = []; window.__la_els = []; for (const c of cand) { if (!keep.has(c)) continue; const id = window.__la_els.length; window.__la_els.push(c.el); const { el, ...rest } = c; out.push({ id, ...rest }); }
    const de = document.documentElement;
    return { url: location.href, title: document.title, text: (document.body ? document.body.innerText : '').replace(/\\n{3,}/g, '\\n\\n').slice(0, 7000), els: out, total: cand.length, scroll: { y: Math.round(scrollY), h: de.scrollHeight, vh }, ready: document.readyState };
  }`,
  center: `(id) => {
    const el = window.__la_els && window.__la_els[id]; if (!el || !el.isConnected) return { err: '這個編號的元素已經不存在（頁面變了）。請先用 browser_read 重新取得編號。' };
    el.scrollIntoView({ block: 'center', inline: 'center' }); const r = el.getBoundingClientRect(); let ox = 0, oy = 0, w = el.ownerDocument.defaultView;
    while (w && w.frameElement) { const f = w.frameElement.getBoundingClientRect(); ox += f.left; oy += f.top; w = w.parent; }
    const x = r.left + r.width / 2 + ox, y = r.top + r.height / 2 + oy; const top = document.elementFromPoint(x, y);
    return { x, y, tag: el.tagName.toLowerCase(), type: (el.type || '').toLowerCase(), covered: !!top && top !== el && !el.contains(top) && !top.contains(el) };
  }`,
  focus: `(id, clear) => { const el = window.__la_els && window.__la_els[id]; if (!el) return false; el.focus(); if (clear) { if (el.select) el.select(); else { const s = getSelection(); const r = document.createRange(); r.selectNodeContents(el); s.removeAllRanges(); s.addRange(r); } } return true; }`,
  jsType: `(id, text, clear) => { const el = window.__la_els && window.__la_els[id]; if (!el) return false; el.focus(); if (clear) { if (el.select) el.select(); else document.execCommand('selectAll'); } let ok = false; try { ok = document.execCommand('insertText', false, text); } catch (e) { /* ignore */ } if (!ok || (el.value !== undefined && clear && el.value !== text)) { const proto = el.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype; const d = Object.getOwnPropertyDescriptor(proto, 'value'); if (d && d.set && el.value !== undefined) { d.set.call(el, clear ? text : el.value + text); el.dispatchEvent(new Event('input', { bubbles: true })); el.dispatchEvent(new Event('change', { bubbles: true })); } } return true; }`,
  jsSubmit: `(id) => { const el = window.__la_els && window.__la_els[id]; if (!el) return false; const f = el.form; if (f) { if (f.requestSubmit) f.requestSubmit(); else f.submit(); return true; } for (const t of ['keydown', 'keypress', 'keyup']) el.dispatchEvent(new KeyboardEvent(t, { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true })); return true; }`,
  jsKey: `(k) => { const el = document.activeElement || document.body; if (k === 'Enter' && el.form) { if (el.form.requestSubmit) el.form.requestSubmit(); else el.form.submit(); return true; } if (k === 'Backspace') { document.execCommand('delete'); return true; } const kc = { Enter: 13, Tab: 9, Escape: 27, Delete: 46, ArrowUp: 38, ArrowDown: 40, ArrowLeft: 37, ArrowRight: 39 }[k]; for (const t of ['keydown', 'keyup']) el.dispatchEvent(new KeyboardEvent(t, { key: k, code: k, keyCode: kc, which: kc, bubbles: true })); return true; }`,
  jsClick: `(id) => { const el = window.__la_els && window.__la_els[id]; if (!el) return false; el.click(); return true; }`,
  setValue: `(id, v) => { const el = window.__la_els && window.__la_els[id]; if (!el) return false; const proto = el.tagName === 'SELECT' ? HTMLSelectElement.prototype : el.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype; const set = Object.getOwnPropertyDescriptor(proto, 'value').set; set.call(el, v); el.dispatchEvent(new Event('input', { bubbles: true })); el.dispatchEvent(new Event('change', { bubbles: true })); return true; }`,
  // Google 表單：抽出題目（結構靠 ARIA role，不靠會變動的 class 名稱）
  formRead: `() => {
    const items = [...document.querySelectorAll('div[role="listitem"]')].filter((x) => x.querySelector('[role="heading"]') || x.querySelector('input,textarea,[role=radio],[role=checkbox],[role=listbox]'));
    window.__lf = []; const out = []; const vis = (e) => { const r = e.getBoundingClientRect(); return r.width > 1 && r.height > 1; };
    for (const it of items) {
      const head = it.querySelector('[role="heading"]'); let title = head ? head.innerText.replace(/\\s*\\*\\s*$/, '').trim() : ''; const reqEl = it.querySelector('[aria-label="必填"],[aria-label="Required"],[aria-label="必須"]') || (head && /\\*\\s*$/.test(head.innerText) ? head : null);
      const required = !!reqEl || !!it.querySelector('[aria-required="true"]'); const desc = (it.querySelector('[data-description]') || {}).innerText || '';
      let type = 'unknown', opts = [], control = null;
      const radios = [...it.querySelectorAll('[role="radio"]')], checks = [...it.querySelectorAll('[role="checkbox"]')], lb = it.querySelector('[role="listbox"]');
      const text = it.querySelector('input[type="text"],input[type="email"],input[type="url"],input[type="tel"],input[type="number"]'), area = it.querySelector('textarea'), date = it.querySelector('input[type="date"]'), time = it.querySelector('input[type="time"]');
      const groups = it.querySelectorAll('[role="radiogroup"]');
      if (it.querySelector('input[type="file"]') || /上傳檔案|Upload file|新增檔案|Add file/.test(it.innerText) && !text && !area) type = 'file';
      else if (groups.length > 1) { type = 'grid'; opts = [...groups].map((g) => ({ label: g.getAttribute('aria-label') || '', el: g, choices: [...g.querySelectorAll('[role="radio"]')].map((r) => ({ label: r.getAttribute('aria-label') || r.getAttribute('data-value') || '', el: r })) })); }
      else if (radios.length) { type = 'radio'; opts = radios.map((r) => ({ label: r.getAttribute('aria-label') || r.getAttribute('data-value') || r.innerText.trim(), el: r, checked: r.getAttribute('aria-checked') === 'true', other: r.getAttribute('data-value') === '__other_option__' })); }
      else if (checks.length) { type = 'checkbox'; opts = checks.map((r) => ({ label: r.getAttribute('aria-label') || r.getAttribute('data-answer-value') || r.innerText.trim(), el: r, checked: r.getAttribute('aria-checked') === 'true', other: r.getAttribute('data-answer-value') === '__other_option__' })); }
      else if (lb) { type = 'dropdown'; control = lb; }
      else if (area) { type = 'paragraph'; control = area; } else if (date) { type = 'date'; control = date; } else if (time) { type = 'time'; control = time; } else if (text) { type = 'text'; control = text; }
      const idx = out.length; window.__lf.push({ it, type, control, opts }); const q = { i: idx, title, type, required, desc: desc.slice(0, 120) };
      if (type === 'radio' || type === 'checkbox') q.options = opts.map((o) => o.label + (o.checked ? ' ✓' : '')); if (type === 'grid') q.rows = opts.map((o) => ({ row: o.label, choices: o.choices.map((c) => c.label) }));
      if (control) q.value = String(control.value || ''); out.push(q);
    }
    const btns = [...document.querySelectorAll('[role="button"],button')].filter(vis).map((b) => (b.innerText || b.getAttribute('aria-label') || '').trim()).filter((t) => /^(下一頁|下一步|Next|提交|送出|Submit|上一頁|返回|Back|清除表單|Clear form)$/i.test(t));
    const done = /已記錄(您|你)的回應|Your response has been recorded|已提交|感謝您(填寫|的回覆)/.test(document.body.innerText);
    const err = [...document.querySelectorAll('[role="alert"],[aria-live]')].map((e) => e.innerText.trim()).filter(Boolean).slice(0, 5);
    const title = (document.querySelector('[role="heading"][aria-level="1"],.freebirdFormviewerViewHeaderTitle') || document.querySelector('[role="heading"]') || {}).innerText || document.title;
    return { url: location.href, formTitle: (title || '').trim(), questions: out, buttons: btns, done, alerts: err, needLogin: /accounts\\.google\\.com/.test(location.href) };
  }`,
  formCenter: `(qi, oi, ri) => {
    const f = window.__lf && window.__lf[qi]; if (!f) return { err: '題目編號不存在，請先 google_form_read' }; let el;
    if (f.type === 'grid') el = f.opts[ri].choices[oi].el; else if (oi != null && oi >= 0) el = f.opts[oi].el; else el = f.control;
    if (!el) return { err: '找不到作答元件' }; el.scrollIntoView({ block: 'center' }); const r = el.getBoundingClientRect(); return { x: r.left + r.width / 2, y: r.top + r.height / 2, checked: el.getAttribute('aria-checked') === 'true' };
  }`,
  formOtherInput: `(qi) => { const f = window.__lf && window.__lf[qi]; if (!f) return null; const el = f.it.querySelector('input[type="text"][aria-label*="其他"],input[type="text"][aria-label*="ther"],input[type="text"]:not([aria-label=""])'); if (!el) return null; el.scrollIntoView({ block: 'center' }); const r = el.getBoundingClientRect(); return { x: r.left + r.width / 2, y: r.top + r.height / 2 }; }`,
  formDropdownOptions: `(qi) => { const f = window.__lf && window.__lf[qi]; if (!f) return []; const lst = [...document.querySelectorAll('[role="option"]')].filter((e) => { const r = e.getBoundingClientRect(); return r.width > 1 && r.height > 1; }); window.__lf_opts = lst; return lst.map((e, i) => { const r = e.getBoundingClientRect(); return { i, label: (e.getAttribute('data-value') || e.innerText || '').trim(), x: r.left + r.width / 2, y: r.top + r.height / 2 }; }); }`,
  formState: `(qi) => { const f = window.__lf && window.__lf[qi]; if (!f) return null; if (f.control) return { value: String(f.control.value || (f.control.innerText || '')).trim() }; return { checked: f.opts.filter((o) => o.el && o.el.getAttribute && o.el.getAttribute('aria-checked') === 'true').map((o) => o.label) }; }`,
  findButton: `(re) => { const r = new RegExp(re, 'i'); const vis = (e) => { const b = e.getBoundingClientRect(); return b.width > 1 && b.height > 1; }; const b = [...document.querySelectorAll('[role="button"],button')].filter(vis).find((e) => r.test((e.innerText || e.getAttribute('aria-label') || '').trim())); if (!b) return null; b.scrollIntoView({ block: 'center' }); const rc = b.getBoundingClientRect(); return { x: rc.left + rc.width / 2, y: rc.top + rc.height / 2, label: (b.innerText || b.getAttribute('aria-label') || '').trim() }; }`,
  // ===== 26.11.3 Revise5：全自動操作用（用看得到的文字／標籤找元素，不必先讀編號）=====
  findEl: `(q, kind, nth, exact) => {
    const norm = (x) => String(x || '').replace(/\\s+/g, ' ').trim().toLowerCase(); const Q = norm(q); if (!Q) return { err: '要給文字' };
    const SELC = 'a[href],button,input[type=submit],input[type=button],input[type=reset],input[type=checkbox],input[type=radio],input[type=image],summary,label,[role=button],[role=link],[role=tab],[role=menuitem],[role=menuitemradio],[role=option],[role=checkbox],[role=radio],[role=switch],[role=treeitem],[onclick],[tabindex]:not([tabindex="-1"])';
    const SELI = 'input:not([type=hidden]):not([type=submit]):not([type=button]):not([type=reset]):not([type=checkbox]):not([type=radio]):not([type=image]),textarea,select,[contenteditable=""],[contenteditable=true],[role=textbox],[role=combobox],[role=searchbox],[role=spinbutton]';
    const roots = []; const collect = (root, ox, oy) => { roots.push([root, ox, oy]); let all; try { all = root.querySelectorAll('*'); } catch (e) { return; } for (const n of all) { if (n.shadowRoot) collect(n.shadowRoot, ox, oy); if (n.tagName === 'IFRAME') { try { const d = n.contentDocument; if (d) { const r = n.getBoundingClientRect(); collect(d, ox + r.left, oy + r.top); } } catch (e) { /* 跨網域 */ } } } };
    collect(document, 0, 0);
    const vis = (el) => { const r = el.getBoundingClientRect(); if (r.width < 2 || r.height < 2) return false; const cs = (el.ownerDocument.defaultView || window).getComputedStyle(el); return cs.visibility !== 'hidden' && cs.display !== 'none' && +cs.opacity !== 0; };
    const near = (el) => { let t = ''; const id = el.id; if (id) { try { const l = el.getRootNode().querySelector('label[for="' + CSS.escape(id) + '"]'); if (l) t = l.innerText; } catch (e) { /* ignore */ } }
      if (!t && el.labels && el.labels[0]) t = el.labels[0].innerText; const lb = el.getAttribute('aria-labelledby'); if (!t && lb) t = lb.split(' ').map((i) => { const n = el.ownerDocument.getElementById(i); return n ? n.innerText : ''; }).join(' ');
      if (!t) { let p = el.previousElementSibling; for (let k = 0; k < 2 && p && !t; k++, p = p.previousElementSibling) { const x = (p.innerText || '').trim(); if (x && x.length < 60) t = x; } }
      if (!t) { const par = el.parentElement; if (par) { const x = (par.innerText || '').trim(); if (x && x.length < 60) t = x; } } return t || ''; };
    const names = (el, input) => { const out = [el.getAttribute('aria-label'), el.getAttribute('title'), el.getAttribute('alt')];
      if (input) { out.push(near(el), el.placeholder, el.name, el.id, el.getAttribute('data-placeholder')); if (!/^(INPUT|TEXTAREA|SELECT)$/.test(el.tagName)) { const it = (el.innerText || '').trim(); if (it && it.length < 60) out.push(it); } }
      else { out.push(el.innerText, el.value, el.textContent); const img = el.querySelector && el.querySelector('img[alt]'); if (img) out.push(img.alt); } return out.map(norm).filter(Boolean); };
    const found = [];
    for (const [root, ox, oy] of roots) { let list; try { list = root.querySelectorAll(kind === 'input' ? SELI : SELC); } catch (e) { continue; }
      for (const el of list) { if (!vis(el) || el.disabled) continue; let best = 0; for (const n of names(el, kind === 'input')) { let sc = 0; if (n === Q) sc = 100; else if (exact) sc = 0; else if (n.startsWith(Q)) sc = 80; else if (n.includes(Q)) sc = 60 - Math.min(20, (n.length - Q.length) / 10); else if (n.length >= 2 && Q.includes(n)) sc = 35; if (sc > best) best = sc; }
        if (!best) continue; const r = el.getBoundingClientRect(); const inView = r.top + oy < innerHeight && r.bottom + oy > 0; found.push({ el, sc: best + (inView ? 5 : 0), label: (names(el, kind === 'input')[0] || '').slice(0, 60) }); } }
    found.sort((a, b) => b.sc - a.sc); const pick = found[Math.max(0, +nth || 0)]; if (!pick) return { err: 'notfound', count: 0 };
    window.__la_els = window.__la_els || []; const id = window.__la_els.length; window.__la_els.push(pick.el);
    return { id, label: pick.label, tag: pick.el.tagName.toLowerCase(), type: (pick.el.type || '').toLowerCase(), count: found.length, others: found.slice(0, 6).filter((x) => x !== pick).map((x) => x.label) };
  }`,
  selectOpt: `(id, want) => { const el = window.__la_els && window.__la_els[id]; if (!el) return { err: '元素不存在' }; const norm = (x) => String(x || '').replace(/\\s+/g, ' ').trim().toLowerCase(); const W = norm(want);
    if (el.tagName !== 'SELECT') return { custom: true };
    const opts = [...el.options]; const o = opts.find((x) => norm(x.text) === W || norm(x.value) === W) || opts.find((x) => norm(x.text).includes(W)) || opts.find((x) => W.includes(norm(x.text)) && norm(x.text).length > 1);
    if (!o) return { err: '下拉選單裡沒有「' + want + '」，可選：' + opts.map((x) => x.text.trim()).filter(Boolean).slice(0, 30).join('、') };
    const set = Object.getOwnPropertyDescriptor(HTMLSelectElement.prototype, 'value').set; set.call(el, o.value); el.dispatchEvent(new Event('input', { bubbles: true })); el.dispatchEvent(new Event('change', { bubbles: true })); return { ok: true, text: o.text.trim() }; }`,
  // cookie／同意橫幅、訂閱彈窗：只在「浮在畫面上的」容器裡找按鈕；優先選「只接受必要／拒絕」，沒有才按接受；付款、登入、註冊類按鈕一律不碰
  dismiss: `() => {
    const vis = (el) => { const r = el.getBoundingClientRect(); if (r.width < 2 || r.height < 2) return false; const cs = getComputedStyle(el); return cs.visibility !== 'hidden' && cs.display !== 'none' && +cs.opacity !== 0; };
    const overlay = (el) => { for (let n = el, k = 0; n && n !== document.body && k < 12; n = n.parentElement, k++) { const cs = getComputedStyle(n); const tag = ((n.id || '') + ' ' + (typeof n.className === 'string' ? n.className : '')).toLowerCase();
      if (cs.position === 'fixed' || cs.position === 'sticky' || n.getAttribute('role') === 'dialog' || n.getAttribute('role') === 'alertdialog' || n.getAttribute('aria-modal') === 'true' || /cookie|consent|gdpr|cmp|privacy|banner|modal|popup|overlay|newsletter|subscribe-popup/.test(tag)) return true; } return false; };
    const BAD = /付款|付費|結帳|購買|訂閱|加入會員|註冊|登入|登錄|pay|buy|purchase|checkout|subscribe|sign ?up|sign ?in|log ?in|register|delete|刪除|移除/i;
    const PREF = [/^(只接受必要|僅接受必要|僅限必要|只允許必要|拒絕全部|全部拒絕|拒絕|reject all|reject|decline|necessary only|only necessary|use necessary cookies only|accept necessary)/i,
      /^(接受全部|全部接受|接受所有|接受|同意|我同意|允許全部|允許所有|允許|accept all|accept all cookies|accept|allow all|allow|i agree|agree|got it|ok|okay|知道了|我知道了|好的?)$/i,
      /^(不用了|不用，謝謝|稍後再說|以後再說|暫時不要|no,? thanks|not now|maybe later|close|關閉|×|✕|✖|x)$/i];
    const btns = [...document.querySelectorAll('button,[role=button],a,input[type=button],input[type=submit]')].filter((b) => vis(b) && overlay(b));
    const lbl = (b) => (b.innerText || b.value || b.getAttribute('aria-label') || b.getAttribute('title') || '').replace(/\\s+/g, ' ').trim();
    const clicked = [];
    for (const re of PREF) { if (clicked.length) break; for (const b of btns) { const t = lbl(b); if (!t || t.length > 40 || BAD.test(t)) continue; if (re.test(t)) { try { b.click(); clicked.push(t); } catch (e) { /* ignore */ } break; } } }
    return clicked;
  }`,
  extract: `(kind) => {
    const clip = (x, n) => String(x || '').replace(/\\s+/g, ' ').trim().slice(0, n);
    if (kind === 'links') { const seen = new Set(); return [...document.querySelectorAll('a[href]')].map((a) => ({ t: clip(a.innerText || a.getAttribute('aria-label') || a.title, 80), u: a.href })).filter((x) => x.t && /^https?:/.test(x.u) && !seen.has(x.u) && seen.add(x.u)).slice(0, 150); }
    if (kind === 'tables') return [...document.querySelectorAll('table')].slice(0, 8).map((t) => [...t.rows].slice(0, 60).map((r) => [...r.cells].slice(0, 12).map((c) => clip(c.innerText, 60))));
    if (kind === 'headings') return [...document.querySelectorAll('h1,h2,h3,h4')].slice(0, 80).map((h) => h.tagName + ' ' + clip(h.innerText, 120));
    if (kind === 'forms') return [...document.querySelectorAll('form')].slice(0, 6).map((f) => [...f.elements].filter((e) => e.type !== 'hidden').slice(0, 40).map((e) => ({ tag: e.tagName.toLowerCase(), type: e.type || '', name: e.name || '', label: clip((e.labels && e.labels[0] && e.labels[0].innerText) || e.placeholder || e.getAttribute('aria-label') || '', 50), required: !!e.required })));
    return null; }`,
};

class Browser {
  constructor(ctx) {
    this.ctx = ctx; this.name = 'browser'; this.cdp = null; this.tp = null; this.proc = null; this.tabId = null; this.provider = ''; this.control = 'ai'; this.handoff = null; this.lastAction = { ts: 0, text: '' };
    this.lastFrame = null; this.lastFrameAt = 0; this.dialog = null; this.lastActive = Date.now(); this._ensuring = null; this._lock = Promise.resolve(); this.timer = null; this.err = ''; this.vp = { w: 1024, h: 768 }; this.profileDir = path.join(ctx.paths.data, 'browser-profile'); this.reconnects = 0; this.starts = 0; this.uaFixed = '';
    // 26.11.3 Revise6（Manus 式步驟串流）：每做一個動作截一張圖，推給 App 的瀏覽器頁與對話等待泡泡
    this.steps = []; this.stepSeq = 0; this.ev = new (require('events'))(); this.ev.setMaxListeners(50); this._inRun = 0; this._mark = null;
  }
  /** 首頁：預設 Google（設定 browser.home_url 可改） */
  home() { const h = String(this.cfg.home_url || '').trim(); return /^https?:\/\//i.test(h) ? h : 'https://www.google.com/'; }
  stepMeta(x) { return x ? { seq: x.seq, ts: x.ts, label: x.label, url: x.url, title: x.title, by: x.by } : null; }
  lastStep() { return this.steps[this.steps.length - 1] || null; }
  /** 記一步：截圖（點擊的位置畫一個紅圈），存最近 80 步，發出 step 事件 */
  async snapStep(label, mark) {
    if (!this.cdp || !this.cdp.open) return null;
    try {
      if (mark) await this.evalPage(`(x, y) => { const d = document.createElement('div'); d.id = '__la_mark'; d.style.cssText = 'position:fixed;z-index:2147483647;left:' + (x - 15) + 'px;top:' + (y - 15) + 'px;width:30px;height:30px;border-radius:50%;border:3px solid #ff3b30;background:rgba(255,59,48,.22);pointer-events:none;box-sizing:border-box'; (document.body || document.documentElement).appendChild(d); }`, mark.x, mark.y).catch(() => {});
      const jpeg = await this.screenshot({ quality: 60, maxW: 1100 });
      if (mark) await this.evalPage(`() => { const d = document.getElementById('__la_mark'); if (d) d.remove(); }`).catch(() => {});
      const info = await this.pageInfo();
      const st = { seq: ++this.stepSeq, ts: Date.now(), label: String(label || '').slice(0, 140), url: info.url, title: info.title, by: this.control === 'user' ? 'user' : 'ai', jpeg };
      this.steps.push(st); while (this.steps.length > 80) this.steps.shift(); this.lastFrame = jpeg; this.lastFrameAt = Date.now(); this._clearAt = 0;   // 又在做事：取消「5 分鐘後刪除」，做完再重新排
      this.ev.emit('step', this.stepMeta(st)); return st;
    } catch (e) { log.warn('步驟截圖失敗：' + e.message); return null; }
  }
  get cfg() { return this.ctx.settings.get('browser') || {}; }
  /** 手機的 WebView 在 App 退到背景時不一定處理「真實滑鼠／鍵盤事件」，所以 Android 預設改用網頁內的 JS 操作（點擊、輸入、送出），背景也能跑 */
  get jsInput() { return this.provider === 'android' || this.cfg.js_input === true; }
  enabled() { return this.cfg.enabled !== false; }
  // ---- 守護進程介面（健康檢查永遠回 true：瀏覽器是隨用隨起，不要被當成「壞掉的服務」反覆重啟）----
  async start() { try { this.migrate(); } catch (e) { log.warn('瀏覽器設定遷移失敗：' + e.message); } try { this.sweepImages(true); } catch { /* ignore */ } if (this.enabled() && this.cfg.autostart) await this.ensure().catch((e) => log.warn('瀏覽器自動啟動失敗：' + e.message)); this.timer = setInterval(() => this.tick().catch(() => {}), 45000); if (this.timer.unref) this.timer.unref(); this.clearTimer = setInterval(() => { try { this.autoClear(); } catch { /* ignore */ } }, 15000); if (this.clearTimer.unref) this.clearTimer.unref(); }
  async stop() { clearInterval(this.timer); clearInterval(this.clearTimer); await this.shutdown(); }
  health() { return true; }

  /** 26.11.3 Revise5：cdp_url 指向本機（127.0.0.1／localhost）＝以前「啟動 Chromium 並設為 AI 瀏覽器」留下的設定 */
  isLocalCdp() { try { return /^(127\.\d+\.\d+\.\d+|localhost|\[?::1\]?)$/i.test(new URL(this.cfg.cdp_url || '').hostname); } catch { return false; } }
  /** 有可以「由 App 自己管理」的 Chromium：內建 Linux 已裝 Chromium，或外部 Termux 橋接已設定 */
  managedAvailable() {
    const L = this.ctx.linux, T = this.ctx.termux;
    try { if (L && L.supported() && L.installed() && L.meta().chromium) return true; } catch { /* ignore */ }
    try { return !!(T && T.ready()); } catch { return false; }
  }
  /** 舊設定遷移：provider=cdp＋本機網址 → 改成受管理的 linux（Chromium 掛了會自己重開，不再卡在 ECONNREFUSED 127.0.0.1:9222） */
  migrate() {
    const S = this.ctx.settings; if (S.get('browser.provider') !== 'cdp' || !this.isLocalCdp() || !this.managedAvailable()) return false;
    S.set('browser.provider', 'linux', 'human'); S.set('browser.cdp_url', '', 'human'); log.info('瀏覽器設定已從「固定 CDP 位址」改成「App 自動管理的 Chromium」（會自動啟動與重開）'); return true;
  }
  resolveProvider() {
    const p = this.cfg.provider || 'auto'; const android = this.androidSock();
    if (p === 'linux') return 'linux';
    if (p === 'cdp' && this.isLocalCdp() && this.managedAvailable()) return 'linux';
    // 26.9.5：App 內建 Linux 裝了 Chromium → 優先用它（真正的 Chrome 引擎，登入、表單、點擊都可靠）
    if (p === 'auto' && this.linuxReady()) return 'linux';
    // 舊的 App 內 WebView 問題太多（Google 拒絕登入、點擊無效、接手後 AI 無法繼續）：除非管理員明確選它或開 allow_webview，不再自動使用
    // 26.12.4：內建 Linux 還不能用（沒裝、PRoot 在這支手機崩潰…）時，不要讓 AI 完全沒瀏覽器 → 先退回 App 內 WebView（功能較陽春：
    // Google 帳號可能拒絕登入、部分網站點擊要改用 JS）。管理員可用 browser.no_webview=true 關掉這個退路。
    if (android && p === 'auto') return this.cfg.allow_webview || !this.cfg.no_webview ? 'android' : 'linux';
    if (android && p === 'local') return 'android';
    if (p !== 'auto') return p;
    if (this.cfg.cdp_url) return 'cdp'; return 'local';
  }
  linuxReady() { const L = this.ctx.linux; return !!(L && L.installed() && L.meta().chromium && this.ctx.settings.get('termux.mode') === 'embedded'); }
  /**
   * 受管理的 Chromium（內建 Linux 或外部 Termux）。26.11.3 Revise5：全自動——
   *  1. 先探測 Chromium 是不是本來就活著（App 重開後沿用，不重複啟動）
   *  2. 內建 Linux 沒在跑 → 自動啟動；在跑但橋接沒回應 → 自動重啟
   *  3. 叫橋接啟動 Chromium（橋接會依序試 3 種相容模式）；橋接中途死掉 → 重啟 Linux 再試一次
   *  4. 等 CDP 埠真的可以連再回傳
   * fresh=true：連得到埠但開不了分頁（Chromium 假死）時，先關掉再重開。
   */
  async _linuxChrome({ fresh = false } = {}) {
    const L = this.ctx.linux, T = this.ctx.termux, S = this.ctx.settings;
    let embedded = false; try { embedded = !!(L && L.supported() && L.installed() && L.meta().chromium); } catch { /* ignore */ }
    const external = !embedded && T && T.ready() && S.get('termux.mode') !== 'embedded';
    if (!embedded && !external) {
      if (!L || !L.supported()) throw new Error('這個 App 版本沒有內建 Linux，無法啟動 Chromium。請更新 App；或到「瀏覽器」頁設定外部 Termux。');
      if (!L.installed()) throw new Error('AI 瀏覽器需要內建 Linux 的 Chromium：到 App「瀏覽器」頁 →「內建 Linux」→ 按「安裝（含 Chromium）」（約 10 分鐘，只要一次）。');
      throw new Error('內建 Linux 還沒裝 Chromium：到 App「瀏覽器」頁 →「內建 Linux」→ 按「加裝 Chromium」。');
    }
    if (embedded && S.get('termux.mode') !== 'embedded') S.set('termux.mode', 'embedded', 'human');
    const w = +this.cfg.width || 1280, h = +this.cfg.height || 800; this.vp = { w, h };
    const port = +S.get('termux.chromium_port') || 9222; const probe = async (tp, ms = 2500) => { try { await httpGet(tp, '/json/version', 'GET', ms); return true; } catch { return false; } };
    if (!fresh && await probe({ host: '127.0.0.1', port })) { this.phase = ''; return { host: '127.0.0.1', port }; }
    const bridgeUp = async () => {
      if (!embedded) return;   // 外部 Termux 的橋接由使用者自己的 Termux 負責（錯誤訊息會教他怎麼重開）
      if (!L.running()) { this.phase = '正在啟動內建 Linux'; await L.start(); return; }
      try { await T.health(); } catch { this.phase = '內建 Linux 沒有回應，正在重啟'; log.warn('橋接沒有回應，重啟內建 Linux'); await L.stop(); await L.start(); }
    };
    await bridgeUp();
    if (fresh) { this.phase = '瀏覽器沒反應，正在重開'; await T.chromiumStop().catch(() => {}); await sleep(800); }
    this.phase = '正在啟動 Chromium（第一次約 30～60 秒）';
    const opts = { port, width: w, height: h, url: this.home(), ...(this.cfg.proxy ? { proxy: this.cfg.proxy } : {}) };
    let r; try { r = await T.chromiumStart(opts); }
    catch (e) {
      if (!embedded || !/橋接|ECONN|逾時|socket|fetch failed/i.test(e.message)) { this.phase = ''; throw e; }
      log.warn('啟動 Chromium 時橋接斷線，重啟內建 Linux 再試：' + e.message); this.phase = '橋接斷線，重啟內建 Linux 後再試';
      await L.stop().catch(() => {}); await L.start(); r = await T.chromiumStart(opts);
    }
    const tp = { host: '127.0.0.1', port: +r.port || port };
    for (let i = 0; i < 20 && !(await probe(tp, 1500)); i++) await sleep(500);
    this.phase = ''; return tp;
  }
  androidSock() {
    const e = this.androidEndpoint(); return e ? (e.sock || `127.0.0.1:${e.port}`) : '';
  }
  androidEndpoint() {
    try {
      const j = JSON.parse(fs.readFileSync(path.join(this.ctx.paths.data, 'browser_host.json'), 'utf8'));
      if (!j || !j.pid || j.enabled === false) return null;
      if (Number.isInteger(+j.proxyPort) && +j.proxyPort > 0 && typeof j.proxyToken === 'string' && j.proxyToken.length >= 32) {
        return { host: '127.0.0.1', port: +j.proxyPort, hostHeader: `localhost:${+j.proxyPort}`, headers: { 'X-Agent-CDP-Token': j.proxyToken } };
      }
      if (+j.relayVersion >= 1) return { error: 'Android 原生 WebView CDP relay 尚未就緒，請重新開啟 App。' };
      return { sock: '\0webview_devtools_remote_' + j.pid };
    } catch { return null; }
  }
  async lock(fn) { const run = this._lock.then(fn, fn); this._lock = run.catch(() => {}); return run; }

  // ---------- 連線 ----------
  async ensure() {
    this.lastActive = Date.now();
    if (this.cdp && this.cdp.open) return;
    if (this._ensuring) return this._ensuring;
    this._ensuring = (async () => {
      try {
        for (let attempt = 0; attempt < 9; attempt++) {
          try { await this._connect(); this.err = ''; return; }
          catch (e) {
            this.err = e.message;
            const pv = this.resolveProvider();
            if (pv === 'linux' && attempt < 1 && !/沒有內建|需要內建|還沒裝|設定外部/.test(e.message)) { await sleep(1500); continue; }   // 受管理的 Chromium：整套再試一次
            if (pv !== 'android' || !/ECONNREFUSED|ENOENT/.test(e.message) || attempt === 8) throw e;
            await sleep(300);
          }
        }
      } finally { this._ensuring = null; }
    })();
    return this._ensuring;
  }
  async _connect() {
    const prov = this.resolveProvider(); this.provider = prov; this.starts++;
    if (prov === 'android') {
      const endpoint = this.androidEndpoint(); if (!endpoint) throw new Error('App 的瀏覽器區還沒啟動。請在 App 的「瀏覽器」頁按「啟用 App 內瀏覽器」，或重新開啟 App。');
      if (endpoint.error) throw new Error(endpoint.error);
      this.tp = endpoint;
    } else if (prov === 'linux') {
      this.tp = await this._linuxChrome();
    } else if (prov === 'cdp') {
      const u = new URL(this.cfg.cdp_url); this.tp = { host: u.hostname, port: +u.port || 9222 };
    } else {
      this.tp = await this._launchLocal();
    }
    let list; try { list = await httpGet(this.tp, '/json/list'); }
    catch (e) {
      if (prov !== 'linux') throw new Error(`連不上瀏覽器（${prov}）：${e.message}${prov === 'cdp' && this.isLocalCdp() ? '。這個位址上的 Chromium 沒在跑：到「瀏覽器」頁按「啟動 Chromium 並設為 AI 瀏覽器」，之後 App 會自動管理（掛掉會自己重開）。' : ''}`);
      log.warn('Chromium 沒回應，自動重開：' + e.message); this.tp = await this._linuxChrome({ fresh: true });
      try { list = await httpGet(this.tp, '/json/list'); } catch (e2) { throw new Error(`連不上瀏覽器（linux）：${e2.message}。已自動重開過一次 Chromium；請到「瀏覽器」頁看「內建 Linux」的診斷。`); }
    }
    let pages = (Array.isArray(list) ? list : []).filter((t) => t.type === 'page' && t.webSocketDebuggerUrl);
    if (!pages.length && prov !== 'android') { const nu = '/json/new?' + encodeURIComponent(this.home()); const t = await httpGet(this.tp, nu, 'PUT').catch(() => httpGet(this.tp, nu)); if (t && t.webSocketDebuggerUrl) pages = [t]; }
    if (!pages.length && prov === 'linux') { this.tp = await this._linuxChrome({ fresh: true }); const t = await httpGet(this.tp, '/json/new?about:blank', 'PUT').catch(() => httpGet(this.tp, '/json/new?about:blank')).catch(() => null); if (t && t.webSocketDebuggerUrl) pages = [t]; }
    if (!pages.length) throw new Error('瀏覽器裡沒有可操作的分頁');
    const keep = this.tabId && pages.find((t) => t.id === this.tabId); await this._attach(keep || pages[0]);
    // 26.11.3 Revise6：開起來是空白頁 → 直接到首頁（預設 Google），並推一張畫面給 App
    try {
      const u = await this.evalPage('() => location.href'); const short = this.home().replace(/^https?:\/\//, '').replace(/\/$/, '');
      if (!u || /^about:blank/.test(u) || /^chrome:\/\/newtab/.test(u)) { await this.goto(this.home()); await this.snapStep('開啟首頁 ' + short); }
      else { await this.waitLoad(8000); await this.snapStep(u.replace(/\/$/, '') === this.home().replace(/\/$/, '') ? '開啟首頁 ' + short : '瀏覽器已連線'); }   // 每次連上都先推一張目前畫面
    }
    catch (e) { log.warn('開首頁失敗：' + e.message); }
  }
  async _launchLocal() {
    if (this.proc && this.proc.exitCode === null && this.tp && this.tp.port) { try { await httpGet(this.tp, '/json/version', 'GET', 2500); return this.tp; } catch { try { this.proc.kill('SIGKILL'); } catch { /* ignore */ } this.proc = null; } }
    const bin = findChrome(this.cfg.chrome_path);
    if (!bin) throw new Error('找不到 Chrome／Chromium／Edge。請安裝其中一個，或在設定頁「瀏覽器」填入執行檔路徑；手機版請用 App 內瀏覽器。');
    fs.mkdirSync(this.profileDir, { recursive: true }); for (const f of ['SingletonLock', 'SingletonCookie', 'SingletonSocket']) { try { fs.rmSync(path.join(this.profileDir, f), { force: true }); } catch { /* ignore */ } }
    const port = await freePort(+this.cfg.port || 9333); const w = +this.cfg.width || 1280, h = +this.cfg.height || 800; this.vp = { w, h };
    const args = [`--remote-debugging-port=${port}`, '--remote-debugging-address=127.0.0.1', `--user-data-dir=${this.profileDir}`, '--no-first-run', '--no-default-browser-check', '--disable-features=Translate,MediaRouter', '--disable-blink-features=AutomationControlled',
      '--disable-background-timer-throttling', '--disable-renderer-backgrounding', '--disable-backgrounding-occluded-windows', '--password-store=basic', '--use-mock-keychain', `--window-size=${w},${h}`, '--lang=zh-TW', '--disable-dev-shm-usage', '--disable-background-networking', '--disable-component-update', '--disable-sync', '--metrics-recording-only', '--disk-cache-size=52428800', '--media-cache-size=10485760'];
    if (this.cfg.headless !== false) args.push('--headless=new'); if (typeof process.getuid === 'function' && process.getuid() === 0) args.push('--no-sandbox');
    if (this.cfg.proxy) args.push('--proxy-server=' + this.cfg.proxy); args.push(this.home());
    log.info('啟動瀏覽器：' + bin); const p = spawn(bin, args, { stdio: ['ignore', 'ignore', 'pipe'], detached: false }); this.proc = p; let errTxt = '';
    p.stderr.on('data', (d) => { errTxt = (errTxt + d).slice(-1500); }); p.on('exit', (c) => { log.warn(`瀏覽器行程結束 code=${c}`); if (this.proc === p) this.proc = null; });
    const tp = { host: '127.0.0.1', port }; const t0 = Date.now();
    while (Date.now() - t0 < 20000) { if (p.exitCode !== null) throw new Error('瀏覽器啟動後立刻結束：' + errTxt.split('\n').slice(-3).join(' ')); try { await httpGet(tp, '/json/version', 'GET', 1500); return tp; } catch { await sleep(300); } }
    throw new Error('瀏覽器啟動逾時：' + errTxt.slice(-200));
  }
  async _attach(tab) {
    if (this.cdp) { this.cdp.onclose = null; this.cdp.close(); }
    const c = new CDP(); const wsPath = new URL(tab.webSocketDebuggerUrl.replace(/^ws:\/\/[^/]+/, 'http://x')).pathname; await c.connect(this.tp, wsPath);
    this.cdp = c; this.tabId = tab.id; this.dialog = null; this.lastFrame = null;
    c.onclose = () => { if (this.cdp === c) { log.warn('瀏覽器連線中斷'); this.cdp = null; this._scheduleReconnect(); } };
    c.on('Page.javascriptDialogOpening', (p) => { this.dialog = { type: p.type, message: p.message, ts: Date.now() }; c.send('Page.handleJavaScriptDialog', { accept: true, promptText: p.defaultPrompt || '' }).catch(() => {}); });
    await c.send('Page.enable'); await c.send('Runtime.enable').catch(() => {});
    if (this.provider !== 'android') {
      await c.send('Emulation.setDeviceMetricsOverride', { width: this.vp.w, height: this.vp.h, deviceScaleFactor: 1, mobile: false }).catch(() => {});
      if (!this.uaFixed) { try { const v = await httpGet(this.tp, '/json/version'); this.uaFixed = String(v['User-Agent'] || '').replace(/HeadlessChrome/g, 'Chrome'); } catch { /* ignore */ } }
      if (this.uaFixed) await c.send('Emulation.setUserAgentOverride', { userAgent: this.uaFixed, acceptLanguage: 'zh-TW,zh;q=0.9,en;q=0.8' }).catch(() => {});
    } else { try { const m = await c.send('Page.getLayoutMetrics'); const v = m.cssVisualViewport || m.visualViewport; if (v) this.vp = { w: Math.round(v.clientWidth), h: Math.round(v.clientHeight) }; } catch { /* ignore */ } }
  }
  /** 連線意外中斷：背景自動重連（退避），不用等下一次工具呼叫 */
  _scheduleReconnect() {
    if (this._rc || !this.enabled() || this._closing) return; const n = ++this.reconnects; if (n > 8) return;
    this._rc = setTimeout(async () => { this._rc = null; try { await this.ensure(); this.reconnects = 0; log.info('瀏覽器已自動重新連線'); } catch (e) { log.warn('瀏覽器重連失敗：' + e.message); this._scheduleReconnect(); } }, Math.min(30000, 1500 * 2 ** Math.min(n, 4)));
  }
  async shutdown() {
    this._closing = true; clearTimeout(this._rc); this._rc = null;
    if (this.cdp) { this.cdp.onclose = null; this.cdp.close(); this.cdp = null; }
    if (this.proc) { const p = this.proc; this.proc = null; try { p.kill('SIGTERM'); } catch { /* ignore */ } setTimeout(() => { try { p.kill('SIGKILL'); } catch { /* ignore */ } }, 4000).unref(); }
    this._closing = false;
  }
  /** 每 45 秒：心跳（偵測假死）、整理分頁、閒置回收 */
  /**
   * 26.11.3 Revise7：瀏覽器運作時產生的圖片自動刪除
   *  ・每一步的截圖只放在記憶體，超過 browser.step_ttl_min（預設 30 分鐘）就丟掉；關閉瀏覽器後也會在同樣時間後清空
   *  ・AI 存到工作區的截圖（images/shot-*）超過 browser.shot_keep_h（預設 24 小時）自動刪除
   *  ・手機代理的步驟截圖也一起清（phone_agent.step_ttl_min）
   */
  // ---------- 26.11.3 pro2.1：圖片紀錄可以刪、可以隱藏；每次任務做完 5 分鐘後自動刪除 ----------
  showSteps() { return this.cfg.show_steps !== false; }
  /** 任務結束（AI 這一輪回覆完、或你接手操作後）：排程 N 分鐘後清掉（browser.clear_after_task_min，預設 5；0＝不自動清） */
  taskDone() {
    const has = this.steps.length || (this.ctx.phoneagent && this.ctx.phoneagent.steps.length); if (!has) return 0;
    const m = this.cfg.clear_after_task_min === 0 ? 0 : Math.max(1, +this.cfg.clear_after_task_min || 5); if (!m) return 0;
    this._clearAt = Date.now() + m * 60000; this.ev.emit('clear_at', { at: this._clearAt }); return this._clearAt;
  }
  autoClear() { if (this._clearAt && Date.now() >= this._clearAt && !this._inRun && !(this.ctx.phoneagent && this.ctx.phoneagent.task)) { this._clearAt = 0; const r = this.clearSteps({ reason: 'auto' }); if (r.steps || r.files) log.info(`任務結束 5 分鐘，自動刪掉圖片紀錄：${r.steps} 張、存檔截圖 ${r.files} 個`); } }
  /** 刪掉所有圖片紀錄（瀏覽器步驟、手機代理步驟、AI 存的瀏覽器截圖檔） */
  clearSteps({ files = true, reason = 'manual' } = {}) {
    let n = this.steps.length; this.steps = []; this.lastFrame = null; this._clearAt = 0; let f = 0;
    if (this.ctx.phoneagent) { n += this.ctx.phoneagent.steps.length; this.ctx.phoneagent.steps = []; this.ctx.phoneagent.ev.emit('cleared', { reason }); }
    if (files) { const dir = path.join(this.ctx.paths.workspace, 'images'); try { for (const x of fs.readdirSync(dir)) if (/^shot-/.test(x)) { try { fs.rmSync(path.join(dir, x), { force: true }); f++; } catch { /* ignore */ } } } catch { /* 沒有資料夾 */ } }
    this.ev.emit('cleared', { reason }); return { steps: n, files: f };
  }
  deleteStep(seq) { const before = this.steps.length; this.steps = this.steps.filter((x) => x.seq !== +seq); if (this.steps.length === before) throw new Error('沒有這一步'); if (!this.steps.length) this.lastFrame = null; this.ev.emit('cleared', { reason: 'one', seq: +seq }); return { ok: true }; }
  sweepImages(force = false) {
    if (!force && Date.now() - (this._swept || 0) < 5 * 60000) return { steps: 0, files: 0 }; this._swept = Date.now();
    const ttl = Math.max(1, +this.cfg.step_ttl_min || 30) * 60000; const before = this.steps.length; this.steps = this.steps.filter((x) => Date.now() - x.ts < ttl); if (!this.steps.length) this.lastFrame = null;
    let files = 0; const keep = Math.max(1, +this.cfg.shot_keep_h || 24) * 3600e3; const dir = path.join(this.ctx.paths.workspace, 'images');
    try { for (const f of fs.readdirSync(dir)) { if (!/^shot-/.test(f)) continue; const p = path.join(dir, f); try { if (Date.now() - fs.statSync(p).mtimeMs > keep) { fs.rmSync(p, { force: true }); files++; } } catch { /* ignore */ } } } catch { /* 沒有資料夾 */ }
    try { if (this.ctx.phoneagent) this.ctx.phoneagent.sweep(); } catch { /* ignore */ }
    if (before - this.steps.length || files) log.info(`自動清掉瀏覽器圖片：步驟截圖 ${before - this.steps.length} 張、存檔截圖 ${files} 個`);
    return { steps: before - this.steps.length, files };
  }
  async tick() {
    this.sweepImages();
    if (!this.cdp || !this.cdp.open) {
      // 看門狗：受管理的 Chromium 最近 30 分鐘有在用（或設定開機自動啟動），斷了就在背景自己接回去，AI 下次用時不用等
      if (this.enabled() && !this._ensuring && !this._closing && this.control === 'ai' && this.resolveProvider() === 'linux' && (this.cfg.autostart || Date.now() - this.lastActive < 30 * 60000)) await this.ensure().catch((e) => log.warn('瀏覽器看門狗重連失敗：' + e.message));
      return;
    }
    try { await this.cdp.send('Runtime.evaluate', { expression: '1', returnByValue: true }, 8000); } catch (e) { log.warn('瀏覽器心跳失敗，重新連線：' + e.message); const c = this.cdp; this.cdp = null; try { c.close(); } catch { /* ignore */ } await this.ensure().catch(() => {}); return; }
    if (this.provider === 'local') {
      try { const list = await httpGet(this.tp, '/json/list'); const pages = list.filter((t) => t.type === 'page'); if (pages.length > 8) for (const t of pages.filter((x) => x.id !== this.tabId).slice(0, pages.length - 6)) await httpGet(this.tp, '/json/close/' + t.id).catch(() => {}); } catch { /* ignore */ }
      const idle = (+this.cfg.idle_close_min || 0) * 60000; if (idle && this.control === 'ai' && Date.now() - this.lastActive > idle) { log.info('瀏覽器閒置過久，先關閉以節省記憶體（登入狀態保留在設定檔，下次使用自動重開）'); await this.shutdown(); }
    }
  }
  /** 失敗時自動重連一次再重試（長時間運作時 Chrome 偶爾會斷） */
  async run(fn, label = '') {
    return this.lock(async () => {
      this.lastActive = Date.now(); this._inRun++; try {
      for (let i = 0; i < 2; i++) {
        try { await this.ensure(); return await fn(); }
        catch (e) { const dead = /連線已中斷|尚未連線|WebSocket|ECONN|Target closed|No target|Session closed|not opened/i.test(e.message); if (i === 0 && dead) { log.warn(`${label} 失敗（${e.message}），重連後重試`); const c = this.cdp; this.cdp = null; try { c && c.close(); } catch { /* ignore */ } continue; } throw e; }
      }
      } finally { this._inRun--; }
    });
  }
  note(text) { this.lastAction = { ts: Date.now(), text }; }

  // ---------- 基本動作 ----------
  async evalPage(fnSrc, ...args) {
    const expr = `(${fnSrc})(${args.map((a) => JSON.stringify(a === undefined ? null : a)).join(',')})`;
    const r = await this.cdp.send('Runtime.evaluate', { expression: expr, returnByValue: true, awaitPromise: true }, 20000);
    if (r.exceptionDetails) throw new Error('網頁腳本錯誤：' + ((r.exceptionDetails.exception && r.exceptionDetails.exception.description) || r.exceptionDetails.text).slice(0, 200)); return r.result.value;
  }
  async waitLoad(ms = 12000) {
    const t0 = Date.now(); await sleep(250);
    while (Date.now() - t0 < ms) { try { const s = await this.evalPage('() => document.readyState'); if (s === 'complete') break; } catch { /* 頁面切換中 */ } await sleep(250); }
    await sleep(350);
  }
  async guardUrl() {   // 導覽後檢查：被轉址到本機位址就退回空白頁
    try { const u = await this.evalPage('() => location.href'); const b = blockedUrl(u); if (b) { await this.cdp.send('Page.navigate', { url: 'about:blank' }); throw new Error(b); } return u; } catch (e) { if (/本機/.test(e.message)) throw e; return ''; }
  }
  async goto(url) {
    if (!/^[a-z][a-z0-9+.-]*:/i.test(url)) url = 'https://' + url; const b = blockedUrl(url); if (b) throw new Error(b);
    let r; try { r = await this.cdp.send('Page.navigate', { url }, 30000); } catch (e) { if (!/逾時|timeout/i.test(e.message)) throw e; r = {}; log.warn('導覽逾時，仍繼續讀目前頁面'); }
    if (r.errorText) { if (/ERR_(NETWORK_CHANGED|CONNECTION_RESET|TIMED_OUT|NAME_NOT_RESOLVED|INTERNET_DISCONNECTED)/.test(r.errorText) && !this._navRetry) { this._navRetry = true; try { await sleep(1500); return await this.goto(url); } finally { this._navRetry = false; } } throw new Error('開啟失敗：' + r.errorText); }
    await this.waitLoad(); await this.guardUrl(); await this.afterAction(); await this.autoDismiss();
  }
  /** 自動關掉 cookie／同意橫幅、訂閱彈窗（browser.auto_dismiss=false 可關） */
  async autoDismiss() {
    if (this.cfg.auto_dismiss === false) return []; try { const c = await this.evalPage(PAGE.dismiss); if (c && c.length) { this.dismissed = c; await sleep(400); } return c || []; } catch { return []; }
  }
  async dismissNow() { const c = (await this.evalPage(PAGE.dismiss)) || []; if (c.length) { this.dismissed = c; await sleep(400); } return c; }
  /** 26.11.3 Revise5：用看得到的文字找元素（按鈕文字、連結文字、欄位標籤、placeholder…）。找不到會往下捲動再找一次 */
  async findEl(q, kind = 'click', { nth = 0, exact = false } = {}) {
    let r = await this.evalPage(PAGE.findEl, String(q), kind, nth, !!exact);
    if (r.err === 'notfound') { await this.autoDismiss(); r = await this.evalPage(PAGE.findEl, String(q), kind, nth, !!exact); }
    if (r.err === 'notfound') { for (let i = 0; i < 3 && r.err; i++) { await this.scroll('down', 0.9); r = await this.evalPage(PAGE.findEl, String(q), kind, nth, !!exact); } }
    if (r.err) throw new Error(r.err === 'notfound' ? `頁面上找不到「${q}」${kind === 'input' ? '這個欄位' : '這個按鈕／連結'}。用 browser_read 看看實際的名稱，或換個說法。` : r.err); return r;
  }
  async clickText(q, o = {}) { const r = await this.findEl(q, 'click', o); await this.clickId(r.id); return r; }
  async fill(fields, { submit = false } = {}) {
    const done = []; let last = null;
    for (const f of fields || []) {
      const r = await this.findEl(f.label, 'input', { nth: f.nth || 0 }); last = r;
      if (r.tag === 'select' || r.type === 'select-one' || (r.tag !== 'input' && r.tag !== 'textarea' && /combobox/.test(r.type || ''))) await this.selectId(r.id, String(f.value));
      else await this.typeId(r.id, String(f.value ?? ''), { clear: f.clear !== false });
      done.push(`${r.label || f.label}＝${/pass|密碼/i.test(f.label + r.label + r.type) ? '（已填）' : String(f.value).slice(0, 40)}`);
    }
    if (submit && last) { await sleep(150); if (this.jsInput) await this.evalPage(PAGE.jsSubmit, last.id); else await this.key('Enter'); await sleep(500); await this.waitLoad(8000); await this.afterAction(); }
    return done;
  }
  async selectId(id, option) {
    const r = await this.evalPage(PAGE.selectOpt, id, String(option)); if (r.err) throw new Error(r.err); if (r.ok) { await sleep(300); return r.text; }
    // 自訂下拉選單（div／role=combobox）：先點開，再點選項
    await this.clickId(id); await sleep(400); const o = await this.findEl(option, 'click'); await this.clickId(o.id); return o.label;
  }
  /** 等到條件成立：文字出現／消失、CSS 選擇器出現、網址包含某段。最多 timeout 秒（預設 20、上限 60） */
  async waitFor({ text, gone, selector, url, timeout = 20 } = {}) {
    const end = Date.now() + Math.min(60, Math.max(1, +timeout || 20)) * 1000;
    while (Date.now() < end) {
      try {
        const st = await this.evalPage(`(t, g, sel) => ({ body: document.body ? document.body.innerText : '', url: location.href, sel: sel ? !!document.querySelector(sel) : false })`, text || '', gone || '', selector || '');
        const ok = (!text || st.body.includes(text)) && (!gone || !st.body.includes(gone)) && (!selector || st.sel) && (!url || st.url.includes(url));
        if (ok) return true;
      } catch { /* 頁面切換中 */ }
      await sleep(500);
    }
    return false;
  }
  async extract(kind) { const r = await this.evalPage(PAGE.extract, kind); if (r == null) throw new Error('kind 只能是 links｜tables｜headings｜forms'); return r; }
  /** 編號失效（頁面重新渲染）時，用上一次讀到的名稱自動找回同一個元素 */
  async resolveId(id) {
    const c = await this.evalPage(PAGE.center, id); if (!c.err) return { id, c };
    const old = (this._snapEls || []).find((e) => e.id === id); if (!old || !old.label) throw new Error(c.err);
    const s = await this.snapshot(120); const m = s.els.find((e) => e.tag === old.tag && e.label === old.label) || s.els.find((e) => e.label === old.label);
    if (!m) throw new Error(c.err); const c2 = await this.evalPage(PAGE.center, m.id); if (c2.err) throw new Error(c2.err); log.info(`元素 [${id}] 失效，已用名稱「${old.label}」找回 [${m.id}]`); return { id: m.id, c: c2 };
  }
  async newTab(url) {
    url = url || this.home();
    if (this.provider === 'android') return this.goto(url); const t = await httpGet(this.tp, '/json/new?' + encodeURIComponent(url), 'PUT').catch(() => httpGet(this.tp, '/json/new?' + encodeURIComponent(url)));
    await this._attach(t); await this.waitLoad();
  }
  async tabs() {
    if (!this.tp) return []; try { const l = await httpGet(this.tp, '/json/list'); return l.filter((t) => t.type === 'page').map((t) => ({ id: t.id, title: t.title, url: t.url, active: t.id === this.tabId })); } catch { return []; }
  }
  async switchTab(id) { const l = await httpGet(this.tp, '/json/list'); const t = l.find((x) => x.id === id || (x.title || '').includes(id) || (x.url || '').includes(id)); if (!t) throw new Error('找不到這個分頁'); await httpGet(this.tp, '/json/activate/' + t.id).catch(() => {}); await this._attach(t); }
  async closeTab(id) { const tid = id || this.tabId; await httpGet(this.tp, '/json/close/' + tid).catch(() => {}); if (tid === this.tabId) { const l = await httpGet(this.tp, '/json/list'); const t = l.find((x) => x.type === 'page'); if (t) await this._attach(t); else await this.newTab(); } }
  /** 動作後：如果點擊開了新分頁，就切過去 */
  async afterAction() {
    if (this.provider === 'android' || !this.tp) return; try { const l = (await httpGet(this.tp, '/json/list')).filter((t) => t.type === 'page'); this._known = this._known || new Set(l.map((t) => t.id)); const fresh = l.filter((t) => !this._known.has(t.id)); l.forEach((t) => this._known.add(t.id)); if (fresh.length) { await this._attach(fresh[fresh.length - 1]); await this.waitLoad(8000); this.newTabSwitched = true; } } catch { /* ignore */ }
  }
  async snapshot(max = 80) { const s = await this.evalPage(PAGE.snap, max); this._snapEls = (s.els || []).map((e) => ({ id: e.id, tag: e.tag, label: e.label })); const b = blockedUrl(s.url); if (b) { await this.cdp.send('Page.navigate', { url: 'about:blank' }); throw new Error(b); } return s; }
  async mouse(type, x, y, extra = {}) { return this.cdp.send('Input.dispatchMouseEvent', { type, x, y, button: 'left', buttons: type === 'mouseReleased' ? 0 : 1, clickCount: 1, ...extra }); }
  async clickAt(x, y, { dbl = false, right = false } = {}) {
    this._mark = { x, y };
    if (this.jsInput) { const ok = await this.evalPage(`(x, y) => { const e = document.elementFromPoint(x, y); if (!e) return false; e.focus && e.focus(); e.click(); return true; }`, x, y); if (ok) return; }
    const b = right ? { button: 'right', buttons: 2 } : {}; await this.mouse('mouseMoved', x, y, { buttons: 0 }); await sleep(40 + Math.random() * 60);
    await this.mouse('mousePressed', x, y, { clickCount: dbl ? 2 : 1, ...b }); await sleep(30 + Math.random() * 50); await this.mouse('mouseReleased', x, y, { clickCount: dbl ? 2 : 1, ...b });
  }
  async clickId(id0) {
    const { id, c } = await this.resolveId(id0);
    this._mark = { x: c.x, y: c.y }; if (c.covered || this.jsInput) { await this.evalPage(PAGE.jsClick, id); } else await this.clickAt(c.x, c.y);
    await sleep(350); await this.waitLoad(5000); await this.afterAction(); return c;
  }
  async typeId(id0, text, { clear = true, submit = false } = {}) {
    const { id, c } = await this.resolveId(id0);
    if (c.type === 'date' || c.type === 'time' || c.tag === 'select') { await this.evalPage(PAGE.setValue, id, text); }
    else if (this.jsInput) { await this.evalPage(PAGE.jsType, id, String(text), clear); if (submit) { await sleep(150); await this.evalPage(PAGE.jsSubmit, id); await sleep(400); await this.waitLoad(6000); await this.afterAction(); } return; }
    else { await this.clickAt(c.x, c.y); await this.evalPage(PAGE.focus, id, clear); if (clear) await this.key('Control+a'); if (text === '' && clear) await this.key('Backspace'); else await this.cdp.send('Input.insertText', { text: String(text) }); }
    if (submit) { await sleep(150); await this.key('Enter'); await sleep(400); await this.waitLoad(6000); await this.afterAction(); }
  }
  async insertText(text) { if (this.jsInput) { const ok = await this.evalPage(`(t) => document.execCommand('insertText', false, t)`, String(text)); if (ok) return; } await this.cdp.send('Input.insertText', { text: String(text) }); }
  async key(spec) {
    if (this.jsInput && /^(Enter|Tab|Escape|Backspace|Delete|Arrow\w+)$/.test(spec)) return this.evalPage(PAGE.jsKey, spec);
    const parts = String(spec).split('+'); const k = parts.pop(); const mods = parts.map((m) => m.toLowerCase()); let modifiers = 0; if (mods.includes('alt')) modifiers |= 1; if (mods.includes('control') || mods.includes('ctrl')) modifiers |= 2; if (mods.includes('meta') || mods.includes('cmd')) modifiers |= 4; if (mods.includes('shift')) modifiers |= 8;
    const def = KEYS[k] || (k.length === 1 ? { key: k, code: /[a-z]/i.test(k) ? 'Key' + k.toUpperCase() : /\d/.test(k) ? 'Digit' + k : '', vk: k.toUpperCase().charCodeAt(0), text: k } : null); if (!def) throw new Error('不認得的按鍵：' + spec);
    const cmds = modifiers & 2 ? ({ a: ['selectAll'], c: ['copy'], v: ['paste'], x: ['cut'], z: ['undo'] }[k.toLowerCase()]) : undefined;
    const base = { modifiers, key: def.key, code: def.code, windowsVirtualKeyCode: def.vk, nativeVirtualKeyCode: def.vk };
    await this.cdp.send('Input.dispatchKeyEvent', { type: def.text && !modifiers ? 'keyDown' : 'rawKeyDown', ...base, ...(def.text && !(modifiers & 6) ? { text: def.text } : {}), ...(cmds ? { commands: cmds } : {}) }); await this.cdp.send('Input.dispatchKeyEvent', { type: 'keyUp', ...base });
  }
  async scroll(dir = 'down', amount = 0.8, x, y) {
    const vp = await this.viewport(); const px = Math.round(amount <= 5 ? amount * vp.h : amount); const dx = dir === 'left' ? -px : dir === 'right' ? px : 0, dy = dir === 'up' ? -px : dir === 'down' ? px : 0;
    await this.cdp.send('Input.dispatchMouseEvent', { type: 'mouseWheel', x: x ?? vp.w / 2, y: y ?? vp.h / 2, deltaX: dx, deltaY: dy }); await sleep(450);
  }
  async viewport() { try { const m = await this.cdp.send('Page.getLayoutMetrics', {}, 6000); const v = m.cssVisualViewport || m.visualViewport; if (v) this.vp = { w: Math.round(v.clientWidth), h: Math.round(v.clientHeight) }; } catch { /* ignore */ } return this.vp; }
  async history(delta) { const h = await this.cdp.send('Page.getNavigationHistory'); const e = h.entries[h.currentIndex + delta]; if (!e) throw new Error(delta < 0 ? '沒有上一頁' : '沒有下一頁'); await this.cdp.send('Page.navigateToHistoryEntry', { entryId: e.id }); await this.waitLoad(); }
  async reload() { await this.cdp.send('Page.reload'); await this.waitLoad(); }
  /** 截圖（JPEG）。給 AI 看：寬度縮到 ≤1024、品質 55，省 token 又夠看 */
  async screenshot({ quality = 55, maxW = 1024, full = false } = {}) {
    const vp = await this.viewport(); const scale = Math.min(1, maxW / vp.w); const p = { format: 'jpeg', quality, captureBeyondViewport: false, fromSurface: true };
    if (full) { const m = await this.cdp.send('Page.getLayoutMetrics'); const cs = m.cssContentSize || m.contentSize; p.captureBeyondViewport = true; p.clip = { x: 0, y: 0, width: cs.width, height: Math.min(cs.height, 6000), scale }; } else if (scale < 1) p.clip = { x: 0, y: 0, width: vp.w, height: vp.h, scale };
    const r = await this.cdp.send('Page.captureScreenshot', p, 12000); return Buffer.from(r.data, 'base64');
  }
  /** App「瀏覽器」頁用的畫面：250 毫秒內重複索取共用同一張 */
  async frame() {
    if (this.lastFrame && Date.now() - this.lastFrameAt < 250) return this.lastFrame;
    if (this._inRun && this.lastFrame) return this.lastFrame;   // AI 正在動作：不要排隊等鎖，先給最近一步的畫面（新的一步做完會推過去）
    const buf = await this.run(() => this.screenshot({ quality: 60, maxW: 1100 }), 'frame'); this.lastFrame = buf; this.lastFrameAt = Date.now(); return buf;
  }
  async pageInfo() { try { return await this.evalPage('() => ({ url: location.href, title: document.title, ready: document.readyState })'); } catch { return { url: '', title: '', ready: '' }; } }

  // ---------- 給 AI 的文字化頁面 ----------
  fmtEls(s, max = 60) {
    const rows = s.els.slice(0, max).map((e) => { const flag = [e.checked ? '已勾選' : '', e.disabled ? '停用' : '', !e.inView ? '畫面外' : ''].filter(Boolean).join('/'); const kind = e.role || (e.tag === 'input' ? 'input:' + (e.type || 'text') : e.tag);
      return `[${e.id}] ${kind} ${e.label ? '「' + e.label + '」' : ''}${e.value ? ' 值=' + e.value : ''}${e.href ? ' → ' + e.href : ''}${flag ? ' (' + flag + ')' : ''}`; });
    return rows.join('\n') + (s.total > max ? `\n…還有 ${s.total - Math.min(max, s.els.length)} 個元素沒列出（用 browser_scroll 後再 browser_read）` : '');
  }
  async readText(full = true) {
    const s = await this.snapshot(full ? 100 : 50); const sc = s.scroll; const where = sc.h > sc.vh * 1.2 ? `（捲動位置 ${Math.round((sc.y / Math.max(1, sc.h - sc.vh)) * 100)}%）` : '';
    let out = `網址：${s.url}\n標題：${s.title}${where}${this.dialog && Date.now() - this.dialog.ts < 20000 ? `\n（剛剛自動處理了一個網頁對話框：${this.dialog.message}）` : ''}${this.newTabSwitched ? '\n（已自動切換到新開的分頁）' : ''}${this.dismissed && this.dismissed.length ? `\n（已自動關掉浮動橫幅：按了「${this.dismissed.join('、')}」）` : ''}\n`; this.newTabSwitched = false; this.dismissed = null;
    out += `\n── 可操作元素 ──\n${this.fmtEls(s, full ? 100 : 50)}\n\n── 頁面文字 ──\n${s.text.slice(0, full ? 6000 : 1200)}`; return out;
  }
  /** 動作之後回傳的精簡頁面狀態（省去一次 browser_read，加速） */
  async brief(prefix) { try { return `${prefix}\n\n${await this.readText(false)}`; } catch (e) { return `${prefix}\n（讀取頁面狀態失敗：${e.message}）`; } }

  // ---------- 接手 ----------
  status() {
    return { home: this.home(), step: this.stepMeta(this.lastStep()), steps: this.steps.length, show_steps: this.showSteps(), clear_at: this._clearAt || 0, clear_after_min: this.cfg.clear_after_task_min === 0 ? 0 : Math.max(1, +this.cfg.clear_after_task_min || 5), enabled: this.enabled(), provider: this.provider || this.resolveProvider(), managed: this.resolveProvider() === 'linux', phase: this.phase || '', connected: !!(this.cdp && this.cdp.open), control: this.control, handoff: this.handoff, last_action: this.lastAction, error: this.err, viewport: this.vp, headless: this.cfg.headless !== false,
      chrome: this.resolveProvider() === 'local' ? (findChrome(this.cfg.chrome_path) || '') : '', starts: this.starts };
  }
  requestHandoff(reason, origin) {
    this.control = 'user'; this.handoff = { reason: String(reason || '需要你協助').slice(0, 300), at: Date.now(), origin: origin || null };
    this.ctx.notifier.push('warn', '🖐 AI 需要你接手瀏覽器', this.handoff.reason + '\n請到 App →「瀏覽器」頁，處理完按「交還給 AI」。', { force: true }).catch(() => {}); return this.handoff;
  }
  takeOver() { this.control = 'user'; if (!this.handoff) this.handoff = { reason: '管理員主動接手', at: Date.now(), origin: null }; this.note('管理員接手中'); }
  async giveBack() {
    const h = this.handoff; this.control = 'ai'; this.handoff = null; this.note('已交還給 AI'); this.lastActive = Date.now();
    if (h && h.origin && this.ctx.hub) this.ctx.hub.resumeAfterHandoff(h.origin).catch((e) => log.warn('通知 AI 繼續失敗：' + e.message));
    return { ok: true, resumed: !!(h && h.origin) };
  }
  guardAI() { if (!this.enabled()) throw new Error('管理員已關閉瀏覽器功能（設定頁 → 瀏覽器）'); if (this.control === 'user') throw new Error(`瀏覽器目前由管理員接手中（${(this.handoff && this.handoff.reason) || ''}）。請先告訴管理員你卡在哪，等他按「交還給 AI」後會自動通知你繼續；不要重複呼叫。`); }
}
module.exports = { Browser, PAGE, blockedUrl, findChrome, KEYS };
