'use strict';
/**
 * 26.11.3 pro10 工程計算機（SI 單位、純計算）：常見工程題直接給公式、代入過程與結果，並附工程判讀。
 *  beam       梁：簡支／懸臂 × 集中／均布載重 → 最大彎矩、最大撓度、最大彎曲應力、安全係數
 *  pipe       管流：雷諾數、流態、摩擦係數、壓損、所需泵功率
 *  gas        理想氣體 PV = nRT（給三個求第四個）
 *  projectile 拋體：飛行時間、最大高度、射程
 *  rotation   轉動：功率 = 扭矩 × 角速度（給兩個求第三個），含齒輪比
 *  thermal    熱：傳導熱流、熱膨脹、加熱所需能量與時間
 *  buckling   柱挫屈（尤拉臨界載重）
 */
const g = (a, k, name) => { const v = a[k]; if (v == null || v === '') return null; const n = Number(v); if (!Number.isFinite(n)) throw new Error(`${name || k} 要是數字（SI 單位）`); return n; };
const need = (a, k, name) => { const v = g(a, k, name); if (v == null) throw new Error(`要給 ${k}（${name}）`); return v; };
const f = (x, n = 5) => { if (!Number.isFinite(x)) return String(x); if (x === 0) return '0'; const a = Math.abs(x); const r = parseFloat(x.toPrecision(n)); return a >= 1e6 || a < 1e-3 ? r.toExponential().replace(/\.?0+e/, 'e') : String(r); };
const MAT = { steel: [200e9, 250e6, '鋼'], 鋼: [200e9, 250e6, '鋼'], aluminum: [69e9, 240e6, '鋁（6061-T6）'], 鋁: [69e9, 240e6, '鋁（6061-T6）'], copper: [117e9, 70e6, '銅'], 銅: [117e9, 70e6, '銅'], wood: [11e9, 40e6, '木材（順紋）'], 木: [11e9, 40e6, '木材（順紋）'], concrete: [30e9, 3e6, '混凝土（抗拉）'], titanium: [114e9, 880e6, '鈦合金'] };
/** 截面慣性矩 I 與到中性軸距離 c：矩形 b×h、圓 d、空心圓 d,di；或直接給 I、c */
function section(a) {
  const I0 = g(a, 'I', '慣性矩'); if (I0 != null) return { I: I0, c: g(a, 'c', '到中性軸距離'), desc: `I = ${f(I0)} m⁴` };
  const b = g(a, 'width'), h = g(a, 'height'), d = g(a, 'diameter'), di = g(a, 'inner') || 0;
  if (b != null && h != null) return { I: b * h ** 3 / 12, c: h / 2, desc: `矩形 ${f(b)}×${f(h)} m：I = bh³/12 = ${f(b * h ** 3 / 12)} m⁴` };
  if (d != null) return { I: Math.PI * (d ** 4 - di ** 4) / 64, c: d / 2, desc: `${di ? '空心' : ''}圓 d=${f(d)} m：I = π(d⁴${di ? '−dᵢ⁴' : ''})/64 = ${f(Math.PI * (d ** 4 - di ** 4) / 64)} m⁴` };
  throw new Error('要給截面：width＋height（矩形）、diameter（圓，可加 inner）、或直接給 I');
}
function beam(a) {
  const L = need(a, 'L', '跨距 m'); const sup = /cant|懸臂/i.test(a.support || '') ? 'cantilever' : 'simple'; const P = g(a, 'P', '集中載重 N'), w = g(a, 'w', '均布載重 N/m'); if (P == null && w == null) throw new Error('要給 P（集中載重 N）或 w（均布載重 N/m）');
  const m = MAT[String(a.material || 'steel').toLowerCase()] || MAT.steel; const E = g(a, 'E', '彈性模數 Pa') ?? m[0]; const sy = g(a, 'yield', '降伏強度 Pa') ?? m[1]; const s = section(a);
  let M, d, mf, df;
  if (sup === 'simple') { if (P != null) { M = P * L / 4; d = P * L ** 3 / (48 * E * s.I); mf = 'PL/4'; df = 'PL³/(48EI)'; } else { M = w * L ** 2 / 8; d = 5 * w * L ** 4 / (384 * E * s.I); mf = 'wL²/8'; df = '5wL⁴/(384EI)'; } }
  else if (P != null) { M = P * L; d = P * L ** 3 / (3 * E * s.I); mf = 'PL'; df = 'PL³/(3EI)'; } else { M = w * L ** 2 / 2; d = w * L ** 4 / (8 * E * s.I); mf = 'wL²/2'; df = 'wL⁴/(8EI)'; }
  const sig = s.c ? M * s.c / s.I : null; const sf = sig ? sy / sig : null; const ratio = L / d;
  return { M, deflection: d, stress: sig, sf, text: [`${sup === 'simple' ? '簡支梁' : '懸臂梁'}，${P != null ? `${sup === 'simple' ? '中央' : '自由端'}集中載重 P = ${f(P)} N` : `均布載重 w = ${f(w)} N/m`}，L = ${f(L)} m，E = ${f(E)} Pa${a.E == null ? `（${m[2]}）` : ''}`, s.desc,
    `最大彎矩 M = ${mf} = ${f(M)} N·m`, `最大撓度 δ = ${df} = ${f(d)} m（${f(d * 1000)} mm，L/${f(ratio, 3)}）`, sig != null ? `最大彎曲應力 σ = Mc/I = ${f(sig)} Pa（${f(sig / 1e6)} MPa）` : '', sf != null ? `安全係數 = 降伏強度 ${f(sy / 1e6)} MPa ÷ σ = ${f(sf, 3)}${sf < 1 ? '　→ 會降伏，不可用' : sf < 1.5 ? '　→ 偏低，一般結構建議 1.5～2 以上' : ''}` : '',
    ratio < 250 ? `撓度偏大（L/${f(ratio, 3)}）：一般樓板／梁的使用性限制約 L/250～L/360，建議加大截面或縮短跨距` : ''].filter(Boolean).join('\n') };
}
function pipe(a) {
  const D = need(a, 'D', '管內徑 m'); const L = g(a, 'L', '管長 m') ?? 1; const rho = g(a, 'rho', '密度 kg/m³') ?? 998; const mu = g(a, 'mu', '黏度 Pa·s') ?? 1.0e-3; const eps = g(a, 'roughness', '粗糙度 m') ?? 4.5e-5; const A = Math.PI * D * D / 4;
  let v = g(a, 'v', '流速 m/s'); const Q0 = g(a, 'Q', '流量 m³/s'); if (v == null && Q0 == null) throw new Error('要給 v（流速 m/s）或 Q（流量 m³/s）'); if (v == null) v = Q0 / A; const Q = v * A;
  const Re = rho * v * D / mu; const regime = Re < 2300 ? '層流' : Re < 4000 ? '過渡區' : '紊流'; const fr = Re < 2300 ? 64 / Re : 0.25 / Math.log10(eps / (3.7 * D) + 5.74 / Re ** 0.9) ** 2;
  const dP = fr * (L / D) * rho * v * v / 2; const head = dP / (rho * 9.80665); const eta = g(a, 'efficiency', '泵效率') ?? 0.7; const Pw = dP * Q / eta;
  return { Re, f: fr, dP, text: [`管內徑 ${f(D)} m、長 ${f(L)} m，流速 ${f(v)} m/s（流量 ${f(Q)} m³/s ＝ ${f(Q * 60000)} L/min），ρ = ${f(rho)}、μ = ${f(mu)}${a.rho == null ? '（預設：20°C 的水）' : ''}`, `雷諾數 Re = ρvD/μ = ${f(Re)} → ${regime}`, `摩擦係數 f = ${f(fr)}（${Re < 2300 ? '64/Re' : 'Swamee–Jain，粗糙度 ' + f(eps) + ' m'}）`,
    `壓損 ΔP = f·(L/D)·ρv²/2 = ${f(dP)} Pa（${f(dP / 1000)} kPa，水頭 ${f(head)} m）`, `克服這段壓損的泵功率 ≈ ΔP·Q/η = ${f(Pw)} W（η = ${eta}；不含高度差與管件損失）`, v > 3 ? '流速超過 3 m/s：噪音、沖蝕與水錘風險增加，一般水管建議 1～3 m/s' : ''].filter(Boolean).join('\n') };
}
function gas(a) {
  const R = 8.314462618; const P = g(a, 'P', '壓力 Pa'), V = g(a, 'V', '體積 m³'), n = g(a, 'n', '莫耳數'), T = g(a, 'T', '溫度 K'); const miss = [['P', P], ['V', V], ['n', n], ['T', T]].filter(([, v]) => v == null).map(([k]) => k);
  if (miss.length !== 1) throw new Error('P（Pa）、V（m³）、n（mol）、T（K）給三個，求第四個'); if (T != null && T <= 0) throw new Error('T 要用絕對溫度 K（> 0）');
  const r = miss[0] === 'P' ? n * R * T / V : miss[0] === 'V' ? n * R * T / P : miss[0] === 'n' ? P * V / (R * T) : P * V / (n * R); const unit = { P: 'Pa', V: 'm³', n: 'mol', T: 'K' }[miss[0]];
  return { [miss[0]]: r, text: `理想氣體 PV = nRT（R = 8.314 J/(mol·K)）\n${miss[0]} = ${f(r, 6)} ${unit}${miss[0] === 'P' ? `（${f(r / 101325, 4)} atm）` : miss[0] === 'V' ? `（${f(r * 1000, 5)} L）` : miss[0] === 'T' ? `（${f(r - 273.15, 5)} °C）` : ''}\n（高壓或接近液化時理想氣體會失準）` };
}
function projectile(a) {
  const v = need(a, 'v', '初速 m/s'); const ang = (g(a, 'angle', '仰角 度') ?? 45) * Math.PI / 180; const h = g(a, 'h', '起始高度 m') ?? 0; const G = g(a, 'g', '重力') ?? 9.80665; const vx = v * Math.cos(ang), vy = v * Math.sin(ang);
  const t = (vy + Math.sqrt(vy * vy + 2 * G * h)) / G; const hmax = h + vy * vy / (2 * G); const R = vx * t; const vf = Math.hypot(vx, vy - G * t);
  return { t, range: R, hmax, text: `拋體（不計空氣阻力）：v₀ = ${f(v)} m/s、仰角 ${f(ang * 180 / Math.PI)}°、起始高度 ${f(h)} m\nvx = ${f(vx)} m/s、vy = ${f(vy)} m/s\n飛行時間 t = (vy + √(vy² + 2gh))/g = ${f(t)} s\n最大高度 = h + vy²/(2g) = ${f(hmax)} m\n水平射程 = vx·t = ${f(R)} m；落地速率 ${f(vf)} m/s` };
}
function rotation(a) {
  let P = g(a, 'P', '功率 W'), T = g(a, 'torque', '扭矩 N·m'), rpm = g(a, 'rpm', '轉速 rpm'); const k = [P, T, rpm].filter((x) => x != null).length; if (k !== 2) throw new Error('P（W）、torque（N·m）、rpm 給兩個，求第三個');
  const w = rpm != null ? rpm * 2 * Math.PI / 60 : P / T; if (P == null) P = T * w; else if (T == null) T = P / w; else rpm = w * 60 / (2 * Math.PI);
  const L = [`P = T·ω（ω = 2π·rpm/60）`, `功率 ${f(P)} W（${f(P / 745.7, 4)} hp）、扭矩 ${f(T)} N·m、轉速 ${f(rpm)} rpm（ω = ${f(w)} rad/s）`];
  const ratio = g(a, 'gear', '減速比'); if (ratio) { const eta = g(a, 'efficiency', '效率') ?? 0.95; L.push(`經減速比 ${f(ratio)}（效率 ${eta}）：輸出轉速 ${f(rpm / ratio)} rpm、輸出扭矩 ${f(T * ratio * eta)} N·m`); }
  return { P, torque: T, rpm, text: L.join('\n') };
}
function thermal(a) {
  const L = [];
  const k = g(a, 'k', '熱傳導係數 W/(m·K)'), A = g(a, 'A', '面積 m²'), dT = g(a, 'dT', '溫差 K'), d = g(a, 'thickness', '厚度 m');
  if (k != null && A != null && dT != null && d != null) { const q = k * A * dT / d; L.push(`熱傳導 q = kAΔT/d = ${f(q)} W（熱阻 ${f(d / (k * A))} K/W）`); }
  const al = g(a, 'alpha', '膨脹係數 1/K'), L0 = g(a, 'L0', '原長 m'); if (al != null && L0 != null && dT != null) L.push(`熱膨脹 ΔL = αL₀ΔT = ${f(al * L0 * dT)} m（${f(al * L0 * dT * 1000)} mm）`);
  const m = g(a, 'm', '質量 kg'), c = g(a, 'c', '比熱 J/(kg·K)') ?? (g(a, 'm') != null ? 4186 : null); if (m != null && dT != null) { const Q = m * c * dT; L.push(`加熱所需能量 Q = mcΔT = ${f(Q)} J（${f(Q / 3.6e6, 4)} kWh）${a.c == null ? '（比熱用水 4186）' : ''}`); const pw = g(a, 'power', '加熱功率 W'); if (pw) L.push(`用 ${f(pw)} W 加熱約需 ${f(Q / pw)} s（${f(Q / pw / 60, 4)} 分鐘，不計散熱）`); }
  if (!L.length) throw new Error('thermal：傳導給 k、A、dT、thickness；膨脹給 alpha、L0、dT；加熱給 m、dT（可加 c、power）'); return { text: L.join('\n') };
}
function buckling(a) {
  const L = need(a, 'L', '柱長 m'); const m = MAT[String(a.material || 'steel').toLowerCase()] || MAT.steel; const E = g(a, 'E') ?? m[0]; const s = section(a); const K = { pinned: 1, 兩端鉸接: 1, fixed: 0.5, 兩端固定: 0.5, cantilever: 2, 一端固定一端自由: 2, 'fixed-pinned': 0.7 }[String(a.end || 'pinned')] ?? 1;
  const Pcr = Math.PI ** 2 * E * s.I / (K * L) ** 2; return { Pcr, text: `${s.desc}\n尤拉臨界載重 Pcr = π²EI/(KL)² = ${f(Pcr)} N（${f(Pcr / 9806.65, 4)} 噸力），K = ${K}、E = ${f(E)} Pa\n（細長柱才適用；短柱先壓壞而不是挫屈，實務要再除以安全係數 2～3）` };
}
const KINDS = { beam, pipe, gas, projectile, rotation, thermal, buckling };
function run(a = {}) { const fn = KINDS[String(a.kind || '').toLowerCase()]; if (!fn) throw new Error('kind：' + Object.keys(KINDS).join('｜')); return fn(a); }
module.exports = { run, KINDS, MAT };
