'use strict';
/**
 * 26.11.3 pro2.1：股價走勢（給聊天裡的折線圖用）。
 * 資料：Yahoo Finance 公開圖表資料（query1.finance.yahoo.com/v8/finance/chart），可能延遲約 15～20 分鐘，不是投資建議。
 * 台股輸入 2330 會自動試 2330.TW（上市）再試 2330.TWO（上櫃）；美股 AAPL；指數 ^TWII；加密貨幣 BTC-USD。
 */
const CH = require('../../ui/chart.js');
const UA = 'Mozilla/5.0 (Linux; Android 14) AgentCenter/26.11';
const RANGES = { '1d': '5m', '5d': '30m', '1mo': '1d', '3mo': '1d', '6mo': '1d', ytd: '1d', '1y': '1d', '2y': '1wk', '5y': '1wk', max: '1mo' };
const NAMES = { 台積電: '2330', 鴻海: '2317', 聯發科: '2454', 台達電: '2308', 廣達: '2382', 富邦金: '2881', 國泰金: '2882', 中華電: '2412', 長榮: '2603', 陽明: '2609', 萬海: '2615', 聯電: '2303', 日月光: '3711', 元大台灣50: '0050', 台灣50: '0050', 高股息: '0056', 加權指數: '^TWII', 台股大盤: '^TWII', 大盤: '^TWII', 那斯達克: '^IXIC', 道瓊: '^DJI', 標普500: '^GSPC', 費半: '^SOX', 蘋果: 'AAPL', 輝達: 'NVDA', 特斯拉: 'TSLA', 微軟: 'MSFT', 谷歌: 'GOOGL', 亞馬遜: 'AMZN', 比特幣: 'BTC-USD', 以太幣: 'ETH-USD' };
async function get(url) {
  const r = await fetch(url, { headers: { 'user-agent': UA, accept: 'application/json' }, signal: AbortSignal.timeout(15000) });
  const text = await r.text(); let j = null; try { j = JSON.parse(text); } catch { /* ignore */ } return { status: r.status, j };
}
function candidates(sym) {
  const s = String(sym || '').trim(); if (!s) throw new Error('要給股票代號（例：2330、AAPL、^TWII）');
  const k = NAMES[s.replace(/\s+/g, '')]; const t = (k || s).toUpperCase();
  if (/^\d{4,6}[A-Z]?$/.test(t)) return [t + '.TW', t + '.TWO'];
  if (!/^[\^A-Z0-9.=-]{1,20}$/.test(t)) return null; return [t];
}
async function search(q) {
  const { j } = await get(`https://query2.finance.yahoo.com/v1/finance/search?q=${encodeURIComponent(q)}&quotesCount=3&newsCount=0`);
  const h = ((j && j.quotes) || []).find((x) => x.symbol); if (!h) throw new Error(`找不到「${q}」的股票代號，請直接給代號（例：2330、AAPL）`); return [h.symbol];
}
const pad = (n) => String(n).padStart(2, '0');
function label(ts, tz, intraday, long) {
  const d = new Date(ts * 1000); const p = Object.fromEntries(new Intl.DateTimeFormat('en-GB', { timeZone: tz, year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', hour12: false }).formatToParts(d).map((x) => [x.type, x.value]));
  return intraday ? `${p.hour === '24' ? '00' : p.hour}:${p.minute}` : long ? `${p.year}/${p.month}` : `${+p.month}/${+p.day}`;
}
async function history({ symbol, range = '1mo', interval } = {}) {
  range = RANGES[range] ? range : '1mo'; interval = interval && /^(1m|5m|15m|30m|60m|1h|1d|1wk|1mo)$/.test(interval) ? interval : RANGES[range];
  let cands = candidates(symbol); if (!cands) cands = await search(symbol); let last = null;
  for (const sym of cands) {
    const url = `https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(sym)}?range=${range}&interval=${interval}&includePrePost=false`;
    const { status, j } = await get(url); const res = j && j.chart && j.chart.result && j.chart.result[0];
    if (!res || !Array.isArray(res.timestamp) || !res.timestamp.length) { last = (j && j.chart && j.chart.error && j.chart.error.description) || `HTTP ${status}`; continue; }
    const m = res.meta || {}; const q = (res.indicators && res.indicators.quote && res.indicators.quote[0]) || {}; const tz = m.exchangeTimezoneName || 'Asia/Taipei';
    const intraday = /m$|h$/.test(interval); const long = ['2y', '5y', 'max'].includes(range);
    const rows = res.timestamp.map((t, i) => ({ t, c: q.close ? q.close[i] : null })).filter((r) => r.c !== null && r.c !== undefined);
    if (!rows.length) { last = '沒有成交資料'; continue; }
    const ds = CH.downsample(rows.map((r) => label(r.t, tz, intraday, long)), [rows.map((r) => +(+r.c).toFixed(4))], 60);
    const name = m.longName || m.shortName || sym; const price = m.regularMarketPrice ?? rows[rows.length - 1].c; const prev = m.chartPreviousClose ?? m.previousClose ?? rows[0].c;
    const chg = price - prev; const pct = prev ? (chg / prev) * 100 : 0; const cur = m.currency || '';
    const spec = { type: 'line', title: `${name}（${sym}）${{ '1d': '今天', '5d': '近 5 天', '1mo': '近 1 個月', '3mo': '近 3 個月', '6mo': '近半年', ytd: '今年以來', '1y': '近 1 年', '2y': '近 2 年', '5y': '近 5 年', max: '上市以來' }[range]}`, unit: cur === 'TWD' ? '元' : cur, x: ds.x, series: [{ name: '收盤', data: ds.cols[0] }], source: 'Yahoo Finance（可能延遲）' };
    return { symbol: sym, name, currency: cur, price, change: chg, pct, high: Math.max(...rows.map((r) => r.c)), low: Math.min(...rows.map((r) => r.c)), points: rows.length, spec, block: CH.block(spec), source: `https://finance.yahoo.com/quote/${encodeURIComponent(sym)}` };
  }
  throw new Error(`查不到「${symbol}」的股價（${last || '沒有資料'}）`);
}
module.exports = { history, candidates, NAMES };
