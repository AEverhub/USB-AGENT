'use strict';
/**
 * 26.11.3 pro7：電路工具的共用狀態（App 頁面和 AI 操作同一份）。存在 store.db.circuit_state。
 * { title, parts:[{id,type,n:[節點…],v,…}], env:{light, temp}, ts, by }
 */
const C = require('../../ui/circuit.js');
const MAXP = 60;

class CircuitState {
  constructor(ctx) { this.ctx = ctx; }
  get() { const s = this.ctx.store.db.circuit_state; return s && Array.isArray(s.parts) ? { env: { light: 300, temp: 25 }, ...s } : { ...C.preset('led'), ts: 0 }; }
  /** 檢查並整理（每個零件重新跑一次文字格式，壞的資料進不來） */
  clean(s) {
    if (!s || !Array.isArray(s.parts)) throw new Error('電路格式不對');
    if (s.parts.length > MAXP) throw new Error(`最多 ${MAXP} 個零件`);
    const ck = C.parse(C.format({ parts: s.parts }));
    const env = { light: 300, temp: 25 }; const e = s.env || {};
    if (e.light != null && e.light !== '') env.light = Math.max(0, Math.min(100000, +e.light || 0));
    if (e.temp != null && e.temp !== '') env.temp = Math.max(-55, Math.min(150, +e.temp));
    if (!Number.isFinite(env.temp)) env.temp = 25;
    return { title: String(s.title || '').slice(0, 60), parts: ck.parts, env };
  }
  put(s, who = 'app') {
    const out = { ...this.clean(s), ts: Date.now(), by: who };
    if (out.parts.length) C.dc(out);   // 解不出來（浮接、電壓源短路）就丟錯，不存
    this.ctx.store.db.circuit_state = out; this.ctx.store.touch(); return out;
  }
  describe(st = this.get(), tran = true) { if (!st.parts.length) return '電路工具目前沒有零件。'; try { return C.report(st, { tran }); } catch (e) { return `電路（${st.parts.length} 個零件）：\n${C.format(st)}\n\n解不出來：${e.message}`; } }
  /**
   * AI 操作：netlist（整個換掉）、preset、add（一行或多行零件）、remove（零件名稱）、set（{id, value, pos, on, color, beta, vz, nodes}）、env（{light, temp}）、title、reset
   */
  apply(op = {}) {
    let st = JSON.parse(JSON.stringify(this.get()));
    if (op.reset) st = C.preset('led');
    if (op.preset) { if (!C.PRESETS[op.preset]) throw new Error('預設電路：' + Object.entries(C.PRESETS).map(([k, v]) => `${k}（${v.name}）`).join('、')); st = C.preset(op.preset); }
    if (op.netlist) { const r = C.parse(String(op.netlist)); st.parts = r.parts; st.env = { ...st.env, ...r.env }; if (!op.title) st.title = ''; }
    if (op.add) { const r = C.parse(String(op.add)); for (const p of r.parts) { if (st.parts.some((x) => x.id.toLowerCase() === p.id.toLowerCase())) throw new Error(`已經有 ${p.id} 了（要改它用 set）`); st.parts.push(p); } st.env = { ...st.env, ...r.env }; }
    if (op.remove) { for (const id of String(op.remove).split(/[\s,，、]+/).filter(Boolean)) { const i = st.parts.findIndex((x) => x.id.toLowerCase() === id.toLowerCase()); if (i < 0) throw new Error(`沒有 ${id}（有：${st.parts.map((x) => x.id).join('、')}）`); st.parts.splice(i, 1); } }
    for (const s of [].concat(op.set || [])) {
      const p = st.parts.find((x) => x.id.toLowerCase() === String(s.id || '').toLowerCase()); if (!p) throw new Error(`沒有 ${s.id}（有：${st.parts.map((x) => x.id).join('、')}）`);
      if (s.value != null) { if (['R', 'C', 'L', 'V', 'I', 'POT', 'NTC'].includes(p.type)) p.v = C.num(s.value); else if (p.type === 'U7805') p.vout = C.num(s.value); else throw new Error(`${p.id}（${C.TYPES[p.type].name}）沒有可以改的數值`); }
      if (s.pos != null) { if (p.type !== 'POT') throw new Error(`${p.id} 不是可變電阻`); p.pos = Math.max(0, Math.min(1, +s.pos > 1 ? +s.pos / 100 : +s.pos)); }
      if (s.on != null) { if (p.type !== 'SW') throw new Error(`${p.id} 不是開關`); p.on = !!s.on && s.on !== 'off' && s.on !== '0'; }
      if (s.color) { if (p.type !== 'LED') throw new Error(`${p.id} 不是 LED`); if (!C.LEDC[s.color]) throw new Error('LED 顏色：' + Object.keys(C.LEDC).join('、')); p.color = s.color; }
      if (s.beta != null) p.beta = Math.max(10, Math.min(1000, +s.beta || 100)); if (s.vz != null && p.type === 'D') { p.model = 'zener'; p.vz = C.num(s.vz); }
      if (s.r1 != null && p.type === 'NE555') p.r1 = C.num(s.r1); if (s.r2 != null && p.type === 'NE555') p.r2 = C.num(s.r2); if (s.c != null && p.type === 'NE555') p.c = C.num(s.c);
      if (Array.isArray(s.nodes)) { if (s.nodes.length !== p.n.length) throw new Error(`${p.id} 要接 ${p.n.length} 個節點（${C.pinNames(p.type).join('、')}）`); p.n = s.nodes.map(String); }
    }
    if (op.env && typeof op.env === 'object') st.env = { ...st.env, ...op.env };
    if (op.title != null) st.title = String(op.title);
    return this.put(st, 'ai');
  }
}
module.exports = { CircuitState };
