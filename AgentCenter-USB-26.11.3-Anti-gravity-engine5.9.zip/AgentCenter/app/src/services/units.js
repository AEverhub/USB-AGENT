'use strict';
/**
 * 26.11.3 pro9 單位換算（理工用，純計算、不連網）：長度、質量、時間、溫度、面積、體積、速度、力、壓力、能量、功率、角度、頻率、資料量、電學。
 * 支援 SI 字首（k、M、G、m、u／µ、n、p…）接在基本單位前面，例：km、mA、µF、GHz、kPa。
 */
const PRE = { Y: 1e24, Z: 1e21, E: 1e18, P: 1e15, T: 1e12, G: 1e9, M: 1e6, k: 1e3, h: 1e2, da: 10, d: 0.1, c: 0.01, m: 1e-3, u: 1e-6, 'µ': 1e-6, 'μ': 1e-6, n: 1e-9, p: 1e-12, f: 1e-15 };
// 每個量：基準單位＋各單位換到基準的倍數；si＝可以加 SI 字首的單位
const Q = {
  長度: { base: 'm', u: { m: 1, in: 0.0254, inch: 0.0254, ft: 0.3048, yd: 0.9144, mi: 1609.344, mile: 1609.344, nmi: 1852, mil: 2.54e-5, au: 1.495978707e11, ly: 9.4607304725808e15, 公尺: 1, 公分: 0.01, 公里: 1000, 英吋: 0.0254, 英尺: 0.3048, 英里: 1609.344, 台尺: 0.30303 }, si: ['m'] },
  質量: { base: 'kg', u: { g: 1e-3, t: 1000, lb: 0.45359237, oz: 0.028349523125, 公斤: 1, 公克: 1e-3, 公噸: 1000, 磅: 0.45359237, 盎司: 0.028349523125, 台斤: 0.6, 斤: 0.6, 兩: 0.0375 }, si: ['g'] },
  時間: { base: 's', u: { s: 1, min: 60, h: 3600, hr: 3600, day: 86400, d: 86400, week: 604800, yr: 31557600, 秒: 1, 分: 60, 分鐘: 60, 小時: 3600, 天: 86400, 週: 604800, 年: 31557600 }, si: ['s'] },
  面積: { base: 'm2', u: { m2: 1, cm2: 1e-4, mm2: 1e-6, km2: 1e6, ha: 1e4, acre: 4046.8564224, ft2: 0.09290304, in2: 0.00064516, 坪: 3.305785, 平方公尺: 1, 公頃: 1e4, 甲: 9699.17 } },
  體積: { base: 'm3', u: { m3: 1, cm3: 1e-6, mm3: 1e-9, L: 1e-3, l: 1e-3, mL: 1e-6, ml: 1e-6, cc: 1e-6, gal: 0.003785411784, qt: 0.000946352946, cup: 0.0002365882365, ft3: 0.028316846592, in3: 1.6387064e-5, 公升: 1e-3, 毫升: 1e-6, 立方公尺: 1 } },
  速度: { base: 'm/s', u: { 'm/s': 1, 'km/h': 1 / 3.6, kph: 1 / 3.6, mph: 0.44704, knot: 0.514444444, kn: 0.514444444, 'ft/s': 0.3048, mach: 340.29 } },
  力: { base: 'N', u: { N: 1, kgf: 9.80665, lbf: 4.4482216152605, dyn: 1e-5 }, si: ['N'] },
  壓力: { base: 'Pa', u: { Pa: 1, bar: 1e5, atm: 101325, psi: 6894.757293168, mmHg: 133.322387415, torr: 133.322368421, inHg: 3386.389 }, si: ['Pa', 'bar'] },
  能量: { base: 'J', u: { J: 1, cal: 4.184, kcal: 4184, Wh: 3600, kWh: 3.6e6, eV: 1.602176634e-19, BTU: 1055.05585262, 'ft·lbf': 1.3558179483 }, si: ['J', 'eV', 'Wh'] },
  功率: { base: 'W', u: { W: 1, hp: 745.699871582, PS: 735.49875, 'BTU/h': 0.29307107 }, si: ['W'] },
  角度: { base: 'rad', u: { rad: 1, deg: Math.PI / 180, '°': Math.PI / 180, 度: Math.PI / 180, grad: Math.PI / 200, rev: 2 * Math.PI, turn: 2 * Math.PI, arcmin: Math.PI / 10800, arcsec: Math.PI / 648000 } },
  頻率: { base: 'Hz', u: { Hz: 1, rpm: 1 / 60, 'rad/s': 1 / (2 * Math.PI) }, si: ['Hz'] },
  資料量: { base: 'B', u: { B: 1, bit: 0.125, b: 0.125, KB: 1e3, MB: 1e6, GB: 1e9, TB: 1e12, KiB: 1024, MiB: 1048576, GiB: 1073741824, TiB: 1099511627776 } },
  電流: { base: 'A', u: { A: 1 }, si: ['A'] }, 電壓: { base: 'V', u: { V: 1 }, si: ['V'] }, 電阻: { base: 'Ω', u: { 'Ω': 1, ohm: 1 }, si: ['Ω', 'ohm'] }, 電容: { base: 'F', u: { F: 1 }, si: ['F'] }, 電感: { base: 'H', u: { H: 1 }, si: ['H'] },
  電荷: { base: 'C', u: { C: 1, Ah: 3600, mAh: 3.6 }, si: ['C'] }, 磁通密度: { base: 'T', u: { T: 1, G: 1e-4, gauss: 1e-4 }, si: ['T'] },
};
const TEMP = { c: 'C', '°c': 'C', '℃': 'C', 攝氏: 'C', celsius: 'C', f: 'F', '°f': 'F', '℉': 'F', 華氏: 'F', fahrenheit: 'F', k: 'K', kelvin: 'K', 克氏: 'K' };
const norm = (u) => String(u == null ? '' : u).trim().replace(/\^/g, '').replace(/²/g, '2').replace(/³/g, '3').replace(/Ω/g, 'Ω');
/** 找出單位屬於哪個量、換到基準的倍數 */
function find(u) {
  const out = [];
  for (const [q, d] of Object.entries(Q)) {
    if (d.u[u] != null) out.push({ q, k: d.u[u] });
    for (const b of d.si || []) { if (u.length > b.length && u.endsWith(b)) { const p = u.slice(0, -b.length); if (PRE[p] != null) out.push({ q, k: PRE[p] * d.u[b] }); } }
  }
  return out;
}
const fmt = (x) => { if (!Number.isFinite(x)) return String(x); const a = Math.abs(x); if (a !== 0 && (a >= 1e9 || a < 1e-4)) return x.toExponential(6).replace(/\.?0+e/, 'e'); return String(parseFloat(x.toPrecision(10))); };
/** convert(100, 'km/h', 'm/s') → { value, text } */
function convert(value, from, to) {
  const v = Number(value); if (!Number.isFinite(v)) throw new Error('value 要是數字');
  const f = norm(from), t = norm(to); if (!f || !t) throw new Error('要給 from 與 to 單位');
  const tf = TEMP[f.toLowerCase()], tt = TEMP[t.toLowerCase()];
  if (tf && tt) { const k = tf === 'C' ? v + 273.15 : tf === 'F' ? (v - 32) * 5 / 9 + 273.15 : v; if (k < -1e-9) throw new Error('低於絕對零度'); const r = tt === 'C' ? k - 273.15 : tt === 'F' ? (k - 273.15) * 9 / 5 + 32 : k; return { value: r, quantity: '溫度', text: `${fmt(v)} °${tf}`.replace('°K', 'K') + ' = ' + `${fmt(r)} °${tt}`.replace('°K', 'K') }; }
  const a = find(f), b = find(t);
  if (!a.length) throw new Error(`不認得單位「${from}」。支援：${Object.entries(Q).map(([q, d]) => q + '（' + Object.keys(d.u).slice(0, 6).join(' ') + '…）').join('、')}、溫度（C F K）；SI 字首可加在 m、g、s、N、Pa、J、W、Hz、A、V、Ω、F、H 前面`);
  if (!b.length) throw new Error(`不認得單位「${to}」`);
  for (const x of a) for (const y of b) if (x.q === y.q) { const r = v * x.k / y.k; return { value: r, quantity: x.q, text: `${fmt(v)} ${from} = ${fmt(r)} ${to}（${x.q}）` }; }
  throw new Error(`「${from}」是${a[0].q}、「${to}」是${b[0].q}，不同的物理量不能互換`);
}
module.exports = { convert, Q, PRE };
