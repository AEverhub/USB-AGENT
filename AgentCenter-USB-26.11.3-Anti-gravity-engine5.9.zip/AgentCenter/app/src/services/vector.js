'use strict';
/**
 * 本地向量檢索（瓶頸 2）：純 JS、無原生相依（chromadb/faiss 在 Android 上編不起來）。
 * 嵌入來源：① 有 Gemini 金鑰 → 雲端嵌入（語意最好）；② 沒有 → 本地「字元 n-gram 雜湊嵌入」（離線可用，對中文關鍵片段相似也有效）。
 * 搜尋：暴力餘弦相似度（數萬筆以內在手機上毫秒級）。兩種嵌入不混用：每筆記錄嵌入類型，只和同類型比。
 */
const { logger } = require('../core/log');
const { fetchJson, clip } = require('../core/util');
const log = logger('vector');

function hashEmbed(text, dims = 256) {
  const v = new Float32Array(dims); const s = String(text).toLowerCase().replace(/\s+/g, ' ');
  const grams = []; for (let n = 1; n <= 3; n++) for (let i = 0; i + n <= s.length; i++) grams.push(s.substr(i, n));
  for (const g of grams) {
    let h = 2166136261; for (let i = 0; i < g.length; i++) { h ^= g.charCodeAt(i); h = Math.imul(h, 16777619); }
    const idx = (h >>> 0) % dims; v[idx] += ((h >>> 16) & 1 ? 1 : -1) * (g.length === 1 ? 0.5 : g.length === 2 ? 1 : 1.5);
  }
  return norm(v);
}
function norm(v) { let s = 0; for (const x of v) s += x * x; s = Math.sqrt(s) || 1; for (let i = 0; i < v.length; i++) v[i] /= s; return v; }
const dot = (a, b) => { let s = 0; const n = Math.min(a.length, b.length); for (let i = 0; i < n; i++) s += a[i] * b[i]; return s; };

class VectorMemory {
  constructor(ctx) { this.ctx = ctx; }
  get items() { return this.ctx.store.vec; }
  async embed(text) {
    const S = this.ctx.settings; const dims = S.get('vector.dims', 256); const key = S.get('model.gemini_key');
    const mode = S.get('vector.backend', 'auto');
    if ((mode === 'auto' || mode === 'gemini') && key) {
      try {
        const m = S.get('model.embed_model', 'gemini-embedding-001');
        const r = await fetchJson(`https://generativelanguage.googleapis.com/v1beta/models/${m}:embedContent`, { method: 'POST',
          headers: { 'content-type': 'application/json', 'x-goog-api-key': key }, body: JSON.stringify({ content: { parts: [{ text: clip(text, 8000) }] }, outputDimensionality: 768 }) }, 20000);
        const vals = r.json && r.json.embedding && r.json.embedding.values;
        if (vals) return { kind: 'gemini', vec: norm(Float32Array.from(vals)) };
        log.warn('嵌入 API 回應異常，改用本地嵌入', r.status);
      } catch (e) { log.warn('嵌入失敗，改用本地嵌入', e.message); }
    }
    return { kind: 'hash' + dims, vec: hashEmbed(text, dims) };
  }
  async add({ pid = '*', source = 'note', text, meta = {} }) {
    if (!this.ctx.settings.get('vector.enabled', true) || !text || !String(text).trim()) return null;
    const { kind, vec } = await this.embed(text);
    const it = { id: this.ctx.store.nextId('vec'), pid, source, text: clip(text, 2000), kind, vec: Array.from(vec, (x) => Math.round(x * 1e3) / 1e3), meta, ts: Date.now() };
    this.items.push(it); if (this.items.length > 3000) this.items.splice(0, this.items.length - 3000); this.ctx.store.touchVec(); return it.id;
  }
  async search(q, { pid = null, k = 6, source = null, min = null } = {}) {
    const { kind, vec } = await this.embed(q); const out = []; if (min == null) min = kind === 'gemini' ? 0.5 : 0.05;   // 雲端嵌入的無關文字也常有 0.4 以上，本地 n-gram 則接近 0
    for (const it of this.items) {
      if (it.kind !== kind) continue; if (pid && it.pid !== pid && it.pid !== '*') continue; if (source && it.source !== source) continue;
      const sc = dot(vec, it.vec); if (sc >= min) out.push({ id: it.id, score: Math.round(sc * 1000) / 1000, text: it.text, source: it.source, pid: it.pid, ts: it.ts, meta: it.meta });
    }
    out.sort((a, b) => b.score - a.score);
    if (!out.length && this.items.some((i) => i.kind !== kind)) { // 嵌入類型換過 → 舊資料需重建
      return [];
    }
    return out.slice(0, k);
  }
  remove(id) { const i = this.items.findIndex((x) => x.id === +id); if (i >= 0) { this.items.splice(i, 1); this.ctx.store.touchVec(); return true; } return false; }
  /** 換嵌入來源後，用原文重建所有向量 */
  async reindex() { let n = 0; for (const it of this.items) { const { kind, vec } = await this.embed(it.text); it.kind = kind; it.vec = Array.from(vec, (x) => Math.round(x * 1e3) / 1e3); n++; } this.ctx.store.touchVec(); return n; }
  stats() { const by = {}; for (const i of this.items) by[i.kind] = (by[i.kind] || 0) + 1; return { count: this.items.length, byKind: by }; }
}
module.exports = { VectorMemory, hashEmbed };
