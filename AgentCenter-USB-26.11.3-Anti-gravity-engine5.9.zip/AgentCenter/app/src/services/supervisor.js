'use strict';
/**
 * 守護進程（瓶頸 1，等同輕量版 pm2/systemd）：
 *  ① 內建服務（LINE/Discord/Telegram 連線、排程器…）：定時健康檢查，掛了自動重啟，指數退避，視窗內重啟過多就推播 critical。
 *  ② 使用者自訂「背景工人」：js（worker_threads，nodejs-mobile 可用）或 shell（sh -c），可設 always / on-failure / never 重啟。
 *  ③ 事件迴圈延遲、記憶體水位監控，異常時主動通知。
 * 注意：Android 殺掉整個 App 的情況由前景服務（NodeService）＋開機自啟處理，見 android/。
 */
const { spawn } = require('child_process');
const path = require('path');
const fs = require('fs');
const { logger } = require('../core/log');
const log = logger('supervisor');

class Supervisor {
  constructor(ctx) {
    this.ctx = ctx; this.services = new Map(); this.workers = new Map(); this.timer = null; this.running = false;
    this.lag = 0; this._last = Date.now(); this.startedAt = 0;
  }
  /** svc: {name, start():Promise, stop():Promise, health?():boolean|Promise<boolean>, critical?:bool} */
  register(svc) { this.services.set(svc.name, { svc, state: 'stopped', restarts: [], error: '', since: 0, backoff: 0 }); }

  async startAll() {
    this.running = true; this.startedAt = Date.now();
    for (const e of this.services.values()) await this._start(e);
    for (const w of this.ctx.settings.get('supervisor.workers', [])) if (w.autostart !== false) this.startWorker(w);
    this._loop();
  }
  async stopAll() {
    this.running = false; clearInterval(this.timer); this.timer = null;
    for (const e of this.services.values()) await this._stop(e);
    for (const n of [...this.workers.keys()]) this.stopWorker(n);
  }
  async restartAll() { await this.stopAll(); await this.startAll(); }
  async _start(e) {
    try { e.state = 'starting'; await e.svc.start(); e.state = 'running'; e.since = Date.now(); e.error = ''; }
    catch (err) { e.state = 'failed'; e.error = err.message; log.error(`${e.svc.name} 啟動失敗`, err.message); }
  }
  async _stop(e) { try { if (e.state === 'running' || e.state === 'failed') await e.svc.stop(); } catch (err) { log.warn(`${e.svc.name} 停止時出錯`, err.message); } e.state = 'stopped'; }
  async restartService(name) { const e = this.services.get(name); if (!e) throw new Error('沒有這個服務'); await this._stop(e); await this._start(e); return this.status(); }

  _loop() {
    clearInterval(this.timer); const every = Math.max(5, this.ctx.settings.get('supervisor.health_interval_s', 30)) * 1000;
    this._last = Date.now();
    this.timer = setInterval(() => this._tick().catch((e) => log.error(e)), every);
    if (!this.lagTimer) { this._lagReset(); this.lagTimer = setInterval(() => this._lagSample(), 1000); if (this.lagTimer.unref) this.lagTimer.unref(); }
  }
  /**
   * 事件迴圈卡頓偵測（26.12.3 重寫，修正手機一直誤報）：
   *  - 用單調時鐘（hrtime）量，不用 Date.now()：手機休眠時單調時鐘會停，不會把「睡著的時間」當成卡頓。
   *  - 同時看這段時間用掉多少 CPU：真的卡住（同步重運算）CPU 會一直在跑；CPU 幾乎沒動代表是 Android 把 App 暫停／降速，不是程式的問題，不警告。
   *  - 一個週期內要真的卡住才算，且警告有 30 分鐘冷卻、只進 App 通知中心（不私訊、不推外部），並附上「最近最慢的操作」方便找兇手。
   */
  _lagReset() { this._lagCheckedAt = this._lagCheckedAt || Date.now(); this._lagT = process.hrtime.bigint(); this._lagCpu = process.cpuUsage(); this.lagStats = this.lagStats || { stalls: [], paused: 0, max: 0 }; }
  _lagSample() {
    const now = process.hrtime.bigint(); const gap = Number(now - this._lagT) / 1e6; const cpu = process.cpuUsage(this._lagCpu); const cpuMs = (cpu.user + cpu.system) / 1000;
    this._lagT = now; this._lagCpu = process.cpuUsage();
    const lag = Math.max(0, Math.round(gap - 1000)); this.lag = lag; if (lag < 500) return;
    const busy = cpuMs / Math.max(1, gap);   // 這段時間 CPU 忙碌比例
    if (busy < 0.35) { this.lagStats.paused++; return; }   // 被系統暫停／降速，不是我們卡住
    this.lagStats.stalls.push({ ts: Date.now(), ms: lag, busy: +busy.toFixed(2) }); if (this.lagStats.stalls.length > 50) this.lagStats.stalls.shift();
    if (lag > this.lagStats.max) this.lagStats.max = lag;
  }
  lagReport(since = 0) {
    const st = (this.lagStats || { stalls: [] }).stalls.filter((x) => x.ts >= since); const slow = require('../core/slow');
    return { stalls: st.length, max_ms: st.reduce((m, x) => Math.max(m, x.ms), 0), paused_samples: (this.lagStats || {}).paused || 0, suspects: slow.suspects(since - 2000), recent: st.slice(-10) };
  }
  _checkLag() {
    const S = this.ctx.settings; const warnMs = +S.get('supervisor.lag_warn_ms', 3000) || 3000; const since = this._lagCheckedAt || 0; this._lagCheckedAt = Date.now();
    const r = this.lagReport(since); if (!r.stalls) return null;
    const bad = r.max_ms >= warnMs * 3 || r.recent.filter((x) => x.ms >= warnMs).length >= 2; if (!bad) return null;
    if (Date.now() - (this._lagWarnAt || 0) < 30 * 60e3) return null; this._lagWarnAt = Date.now();
    const who = r.suspects.length ? '最慢的操作：' + r.suspects.map((s) => `${s.label} ${s.ms}ms${s.extra ? '（' + s.extra + '）' : ''}${s.count > 1 ? ` ×${s.count}` : ''}`).join('、') : '沒有抓到特定的慢操作（可到 監控 → 除錯 看詳細）';
    const text = `最近 ${Math.round((Date.now() - since) / 1000)} 秒內卡住 ${r.stalls} 次，最久 ${r.max_ms} ms。${who}`;
    this.ctx.notifier.push('warn', '事件迴圈卡頓', text, { quiet: true }).catch(() => {}); log.warn('卡頓：' + text); return text;
  }
  async _tick() {
    if (!this.running || !this.ctx.settings.get('supervisor.enabled', true)) return;
    const max = this.ctx.settings.get('supervisor.max_restarts', 10), win = this.ctx.settings.get('supervisor.window_s', 600) * 1000;
    for (const e of this.services.values()) {
      let ok = e.state === 'running';
      if (ok && e.svc.health) { try { ok = !!(await e.svc.health()); } catch (er) { ok = false; e.error = er.message; } if (!ok && e.svc.healthWhy) e.error = e.svc.healthWhy; }
      if (ok) continue;
      if (e.state === 'stopped') continue;
      const now = Date.now(); e.restarts = e.restarts.filter((t) => now - t < win);
      if (e.restarts.length >= max) { if (e.state !== 'gave_up') { e.state = 'gave_up'; this.ctx.notifier.critical(`服務 ${e.svc.name} 持續失敗`, `${Math.round(win / 60000)} 分鐘內重啟 ${max} 次仍不正常，已停止自動重啟。最後錯誤：${e.error || '未知'}`); } continue; }
      if (now - (e.lastTry || 0) < Math.min(60000, 2000 * 2 ** e.restarts.length)) continue;   // 指數退避
      e.lastTry = now; e.restarts.push(now); log.warn(`${e.svc.name} 不健康，重啟（${e.restarts.length}/${max}）`);
      await this._stop(e); await this._start(e);
      if (e.state === 'running') this.ctx.notifier.warn(`服務 ${e.svc.name} 已自動重啟`, `原因：${e.error || '健康檢查失敗'}`);
    }
    const mem = process.memoryUsage(); const mb = mem.rss / 1048576;
    if (mb > 600 && !this._memWarned) { this._memWarned = true; this.ctx.notifier.warn('記憶體偏高', `RSS ${mb.toFixed(0)} MB；若持續上升請到除錯頁檢查。`); }
    if (mb < 450) this._memWarned = false;
    this._checkLag();
  }

  // ---- 背景工人 ----
  startWorker(def) {
    if (this.workers.has(def.name)) return this.workers.get(def.name);
    const w = { def, state: 'starting', restarts: 0, logs: [], started: Date.now(), proc: null, th: null, stopping: false, exit: null };
    this.workers.set(def.name, w);
    const push = (t) => { for (const l of String(t).split('\n')) if (l) { w.logs.push(l); if (w.logs.length > 300) w.logs.shift(); } };
    const spawnIt = () => {
      w.stopping = false; w.state = 'running'; w.started = Date.now();
      const onExit = (code) => {
        w.exit = code; w.proc = null; w.th = null;
        if (w.stopping) { w.state = 'stopped'; return; }
        const pol = def.restart || 'on-failure'; const should = pol === 'always' || (pol === 'on-failure' && code !== 0);
        if (should && w.restarts < (def.max_restarts ?? 20)) {
          w.restarts++; w.state = 'restarting'; push(`[supervisor] 結束 code=${code}，${Math.min(30, 2 ** w.restarts)}s 後重啟（第 ${w.restarts} 次）`);
          setTimeout(() => { if (this.workers.get(def.name) === w && !w.stopping) spawnIt(); }, Math.min(30, 2 ** w.restarts) * 1000);
        } else { w.state = code === 0 ? 'exited' : 'crashed'; if (code !== 0) this.ctx.notifier.error(`背景工人 ${def.name} 當機`, `exit code ${code}`); }
      };
      try {
        if (def.kind === 'js') {
          const { Worker } = require('worker_threads'); const file = path.resolve(this.ctx.paths.workers, def.script);
          if (!file.startsWith(path.resolve(this.ctx.paths.workers))) throw new Error('腳本必須放在 workers 資料夾');
          if (!fs.existsSync(file)) throw new Error('找不到腳本 ' + def.script);
          const th = new Worker(file, { workerData: def.args || {}, stdout: true, stderr: true }); w.th = th;
          th.stdout.on('data', (d) => push(d)); th.stderr.on('data', (d) => push(d));
          th.on('error', (e) => push('[error] ' + e.stack)); th.on('exit', onExit);
        } else {
          const p = spawn('/system/bin/sh', ['-c', def.cmd], { cwd: this.ctx.paths.workspace, env: process.env, stdio: ['ignore', 'pipe', 'pipe'] });
          if (!fs.existsSync('/system/bin/sh')) throw new Error('沒有 /system/bin/sh');
          w.proc = p; p.stdout.on('data', push); p.stderr.on('data', push); p.on('error', (e) => { push('[spawn error] ' + e.message); }); p.on('close', onExit);
        }
      } catch (e) { push('[啟動失敗] ' + e.message); w.state = 'crashed'; }
    };
    spawnIt(); return w;
  }
  stopWorker(name) {
    const w = this.workers.get(name); if (!w) return false; w.stopping = true;
    try { if (w.proc) w.proc.kill('SIGKILL'); if (w.th) w.th.terminate(); } catch { /* ignore */ }
    w.state = 'stopped'; this.workers.delete(name); return true;
  }
  saveWorker(def) {
    if (!/^[\w-]{1,32}$/.test(def.name || '')) throw new Error('名稱只能英數與 - _');
    if (def.kind === 'js' ? !def.script : !def.cmd) throw new Error(def.kind === 'js' ? '缺 script' : '缺 cmd');
    const list = this.ctx.settings.get('supervisor.workers', []).filter((w) => w.name !== def.name); list.push(def);
    this.ctx.settings.set('supervisor.workers', list, 'ai'); return def;
  }
  deleteWorker(name) { this.stopWorker(name); this.ctx.settings.set('supervisor.workers', this.ctx.settings.get('supervisor.workers', []).filter((w) => w.name !== name), 'ai'); }
  workerLogs(name) { const w = this.workers.get(name); return w ? w.logs.slice(-100) : []; }

  status() {
    return {
      running: this.running, uptime_s: this.running ? Math.round((Date.now() - this.startedAt) / 1000) : 0, lag_ms: this.lag,
      services: [...this.services.values()].map((e) => ({ name: e.svc.name, state: e.state, error: e.error, since: e.since, restarts: e.restarts.length })),
      workers: this.ctx.settings.get('supervisor.workers', []).map((d) => { const w = this.workers.get(d.name); return { ...d, state: w ? w.state : 'stopped', restarts: w ? w.restarts : 0 }; }),
    };
  }
}
module.exports = { Supervisor };
