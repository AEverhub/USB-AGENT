'use strict';
/**
 * 26.11.3 Revise6：把 Opus 封包包成 Ogg Opus 檔（RFC 7845），不用解碼器。
 * Discord 語音收到的是一包包 20ms 的 Opus；包成 .ogg 就能直接送 Whisper／Gemini 轉文字。
 */
const CRC = (() => { const t = new Uint32Array(256); for (let i = 0; i < 256; i++) { let r = i << 24; for (let j = 0; j < 8; j++) r = r & 0x80000000 ? ((r << 1) ^ 0x04c11db7) >>> 0 : (r << 1) >>> 0; t[i] = r >>> 0; } return t; })();
function crc32(buf) { let c = 0; for (let i = 0; i < buf.length; i++) c = ((c << 8) ^ CRC[((c >>> 24) ^ buf[i]) & 0xff]) >>> 0; return c >>> 0; }

/** 一個 Opus 封包有幾個 48kHz 取樣（看 TOC 位元組） */
function opusSamples(pkt) {
  if (!pkt || !pkt.length) return 0; const toc = pkt[0]; const cfg = toc >> 3;
  const ms = cfg < 12 ? [10, 20, 40, 60][cfg % 4] : cfg < 16 ? [10, 20][cfg % 2] : [2.5, 5, 10, 20][cfg % 4];
  const c = toc & 3; const frames = c === 0 ? 1 : c === 3 ? (pkt.length > 1 ? pkt[1] & 0x3f : 0) : 2;
  return Math.round(frames * ms * 48);
}
function page({ data, segs, granule, serial, seq, flags }) {
  const h = Buffer.alloc(27 + segs.length); h.write('OggS', 0, 'latin1'); h[4] = 0; h[5] = flags;
  h.writeBigInt64LE(BigInt(granule), 6); h.writeUInt32LE(serial >>> 0, 14); h.writeUInt32LE(seq >>> 0, 18); h.writeUInt32LE(0, 22); h[26] = segs.length; Buffer.from(segs).copy(h, 27);
  const out = Buffer.concat([h, data]); out.writeUInt32LE(crc32(out), 22); return out;
}
const lacing = (len) => { const s = []; let n = len; while (n >= 255) { s.push(255); n -= 255; } s.push(n); return s; };

/**
 * @param {Buffer[]} packets Opus 封包
 * @param {{channels?:number, preskip?:number, serial?:number}} o
 * @returns {Buffer} .ogg 檔
 */
function oggOpus(packets, { channels = 2, preskip = 312, serial = (Math.random() * 0xffffffff) >>> 0 } = {}) {
  const head = Buffer.alloc(19); head.write('OpusHead', 0, 'latin1'); head[8] = 1; head[9] = channels; head.writeUInt16LE(preskip, 10); head.writeUInt32LE(48000, 12); head.writeInt16LE(0, 16); head[18] = 0;
  const vendor = Buffer.from('agent-center', 'utf8'); const tags = Buffer.alloc(8 + 4 + vendor.length + 4); tags.write('OpusTags', 0, 'latin1'); tags.writeUInt32LE(vendor.length, 8); vendor.copy(tags, 12); tags.writeUInt32LE(0, 12 + vendor.length);
  const out = [page({ data: head, segs: lacing(head.length), granule: 0, serial, seq: 0, flags: 0x02 }), page({ data: tags, segs: lacing(tags.length), granule: 0, serial, seq: 1, flags: 0 })];
  let seq = 2; let gran = 0; let cur = []; let segs = [];
  const list = (packets || []).filter((p) => p && p.length);
  const flush = (last) => { if (!cur.length && !last) return; out.push(page({ data: Buffer.concat(cur), segs, granule: gran, serial, seq: seq++, flags: last ? 0x04 : 0 })); cur = []; segs = []; };
  list.forEach((p, i) => { const l = lacing(p.length); if (segs.length + l.length > 255 || cur.reduce((a, b) => a + b.length, 0) > 4000) flush(false); cur.push(p); segs.push(...l); gran += opusSamples(p); if (i === list.length - 1) flush(true); });
  if (!list.length) flush(true);
  return Buffer.concat(out);
}
/** 讀 Ogg 檔裡的封包（測試與除錯用） */
function oggPackets(buf) {
  const pk = []; let cur = []; let o = 0;
  while (o + 27 <= buf.length && buf.toString('latin1', o, o + 4) === 'OggS') {
    const n = buf[o + 26]; const segs = buf.slice(o + 27, o + 27 + n); let d = o + 27 + n;
    for (const s of segs) { cur.push(buf.slice(d, d + s)); d += s; if (s < 255) { pk.push(Buffer.concat(cur)); cur = []; } }
    o = d;
  }
  return pk;
}
module.exports = { oggOpus, oggPackets, opusSamples, crc32 };
