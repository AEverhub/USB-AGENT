'use strict';
/**
 * 媒體：讓 AI 生成／截取的圖片能「直接傳上聊天室」。
 *  - Telegram、Discord：直接用平台的上傳 API，不需要公開網址。
 *  - LINE：官方 API 只收「公開 HTTPS 網址」，沒有上傳端點。所以這裡把圖片放到一個公開網址上：
 *      ① LINE 走 Cloudflare Worker 中繼時 → 圖片上傳到同一個 Worker（KV，24 小時後自動刪）
 *      ② 否則走 App 內網穿透的公開網址 → 圖片放在 data/media/，由 Webhook 伺服器的 /m/<隨機碼>.<副檔名> 提供
 *    網址帶 128 位元隨機碼，沒有人猜得到；預設保留 24 小時。
 *  - 另外提供「純 JS 的 PNG 縮圖」：LINE 的預覽圖限制 1MB，Gemini 輸出的 PNG 常超過，沒有縮圖函式庫也要能用。
 */
const fs = require('fs');
const path = require('path');
const zlib = require('zlib');
const { logger } = require('../core/log');
const { rid, fetchJson, fetchBuf } = require('../core/util');
const log = logger('media');

const EXT = { 'image/png': 'png', 'image/jpeg': 'jpg', 'image/jpg': 'jpg', 'image/webp': 'webp', 'image/gif': 'gif' };
const MIME = { png: 'image/png', jpg: 'image/jpeg', jpeg: 'image/jpeg', webp: 'image/webp', gif: 'image/gif' };
const TTL_MS = 24 * 3600e3;

/** 看檔頭判斷真正的圖片格式（模型／網站回報的 content-type 不一定準） */
function sniff(buf) {
  if (buf.length > 8 && buf[0] === 0x89 && buf[1] === 0x50 && buf[2] === 0x4e && buf[3] === 0x47) return 'image/png';
  if (buf.length > 3 && buf[0] === 0xff && buf[1] === 0xd8) return 'image/jpeg';
  if (buf.length > 12 && buf.slice(0, 4).toString() === 'RIFF' && buf.slice(8, 12).toString() === 'WEBP') return 'image/webp';
  if (buf.length > 6 && buf.slice(0, 3).toString() === 'GIF') return 'image/gif';
  return '';
}

// ---------- 純 JS PNG 縮圖（只處理 8 bit、非交錯；其餘格式原樣回傳） ----------
const CRC = (() => { const t = new Int32Array(256); for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1; t[n] = c; } return t; })();
const crc32 = (b) => { let c = -1; for (let i = 0; i < b.length; i++) c = CRC[(c ^ b[i]) & 255] ^ (c >>> 8); return (c ^ -1) >>> 0; };
const chunk = (type, data) => { const len = Buffer.alloc(4); len.writeUInt32BE(data.length); const td = Buffer.concat([Buffer.from(type), data]); const crc = Buffer.alloc(4); crc.writeUInt32BE(crc32(td)); return Buffer.concat([len, td, crc]); };

function decodePng(buf) {
  let p = 8; let ihdr = null; const idat = []; let plte = null; let trns = null;
  while (p + 8 <= buf.length) {
    const len = buf.readUInt32BE(p); const type = buf.slice(p + 4, p + 8).toString('latin1'); const data = buf.slice(p + 8, p + 8 + len); p += 12 + len;
    if (type === 'IHDR') ihdr = { w: data.readUInt32BE(0), h: data.readUInt32BE(4), depth: data[8], ct: data[9], inter: data[12] };
    else if (type === 'PLTE') plte = data; else if (type === 'tRNS') trns = data; else if (type === 'IDAT') idat.push(data); else if (type === 'IEND') break;
  }
  if (!ihdr || ihdr.depth !== 8 || ihdr.inter !== 0) return null;
  const ch = { 0: 1, 2: 3, 3: 1, 4: 2, 6: 4 }[ihdr.ct]; if (!ch) return null;
  const raw = zlib.inflateSync(Buffer.concat(idat)); const stride = ihdr.w * ch; const out = Buffer.alloc(stride * ihdr.h);
  for (let y = 0; y < ihdr.h; y++) {
    const f = raw[y * (stride + 1)]; const src = y * (stride + 1) + 1; const dst = y * stride;
    for (let x = 0; x < stride; x++) {
      const a = x >= ch ? out[dst + x - ch] : 0; const b = y > 0 ? out[dst - stride + x] : 0; const c = x >= ch && y > 0 ? out[dst - stride + x - ch] : 0; let v = raw[src + x];
      if (f === 1) v += a; else if (f === 2) v += b; else if (f === 3) v += (a + b) >> 1;
      else if (f === 4) { const pp = a + b - c; const pa = Math.abs(pp - a), pb = Math.abs(pp - b), pc = Math.abs(pp - c); v += pa <= pb && pa <= pc ? a : pb <= pc ? b : c; }
      out[dst + x] = v & 255;
    }
  }
  // 統一轉成 RGBA
  const rgba = Buffer.alloc(ihdr.w * ihdr.h * 4);
  for (let i = 0, n = ihdr.w * ihdr.h; i < n; i++) {
    let r, g, b, a = 255;
    if (ihdr.ct === 6) { r = out[i * 4]; g = out[i * 4 + 1]; b = out[i * 4 + 2]; a = out[i * 4 + 3]; }
    else if (ihdr.ct === 2) { r = out[i * 3]; g = out[i * 3 + 1]; b = out[i * 3 + 2]; }
    else if (ihdr.ct === 0) { r = g = b = out[i]; }
    else if (ihdr.ct === 4) { r = g = b = out[i * 2]; a = out[i * 2 + 1]; }
    else { const k = out[i]; if (!plte) return null; r = plte[k * 3]; g = plte[k * 3 + 1]; b = plte[k * 3 + 2]; if (trns && k < trns.length) a = trns[k]; }
    rgba[i * 4] = r; rgba[i * 4 + 1] = g; rgba[i * 4 + 2] = b; rgba[i * 4 + 3] = a;
  }
  return { w: ihdr.w, h: ihdr.h, rgba };
}
function encodePngRGB(w, h, rgb) {
  const stride = w * 3; const raw = Buffer.alloc((stride + 1) * h);
  for (let y = 0; y < h; y++) { raw[y * (stride + 1)] = 0; rgb.copy(raw, y * (stride + 1) + 1, y * stride, (y + 1) * stride); }
  const ihdr = Buffer.alloc(13); ihdr.writeUInt32BE(w, 0); ihdr.writeUInt32BE(h, 4); ihdr[8] = 8; ihdr[9] = 2;
  return Buffer.concat([Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]), chunk('IHDR', ihdr), chunk('IDAT', zlib.deflateSync(raw, { level: 6 })), chunk('IEND', Buffer.alloc(0))]);
}
/** 縮到長邊 maxSide（方塊平均），透明處墊白底。無法處理時回傳 null。 */
function downscalePng(buf, maxSide = 480) {
  try {
    const d = decodePng(buf); if (!d) return null;
    const scale = Math.min(1, maxSide / Math.max(d.w, d.h)); const nw = Math.max(1, Math.round(d.w * scale)), nh = Math.max(1, Math.round(d.h * scale));
    const out = Buffer.alloc(nw * nh * 3);
    for (let y = 0; y < nh; y++) {
      const y0 = Math.floor((y * d.h) / nh), y1 = Math.max(y0 + 1, Math.floor(((y + 1) * d.h) / nh));
      for (let x = 0; x < nw; x++) {
        const x0 = Math.floor((x * d.w) / nw), x1 = Math.max(x0 + 1, Math.floor(((x + 1) * d.w) / nw)); let r = 0, g = 0, b = 0, n = 0;
        for (let yy = y0; yy < y1; yy++) for (let xx = x0; xx < x1; xx++) { const i = (yy * d.w + xx) * 4; const a = d.rgba[i + 3] / 255; r += d.rgba[i] * a + 255 * (1 - a); g += d.rgba[i + 1] * a + 255 * (1 - a); b += d.rgba[i + 2] * a + 255 * (1 - a); n++; }
        const o = (y * nw + x) * 3; out[o] = r / n; out[o + 1] = g / n; out[o + 2] = b / n;
      }
    }
    return encodePngRGB(nw, nh, out);
  } catch (e) { log.warn('PNG 縮圖失敗：' + e.message); return null; }
}

class Media {
  constructor(ctx) { this.ctx = ctx; this.dir = path.join(ctx.paths.data, 'media'); fs.mkdirSync(this.dir, { recursive: true }); this.sweepT = null; }
  start() { this.sweep(); this.sweepT = setInterval(() => this.sweep(), 3600e3); if (this.sweepT.unref) this.sweepT.unref(); }
  stop() { clearInterval(this.sweepT); }
  sweep() { try { const now = Date.now(); for (const f of fs.readdirSync(this.dir)) { const p = path.join(this.dir, f); if (now - fs.statSync(p).mtimeMs > TTL_MS) fs.unlinkSync(p); } } catch { /* ignore */ } }

  /** 取得圖片（路徑在工作區內、或 http(s) 網址、或 data: URI）→ {buf, mime} */
  async load(src) {
    src = String(src || '').trim(); if (!src) throw new Error('沒有圖片來源');
    let buf, mime = '';
    if (/^data:image\//i.test(src)) { const m = /^data:([^;]+);base64,(.*)$/s.exec(src); if (!m) throw new Error('data URI 格式不對'); buf = Buffer.from(m[2], 'base64'); mime = m[1]; }
    else if (/^https?:\/\//i.test(src)) { const web = require('./web'); const b = web.blocked(src); if (b) throw new Error(b); const r = await fetchBuf(src, { headers: { 'user-agent': 'Mozilla/5.0 AgentHub' } }, 30000, 20 * 1024 * 1024); buf = r.buf; mime = r.mime; }
    else { const full = this.ctx.fsx.resolve(src, 'workspace'); if (!fs.existsSync(full)) throw new Error('找不到圖片檔：' + src); buf = fs.readFileSync(full); mime = MIME[path.extname(full).slice(1).toLowerCase()] || ''; }
    const real = sniff(buf); if (!real) throw new Error('這不是支援的圖片格式（PNG／JPEG／WebP／GIF）'); return { buf, mime: real };
  }
  /** 存進工作區 images/ 方便之後再用 */
  saveWorkspace(buf, mime, hint = 'img') {
    const dir = path.join(this.ctx.paths.workspace, 'images'); fs.mkdirSync(dir, { recursive: true });
    const name = `${hint.replace(/[^\w-]+/g, '_').slice(0, 24) || 'img'}-${Date.now().toString(36)}.${EXT[mime] || 'png'}`; fs.writeFileSync(path.join(dir, name), buf); return 'images/' + name;
  }

  publicBase() {
    const u = (this.ctx.tunnel && this.ctx.tunnel.state && this.ctx.tunnel.state.url) || this.ctx.settings.get('dev.public_base_url') || '';
    return String(u).replace(/\/$/, '');
  }
  /** 放到公開網址，回傳 https URL（LINE 用） */
  async publish(buf, mime) {
    const ext = EXT[mime] || 'png'; const id = rid(16); const S = this.ctx.settings; const line = this.ctx.hub && this.ctx.hub.connectors.line;
    if (line && line.mode === 'relay' && S.get('platforms.line.relay_url')) {
      const base = S.get('platforms.line.relay_url').replace(/\/$/, '');
      const r = await fetchJson(`${base}/media/${id}.${ext}?token=${encodeURIComponent(S.get('platforms.line.relay_token'))}`, { method: 'PUT', headers: { 'content-type': mime }, body: buf }, 30000);
      if (!r.ok) throw new Error(`上傳到 Cloudflare Worker 失敗（${r.status}）。請把 relay/cloudflare-worker.mjs 更新成 26.5.6 版後重新部署。${r.text.slice(0, 80)}`);
      return `${base}/m/${id}.${ext}`;
    }
    const pub = this.publicBase();
    if (!pub) throw new Error('目前沒有公開網址，LINE 沒辦法收圖。請到設定頁開啟內網穿透（或改用 Cloudflare Worker 中繼）。');
    fs.writeFileSync(path.join(this.dir, `${id}.${ext}`), buf); return `${pub}/m/${id}.${ext}`;
  }
  /** 任意檔案放到公開網址（LINE 傳檔用）：/m/<32 碼>.<副檔名>，24 小時後刪除 */
  async publishFile(buf, name, { page = false } = {}) {
    const ext = (String(name).split('.').pop() || 'bin').toLowerCase().replace(/[^a-z0-9]/g, '').slice(0, 5) || 'bin'; const pub = this.publicBase();
    if (!pub) throw new Error('目前沒有公開網址（要開內網穿透），LINE 無法傳檔');
    const id = rid(16); fs.mkdirSync(this.dir, { recursive: true }); fs.writeFileSync(path.join(this.dir, `${id}.${ext}`), buf);
    fs.writeFileSync(path.join(this.dir, `${id}.meta.json`), JSON.stringify({ name: String(name).slice(0, 120), size: buf.length }));
    return `${pub}/${page ? 'd' : 'm'}/${id}.${ext}`;   // 26.11.3 Revise8：page＝先開「確認下載」頁（影片可以先播）
  }
  meta(file) { const m = /^([0-9a-f]{32})\./.exec(file || ''); if (!m) return null; try { return JSON.parse(fs.readFileSync(path.join(this.dir, `${m[1]}.meta.json`), 'utf8')); } catch { return null; } }
  /** LINE 收到的檔案連結先到這頁：檔名、大小、「確認下載」；影片／音訊可以先在頁面上播放 */
  downloadPage(file) {
    const f = this.serve(file); if (!f) return null; const meta = this.meta(file) || {}; const name = String(meta.name || file); const esc = (x) => String(x).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
    const kb = Math.max(1, Math.round(f.buf.length / 1024)); const size = kb >= 1024 ? (kb / 1024).toFixed(1) + ' MB' : kb + ' KB'; const src = `/m/${file}`;
    const media = /^video\//.test(f.mime) ? `<video src="${src}" controls playsinline preload="metadata" style="width:100%;border-radius:12px;background:#000"></video>` : /^audio\//.test(f.mime) ? `<audio src="${src}" controls style="width:100%"></audio>` : /^image\//.test(f.mime) ? `<img src="${src}" style="width:100%;border-radius:12px" alt="">` : '';
    return `<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${esc(name)}</title><meta name="robots" content="noindex">
<body style="margin:0;font-family:system-ui,'Noto Sans TC',sans-serif;background:#0b1020;color:#edf3ff;display:flex;justify-content:center;padding:24px 16px"><div style="max-width:520px;width:100%">
<div style="background:#121a2b;border:1px solid #2a3a58;border-radius:16px;padding:18px"><div style="font-size:13px;color:#91a0ba">Agent中控中心 傳給你的檔案</div><div style="font-size:18px;font-weight:700;margin:6px 0;word-break:break-all">${esc(name)}</div><div style="color:#91a0ba;font-size:13px">${size}・24 小時內有效</div>
${media ? `<div style="margin-top:14px">${media}</div>` : ''}<p style="margin:16px 0 8px">要下載這個檔案嗎？</p>
<a href="${src}?dl=1" style="display:block;text-align:center;background:#7db4ff;color:#0b1220;font-weight:700;text-decoration:none;padding:12px;border-radius:12px">確認下載</a></div></div></body>`;
  }
  /** Webhook 伺服器呼叫：回傳 {buf,mime,download?} 或 null */
  serve(file) {
    const m = /^([0-9a-f]{32})\.(png|jpg|jpeg|webp|gif|pdf|docx|doc|xlsx|xls|pptx|ppt|csv|txt|md|json|html|tex|zip|mp4|mov|webm|m4v|mp3|m4a|wav|ogg|bin)$/.exec(file || ''); if (!m) return null;
    const p = path.join(this.dir, file); if (!fs.existsSync(p)) return null; const mime = MIME[m[2]] || require('./filegen').MIME[m[2]] || require('../platforms/common').mimeOf('x.' + m[2]);
    return { buf: fs.readFileSync(p), mime: m[2] === 'html' ? 'text/plain; charset=utf-8' : mime, download: !/^(image|video|audio)\//.test(mime) };   // 圖片／影片／音訊可以直接播；其他一律下載
  }
  /** LINE 要的 original + preview 兩個網址（預覽圖限 1MB，必要時縮小） */
  async lineUrls(buf, mime) {
    const original = await this.publish(buf, mime); let preview = original;
    if (buf.length > 900 * 1024) { let small = null; if (mime === 'image/png') { for (const side of [640, 480, 320]) { small = downscalePng(buf, side); if (small && small.length < 900 * 1024) break; } } if (small && small.length < 1024 * 1024) preview = await this.publish(small, 'image/png'); }
    return { original, preview };
  }
}
module.exports = { Media, sniff, downscalePng, EXT, MIME };
