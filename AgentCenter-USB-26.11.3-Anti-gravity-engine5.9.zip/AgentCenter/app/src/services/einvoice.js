'use strict';
/**
 * 台灣電子發票證明聯 QR Code 解析（財政部「電子發票證明聯一維及二維條碼規格」）。
 * 左邊 QR：
 *   1–10 字軌號碼｜11–17 開立日期（民國 yyyMMdd）｜18–21 隨機碼｜22–29 銷售額（未稅，16 進位）｜30–37 總計額（含稅，16 進位）
 *   38–45 買方統編（無則 00000000）｜46–53 賣方統編｜54–77 加密驗證資訊
 *   之後以「:」分隔：營業人自用區(10)｜本 QR 記載品目筆數｜總品目筆數｜中文編碼（0 Big5、1 UTF-8、2 Base64）｜品名:數量:單價…
 * 右邊 QR：以「**」開頭，接續 品名:數量:單價…
 * 掃到就能直接記帳（不用 AI、不用網路）；同一張發票（字軌號碼）只記一次。
 */
const { fromTaipei, clip } = require('../core/util');

const LEFT = /^([A-Z]{2}\d{8})(\d{3})(\d{2})(\d{2})(\d{4})([0-9A-Fa-f]{8})([0-9A-Fa-f]{8})(\d{8})(\d{8})(.{24})/;

function items(parts, enc) {
  const out = [];
  for (let i = 0; i < parts.length; i += 3) {
    let name = parts[i]; const qty = Number(parts[i + 1]); const price = Number(parts[i + 2]);
    if (name === undefined || name === '') continue;
    if (enc === '2') { try { name = Buffer.from(name, 'base64').toString('utf8'); } catch { /* 保留原字串 */ } }
    out.push({ name: clip(String(name).trim(), 60), qty: Number.isFinite(qty) ? qty : 1, price: Number.isFinite(price) ? price : 0 });
  }
  return out;
}
function isInvoice(s) { s = String(s || '').trim(); return LEFT.test(s) || s.startsWith('**'); }

/** 解析一段 QR 文字。左碼回傳完整發票；右碼回傳 {right:true, items} */
function parse(raw) {
  const s = String(raw || '').trim();
  if (s.startsWith('**')) { const parts = s.slice(2).replace(/^:/, '').split(':'); return { right: true, items: items(parts, '') }; }
  const m = LEFT.exec(s); if (!m) throw new Error('這不是台灣電子發票的 QR Code（要掃發票左邊那個）');
  const y = +m[2] + 1911, mo = +m[3], d = +m[4];
  if (mo < 1 || mo > 12 || d < 1 || d > 31) throw new Error('發票日期不正確');
  const rest = s.slice(77).replace(/^:/, '').split(':'); const enc = rest[3] || '1';
  return {
    number: m[1], date: `${y}-${String(mo).padStart(2, '0')}-${String(d).padStart(2, '0')}`, y, m: mo, d, random: m[5],
    sales: parseInt(m[6], 16), total: parseInt(m[7], 16), buyer: m[8] === '00000000' ? '' : m[8], seller: m[9],
    qr_items: Number(rest[1]) || 0, total_items: Number(rest[2]) || 0, encoding: enc, items: items(rest.slice(4), enc),
  };
}

class EInvoice {
  constructor(ctx) { this.ctx = ctx; }
  get seen() { const db = this.ctx.store.db; if (!db.einvoices || typeof db.einvoices !== 'object') db.einvoices = {}; return db.einvoices; }
  /** 記帳：回傳 {ok, duplicate, entry, invoice, text} */
  record(qrTexts, owner, { note = '' } = {}) {
    const list = (Array.isArray(qrTexts) ? qrTexts : [qrTexts]).map((x) => String(x || '').trim()).filter(Boolean);
    const leftRaw = list.find((x) => LEFT.test(x)); if (!leftRaw) throw new Error('這不是台灣電子發票的 QR Code（要掃發票左邊那個）');
    const inv = parse(leftRaw); for (const r of list.filter((x) => x.startsWith('**'))) inv.items.push(...parse(r).items);
    if (!inv.total) throw new Error('發票金額是 0，沒有記帳');
    const key = `${inv.number}-${inv.date}`; const prev = this.seen[key];
    const what = inv.items.length ? inv.items.slice(0, 4).map((i) => i.name).join('、') + (inv.items.length > 4 ? ` 等 ${inv.total_items || inv.items.length} 項` : '') : '';
    if (prev) { const e = this.ctx.store.db.ledger.find((x) => x.id === prev.ledger_id); if (e) return { ok: true, duplicate: true, entry: e, invoice: inv, text: `這張發票（${inv.number}）之前就記過了：${inv.date} 支出 ${e.amount} 元，沒有重複記。` }; }
    const now = new Date(); const sameDay = fromTaipei(inv.y, inv.m, inv.d) <= now.getTime() && now.getTime() - fromTaipei(inv.y, inv.m, inv.d) < 86400e3;
    const ts = sameDay ? now.getTime() : fromTaipei(inv.y, inv.m, inv.d, 12, 0);
    const e = this.ctx.ledger.add({ owner, kind: 'expense', amount: inv.total, note: clip(`${note ? note + '｜' : ''}電子發票 ${inv.number}${what ? '｜' + what : ''}`, 200), ts });
    this.seen[key] = { ledger_id: e.id, at: Date.now(), seller: inv.seller }; this.ctx.store.touch();
    return { ok: true, duplicate: false, entry: e, invoice: inv, text: `已記帳：${inv.date} 支出 ${inv.total} 元（${e.tag}）${what ? '，' + what : ''}。發票 ${inv.number}${inv.seller ? '，賣方統編 ' + inv.seller : ''}。` };
  }
}
module.exports = { EInvoice, parse, isInvoice };
