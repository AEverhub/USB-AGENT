'use strict';
const { fetchJson, clip } = require('../core/util');

const UA = 'Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/124 Mobile Safari/537.36 LineAgent/1.4';
function blocked(urlStr) {
  let u; try { u = new URL(urlStr); } catch { return '網址格式不正確'; }
  if (!/^https?:$/.test(u.protocol)) return '只支援 http/https';
  const h = u.hostname.toLowerCase();
  if (h === 'localhost' || h.endsWith('.localhost') || /^(127\.|0\.0\.0\.0|\[?::1\]?$)/.test(h)) return '不允許存取本機位址（避免繞過 App 的保護）';
  return null;
}
function htmlToText(html) {
  return String(html).replace(/<script[\s\S]*?<\/script>/gi, ' ').replace(/<style[\s\S]*?<\/style>/gi, ' ').replace(/<noscript[\s\S]*?<\/noscript>/gi, ' ')
    .replace(/<(br|\/p|\/div|\/li|\/h\d|\/tr)>/gi, '\n').replace(/<[^>]+>/g, ' ').replace(/&nbsp;/g, ' ').replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&#39;/g, "'")
    .replace(/[ \t\r\f]+/g, ' ').replace(/\n\s*\n+/g, '\n').trim();
}
// ---- engine5.4：Facebook／Instagram／Threads ----
// 一般抓網頁只會拿到「請登入」的空殼。這些網站會把公開貼文、粉專的摘要（標題、內文、圖片）提供給「連結預覽」用的爬蟲，
// 所以先用預覽爬蟲的身分讀公開摘要；要登入才看得到的（私人帳號、社團、朋友限定）就清楚告訴 AI 改用 App 內建瀏覽器（登入過一次就行）
const SOCIAL = /(^|\.)(facebook\.com|fb\.com|fb\.watch|fb\.me|instagram\.com|threads\.net|threads\.com)$/i;
function isSocial(url) { try { return SOCIAL.test(new URL(url).hostname); } catch { return false; } }
function metaOf(html) {
  const out = {}; const dec = (x) => htmlToText(String(x || ''));
  for (const m of String(html).matchAll(/<meta\s+[^>]*>/gi)) {
    const tag = m[0]; const k = (/(?:property|name)\s*=\s*["']([^"']+)["']/i.exec(tag) || [])[1]; const v = (/content\s*=\s*["']([^"']*)["']/i.exec(tag) || [])[1];
    if (k && v != null && !(k.toLowerCase() in out)) out[k.toLowerCase()] = dec(v);
  }
  return out;
}
async function fetchSocial(url, max) {
  const site = /instagram/i.test(url) ? 'Instagram' : /threads/i.test(url) ? 'Threads' : 'Facebook';
  let r; try { r = await fetch(url, { headers: { 'user-agent': 'facebookexternalhit/1.1 (+http://www.facebook.com/externalhit_uatext.php)', 'accept-language': 'zh-TW,zh;q=0.9,en;q=0.8' }, redirect: 'follow', signal: AbortSignal.timeout(25000) }); }
  catch (e) { throw new Error(`${site} 連不上：${e.message}`); }
  const raw = await r.text().catch(() => ''); const m = metaOf(raw);
  const title = m['og:title'] || m['twitter:title'] || ''; const desc = m['og:description'] || m['description'] || m['twitter:description'] || '';
  const loginWall = /login|登入|log in|log into/i.test(r.url) || (!desc && /^(facebook|instagram|threads)$|登入|log in/i.test(title || ''));
  if (!r.ok || loginWall || (!title && !desc)) {
    const e = new Error(`${site} 這個內容要登入才看得到（或是私人、社團、朋友限定的貼文），一般讀網頁讀不到。改用 App 內建瀏覽器：browser_open 這個網址再讀畫面（瀏覽器第一次要請管理員在 App「瀏覽器」頁登入 ${site}）。`);
    e.code = 'SOCIAL_LOGIN'; throw e;
  }
  const lines = [`【${site} 公開摘要（連結預覽提供的內容，不是完整頁面；留言、完整相簿、按讚數要用瀏覽器看）】`];
  if (title) lines.push('標題：' + title); if (desc) lines.push('內容：' + desc);
  const when = m['article:published_time'] || m['og:updated_time']; if (when) lines.push('時間：' + when);
  if (m['og:image']) lines.push('圖片：' + m['og:image']); if (m['og:video'] || m['og:video:url']) lines.push('影片：' + (m['og:video'] || m['og:video:url']));
  return { url: m['og:url'] || r.url, status: r.status, title: title || site, text: clip(lines.join('\n'), max), social: site };
}
async function fetchPage(url, max = 12000) {
  const b = blocked(url); if (b) throw new Error(b);
  if (isSocial(url)) return fetchSocial(url, max);
  const r = await fetch(url, { headers: { 'user-agent': UA, 'accept-language': 'zh-TW,zh;q=0.9,en;q=0.8' }, redirect: 'follow', signal: AbortSignal.timeout(25000) });
  const ct = r.headers.get('content-type') || ''; if (!r.ok) throw new Error(`HTTP ${r.status}`);
  const raw = await r.text(); const title = (/<title[^>]*>([\s\S]*?)<\/title>/i.exec(raw) || [])[1];
  return { url: r.url, status: r.status, title: title ? htmlToText(title) : '', text: clip(/html/i.test(ct) || /<html/i.test(raw.slice(0, 500)) ? htmlToText(raw) : raw, max) };
}
/** 搜尋：有 Brave 金鑰用 Brave；否則 DuckDuckGo HTML 版（免金鑰） */
async function search(q, n = 8) {
  const out = [];
  const r = await fetch('https://html.duckduckgo.com/html/?q=' + encodeURIComponent(q) + '&kl=tw-tzh', { headers: { 'user-agent': UA }, signal: AbortSignal.timeout(20000) });
  const html = await r.text();
  const re = /<a[^>]+class="result__a"[^>]+href="([^"]+)"[^>]*>([\s\S]*?)<\/a>[\s\S]*?(?:class="result__snippet"[^>]*>([\s\S]*?)<\/(?:a|td|div)>)?/g; let m;
  while ((m = re.exec(html)) && out.length < n) {
    let href = m[1]; const u = /uddg=([^&]+)/.exec(href); if (u) href = decodeURIComponent(u[1]); if (href.startsWith('//')) href = 'https:' + href;
    out.push({ title: htmlToText(m[2]), url: href, snippet: htmlToText(m[3] || '') });
  }
  if (!out.length) throw new Error('搜尋沒有結果（可能被擋或網路不通）');
  return out;
}
function parseRss(xml, n = 12) {
  const items = []; const re = /<item>([\s\S]*?)<\/item>/g; let m;
  const tag = (s, t) => { const x = new RegExp(`<${t}[^>]*>([\\s\\S]*?)</${t}>`, 'i').exec(s); return x ? htmlToText(x[1].replace(/<!\[CDATA\[|\]\]>/g, '')) : ''; };
  while ((m = re.exec(xml)) && items.length < n) items.push({ title: tag(m[1], 'title'), link: tag(m[1], 'link'), source: tag(m[1], 'source'), date: tag(m[1], 'pubDate') });
  return items;
}
module.exports = { fetchPage, search, parseRss, blocked, htmlToText, isSocial, metaOf };
