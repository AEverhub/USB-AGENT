'use strict';
/**
 * 26.11.3 Revise5 語音模式：文字轉語音（TTS）＋「語音包」。
 *  ・語音包＝聲音＋說話風格。三種來源：
 *      device：手機內建 TTS（離線、免費；在 App 端由 Android TextToSpeech 播，後台不產生音檔）
 *      gemini：Gemini TTS（模型頁的 Gemini 金鑰；回傳 24kHz 16-bit 單聲道 WAV／PCM）
 *      openai：OpenAI /v1/audio/speech（模型頁的 OpenAI 金鑰）
 *  ・金鑰沿用「模型」頁的金鑰池，不需要另外設定，也不會出現在任何日誌或提示詞裡。
 *  ・語音轉文字沿用 speech.js（Groq／OpenAI Whisper、Gemini）。
 */
const crypto = require('crypto');
const llm = require('../llm');
const { logger } = require('../core/log');
const log = logger('voice');

/** 內建語音包。style 是給雲端 TTS 的說話風格提示 */
const PACKS = [
  { id: 'device', name: '手機內建語音', provider: 'device', desc: '離線、免費，用手機系統的 TTS 聲音（可在下方挑選系統聲音、語速、音調）' },
  { id: 'g-warm', name: '溫暖親切', provider: 'gemini', voice: 'Sulafat', style: '用溫暖、親切、像朋友聊天的語氣，台灣華語自然口音', desc: 'Gemini・Sulafat' },
  { id: 'g-gentle', name: '溫柔輕聲', provider: 'gemini', voice: 'Vindemiatrix', style: '用溫柔、輕聲、放慢一點的語氣，台灣華語', desc: 'Gemini・Vindemiatrix' },
  { id: 'g-bright', name: '活潑開朗', provider: 'gemini', voice: 'Puck', style: '用活潑、開朗、有精神的語氣，台灣華語', desc: 'Gemini・Puck' },
  { id: 'g-calm', name: '沉穩專業', provider: 'gemini', voice: 'Charon', style: '用沉穩、清楚、像新聞主播的語氣，台灣華語', desc: 'Gemini・Charon' },
  { id: 'g-crisp', name: '俐落清楚', provider: 'gemini', voice: 'Kore', style: '用俐落、清楚、有條理的語氣，台灣華語', desc: 'Gemini・Kore' },
  { id: 'g-soft', name: '柔和慢速', provider: 'gemini', voice: 'Achernar', style: '用柔和、慢一點、讓人放鬆的語氣，台灣華語', desc: 'Gemini・Achernar' },
  { id: 'o-marin', name: '自然對話', provider: 'openai', voice: 'marin', style: 'Speak Taiwanese Mandarin naturally, warm and conversational.', desc: 'OpenAI・marin' },
  { id: 'o-cedar', name: '低沉穩重', provider: 'openai', voice: 'cedar', style: 'Speak Taiwanese Mandarin, calm, steady and reassuring.', desc: 'OpenAI・cedar' },
  { id: 'o-nova', name: '明亮輕快', provider: 'openai', voice: 'nova', style: 'Speak Taiwanese Mandarin, bright, upbeat and friendly.', desc: 'OpenAI・nova' },
];
/** 各雲端聲音的性別（依官方試聽的音色；給影片「男聲配男生、女聲配女生」用） */
const VOICE_GENDER = { Puck: 'male', Charon: 'male', Fenrir: 'male', Orus: 'male', Enceladus: 'male', Iapetus: 'male', Umbriel: 'male', Algieba: 'male', Algenib: 'male', Rasalgethi: 'male', Alnilam: 'male', Schedar: 'male', Achird: 'male', Zubenelgenubi: 'male', Sadachbia: 'male', Sadaltager: 'male',
  Zephyr: 'female', Kore: 'female', Leda: 'female', Aoede: 'female', Callirrhoe: 'female', Autonoe: 'female', Despina: 'female', Erinome: 'female', Laomedeia: 'female', Achernar: 'female', Gacrux: 'female', Pulcherrima: 'female', Vindemiatrix: 'female', Sulafat: 'female',
  marin: 'female', coral: 'female', nova: 'female', sage: 'female', shimmer: 'female', cedar: 'male', ash: 'male', ballad: 'male', echo: 'male', onyx: 'male', verse: 'male', fable: 'male' };
/** 指定性別時用的聲音（自然、適合講解） */
const GENDER_VOICE = { gemini: { male: 'Charon', female: 'Kore' }, openai: { male: 'cedar', female: 'marin' } };
const GEMINI_VOICES = ['Zephyr', 'Puck', 'Charon', 'Kore', 'Fenrir', 'Leda', 'Orus', 'Aoede', 'Callirrhoe', 'Autonoe', 'Enceladus', 'Iapetus', 'Umbriel', 'Algieba', 'Despina', 'Erinome', 'Algenib', 'Rasalgethi', 'Laomedeia', 'Achernar', 'Alnilam', 'Schedar', 'Gacrux', 'Pulcherrima', 'Achird', 'Zubenelgenubi', 'Vindemiatrix', 'Sadachbia', 'Sadaltager', 'Sulafat'];
const OPENAI_VOICES = ['marin', 'cedar', 'alloy', 'ash', 'ballad', 'coral', 'echo', 'fable', 'nova', 'onyx', 'sage', 'shimmer', 'verse'];
// 依序嘗試（新模型在舊帳號可能還沒開，就退到下一個）
const GEMINI_TTS_MODELS = ['gemini-3.8-flash-tts', 'gemini-3.1-flash-tts-preview', 'gemini-2.5-flash-preview-tts'];

/** 把 AI 的回覆整理成適合念出來的文字：去掉 Markdown、程式碼、網址、表情符號 */
/** WAV 秒數（讀 fmt 的 byteRate 與 data 長度）；不是 WAV 回 0 */
function wavSec(buf) {
  if (!buf || buf.length < 44 || buf.toString('latin1', 0, 4) !== 'RIFF') return 0; let p = 12, br = 0;
  while (p + 8 <= buf.length) { const id = buf.toString('latin1', p, p + 4); const sz = buf.readUInt32LE(p + 4); if (id === 'fmt ') br = buf.readUInt32LE(p + 16); if (id === 'data') return br ? Math.min(sz, buf.length - p - 8) / br : 0; p += 8 + sz + (sz % 2); }
  return 0;
}
/** 這段文字大概念多久（秒）：中日文每字約 0.22 秒、英文每字（word）約 0.4 秒、標點停頓 */
function expectSec(text) {
  const t = String(text || ''); const cjk = (t.match(/[\u3400-\u9fff\u3040-\u30ff\uac00-\ud7af]/g) || []).length; const words = (t.replace(/[\u3400-\u9fff\u3040-\u30ff\uac00-\ud7af]/g, ' ').match(/[A-Za-z0-9]+/g) || []).length; const stops = (t.match(/[，。！？、；：,.!?;:\n]/g) || []).length;
  return cjk * 0.22 + words * 0.4 + stops * 0.15;
}
/** 念太久＝多念了東西（重複或把提示念出來）。短句寬鬆一點 */
function tooLong(out, text) { const sec = out && out.buf ? wavSec(out.buf) : 0; if (!sec) return false; const e = expectSec(text); return sec > Math.max(e * 1.75 + 1.5, e + 4); }
function speakable(text, max = 1200) {
  let t = String(text || '');
  // engine4.8：開頭的系統標記、指令標籤、語氣說明一律不念（【系統…】【手機懸浮面板指令…】[[quote:…]]、「用○○語氣念出…：」這類說明）
  t = t.replace(/^\s*(?:\[\[[^\]]{0,80}\]\]\s*)+/, '').replace(/^\s*(?:【[^】]{0,60}(?:系統|指令|提示|自我檢查|語氣|旁白)[^】]{0,60}】\s*)+/, '').replace(/^\s*(?:請)?用[^。\n：:]{2,40}(?:語氣|口吻|聲音)[^。\n：:]{0,30}(?:念|唸|讀|說)出?[^。\n：:]{0,20}[：:]\s*/, '');
  t = t.replace(/```chart[\s\S]*?```/g, '（圖表請看畫面）').replace(/```[\s\S]*?```/g, '（程式碼請看畫面）').replace(/`([^`]+)`/g, '$1');
  t = t.replace(/\$\$[\s\S]*?\$\$/g, '（算式請看畫面）').replace(/\\\[[\s\S]*?\\\]/g, '（算式請看畫面）');
  t = t.replace(/!\[[^\]]*\]\([^)]*\)/g, '').replace(/\[([^\]]+)\]\((https?:[^)]+)\)/g, '$1').replace(/https?:\/\/\S+/g, '（連結）');
  t = t.replace(/^\s{0,3}#{1,6}\s*/gm, '').replace(/^\s*[-*+]\s+/gm, '').replace(/^\s*>\s?/gm, '').replace(/\*\*|__|~~/g, '').replace(/(^|\s)[*_](\S[^*_]*\S|\S)[*_](?=\s|$)/g, '$1$2');
  t = t.replace(/^\s*\|.*\|\s*$/gm, (row) => (/^\s*\|[\s:|-]+\|\s*$/.test(row) ? '' : row.replace(/\|/g, '，')));
  t = t.replace(/[\uD83C-\uDBFF][\uDC00-\uDFFF]/g, '').replace(/[☀-➿️‍]/g, '');
  t = t.replace(/[ \t]+/g, ' ').replace(/\n{2,}/g, '\n').trim();
  if (t.length > max) { const cut = t.slice(0, max); const p = Math.max(cut.lastIndexOf('。'), cut.lastIndexOf('！'), cut.lastIndexOf('？'), cut.lastIndexOf('\n')); t = (p > max * 0.5 ? cut.slice(0, p + 1) : cut) + '……其餘內容請看畫面。'; }
  return t;
}
/** 依句子切段（第一段短一點，讓第一個聲音更快出來） */
function chunks(text, first = 80, rest = 180) {   // engine4.6：段落短一點，雲端語音比較不會念到後面開始重複
  const parts = String(text || '').split(/(?<=[。！？!?；;\n])/).map((x) => x.trim()).filter(Boolean); const out = []; let cur = '';
  for (const p of parts) { const lim = out.length ? rest : first; if (cur && (cur + p).length > lim) { out.push(cur); cur = p; } else cur += p; while (cur.length > rest) { out.push(cur.slice(0, rest)); cur = cur.slice(rest); } }
  if (cur) out.push(cur); return out;
}
function wav(pcm, rate = 24000, ch = 1, bits = 16) {
  const h = Buffer.alloc(44); const br = rate * ch * bits / 8;
  h.write('RIFF', 0); h.writeUInt32LE(36 + pcm.length, 4); h.write('WAVE', 8); h.write('fmt ', 12); h.writeUInt32LE(16, 16); h.writeUInt16LE(1, 20); h.writeUInt16LE(ch, 22); h.writeUInt32LE(rate, 24); h.writeUInt32LE(br, 28); h.writeUInt16LE(ch * bits / 8, 32); h.writeUInt16LE(bits, 34); h.write('data', 36); h.writeUInt32LE(pcm.length, 40);
  return Buffer.concat([h, pcm]);
}

class Voice {
  constructor(ctx) { this.ctx = ctx; this.cache = new Map(); this.geminiModel = ''; }
  cfg() { return { pack: 'auto', rate: 1, pitch: 1, device_voice: '', auto_listen: true, speak_replies: true, stt: 'auto', custom: null, max_chars: 1200, ...(this.ctx.settings.get('voice', {}) || {}) }; }
  _key(p) { const c = llm.keyCandidates(this.ctx.settings, p).find(llm.usable); return c && c.key; }
  has(p) { try { return !!this._key(p); } catch { return false; } }
  packs() {
    const c = this.cfg(); const list = PACKS.map((p) => ({ ...p, available: p.provider === 'device' || this.has(p.provider) }));
    if (c.custom && c.custom.provider && c.custom.voice) list.push({ id: 'custom', name: c.custom.name || '自訂語音包', provider: c.custom.provider, voice: c.custom.voice, style: c.custom.style || '', desc: `自訂・${c.custom.provider}・${c.custom.voice}`, available: c.custom.provider === 'device' || this.has(c.custom.provider) });
    return list;
  }
  /** 目前用哪個語音包（auto：有 Gemini 金鑰用「溫暖親切」，有 OpenAI 用「自然對話」，否則手機內建） */
  current() {
    const c = this.cfg(); const list = this.packs(); const want = list.find((p) => p.id === c.pack);
    if (want && want.available) return want;
    return list.find((p) => p.id === 'g-warm' && p.available) || list.find((p) => p.id === 'o-marin' && p.available) || list[0];
  }
  state() {
    const c = this.cfg(); const sttRoutes = this.ctx.speech ? this.ctx.speech.routes() : [];
    return { settings: { pack: c.pack, rate: c.rate, pitch: c.pitch, device_voice: c.device_voice, auto_listen: c.auto_listen !== false, speak_replies: c.speak_replies !== false, stt: c.stt, custom: c.custom, max_chars: c.max_chars },
      current: this.current(), packs: this.packs(), voices: { gemini: GEMINI_VOICES, openai: OPENAI_VOICES }, stt: { cloud: sttRoutes, enabled: !this.ctx.speech || this.ctx.speech.enabled() } };
  }
  update(b = {}) {
    const S = this.ctx.settings; const set = (k, v) => S.set('voice.' + k, v, 'human');
    if (b.pack !== undefined) { const id = String(b.pack); if (id !== 'auto' && !this.packs().some((p) => p.id === id) && id !== 'custom') throw new Error('沒有這個語音包'); set('pack', id); }
    if (b.rate !== undefined) set('rate', Math.min(2, Math.max(0.5, +b.rate || 1)));
    if (b.pitch !== undefined) set('pitch', Math.min(2, Math.max(0.5, +b.pitch || 1)));
    if (b.device_voice !== undefined) set('device_voice', String(b.device_voice).slice(0, 120));
    if (b.auto_listen !== undefined) set('auto_listen', !!b.auto_listen);
    if (b.speak_replies !== undefined) set('speak_replies', !!b.speak_replies);
    if (b.stt !== undefined) { if (!['auto', 'cloud', 'device'].includes(b.stt)) throw new Error('stt 只能是 auto／cloud／device'); set('stt', b.stt); }
    if (b.custom !== undefined) {
      if (b.custom === null) set('custom', null);
      else { const c = b.custom || {}; const prov = String(c.provider || ''); if (!['gemini', 'openai', 'device'].includes(prov)) throw new Error('自訂語音包的來源只能是 gemini／openai／device');
        const v = String(c.voice || ''); if (prov === 'gemini' && !GEMINI_VOICES.includes(v)) throw new Error('Gemini 沒有這個聲音'); if (prov === 'openai' && !OPENAI_VOICES.includes(v)) throw new Error('OpenAI 沒有這個聲音');
        set('custom', { name: String(c.name || '自訂語音包').slice(0, 20), provider: prov, voice: v || 'device', style: String(c.style || '').slice(0, 200) }); }
    }
    return this.state();
  }
  /** 產生語音。回傳 { mime, buf, provider }；device 語音包回傳 { device: true, text }（App 端自己念） */
  async tts(text, packId, opts = {}) {
    const c = this.cfg(); const t = String(text || '').trim(); if (!t) throw new Error('沒有要念的文字'); if (t.length > 1500) throw new Error('一次最多 1500 字，請分段');
    let pack = packId ? this.packs().find((p) => p.id === packId) : this.current(); if (!pack) throw new Error('沒有這個語音包');
    if (!pack.available) throw new Error(`「${pack.name}」需要模型頁的 ${pack.provider === 'gemini' ? 'Gemini' : 'OpenAI'} 金鑰`);
    if (pack.provider === 'device') return { device: true, text: t, rate: c.rate, pitch: c.pitch, voice: c.device_voice };
    if (opts.voice && opts.voice !== pack.voice) pack = { ...pack, voice: String(opts.voice) };   // engine4.6：影片旁白指定男聲／女聲時換成同一家的對應聲音
    const k = crypto.createHash('sha1').update(`${pack.provider}|${pack.voice}|${pack.style}|${t}`).digest('hex');
    if (this.cache.has(k)) { const v = this.cache.get(k); this.cache.delete(k); this.cache.set(k, v); return v; }
    let out = pack.provider === 'gemini' ? await this._gemini(t, pack, c) : await this._openai(t, pack, c);
    // engine4.6：雲端語音偶爾會「多念」（把同一句念兩次、或念出不該念的字）→ 聲音長度明顯超過這段文字該有的長度就重錄一次，還是不對就改用手機內建語音念這段
    if (tooLong(out, t)) { log.warn(`雲端語音長度異常（${wavSec(out.buf).toFixed(1)} 秒／${t.length} 字），重錄一次`); out = pack.provider === 'gemini' ? await this._gemini(t, pack, c) : out;
      if (tooLong(out, t)) { log.warn('重錄後長度仍異常，這段改用手機內建語音'); return { device: true, text: t, rate: c.rate, pitch: c.pitch, voice: c.device_voice, fallback: 'too_long' }; } }
    this.cache.set(k, out); while (this.cache.size > 40) this.cache.delete(this.cache.keys().next().value);
    return out;
  }
  async _gemini(text, pack, c) {
    const key = this._key('gemini');   // 語速由 App 端播放速度控制（不放進提示，避免同一段話被快慢各念一次）
    // engine4.6：只送要念的文字本身。新版 Gemini TTS（3.8）把文字當逐字稿，前面加的語氣說明會被一起念出來；語氣改由聲音（voiceName）決定
    const prompt = text;
    const body = { contents: [{ role: 'user', parts: [{ text: prompt }] }], generationConfig: { responseModalities: ['AUDIO'], speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: pack.voice || 'Kore' } } } } };
    const models = [c.gemini_model, this.geminiModel, ...GEMINI_TTS_MODELS].filter(Boolean).filter((m, i, a) => a.indexOf(m) === i); let last;
    for (const m of models) {
      try {
        const j = await llm.post(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(m)}:generateContent`, { 'x-goog-api-key': key }, body, 'Gemini TTS', true);
        const part = ((((j.candidates || [])[0] || {}).content || {}).parts || []).find((p) => p.inlineData && p.inlineData.data);
        if (!part) throw new Error('Gemini 沒有回傳聲音');
        let buf = Buffer.from(part.inlineData.data, 'base64'); const mt = String(part.inlineData.mimeType || '');
        if (buf.slice(0, 4).toString('latin1') !== 'RIFF') { const rate = +((mt.match(/rate=(\d+)/) || [])[1]) || 24000; buf = wav(buf, rate); }   // 舊模型回傳沒有檔頭的 PCM
        this.geminiModel = m; return { mime: 'audio/wav', buf, provider: 'gemini' };
      } catch (e) { last = e; const modelGone = e.status === 404 || (e.status === 400 && /model|modalit|not supported|does not support/i.test(JSON.stringify(e.body || e.message || ''))); if (!modelGone) break; log.warn(`Gemini TTS 模型 ${m} 不能用，換下一個`); }
    }
    throw new Error('Gemini 語音產生失敗：' + String((last && last.message) || '').slice(0, 200));
  }
  async _openai(text, pack, c) {
    const model = c.openai_model || 'gpt-4o-mini-tts';
    const body = { model, voice: pack.voice || 'marin', input: text, response_format: 'mp3', ...(pack.style && /gpt-4o/.test(model) ? { instructions: pack.style } : {}) };
    const r = await fetch('https://api.openai.com/v1/audio/speech', { method: 'POST', headers: { authorization: 'Bearer ' + this._key('openai'), 'content-type': 'application/json' }, body: JSON.stringify(body), signal: AbortSignal.timeout(60000) });
    if (!r.ok) { const j = await r.json().catch(() => ({})); throw new Error(`OpenAI 語音 ${r.status}：${String((j.error && (j.error.message || j.error)) || '').slice(0, 200)}`); }
    return { mime: 'audio/mpeg', buf: Buffer.from(await r.arrayBuffer()), provider: 'openai' };
  }
}
module.exports = { VOICE_GENDER, GENDER_VOICE, Voice, PACKS, wavSec, expectSec, tooLong, speakable, chunks, wav, GEMINI_VOICES, OPENAI_VOICES, GEMINI_TTS_MODELS };
