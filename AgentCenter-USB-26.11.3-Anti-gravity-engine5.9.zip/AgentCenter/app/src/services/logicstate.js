'use strict';
/**
 * 26.11.3 pro2：邏輯閘轉換器的共用狀態（App 頁面和 AI 操作同一份）。存在 store.db.logic_state。
 * { ckt:{inputs, gates:[{id,type,ins,out}], output}, env:{A:0|1}, ics:'7400', tab:'sop'|'pos'|'nand'|'nor', ts }
 */
const L = require('../../ui/logic.js');
const TYPES = ['AND', 'OR', 'NAND', 'NOR', 'XOR', 'XNOR', 'NOT', 'BUF'];
const FORMS = ['sop', 'pos', 'nand', 'nor'];

class LogicState {
  constructor(ctx) { this.ctx = ctx; }
  get() { const s = this.ctx.store.db.logic_state; return s && s.ckt ? { icmap: {}, wsrc: 'ckt', arith: null, ...s } : { ckt: L.preset(), env: {}, ics: '', tab: 'sop', icmap: {}, wsrc: 'ckt', arith: null, ts: 0 }; }
  /** 26.11.3 pro5：每種閘用哪顆 IC（只留認得、而且能當那種閘用的） */
  cleanMap(m) { const out = {}; for (const [t, v] of Object.entries(m && typeof m === 'object' ? m : {})) { const T = String(t).toUpperCase(); if (!TYPES.includes(T) || T === 'BUF' || !v) continue; const id = L.icId(v); if (!id) throw new Error(`不認得的 IC「${v}」`); if (!L.icChoices(T).includes(id)) throw new Error(`${id} 不能當 ${T} 用；${T} 可以選：${L.icChoices(T).join('、')}`); out[T] = id; } return out; }
  cleanArith(a) {
    if (!a || !a.kind) return null; if (!L.ARITH[a.kind]) throw new Error('加減法器種類：' + Object.keys(L.ARITH).join('、'));
    const bits = Math.max(1, Math.min(8, Math.floor(+a.bits || 4))); const impl = a.impl === 'msi' ? 'msi' : 'gates'; let ic = ''; if (a.ic) { ic = L.icId(a.ic); if (!ic || L.IC[ic].type !== 'ADD4') throw new Error('加法器 IC 可以選：74283、7483、4008'); }
    return { kind: a.kind, bits, a: Math.max(0, Math.floor(+a.a || 0)) & 255, b: Math.max(0, Math.floor(+a.b || 0)) & 255, x: +a.x ? 1 : 0, env: a.env && typeof a.env === 'object' ? Object.fromEntries(Object.entries(a.env).slice(0, 4).map(([k, v]) => [String(k).slice(0, 4), +v ? 1 : 0])) : {}, impl, ic: ic || '74283' };
  }
  put(s, who = 'app') {
    const ck = s.ckt; if (!ck || !Array.isArray(ck.inputs) || !Array.isArray(ck.gates)) throw new Error('電路格式不對');
    if (ck.inputs.length > 6 || ck.gates.length > 60) throw new Error('互動電路最多 6 個變數、60 個閘');
    for (const g of ck.gates) if (!TYPES.includes(g.type) || !Array.isArray(g.ins) || !g.ins.length) throw new Error('閘的格式不對');
    L.simulate(ck, {});   // 有迴圈或接錯會丟錯
    const out = { ckt: ck, env: s.env || {}, ics: String(s.ics || '').slice(0, 80), tab: FORMS.includes(s.tab) ? s.tab : 'sop', icmap: this.cleanMap(s.icmap), wsrc: s.wsrc === 'form' ? 'form' : 'ckt', arith: this.cleanArith(s.arith), ts: Date.now(), by: who };
    this.ctx.store.db.logic_state = out; this.ctx.store.touch(); return out;
  }
  /** 目前電路的完整分析（給 AI 看、也給 App 用） */
  analyze(st = this.get()) {
    const ck = st.ckt; const val = L.simulate(ck, st.env || {});
    const sol = L.solve({ name: 'F', vars: ck.inputs, minterms: L.circuitMinterms(ck), dc: [] });
    return { sol, val, expr: L.circuitExpr(ck), out: val[ck.output] };
  }
  /** 給 AI 的文字說明（電路每個閘、目前輸入、布林式、真值表、卡諾圖、各種形式） */
  describe(st = this.get()) {
    const a = this.analyze(st); const ck = st.ckt; const s = a.sol;
    const lines = [`電路（輸入 ${ck.inputs.join('、')}；輸出 F 接 ${ck.output}）：`, ...ck.gates.map((g) => `・${g.id}：${g.type}(${g.ins.join(', ')}) → ${g.out}`),
      `目前輸入：${ck.inputs.map((v) => `${v}=${st.env[v] ? 1 : 0}`).join('、')} → F=${a.out}`, `電路布林式：F = ${a.expr}`, `F = Σm(${s.minterms.join(',') || '—'})`,
      `最簡 SOP：${s.sopStr}`, `最簡 POS：${s.posStr}`, `只用 NAND：${s.nandStr}`, `只用 NOR：${s.norStr}`, `畫面顯示：${{ sop: 'SOP', pos: 'POS', nand: 'NAND', nor: 'NOR' }[st.tab]}${st.ics ? `；IC：${st.ics}` : ''}`,
      '', '真值表：', L.tableText(s), '', '卡諾圖：', L.kmapText(s)];
    try { const tgt = st.wsrc === 'form' ? L.circuit(s, st.tab, st.tab === 'nand' || st.tab === 'nor' ? 2 : 4) : ck; const w = L.wiringOf(tgt, st.icmap || {}); lines.push('', `實際接線（${st.wsrc === 'form' ? '「轉換結果」的 ' + st.tab.toUpperCase() + ' 電路' : '上面畫的電路'}；每種閘用的 IC：${Object.entries(w.chosen).map(([t, i]) => `${t}→${i}`).join('、')}）：`, L.wiringText(w)); } catch (e) { lines.push('', '實際接線：' + e.message); }
    if (st.arith) { try { const A = st.arith; const multi = ['add', 'sub', 'addsub'].includes(A.kind); lines.push('', '加法器／減法器畫面：', L.arithReport(A.kind, { bits: A.bits, a: A.a, b: A.b, x: A.x, impl: multi ? A.impl : 'gates', ic: A.ic, map: st.icmap })); } catch (e) { lines.push('', '加減法器：' + e.message); } }
    if (st.ics) { try { lines.push('', '（下面是「只有這些 IC」模式）'); const w = L.wiring(s, st.ics); lines.push('', `IC 接線（${w.chips.map((c) => c.ref + '=' + c.ic).join('、')}）：`, ...w.lines.map((l) => `・${l.chip} 閘${l.gate} ${l.type}：${l.ins.map((p) => `腳${p.pin}←${p.sig}`).join('、')} → 腳${l.out.pin}${l.out.sig === w.circuit.output ? '＝F' : '（' + l.out.sig + '）'}`), '電源：' + w.power.join('；')); } catch (e) { lines.push('IC 接線：' + e.message); } }
    return lines.join('\n');
  }
  /**
   * AI 操作：expr（換成這個函數的電路，form 決定用哪種形式建）、form、ics、inputs（{A:1}）、gate（{id, type?, ins?}）、add_gate（{type, ins}）、remove_gate（id）、output（訊號）、add_input、remove_input、reset
   */
  apply(op = {}) {
    let st = JSON.parse(JSON.stringify(this.get())); const ck = () => st.ckt;
    if (op.reset) st = { ckt: L.preset(), env: {}, ics: '', tab: 'sop' };
    if (op.expr) { const s = L.solve(String(op.expr)); if (s.vars.length > 6) throw new Error('互動電路最多 6 個變數'); const form = FORMS.includes(op.form) ? op.form : 'sop'; let c = L.circuit(s, form, form === 'nand' || form === 'nor' ? 2 : 4); if (!c.gates.length) c = { ...c, gates: [{ id: 'g1', type: 'BUF', ins: [c.output], out: 'n1' }], output: 'n1' }; st.ckt = c; st.env = {}; st.tab = form; }
    else if (op.form) { if (!FORMS.includes(op.form)) throw new Error('form 只能是 sop／pos／nand／nor'); st.tab = op.form; if (op.rebuild) { const a = this.analyze(st); const c = L.circuit(a.sol, op.form, op.form === 'nand' || op.form === 'nor' ? 2 : 4); if (c.gates.length) st.ckt = c; } }
    if (op.add_input) { const nv = 'ABCDEFGH'.split('').find((v) => !ck().inputs.includes(v)); if (!nv || ck().inputs.length >= 6) throw new Error('最多 6 個變數'); ck().inputs.push(nv); }
    if (op.remove_input) { const v = String(op.remove_input); if (ck().gates.some((g) => g.ins.includes(v))) throw new Error(`變數 ${v} 還有接到閘`); ck().inputs = ck().inputs.filter((x) => x !== v); delete st.env[v]; }
    if (op.add_gate) { const t = String(op.add_gate.type || 'AND').toUpperCase(); if (!TYPES.includes(t)) throw new Error('閘的種類：' + TYPES.join('、')); const k = Math.max(0, ...ck().gates.map((g) => +String(g.id).slice(1) || 0)) + 1; const ins = (op.add_gate.ins || [ck().output]).map(String); ck().gates.push({ id: 'g' + k, type: t, ins: /NOT|BUF/.test(t) ? ins.slice(0, 1) : ins.length >= 2 ? ins : [ins[0], ins[0]], out: 'n' + k }); if (op.add_gate.as_output !== false) ck().output = 'n' + k; }
    if (op.gate) { const g = ck().gates.find((x) => x.id === op.gate.id); if (!g) throw new Error('沒有這個閘：' + op.gate.id + '（可用：' + ck().gates.map((x) => x.id).join('、') + '）'); if (op.gate.type) { const t = String(op.gate.type).toUpperCase(); if (!TYPES.includes(t)) throw new Error('閘的種類：' + TYPES.join('、')); g.type = t; if (/NOT|BUF/.test(t)) g.ins = g.ins.slice(0, 1); else if (g.ins.length < 2) g.ins = [g.ins[0], g.ins[0]]; } if (Array.isArray(op.gate.ins)) g.ins = op.gate.ins.map(String); }
    if (op.remove_gate) { const g = ck().gates.find((x) => x.id === op.remove_gate); if (!g) throw new Error('沒有這個閘'); ck().gates = ck().gates.filter((x) => x !== g); for (const x of ck().gates) x.ins = x.ins.map((s2) => (s2 === g.out ? g.ins[0] : s2)); if (ck().output === g.out) ck().output = ck().gates.length ? ck().gates[ck().gates.length - 1].out : g.ins[0]; }
    if (op.output) ck().output = String(op.output);
    if (op.inputs && typeof op.inputs === 'object') for (const [k, v] of Object.entries(op.inputs)) { if (!ck().inputs.includes(k)) throw new Error('沒有這個輸入：' + k); st.env[k] = +v ? 1 : 0; }
    if (op.ic_map !== undefined) st.icmap = { ...(op.ic_map && Object.keys(op.ic_map).length ? st.icmap : {}), ...this.cleanMap(op.ic_map) };
    if (op.wire_source) st.wsrc = op.wire_source === 'form' ? 'form' : 'ckt';
    if (op.arith !== undefined) st.arith = op.arith ? this.cleanArith({ ...(st.arith || {}), ...op.arith }) : null;
    if (op.ics !== undefined) { const ics = String(op.ics || ''); if (ics) L.wiring(this.analyze(st).sol, ics); st.ics = ics; }
    if (!ck().gates.length) throw new Error('電路至少要一個閘');
    return this.put(st, 'ai');
  }
}
module.exports = { LogicState };
