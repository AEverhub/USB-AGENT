'use strict';
/**
 * 工具參數 Schema 適配器（每家模型一個）＋送出前預檢。
 *
 * 為什麼需要：工具（尤其 MCP 連接器帶來的）用的是完整 JSON Schema（exclusiveMinimum、oneOf、$ref、const、type 陣列…），
 * 但 Gemini 只吃 OpenAPI 3.0 的子集，遇到不認得的欄位會整個請求 400，整個 AI 就不能用。
 *
 * 原則：
 *   1. 永遠不改原始工具定義（全部深拷貝後轉換）
 *   2. 能等價轉換就轉（oneOf→anyOf、const→enum、["x","null"]→nullable、$ref 展開、allOf 合併）
 *   3. 無法表達的限制（exclusiveMinimum、multipleOf、uniqueItems…）寫進 description 提醒模型，
 *      並由本地驗證層（src/agent/validate.js）用「原始」Schema 在執行前把關 → 安全性不降低
 *   4. 單一工具轉不過或預檢失敗 → 只排除那一個工具並記錄詳細原因，其他工具照常
 */

// ---------------- Gemini ----------------
// Gemini Schema（OpenAPI 3.0 子集）允許的欄位；其餘一律不送
const GEM_KEYS = new Set(['type', 'format', 'title', 'description', 'nullable', 'enum', 'maxItems', 'minItems', 'properties', 'required', 'minProperties', 'maxProperties', 'minLength', 'maxLength', 'pattern', 'example', 'anyOf', 'propertyOrdering', 'items', 'minimum', 'maximum']);
const GEM_TYPES = new Set(['string', 'number', 'integer', 'boolean', 'array', 'object']);
const GEM_FORMAT = { string: new Set(['enum', 'date-time']), number: new Set(['float', 'double']), integer: new Set(['int32', 'int64']) };
const MAX_DEPTH = 12;

const isObj = (x) => x && typeof x === 'object' && !Array.isArray(x);
const clone = (x) => (x === undefined ? undefined : JSON.parse(JSON.stringify(x)));
const fmtVal = (v) => (typeof v === 'string' ? v : JSON.stringify(v));

/** 解析 #/$defs/X、#/definitions/X（只支援文件內部參照） */
function deref(node, root, seen) {
  let n = node; let hops = 0;
  while (isObj(n) && typeof n.$ref === 'string') {
    if (hops++ > 10 || seen.has(n.$ref)) return { circular: true, ref: n.$ref };
    const m = /^#\/(\$defs|definitions)\/(.+)$/.exec(n.$ref); if (!m) return { unresolved: true, ref: n.$ref };
    const target = root && root[m[1]] && root[m[1]][decodeURIComponent(m[2]).replace(/~1/g, '/').replace(/~0/g, '~')];
    if (!target) return { unresolved: true, ref: n.$ref };
    const { $ref, ...rest } = n; n = { ...clone(target), ...rest };   // 參照旁邊的 description 等覆蓋
  }
  return { node: n };
}
/** allOf：合併成一個物件（properties／required 聯集，其他欄位後者覆蓋） */
function mergeAllOf(n) {
  if (!Array.isArray(n.allOf)) return n;
  const { allOf, ...base } = n; const out = { ...base };
  for (const s of allOf) {
    if (!isObj(s)) continue;
    for (const [k, v] of Object.entries(s)) {
      if (k === 'properties' && isObj(v)) out.properties = { ...(out.properties || {}), ...v };
      else if (k === 'required' && Array.isArray(v)) out.required = [...new Set([...(out.required || []), ...v])];
      else if (out[k] === undefined) out[k] = v;
    }
  }
  if (!out.type && out.properties) out.type = 'object';
  return out;
}
/** 收集無法用 Gemini 表達的限制（寫進 description；真正的把關在本地驗證層） */
function constraintNotes(n) {
  const notes = [];
  if (n.exclusiveMinimum !== undefined && n.exclusiveMinimum !== false) notes.push(`必須大於 ${n.exclusiveMinimum === true ? n.minimum : n.exclusiveMinimum}`);
  if (n.exclusiveMaximum !== undefined && n.exclusiveMaximum !== false) notes.push(`必須小於 ${n.exclusiveMaximum === true ? n.maximum : n.exclusiveMaximum}`);
  if (n.multipleOf !== undefined) notes.push(`必須是 ${n.multipleOf} 的倍數`);
  if (n.uniqueItems) notes.push('項目不可重複');
  if (n.const !== undefined && typeof n.const !== 'string') notes.push(`固定值 ${fmtVal(n.const)}`);
  if (n.additionalProperties === false) notes.push('不可有其他欄位');
  if (n.not) notes.push('有排除條件');
  if (n.if || n.then || n.else || n.dependentRequired || n.dependencies) notes.push('有條件式必填');
  if (n.contains) notes.push('需包含特定項目');
  if (n.patternProperties || n.propertyNames) notes.push('欄位名稱有規則');
  return notes;
}

/**
 * 轉成 Gemini 可接受的 Schema。回傳 {schema, coerce, notes}
 *   coerce：哪些路徑被改成「JSON 字串」（例如沒有 properties 的巢狀物件），模型回傳後要解析回物件
 */
function toGemini(schema) {
  const root = isObj(schema) ? schema : {}; const coerce = []; const dropped = [];
  const walk = (node, path, depth, seen) => {
    if (depth > MAX_DEPTH) { coerce.push(path); return { type: 'string', description: '（結構太深，請用 JSON 字串表示）' }; }
    if (!isObj(node)) { if (node === true || node === undefined) return { type: 'string' }; return { type: 'string' }; }
    const d = deref(node, root, seen); if (d.circular || d.unresolved) { coerce.push(path); dropped.push(`${path || '(根)'}: $ref ${d.ref}${d.circular ? '（循環）' : '（找不到）'}→改用 JSON 字串`); return { type: 'string', description: `${node.description ? node.description + '｜' : ''}JSON 字串` }; }
    let n = mergeAllOf(d.node); const nextSeen = new Set(seen); if (node.$ref) nextSeen.add(node.$ref);
    const notes = constraintNotes(n); const out = {};
    // 類型：陣列 → nullable／anyOf
    let type = n.type; let nullable = n.nullable === true;
    if (Array.isArray(type)) { const t = type.filter((x) => x !== 'null'); if (t.length !== type.length) nullable = true; if (t.length > 1) { n = { ...n, anyOf: t.map((x) => ({ ...n, type: x, anyOf: undefined, oneOf: undefined })) }; type = undefined; } else type = t[0]; }
    if (n.oneOf && !n.anyOf) n = { ...n, anyOf: n.oneOf };
    if (Array.isArray(n.anyOf)) {
      const alts = n.anyOf.filter((x) => !(isObj(x) && x.type === 'null')); if (alts.length !== n.anyOf.length) nullable = true;
      if (alts.length === 1 && !type) { const one = walk({ ...alts[0], description: alts[0].description || n.description }, path, depth + 1, nextSeen); if (nullable) one.nullable = true; return one; }
      if (alts.length > 1) { out.anyOf = alts.map((x, i) => walk(x, `${path}.anyOf[${i}]`, depth + 1, nextSeen)); }
    }
    // 26.11.3 pro1：Gemini 的 enum 不能有空字串（"enum[0]: cannot be empty"，例如 Canva 的 link: anyOf[{const:""}, …]＝「清除連結」）
    //   → 空字串從 enum 拿掉，改在說明寫「可以填空字串」；本地驗證仍用原始規格，所以模型送 "" 照樣合法
    if (n.const !== undefined && typeof n.const === 'string') { type = 'string'; if (n.const === '') { notes.push('填空字串 "" 代表清除／不設定'); dropped.push(`${path || '(根)'}: const "" → 一般字串`); } else out.enum = [n.const]; }
    if (!type && !out.anyOf) type = n.properties ? 'object' : n.items ? 'array' : n.enum ? 'string' : (n.minimum !== undefined || n.maximum !== undefined) ? 'number' : 'string';
    if (type && !GEM_TYPES.has(type)) { dropped.push(`${path || '(根)'}: 不支援的 type ${type}→string`); type = 'string'; }
    if (type) out.type = type;
    if (nullable) out.nullable = true;
    for (const k of ['title', 'description', 'pattern', 'example']) if (typeof n[k] === 'string' && n[k]) out[k] = n[k];
    if (n.examples && Array.isArray(n.examples) && n.examples.length && out.example === undefined) out.example = n.examples[0];
    if (out.example !== undefined && typeof out.example === 'object') out.example = JSON.stringify(out.example);
    if (n.default !== undefined) notes.push(`預設 ${fmtVal(n.default)}`);
    if (n.format) { if (GEM_FORMAT[type] && GEM_FORMAT[type].has(n.format)) out.format = n.format; else notes.push(`格式 ${n.format}`); }
    if (Array.isArray(n.enum)) {
      if (n.enum.every((v) => typeof v === 'string') && (type === 'string' || !type)) {
        const vals = [...new Set(n.enum)].filter((v) => v !== ''); if (vals.length !== n.enum.length && n.enum.includes('')) { notes.push('也可以填空字串 ""'); dropped.push(`${path || '(根)'}: enum 拿掉空字串`); }
        if (vals.length) out.enum = vals.slice(0, 200);
      } else notes.push(`可用值：${n.enum.slice(0, 30).map(fmtVal).join('、')}`);
    }
    if (type === 'number' || type === 'integer') {
      for (const k of ['minimum', 'maximum']) if (typeof n[k] === 'number') out[k] = n[k];
      if (typeof n.exclusiveMinimum === 'number' && out.minimum === undefined) out.minimum = n.exclusiveMinimum;   // 近似（下限）；「不可等於」由本地驗證把關
      if (typeof n.exclusiveMaximum === 'number' && out.maximum === undefined) out.maximum = n.exclusiveMaximum;
    }
    if (type === 'string') for (const k of ['minLength', 'maxLength']) if (Number.isInteger(n[k])) out[k] = n[k];
    if (type === 'array') {
      for (const k of ['minItems', 'maxItems']) if (Number.isInteger(n[k])) out[k] = n[k];
      const it = Array.isArray(n.items) ? n.items[0] : (n.items || n.prefixItems && n.prefixItems[0]);
      out.items = it ? walk(it, `${path}[]`, depth + 1, nextSeen) : { type: 'string' };
    }
    if (type === 'object') {
      const props = isObj(n.properties) ? n.properties : {};
      const keys = Object.keys(props).filter((k) => k !== '');   // Gemini 不接受空的欄位名稱
      if (!keys.length) {
        if (depth > 0) { coerce.push(path); const desc = [n.description, '請用 JSON 物件字串表示'].filter(Boolean).join('｜'); return { type: 'string', description: desc, ...(nullable ? { nullable: true } : {}) }; }
      } else {
        out.properties = {}; for (const k of keys) out.properties[k] = walk(props[k], path ? `${path}.${k}` : k, depth + 1, nextSeen);
        const req = Array.isArray(n.required) ? n.required.filter((r) => keys.includes(r)) : []; if (req.length) out.required = req;
        for (const k of ['minProperties', 'maxProperties']) if (Number.isInteger(n[k])) out[k] = n[k];
      }
    }
    if (notes.length) out.description = `${out.description ? out.description + ' ' : ''}（限制：${notes.join('；')}）`.slice(0, 1000);
    return out;
  };
  const s = walk(clone(schema) || { type: 'object', properties: {} }, '', 0, new Set());
  // 函式參數最外層必須是 object；沒有參數就不送 parameters
  const top = s.type === 'object' && s.properties && Object.keys(s.properties).length ? s : s.type === 'object' ? null : { type: 'object', properties: { value: s }, required: ['value'] };
  if (top && top !== s) coerce.push('@wrap');
  return { schema: top, coerce, dropped };
}

/** Gemini 預檢：回傳錯誤清單（空＝可送） */
function checkGemini(s, path = '') {
  const errs = []; if (s === null) return errs;
  const w = (n, p) => {
    if (!isObj(n)) { errs.push(`${p || '(根)'}: 不是物件`); return; }
    for (const k of Object.keys(n)) if (!GEM_KEYS.has(k)) errs.push(`${p || '(根)'}: 不支援的欄位 ${k}`);
    if (n.type !== undefined && !GEM_TYPES.has(n.type)) errs.push(`${p || '(根)'}: 不支援的 type ${JSON.stringify(n.type)}`);
    if (n.type === undefined && !n.anyOf) errs.push(`${p || '(根)'}: 缺 type`);
    if (n.enum && (!Array.isArray(n.enum) || n.enum.some((v) => typeof v !== 'string'))) errs.push(`${p || '(根)'}: enum 必須全是字串`);
    if (Array.isArray(n.enum) && (!n.enum.length || n.enum.some((v) => v === ''))) errs.push(`${p || '(根)'}: enum 不可為空、也不可有空字串`);
    if (isObj(n.properties) && Object.keys(n.properties).some((k) => k === '')) errs.push(`${p || '(根)'}: 有空的欄位名稱`);
    if (n.type === 'array' && !isObj(n.items)) errs.push(`${p || '(根)'}: array 缺 items`);
    if (n.type === 'object') {
      if (!isObj(n.properties) || !Object.keys(n.properties).length) errs.push(`${p || '(根)'}: object 的 properties 不可為空`);
      else { if (n.required && n.required.some((r) => !(r in n.properties))) errs.push(`${p || '(根)'}: required 有不存在的欄位`); for (const [k, v] of Object.entries(n.properties)) w(v, p ? `${p}.${k}` : k); }
    }
    if (isObj(n.items)) w(n.items, `${p}[]`);
    if (Array.isArray(n.anyOf)) n.anyOf.forEach((x, i) => w(x, `${p}.anyOf[${i}]`));
  };
  w(s, path); return errs;
}

/** 模型回傳的參數：把被改成 JSON 字串的欄位解析回去 */
function restoreArgs(args, coerce) {
  if (!coerce || !coerce.length || !isObj(args)) return args || {};
  let a = clone(args);
  if (coerce.includes('@wrap')) a = a.value;
  const fix = (obj, parts) => {
    if (obj == null) return obj; const [h, ...rest] = parts;
    if (h === undefined) { if (typeof obj === 'string') { try { return JSON.parse(obj); } catch { return obj; } } return obj; }
    if (h.endsWith('[]')) { const key = h.slice(0, -2); const arr = key ? obj[key] : obj; if (Array.isArray(arr)) { const fixed = arr.map((x) => fix(x, rest)); if (key) obj[key] = fixed; else return fixed; } return obj; }
    if (isObj(obj) && h in obj) obj[h] = fix(obj[h], rest); return obj;
  };
  for (const p of coerce) { if (p === '@wrap' || !p) continue; const parts = p.split('.').filter((x) => !/^anyOf\[\d+\]$/.test(x)).flatMap((x) => (x.endsWith('[]') && x !== '[]' ? [x] : [x])); a = fix(a, parts); }
  return a;
}

// ---------------- Claude（Anthropic）----------------
/** Claude 吃標準 JSON Schema：只需確保最外層是 object、拿掉 $schema/$id 這類中繼欄位 */
function toAnthropic(schema) {
  const s = clone(schema) || {}; for (const k of ['$schema', '$id', '$comment']) delete s[k];
  if (s.type !== 'object') return { type: 'object', properties: { value: s }, required: ['value'] };
  if (!isObj(s.properties)) s.properties = {}; return s;
}
// ---------------- OpenAI 相容（ChatGPT／NVIDIA／Groq／自訂）----------------
/** OpenAI 系列吃大部分 JSON Schema；部分相容服務（Groq、NIM、自架）對罕見欄位會報錯 → 保守移除中繼／條件式欄位，限制寫進 description */
function toOpenAI(schema, { conservative = false } = {}) {
  const s = clone(schema) || {};
  const strip = (n, depth) => {
    if (!isObj(n) || depth > MAX_DEPTH) return n;
    for (const k of ['$schema', '$id', '$comment']) delete n[k];
    if (conservative) {
      const notes = constraintNotes(n).filter((x) => !/不可有其他欄位/.test(x));
      for (const k of ['if', 'then', 'else', 'not', 'dependentRequired', 'dependencies', 'patternProperties', 'propertyNames', 'contains', 'unevaluatedProperties', 'unevaluatedItems', 'contentEncoding', 'contentMediaType', 'readOnly', 'writeOnly', 'deprecated', 'examples']) delete n[k];
      if (notes.length && !String(n.description || '').includes('（限制：')) n.description = `${n.description ? n.description + ' ' : ''}（限制：${notes.join('；')}）`.slice(0, 1000);
    }
    if (isObj(n.properties)) for (const v of Object.values(n.properties)) strip(v, depth + 1);
    if (isObj(n.items)) strip(n.items, depth + 1); if (Array.isArray(n.items)) n.items.forEach((x) => strip(x, depth + 1));
    for (const k of ['anyOf', 'oneOf', 'allOf', 'prefixItems']) if (Array.isArray(n[k])) n[k].forEach((x) => strip(x, depth + 1));
    for (const k of ['$defs', 'definitions']) if (isObj(n[k])) for (const v of Object.values(n[k])) strip(v, depth + 1);
    if (isObj(n.additionalProperties)) strip(n.additionalProperties, depth + 1);
    return n;
  };
  strip(s, 0);
  if (s.type !== 'object') return { type: 'object', properties: { value: s }, required: ['value'] };
  if (!isObj(s.properties)) s.properties = {}; return s;
}

/** 工具名稱：各家都要求 [A-Za-z0-9_-]、最長 64；Gemini 另允許 . 但為了一致不用 */
const safeName = (n) => String(n || 'tool').replace(/[^A-Za-z0-9_-]/g, '_').replace(/^[^A-Za-z_]/, '_$&').slice(0, 64);

module.exports = { toGemini, checkGemini, restoreArgs, toAnthropic, toOpenAI, safeName, GEM_KEYS };
