'use strict';
/**
 * 統一的模型介面。內部訊息格式（供 agent 使用）：
 *   {role:'user', text, images?:[{mime,data(base64)}]}
 *   {role:'assistant', text, toolCalls?:[{id,name,args}], raw?:{provider, parts}}
 *   {role:'tool', results:[{id,name,content}]}
 * generate() 回傳 {text, toolCalls, usage:{in,out}, raw}
 */
const { logger } = require('../core/log');
const SCH = require('./schema');
const { sleep, rid, fetchJson } = require('../core/util');
const log = logger('llm');

class LLMError extends Error { constructor(msg, status, retryable) { super(msg); this.status = status; this.retryable = retryable; } }

/** 從回應取「該等幾秒再試」：優先 retry-after 標頭，其次 Gemini 的 RetryInfo（body.error.details[].retryDelay:"18s"）；都沒有回 0 */
function retryAfterOf(r) {
  if (!r) return 0;
  if (r.retryAfter && r.retryAfter > 0) return Math.min(300, r.retryAfter);
  try { const det = ((r.json || {}).error || {}).details || []; for (const d of det) { const m = /([\d.]+)s/.exec(d && d.retryDelay || ''); if (m) return Math.min(300, Math.ceil(Number(m[1]))); } } catch { /* ignore */ }
  return 0;
}
/** 是不是「每分鐘請求上限」這種暫時性速率限制（RPM/TPM/並發），不是每日額度或餘額不足。這種只要稍等就會恢復，不該把金鑰當成耗盡。 */
function isRateLimit(e) {
  if (!e || e.status !== 429) return false;
  if (e.quota === 'daily' || e.quota === 'credit') return false;
  const t = `${e.message || ''} ${e.body ? JSON.stringify(e.body).slice(0, 1500) : ''}`;
  if (/per ?day|PerDay|daily|free[_ -]?tier|credit balance|insufficient_quota|billing|exceeded your current quota/i.test(t)) return false;
  return true;   // 預設把一般 429 當成暫時性速率限制（稍等重試），而不是永久耗盡
}

/**
 * 供應商註冊表。kind＝線路格式：gemini／anthropic／openai（OpenAI Chat Completions 相容，ChatGPT、NVIDIA NIM、Groq 與自訂端點共用）。
 * 模型名稱只是「預設建議」，實際可用清單請用 listModels() 向供應商查（各家常換型號，這裡不寫死）。
 */
const PROVIDERS = {
  gemini: { label: 'Gemini', kind: 'gemini', defaultModel: 'gemini-3.6-flash', keyUrl: 'https://aistudio.google.com/apikey', vision: true },
  anthropic: { label: 'Claude', kind: 'anthropic', defaultModel: 'claude-sonnet-5-5', keyUrl: 'https://console.anthropic.com/settings/keys', vision: true },
  openai: { label: 'ChatGPT (OpenAI)', kind: 'openai', baseUrl: 'https://api.openai.com/v1', tokenParam: 'max_completion_tokens', defaultModel: 'gpt-4o-mini', keyUrl: 'https://platform.openai.com/api-keys', vision: true },
  nvidia: { label: 'NVIDIA NIM', kind: 'openai', baseUrl: 'https://integrate.api.nvidia.com/v1', tokenParam: 'max_tokens', defaultModel: 'meta/llama-3.3-70b-instruct', keyUrl: 'https://build.nvidia.com', vision: /vision|-vl|vlm|llava|neva|vila|pixtral|llama-4|phi-3\.5-vision|paligemma/i },
  groq: { label: 'Groq', kind: 'openai', baseUrl: 'https://api.groq.com/openai/v1', tokenParam: 'max_tokens', defaultModel: 'llama-3.3-70b-versatile', keyUrl: 'https://console.groq.com/keys', vision: /vision|llama-4|scout|maverick/i },
  custom: { label: '自訂 (OpenAI 相容)', kind: 'openai', baseUrl: '', tokenParam: 'max_tokens', defaultModel: '', keyUrl: '', vision: false },
};
const providerIds = () => Object.keys(PROVIDERS);
const isProvider = (p) => Object.prototype.hasOwnProperty.call(PROVIDERS, p);
const labelOf = (p) => (PROVIDERS[p] ? PROVIDERS[p].label : String(p));
const supportsVision = (provider, model) => { const v = PROVIDERS[provider] && PROVIDERS[provider].vision; return v instanceof RegExp ? v.test(model || '') : !!v; };
/** 某供應商目前要用的模型：主供應商用 model.name；其他（備援）用 provider_models 記住的或預設 */
function modelFor(S, provider) {
  if (provider === S.get('model.provider')) return S.get('model.name') || (PROVIDERS[provider] || {}).defaultModel || '';
  return (S.get('model.provider_models', {}) || {})[provider] || (PROVIDERS[provider] || {}).defaultModel || '';
}
/** OpenAI 相容端點的網址：只接受 http(s)；結尾斜線與 /chat/completions 會被整理掉 */
function baseUrlOf(S, provider, candidate) {
  const raw = provider === 'custom' ? ((candidate && candidate.base_url) || S.get('model.custom_base_url', '')) : (PROVIDERS[provider] || {}).baseUrl;
  const u = String(raw || '').trim().replace(/\/+$/, '').replace(/\/chat\/completions$/, '');
  if (!/^https?:\/\/[^\s]+$/i.test(u)) throw new LLMError(provider === 'custom' ? '自訂供應商還沒設定 API 網址（例如 https://example.com/v1）。' : `${labelOf(provider)} 網址無效`, 0, false);
  return u;
}

function friendly(status, body, provider) {
  const detail = (body && (body.error && (body.error.message || body.error) || body.message || body.detail) || '').toString().slice(0, 300);
  if (status === 400 && /API key/i.test(detail)) return '模型金鑰無效，請到「設定」頁重新填寫 API Key。';
  if (status === 401 || status === 403) return `${provider} 金鑰無效或沒有權限（${status}）。${detail}`;
  if (status === 404) return `找不到模型或網址，請到「設定 → 模型」確認模型名稱。${detail}`;
  if (status === 429) return `${provider} 額度或速率受限（429），稍後再試。${detail}`;
  if (status >= 500) return `${provider} 服務暫時有問題（${status}）。`;
  if ((status === 400 || status === 422) && /Unknown name|Invalid JSON payload|function_declarations|schema/i.test(detail)) return `${provider} 不接受某個工具的參數規格（${status}）：${detail}（系統會自動隔離該工具；可到「模型 → 工具相容性」查看）`;
  if ((status === 400 || status === 422) && /tool|function/i.test(detail)) return `${provider} 錯誤（${status}）：${detail}（此模型可能不支援工具呼叫，請改選支援 function calling 的模型）`;
  return `${provider} 錯誤（${status}）：${detail}`;
}

async function post(url, headers, body, provider, fastFail = false) {
  // fastFail（金鑰池模式）：同一把金鑰只快速重試一次，其餘交給金鑰輪換，不浪費等待時間
  const tries = fastFail ? 2 : 3; let last;
  for (let i = 0; i < tries; i++) {
    try {
      const r = await fetchJson(url, { method: 'POST', headers: { 'content-type': 'application/json', ...headers }, body: JSON.stringify(body) }, 90000);
      if (r.ok) return r.json;
      last = new LLMError(friendly(r.status, r.json, provider), r.status, r.status === 429 || r.status >= 500);
      last.body = r.json; last.retryAfter = retryAfterOf(r);
      if (!last.retryable) throw last;
      if (fastFail && (r.status === 401 || r.status === 403 || r.status === 429)) { last.noRetry = true; throw last; }
    } catch (e) {
      if (e instanceof LLMError) { if (!e.retryable || e.noRetry) throw e; last = e; }   // 26.11.3 pro3：金鑰池模式 429 直接換下一把（以前會被這裡吃掉又重試一次）
      else last = new LLMError(`連不上 ${provider}：${e.name === 'AbortError' ? '逾時' : e.message}`, 0, true);
    }
    if (i < tries - 1) await sleep((fastFail ? 400 : 1200) * (i + 1));
  }
  throw last;
}

/** 26.11.3 pro3：判斷是不是「額度用完」：daily＝每日免費額度；credit＝儲值／帳單餘額不足；''＝不是 */
function quotaKind(e) {
  const t = `${e.message || ''} ${e.body ? JSON.stringify(e.body).slice(0, 2000) : ''}`;
  if (/credit balance|insufficient_quota|billing|payment required|exceeded your current quota|余額不足|餘額不足|plan and billing/i.test(t) && (e.status === 400 || e.status === 402 || e.status === 403 || e.status === 429)) return 'credit';
  if (e.status === 429 && /per ?day|PerDay|daily|RESOURCE_EXHAUSTED.*quota|quota.*exceeded|free[_ -]?tier/i.test(t)) return 'daily';
  return '';
}
/** 供應商順序（26.11.3 pro3）：model.provider_order 由你排；第一個就是主要（model.provider）。沒排過＝[主要, 舊版備援] */
function providerOrder(S) {
  const main = isProvider(S.get('model.provider')) ? S.get('model.provider') : 'gemini';
  const o = (S.get('model.provider_order', []) || []).filter(isProvider); const fb = S.get('model.fallback_provider', '');
  return [...new Set([main, ...(o.length ? o : fb && isProvider(fb) ? [fb] : [])])];
}
/** 這家在多家順序裡（有別家可接手或接手過）：由 generate 統一通知，不在這裡發「金鑰全部用完」 */
function inChain(S, provider) { const o = providerOrder(S); return o.includes(provider) && o.filter((p) => p !== provider && keyCandidates(S, p).length).length > 0; }
/** 這家後面還有沒有「有金鑰可用」的供應商 */
function hasNext(S, provider) { const o = providerOrder(S); const i = o.indexOf(provider); return i >= 0 && o.slice(i + 1).some((p) => hasKeyFor(S, p)); }
/** 金鑰目前能不能用：被標記耗盡或「每分鐘上限」冷卻中的，要等冷卻時間過了才視為恢復（都不需要人工重設） */
const usable = (x) => (!x.exhausted && !x.rate_limited) || (x.cooldown_until && Date.now() > x.cooldown_until);

function keyCandidates(S, provider) {
  const pool = S.get('model.api_keys', []);
  if (Array.isArray(pool) && pool.length) { const own = pool.map((x, index) => ({ ...x, index })).filter((x) => x.provider === provider && x.key && x.enabled !== false); if (own.length) return own; }   // 這家在池裡沒有金鑰時，退回舊版單一金鑰欄位
  const legacy = S.get(`model.${provider}_key`);
  return legacy && isProvider(provider) ? [{ key: legacy, provider, model: '', index: -1 }] : [];
}

async function withKeyRotation(ctx, provider, call) {
  const S = ctx.settings; const all = keyCandidates(S, provider);
  if (!all.length) throw new LLMError(`還沒設定 ${labelOf(provider)} 的 API Key（設定 → 模型）。`, 0, false);
  const pool = S.get('model.api_keys', []); const isPool = Array.isArray(pool) && pool.length > 0;
  const cursor = isPool ? Math.max(0, Number(S.get('model.api_key_cursor', 0)) || 0) : 0;
  // 把 cursor 當起點輪流試；fresh()＝每一輪都用「設定裡最新的狀態」重算，這樣請求內等過冷卻的金鑰會重新變回可用
  const fresh = () => { const cur = Math.max(0, Number(S.get('model.api_key_cursor', 0)) || 0) % Math.max(1, all.length); const mk = (x) => ({ ...x, ...(S.get('model.api_keys', [])[x.index] || {}), index: x.index, key: x.key, provider: x.provider }); return all.slice(cur).map(mk).concat(all.slice(0, cur).map(mk)); };
  let last; let anyCool = Infinity;
  // Anti-gravity-engine1：最多跑兩輪。第一輪全部碰到「每分鐘上限」時不當作耗盡，而是稍等（取最短冷卻，最多 8 秒）再跑第二輪，讓這則回覆能完成、速度保持穩定。
  for (let pass = 0; pass < 2; pass++) {
    let tried = 0; let sawRate = false; anyCool = Infinity;
    for (const candidate of fresh()) {
      if (isPool && !usable(candidate)) { if (candidate.cooldown_until) anyCool = Math.min(anyCool, candidate.cooldown_until); continue; }
      tried++;
      try {
        const result = await call(candidate);
        if (isPool) {
          if (S.get('model.api_keys_notified')) S.set('model.api_keys_notified', false, 'system');
          if (candidate.exhausted || candidate.rate_limited) S.set('model.api_keys', S.get('model.api_keys', []).map((x, i) => (i === candidate.index ? { ...x, exhausted: false, rate_limited: false, last_error: '', cooldown_until: 0 } : x)), 'system');
        }
        return result;
      } catch (e) {
        last = e;
        const q = e instanceof LLMError ? quotaKind(e) : ''; if (q) e.quota = q;
        const rate = e instanceof LLMError && isRateLimit(e); if (rate) sawRate = true;
        const rotate = e instanceof LLMError && (e.status === 401 || e.status === 403 || e.status === 429 || e.status >= 500 || e.status === 0 || !!q);
        if (!isPool || !rotate) throw e;
        // 401/403＝金鑰壞了，需人工處理；每分鐘上限（RPM）＝短冷卻（照 retry-after，預設 20 秒）、標成 rate_limited 而非耗盡；每日額度冷卻 1 小時；儲值不足冷卻 6 小時；5xx／網路＝不標記金鑰、直接換下一把
        const bad = (e.status === 401 || e.status === 403) && !q;
        if (bad || rate || q) {
          const cool = bad ? 0 : Date.now() + (q === 'credit' ? 6 * 3600e3 : q === 'daily' ? 3600e3 : Math.max(5, Math.min(60, e.retryAfter || 20)) * 1000);
          if (cool) anyCool = Math.min(anyCool, cool);
          const next = S.get('model.api_keys', []).map((x, i) => (i === candidate.index ? { ...x, exhausted: !rate || !!q, rate_limited: rate && !q, last_error: e.message, last_used: Date.now(), cooldown_until: cool } : x));
          S.set('model.api_keys', next, 'system');
        }
        S.set('model.api_key_cursor', (candidate.index + 1) % Math.max(1, all.length), 'system');
      }
    }
    // 這一輪都沒成功：如果全是「每分鐘上限」而且只是短暫冷卻，就等一下再跑第二輪（單人使用時這能讓回覆不中斷）
    const onlyRate = sawRate && isRateLimit(last || {}) && !(last && last.quota);
    if (pass === 0 && onlyRate && !inChain(S, provider) && anyCool !== Infinity && anyCool - Date.now() <= 8200) { await sleep(Math.max(300, Math.min(8000, anyCool - Date.now()))); continue; }
    break;
  }
  // 走到這裡＝這家目前沒有可用金鑰。分兩種：暫時（每分鐘上限，稍候即可）vs 真的耗盡／失效（要換金鑰）
  if (isRateLimit(last || {}) && !(last && last.quota)) {
    const wait = anyCool !== Infinity ? `約 ${Math.max(1, Math.ceil((anyCool - Date.now()) / 1000))} 秒後` : '稍候';
    const er = new LLMError(`目前 ${labelOf(provider)} 請求太頻繁（每分鐘上限），${wait}會自動恢復。不是金鑰用完，不用換金鑰。`, 429, true); er.rate = true; if (inChain(S, provider)) er.quota = 'rate';
    throw er;   // rate：多家時交給 generate 換下一家；單一供應商時 retryable＝true、不發「全部用完」通知
  }
  const msg = `目前供應商 ${labelOf(provider)} 的 API 金鑰已全部耗盡或失效。請在設定頁更換或重設金鑰。`;
  if (isPool && (last == null || last.status === 401 || last.status === 403 || last.status === 429 || last.quota)) {
    if (inChain(S, provider)) { const er = new LLMError(msg, 429, false); er.quota = 'all'; throw er; }   // 後面還有供應商：交給 generate 換下一家
    if (!S.get('model.api_keys_notified')) { S.set('model.api_keys_notified', true, 'system'); await ctx.notifier.critical('AI API 金鑰已全部用完', msg).catch(() => {}); }
    throw new LLMError(msg, 429, false);
  }
  throw last || new LLMError('模型呼叫失敗', 0, false);
}

// ---------------- Gemini ----------------
function toGemini(messages) {
  const out = [];
  const push = (role, parts) => { const l = out[out.length - 1]; if (l && l.role === role) l.parts.push(...parts); else out.push({ role, parts }); };
  for (const m of messages) {
    if (m.role === 'user') {
      const parts = []; if (m.text) parts.push({ text: m.text });
      for (const im of m.images || []) parts.push({ inlineData: { mimeType: im.mime, data: im.data } });
      if (!parts.length) parts.push({ text: '(空)' }); push('user', parts);
    } else if (m.role === 'assistant') {
      const parts = m.raw && m.raw.provider === 'gemini' ? m.raw.parts
        : [...(m.text ? [{ text: m.text }] : []), ...(m.toolCalls || []).map((c) => ({ functionCall: { name: SCH.safeName(c.name), args: c.args } }))];
      if (parts.length) push('model', parts);
    } else if (m.role === 'tool') {
      const parts = m.results.map((r) => ({ functionResponse: { name: SCH.safeName(r.name), response: { result: r.content } } }));
      for (const r of m.results) for (const im of r.images || []) parts.push({ inlineData: { mimeType: im.mime, data: im.data } });   // 工具回傳的截圖／圖片：接在函式結果後面讓模型看得到
      push('user', parts);
    }
  }
  return out;
}
/** 讓 Gemini 少花時間「想」：預設用低思考量，回覆明顯變快；模型不支援時自動退回預設。 */
/**
 * fast：簡單的一句話 → 不思考，直接回（26.11.3 Revise4 加速）
 * deep：26.11.3 Revise5——多步驟任務、需要推理分析、上一步失敗或自我檢查沒過時 → 想深一點（管理員可用 model.deep_think=false 關掉）
 */
function thinkingCfg(S, model, fast, deep) {
  const base = S.get('model.thinking', 'low'); if (base === 'auto') return null;
  const mode = fast ? 'off' : deep && S.get('model.deep_think', true) !== false ? 'high' : base;
  if (/gemini-3/i.test(model)) return { thinkingLevel: mode === 'off' ? 'minimal' : mode === 'high' ? 'high' : 'low' };
  if (/gemini-2\.5-flash/i.test(model)) return { thinkingBudget: mode === 'off' ? 0 : mode === 'high' ? 4096 : 512 };
  if (/gemini-2\.5-pro/i.test(model) && mode === 'high') return { thinkingBudget: 8192 };
  return null;
}
const MARK = '\n\n<<<DYNAMIC>>>\n\n';
const flat = (s) => String(s || '').split(MARK).join('\n\n');
async function gemini(ctx, S, { system, messages, decls, maxTokens, model, fallback, fast, deep }) {
  system = flat(system);
  const body = { systemInstruction: { parts: [{ text: system }] }, contents: toGemini(messages), generationConfig: { maxOutputTokens: maxTokens } };
  if (decls && decls.length) body.tools = [{ functionDeclarations: decls }];
  const run = (mdl, withThink) => withKeyRotation(ctx, 'gemini', (candidate) => {
    const m = candidate.model || mdl; const th = withThink ? thinkingCfg(S, m, fast, deep) : null;
    const b = th ? { ...body, generationConfig: { ...body.generationConfig, thinkingConfig: th } } : body;
    return post(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(m)}:generateContent`, { 'x-goog-api-key': candidate.key }, b, 'Gemini', true);
  });
  let j;
  try {
    try { j = await run(model, true); }
    catch (e) { if (e instanceof LLMError && e.status === 400 && /think/i.test(JSON.stringify(e.body || e.message))) { log.warn('此模型不支援 thinking 設定，改用預設'); S.data.model.thinking = 'auto'; j = await run(model, false); } else throw e; }
  } catch (e) {
    if (fallback && fallback !== model && e instanceof LLMError && (e.retryable || e.status === 404 || e.status === 0)) { log.warn(`主模型失敗（${e.message}），改用備援模型 ${fallback}`); j = await run(fallback, false); }
    else throw e;
  }
  const cand = j.candidates && j.candidates[0]; const parts = (cand && cand.content && cand.content.parts) || [];
  if (!parts.length) {
    const why = (cand && cand.finishReason) || (j.promptFeedback && j.promptFeedback.blockReason) || '未知';
    return { text: why === 'STOP' ? '' : `（模型沒有回應內容，原因：${why}）`, toolCalls: [], usage: usage(j.usageMetadata, 'g'), raw: null };
  }
  const text = parts.filter((p) => p.text && !p.thought).map((p) => p.text).join('');
  const toolCalls = parts.filter((p) => p.functionCall).map((p) => ({ id: 'c_' + rid(4), name: p.functionCall.name, args: p.functionCall.args || {} }));
  return { text, toolCalls, usage: usage(j.usageMetadata, 'g'), raw: { provider: 'gemini', parts } };
}
const usage = (u, k) => (u ? (k === 'g' ? { in: u.promptTokenCount || 0, out: (u.candidatesTokenCount || 0) + (u.thoughtsTokenCount || 0) } : { in: u.input_tokens || 0, out: u.output_tokens || 0 }) : { in: 0, out: 0 });

// ---------------- Anthropic ----------------
function toAnthropic(messages) {
  const out = [];
  const push = (role, content) => { const l = out[out.length - 1]; if (l && l.role === role) l.content.push(...content); else out.push({ role, content }); };
  for (const m of messages) {
    if (m.role === 'user') {
      const c = []; for (const im of m.images || []) c.push({ type: 'image', source: { type: 'base64', media_type: im.mime, data: im.data } });
      c.push({ type: 'text', text: m.text || '(空)' }); push('user', c);
    } else if (m.role === 'assistant') {
      const c = m.raw && m.raw.provider === 'anthropic' ? m.raw.parts
        : [...(m.text ? [{ type: 'text', text: m.text }] : []), ...(m.toolCalls || []).map((t) => ({ type: 'tool_use', id: t.id, name: SCH.safeName(t.name), input: t.args }))];
      if (c.length) push('assistant', c);
    } else if (m.role === 'tool') {
      const c = m.results.map((r) => ({ type: 'tool_result', tool_use_id: r.id, content: String(r.content) }));
      for (const r of m.results) for (const im of r.images || []) c.push({ type: 'image', source: { type: 'base64', media_type: im.mime, data: im.data } });   // tool_result 在前、圖片在後
      push('user', c);
    }
  }
  return out;
}
async function anthropic(ctx, S, { system, messages, decls, maxTokens, model, fallback }) {
  // prompt caching：系統提示與工具清單每次都一樣，快取後第二次起首字更快、也更省
  // 系統提示分兩段：固定段打快取標記（每一輪、每次對話都能命中），動態段（時間、記憶）放後面不快取
  const [fixedPart, dynPart] = String(system || '').split(MARK);
  const sys = [{ type: 'text', text: fixedPart, cache_control: { type: 'ephemeral' } }, ...(dynPart ? [{ type: 'text', text: dynPart }] : [])];
  const body = { model, max_tokens: maxTokens, system: sys, messages: toAnthropic(messages) };
  if (decls && decls.length) { body.tools = decls.map((d) => ({ ...d })); body.tools[body.tools.length - 1].cache_control = { type: 'ephemeral' }; }
  const run = (mdl) => withKeyRotation(ctx, 'anthropic', (candidate) => post('https://api.anthropic.com/v1/messages', { 'x-api-key': candidate.key, 'anthropic-version': '2023-06-01' }, { ...body, model: candidate.model || mdl }, 'Claude', true));
  let j;
  try { j = await run(body.model); }
  catch (e) { if (fallback && fallback !== body.model && e instanceof LLMError && (e.retryable || e.status === 404 || e.status === 0)) { log.warn(`主模型失敗（${e.message}），改用備援模型 ${fallback}`); j = await run(fallback); } else throw e; }
  const blocks = j.content || [];
  return { text: blocks.filter((b) => b.type === 'text').map((b) => b.text).join(''), toolCalls: blocks.filter((b) => b.type === 'tool_use').map((b) => ({ id: b.id, name: b.name, args: b.input || {} })),
    usage: usage(j.usage, 'a'), raw: { provider: 'anthropic', parts: blocks } };
}

// ---------------- OpenAI 相容（ChatGPT／NVIDIA NIM／Groq／自訂） ----------------
const oaId = (id) => String(id || 'c_' + rid(4)).replace(/[^a-zA-Z0-9_-]/g, '_').slice(0, 40);
const oaImg = (im) => ({ type: 'image_url', image_url: { url: `data:${im.mime};base64,${im.data}` } });
/** 內部訊息 → Chat Completions。canSee=false 時圖片改成文字註記（模型不支援看圖就不要硬送，否則整個請求會 400） */
function toOpenAI(system, messages, canSee = true) {
  const out = [{ role: 'system', content: system || '' }];
  const note = (n) => `（${n} 張圖片已省略：目前模型不支援看圖）`;
  for (const m of messages) {
    if (m.role === 'user') {
      const imgs = m.images || [];
      if (imgs.length && canSee) out.push({ role: 'user', content: [{ type: 'text', text: m.text || '(空)' }, ...imgs.map(oaImg)] });
      else out.push({ role: 'user', content: (m.text || '(空)') + (imgs.length ? '\n' + note(imgs.length) : '') });
    } else if (m.role === 'assistant') {
      const calls = (m.toolCalls || []).map((c) => ({ id: oaId(c.id), type: 'function', function: { name: SCH.safeName(c.name), arguments: JSON.stringify(c.args || {}) } }));
      if (!m.text && !calls.length) continue;
      out.push({ role: 'assistant', content: m.text || null, ...(calls.length ? { tool_calls: calls } : {}) });
    } else if (m.role === 'tool') {
      const pics = [];
      for (const r of m.results) {
        out.push({ role: 'tool', tool_call_id: oaId(r.id), content: String(r.content == null ? '' : r.content) });
        for (const im of r.images || []) pics.push(im);
      }
      // tool 訊息不能帶圖：截圖等結果圖片改用緊接著的 user 訊息交給模型
      if (pics.length) out.push(canSee ? { role: 'user', content: [{ type: 'text', text: '（以上工具回傳的圖片）' }, ...pics.map(oaImg)] } : { role: 'user', content: note(pics.length) });
    }
  }
  return out;
}
function parseArgs(a) {
  if (a && typeof a === 'object') return a;
  try { const v = JSON.parse(a || '{}'); return v && typeof v === 'object' ? v : {}; } catch { return {}; }
}
async function openaiCompat(ctx, S, provider, { system, messages, decls, maxTokens, model, fallback, fast, deep }) {
  const P = PROVIDERS[provider]; const label = P.label.split(' ')[0];
  const mk = (mdl, candidate) => {
    const body = { model: mdl, messages: toOpenAI(flat(system), messages, supportsVision(provider, mdl)), [P.tokenParam]: maxTokens };
    if (decls && decls.length) { body.tools = decls; body.tool_choice = 'auto'; }
    // 推理模型（gpt-5、o 系列）：預設低推理量，簡單的一句話用最低，回覆快很多
    if (provider === 'openai' && /^(gpt-5|o\d)/i.test(mdl) && S.get('model.thinking', 'low') !== 'auto') body.reasoning_effort = fast || S.get('model.thinking', 'low') === 'off' ? 'minimal' : deep && S.get('model.deep_think', true) !== false ? 'medium' : 'low';
    return body;
  };
  const run = (mdl) => withKeyRotation(ctx, provider, async (candidate) => {
    const url = baseUrlOf(S, provider, candidate) + '/chat/completions'; const m = candidate.model || mdl; const hdr = { authorization: `Bearer ${candidate.key}` };
    try { return await post(url, hdr, mk(m, candidate), label, true); }
    // Groq 等偶爾回 tool_use_failed（模型吐出壞掉的工具呼叫）：同一請求重試一次通常就好
    catch (e) { if (e instanceof LLMError && e.status === 400 && /tool_use_failed|failed_generation/i.test(JSON.stringify(e.body || e.message))) return post(url, hdr, mk(m, candidate), label, true); throw e; }
  });
  let j;
  try { j = await run(model); }
  catch (e) { if (fallback && fallback !== model && e instanceof LLMError && (e.retryable || e.status === 404 || e.status === 0)) { log.warn(`主模型失敗（${e.message}），改用備援模型 ${fallback}`); j = await run(fallback); } else throw e; }
  const ch = j.choices && j.choices[0]; const msg = (ch && ch.message) || {};
  const text = Array.isArray(msg.content) ? msg.content.map((c) => c.text || '').join('') : String(msg.content || '');
  const toolCalls = (msg.tool_calls || []).filter((c) => c.function && c.function.name).map((c) => ({ id: oaId(c.id), name: c.function.name, args: parseArgs(c.function.arguments) }));
  const u = j.usage ? { in: j.usage.prompt_tokens || 0, out: j.usage.completion_tokens || 0 } : { in: 0, out: 0 };
  if (!text && !toolCalls.length) return { text: ch && ch.finish_reason && ch.finish_reason !== 'stop' ? `（模型沒有回應內容，原因：${ch.finish_reason}）` : '', toolCalls: [], usage: u, raw: null };
  return { text, toolCalls, usage: u, raw: null };
}

// ---------------- 分派 ----------------
/**
 * 送出前：把工具定義轉成這家模型吃得下的格式並預檢（llm/schema.js）。
 * 轉不過／預檢失敗的工具只排除那一個（隔離 6 小時；工具規格改了就重新檢查），其他照送。
 * 模型端仍回 400 並指出是第幾個工具 → 隔離那一個、自動重送（最多 3 次），不讓整個 AI 停擺。
 */
const QUAR = new Map(); const QUAR_MS = 6 * 3600e3;
const hashOf = (o) => require('crypto').createHash('sha1').update(JSON.stringify(o || {})).digest('hex').slice(0, 12);
function quarantine(ctx, key, info) {
  const first = !QUAR.has(key); QUAR.set(key, { ...info, at: Date.now() });
  log.warn(`[工具 Schema] ${info.provider} 暫停送出工具「${info.tool}」：${info.reason}`);
  try { ctx.debug && ctx.debug.recordError('schema:' + info.tool, new Error(`${info.provider}：${info.reason}`)); } catch { /* ignore */ }
  if (first && ctx.notifier) ctx.notifier.warn('有工具和目前模型不相容，已暫時停用該工具', `${info.tool}（${info.provider}）：${String(info.reason).slice(0, 300)}。其他工具照常運作；本地仍會用原始規格驗證參數。`).catch(() => {});
}
function prepTools(ctx, provider, tools) {
  const kind = PROVIDERS[provider].kind; const decls = []; const map = new Map(); const order = []; const skipped = [];
  for (const t of tools || []) {
    const key = `${provider}:${t.name}:${hashOf(t.parameters)}`; const q = QUAR.get(key);
    if (q && Date.now() - q.at < QUAR_MS) { skipped.push({ tool: t.name, reason: q.reason }); continue; }
    let name = SCH.safeName(t.name); for (let i = 2; map.has(name); i++) name = SCH.safeName(t.name).slice(0, 60) + '_' + i;
    const desc = String(t.description || '').slice(0, 1024); const wrapped = !!(t.parameters && t.parameters.type && t.parameters.type !== 'object');
    try {
      let decl; let coerce = wrapped ? ['@wrap'] : [];
      if (kind === 'gemini') {
        const r = SCH.toGemini(t.parameters); const errs = SCH.checkGemini(r.schema); if (errs.length) throw new Error('預檢失敗：' + errs.slice(0, 5).join('；'));
        if (r.dropped.length) log.info(`[工具 Schema] ${t.name} 轉成 Gemini 格式時調整：${r.dropped.slice(0, 5).join('；')}`);
        decl = { name, description: desc, ...(r.schema ? { parameters: r.schema } : {}) }; coerce = r.coerce;
      } else if (kind === 'anthropic') decl = { name, description: desc, input_schema: SCH.toAnthropic(t.parameters) };
      else decl = { type: 'function', function: { name, description: desc, parameters: SCH.toOpenAI(t.parameters, { conservative: provider !== 'openai' }) } };
      decls.push(decl); order.push(key); map.set(name, { orig: t.name, coerce, key });
    } catch (e) { quarantine(ctx, key, { provider, tool: t.name, reason: 'Schema 轉換失敗：' + e.message }); skipped.push({ tool: t.name, reason: e.message }); }
  }
  return { decls, map, order, skipped };
}
/** 從 400 錯誤訊息找出是第幾個工具（Gemini：function_declarations[N]；OpenAI：tools[N]；Claude：tools.N） */
function badToolIndex(e) {
  if (!(e instanceof LLMError) || e.status !== 400) return null;
  const s = JSON.stringify(e.body || '') + ' ' + e.message;
  const g = /function_declarations\[(\d+)\]/.exec(s); if (g) return +g[1];   // Gemini：tools[0].function_declarations[N]（tools[0] 是外層，不是工具編號）
  const m = /\btools(?:\[(\d+)\]|\.(\d+))/.exec(s); return m ? +(m[1] || m[2]) : null;
}
async function callProvider(ctx, provider, req) {
  const S = ctx.settings; const k = PROVIDERS[provider].kind;
  for (let attempt = 0; ; attempt++) {
    const prep = prepTools(ctx, provider, req.tools);
    try {
      const r = await (k === 'anthropic' ? anthropic(ctx, S, { ...req, decls: prep.decls }) : k === 'gemini' ? gemini(ctx, S, { ...req, decls: prep.decls }) : openaiCompat(ctx, S, provider, { ...req, decls: prep.decls }));
      r.toolCalls = (r.toolCalls || []).map((c) => { const m = prep.map.get(c.name); return m ? { ...c, name: m.orig, args: SCH.restoreArgs(c.args, m.coerce) } : c; });
      if (prep.skipped.length) r.skipped_tools = prep.skipped;
      return r;
    } catch (e) {
      const i = badToolIndex(e); const key = i != null ? prep.order[i] : null;
      if (key == null || attempt >= 3) { if (e instanceof LLMError && e.status === 400 && /function_declarations|parameters|schema/i.test(e.message)) log.error(`[工具 Schema] ${provider} 拒收工具定義且無法判斷是哪一個：${e.message}`); throw e; }
      const tool = [...prep.map.values()].find((x) => x.key === key).orig;
      quarantine(ctx, key, { provider, tool, reason: `模型拒收：${String(e.message).slice(0, 400)}` });
    }
  }
}
const hasKeyFor = (S, provider) => isProvider(provider) && keyCandidates(S, provider).some(usable);

async function generate(ctx, req) {
  const S = ctx.settings; let provider = S.get('model.provider'); if (!isProvider(provider)) provider = 'gemini';
  const maxTokens = S.get('model.max_tokens', 4096); const fbProv = S.get('model.fallback_provider', '');
  const sameFallback = S.get('model.fallback_model', '');
  // 26.11.3 pro3：照你排的供應商順序試；一家的額度用完／金鑰全失效／服務故障／連不上，就自動跳下一家（對話不中斷）
  const order = providerOrder(S); const ordered = (S.get('model.provider_order', []) || []).length > 0; let lastErr = null; const skipped = [];
  for (let i = 0; i < order.length; i++) {
    const p = order[i]; if (i > 0 && !hasKeyFor(S, p)) continue;
    // 舊版設定（沒排順序）：fallback_model 是備援供應商要用的型號；排了順序就各家用自己記住的型號，fallback_model 只當主要那家的備用型號
    const legacyFb = !ordered && i > 0 && p === fbProv && sameFallback; const model = legacyFb ? sameFallback : modelFor(S, p);
    const sameProvFb = i === 0 && (ordered || !fbProv || fbProv === p) ? sameFallback : '';
    try {
      const r = await callProvider(ctx, p, { maxTokens, ...req, model, fallback: sameProvFb });
      if (i > 0) { r.fallback = { provider: p, model, reason: lastErr ? lastErr.message : '', skipped }; noteSwitch(ctx, skipped, p, lastErr); }
      ctx.usage.add(model, r.usage); return r;
    } catch (e) {
      const can = e instanceof LLMError && ((e.status !== 400 && e.status !== 413) || e.quota);
      if (!can) throw e; lastErr = e; skipped.push(p);
      if (i < order.length - 1) log.warn(`${labelOf(p)} 不能用（${e.message}），改試下一個供應商`);
    }
  }
  if (skipped.length > 1) { const msg = `照順序試過 ${skipped.map(labelOf).join(' → ')}，都不能用（最後：${lastErr.message}）。請在「更多 → 模型」加金鑰或調整順序。`; if (!S.get('model.api_keys_notified')) { S.set('model.api_keys_notified', true, 'system'); await ctx.notifier.critical('所有 AI 供應商都不能用', msg).catch(() => {}); } throw new LLMError(msg, lastErr.status, false); }
  throw lastErr || new LLMError('模型呼叫失敗', 0, false);
}
/** 換到下一家時提醒一次（同一個組合 1 小時內只提醒一次） */
const SWITCH_NOTE = new Map();
function noteSwitch(ctx, from, to, err) {
  const k = from.join('>') + '>' + to; if (Date.now() - (SWITCH_NOTE.get(k) || 0) < 3600e3) return; SWITCH_NOTE.set(k, Date.now());
  const why = err && (err.rate || err.quota === 'rate') ? '請求太頻繁（每分鐘上限）' : err && err.quota ? '額度用完' : err && (err.status === 401 || err.status === 403) ? '金鑰失效' : '暫時不能用';
  try { if (ctx.notifier && ctx.notifier.warn) ctx.notifier.warn(`${from.map(labelOf).join('、')} ${why}，已自動改用 ${labelOf(to)}`, String((err && err.message) || '').slice(0, 300)); } catch { /* ignore */ }
}
/** 單次文字生成（日記、新聞摘要、個性整理等不需工具的場合） */
async function simple(ctx, prompt, system = '你是簡潔、準確的助理，使用繁體中文。') {
  const r = await generate(ctx, { system, messages: [{ role: 'user', text: prompt }], tools: [] }); return r.text;
}
function hasKey(S) { return hasKeyFor(S, S.get('model.provider')); }

// ---------------- 連線測試與模型清單（不動金鑰池） ----------------
/** 用「這一把」金鑰直接試一次（儲存前測試用）；不寫入設定、不輪換 */
async function probe(ctx, { provider, model, key, base_url }) {
  if (!isProvider(provider)) throw new LLMError('不支援的供應商', 0, false);
  const S = ctx.settings; const P = PROVIDERS[provider]; const label = P.label.split(' ')[0]; const mdl = model || modelFor(S, provider);
  if (!key) throw new LLMError('沒有可測試的金鑰', 0, false);
  if (!mdl) throw new LLMError('請先填模型名稱', 0, false);
  const ask = '請只回覆「OK」。';
  if (P.kind === 'gemini') { const j = await post(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(mdl)}:generateContent`, { 'x-goog-api-key': key }, { contents: [{ role: 'user', parts: [{ text: ask }] }], generationConfig: { maxOutputTokens: 64 } }, label, true); const p = (((j.candidates || [])[0] || {}).content || {}).parts || []; return { ok: true, provider, model: mdl, text: p.map((x) => x.text || '').join('').trim() }; }
  if (P.kind === 'anthropic') { const j = await post('https://api.anthropic.com/v1/messages', { 'x-api-key': key, 'anthropic-version': '2023-06-01' }, { model: mdl, max_tokens: 32, messages: [{ role: 'user', content: ask }] }, label, true); return { ok: true, provider, model: mdl, text: (j.content || []).map((b) => b.text || '').join('').trim() }; }
  const j = await post(baseUrlOf(S, provider, { base_url }) + '/chat/completions', { authorization: `Bearer ${key}` }, { model: mdl, messages: [{ role: 'user', content: ask }], [P.tokenParam]: 64 }, label, true);
  const m = (((j.choices || [])[0]) || {}).message || {}; return { ok: true, provider, model: mdl, text: String(m.content || '').trim() };
}
const NOT_CHAT = { openai: /embed|tts|whisper|transcribe|realtime|audio|image|moderation|search|davinci|babbage|dall-e|sora/i, nvidia: /embed|rerank|retriev|guard|reward|clip|parse|safety|bge|arctic|paraphrase|ocr|nemoguard|vila-|riva|cosmos|fuyu-kosmos/i, groq: /whisper|tts|guard|playai|orpheus|distil-whisper/i, custom: /embed|rerank|whisper|tts/i };
/** 向供應商查「這把金鑰實際能用的模型」。回傳 [{id}]（已濾掉嵌入、語音、審查等非聊天模型） */
async function listModels(ctx, { provider, key, base_url }) {
  if (!isProvider(provider)) throw new LLMError('不支援的供應商', 0, false);
  const S = ctx.settings; const P = PROVIDERS[provider];
  if (!key) { const c = keyCandidates(S, provider).find(usable); key = c && c.key; if (!base_url && c) base_url = c.base_url; }
  if (!key) throw new LLMError(`還沒設定 ${P.label} 的 API Key，無法查模型清單。`, 0, false);
  const get = async (url, headers) => {
    let r; try { r = await fetchJson(url, { headers }, 20000); } catch (e) { throw new LLMError(`連不上 ${P.label}：${e.name === 'AbortError' ? '逾時' : e.message}`, 0, true); }
    if (!r.ok) throw new LLMError(friendly(r.status, r.json, P.label.split(' ')[0]), r.status, false);
    return r.json || {};
  };
  let ids = [];
  if (P.kind === 'gemini') { const j = await get('https://generativelanguage.googleapis.com/v1beta/models?pageSize=200', { 'x-goog-api-key': key }); ids = (j.models || []).filter((m) => (m.supportedGenerationMethods || []).includes('generateContent')).map((m) => String(m.name).replace(/^models\//, '')).filter((x) => !/embed|aqa|imagen|veo|tts|live/i.test(x)); }
  else if (P.kind === 'anthropic') { const j = await get('https://api.anthropic.com/v1/models?limit=100', { 'x-api-key': key, 'anthropic-version': '2023-06-01' }); ids = (j.data || []).map((m) => m.id); }
  else { const j = await get(baseUrlOf(S, provider, { base_url }) + '/models', { authorization: `Bearer ${key}` }); ids = (j.data || []).map((m) => m.id).filter(Boolean).filter((x) => !(NOT_CHAT[provider] || NOT_CHAT.custom).test(x)); if (provider === 'openai') ids = ids.filter((x) => /^(gpt-|o\d|chatgpt)/i.test(x)); }
  return { provider, models: [...new Set(ids)].sort().map((id) => ({ id, vision: supportsVision(provider, id) })) };
}
/** 給前端：供應商清單（不含任何金鑰） */
function providerList(S) {
  return providerIds().map((id) => ({ id, label: PROVIDERS[id].label, kind: PROVIDERS[id].kind, default_model: PROVIDERS[id].defaultModel, base_url: PROVIDERS[id].baseUrl || '', key_url: PROVIDERS[id].keyUrl || '', has_key: hasKeyFor(S, id) }));
}

/** 診斷：目前所有工具在某供應商下的轉換結果（給 App 的「工具相容性檢查」） */
function schemaReport(ctx, provider, tools) {
  const prep = prepTools(ctx, provider, tools); const quarantined = [...QUAR.entries()].filter(([k, v]) => k.startsWith(provider + ':') && Date.now() - v.at < QUAR_MS).map(([, v]) => ({ tool: v.tool, reason: v.reason, at: v.at }));
  return { provider, sent: prep.decls.length, skipped: prep.skipped, quarantined };
}
const clearQuarantine = () => QUAR.clear();
module.exports = { providerOrder, quotaKind, isRateLimit, retryAfterOf, hasNext, thinkingCfg, schemaReport, clearQuarantine, prepTools, generate, simple, hasKey, hasKeyFor, keyCandidates, withKeyRotation, post, LLMError, toGemini, toAnthropic, toOpenAI, usable, PROVIDERS, providerList, modelFor, probe, listModels, supportsVision, isProvider };
