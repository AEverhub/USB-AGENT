#!/data/data/com.termux/files/usr/bin/bash
# Agent中控中心 × Termux 一鍵安裝：Linux 工具、Chromium、橋接程式；完成後自動向 App 註冊（不用複製貼上）。
# 可重複執行（升級／修復）。要在 Termux（從 F-Droid 或 GitHub 安裝，不是 Google Play 舊版）裡執行。
set -e
APP_URL="__APP_URL__"
APP_TOKEN="__APP_TOKEN__"
PORT="${BRIDGE_PORT:-8766}"
BH="$HOME/.agent-bridge"

say() { printf '\n\033[1;36m[%s]\033[0m %s\n' "$1" "$2"; }
auth=(-H "authorization: Bearer $APP_TOKEN")

say 1/6 "更新套件清單"
pkg update -y || true
say 2/6 "安裝 Node、Python、Git、curl 等工具"
pkg install -y nodejs-lts python git curl procps termux-tools openssl-tool tmux termux-api openssh zip unzip || pkg install -y nodejs python git curl procps termux-tools tmux
say 3/6 "安裝 Chromium（TUR 社群套件庫；需要下載數百 MB，請連 Wi-Fi）"
pkg install -y tur-repo || echo "警告：tur-repo 安裝失敗，稍後可手動重試"
pkg install -y chromium || echo "警告：Chromium 安裝失敗。可稍後在 Termux 手動執行：pkg install -y tur-repo && pkg install -y chromium"

say 3b/6 "申請手機共用儲存空間權限（會跳出 Android 授權視窗，請按允許；略過也行）"
termux-setup-storage </dev/null >/dev/null 2>&1 || true

say 4/6 "安裝橋接程式"
mkdir -p "$BH" "$HOME/work"
curl -fsS "${auth[@]}" "$APP_URL/api/termux/bridge.js" -o "$BH/agent-bridge.js"
if [ ! -s "$BH/token" ]; then head -c 24 /dev/urandom | od -An -tx1 | tr -d ' \n' > "$BH/token"; fi
chmod 600 "$BH/token"
cat > "$BH/run-forever.sh" <<EOS
#!/data/data/com.termux/files/usr/bin/bash
# 看門狗：橋接程式若當掉，2 秒後自動重啟
cd "$BH"
while true; do BRIDGE_PORT=$PORT node "$BH/agent-bridge.js" >> "$BH/bridge.log" 2>&1; sleep 2; done
EOS
cat > "$BH/start.sh" <<EOS
#!/data/data/com.termux/files/usr/bin/bash
termux-wake-lock 2>/dev/null || true
pkill -f "$BH/run-forever.sh" 2>/dev/null || true
pkill -f "$BH/agent-bridge.js" 2>/dev/null || true
nohup bash "$BH/run-forever.sh" >/dev/null 2>&1 &
EOS
chmod +x "$BH/start.sh" "$BH/run-forever.sh"

say 5/6 "設定開機自動啟動（需另外安裝 Termux:Boot；沒有也沒關係，每次開 Termux 執行 ~/.agent-bridge/start.sh）"
mkdir -p "$HOME/.termux/boot"
printf '#!/data/data/com.termux/files/usr/bin/bash\n%s/start.sh\n' "$BH" > "$HOME/.termux/boot/agent-bridge.sh"; chmod +x "$HOME/.termux/boot/agent-bridge.sh"
"$BH/start.sh"
sleep 2

say 6/6 "向 App 註冊"
TOKEN="$(cat "$BH/token")"
curl -fsS "${auth[@]}" -H 'content-type: application/json' -X POST "$APP_URL/api/termux/register" -d "{\"url\":\"http://127.0.0.1:$PORT\",\"token\":\"$TOKEN\"}" && echo
curl -fsS -H "authorization: Bearer $TOKEN" "http://127.0.0.1:$PORT/health" && echo
printf '\n\033[1;32m完成！\033[0m 回到 App →「瀏覽器」頁 →「Termux 環境」，按「測試連線」。\n'
printf '建議：Android 設定 → 電池 → 把 Termux 設為「不受限制」，否則切到背景會被系統殺掉。\n'
