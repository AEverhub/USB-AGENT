#!/usr/bin/env node
'use strict';
/**
 * Agent 橋接程式（跑在 Termux 裡，沒有任何外部依賴，Node ≥ 18）
 * 讓 Agent中控中心的 AI 能用「完整的 Linux 環境」與「真正的 Chromium」：
 *   GET  /health                健康檢查
 *   POST /exec                  {cmd, cwd?, timeout_s?, background?, full?}  執行指令（bash -c）；background 立即回傳 job id
 *   GET  /jobs · GET /jobs/log?id=&tail= · POST /jobs/kill {id}   背景工作（長時間任務，App 重啟也不會中斷）
 *   POST /chromium/start        {port?, headless?, width?, height?, proxy?}  啟動 Chromium（CDP，只綁 127.0.0.1）
 *   POST /chromium/stop | GET /chromium/status
 *   GET  /file/get?path=        讀檔（base64）          ┐ 預設只限 HOME 底下；full=1（完整權限模式，由 App 依
 *   POST /file/put              {path, b64, full?} 寫檔  ┘ 設定帶入）可存取 Termux 使用者能碰到的所有路徑；單檔 ≤ 25MB
 * 安全：只綁 127.0.0.1；每個請求都要 Bearer token（~/.agent-bridge/token）；檢查 Host／拒絕帶 Origin 的瀏覽器請求（防 DNS rebinding／CSRF）。
 * 環境變數：BRIDGE_PORT(8766)、BRIDGE_HOME、BRIDGE_TOKEN、CHROMIUM_BIN、BRIDGE_ALLOW_ANY_HOST=1（要從別台機器連才開）、BRIDGE_BIND。
 */
const http = require('http');
const fs = require('fs');
const os = require('os');
const path = require('path');
const crypto = require('crypto');
const { spawn } = require('child_process');

const VERSION = '1.0.0';
const PORT = +process.env.BRIDGE_PORT || 8766;   // 8765 是 App 自己的控制 API，不能撞
const BIND = process.env.BRIDGE_BIND || '127.0.0.1';
const HOME = fs.realpathSync(process.env.HOME || os.homedir());
const BH = process.env.BRIDGE_HOME || path.join(HOME, '.agent-bridge');
fs.mkdirSync(BH, { recursive: true });
const TOKEN = process.env.BRIDGE_TOKEN || (() => { try { return fs.readFileSync(path.join(BH, 'token'), 'utf8').trim(); } catch { return ''; } })();
if (TOKEN.length < 16) { console.error('找不到 token（~/.agent-bridge/token）。請先執行 setup.sh。'); process.exit(1); }
const MAX_FILE = 25 * 1024 * 1024;
const MAX_OUT = 1 << 20;

const safeEq = (a, b) => { const x = Buffer.from(String(a)), y = Buffer.from(String(b)); return x.length === y.length && crypto.timingSafeEqual(x, y); };
function which(cmd) {
  if (!cmd) return ''; if (path.isAbsolute(cmd)) return fs.existsSync(cmd) ? cmd : '';
  for (const d of String(process.env.PATH || '').split(path.delimiter)) { const p = path.join(d, cmd); try { if (fs.statSync(p).isFile()) return p; } catch { /* next */ } } return '';
}
/** 路徑必須在 HOME 底下（解開符號連結後再檢查，防止用 symlink 逃出去） */
function inHome(p, fullAccess) {
  const full = path.resolve(HOME, String(p || '.')); if (fullAccess) return full; let probe = full; const rest = [];
  while (!fs.existsSync(probe)) { rest.unshift(path.basename(probe)); const up = path.dirname(probe); if (up === probe) break; probe = up; }
  const real = path.join(fs.realpathSync(probe), ...rest);
  if (real !== HOME && !real.startsWith(HOME + path.sep)) throw Object.assign(new Error('只能存取 HOME 底下的路徑：' + HOME), { status: 403 });
  return real;
}
const tail = (buf, n) => (buf.length > n ? buf.subarray(buf.length - n) : buf);

function run(cmd, { cwd, timeoutMs }) {
  return new Promise((resolve) => {
    const t0 = Date.now(); const sh = which('bash') || which('sh') || '/bin/sh'; let out = Buffer.alloc(0); let timedOut = false; let done = false;
    const p = spawn(sh, ['-c', cmd], { cwd, env: process.env, stdio: ['ignore', 'pipe', 'pipe'], detached: true });
    const add = (d) => { out = Buffer.concat([out, d]); if (out.length > MAX_OUT * 2) out = tail(out, MAX_OUT); };
    p.stdout.on('data', add); p.stderr.on('data', add);
    const finish = (code, signal) => { if (done) return; done = true; clearTimeout(timer); resolve({ code, signal, timedOut, ms: Date.now() - t0, out: tail(out, MAX_OUT).toString('utf8') }); };
    const timer = setTimeout(() => { timedOut = true; try { process.kill(-p.pid, 'SIGKILL'); } catch { try { p.kill('SIGKILL'); } catch { /* ignore */ } } }, timeoutMs);
    p.on('error', (e) => { add(Buffer.from('無法執行：' + e.message)); finish(-1, null); });
    // 用 exit 而不是 close：指令若把背景程式的輸出管線留著（cmd &），close 會一直等不到
    p.on('exit', (code, signal) => setTimeout(() => finish(code, signal), 250));
  });
}

// ---------- 背景工作（長時間任務：detached、輸出寫檔；橋接重啟也不影響）----------
const JOBS = path.join(BH, 'jobs'); fs.mkdirSync(JOBS, { recursive: true });
const isAlive = (pid) => { try { process.kill(pid, 0); return true; } catch { return false; } };
const jobFile = (id) => path.join(JOBS, id + '.json'); const jobLog = (id) => path.join(JOBS, id + '.log');
const jobOk = (id) => /^[0-9a-f]{8}$/.test(String(id || ''));
function jobMeta(id) { try { return JSON.parse(fs.readFileSync(jobFile(id), 'utf8')); } catch { return null; } }
function startJob(cmd, cwd) {
  const id = crypto.randomBytes(4).toString('hex'); const fd = fs.openSync(jobLog(id), 'a'); const sh = which('bash') || which('sh') || '/bin/sh';
  const p = spawn(sh, ['-c', cmd], { cwd, env: process.env, stdio: ['ignore', fd, fd], detached: true }); p.unref(); fs.closeSync(fd);
  const meta = { id, cmd: cmd.slice(0, 500), cwd, pid: p.pid, started: Date.now(), ended: 0, code: null };
  fs.writeFileSync(jobFile(id), JSON.stringify(meta)); p.on('exit', (code, signal) => { meta.ended = Date.now(); meta.code = code; meta.signal = signal; try { fs.writeFileSync(jobFile(id), JSON.stringify(meta)); } catch { /* ignore */ } });
  return meta;
}
function listJobs() {
  return fs.readdirSync(JOBS).filter((f) => f.endsWith('.json')).map((f) => jobMeta(f.slice(0, -5))).filter(Boolean).sort((a, b) => b.started - a.started).slice(0, 30).map((m) => ({ ...m, running: !m.ended && isAlive(m.pid) }));
}

// ---------- Chromium ----------
let chrome = null;   // { proc, port, pid, started, err }
const alive = () => !!chrome && (chrome.adopted ? true : chrome.proc.exitCode === null && chrome.proc.signalCode === null);
function probe(port) { return new Promise((res) => { const r = http.get({ host: '127.0.0.1', port, path: '/json/version', timeout: 1500 }, (x) => { let b = ''; x.on('data', (d) => { b += d; }); x.on('end', () => { try { res(JSON.parse(b)); } catch { res(null); } }); }); r.on('error', () => res(null)); r.on('timeout', () => { r.destroy(); res(null); }); }); }
/**
 * 啟動 Chromium（CDP）。手機上的 Chromium 跑在 PRoot 裡常見的問題：zygote 行程、crashpad 當機回報、多行程沙箱、/dev/shm。
 * 26.11.3 Revise4：依序試幾組相容參數（標準 → 不用 zygote／關 crashpad → 單一行程），成功的那組記起來下次直接用；
 * 第一次啟動在手機上可能要 30～60 秒，等待時間拉長到 75 秒。
 */
const FLAG_SETS = [
  ['--no-zygote', '--disable-breakpad', '--disable-crash-reporter'],
  ['--no-zygote', '--disable-breakpad', '--disable-crash-reporter', '--single-process', '--disable-features=VizDisplayCompositor'],
  ['--no-zygote', '--disable-breakpad', '--disable-crash-reporter', '--single-process', '--use-gl=swiftshader', '--disable-software-rasterizer', '--renderer-process-limit=1'],
];
const flagFile = () => path.join(BH, 'chromium-flags.json');
async function chromiumStart(o = {}) {
  if (alive()) { const v = await probe(chrome.port); if (v) return { ...chromiumInfo(), reused: true }; if (chrome.proc) { try { chrome.proc.kill('SIGKILL'); } catch { /* ignore */ } } else killPort(chrome.port); chrome = null; }
  // 橋接重啟過、但上一個 Chromium 還活著佔著埠 → 直接接手沿用（以前會因為埠被佔、設定檔被鎖而開不起來）
  { const port0 = +o.port || 9222; const v0 = await probe(port0); if (v0) { chrome = { proc: null, adopted: true, port: port0, pid: 0, started: Date.now(), err: '' }; return { ...chromiumInfo(), browser: v0.Browser, adopted: true }; } }
  const bin = which(process.env.CHROMIUM_BIN) || ['chromium', 'chromium-browser', 'google-chrome-stable', 'google-chrome'].map(which).find(Boolean);
  if (!bin) throw Object.assign(new Error('找不到 Chromium。內建 Linux：到「瀏覽器」頁按「加裝 Chromium」；外部 Termux：pkg install -y tur-repo && pkg install -y chromium'), { status: 424 });
  const port = +o.port || 9222; const profile = path.join(BH, 'chromium-profile'); fs.mkdirSync(profile, { recursive: true });
  let known = -1; try { known = JSON.parse(fs.readFileSync(flagFile(), 'utf8')).index; } catch { /* 第一次 */ }
  const order = known >= 0 && known < FLAG_SETS.length ? [known, ...FLAG_SETS.map((_, i) => i).filter((i) => i !== known)] : FLAG_SETS.map((_, i) => i);
  const errors = [];
  for (const idx of order) {
    for (const f of ['SingletonLock', 'SingletonCookie', 'SingletonSocket']) { try { fs.rmSync(path.join(profile, f), { force: true }); } catch { /* ignore */ } }
    const w = +o.width || 1280, h = +o.height || 800;
    const args = [`--remote-debugging-port=${port}`, '--remote-debugging-address=127.0.0.1', `--user-data-dir=${profile}`, '--no-sandbox', '--disable-gpu', '--disable-dev-shm-usage', '--no-first-run', '--no-default-browser-check',
      '--disable-features=Translate,MediaRouter', '--password-store=basic', '--disable-background-networking', '--disable-component-update', '--disable-sync', '--disk-cache-size=52428800', '--media-cache-size=10485760', `--window-size=${w},${h}`, '--lang=zh-TW', ...FLAG_SETS[idx]];
    if (o.headless !== false) args.push('--headless=new'); if (o.proxy) args.push('--proxy-server=' + String(o.proxy)); args.push(/^https?:\/\/[^\s]+$/i.test(String(o.url || '')) ? String(o.url) : 'https://www.google.com/');   // Revise6：開起來就是首頁（預設 Google）
    const proc = spawn(bin, args, { stdio: ['ignore', 'ignore', 'pipe'], env: { ...process.env, TMPDIR: process.env.TMPDIR || '/tmp' } }); const st = { proc, port, pid: proc.pid, started: Date.now(), err: '', bin, args, mode: idx };
    proc.stderr.on('data', (d) => { st.err = (st.err + d).slice(-1500); }); proc.on('error', (e) => { st.err += '\n' + e.message; }); chrome = st;
    const t0 = Date.now(); let died = false;
    while (Date.now() - t0 < 75000) {
      if (!alive()) { died = true; break; }
      const v = await probe(port); if (v) { try { fs.writeFileSync(flagFile(), JSON.stringify({ index: idx, at: Date.now() })); } catch { /* ignore */ } return { ...chromiumInfo(), browser: v.Browser, mode: idx }; }
      await new Promise((r) => setTimeout(r, 400));
    }
    try { proc.kill('SIGKILL'); } catch { /* ignore */ } chrome = null;
    errors.push(`模式 ${idx + 1}：${died ? '啟動後立刻結束' : '75 秒內沒有回應'}${st.err ? '｜' + st.err.trim().split('\n').slice(-2).join(' / ').slice(0, 220) : ''}`);
  }
  throw Object.assign(new Error('Chromium 開不起來（試了 ' + order.length + ' 種相容模式）：\n' + errors.join('\n')), { status: 500 });
}
const chromiumInfo = () => (alive() ? { running: true, port: chrome.port, pid: chrome.pid, since: chrome.started, cdp_url: `http://127.0.0.1:${chrome.port}` } : { running: false });
function killPort(port) { try { require('child_process').spawnSync('pkill', ['-f', `remote-debugging-port=${+port}`], { timeout: 5000 }); } catch { /* 沒有 pkill 就算了 */ } }
function chromiumStop() { if (alive() && chrome.adopted) { killPort(chrome.port); chrome = null; return { running: false, was_running: true }; } if (alive()) { const p = chrome.proc; try { p.kill('SIGTERM'); } catch { /* ignore */ } setTimeout(() => { try { p.kill('SIGKILL'); } catch { /* ignore */ } }, 3000).unref(); } const was = alive(); chrome = null; return { running: false, was_running: !!was }; }

// ---------- HTTP ----------
const readBody = (req, max) => new Promise((resolve, reject) => { const c = []; let n = 0; req.on('data', (d) => { n += d.length; if (n > max) { reject(Object.assign(new Error('內容太大'), { status: 413 })); req.destroy(); } else c.push(d); }); req.on('end', () => resolve(Buffer.concat(c))); req.on('error', reject); });
const send = (res, code, obj) => { const b = Buffer.from(JSON.stringify(obj)); res.writeHead(code, { 'content-type': 'application/json; charset=utf-8', 'content-length': b.length, 'cache-control': 'no-store' }); res.end(b); };

const server = http.createServer(async (req, res) => {
  try {
    if (req.headers.origin) return send(res, 403, { error: '不接受瀏覽器跨來源請求' });
    if (process.env.BRIDGE_ALLOW_ANY_HOST !== '1' && !/^(127\.0\.0\.1|localhost|\[::1\])(:\d+)?$/i.test(req.headers.host || '')) return send(res, 403, { error: 'Host 不允許' });
    const tok = (req.headers.authorization || '').replace(/^Bearer\s+/i, ''); if (!safeEq(tok, TOKEN)) return send(res, 401, { error: '未授權' });
    const url = new URL(req.url, 'http://x'); const p = url.pathname; const body = async (max = 1 << 20) => { const b = await readBody(req, max); if (!b.length) return {}; try { return JSON.parse(b.toString('utf8')); } catch { throw Object.assign(new Error('JSON 格式錯誤'), { status: 400 }); } };
    if (req.method === 'GET' && p === '/health') return send(res, 200, { ok: true, version: VERSION, node: process.version, arch: process.arch, platform: process.platform, home: HOME, prefix: process.env.PREFIX || '', chromium: { installed: !!(which(process.env.CHROMIUM_BIN) || ['chromium', 'chromium-browser', 'google-chrome-stable', 'google-chrome'].map(which).find(Boolean)), ...chromiumInfo() }, tools: Object.fromEntries(['python3', 'git', 'curl', 'node', 'pip'].map((t) => [t, !!which(t)])) });
    if (req.method === 'POST' && p === '/exec') {
      const b = await body(); if (!b.cmd || typeof b.cmd !== 'string') throw Object.assign(new Error('缺少 cmd'), { status: 400 });
      const full = b.full === true; const cwd = b.cwd ? inHome(b.cwd, full) : (() => { const d = path.join(HOME, 'work'); fs.mkdirSync(d, { recursive: true }); return d; })();
      if (b.cwd && !fs.existsSync(cwd)) throw Object.assign(new Error('工作目錄不存在：' + cwd), { status: 404 });
      if (b.background === true) return send(res, 200, startJob(b.cmd, cwd));
      return send(res, 200, await run(b.cmd, { cwd, timeoutMs: Math.min(full ? 21600 : 1800, Math.max(1, +b.timeout_s || 120)) * 1000 }));
    }
    if (req.method === 'GET' && p === '/jobs') return send(res, 200, { jobs: listJobs() });
    if (req.method === 'GET' && p === '/jobs/log') { const id = url.searchParams.get('id'); if (!jobOk(id) || !fs.existsSync(jobLog(id))) throw Object.assign(new Error('找不到這個工作'), { status: 404 }); const buf = fs.readFileSync(jobLog(id)); const n = Math.min(MAX_OUT, Math.max(100, +url.searchParams.get('tail') || 4000)); const m = jobMeta(id) || {}; return send(res, 200, { id, running: !m.ended && isAlive(m.pid), code: m.code, size: buf.length, out: tail(buf, n).toString('utf8') }); }
    if (req.method === 'POST' && p === '/jobs/kill') { const b = await body(); const m = jobOk(b.id) && jobMeta(b.id); if (!m) throw Object.assign(new Error('找不到這個工作'), { status: 404 }); let killed = false; try { process.kill(-m.pid, 'SIGKILL'); killed = true; } catch { try { process.kill(m.pid, 'SIGKILL'); killed = true; } catch { /* 已結束 */ } } return send(res, 200, { id: b.id, killed }); }
    if (req.method === 'POST' && p === '/chromium/start') return send(res, 200, await chromiumStart(await body()));
    if (req.method === 'POST' && p === '/chromium/stop') return send(res, 200, chromiumStop());
    if (req.method === 'GET' && p === '/chromium/status') return send(res, 200, chromiumInfo());
    if (req.method === 'GET' && p === '/file/get') { const f = inHome(url.searchParams.get('path'), url.searchParams.get('full') === '1'); const st = fs.statSync(f); if (st.isDirectory()) throw Object.assign(new Error('這是資料夾'), { status: 400 }); if (st.size > MAX_FILE) throw Object.assign(new Error('檔案超過 25MB'), { status: 413 }); return send(res, 200, { name: path.basename(f), size: st.size, b64: fs.readFileSync(f).toString('base64') }); }
    if (req.method === 'POST' && p === '/file/put') { const b = await body(MAX_FILE * 1.4 + 4096); if (!b.path || typeof b.b64 !== 'string') throw Object.assign(new Error('缺少 path／b64'), { status: 400 }); const buf = Buffer.from(b.b64, 'base64'); if (buf.length > MAX_FILE) throw Object.assign(new Error('檔案超過 25MB'), { status: 413 }); const f = inHome(b.path, b.full === true); fs.mkdirSync(path.dirname(f), { recursive: true }); fs.writeFileSync(f, buf); return send(res, 200, { path: f, size: buf.length }); }
    return send(res, 404, { error: '沒有這個端點' });
  } catch (e) { if (!res.headersSent) send(res, e.status || (e.code === 'ENOENT' ? 404 : 500), { error: e.code === 'ENOENT' ? '找不到檔案或資料夾' : e.message }); }
});
server.listen(PORT, BIND, () => console.log(`agent-bridge ${VERSION} 已啟動 http://${BIND}:${PORT}（HOME=${HOME}）`));
const bye = () => { try { chromiumStop(); } catch { /* ignore */ } server.close(); setTimeout(() => process.exit(0), 500).unref(); };
process.on('SIGINT', bye); process.on('SIGTERM', bye);
