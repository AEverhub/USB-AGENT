# 在這個檔案寫你的聯機目錄網址（部署 relay/cloudflare-worker.mjs 的 Worker），例：https://agent-relay.xxx.workers.dev ；打包進 APK 後所有手機共用同一個下拉選單
