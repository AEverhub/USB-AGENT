# 資安知識庫（防禦導向）

本庫供 AI 擔任資安顧問時引用。定位是**防禦**：找出並修補自己（或已獲授權）系統的弱點、做威脅建模、給強化建議。**不產生攻擊程式、exploit、惡意程式、入侵步驟**；不協助攻擊第三方。

## OWASP Web 應用十大風險（2021）
1. 存取控制失效（Broken Access Control）：使用者能做不該做的事（改 id 看別人資料＝IDOR、越權操作）。對策：預設拒絕、伺服器端每次請求都查授權、物件層級授權、拒絕目錄列出。
2. 加密失效（Cryptographic Failures）：機敏資料沒加密或用弱演算法。對策：傳輸 TLS、靜態加密、密碼用 argon2／bcrypt、不自製加密。
3. 注入（Injection）：SQL／NoSQL／OS 指令／LDAP 注入、XSS。對策：參數化查詢、ORM、輸入驗證、輸出跳脫。
4. 不安全設計（Insecure Design）：設計階段就缺防護。對策：威脅建模、安全需求、濫用案例、分層防禦。
5. 安全設定錯誤（Security Misconfiguration）：預設帳密、開著 debug、冗餘功能、錯誤訊息外洩。對策：最小化、硬化範本、關 debug、安全標頭。
6. 易受攻擊與過時元件（Vulnerable Components）：有已知 CVE 的套件。對策：盤點相依、鎖版本、SCA 掃描、及時更新。
7. 認證與識別失效（Identification and Authentication Failures）：弱密碼、暴力破解、session 固定。對策：MFA、擋常見密碼、登入速率限制、安全 session。
8. 軟體與資料完整性失效（Software and Data Integrity Failures）：不安全反序列化、CI/CD 供應鏈被植入。對策：簽章驗證、可信來源、安全反序列化。
9. 日誌與監控失效（Logging and Monitoring Failures）：事件沒記、沒告警。對策：集中日誌（不含祕密）、告警、保留、可追溯。
10. 伺服器端請求偽造（SSRF）：讓伺服器去連攻擊者指定的位址。對策：網域白名單、擋內網與雲端 metadata（169.254.169.254）、禁危險跳轉。

## API 安全常見問題
- 物件層級授權失效（BOLA/IDOR）：最常見。每個資源存取都要驗「這個人能不能動這個物件」。
- 認證失效、過度資料暴露（回傳整個物件含敏感欄位）、缺速率限制、函式層級授權失效、大量指派（Mass Assignment）。
- 對策：最小回傳欄位、輸出白名單、每個端點驗授權、速率限制、API Gateway、版本與棄用管理。

## 注入與輸出（修法樣式）
- SQL：用參數化查詢（`?`、`:name`、`$1`），值用綁定不要字串相加；ORM 也要用參數化介面，別手拼。
- OS 指令：避免經過 shell；用參數陣列（`execFile`、`spawn(cmd,[args])`、`subprocess.run([...], shell=False)`）。
- XSS：輸出用 `textContent`／框架自動跳脫；要放 HTML 先用 DOMPurify；加 CSP 當第二道防線。避免 `innerHTML`、`dangerouslySetInnerHTML`、`v-html` 直接接資料。
- 路徑穿越：`path.basename` 去目錄，或 `resolve` 後檢查 `startsWith(允許根目錄)`；最好白名單。
- 反序列化：yaml 用 `safe_load`，跨程序用 JSON，避免 `pickle`／`unserialize` 不信任資料。

## 認證與授權
- 密碼：argon2id（首選）或 bcrypt／scrypt，加鹽、設工作因子；擋已外洩密碼清單；長度優先於複雜度。
- Session：安全隨機 id、Cookie 設 `HttpOnly`＋`Secure`＋`SameSite`；登入後換新 id（防固定）；閒置與絕對逾時。
- JWT：指定 `algorithms`（如 `["RS256"]`）、拒絕 `alg:none`；密鑰夠長且不寫死；短效期＋可撤銷（黑名單／短 access＋refresh）。
- 授權：伺服器端集中判斷、預設拒絕、最小權限、角色＋物件層級雙重檢查。
- MFA：重要帳號強制（TOTP／passkey）；重要操作要求重新驗證。

## 密碼學原則
- 不自製加密；用成熟函式庫。對稱加密用帶驗證的模式（AES-GCM／ChaCha20-Poly1305），不要 ECB。
- 雜湊：一般完整性用 SHA-256 以上；密碼用專用慢雜湊（argon2／bcrypt），不要 MD5／SHA-1。
- 亂數：安全來源（`crypto.randomBytes`、`getRandomValues`、Python `secrets`、Java `SecureRandom`），不要 `Math.random`／一般 `random` 做 token。
- 金鑰：用 KMS／Vault 保管、定期輪替、分環境、不入版控、最小權限。
- TLS：1.2 以上、停用弱套件、永遠驗證憑證；自簽就加 CA，不要關驗證。

## 祕密管理
- 祕密（金鑰、密碼、token）：放環境變數或 Secret Manager／Vault；`.env` 進 `.gitignore`；前端不放任何長期祕密。
- 掃描：用 git-secrets／trufflehog／gitleaks 擋提交與掃歷史。
- 外洩處理：立刻輪替與撤銷、查存取紀錄、評估影響範圍。

## 伺服器與雲端硬化
- SSH：金鑰登入、禁密碼、禁 root 直登、限制來源 IP、搭配 fail2ban。
- 防火牆：預設拒絕，只開必要埠；最小化對外曝露面。
- 更新：自動安全更新、定期弱點掃描、追 CVE。
- 容器：非 root 跑、唯讀檔案系統、最小映像、掃描映像、不掛敏感主機路徑。
- 雲端：IAM 最小權限、關閉公開儲存桶、開啟稽核日誌與異常告警、靜態加密。

## 行動 App（Android）安全
- 不把金鑰／密碼寫死在 App（可反編譯取出）；要存機密用 Keystore／EncryptedSharedPreferences。
- 網路全程 HTTPS、用 network-security-config，必要時憑證綁定（pinning）。
- 元件（Activity／Service／Provider／Receiver）最小化 `exported`，加權限保護。
- WebView：關掉不需要的 JS 介面（`addJavascriptInterface`）、只載信任來源、不開 `allowFileAccess` 等危險設定。
- 上架前做反編譯檢視、相依掃描、移除除錯與測試後門。

## 威脅建模（STRIDE）
對每個資料流與信任邊界問六類威脅：
- Spoofing 假冒 → 身分驗證
- Tampering 竄改 → 完整性（簽章、雜湊、權限）
- Repudiation 否認 → 稽核日誌
- Information Disclosure 洩漏 → 加密、最小化
- Denial of Service 阻斷 → 速率限制、資源配額
- Elevation of Privilege 提權 → 授權、最小權限
流程：畫資料流圖→標信任邊界→逐項套 STRIDE→列風險與對策→排優先序。

## 紅隊／綠隊的分工（本助理只做防禦面）
- 紅隊（攻擊視角）：在**檢查清單**層次列出「攻擊者會盯哪裡、會嘗試什麼類型的手法」，用來驗證系統擋不擋得住。本助理只給「要檢查什麼」，不給可執行的攻擊程式或入侵步驟。
- 綠隊／藍隊（防禦視角）：針對每個弱點給具體強化與修補。
- 滲透測試：只對自己擁有、或拿到書面授權的系統進行；範圍、時間、聯絡人要先談定（Rules of Engagement）。

## 事件應變（IR）基本流程
準備→偵測與分析→圍堵→根除→復原→事後檢討。重點：有離線備份並定期演練還原、有通報流程、外洩時快速輪替金鑰與撤銷存取、保留證據與時間軸。

## 相依套件與供應鏈
- 盤點相依、鎖版本（lockfile）、來源可信。
- 定期 `npm audit`／`pip-audit`／SCA 掃描；啟用自動更新告警（如 Dependabot）。
- 警覺 typosquatting（名字相近的惡意套件）、審核新引入的套件。

## 安全標頭與前端
- `Content-Security-Policy`（擋 XSS 的主力）、`Strict-Transport-Security`、`X-Content-Type-Options: nosniff`、`X-Frame-Options`／`frame-ancestors`（擋點擊劫持）、`Referrer-Policy`。
- CSRF：用 token 或 `SameSite` cookie；改狀態的請求不走 GET。
- CORS：明確列允許來源，帶 cookie 時絕不用 `*`。

## 本助理的界線
- 可以：審自己的程式／設定找弱點並修、威脅建模、給強化建議、解釋漏洞原理與防法、查知識庫、做防禦性檢查清單。
- 不可以：寫或給可執行的攻擊程式、exploit、惡意程式、繞過他人系統、攻擊第三方、產生釣魚或假冒內容。遇到這類要求，改成提供對應的「如何防禦」。
