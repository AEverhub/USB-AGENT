'use strict';
/* F 開發者設置頁：/claim 密碼、Webhook 伺服器、政策、守護進程與背景工人、遠端除錯、日誌、向量記憶、備份與還原 */
(function () {
  const { esc, $ } = LA; let tab = 'cfg';
  LA.devTab = (t) => { tab = t; LA.go('dev'); };   // 其他地方可以直接打開某個分頁（例如 聯機）
  const POLICY = [
    { key: 'policy.approve_downloads', label: '下載類操作需管理員審批', type: 'toggle' }, { key: 'policy.approve_new_users', label: '新用戶需管理員審核', type: 'toggle' },
    { key: 'policy.ai_fs_scope', label: 'AI 檔案權限範圍', type: 'select', options: [['app', 'app：整個 App 沙盒（含 AI 自己的程式，可刪自己）'], ['workspace', 'workspace：只有工作區']] },
    { key: 'policy.ai_can_edit_rules', label: 'AI 可編寫系統規則', type: 'toggle' }, { key: 'policy.ai_can_manage_app', label: 'AI 可操作 App 設定與功能', type: 'toggle' }, { key: 'policy.ai_shell', label: 'AI 可使用終端機', type: 'toggle' },
    { key: 'policy.snapshot_before_destructive', label: '刪除／覆蓋前自動快照', type: 'toggle' }, { key: 'policy.group_trigger', label: '群組觸發方式', type: 'select', options: [['mention', '被提及／回覆／叫名字才回'], ['all', '群組每句都回（不建議）']] }, { key: 'policy.group_followup_s', label: '群組「接著說」不用 @ 的時間（秒，0＝每句都要 @ 或叫名字）', type: 'number' }, { key: 'policy.bot_reply', label: '其他機器人 @AI 時', type: 'select', options: [['mention', '回它（直接 @ 或回覆 AI 的訊息才回）'], ['off', '不理其他機器人']] }, { key: 'policy.bot_max_turns', label: '10 分鐘內最多回機器人幾次（防兩個機器人無限互聊；測試時可調高）', type: 'number' }, { key: 'memory.group_keep_h', label: '群組訊息保留幾小時（過時刪除；重要的先存進向量記憶）', type: 'number' }, { key: 'memory.group_drop_junk', label: '群組裡的廢話（hi、哈哈、ok、貼圖）不存', type: 'toggle' },
    { key: 'policy.reply_in_quiet', label: '夜間限制的回覆語' }, { key: 'bot.enabled', label: 'Bot 對一般用戶開放（關閉＝維護模式，只有管理員能用）', type: 'toggle' }, { key: 'extra_prompt', label: '附加系統提示詞', type: 'textarea' } ];
  const NET = [{ key: 'dev.hook_port', label: 'Webhook 伺服器埠', type: 'number', hint: '內網穿透指向這個埠；只開放 /hook/line 與 /health' }, { key: 'dev.hook_bind', label: 'Webhook 綁定位址', hint: '127.0.0.1（預設，只給穿透用）或 0.0.0.0（區網直連）' },
    { key: 'supervisor.enabled', label: '守護進程（自動重啟不健康的服務）', type: 'toggle' }, { key: 'supervisor.health_interval_s', label: '健康檢查間隔（秒）', type: 'number' }, { key: 'supervisor.max_restarts', label: '視窗內最大重啟次數', type: 'number' },
    { key: 'vector.enabled', label: '向量記憶', type: 'toggle' }, { key: 'vector.backend', label: '嵌入來源', type: 'select', options: [['auto', '自動（有 Gemini 金鑰用雲端，否則本地）'], ['gemini', '只用 Gemini'], ['hash', '只用本地（離線）']] }];

  LA.register('dev', { name: '開發者', title: 'F 開發者', async render(main) {
    main.innerHTML = `<div class="seg"><button data-t="cfg">設置</button><button data-t="sup">守護</button><button data-t="net">聯機</button><button data-t="srv">伺服器</button><button data-t="dbg">除錯</button><button data-t="log">日誌</button><button data-t="mem">資料</button></div><div class="row dev-log"><button class="btn sm" id="dl-log-top">${LA.icon('download', 'sm')} 下載運行記錄</button><span class="mute small grow">執行記錄＋錯誤記錄＋日誌（金鑰已遮蔽），回報問題時附上</span></div><div id="d-body"></div>`;
    $('#dl-log-top').onclick = LA.guard(downloadLog);
    LA.$$('.seg button', main).forEach((b) => { b.classList.toggle('on', b.dataset.t === tab); b.onclick = () => { tab = b.dataset.t; LA.go('dev'); }; });
    await ({ cfg, sup, dbg, log, mem, net: (b) => LA.renderLink(b), srv: (b) => LA.renderDeploy(b) }[tab])($('#d-body'));
  } });

  // 26.11.3 pro10：運行記錄下載
  async function downloadLog() { const r = await LA.api('/api/debug/logs/export'); await LA.saveBlob(new Blob([r.text], { type: 'text/plain;charset=utf-8' }), r.name); LA.toast(`已下載 ${r.name}（錯誤 ${r.errors} 筆、執行 ${r.traces} 次、日誌 ${r.lines} 行）`); }
  async function cfg(b) {
    const { settings } = await LA.api('/api/settings'); const claim = settings.dev.claim_password;
    b.innerHTML = `<div class="card"><h3>🔑 /claim 密碼</h3><div class="hint">第一次在 LINE／Discord／Telegram 私訊 bot「/claim 密碼」即成為管理員（只有在還沒有管理員時有效）。<b>AI 無法讀取或修改這個密碼。</b></div><input type="password" id="claim" placeholder="${claim ? '已設定（輸入新密碼可更換）' : '尚未設定，請輸入'}" autocomplete="new-password"><button class="btn pri" id="claim-save" style="margin-top:8px">儲存密碼</button></div>
      <div class="card" data-sec="policy"><h3>🛡️ 權限與政策</h3>${POLICY.map((f) => LA.fieldHTML(f, settings)).join('')}<button class="btn pri" data-save="policy" style="margin-top:10px">儲存</button></div>
      <div class="card" data-sec="net"><h3>⚙️ 伺服器・守護・向量</h3>${NET.map((f) => LA.fieldHTML(f, settings)).join('')}<button class="btn pri" data-save="net" style="margin-top:10px">儲存</button></div>
      <div class="card"><h3>🧩 任意設定（進階）</h3><label class="f">設定路徑</label><input id="kv-k" placeholder="例如 model.max_tokens"><label class="f">值（JSON 或文字）</label><textarea id="kv-v" style="min-height:60px"></textarea><button class="btn" id="kv-go" style="margin-top:8px">寫入</button></div>
      <details class="card"><summary>目前所有設定（機密已遮蔽）</summary><pre class="mono" style="white-space:pre-wrap">${esc(JSON.stringify(settings, null, 1))}</pre></details>
      <div class="card"><h3>⚠️ 危險區</h3><div class="row"><button class="btn bad" id="restart-proc">重啟整個後台行程</button>${window.AndroidBridge ? '<button class="btn" id="reset-be">重設 AI 程式（從 APK 還原）</button><button class="btn" id="batt">電池優化白名單</button>' : ''}</div><div class="hint">後台由 Android 前景服務自動拉起。若 AI 把自己的程式刪了：App 啟動頁的「重設 AI 程式」可從 APK 內建版本還原（資料不受影響）。</div></div>`;
    b.onclick = LA.guard(async (e) => {
      if (e.target.id === 'claim-save') { const v = $('#claim').value; if (v.length < 8) throw new Error('密碼至少 8 個字元'); await LA.post('/api/settings', { key: 'dev.claim_password', value: v }); $('#claim').value = ''; LA.toast('已儲存'); }
      const s = e.target.closest('[data-save]'); if (s) { await LA.post('/api/settings', { items: LA.collect($(`[data-sec="${s.dataset.save}"]`)) }); LA.toast('已儲存'); }
      if (e.target.id === 'kv-go') { const k = $('#kv-k').value.trim(); let v = $('#kv-v').value; try { v = JSON.parse(v); } catch { /* 當字串 */ } await LA.post('/api/settings', { key: k, value: v }); LA.toast('已寫入 ' + k); }
      if (e.target.id === 'reset-be' && await LA.confirm('用 APK 內建版本覆蓋 AI 程式並重啟？（資料、記憶、設定不受影響；AI 自己改過的程式會被還原）')) AndroidBridge.resetBackend();
      if (e.target.id === 'batt') AndroidBridge.requestBatteryExemption();
      if (e.target.id === 'restart-proc' && await LA.confirm('重啟後台行程？（約 3–5 秒）')) { await LA.post('/api/process/restart'); LA.toast('重啟中…'); }
    });
  }

  async function sup(b) {
    const s = await LA.api('/api/supervisor');
    b.innerHTML = `<div class="card"><h3>🛠️ 守護進程 <small>事件迴圈延遲 ${s.lag_ms}ms</small></h3><div class="list">${s.services.map((x) => `<div class="row"><span class="grow"><span class="dot ${x.state === 'running' ? 'ok' : x.state === 'stopped' ? '' : 'bad'}"></span>${esc(x.name)} <span class="mute small">${esc(x.state)}${x.restarts ? ' · 視窗內重啟 ' + x.restarts : ''}</span></span><button class="btn sm" data-rs="${esc(x.name)}">重啟</button></div>${x.error ? `<div class="hint err">${esc(x.error)}</div>` : ''}`).join('')}</div></div>
      <div class="card"><h3>👷 背景工人 <small>常駐腳本／指令</small></h3><div class="list">${s.workers.map((w) => `<div><div class="row"><span class="grow"><b>${esc(w.name)}</b> <span class="tag">${esc(w.kind)}</span><span class="tag ${w.state === 'running' ? 'staff' : ''}">${esc(w.state)}</span>${w.restarts ? `<span class="mute small">重啟${w.restarts}次</span>` : ''}<div class="mono mute">${esc(w.kind === 'js' ? 'workers/' + w.script : w.cmd)} · ${esc(w.restart)}</div></span></div><div class="row" style="margin-top:6px"><button class="btn sm" data-w="start" data-n="${esc(w.name)}">啟動</button><button class="btn sm" data-w="stop" data-n="${esc(w.name)}">停止</button><button class="btn sm" data-w="restart" data-n="${esc(w.name)}">重啟</button><button class="btn sm" data-wl="${esc(w.name)}">日誌</button><button class="btn sm bad" data-w="delete" data-n="${esc(w.name)}">刪</button></div></div>`).join('') || '<div class="mute">沒有背景工人。AI 也能用 worker_save 自己建立。</div>'}</div>
        <h3 style="margin-top:14px">＋ 新增</h3><input id="w-n" placeholder="名稱（英數 - _）"><select id="w-k" style="margin-top:6px"><option value="shell">shell 指令</option><option value="js">JS 腳本（data/workers/ 下，worker_threads）</option></select><input id="w-c" placeholder="指令（shell）或檔名（js）" style="margin-top:6px"><select id="w-r" style="margin-top:6px"><option value="on-failure">失敗時重啟</option><option value="always">一律重啟</option><option value="never">不重啟</option></select><button class="btn pri" id="w-add" style="margin-top:8px">建立並啟動</button></div>`;
    b.onclick = LA.guard(async (e) => {
      const r = e.target.closest('[data-rs]'); if (r) { await LA.post(`/api/service/${r.dataset.rs}/restart`); LA.toast('已重啟'); return LA.go('dev'); }
      const w = e.target.closest('[data-w]'); if (w) { await LA.post(`/api/workers/${encodeURIComponent(w.dataset.n)}/${w.dataset.w}`); return LA.go('dev'); }
      const l = e.target.closest('[data-wl]'); if (l) { const j = await LA.api(`/api/workers/${encodeURIComponent(l.dataset.wl)}/logs`); LA.modal(`<h3 style="margin-top:0">${esc(l.dataset.wl)} 日誌</h3><pre class="term" style="height:300px">${esc(j.lines.join('\n') || '（沒有輸出）')}</pre>`); }
      if (e.target.id === 'w-add') { const k = $('#w-k').value, c = $('#w-c').value.trim(); await LA.post('/api/workers', { name: $('#w-n').value.trim(), kind: k, [k === 'js' ? 'script' : 'cmd']: c, restart: $('#w-r').value }); LA.go('dev'); }
    });
  }

  async function dbg(b) {
    const [d, tr, { settings }] = await Promise.all([LA.api('/api/debug/state'), LA.api('/api/debug/traces'), LA.api('/api/settings')]);
    b.innerHTML = `<div class="card"><h3>🩺 執行狀態 <small><a href="#" id="d-ref" style="color:var(--ac)">重新整理</a></small></h3><div class="kv"><b>版本</b><span>${d.version} · Node ${esc(d.node)} · ${esc(d.arch)}</span><b>執行</b><span>${LA.fmtDur(d.uptime_s)}</span><b>記憶體</b><span>RSS ${d.rss_mb}MB · heap ${d.heap_used_mb}/${d.heap_limit_mb}MB</span><b>事件迴圈延遲</b><span>${d.event_loop_lag_ms} ms</span><b>活動 handle</b><span>${d.active_handles}</span><b>佇列</b><span>待審批 ${d.queues.approvals_pending} · 排程 ${d.queues.tasks} · 終端機 ${d.queues.terminals}</span><b>資料</b><span>${d.db.persons} 人 · ${d.db.facts} 事實 · ${d.db.vectors} 向量 · ${d.db.ledger} 帳 · ${d.db.sheets} 表</span></div>
      ${d.recent_errors.length ? `<h3 style="margin-top:12px">最近錯誤</h3><div class="list">${d.recent_errors.slice().reverse().map((e) => `<div><span class="tag">${esc(e.where)}</span>${esc(e.message)}<pre class="mono mute" style="white-space:pre-wrap;margin:4px 0 0">${esc(e.stack)}</pre></div>`).join('')}</div>` : ''}</div>
      <div class="card"><h3>🔎 遠端除錯（Node Inspector）</h3><div class="hint">開啟後在電腦執行 <span class="mono">adb forward tcp:${d.inspector.port} tcp:${d.inspector.port}</span>，再用 Chrome 開 <span class="mono">chrome://inspect</span> 或 VS Code「Attach to Node」連 127.0.0.1:${d.inspector.port}，即可看變數、下中斷點、抓記憶體快照。Inspector 沒有密碼，只綁 127.0.0.1，用完請關閉。</div>
        <label class="chk"><input type="checkbox" id="insp" ${d.inspector.open ? 'checked' : ''}> 開啟 Inspector</label><label class="f">連接埠</label><input id="insp-p" type="number" value="${d.inspector.port}">
        <label class="chk" style="margin-top:10px"><input type="checkbox" id="evalon" ${settings.dev.debug_eval ? 'checked' : ''}> 允許遠端 eval（在後台行程內執行 JS，可讀 ctx 內任何變數）</label><div class="hint">這是人類才能開的開關，AI 無法改。</div>
        <div id="evalbox" ${settings.dev.debug_eval ? '' : 'hidden'}><textarea id="ev-c" style="min-height:70px" placeholder="例：ctx.supervisor.status()　或　ctx.store.db.persons"></textarea><button class="btn" id="ev-go" style="margin-top:6px">執行</button><pre class="mono term" id="ev-out" style="height:160px;margin-top:8px"></pre></div></div>
      <div class="card"><h3>🧾 AI 執行追蹤 <small>最近 ${tr.length} 次</small></h3><div class="list">${tr.map((t) => `<div><b>${esc(t.who)}</b> <span class="tag">${esc(t.role)}</span><span class="mute small">${LA.fmtTime(t.ts)} · ${t.rounds} 輪 · ${t.ms}ms · ${t.tokens.in}/${t.tokens.out} tok</span><div class="small">「${esc(t.input)}」</div>${t.calls.map((c) => `<div class="mono mute">▸ ${esc(c.name)} ${esc(c.args)} → ${esc(c.result)} <i>(${c.ms}ms)</i></div>`).join('')}</div>`).join('') || '<div class="mute">還沒有紀錄</div>'}</div></div>`;
    const errorText = d.recent_errors.length ? d.recent_errors.slice().reverse().map((x) => `[${x.where}] ${x.message}\n${x.stack || ''}`).join('\n\n') : '目前沒有最近錯誤';
    // 26.11.3 偵錯：每個問題有固定的錯誤代碼，可以單獨複製；也能一鍵複製整份報告（金鑰、token 已自動遮蔽）
    const { issues } = await LA.api('/api/debug/issues'); const sp = await LA.api('/api/debug/speed').catch(() => null);
    b.insertAdjacentHTML('afterbegin', `<div class="card"><h3 style="margin-top:0">偵錯 <small>${issues.length ? issues.length + ' 個問題' : '目前沒有問題'}</small></h3>
      <div class="row" style="gap:8px;flex-wrap:wrap"><button class="btn pri sm" id="copy-report">複製完整偵錯報告</button><button class="btn sm" id="copy-errors">複製最近錯誤</button><button class="btn sm" id="dl-log">${LA.icon('download', 'sm')} 下載運行記錄</button></div><div class="hint small">運行記錄是一個文字檔：摘要、錯誤記錄、AI 執行記錄（用了哪些工具、花多久、多少 token）、系統日誌、操作稽核。金鑰與密碼會自動遮蔽。</div>
      <div class="hint">報告裡的金鑰、token、密碼會自動遮蔽，可以直接貼給維護人員或 AI。</div>
      ${sp && sp.turns ? `<div class="kv" style="margin-top:8px"><b>回覆速度</b><span>最近 ${sp.turns} 次平均 ${(sp.avg_ms / 1000).toFixed(1)} 秒（模型 ${(sp.llm_ms / 1000).toFixed(1)}s・工具 ${(sp.tool_ms / 1000).toFixed(1)}s・${sp.rounds} 回合）</span><b>判斷</b><span>${esc(sp.hint)}</span></div>` : ''}
      <div class="list" style="margin-top:8px">${issues.map((x) => `<div class="issue"><div class="row"><span class="mono ecode">${esc(x.code)}</span><span class="tag">${esc(x.where)}</span>${x.count > 1 ? `<span class="tag">×${x.count}</span>` : ''}<span class="grow"></span><button class="btn sm" data-copy="${esc(x.code + '｜' + x.where + '｜' + x.message)}">複製</button></div><div class="small" style="word-break:break-all;margin-top:4px">${esc(x.message)}</div><div class="small mute">${LA.fmtTime(x.last)}${x.count > 1 ? '（第一次 ' + LA.fmtTime(x.first) + '）' : ''}</div></div>`).join('')}</div></div>`);
    $('#copy-errors').onclick = () => LA.copy(errorText);
    $('#dl-log').onclick = LA.guard(downloadLog);
    $('#copy-report').onclick = LA.guard(async () => { const r = await LA.api('/api/debug/report'); await LA.copy(r.text); });
    b.addEventListener('click', (e) => { const c = e.target.closest('[data-copy]'); if (c) LA.copy(c.dataset.copy); });
    $('#d-ref').onclick = (e) => { e.preventDefault(); LA.go('dev'); };
    $('#insp').onchange = LA.guard(async (e) => { const r = await LA.post('/api/debug/inspector', { on: e.target.checked, port: +$('#insp-p').value }); if (!r.ok) { e.target.checked = false; throw new Error(r.error); } LA.toast(r.open ? 'Inspector 已開啟' : '已關閉'); });
    $('#evalon').onchange = LA.guard(async (e) => { await LA.post('/api/settings', { key: 'dev.debug_eval', value: e.target.checked }); $('#evalbox').hidden = !e.target.checked; });
    $('#ev-go').onclick = LA.guard(async () => { try { const r = await LA.post('/api/debug/eval', { code: $('#ev-c').value }); $('#ev-out').textContent = r.result; } catch (e) { $('#ev-out').textContent = '⚠️ ' + e.message; } });
  }

  async function log(b) {
    const [l, au] = await Promise.all([LA.api('/api/logs'), LA.api('/api/audit?n=60')]);
    b.innerHTML = `<div class="card"><h3>📜 即時日誌</h3><pre class="term" id="lg" style="height:300px">${esc(l.lines.join('\n'))}</pre></div><div class="card"><h3>🗒️ 稽核紀錄 <small>AI 與人的操作</small></h3><div class="list">${au.map((a) => `<div class="small"><span class="mute">${LA.fmtTime(a.ts)}</span> <span class="tag">${esc(a.who)}</span><b>${esc(a.action)}</b> <span class="mute mono">${esc(a.detail)}</span></div>`).join('')}</div></div>`;
    const es = new EventSource('/api/logs/stream?t=' + encodeURIComponent(LA.token)); const p = $('#lg'); p.scrollTop = p.scrollHeight;
    es.onmessage = (e) => { const o = $('#lg'); if (!o) { es.close(); return; } o.textContent += '\n' + JSON.parse(e.data); o.scrollTop = o.scrollHeight; }; LA._es = es;
  }

  async function mem(b) {
    const [v, snaps] = await Promise.all([LA.api('/api/vector/stats'), LA.api('/api/snapshots')]);
    b.innerHTML = `<div class="card"><h3>🧠 向量記憶</h3><div class="kv"><b>筆數</b><span>${v.count}</span><b>嵌入類型</b><span>${Object.entries(v.byKind).map(([k, n]) => `${esc(k)}×${n}`).join('、') || '—'}</span></div><div class="row" style="margin-top:8px"><input id="vq" class="grow" placeholder="試搜尋（語意）"><button class="btn" id="vs">搜尋</button></div><div id="vr" class="small" style="margin-top:8px"></div><button class="btn sm" id="vre" style="margin-top:6px">重建全部向量</button><div class="hint">換了嵌入來源（有／無 Gemini 金鑰）後請重建。本地嵌入為字元 n-gram，離線可用。</div></div>
      <div class="card"><h3>💾 備份與還原</h3><button class="btn pri" id="bk">立即備份資料庫＋設定</button><div class="hint">備份放在 data/backups/。檔案刪除／覆蓋的快照如下，可一鍵還原：</div><div class="list">${snaps.slice(0, 25).map((s) => `<div class="row"><span class="grow mono">${esc(s.orig)}<div class="mute small">${LA.fmtTime(s.ts)} · ${esc(s.who)}</div></span><button class="btn sm" data-rs="${s.id}">還原</button></div>`).join('') || '<div class="mute">沒有快照</div>'}</div></div>`;
    b.onclick = LA.guard(async (e) => {
      if (e.target.id === 'vs') { const r = await LA.post('/api/vector/search', { query: $('#vq').value }); $('#vr').innerHTML = r.map((x) => `<div>(${x.score}) ${esc(x.text)}</div>`).join('') || '<span class="mute">沒有相近的記憶</span>'; }
      if (e.target.id === 'vre') { const r = await LA.post('/api/vector/reindex'); LA.toast(`已重建 ${r.n} 筆`); }
      if (e.target.id === 'bk') { const r = await LA.post('/api/backup'); LA.toast('已備份'); LA.$('#bk').insertAdjacentHTML('afterend', `<div class="hint mono">${esc(r.path)}</div>`); }
      const s = e.target.closest('[data-rs]'); if (s && await LA.confirm('還原這個快照？（會覆蓋目前同路徑檔案）')) { const r = await LA.post('/api/snapshots/restore', { id: s.dataset.rs }); LA.toast('已還原：' + r.restored); }
    });
  }
})();
