'use strict';
/*
 * 網站工作室（和 AI 的 site_* 工具共用同一份專案）
 *  Anti-gravity-engine3：一句話直接生成——AI 自己判斷類型、規劃、寫程式、檢查修錯、打包；不用選範本（範本放在「進階」）
 *  ・預覽（手機寬／電腦寬）、改檔案、檢查、下載 zip、刪除
 *  ・預覽在另一個本機連接埠（不同來源），網站程式碰不到 App 的權杖與資料
 */
(function () {
  const { esc } = LA; const $ = (s, r = document) => r.querySelector(s);
  let cur = null; let curFile = ''; let wide = false; let checkTxt = ''; let poll = 0; let draft = ''; const seen = new Set();
  const EX = ['咖啡店的一頁式官網，有菜單、營業時間和訂位按鈕', '客戶管理系統，記錄名稱、電話、狀態、下次聯絡日，可以搜尋和匯出', '家庭記帳網頁，收入支出分類，每月統計圖', '有後端 API 的待辦清單系統', '個人作品集網站，深色科技風'];
  const ago = (ms) => { const s = Math.max(0, Math.round(ms / 1000)); return s < 60 ? `${s} 秒` : `${Math.floor(s / 60)} 分 ${s % 60} 秒`; };
  async function view(main) {
    const [r, jr] = await Promise.all([LA.api('/api/sites'), LA.api('/api/sites/jobs').catch(() => ({ jobs: [] }))]); const sites = r.sites || []; const jobs = (jr.jobs || []).slice(0, 4);
    const running = jobs.filter((j) => j.status === 'running');
    for (const j of jobs) if (j.site && j.status !== 'error' && !seen.has(j.id)) { seen.add(j.id); if (j.status === 'running' || Date.now() - j.finished < 15000) { cur = j.site.id; curFile = ''; checkTxt = ''; } }   // 做好（或正在做）的網站自動打開
    if (cur && !sites.some((s) => s.id === cur)) cur = null; if (!cur && sites.length) cur = sites[0].id;
    let det = null, prev = null; if (cur) { det = await LA.api('/api/sites/' + encodeURIComponent(cur)).catch(() => null); prev = await LA.api('/api/sites/' + encodeURIComponent(cur) + '/preview').catch(() => null); }
    const files = det ? det.files : []; if (curFile && !files.some((f) => f.path === curFile)) curFile = '';
    let content = ''; if (det && curFile) { const f = await LA.api(`/api/sites/${encodeURIComponent(cur)}/file?path=${encodeURIComponent(curFile)}`).catch(() => null); content = f && !f.binary ? f.content : ''; }
    const ta = $('#g-req'); if (ta) draft = ta.value;
    main.innerHTML = `
      <div class="card gen-hero"><h3>想要什麼網站？</h3>
        <p class="mute small">一句話就好。AI 會自己決定版面與功能、寫好所有程式、檢查修錯、打包成 zip，做好也會放到對話裡（約 1～3 分鐘）。</p>
        <div class="gen-row"><textarea id="g-req" rows="2" placeholder="例：咖啡店的一頁式官網，有菜單和訂位按鈕">${esc(draft)}</textarea><button class="btn pri" id="g-go"${running.length >= 2 ? ' disabled' : ''}>生成</button></div>
        <div class="chips">${EX.map((a) => `<button class="chip" data-ex="${esc(a)}">${esc(a)}</button>`).join('')}</div>
      </div>
      ${jobs.length ? `<div class="card"><h3>製作進度</h3>${jobs.map((j) => `<div class="gen-job ${j.status}">
          <div class="row"><b class="grow">${esc(j.site ? j.site.name : j.request.slice(0, 30))}</b><span class="small ${j.status === 'error' ? 'bad' : j.status === 'done' ? 'ok' : ''}">${j.status === 'running' ? `${esc(j.stage)}…・${ago(Date.now() - j.started)}` : j.status === 'done' ? `完成・${ago(j.finished - j.started)}` : '失敗'}</span></div>
          ${j.status === 'running' ? '<div class="vbar gen-bar"><i></i></div>' : ''}
          ${j.status === 'error' ? `<div class="small bad">${esc(j.error)}</div>` : ''}
          ${j.status === 'done' && j.check ? `<div class="small mute">檢查：${j.check.ok ? '沒有錯誤' : `${j.check.errors} 個錯誤`}${j.check.warnings ? `・${j.check.warnings} 個建議` : ''}${j.site ? `　<button class="linkbtn" data-site="${esc(j.site.id)}">打開</button>` : ''}</div>` : ''}
        </div>`).join('')}</div>` : ''}
      ${sites.length ? `<div class="card"><div class="row" style="flex-wrap:wrap;gap:6px">${sites.map((s) => `<button class="chip ${s.id === cur ? 'on' : ''}" data-site="${esc(s.id)}">${esc(s.name)}</button>`).join('')}</div></div>` : ''}
      ${det ? `<div class="card site-box">
        <div class="row" style="flex-wrap:wrap;gap:6px"><b class="grow">${esc(det.site.name)} <small class="mute">${det.site.files} 個檔案・${LA.fmtBytes(det.site.bytes)}</small></b>
          <button class="btn sm" id="s-w">${wide ? '手機寬' : '電腦寬'}</button><button class="btn sm" id="s-r" aria-label="重新整理">${LA.icon('refresh')}</button><button class="btn sm" id="s-ext">外部開啟</button></div>
        <div class="site-frame ${wide ? 'wide' : ''}">${prev ? `<iframe id="s-if" src="${esc(prev.url)}" title="網站預覽" sandbox="allow-scripts allow-forms allow-modals allow-same-origin allow-popups allow-downloads"></iframe>` : '<p class="mute">預覽伺服器沒有啟動</p>'}</div>
        <div class="gen-row"><textarea id="s-chg" rows="2" placeholder="想改哪裡？例：主色換成綠色、加一個常見問題區塊"></textarea><button class="btn" id="s-ai">請 AI 改</button></div>
        <div class="row" style="flex-wrap:wrap;gap:6px;margin-top:8px"><button class="btn pri" id="s-zip">${LA.icon('download')} 下載 zip</button><button class="btn" id="s-chk">檢查</button><button class="btn danger" id="s-del">刪除</button></div>
        ${checkTxt ? `<pre class="site-chk">${esc(checkTxt)}</pre>` : ''}
        <p class="mute small">預覽網址：<span class="mono">${prev ? esc(prev.url) : '—'}</span>（只在這支手機上有效）</p>
      </div>
      <details class="card adv"${curFile ? ' open' : ''}><summary>進階：檔案與程式碼</summary><div class="site-files">${files.map((f) => `<button class="${f.path === curFile ? 'on' : ''}" data-f="${esc(f.path)}"><span class="mono">${esc(f.path)}</span><small>${LA.fmtBytes(f.size)}</small></button>`).join('')}</div>
        ${curFile ? `<div class="row" style="margin-top:8px"><b class="grow mono">${esc(curFile)}</b><button class="btn sm pri" id="f-save">儲存</button><button class="btn sm" id="f-close">關閉</button></div><textarea id="f-ed" class="mono site-ed" spellcheck="false">${esc(content)}</textarea>` : '<p class="mute small">點檔案可以直接修改。</p>'}
        <div class="row" style="margin-top:8px"><input id="nf" placeholder="新檔案路徑，例：about.html" class="grow"><button class="btn sm" id="f-new">新增檔案</button></div>
      </details>` : ''}
      <details class="card adv"><summary>進階：從範本自己建立</summary>
        <div class="row" style="margin-top:8px"><input id="sn" placeholder="網站名稱" class="grow"><select id="st">${(r.templates || []).map((t) => `<option value="${t.id}">${esc(t.name)}</option>`).join('')}</select><button class="btn" id="s-new">建立</button></div>
      </details>`;
    clearTimeout(poll); if (running.length && LA.cur === 'sites') poll = setTimeout(() => { if (LA.cur === 'sites' && !document.querySelector('#f-ed:focus, #g-req:focus, #s-chg:focus')) view(main).catch(() => {}); else if (LA.cur === 'sites') poll = setTimeout(() => view(main).catch(() => {}), 3000); }, 2500);
    LA.report();
  }
  LA.register('sites', { name: '網站工作室', title: '網站工作室（一句話生成網站）',
    leave() { clearTimeout(poll); },
    async render(main) {
      await view(main);
      main.onclick = LA.guard(async (e) => {
        const t = e.target; const re = () => view(main);
        const ex = t.closest('[data-ex]'); if (ex) { const i = $('#g-req'); i.value = ex.dataset.ex; i.focus(); return; }
        if (t.closest('#g-go')) { const q = $('#g-req').value.trim(); if (!q) { $('#g-req').focus(); return LA.toast('說一句想要什麼網站', true); } t.closest('#g-go').disabled = true; await LA.post('/api/sites/build', { request: q }); draft = ''; $('#g-req').value = ''; LA.toast('開始做了，大約 1～3 分鐘'); return re(); }
        const st = t.closest('[data-site]'); if (st) { cur = st.dataset.site; curFile = ''; checkTxt = ''; return re(); }
        if (t.closest('#s-new')) { const n = $('#sn').value.trim(); if (!n) return LA.toast('先輸入網站名稱', true); const s = await LA.post('/api/sites', { name: n, template: $('#st').value }); cur = s.id; curFile = ''; checkTxt = ''; LA.toast('已建立'); return re(); }
        if (t.closest('#s-w')) { wide = !wide; return re(); }
        if (t.closest('#s-r')) { const f = $('#s-if'); if (f) f.src = f.src; return; }
        if (t.closest('#s-ext')) { const f = $('#s-if'); if (!f) return; if (window.AndroidBridge && AndroidBridge.openExternal) AndroidBridge.openExternal(f.src); else window.open(f.src, '_blank', 'noopener'); return; }
        if (t.closest('#s-chk')) { const r = await LA.post(`/api/sites/${encodeURIComponent(cur)}/check`); checkTxt = r.text; LA.toast(r.ok ? '檢查通過' : `有 ${r.errors.length} 個錯誤`, !r.ok); return re(); }
        if (t.closest('#s-zip')) { const rec = await LA.post(`/api/sites/${encodeURIComponent(cur)}/zip`); await LA.download(`/api/files/out/${encodeURIComponent(rec.id)}`, rec.name); LA.toast('已下載：' + rec.name); return; }
        if (t.closest('#s-ai')) { const q = $('#s-chg').value.trim(); if (!q) { $('#s-chg').focus(); return LA.toast('說說想改哪裡', true); } const s = cur; LA.go('home').then(() => { const i = $('#c-in'); if (i) { i.value = `修改網站「${s}」：${q}（改完跑 site_check 修到沒錯誤，再 site_zip 傳給我）`; i.dispatchEvent(new Event('input')); const b = $('#c-send'); if (b) b.click(); } }); return; }
        if (t.closest('#s-del')) { if (!await LA.confirm('確定刪除這個網站？檔案會一起刪掉。')) return; await LA.del('/api/sites/' + encodeURIComponent(cur)); cur = null; curFile = ''; checkTxt = ''; return re(); }
        const fb = t.closest('[data-f]'); if (fb) { curFile = fb.dataset.f; return re(); }
        if (t.closest('#f-close')) { curFile = ''; return re(); }
        if (t.closest('#f-save')) { await LA.post(`/api/sites/${encodeURIComponent(cur)}/file`, { path: curFile, content: $('#f-ed').value }); LA.toast('已儲存'); checkTxt = ''; return re(); }
        if (t.closest('#f-new')) { const p = $('#nf').value.trim(); if (!p) return; await LA.post(`/api/sites/${encodeURIComponent(cur)}/file`, { path: p, content: '' }); curFile = p; return re(); }
      });
      main.onkeydown = (e) => { if (e.target.id === 'g-req' && e.key === 'Enter' && !e.shiftKey && !e.isComposing) { e.preventDefault(); const b = $('#g-go'); if (b) b.click(); } };
    } });
})();
