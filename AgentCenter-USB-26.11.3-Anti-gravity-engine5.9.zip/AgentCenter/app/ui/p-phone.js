'use strict';
/*
 * 26.11.3 Revise7 手機代理：AI 依你的指示操作手機上的其他 App。
 * 平常用螢幕上的「AI 浮動球」下指令（打字或語音）、用連點器；這一頁是設定、確認、看每一步的畫面。
 * 26.11.3 pro10：下指令可以用語音輸入；新增計時器、本機音樂播放（手機裡原本就有的音檔）、遊戲協助模式與巨集。
 */
(function () {
  const { esc } = LA; const $ = (s, r = document) => r.querySelector(s); const AB = () => window.AndroidBridge || null;
  let es = null; let steps = []; let st = null; let poll = null; let shown = true; let clearAt = 0; let dev = null; let trOut = '';
  let timers = []; let tOff = 0; let mus = null; let songs = null; let musQ = ''; let macros = []; let mst = null; let tick = null; let macroText = ''; let macroName = '';
  const mmss = (n) => { n = Math.max(0, Math.round(n)); const h = Math.floor(n / 3600); const m = Math.floor((n % 3600) / 60); return (h ? h + ':' + String(m).padStart(2, '0') : m) + ':' + String(n % 60).padStart(2, '0'); };
  const shotUrl = (seq) => `/api/phone/step/${seq}?t=${encodeURIComponent(LA.token)}`;
  const stepHtml = (x) => `<div class="pstep"><div class="pstep-img">${x.img ? `<img src="${shotUrl(x.seq)}" alt="" loading="lazy">${x.tap && x.w ? `<i class="pring" style="left:${(x.tap.x / x.w) * 100}%;top:${(x.tap.y / x.h) * 100}%"></i>` : ''}` : '<span class="mute small">沒有截圖</span>'}</div><span><b>${x.seq}</b> ${esc(x.label)}<small>${esc(x.pkg || '')}</small></span></div>`;
  let render = function (main) {
    const on = AB() && AB().phoneAgentOn ? AB().phoneAgentOn() : false; const s = st || {}; const live = s.enabled; const ball = AB() && AB().phoneBallShown ? AB().phoneBallShown() : true;
    const overlay = AB() && AB().hasOverlay ? AB().hasOverlay() : true;   // Anti-gravity-engine1：沒有「上層顯示」權限時，浮動球在主畫面會不見
    main.innerHTML = `<div class="card"><h3>${LA.icon('grid')} 手機代理 <small><span class="dot ${live ? 'ok' : on ? 'warn' : 'bad'}"></span>${live ? '運作中' : on ? '已開啟，等待連線' : '還沒開啟'}</small></h3>
      <p class="mute small">開啟後螢幕上會有一顆「AI」浮動球：點開面板，打字或按「語音」說「去 YouTube 搜尋放鬆音樂並播放」，AI 會讀畫面、幫你點、滑、打字。面板裡還有<b>連點器</b>。畫面內容會送給你設定的 AI 模型判讀。</p>
      ${!AB() ? '<div class="hint err">要在 Android App 裡才能使用。</div>' : !on ? `<ol class="small"><li>按下面「開啟無障礙設定」→ 找到「已下載的應用程式」或「已安裝的服務」→「Agent中控中心 手機代理」→ 開啟。</li><li>如果開關是灰色、說「受限制的設定」：按「App 資訊」→ 右上角 ⋮ →「允許受限制的設定」，再回去開。</li><li>OPPO／realme／小米等手機：電池設定改成「不受限制」，避免系統把服務關掉。</li></ol><div class="row"><button class="btn pri" id="pa-acc">開啟無障礙設定</button><button class="btn" id="pa-info">App 資訊</button></div>` : `<div class="row"><label class="chk"><input type="checkbox" id="pa-ball" ${ball ? 'checked' : ''}> 顯示 AI 浮動球</label><button class="btn sm" id="pa-acc">無障礙設定</button></div>${ball && !overlay ? '<div class="hint">浮動球在回到主畫面時會不見？開啟「顯示在其他應用程式上層」權限就會一直顯示。<div class="row" style="margin-top:6px"><button class="btn sm pri" id="pa-overlay">開啟上層顯示權限</button></div></div>' : ''}`}
      ${s.health && !s.health.ok && on ? `<div class="hint err">${esc(s.health.error || '')}</div>` : ''}${live && s.health && !s.health.shot ? '<div class="hint">這支手機是 Android 10 以下：不能截圖，AI 只能用畫面上的文字與按鈕操作。</div>' : ''}</div>
      ${s.pending ? `<div class="card bwarn"><b>AI 要執行：</b>${esc(s.pending.text)}<div class="row" style="margin-top:8px"><button class="btn bad" data-dec="0">拒絕</button><button class="btn ok" data-dec="1">允許</button></div></div>` : ''}
      ${devCard()}
      <div class="card"><h3>下指令 <small>可以打字或按麥克風用說的</small></h3><div class="row" style="align-items:flex-end"><textarea id="pa-in" rows="2" class="grow" placeholder="例：打開 LINE，把「明天 9 點開會」傳給王小明"></textarea>${LA.voice ? `<button class="ico pa-mic" id="pa-mic" title="語音輸入">${LA.icon('mic')}</button>` : ''}</div>
        <div class="row" style="margin-top:8px"><button class="btn pri" id="pa-go" ${live ? '' : 'disabled'}>交給 AI</button><button class="btn" id="pa-game" ${live ? '' : 'disabled'} title="AI 看截圖幫你操作遊戲畫面">${LA.icon('play', 'sm')} 遊戲協助</button>${s.running ? '<button class="btn bad" id="pa-stop">停止</button>' : ''}<span class="mute small grow">${s.running && s.task ? 'AI 操作中：' + esc(s.task.doing || '') : ''}</span></div>
        ${(s.history || []).slice(-3).reverse().map((h) => `<div class="pa-h"><b>${esc(h.text)}</b><div class="small">${esc(h.reply || '（進行中）')}</div></div>`).join('')}</div>
      ${toolsCard()}${macroCard(live)}
      <div class="card"><h3>每一步的畫面 <small>${steps.length} 步・${clearAt ? `約 ${Math.max(1, Math.round((clearAt - Date.now()) / 60000))} 分鐘後自動刪除` : '任務做完 5 分鐘後自動刪除'}</small></h3><div class="row" style="margin-bottom:6px"><button class="btn sm" id="pa-hide">${shown ? '隱藏' : '顯示'}</button><button class="btn sm danger" id="pa-clear">清除紀錄</button></div>${shown ? `<div class="psteps" id="pa-steps">${steps.slice().reverse().map(stepHtml).join('') || '<div class="mute small">還沒有動作</div>'}</div>` : '<div class="mute small">圖片紀錄已隱藏</div>'}</div>
      <div class="card"><h3>安全</h3><div class="small">付款、轉帳、刪除、解除安裝、安裝、授權、登出這類按鈕<b>一定</b>先問你（不能關）。AI 不幫忙輸入密碼。</div>
        <label class="chk" style="margin-top:6px"><input type="checkbox" id="pa-send" ${!s.settings || s.settings.confirm_send !== false ? 'checked' : ''}> 傳送訊息、發文、在輸入框按送出也要先問我</label></div>`;
  };
  // 26.11.3 pro10：計時器與本機音樂
  function toolsCard() {
    const ab = AB(); const perm = mus ? mus.permission : (ab && ab.hasAudioFiles ? ab.hasAudioFiles() : false); const now = Date.now() + tOff; const cur = mus && mus.song;
    return `<div class="card" id="pa-tools"><h3>${LA.icon('clock')} 計時器與音樂</h3>
      <div class="pa-sub">計時器 <small class="mute">時間到會用鬧鐘音量響鈴、震動、跳通知</small></div>
      <div class="row pa-quick">${[[60, '1 分'], [180, '3 分'], [300, '5 分'], [600, '10 分'], [1800, '30 分'], [3600, '1 小時']].map(([sec, n]) => `<button class="btn sm" data-tm="${sec}">${n}</button>`).join('')}</div>
      <div class="row" style="margin-top:6px"><input id="tm-dur" style="width:8em" placeholder="例：90、5m、1:30" autocapitalize="off"><input id="tm-label" class="grow" placeholder="名稱（選填），例：泡麵" maxlength="40"><button class="btn sm pri" id="tm-add">開始</button></div>
      ${timers.length ? `<div class="pa-timers">${timers.map((t) => `<div class="pa-timer"><b data-left="${t.due}">${mmss((t.due - now) / 1000)}</b><span class="grow">${esc(t.label || '計時器')} <small class="mute">#${t.id}</small></span><button class="ico" data-tmx="${t.id}" title="取消">${LA.icon('x', 'sm')}</button></div>`).join('')}</div>` : ''}
      <div class="row" style="margin-top:6px"><button class="btn sm" id="tm-quiet">${LA.icon('stop', 'sm')} 停止鈴聲</button></div>
      <div class="pa-sub" style="margin-top:14px">音樂 <small class="mute">播放手機裡原本就有的音檔，不用匯入</small></div>
      ${!ab && !mus ? '<div class="hint">要在 Android App 裡才能播放。</div>' : !perm ? `<div class="hint">要先允許 App 讀取手機裡的音樂（只讀音訊檔）。</div><div class="row"><button class="btn sm pri" id="mu-perm">允許讀取音樂</button></div>` : `
      <div class="pa-now">${cur ? `<div class="grow"><b>${esc(cur.title)}</b><small class="mute">${esc(cur.artist || '')}${mus.queue ? `・第 ${mus.index + 1}／${mus.queue} 首` : ''}・${mmss(mus.position_s || 0)}／${mmss(cur.duration_s || 0)}</small></div>` : `<div class="grow mute small">${mus && mus.other_playing ? '其他 App 正在播放（下面的按鈕可以控制它）' : '沒有在播放'}</div>`}
        <div class="pa-ctl"><button class="ico" data-mu="prev" title="上一首">${LA.icon('back')}</button><button class="ico big" data-mu="${mus && mus.playing ? 'pause' : 'resume'}" title="${mus && mus.playing ? '暫停' : '播放'}">${LA.icon(mus && mus.playing ? 'pause' : 'play')}</button><button class="ico" data-mu="next" title="下一首">${LA.icon('next')}</button><button class="ico" data-mu="stop" title="停止">${LA.icon('stop')}</button></div></div>
      <div class="row" style="margin-top:8px"><input id="mu-q" class="grow" placeholder="搜尋歌名、歌手、專輯（空白＝全部）" value="${esc(musQ)}"><button class="btn sm" id="mu-find">找歌</button><button class="btn sm pri" id="mu-all">隨機播放</button></div>
      ${songs ? `<div class="pa-songs">${songs.length ? songs.map((x) => `<button data-song="${x.id}" class="${cur && cur.id === x.id ? 'on' : ''}"><span class="grow"><b>${esc(x.title)}</b><small>${esc(x.artist || '')}</small></span><i>${mmss(x.duration_s)}</i></button>`).join('') : '<div class="mute small" style="padding:8px">找不到音樂檔。</div>'}</div>` : ''}`}</div>`;
  }
  // 26.11.3 pro10：遊戲協助與巨集
  function macroCard(live) {
    const run = mst && mst.running;
    return `<div class="card" id="pa-macro"><h3>${LA.icon('play')} 遊戲協助與巨集</h3>
      <p class="mute small"><b>遊戲協助</b>：在上面「下指令」寫目標（例：「幫我打完這一關」「每日任務全部領取」）再按「遊戲協助」，AI 會看截圖幫你點。儲值、購買、抽卡付費這類按鈕一定先問你。<br><b>巨集</b>：固定的一串動作重複做（刷關、收獎勵），不看畫面、不花 token。有些遊戲的條款禁止自動操作，是否使用請自行判斷；本功能不含任何規避偵測的機制。</p>
      <textarea id="mc-steps" rows="5" class="mono" spellcheck="false" autocapitalize="off" placeholder="一行一步（座標是螢幕像素）：&#10;tap 540 1800&#10;wait 800&#10;swipe up&#10;tap 900 2100&#10;key back">${esc(macroText)}</textarea>
      <div class="row" style="margin-top:6px"><label class="small mute">重複</label><input id="mc-rep" type="number" min="1" value="1" style="width:6em"><label class="small mute">次・每步間隔</label><input id="mc-gap" type="number" min="60" value="300" style="width:6em"><label class="small mute">毫秒</label></div>
      <div class="row" style="margin-top:8px">${run ? `<button class="btn bad" id="mc-stop">停止巨集</button><span class="small grow">第 ${mst.round}／${mst.repeat} 輪・已做 ${mst.done} 個動作</span>` : `<button class="btn pri" id="mc-run" ${live ? '' : 'disabled'}>執行</button><input id="mc-name" placeholder="名稱" style="width:8em" maxlength="30" value="${esc(macroName)}"><button class="btn" id="mc-save">儲存</button>`}</div>
      ${mst && !run && mst.last ? `<div class="small mute" style="margin-top:6px">上次：做了 ${mst.last.done} 個動作${mst.last.error ? '（' + esc(mst.last.error) + '）' : mst.last.stopped ? '（被停止）' : '（完成）'}</div>` : ''}
      ${macros.length ? `<div class="pa-macros">${macros.map((m) => `<div class="pa-timer"><span class="grow"><b>${esc(m.name)}</b> <small class="mute">${m.steps.length} 步</small></span><button class="btn sm" data-mcload="${esc(m.name)}">載入</button><button class="ico" data-mcdel="${esc(m.name)}" title="刪除">${LA.icon('trash', 'sm')}</button></div>`).join('')}</div>` : ''}</div>`;
  }
  const stepsText = (st2) => st2.map((x) => (x.type === 'tap' ? `tap ${x.x} ${x.y}` : x.type === 'longpress' ? `long ${x.x} ${x.y}` : x.type === 'wait' ? `wait ${x.ms}` : x.type === 'key' ? `key ${x.key}` : x.direction ? `swipe ${x.direction}` : `swipe ${x.x1} ${x.y1} ${x.x2} ${x.y2} ${x.ms || 350}`)).join('\n');
  // 26.11.3 pro2.1：手機資訊（App 自己讀，不用 Termux）＋交通
  function devCard() {
    const d = dev || {}; const b = (d.status && d.status.battery) || {}; const n = (d.status && (d.status.network || d.status.wifi)) || {}; const h = d.health || {}; const t = d.transit || {}; const ab = AB();
    const loc = ab && ab.hasLocation ? ab.hasLocation() : !!h.location; const bg = ab && ab.hasBgLocation ? ab.hasBgLocation() : !!h.location_bg;
    const st2 = { CHARGING: '充電中', FULL: '已充滿', DISCHARGING: '未充電', NOT_CHARGING: '未充電' }[b.status] || '';
    return `<div class="card" id="pa-dev"><h3>${LA.icon('grid')} 手機資訊與交通 <small><span class="dot ${d.native ? 'ok' : d.termux ? 'warn' : 'bad'}"></span>${d.native ? 'App 直接讀取（不用 Termux）' : d.termux ? '透過 Termux:API' : '要在 Android App 裡'}</small></h3>
      <div class="kv small">${b.percentage != null && b.percentage >= 0 ? `<div>電量 <b>${b.percentage}%</b> ${st2}${b.temperature ? `・${b.temperature}°C` : ''}</div>` : ''}${n.type ? `<div>網路 <b>${esc({ wifi: 'Wi-Fi', cellular: '行動網路', ethernet: '有線', vpn: 'VPN', none: '沒有網路' }[n.type] || n.type)}</b>${n.ssid ? '・' + esc(n.ssid) : ''}</div>` : ''}${d.status && d.status.error ? `<div class="err">${esc(d.status.error)}</div>` : ''}
        <div>位置權限 <b>${loc ? (bg ? '一律允許' : '使用 App 時允許') : '未允許'}</b></div></div>
      ${ab && ab.askLocation ? `<div class="row" style="margin-top:6px">${loc ? '' : '<button class="btn sm pri" id="pa-loc">允許位置</button>'}${loc && !bg ? '<button class="btn sm" id="pa-locbg">改成一律允許（背景也能定位）</button>' : ''}</div>` : ''}
      <details style="margin-top:8px"><summary class="small">交通資料（選填）：公車到站、台鐵誤點、高鐵班次、航班、YouBike ${t.tdx ? '<span class="dot ok"></span>TDX 已設定' : ''}${t.google ? '<span class="dot ok"></span>Google 已設定' : ''}</summary>
        <p class="mute small">不填也能用：站牌、車站、單車站位置用 OpenStreetMap，大眾運輸給 Google 地圖連結。填了交通部 TDX（免費申請：tdx.transportdata.tw）就有即時到站、誤點、航班、可借車輛數；填 Google Maps 金鑰（要開 Routes API，Google 依用量計費）可以直接比較每種搭法要多久。金鑰只存在這支手機的設定，不會給 AI 看。</p>
        <input id="tr-id" placeholder="TDX Client ID" autocomplete="off"><input id="tr-sec" type="password" placeholder="TDX Client Secret" autocomplete="off"><input id="tr-g" type="password" placeholder="Google Maps API 金鑰（選填）" autocomplete="off">
        <div class="row" style="margin-top:6px"><button class="btn sm pri" id="tr-save">儲存</button>${t.tdx || t.google ? '<button class="btn sm danger" id="tr-clear">清除金鑰</button>' : ''}</div></details>
      <div class="row" style="margin-top:8px"><input id="tr-dest" class="grow" placeholder="要去哪裡？例：東港、屏東、萬丹（可不填）"><button class="btn sm" id="tr-go">看附近交通</button></div>
      <div class="small" id="tr-out" style="margin-top:6px">${trOut}</div></div>`;
  }
  LA.devPerm = () => { if (LA.cur === 'phone') load(document.querySelector('main')); };
  async function load(main) { try { dev = await LA.api('/api/phone/device'); } catch { dev = null; } try { const r = await LA.api('/api/timers'); timers = r.timers || []; tOff = (r.now || Date.now()) - Date.now(); } catch { timers = []; } try { mus = await LA.api('/api/music'); } catch { mus = null; } try { const r = await LA.api('/api/phone/macros'); macros = r.macros || []; mst = r.state || null; } catch { macros = []; mst = null; }
    try { st = await LA.api('/api/phone/state'); const r0 = await LA.api('/api/phone/steps'); steps = r0.items || []; shown = r0.show !== false; clearAt = r0.clear_at || 0; } catch (e) { st = { health: { ok: false, error: e.message } }; } if (LA.cur === 'phone') render(main); }
  LA.register('phone', { name: '手機代理', title: '手機代理（AI 操作手機上的 App＋連點器）',
    leave() { clearInterval(poll); clearInterval(tick); try { es && es.close(); } catch { /* ignore */ } es = null; },
    async render(main) {
      await load(main); clearInterval(poll); poll = setInterval(() => { if (LA.cur !== 'phone') return clearInterval(poll); if (document.activeElement && /^(pa-in|tr-|tm-|mu-|mc-)/.test(document.activeElement.id || '')) return; if (document.querySelector('#pa-dev details[open]')) return; load(main); }, 3000);
      const keep = () => { const a = $('#mc-steps', main); if (a) macroText = a.value; const b = $('#mc-name', main); if (b) macroName = b.value; const c = $('#mu-q', main); if (c) musQ = c.value; };
      if (!render._w) { const r0 = render; render = (m) => { const a2 = $('#mc-steps', m); if (a2) macroText = a2.value; const b2 = $('#mc-name', m); if (b2) macroName = b2.value; const c2 = $('#mu-q', m); if (c2) musQ = c2.value; r0(m); const b = $('#pa-mic', m), i = $('#pa-in', m); if (b && i && LA.voice && LA.voice.bindMic) LA.voice.bindMic(b, i); }; render._w = true; render(main); }
      clearInterval(tick); tick = setInterval(() => { if (LA.cur !== 'phone') return clearInterval(tick); const now = Date.now() + tOff; let due = false; main.querySelectorAll('[data-left]').forEach((b) => { const left = (+b.dataset.left - now) / 1000; b.textContent = mmss(left); if (left <= 0) due = true; }); if (due) load(main); }, 1000);
      try { es && es.close(); es = new EventSource(`/api/phone/events?t=${encodeURIComponent(LA.token)}`); es.addEventListener('step', (e) => { const m = JSON.parse(e.data); if (!steps.some((x) => x.seq === m.seq)) { steps.push(m); const box = $('#pa-steps', main); if (box) box.insertAdjacentHTML('afterbegin', stepHtml(m)); } }); es.addEventListener('pending', () => load(main)); es.addEventListener('cleared', () => load(main)); es.addEventListener('done', () => load(main)); } catch { /* 用輪詢 */ }
      main.onclick = LA.guard(async (e) => {
        const t = e.target;
        if (t.closest('#pa-acc')) return AB().openAccessibilitySettings();
        if (t.closest('#pa-overlay')) { if (AB().askOverlay) AB().askOverlay(); LA.toast('開啟後回到 App，浮動球就會在主畫面也顯示'); return; }
        if (t.closest('#pa-info')) return AB().openAppInfo();
        if (t.closest('#pa-go')) { const v = $('#pa-in', main).value.trim(); if (!v) return; await LA.post('/api/phone/task', { text: v }); $('#pa-in', main).value = ''; LA.toast('已交給 AI，可以切到要操作的 App 看它做'); return load(main); }
        if (t.closest('#pa-game')) { const v = $('#pa-in', main).value.trim(); if (!v) return LA.toast('先在上面寫要 AI 在遊戲裡做什麼', true); await LA.post('/api/phone/task', { text: v, game: true }); $('#pa-in', main).value = ''; LA.toast('遊戲協助開始：切到遊戲畫面；要停就點懸浮球或回來按停止'); return load(main); }
        const tm = t.closest('[data-tm]'); if (tm) { const r = await LA.post('/api/timers', { seconds: +tm.dataset.tm }); LA.toast('開始計時 ' + mmss(r.seconds)); return load(main); }
        if (t.closest('#tm-add')) { const d = $('#tm-dur', main).value.trim(); if (!d) return LA.toast('請輸入時間，例：90、5m、1:30', true); const r = await LA.post('/api/timers', { duration: d, label: $('#tm-label', main).value.trim() }); LA.toast('開始計時 ' + mmss(r.seconds)); $('#tm-dur', main).value = ''; $('#tm-label', main).value = ''; return load(main); }
        const tx = t.closest('[data-tmx]'); if (tx) { await LA.post('/api/timers/cancel', { id: +tx.dataset.tmx }); return load(main); }
        if (t.closest('#tm-quiet')) { await LA.post('/api/timers/stop_ring', {}); return LA.toast('已停止鈴聲'); }
        if (t.closest('#mu-perm')) { if (AB() && AB().askAudioFiles) { AB().askAudioFiles(); setTimeout(() => load(main), 2500); } else LA.toast('要在 Android App 裡', true); return; }
        if (t.closest('#mu-find')) { musQ = $('#mu-q', main).value.trim(); const r = await LA.post('/api/music/list', { q: musQ, limit: 100 }); songs = r.songs || []; return load(main); }
        if (t.closest('#mu-all')) { musQ = $('#mu-q', main).value.trim(); mus = await LA.post('/api/music/play', { q: musQ, shuffle: true }); return load(main); }
        const sg = t.closest('[data-song]'); if (sg) { mus = await LA.post('/api/music/play', { id: +sg.dataset.song }); return load(main); }
        const mc = t.closest('[data-mu]'); if (mc) { const r = await LA.post('/api/music/control', { action: mc.dataset.mu }); if (r.external) LA.toast(r.text); return load(main); }
        if (t.closest('#mc-run')) { keep(); await LA.post('/api/phone/macro', { action: 'run', steps: macroText, repeat: +$('#mc-rep', main).value || 1, gap_ms: +$('#mc-gap', main).value || 300 }); LA.toast('巨集開始；要停就按「停止巨集」或點懸浮球'); return load(main); }
        if (t.closest('#mc-stop')) { await LA.post('/api/phone/macro', { action: 'stop' }); return load(main); }
        if (t.closest('#mc-save')) { keep(); const r = await LA.post('/api/phone/macro', { action: 'save', name: macroName, steps: macroText }); LA.toast(`已存「${r.name}」`); return load(main); }
        const ml = t.closest('[data-mcload]'); if (ml) { const m = macros.find((x) => x.name === ml.dataset.mcload); if (m) { macroText = stepsText(m.steps); macroName = m.name; const a = $('#mc-steps', main); if (a) a.value = macroText; const b = $('#mc-name', main); if (b) b.value = macroName; } return; }
        const md = t.closest('[data-mcdel]'); if (md) { if (await LA.confirm(`刪除巨集「${md.dataset.mcdel}」？`)) { await LA.post('/api/phone/macro', { action: 'delete', name: md.dataset.mcdel }); return load(main); } return; }
        if (t.closest('#pa-loc')) return AB().askLocation();
        if (t.closest('#pa-locbg')) { LA.toast('在權限頁選「位置 → 一律允許」'); return AB().askBgLocation(); }
        if (t.closest('#tr-save')) { await LA.post('/api/transit/config', { tdx_id: $('#tr-id', main).value, tdx_secret: $('#tr-sec', main).value, google_maps_key: $('#tr-g', main).value }); LA.toast('已儲存'); return load(main); }
        if (t.closest('#tr-clear')) { if (await LA.confirm('清除交通資料的金鑰？')) { await LA.post('/api/transit/config', { clear: true }); return load(main); } return; }
        if (t.closest('#tr-go')) { const o = $('#tr-out', main); o.textContent = '查詢中…（先定位）'; try { const r = await LA.post('/api/transit/nearby', { dest: $('#tr-dest', main).value.trim() || undefined }); trOut = LA.richText(r.text); } catch (er) { trOut = `<span class="err">${esc(er.message)}</span>`; } o.innerHTML = trOut; return; }
        if (t.closest('#pa-clear')) { if (await LA.confirm('刪除全部圖片紀錄？（手機代理與瀏覽器的步驟截圖都會刪掉）')) { const r = await LA.post('/api/phone/steps/clear', {}); LA.toast(`已刪除 ${r.steps} 張紀錄`); } return load(main); }
        if (t.closest('#pa-hide')) { await LA.post('/api/browser/steps/settings', { show: !shown }); return load(main); }
        if (t.closest('#pa-stop')) { await LA.post('/api/phone/stop', {}); return load(main); }
        const d = t.closest('[data-dec]'); if (d && st && st.pending) { await LA.post('/api/phone/confirm', { id: st.pending.id, allow: d.dataset.dec === '1' }); return load(main); }
      });
      main.onchange = LA.guard(async (e) => {
        if (e.target.id === 'pa-ball') AB().phoneBall(e.target.checked);
        if (e.target.id === 'pa-send') { await LA.post('/api/phone/settings', { confirm_send: e.target.checked }); LA.toast('已儲存'); }
      });
    } });
})();
