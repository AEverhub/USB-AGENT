'use strict';
/* 連接器（MCP）：選服務 → 按「連結」→ 在瀏覽器登入同意 → 自動接上，AI 就能用那個服務的工具 */
(function () {
  const { esc, $ } = LA;
  const AUTH = { oauth: '登入連結', open: '免登入', key: 'API Key／權杖', local: '本機程式', builtin: 'App 內建' };
  const openUrl = (u) => { if (window.AndroidBridge && AndroidBridge.openExternal) AndroidBridge.openExternal(u); else window.open(u, '_blank', 'noopener'); };
  function row(c) {
    const st = c.connected ? `<span class="okc"><span class="dot ok"></span>已連結${c.tools ? ` · ${c.tools} 個工具` : ''}</span>` : c.installed && c.error ? `<span class="err"><span class="dot bad"></span>${esc(c.error.slice(0, 80))}</span>` : `<span class="mute">${AUTH[c.auth] || ''}</span>`;
    return `<div class="crow">${LA.badge(c.name, c.icon)}<div class="grow"><b>${esc(c.name)}</b><div class="small mute">${esc(c.desc || '')}</div><div class="small">${st}</div></div>
      <div class="kbtn">${c.auth === 'builtin' ? `<button class="btn sm ${c.connected ? '' : 'pri'}" data-go="browser">${c.connected ? '設定' : '去設定'}</button>` : c.installed ? `${c.connected ? '' : `<button class="btn sm pri" data-con="${esc(c.id)}">重新連結</button>`}<button class="btn sm" data-dis="${esc(c.id)}">中斷</button>` : `<button class="btn sm pri" data-con="${esc(c.id)}">連結</button>`}</div></div>`;
  }
  LA.register('connect', { name: '連接器', title: '連接器（MCP：一鍵連結外部服務）', async render(main) {
    let st = await LA.api('/api/connectors');
    const paint = () => {
      const cats = {}; for (const c of st.catalog) (cats[c.cat] ||= []).push(c);
      const on = [...st.catalog, ...st.custom].filter((c) => c.installed);
      main.innerHTML = `<div class="card"><h3>連接器 <small>${on.length} 個已加入</small></h3><div class="hint">按「連結」→ 在跳出的瀏覽器登入並同意 → 回到 App 就接好了。之後直接跟 AI 說「把會議記錄存到 Notion」這類事就行。登入資料加密存在手機，AI 看不到。</div>
        ${on.length ? on.map(row).join('') : '<div class="hint">還沒有連結任何服務。</div>'}<div class="row" style="margin-top:8px"><button class="btn sm" id="c-refresh">重新整理狀態</button></div></div>
        ${Object.entries(cats).map(([k, list]) => `<div class="card"><h3>${esc(k)}</h3>${list.filter((c) => !c.installed).map(row).join('') || '<div class="hint">都已加入</div>'}</div>`).join('')}
        <div class="card"><h3>自訂連接器</h3><div class="hint">任何支援 MCP 的服務都可以：貼上它的 MCP 網址（https）。</div>
          <div class="row"><div style="width:120px"><label class="f">代號（英文）</label><input id="x-name" placeholder="mytool" autocapitalize="off"></div><div class="grow"><label class="f">顯示名稱</label><input id="x-label" placeholder="我的服務"></div></div>
          <label class="f">MCP 網址</label><input id="x-url" placeholder="https://example.com/mcp" autocapitalize="off" spellcheck="false">
          <label class="f">登入方式</label><select id="x-auth"><option value="oauth">登入連結（OAuth）</option><option value="key">API Key</option><option value="open">免登入</option></select>
          <div id="x-keybox" hidden><label class="f">API Key</label><input id="x-key" type="password" autocomplete="off"></div>
          <details><summary class="small mute">進階：服務不支援自動註冊時填 OAuth Client ID</summary><input id="x-cid" placeholder="client_id"><input id="x-sec" type="password" placeholder="client_secret（選填）" style="margin-top:6px"></details>
          <div class="row" style="margin-top:10px"><button class="btn pri" id="x-go">連結</button></div></div>`;
      $('#x-auth').onchange = () => { $('#x-keybox').hidden = $('#x-auth').value !== 'key'; };
    };
    const go = async (body) => {
      const r = await LA.post('/api/connectors/connect', { ...body, origin: location.origin });
      if (r.go) { LA.toast(r.message || ''); return LA.go(r.go); }
      if (r.auth_url) { openUrl(r.auth_url); LA.toast('請在瀏覽器登入並同意，完成後回到 App'); let n = 0; const iv = setInterval(async () => { n++; try { st = await LA.api('/api/connectors'); const all = [...st.catalog, ...st.custom]; const hit = all.find((c) => c.id === (body.id || body.name)); if ((hit && hit.connected) || n > 100) { clearInterval(iv); if (LA.cur === 'connect') paint(); if (hit && hit.connected) LA.toast(`${hit.name} 已連結`); } } catch { /* 繼續等 */ } }, 3000); LA.timers.push(iv); return; }
      st = await LA.api('/api/connectors'); paint(); LA.toast(`已連結${r.tools ? `，可用 ${r.tools} 個工具` : ''}`);
    };
    paint();
    main.onclick = LA.guard(async (e) => {
      const t = e.target; const busy = async (b, fn) => { b.disabled = true; const o = b.textContent; b.textContent = '處理中…'; try { await fn(); } finally { b.disabled = false; b.textContent = o; } };
      const gg = t.closest('[data-go]'); if (gg) return LA.go(gg.dataset.go);
      const con = t.closest('[data-con]'); if (con) { const c = [...st.catalog, ...st.custom].find((x) => x.id === con.dataset.con); if (c && c.auth === 'key') { if (c.key_url && await LA.confirm(`${c.name} 要用你的金鑰／權杖連結。\n\n${c.key_hint || ''}\n\n要先開啟產生權杖的頁面嗎？（已經有了就按取消）`)) openUrl(c.key_url); const k = await LA.ask(`貼上 ${c.name} 的金鑰／權杖`, '', { type: 'password', hint: c.key_hint || c.desc }); if (!k) return; return busy(con, () => go({ id: c.id, key: k })); } return busy(con, () => go(c && c.custom ? { name: c.id, url: c.url, auth: c.auth } : { id: con.dataset.con })); }
      const dis = t.closest('[data-dis]'); if (dis) { if (!(await LA.confirm('中斷這個連接器？會同時刪除登入資料。'))) return; st = await LA.post('/api/connectors/disconnect', { name: dis.dataset.dis }); paint(); return; }
      if (t.id === 'c-refresh') { await LA.post('/api/mcp/reload'); st = await LA.api('/api/connectors'); paint(); return; }
      if (t.id === 'x-go') return busy(t, () => go({ name: $('#x-name').value.trim(), label: $('#x-label').value.trim(), url: $('#x-url').value.trim(), auth: $('#x-auth').value, key: $('#x-key').value, client_id: $('#x-cid').value.trim(), client_secret: $('#x-sec').value }));
    });
  } });
})();
