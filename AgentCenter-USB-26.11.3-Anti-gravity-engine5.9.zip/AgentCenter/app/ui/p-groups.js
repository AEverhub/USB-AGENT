'use strict';
/*
 * 26.11.3 Revise4 聯機群組：聯機的人（和主機管理員）可以開群組一起聊天，像 LINE 群組。
 * AI 只有在被叫到時才回：打「@AI」、叫 AI 的名字、回覆 AI 的訊息、或剛跟 AI 說完話接著問。
 */
(function () {
  const { esc } = LA; const $ = (s, r = document) => r.querySelector(s);
  let cur = null; let poll = null; let items = []; let replyTo = null;
  const fmt = (ts) => new Date(ts || Date.now()).toLocaleTimeString('zh-TW', { hour: '2-digit', minute: '2-digit', hour12: false });

  async function listView(main) {
    cur = null; clearInterval(poll); document.body.classList.remove('chatmode');
    if (LA.link.mode !== 'host' && LA.link.mode !== 'client') {
      main.innerHTML = `<div class="card"><h3 style="margin-top:0">${LA.icon('group')} 群組</h3><p class="mute">群組要在聯機時才能用：大家連到同一台主機，就可以開群組一起跟 AI 聊天。</p><button class="btn pri" id="gp-setup">到「開發者 → 聯機」設定</button></div>`;
      $('#gp-setup', main).onclick = () => LA.devTab('net'); return;
    }
    const r = await LA.api('/api/ngroups');
    main.innerHTML = `<div class="row" style="justify-content:space-between;align-items:center;margin-bottom:10px"><h2 style="margin:0">群組</h2><button class="btn pri sm" id="gp-new">${LA.icon('plus', 'sm')} 建立群組</button></div>
      <div class="list gp-list">${r.items.map((g) => `<button class="gp-item" data-g="${esc(g.id)}"><span class="cav">${esc((g.name || '?').slice(0, 1))}</span><span class="grow"><b>${esc(g.name)}</b><small>${g.last ? esc((g.last.name ? g.last.name + '：' : '') + g.last.text) : g.members.length + ' 人'}</small></span>${g.last ? `<small class="mute">${fmt(g.last.ts)}</small>` : ''}</button>`).join('') || '<div class="card mute">還沒有群組。按「建立群組」，把聯機的人拉進來一起聊天；要 AI 回話就打 @AI。</div>'}</div>`;
    main.onclick = LA.guard(async (e) => { const b = e.target.closest('[data-g]'); if (b) return chatView(main, b.dataset.g); if (e.target.closest('#gp-new')) return create(main); });
  }
  async function create(main) {
    const ppl = (await LA.api('/api/ngroups/people')).items;
    const m = LA.modal(`<h3 style="margin-top:0">建立群組</h3><label class="f">群組名稱</label><input id="gp-name" maxlength="24" placeholder="例：家人、公司午餐團">
      <label class="f">邀請誰</label><div class="list" style="max-height:40vh;overflow:auto">${ppl.map((p) => `<label class="chk"><input type="checkbox" value="${esc(p.pid)}"> ${esc(p.name)}${p.admin ? '（主機）' : ''} <span class="mono small mute">${esc(p.id)}</span></label>`).join('') || '<div class="mute small">還沒有其他人聯機進來，先建立也可以，之後再邀請。</div>'}</div>
      <div class="row" style="justify-content:flex-end;gap:8px;margin-top:12px"><button class="btn" onclick="LA.closeModal()">取消</button><button class="btn pri" id="gp-ok">建立</button></div>`);
    const root = m || document; $('#gp-ok', root).onclick = LA.guard(async () => {
      const r = await LA.post('/api/ngroups', { name: $('#gp-name', root).value, members: [...root.querySelectorAll('input[type=checkbox]:checked')].map((x) => x.value) });
      LA.closeModal(); chatView(main, r.id);
    });
  }
  function bubble(m, prev) {
    if (m.role === 'system') return `<div class="cday">${esc(m.text)}</div>`;
    const imgs = (m.imgs || []).map((n) => `<img src="${LA.rw('/api/chat/media/' + encodeURIComponent(n))}?t=${encodeURIComponent(LA.token)}" alt="" loading="lazy">`).join('');
    const showName = !m.mine && (!prev || prev.name !== m.name || prev.role === 'system');
    const qt = m.quote && m.quote.text ? `<div class="cquote"><b>${esc(m.quote.name || '')}</b>${esc(String(m.quote.text).slice(0, 100))}</div>` : '';
    return `<div class="cmsg ${m.mine ? 'me' : 'ai'}${m.role === 'assistant' ? ' isai' : ''}" data-ts="${m.ts}">${showName ? `<div class="gname">${esc(m.name || '')}</div>` : ''}<div class="cb">${qt}${imgs}${LA.richText(m.text || '')}</div><div class="cmeta">${fmt(m.ts)}</div></div>`;
  }
  async function chatView(main, gid) {
    cur = gid; clearInterval(poll); document.body.classList.add('chatmode');
    main.innerHTML = `<div class="chat gchat"><div class="chead"><button class="ico" id="gp-back" title="返回">${LA.icon('back')}</button><div class="grow"><b id="gp-title">群組</b><small id="gp-mem" class="mute"></small></div><button class="ico" id="gp-inv" title="邀請">${LA.icon('plus')}</button><button class="ico" id="gp-leave" title="離開群組">${LA.icon('x')}</button></div>
      <div class="clist" id="gp-list"></div><div class="cprev" id="gp-prev" hidden></div>
      <div class="ccomp"><button class="ico cplus" id="gp-ai" title="叫 AI">@AI</button><textarea id="gp-in" rows="1" placeholder="說點什麼…（要 AI 回就打 @AI）"></textarea><button class="ico cplus cmic" id="gp-mic" title="用說的輸入">${LA.icon('mic')}</button><button class="csend" id="gp-send" title="送出">${LA.icon('send')}</button></div></div>`;
    const list = $('#gp-list', main); const input = $('#gp-in', main); if (LA.voice) LA.voice.bindMic($('#gp-mic', main), input);
    const load = async () => {
      if (cur !== gid) return; const r = await LA.api(`/api/ngroups/${gid}/history?limit=80`).catch((e) => { LA.toast(e.message, true); return null; }); if (!r || cur !== gid) return;
      $('#gp-title', main).textContent = r.name; $('#gp-mem', main).textContent = `${r.members.length} 人・${r.members.join('、')}`;
      const stick = list.scrollHeight - list.scrollTop - list.clientHeight < 80; const sig = r.items.map((x) => x.ts).join(',');
      if (sig !== list.dataset.sig) { items = r.items; list.dataset.sig = sig; list.innerHTML = r.items.map((m, i) => bubble(m, r.items[i - 1])).join(''); if (stick || !list.dataset.init) list.scrollTop = list.scrollHeight; list.dataset.init = '1'; }
    };
    const prev = () => { const p = $('#gp-prev', main); p.hidden = !replyTo; p.innerHTML = replyTo ? `<div class="creply grow"><b>回覆 ${esc(replyTo.name)}</b><span>${esc(String(replyTo.text).slice(0, 80))}</span></div><button class="ico" id="gp-noreply">${LA.icon('x')}</button>` : ''; };
    const send = async () => {
      const v = input.value.trim(); if (!v) return; input.value = ''; const quote = replyTo; replyTo = null; prev(); $('#gp-send', main).disabled = true;
      try { const r = LA.post(`/api/ngroups/${gid}/send`, { text: v, quote }); setTimeout(load, 300); const x = await r; await load(); if (x.ai) list.scrollTop = list.scrollHeight; } catch (e) { LA.toast(e.message, true); input.value = v; } finally { $('#gp-send', main).disabled = false; }
    };
    $('#gp-send', main).onclick = send; input.onkeydown = (e) => { if (e.key === 'Enter' && !e.shiftKey && !e.isComposing) { e.preventDefault(); send(); } };
    input.oninput = () => { input.style.height = 'auto'; input.style.height = Math.min(input.scrollHeight, 140) + 'px'; };
    $('#gp-ai', main).onclick = () => { if (!/@AI/.test(input.value)) input.value = '@AI ' + input.value; input.focus(); };
    $('#gp-back', main).onclick = () => listView(main);
    $('#gp-leave', main).onclick = LA.guard(async () => { if (await LA.confirm('離開這個群組？')) { await LA.post(`/api/ngroups/${gid}/leave`, {}); listView(main); } });
    $('#gp-inv', main).onclick = LA.guard(async () => {
      const ppl = (await LA.api('/api/ngroups/people')).items; const m = LA.modal(`<h3 style="margin-top:0">邀請進群組</h3><div class="list">${ppl.map((p) => `<label class="chk"><input type="checkbox" value="${esc(p.pid)}"> ${esc(p.name)}</label>`).join('') || '<div class="mute">沒有其他聯機的人</div>'}</div><div class="row" style="justify-content:flex-end;margin-top:10px"><button class="btn pri" id="gp-iok">邀請</button></div>`);
      const root = m || document; $('#gp-iok', root).onclick = LA.guard(async () => { await LA.post(`/api/ngroups/${gid}/members`, { pids: [...root.querySelectorAll('input:checked')].map((x) => x.value) }); LA.closeModal(); load(); });
    });
    main.addEventListener('click', (e) => { if (e.target.closest('#gp-noreply')) { replyTo = null; prev(); } });
    // 長按訊息：回覆、複製
    let t = null; list.addEventListener('pointerdown', (e) => { const el = e.target.closest('.cmsg'); if (!el) return; clearTimeout(t); t = setTimeout(() => { const m = items.find((x) => String(x.ts) === el.dataset.ts); if (!m) return;
      document.querySelectorAll('.cmenu-pop').forEach((x) => x.remove()); const pop = document.createElement('div'); pop.className = 'cmenu-pop'; pop.innerHTML = `<button data-k="reply">${LA.icon('reply')}<span>回覆</span></button><button data-k="copy">${LA.icon('copy')}<span>複製</span></button>`;
      document.body.appendChild(pop); const r = pop.getBoundingClientRect(); pop.style.left = Math.max(8, Math.min(innerWidth - r.width - 8, e.clientX - r.width / 2)) + 'px'; pop.style.top = Math.max(60, e.clientY - r.height - 14) + 'px';
      pop.onclick = (ev) => { const k = (ev.target.closest('[data-k]') || {}).dataset; pop.remove(); if (!k) return; if (k.k === 'copy') LA.copy(m.text || ''); else { replyTo = { text: m.text, name: m.name || 'AI', role: m.role, ts: m.ts }; prev(); input.focus(); } };
      setTimeout(() => document.addEventListener('pointerdown', function off(x) { if (!x.target.closest('.cmenu-pop')) { pop.remove(); document.removeEventListener('pointerdown', off, true); } }, true), 0); }, 480); });
    ['pointerup', 'pointercancel', 'pointermove'].forEach((ev) => list.addEventListener(ev, () => clearTimeout(t)));
    await load(); poll = setInterval(() => { if (LA.cur !== 'groups' || cur !== gid) return clearInterval(poll); load(); }, 4000);
  }
  LA.register('groups', { name: '群組', title: '群組', async render(main) { if (cur) return chatView(main, cur); return listView(main); }, leave() { clearInterval(poll); document.body.classList.remove('chatmode'); } });
})();
