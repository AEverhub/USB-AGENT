'use strict';
/*
 * 26.11.3 Anti-gravity-engine2：影片算圖（App 畫面裡做）
 *  ・frame(g, spec, t, imgs)：純函式，畫出第 t 秒的畫面（預覽和錄製共用，畫面一模一樣）
 *  ・synth(ac, dest, kind, total)：用 Web Audio 合成背景音樂（柔和／輕快／電影感），不用任何音檔、沒有版權問題
 *  ・record(job)：canvas.captureStream＋MediaRecorder 即時錄成 MP4（支援時）或 WebM
 *  ・背景工作：App 畫面開著（任何一頁）就每幾秒看一次有沒有排隊的影片，有就領來做，做完上傳；切到背景會放回佇列，回來再做
 */
(function () {
  const V = LA.vid = {};
  const FONT = '"Noto Sans TC","PingFang TC","Microsoft JhengHei","Heiti TC",system-ui,-apple-system,sans-serif';
  const THEME = {
    dark: { bg: ['#0a0f1f', '#1c2452'], fg: '#f3f6ff', mute: '#aab5d3', ac: '#5b8cff', ac2: '#a78bfa' },
    light: { bg: ['#f7f8fc', '#dfe6f6'], fg: '#131826', mute: '#56627a', ac: '#3b6cf6', ac2: '#8b5cf6' },
    vivid: { bg: ['#3a0ca3', '#c2185b'], fg: '#ffffff', mute: '#ffe0f0', ac: '#4cc9f0', ac2: '#ffd166' },
    warm: { bg: ['#2a160d', '#7a3b1d'], fg: '#fff7ec', mute: '#f1cfae', ac: '#ffb454', ac2: '#ff7a59' },
    mono: { bg: ['#0e0e10', '#2a2a2e'], fg: '#fafafa', mute: '#b8b8be', ac: '#ffffff', ac2: '#9a9aa0' },
    ocean: { bg: ['#022b3a', '#1f7a8c'], fg: '#f1fbff', mute: '#bfe4ef', ac: '#7ae7ff', ac2: '#ffd166' },
  };
  const clamp = (x, a, b) => Math.max(a, Math.min(b, x));
  const ease = (x) => 1 - Math.pow(1 - clamp(x, 0, 1), 3);
  const rnd = (i) => { const x = Math.sin(i * 127.1 + 311.7) * 43758.5453; return x - Math.floor(x); };
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const theme = (spec) => { const t = { ...(THEME[spec.theme] || THEME.dark) }; if (spec.accent) t.ac = spec.accent; return t; };
  V.sceneAt = (spec, t) => { let acc = 0; for (let i = 0; i < spec.scenes.length; i++) { const d = spec.scenes[i].duration; if (t < acc + d || i === spec.scenes.length - 1) return { i, s: spec.scenes[i], lt: clamp(t - acc, 0, d), start: acc }; acc += d; } return { i: 0, s: spec.scenes[0], lt: 0, start: 0 }; };

  // ---- 文字換行（中文逐字、英文整個字；行首不放標點）----
  const NOHEAD = '，。、！？；：）」』】》,.!?;:)';
  function wrap(g, text, maxW) {
    const toks = String(text || '').match(/[⺀-鿿豈-﫿＀-￯　-〿]|[^\s⺀-鿿豈-﫿＀-￯　-〿]+|\s+/g) || [];
    const lines = []; let cur = '';
    for (const tk of toks) {
      if (tk === '\n') { lines.push(cur); cur = ''; continue; }
      const nx = cur + tk; if (g.measureText(nx).width <= maxW || !cur.trim()) { cur = nx; continue; }
      if (NOHEAD.includes(tk)) { cur = nx; continue; }
      lines.push(cur.trimEnd()); cur = tk.trimStart();
    }
    if (cur.trim()) lines.push(cur.trimEnd()); return lines;
  }
  function text(g, str, x, y, { size, color, weight = 600, align = 'left', maxW, lh = 1.32, maxLines = 8 }) {
    g.font = `${weight} ${size}px ${FONT}`; g.fillStyle = color; g.textAlign = align; g.textBaseline = 'top';
    let lines = wrap(g, str, maxW); if (lines.length > maxLines) { lines = lines.slice(0, maxLines); lines[maxLines - 1] = lines[maxLines - 1].replace(/.$/, '…'); }
    lines.forEach((l, i) => g.fillText(l, x, y + i * size * lh)); return lines.length * size * lh;
  }
  function rrect(g, x, y, w, h, r) { g.beginPath(); g.moveTo(x + r, y); g.arcTo(x + w, y, x + w, y + h, r); g.arcTo(x + w, y + h, x, y + h, r); g.arcTo(x, y + h, x, y, r); g.arcTo(x, y, x + w, y, r); g.closePath(); }

  // ---- 背景：漸層＋慢慢飄的光點＋淡淡格線＋暗角 ----
  function background(g, W, H, th, sc, t) {
    const c = sc.bg && sc.bg.length ? [sc.bg[0], sc.bg[1] || th.bg[1]] : th.bg; const a = t * 0.08;
    const gr = g.createLinearGradient(W / 2 - Math.cos(a) * W, 0, W / 2 + Math.cos(a) * W, H); gr.addColorStop(0, c[0]); gr.addColorStop(1, c[1]); g.fillStyle = gr; g.fillRect(0, 0, W, H);
    for (let i = 0; i < 7; i++) { const x = (rnd(i) * W + Math.sin(t * 0.25 + i) * W * 0.08); const y = (rnd(i + 9) * H + Math.cos(t * 0.2 + i * 2) * H * 0.06); const r = (0.18 + rnd(i + 3) * 0.3) * Math.max(W, H);
      const rg = g.createRadialGradient(x, y, 0, x, y, r); rg.addColorStop(0, (i % 2 ? th.ac : th.ac2) + '2a'); rg.addColorStop(1, (i % 2 ? th.ac : th.ac2) + '00'); g.fillStyle = rg; g.fillRect(0, 0, W, H); }
    g.save(); g.globalAlpha = 0.06; g.strokeStyle = th.fg; g.lineWidth = 1; const step = W / 12; const off = (t * 12) % step;
    for (let x = -step + off; x < W; x += step) { g.beginPath(); g.moveTo(x, 0); g.lineTo(x, H); g.stroke(); } for (let y = -step + off; y < H; y += step) { g.beginPath(); g.moveTo(0, y); g.lineTo(W, y); g.stroke(); } g.restore();
    const vg = g.createRadialGradient(W / 2, H / 2, Math.min(W, H) * 0.3, W / 2, H / 2, Math.max(W, H) * 0.75); vg.addColorStop(0, '#0000'); vg.addColorStop(1, '#00000066'); g.fillStyle = vg; g.fillRect(0, 0, W, H);
  }
  function statParts(v) { const m = /^([^\d-]*)(-?[\d,]*\.?\d+)(.*)$/.exec(String(v)); if (!m) return null; const num = Number(m[2].replace(/,/g, '')); if (!isFinite(num)) return null; const dec = (m[2].split('.')[1] || '').length; return { pre: m[1], num, dec, suf: m[3], comma: m[2].includes(',') }; }
  const fmtNum = (n, dec, comma) => { const s = n.toFixed(dec); if (!comma) return s; const [a, b] = s.split('.'); return a.replace(/\B(?=(\d{3})+(?!\d))/g, ',') + (b ? '.' + b : ''); };

  /** 畫第 t 秒 */
  /** 字幕：旁白依字數切段、依時間顯示（和 HyperFrames 引擎同一套切法） */
  V.capAt = function (text, lt, d) {
    const parts = String(text || '').split(/(?<=[，。！？；、,.!?;])/).map((x) => x.trim()).filter(Boolean); const segs = []; let cur = '';
    for (const p of parts) { if ((cur + p).length > 22 && cur) { segs.push(cur); cur = p; } else cur += p; } if (cur) segs.push(cur); if (!segs.length) return '';
    const tot = segs.reduce((a, x) => a + x.length, 0); const span = Math.max(0.5, d - 0.4); let acc = 0.15; for (const x of segs) { const dd = span * x.length / tot; if (lt < acc + dd) return lt >= acc ? x : ''; acc += dd; } return segs[segs.length - 1];
  };
  // ---- Anti-gravity-engine4.5：免費虛擬主持人（虛構插畫角色，依旁白音量對嘴、眨眼、輕微擺動）----
  const LOOKS = [{ skin: '#f3cba5', hair: '#2b1d14', style: 'short', shirt: '#2f6fed' }, { skin: '#eab48c', hair: '#4a2c1a', style: 'long', shirt: '#d9467a', f: true }, { skin: '#c98e66', hair: '#141414', style: 'bun', shirt: '#1f9d74', f: true }, { skin: '#f6d6b8', hair: '#6b4a2e', style: 'glasses', shirt: '#7a5cff' }];
  /** 這一刻嘴巴張多開（0～1）：有嘴型軌跡就照軌跡；沒有（例如 MP3 旁白、預覽）就用文字產生的假對嘴 */
  V.mouthAt = function (s, lt) {
    const vt = lt - 0.15; if (vt < 0) return 0; const m = s.mouth;
    if (m) { const i = Math.floor(vt * 15); if (i >= m.length) return 0; const a = +m[i] || 0, b = +m[Math.min(m.length - 1, i + 1)] || 0; const f = vt * 15 - i; return (a + (b - a) * f) / 9; }
    const dur = s.voice_dur || (s.narration ? s.narration.length * 0.24 : 0); if (!s.narration || vt > dur) return 0;
    return clamp(0.35 + 0.45 * Math.sin(vt * 17) * Math.sin(vt * 5.3 + 1), 0, 1);
  };
  /** 從解碼後的旁白算嘴型軌跡（MP3 旁白用；和後台 mouthTrack 同規則） */
  V.mouthFromBuffer = function (b) { try { const d = b.getChannelData(0); const step = Math.max(1, Math.round(b.sampleRate / 15)); const rms = []; for (let o = 0; o < d.length && rms.length < 4000; o += step) { let s2 = 0, n = 0; for (let k = o; k < Math.min(o + step, d.length); k += 2) { s2 += d[k] * d[k]; n++; } rms.push(n ? Math.sqrt(s2 / n) : 0); } const ref = rms.slice().sort((a, c) => a - c)[Math.floor(rms.length * 0.95)] || 0; if (ref < 0.003) return ''; return rms.map((r) => { const x = r / ref; return x < 0.12 ? '0' : String(Math.min(9, Math.round(x * 9))); }).join(''); } catch { return ''; } };
  V.avatar = function (g, cx, cy, R, look, open, t, th) {
    const L = LOOKS[look % LOOKS.length]; const sway = Math.sin(t * 1.3) * 0.035 + open * 0.02; const blink = (t % 3.7) < 0.12 || ((t + 1.9) % 7.3) < 0.1;
    g.save(); g.beginPath(); g.arc(cx, cy, R, 0, Math.PI * 2); g.closePath();
    const bg = g.createLinearGradient(cx, cy - R, cx, cy + R); bg.addColorStop(0, th.ac2 || th.ac); bg.addColorStop(1, th.ac); g.fillStyle = bg; g.fill(); g.clip();
    // 肩膀與衣服
    g.fillStyle = L.shirt; g.beginPath(); g.ellipse(cx, cy + R * 1.02, R * 0.78, R * 0.5, 0, 0, Math.PI * 2); g.fill();
    g.fillStyle = '#ffffff55'; g.beginPath(); g.moveTo(cx - R * 0.16, cy + R * 0.55); g.lineTo(cx, cy + R * 0.75); g.lineTo(cx + R * 0.16, cy + R * 0.55); g.closePath(); g.fill();
    g.fillStyle = L.skin; g.fillRect(cx - R * 0.12, cy + R * 0.28, R * 0.24, R * 0.3);
    g.translate(cx, cy + R * 0.05); g.rotate(sway); g.translate(0, -open * R * 0.01);
    if (L.style === 'long') { g.fillStyle = L.hair; g.beginPath(); g.ellipse(-R * 0.34, R * 0.08, R * 0.15, R * 0.44, 0.08, 0, Math.PI * 2); g.ellipse(R * 0.34, R * 0.08, R * 0.15, R * 0.44, -0.08, 0, Math.PI * 2); g.fill(); }
    g.fillStyle = L.skin; g.beginPath(); g.ellipse(0, -R * 0.08, R * 0.38, R * 0.45, 0, 0, Math.PI * 2); g.fill();
    g.beginPath(); g.ellipse(-R * 0.38, -R * 0.06, R * 0.06, R * 0.1, 0, 0, Math.PI * 2); g.ellipse(R * 0.38, -R * 0.06, R * 0.06, R * 0.1, 0, 0, Math.PI * 2); g.fill();
    g.fillStyle = L.hair; g.beginPath(); g.ellipse(0, -R * 0.36, R * 0.41, R * 0.24, 0, Math.PI, Math.PI * 2); g.fill();
    g.beginPath(); g.ellipse(-R * 0.12, -R * 0.38, R * 0.3, R * 0.14, -0.35, 0, Math.PI * 2); g.fill();
    if (L.style === 'bun') { g.beginPath(); g.arc(0, -R * 0.6, R * 0.15, 0, Math.PI * 2); g.fill(); }
    if (L.style === 'short') { g.beginPath(); g.ellipse(R * 0.22, -R * 0.36, R * 0.2, R * 0.12, 0.4, 0, Math.PI * 2); g.fill(); }
    // 眉毛、眼睛
    g.strokeStyle = L.hair; g.lineWidth = R * (L.f ? 0.022 : 0.04); g.lineCap = 'round'; const by = -R * 0.2 - open * R * 0.015;
    g.beginPath(); g.moveTo(-R * 0.22, by); g.lineTo(-R * 0.08, by - R * 0.02); g.moveTo(R * 0.08, by - R * 0.02); g.lineTo(R * 0.22, by); g.stroke();
    g.fillStyle = '#1d1a24'; for (const ex of [-R * 0.15, R * 0.15]) { g.beginPath(); g.ellipse(ex, -R * 0.08, R * 0.045, blink ? R * 0.006 : R * 0.055, 0, 0, Math.PI * 2); g.fill(); if (!blink) { g.fillStyle = '#fff'; g.beginPath(); g.arc(ex + R * 0.015, -R * 0.1, R * 0.014, 0, Math.PI * 2); g.fill(); g.fillStyle = '#1d1a24'; } }
    if (L.f && !blink) { g.strokeStyle = '#1d1a24'; g.lineWidth = R * 0.014; g.beginPath(); for (const ex of [-R * 0.15, R * 0.15]) { const sgn = ex < 0 ? -1 : 1; g.moveTo(ex + sgn * R * 0.035, -R * 0.12); g.lineTo(ex + sgn * R * 0.07, -R * 0.15); } g.stroke(); }
    if (L.style === 'glasses') { g.strokeStyle = '#2a2a2a'; g.lineWidth = R * 0.022; g.beginPath(); g.arc(-R * 0.15, -R * 0.08, R * 0.1, 0, Math.PI * 2); g.moveTo(R * 0.25, -R * 0.08); g.arc(R * 0.15, -R * 0.08, R * 0.1, 0, Math.PI * 2); g.moveTo(-R * 0.05, -R * 0.09); g.lineTo(R * 0.05, -R * 0.09); g.stroke(); }
    g.fillStyle = '#ff7a8a44'; g.beginPath(); g.ellipse(-R * 0.24, R * 0.06, R * 0.07, R * 0.04, 0, 0, Math.PI * 2); g.ellipse(R * 0.24, R * 0.06, R * 0.07, R * 0.04, 0, 0, Math.PI * 2); g.fill();
    // 嘴巴：音量越大張越開
    const mh = R * (0.018 + open * 0.1), mw = R * (0.13 - open * 0.025); g.fillStyle = L.f ? '#b8324a' : '#7a2633'; g.beginPath(); g.ellipse(0, R * 0.16, mw, mh, 0, 0, Math.PI * 2); g.fill();
    if (open > 0.25) { g.fillStyle = '#ff8f9c'; g.beginPath(); g.ellipse(0, R * 0.16 + mh * 0.45, mw * 0.6, mh * 0.4, 0, 0, Math.PI * 2); g.fill(); }
    g.restore();
    g.save(); g.strokeStyle = th.ac; g.lineWidth = R * (0.05 + open * 0.05); g.globalAlpha = 0.55 + open * 0.45; g.beginPath(); g.arc(cx, cy, R + g.lineWidth / 2, 0, Math.PI * 2); g.stroke(); g.restore();
  };
  const ready = (v) => v && v.readyState >= 2 && v.videoWidth > 0;
  const cover = (g, src, W, H, z = 1, sw, sh) => { const r = Math.max(W / sw, H / sh) * z; const iw = sw * r, ih = sh * r; g.drawImage(src, (W - iw) / 2, (H - ih) / 2, iw, ih); };
  /** 畫第 t 秒。media＝{ images:[], footage:[<video>], presenter:<video> }（相容舊版：直接給圖片陣列） */
  V.frame = function (g, spec, t, imgs = []) {
    const M = Array.isArray(imgs) ? { images: imgs, footage: [], presenter: null } : { images: [], footage: [], presenter: null, ...(imgs || {}) };
    const W = spec.w, H = spec.h, k = W / 720, th = theme(spec), port = H > W * 1.2;
    const { i, s, lt } = V.sceneAt(spec, t); const d = s.duration;
    const enter = ease(lt / 0.65), exit = lt > d - 0.4 && i < spec.scenes.length - 1 ? clamp((d - lt) / 0.4, 0, 1) : 1;
    const pres = spec.presenter && ready(M.presenter) ? M.presenter : null;
    if (pres) { cover(g, pres, W, H, 1, pres.videoWidth, pres.videoHeight); const sh = g.createLinearGradient(0, H * 0.5, 0, H); sh.addColorStop(0, '#0000'); sh.addColorStop(1, '#000000b8'); g.fillStyle = sh; g.fillRect(0, H * 0.5, W, H * 0.5); }
    else background(g, W, H, th, s, t);
    const pad = 56 * k, maxW = W - pad * 2; let top = port ? H * 0.30 : H * 0.2;
    g.save(); g.globalAlpha = exit * (s.anim === 'fade' || s.anim === 'type' ? enter : Math.min(1, enter * 1.4));
    if (s.anim === 'slide') g.translate((1 - enter) * 70 * k, 0); else if (s.anim === 'zoom' && !['image', 'footage', 'screen', 'logo'].includes(s.layout) && !pres) { const z = 0.9 + 0.1 * enter; g.translate(W / 2, H / 2); g.scale(z, z); g.translate(-W / 2, -H / 2); }
    const typed = (str) => (s.anim === 'type' ? String(str).slice(0, Math.floor(String(str).length * clamp(lt / Math.max(0.6, String(str).length * 0.055), 0, 1))) : str);
    const accentBar = (x, y, w) => { const gr = g.createLinearGradient(x, 0, x + w, 0); gr.addColorStop(0, th.ac); gr.addColorStop(1, th.ac2); g.fillStyle = gr; rrect(g, x, y, Math.max(1, w), 7 * k, 4 * k); g.fill(); };
    const shadeBottom = () => { const sh = g.createLinearGradient(0, H * 0.45, 0, H); sh.addColorStop(0, '#0000'); sh.addColorStop(1, '#000000cc'); g.fillStyle = sh; g.fillRect(0, H * 0.45, W, H * 0.55); };
    const capR = (s.caption || s.narration) ? (port ? 110 : 80) * k : 0;   // 有字幕：下方文字與主持人卡片往上讓位，不跟字幕重疊
    const lowerText = () => { let y = H - (s.text ? 300 : 190) * k - (port ? 60 * k : 0) - capR; if (s.title) { accentBar(pad, y - 22 * k, 90 * k * enter); y += text(g, typed(s.title), pad, y, { size: 54 * k, color: '#fff', weight: 800, maxW, maxLines: 2 }) + 10 * k; } if (s.text) text(g, typed(s.text), pad, y, { size: 30 * k, color: '#e8ecf6', weight: 500, maxW, maxLines: 3 }); };
    if (pres) {
      // 主持人模式：主持人影片當背景，重點用玻璃卡片放在下方
      const cw = W - pad * 1.4, cx = pad * 0.7; const lines = s.bullets.length ? s.bullets.slice(0, 4) : []; const ch = (s.title ? 70 : 0) * k + (lines.length ? lines.length * 52 * k : s.stat ? 150 * k : s.text ? 90 * k : 0) + 40 * k; const cy = Math.max(H * 0.42, H - ch - (port ? 190 : 80) * k - capR * 0.8);
      if (ch > 50 * k) { g.save(); g.globalAlpha *= enter; g.translate(0, (1 - enter) * 30 * k); g.fillStyle = '#0b1020c4'; rrect(g, cx, cy, cw, ch, 22 * k); g.fill(); g.strokeStyle = th.ac + '66'; g.lineWidth = 2 * k; g.stroke();
        let y = cy + 22 * k; if (s.title) { y += text(g, s.title, cx + 26 * k, y, { size: 40 * k, color: '#fff', weight: 800, maxW: cw - 52 * k, maxLines: 1 }) + 8 * k; }
        if (s.stat) { const sp = statParts(s.stat.value); const pp = ease(lt / 1.3); g.font = `900 ${84 * k}px ${FONT}`; g.fillStyle = th.ac; g.textAlign = 'left'; g.textBaseline = 'top'; g.fillText(sp ? sp.pre + fmtNum(sp.num * pp, sp.dec, sp.comma) + sp.suf : s.stat.value, cx + 26 * k, y); y += 96 * k; if (s.stat.label) text(g, s.stat.label, cx + 26 * k, y, { size: 28 * k, color: '#dfe6f6', weight: 600, maxW: cw - 52 * k, maxLines: 1 }); }
        else if (lines.length) lines.forEach((b, j) => { const p = ease((lt - 0.4 - j * 0.35) / 0.4); if (p <= 0) return; g.save(); g.globalAlpha *= p; g.fillStyle = th.ac; rrect(g, cx + 26 * k, y + 12 * k, 14 * k, 14 * k, 4 * k); g.fill(); text(g, b, cx + 52 * k, y, { size: 32 * k, color: '#fff', weight: 600, maxW: cw - 80 * k, maxLines: 1 }); g.restore(); y += 52 * k; });
        else if (s.text) text(g, s.text, cx + 26 * k, y, { size: 30 * k, color: '#e8ecf6', weight: 500, maxW: cw - 52 * k, maxLines: 2 });
        g.restore(); }
    } else if (s.layout === 'footage') {
      const v = M.footage[i]; if (ready(v)) cover(g, v, W, H, 1 + 0.06 * (lt / d), v.videoWidth, v.videoHeight); else { const im = M.images[i]; if (im) cover(g, im, W, H, 1 + 0.08 * (lt / d), im.width, im.height); }
      shadeBottom(); lowerText();
    } else if (s.layout === 'screen') {
      // 產品畫面：真實網頁截圖放在瀏覽器框裡，鏡頭慢慢推近並往下掃（Video Shotcraft 式的頁面鏡頭）
      const im = M.images[i]; const fw = W * 0.86, fx = (W - fw) / 2, fy = H * (port ? 0.12 : 0.1), fh = H * (port ? 0.5 : 0.58); const z = 1 + 0.05 * (lt / d);
      g.save(); g.translate(W / 2, fy + fh / 2); g.scale(z, z); g.translate(-W / 2, -(fy + fh / 2));
      g.shadowColor = '#000a'; g.shadowBlur = 50 * k; g.shadowOffsetY = 24 * k; g.fillStyle = '#f4f6fb'; rrect(g, fx, fy, fw, fh, 18 * k); g.fill(); g.shadowColor = 'transparent';
      g.fillStyle = '#e3e7ef'; rrect(g, fx, fy, fw, 34 * k, 18 * k); g.fill(); ['#ff5f57', '#febc2e', '#28c840'].forEach((c, j) => { g.fillStyle = c; g.beginPath(); g.arc(fx + (22 + j * 18) * k, fy + 17 * k, 5.5 * k, 0, Math.PI * 2); g.fill(); });
      if (im) { g.save(); rrect(g, fx, fy + 34 * k, fw, fh - 34 * k, 0); g.clip(); const r = fw / im.width; const ih = im.height * r; const travel = Math.max(0, ih - (fh - 34 * k)); g.drawImage(im, fx, fy + 34 * k - travel * ease(lt / d) * 0.6, fw, ih); g.restore(); }
      g.restore();
      let y = fy + fh + 50 * k; if (s.title) { y += text(g, typed(s.title), pad, y, { size: 46 * k, color: th.fg, weight: 800, maxW, maxLines: 2 }) + 8 * k; } if (s.text) text(g, typed(s.text), pad, y, { size: 30 * k, color: th.mute, weight: 500, maxW, maxLines: 3 });
    } else if (s.layout === 'logo') {
      // Logo 動畫：圓形遮罩展開＋光暈＋回彈（Pixel2Motion 的簡化版；完整的向量化在 Termux 用官方 Pixel2Motion）
      const im = M.images[i]; const sz = Math.min(W, H) * 0.42; const p = ease(lt / 1.1); const bounce = 1 + Math.sin(clamp(lt / 1.1, 0, 1) * Math.PI) * 0.06; const cx = W / 2, cy = H * 0.42;
      g.save(); const gl = g.createRadialGradient(cx, cy, 0, cx, cy, sz); gl.addColorStop(0, th.ac + '55'); gl.addColorStop(1, th.ac + '00'); g.fillStyle = gl; g.fillRect(0, 0, W, H);
      g.beginPath(); g.arc(cx, cy, (sz * 0.75) * p, 0, Math.PI * 2); g.clip(); if (im) { const r = Math.min(sz / im.width, sz / im.height) * bounce; g.drawImage(im, cx - im.width * r / 2, cy - im.height * r / 2, im.width * r, im.height * r); } g.restore();
      if (s.title) text(g, s.title, W / 2, cy + sz * 0.62, { size: 48 * k, color: th.fg, weight: 800, align: 'center', maxW, maxLines: 2 });
    } else if (s.layout === 'image') {
      const im = M.images[i];
      if (im && s.anim === 'draw') {
        // 手繪故事：黑白線稿由左往右畫出來，再慢慢上色（story-to-handdrawn 的風格）
        const rv = clamp(lt / Math.min(1.6, d * 0.4), 0, 1), col = clamp((lt - Math.min(1.6, d * 0.4)) / Math.min(1.8, d * 0.4), 0, 1); g.save(); g.fillStyle = '#fbfaf7'; g.fillRect(0, 0, W, H);
        g.beginPath(); g.rect(0, 0, W * ease(rv), H); g.clip(); g.filter = `grayscale(${1 - col}) contrast(${1.6 - 0.6 * col})`; const r = Math.min(W / im.width, (H * 0.72) / im.height) * (1 + 0.04 * (lt / d)); g.drawImage(im, (W - im.width * r) / 2, H * 0.06, im.width * r, im.height * r); g.filter = 'none'; g.restore();
        let y = H * 0.06 + Math.min(H * 0.72, im.height * Math.min(W / im.width, (H * 0.72) / im.height)) + 28 * k; if (s.title) y += text(g, typed(s.title), W / 2, y, { size: 44 * k, color: '#1a1a1a', weight: 800, align: 'center', maxW, maxLines: 2 }) + 6 * k; if (s.text) text(g, typed(s.text), W / 2, y, { size: 30 * k, color: '#3a3a3a', weight: 500, align: 'center', maxW, maxLines: 3 });
      } else {
        if (im) { const z = 1 + 0.12 * (lt / d); const r = Math.max(W / im.width, H / im.height) * z; const iw = im.width * r, ih = im.height * r; g.drawImage(im, (W - iw) / 2, (H - ih) / 2, iw, ih); }
        shadeBottom(); lowerText();
      }
    } else if (s.layout === 'title' || s.layout === 'end') {
      const cy = H * (port ? 0.40 : 0.36); g.font = `800 ${(port ? 76 : 70) * k}px ${FONT}`; const lines = wrap(g, s.title || s.text, maxW); const tH = lines.length * (port ? 76 : 70) * k * 1.22;
      if (s.layout === 'end') { g.save(); g.globalAlpha *= 0.35; g.strokeStyle = th.ac; g.lineWidth = 3 * k; g.beginPath(); g.arc(W / 2, cy + tH / 2, (Math.min(W, H) * 0.36) * (0.85 + 0.15 * enter), 0, Math.PI * 2); g.stroke(); g.restore(); }
      text(g, typed(s.title || s.text), W / 2, cy, { size: (port ? 76 : 70) * k, color: th.fg, weight: 800, align: 'center', maxW, lh: 1.22, maxLines: 4 });
      accentBar(W / 2 - 70 * k * enter, cy + tH + 22 * k, 140 * k * enter);
      if (s.title && s.text) text(g, s.text, W / 2, cy + tH + 56 * k, { size: 32 * k, color: th.mute, weight: 500, align: 'center', maxW: maxW * 0.9, maxLines: 4 });
      if (s.layout === 'end' && spec.credits && spec.credits.length) text(g, '素材：' + spec.credits.join('、'), W / 2, H - (port ? 230 : 110) * k, { size: 20 * k, color: th.mute, weight: 500, align: 'center', maxW, maxLines: 2 });
    } else if (s.layout === 'bullets') {
      if (s.title) { text(g, s.title, pad, top - 30 * k, { size: 52 * k, color: th.fg, weight: 800, maxW, maxLines: 2 }); accentBar(pad, top - 50 * k, 80 * k * enter); }
      let y = top + (s.title ? 110 : 20) * k; const step = Math.min(0.55, (d - 1.2) / Math.max(1, s.bullets.length));
      s.bullets.forEach((b, j) => { const p = ease((lt - 0.35 - j * step) / 0.45); if (p <= 0) { g.font = `600 ${36 * k}px ${FONT}`; y += Math.max(1, wrap(g, b, maxW - 60 * k).length) * 36 * k * 1.3 + 26 * k; return; }
        g.save(); g.globalAlpha *= p; g.translate((1 - p) * -40 * k, 0); g.fillStyle = th.ac; rrect(g, pad, y + 6 * k, 30 * k, 30 * k, 9 * k); g.fill(); g.fillStyle = th.bg[0]; g.font = `800 ${20 * k}px ${FONT}`; g.textAlign = 'center'; g.textBaseline = 'top'; g.fillText(String(j + 1), pad + 15 * k, y + 10 * k);
        const h = text(g, b, pad + 50 * k, y, { size: 36 * k, color: th.fg, weight: 600, maxW: maxW - 60 * k, maxLines: 3 }); g.restore(); y += h + 26 * k; });
    } else if (s.layout === 'stat') {
      const sp = statParts(s.stat.value); const p = ease(lt / 1.3); const val = sp ? sp.pre + fmtNum(sp.num * p, sp.dec, sp.comma) + sp.suf : s.stat.value; const cy = H * (port ? 0.36 : 0.30);
      g.font = `900 ${150 * k}px ${FONT}`; let size = 150 * k; while (g.measureText(val).width > maxW && size > 50 * k) { size -= 6 * k; g.font = `900 ${size}px ${FONT}`; }
      const gr = g.createLinearGradient(0, cy, 0, cy + size); gr.addColorStop(0, th.ac); gr.addColorStop(1, th.ac2); g.fillStyle = gr; g.textAlign = 'center'; g.textBaseline = 'top'; g.fillText(val, W / 2, cy);
      let y = cy + size * 1.15; if (s.stat.label) y += text(g, s.stat.label, W / 2, y, { size: 38 * k, color: th.fg, weight: 700, align: 'center', maxW, maxLines: 2 }) + 14 * k;
      if (s.title) y += text(g, s.title, W / 2, y, { size: 30 * k, color: th.mute, weight: 500, align: 'center', maxW, maxLines: 2 }); if (s.text) text(g, s.text, W / 2, y + 10 * k, { size: 28 * k, color: th.mute, weight: 500, align: 'center', maxW, maxLines: 3 });
    } else if (s.layout === 'quote') {
      g.font = `900 ${200 * k}px Georgia,serif`; g.fillStyle = th.ac; g.globalAlpha *= 0.9; g.textAlign = 'left'; g.textBaseline = 'top'; g.fillText('“', pad - 10 * k, top - 150 * k); g.globalAlpha = exit * enter;
      const h = text(g, typed(s.text || s.title), pad, top + 40 * k, { size: 44 * k, color: th.fg, weight: 600, maxW, lh: 1.45, maxLines: 7 });
      if (s.title && s.text) text(g, '— ' + s.title, pad, top + 70 * k + h, { size: 30 * k, color: th.mute, weight: 500, maxW });
    } else {
      let y = top - 20 * k; if (s.title) { accentBar(pad, y - 26 * k, 80 * k * enter); y += text(g, typed(s.title), pad, y, { size: 56 * k, color: th.fg, weight: 800, maxW, maxLines: 3 }) + 26 * k; }
      if (s.text) text(g, typed(s.text), pad, y, { size: 36 * k, color: s.title ? th.mute : th.fg, weight: s.title ? 500 : 600, maxW, lh: 1.5, maxLines: 9 });
    }
    g.restore();
    // 免費虛擬主持人：右上角小窗（主持人風格放大），依旁白對嘴
    if (spec.avatar && !pres) { const big = spec.style === 'presenter'; const R = (port ? (big ? 130 : 100) : (big ? 95 : 75)) * k; const cx = W - pad * 0.6 - R, cy = (port ? 70 : 40) * k + R; g.save(); g.globalAlpha = 1; V.avatar(g, cx, cy, R, spec.avatar.look || 0, s.voice || s.narration ? V.mouthAt(s, lt) : 0, t, th); g.restore(); }
    // 字幕
    const capText = s.caption || (s.narration ? V.capAt(s.narration, lt, d) : '');
    if (capText) { g.save(); g.globalAlpha = s.caption ? exit * enter : 1; g.font = `600 ${28 * k}px ${FONT}`; const lines = wrap(g, capText, W - pad * 2.4).slice(0, 2); const bh = lines.length * 28 * k * 1.35 + 24 * k; const by = H - bh - (port ? 150 : 70) * k;
      g.fillStyle = '#000000a8'; rrect(g, pad * 0.8, by, W - pad * 1.6, bh, 14 * k); g.fill(); g.fillStyle = '#fff'; g.textAlign = 'center'; g.textBaseline = 'top'; lines.forEach((l, j) => g.fillText(l, W / 2, by + 12 * k + j * 28 * k * 1.35)); g.restore(); }
    // 標題浮水印＋進度條
    if (spec.watermark && spec.title && i > 0) { g.save(); g.globalAlpha = 0.55; g.font = `600 ${22 * k}px ${FONT}`; g.fillStyle = th.fg; g.textAlign = 'left'; g.textBaseline = 'top'; g.fillText(spec.title.slice(0, 24), pad * 0.7, 34 * k); g.restore(); }
    g.save(); g.globalAlpha = 0.85; const gr = g.createLinearGradient(0, 0, W, 0); gr.addColorStop(0, th.ac); gr.addColorStop(1, th.ac2); g.fillStyle = gr; g.fillRect(0, H - 6 * k, W * clamp(t / spec.duration, 0, 1), 6 * k); g.restore();
  };

  // ---- 背景音樂合成（不用音檔）----
  V.synth = function (ac, dest, kind, total, vol = 0.16) {
    if (!kind || kind === 'none') return; const t0 = ac.currentTime + 0.05; const master = ac.createGain(); master.gain.setValueAtTime(0, t0); master.gain.linearRampToValueAtTime(vol, t0 + 0.8); master.gain.setValueAtTime(vol, t0 + Math.max(1, total - 1.6)); master.gain.linearRampToValueAtTime(0, t0 + total); master.connect(dest);
    const CH = [[261.63, 329.63, 392.0], [196.0, 246.94, 293.66], [220.0, 261.63, 329.63], [174.61, 220.0, 261.63]];
    const note = (f, at, dur, type, vol, atk = 0.02, rel = 0.3) => { if (at > t0 + total) return; const o = ac.createOscillator(); const gn = ac.createGain(); o.type = type; o.frequency.setValueAtTime(f, at); gn.gain.setValueAtTime(0, at); gn.gain.linearRampToValueAtTime(vol, at + atk); gn.gain.setValueAtTime(vol, at + Math.max(atk, dur - rel)); gn.gain.linearRampToValueAtTime(0, at + dur); o.connect(gn); gn.connect(master); o.start(at); o.stop(at + dur + 0.05); };
    if (kind === 'calm') { const bar = 4; for (let b = 0; b * bar < total; b++) { const c = CH[b % 4]; const at = t0 + b * bar; c.forEach((f) => { note(f, at, bar + 0.6, 'sine', 0.18, 0.9, 1.2); note(f * 2, at, bar + 0.6, 'triangle', 0.03, 1.2, 1.2); }); note(c[0] / 2, at, bar, 'sine', 0.22, 0.4, 0.8);
      for (let j = 0; j < 4; j++) note(c[(j + b) % 3] * 2, at + j, 0.9, 'sine', 0.05, 0.01, 0.6); } }
    else if (kind === 'upbeat') { const beat = 0.5; const noise = ac.createBuffer(1, ac.sampleRate * 0.05, ac.sampleRate); const nd = noise.getChannelData(0); for (let n = 0; n < nd.length; n++) nd[n] = Math.random() * 2 - 1;
      for (let b = 0; b * beat < total; b++) { const at = t0 + b * beat; const c = CH[Math.floor(b / 4) % 4];
        const kk = ac.createOscillator(); const kg = ac.createGain(); kk.frequency.setValueAtTime(130, at); kk.frequency.exponentialRampToValueAtTime(42, at + 0.14); kg.gain.setValueAtTime(0.55, at); kg.gain.exponentialRampToValueAtTime(0.001, at + 0.18); kk.connect(kg); kg.connect(master); kk.start(at); kk.stop(at + 0.2);
        const hs = ac.createBufferSource(); hs.buffer = noise; const hp = ac.createBiquadFilter(); hp.type = 'highpass'; hp.frequency.value = 7000; const hg = ac.createGain(); hg.gain.value = 0.12; hs.connect(hp); hp.connect(hg); hg.connect(master); hs.start(at + beat / 2);
        c.forEach((f) => note(f, at, 0.28, 'triangle', 0.07, 0.01, 0.2)); if (b % 2 === 0) note(c[0] / 2, at, 0.45, 'sawtooth', 0.05, 0.01, 0.2); } }
    else { const lp = ac.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 900; lp.connect(master);
      const drone = (f, vol) => { const o = ac.createOscillator(); const gn = ac.createGain(); o.type = 'sawtooth'; o.frequency.value = f; gn.gain.value = vol; o.connect(gn); gn.connect(lp); o.start(t0); o.stop(t0 + total + 0.1); }; drone(65.41, 0.08); drone(98.0, 0.05);
      for (let b = 0; b * 8 < total; b++) { const c = CH[(b * 2) % 4]; c.forEach((f) => note(f, t0 + b * 8, 8.5, 'sine', 0.12, 3, 3)); note(c[2] * 2, t0 + b * 8 + 4, 3, 'sine', 0.05, 1, 1.5); } }
  };

  function pickMime(audio) {
    const L = audio ? ['video/mp4;codecs=avc1.42E01E,mp4a.40.2', 'video/mp4;codecs=avc1,mp4a', 'video/mp4', 'video/webm;codecs=vp9,opus', 'video/webm;codecs=vp8,opus', 'video/webm'] : ['video/mp4;codecs=avc1.42E01E', 'video/mp4', 'video/webm;codecs=vp9', 'video/webm;codecs=vp8', 'video/webm'];
    return L.find((m) => window.MediaRecorder && MediaRecorder.isTypeSupported(m)) || '';
  }
  const tok = (u) => LA.rw(u) + (u.includes('?') ? '&' : '?') + 't=' + encodeURIComponent(LA.token);
  const loadImg = (u) => (u ? new Promise((ok) => { const im = new Image(); im.onload = () => ok(im); im.onerror = () => ok(null); im.src = tok(u); }) : Promise.resolve(null));
  const loadVid = (u, muted = true) => (u ? new Promise((ok) => { const v = document.createElement('video'); v.muted = muted; v.playsInline = true; v.preload = 'auto'; v.crossOrigin = 'anonymous'; let done = false; const fin = (x) => { if (!done) { done = true; ok(x); } }; v.oncanplay = () => fin(v); v.onerror = () => fin(null); setTimeout(() => fin(v.readyState >= 2 ? v : null), 15000); v.src = tok(u); v.load(); }) : Promise.resolve(null));
  /** 素材：舊格式（圖片網址陣列）或新格式 { scenes:[{image,footage,voice}], presenter } */
  V.loadAssets = async function (job) {
    const A = job.assets || []; const sc = Array.isArray(A) ? A.map((u) => ({ image: u })) : (A.scenes || []);
    const [images, footage, presenter] = await Promise.all([Promise.all(sc.map((x) => loadImg(x && x.image))), Promise.all(sc.map((x) => loadVid(x && x.footage))), loadVid(!Array.isArray(A) && A.presenter, false)]);
    return { images, footage, presenter, voices: sc.map((x) => (x && x.voice) || '') };
  };
  V.loadImages = (job) => V.loadAssets(job).then((m) => m.images);
  /** 錄一支影片 → { blob, mime, audio }；signal.aborted 時中止 */
  V.record = async function (job, { onProgress, signal } = {}) {
    if (!window.MediaRecorder || !HTMLCanvasElement.prototype.captureStream) throw new Error('這個畫面不支援錄影（需要較新的 Android System WebView／Chrome）');
    const spec = JSON.parse(JSON.stringify(job.spec)); const M = await V.loadAssets(job);
    const cv = document.createElement('canvas'); cv.width = spec.w; cv.height = spec.h; cv.style.cssText = 'position:fixed;left:-20000px;top:0;width:2px;height:2px;opacity:0;pointer-events:none'; document.body.appendChild(cv);
    const g = cv.getContext('2d'); const stream = cv.captureStream(spec.fps || 30);
    let ac = null, dest = null; const AC = window.AudioContext || window.webkitAudioContext;
    const needAudio = (spec.music && spec.music !== 'none') || M.voices.some(Boolean) || M.presenter;
    try { if (needAudio && AC) { ac = new AC(); await Promise.race([ac.resume(), sleep(800)]); if (ac.state === 'running') dest = ac.createMediaStreamDestination(); } } catch { dest = null; }
    // 旁白：解碼後量長度，念不完的格自動拉長（影片總長跟著變）
    const voiceBufs = []; if (dest) { for (let i = 0; i < M.voices.length; i++) { if (!M.voices[i]) continue; try { const ab = await (await fetch(tok(M.voices[i]))).arrayBuffer(); const b = await ac.decodeAudioData(ab); voiceBufs[i] = b; if (!spec.scenes[i].mouth) spec.scenes[i].mouth = V.mouthFromBuffer(b); const need = b.duration + 0.75; if (spec.scenes[i].duration < need) spec.scenes[i].duration = Math.round(need * 10) / 10; } catch { /* 這格沒聲音 */ } } spec.duration = Math.round(spec.scenes.reduce((a, x) => a + x.duration, 0) * 10) / 10; }
    if (M.presenter && M.presenter.duration && isFinite(M.presenter.duration)) { const tot = spec.scenes.reduce((a, x) => a + x.duration, 0); const k = M.presenter.duration / tot; if (k > 0.5 && k < 2) { spec.scenes.forEach((x) => { x.duration *= k; }); spec.duration = M.presenter.duration; } }
    V.frame(g, spec, 0, M);
    if (dest) {
      const hasVoice = voiceBufs.some(Boolean) || !!M.presenter; V.synth(ac, dest, spec.music, spec.duration + 0.2, hasVoice ? 0.06 : 0.16);
      let acc = 0; const t0 = ac.currentTime + 0.1; spec.scenes.forEach((x, i) => { const b = voiceBufs[i]; if (b) { const src = ac.createBufferSource(); src.buffer = b; const gn = ac.createGain(); gn.gain.value = 1; src.connect(gn); gn.connect(dest); src.start(t0 + acc + 0.15); } acc += x.duration; });
      if (M.presenter) { try { const src = ac.createMediaElementSource(M.presenter); src.connect(dest); } catch { /* 主持人沒聲音 */ } }
      const tr = dest.stream.getAudioTracks()[0]; if (tr) stream.addTrack(tr);
    } else if (M.voices.some(Boolean)) throw new Error('這個畫面不能錄聲音（AudioContext 無法啟動），旁白會錄不進去');
    const audio = stream.getAudioTracks().length > 0; const mime = pickMime(audio); if (!mime) throw new Error('這個畫面沒有可用的影片編碼器');
    const rec = new MediaRecorder(stream, { mimeType: mime, videoBitsPerSecond: 2500000, audioBitsPerSecond: 128000 }); const chunks = []; rec.ondataavailable = (e) => { if (e.data && e.data.size) chunks.push(e.data); };
    const stopped = new Promise((r) => { rec.onstop = r; });
    let curScene = -1;
    const playScene = (i) => { M.footage.forEach((v, j) => { if (v && j !== i) { try { v.pause(); } catch { /* ignore */ } } }); const v = M.footage[i]; if (v) { try { v.currentTime = 0; v.loop = true; v.play().catch(() => {}); } catch { /* ignore */ } } };
    try {
      if (M.presenter) { M.presenter.currentTime = 0; await M.presenter.play().catch(() => {}); }
      rec.start(1000); const t0 = performance.now(); let lastP = -1;
      await new Promise((resolve, reject) => { const tick = () => { if (signal && signal.aborted) return reject(new Error(signal.reason || '中止')); const t = (performance.now() - t0) / 1000; const sc = V.sceneAt(spec, Math.min(t, spec.duration)).i; if (sc !== curScene) { curScene = sc; playScene(sc); } V.frame(g, spec, Math.min(t, spec.duration), M); const p = Math.floor(clamp(t / spec.duration, 0, 1) * 100); if (p !== lastP && onProgress) { lastP = p; onProgress(p); } if (t >= spec.duration + 0.3) return resolve(); setTimeout(tick, 1000 / (spec.fps || 30)); }; tick(); });
    } finally { try { if (rec.state !== 'inactive') rec.stop(); } catch { /* ignore */ } await Promise.race([stopped, sleep(3000)]); stream.getTracks().forEach((x) => x.stop()); M.footage.forEach((v) => { if (v) { try { v.pause(); v.removeAttribute('src'); v.load(); } catch { /* ignore */ } } }); if (M.presenter) { try { M.presenter.pause(); } catch { /* ignore */ } } if (ac) ac.close().catch(() => {}); cv.remove(); }
    if (signal && signal.aborted) throw new Error(signal.reason || '中止');
    const type = mime.split(';')[0]; return { blob: new Blob(chunks, { type }), mime: type, audio };
  };

  // ---- 背景工作：有排隊的影片就領來做 ----
  let busy = false; let chip = null;
  const showChip = (txt) => { if (!chip) { chip = document.createElement('button'); chip.id = 'vchip'; chip.className = 'vchip'; chip.onclick = () => LA.go('video'); document.body.appendChild(chip); } chip.hidden = !txt; chip.innerHTML = txt ? `${LA.icon('film')}<span>${LA.esc(txt)}</span>` : ''; };
  V.busy = () => busy;
  V.runOnce = async function () {
    if (busy || document.visibilityState !== 'visible' || LA.web || (LA.link && LA.link.mode === 'client')) return false;
    const q = await LA.api('/api/video/queue').catch(() => null); if (!q || !q.pending) return false;
    const r = await LA.post('/api/video/claim', { worker: 'app' }).catch(() => null); const job = r && r.job; if (!job) return false;
    busy = true; const ctl = new AbortController(); const onHide = () => { if (document.visibilityState !== 'visible') ctl.abort('App 畫面切到背景'); }; document.addEventListener('visibilitychange', onHide);
    let lastPost = 0; showChip(`影片製作中 0%`);
    try {
      const out = await V.record(job, { signal: ctl.signal, onProgress: (p) => { showChip(`影片製作中 ${p}%`); if (Date.now() - lastPost > 2000) { lastPost = Date.now(); LA.post(`/api/video/${job.id}/progress`, { progress: p }).catch(() => {}); } if (V.onProgress) V.onProgress(job.id, p); } });
      showChip('影片上傳中…');
      const res = await fetch(LA.rw(`/api/video/${job.id}/upload?mime=${encodeURIComponent(out.mime)}`), { method: 'POST', headers: { authorization: 'Bearer ' + LA.token, 'content-type': 'application/octet-stream' }, body: out.blob });
      const j = await res.json().catch(() => ({})); if (!res.ok) throw new Error(j.error || '上傳失敗');
      LA.toast(`影片「${job.spec.title}」做好了`); if (V.onDone) V.onDone(job.id);
    } catch (e) {
      const requeue = ctl.signal.aborted; await LA.post(`/api/video/${job.id}/fail`, { error: e.message, requeue }).catch(() => {}); if (!requeue) LA.toast('影片做不出來：' + e.message, true);
    } finally { document.removeEventListener('visibilitychange', onHide); busy = false; showChip(''); }
    return true;
  };
  V.start = () => { if (V._t) return; const loop = async () => { try { await V.runOnce(); } catch { /* ignore */ } V._t = setTimeout(loop, busy ? 3000 : 6000); }; V._t = setTimeout(loop, 2500); };
  if (document.readyState === 'complete') V.start(); else window.addEventListener('load', V.start);
})();
