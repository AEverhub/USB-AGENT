'use strict';
/**
 * 新手教學（26.12.3 重做）：不用卡片。畫面變暗、要點的地方挖一個亮洞、半透明手指在上面點／滑，
 * 使用者「真的點那個地方」才進到下一步；右上角隨時可以「跳過」。
 * 步驟：
 *   tap   手指點擊動畫；點亮起來的地方才繼續（pass=true 時同時真的按下去）
 *   swipe 手指滑動動畫；在亮起來的區域點一下就繼續
 */
(function () {
  // Anti-gravity-engine2：教學只在「第一次」出現。固定的記錄鍵（以後改版不再換鍵、不會再跳一次），舊版 la_tutorial_v*_seen 也算看過；
  // 同時記在後端（/api/ui/flags 的 tutorial_seen），而且「一顯示就記錄」——中途關掉 App、或 WebView 還沒把 localStorage 寫進磁碟就被砍，重開都不會再出現。
  const SEEN = 'la_tutorial_seen';
  const HAND = '<svg viewBox="0 0 64 64" width="58" height="58"><path fill="rgba(255,255,255,.92)" stroke="rgba(20,30,50,.55)" stroke-width="2" stroke-linejoin="round" d="M24 6c2.8 0 5 2.2 5 5v17.5l1.3-.4V22c0-2.6 2-4.6 4.6-4.6s4.6 2 4.6 4.6v6.4l1.2.1v-3.9c0-2.5 2-4.5 4.5-4.5s4.5 2 4.5 4.5v5.2l.7.2V28c0-2.3 1.9-4.2 4.2-4.2S59 25.7 59 28v13.5C59 53 50.6 60 40 60h-3.5c-6.4 0-11-2.5-14.6-7.6L9.6 35.6c-1.4-2-1-4.8 1-6.3 1.9-1.4 4.6-1.1 6.1.7L19 33V11c0-2.8 2.2-5 5-5z"/><circle cx="24" cy="10" r="3.2" fill="rgba(125,180,255,.95)"/></svg>';
  const STEPS = [
    { page: 'home', target: '#c-in', kind: 'tap', title: '有事直接跟它說', text: '像傳 LINE 一樣打字或用說的，記帳、查東西、掛號、做檔案都可以。', hint: '點一下輸入框' },
    { page: 'home', target: '#c-mic', kind: 'tap', title: '懶得打字就用說的', text: '按一下麥克風開始說，講完停一下就會變成文字；長按或到「語音模式」可以一來一往用講的。', hint: '點一下麥克風' },
    { page: 'home', target: '#tp-toggle', kind: 'tap', title: '排程與長期任務', text: '跟它說「明天 8 點提醒我開會」「每週一、四晚上倒垃圾」，排好的事都在這條長條裡；點開可以暫停、修改、取消。', hint: '點一下這條長條' },
    { page: 'home', target: '#c-menu', kind: 'tap', pass: true, before: () => { const w = document.querySelector('#c-menuwrap'); if (w) w.hidden = true; }, title: '服務選單', text: '點這個按鈕打開選單，常用的事一按就辦。', hint: '點一下這個按鈕' },
    { page: 'home', target: '#c-menuwrap', kind: 'swipe', title: '選單會一直在這', text: '掃發票記帳、叫外送、網路掛號…都在這裡；最後一格「編輯選單」可以自己加按鈕。', hint: '點一下選單區域繼續' },
    { page: 'home', target: '#c-plus', kind: 'tap', title: '拍照、掃 QR、做檔案', text: '拍發票或收據會自動記帳；也能請它把資料做成 Excel、Word、PDF。', hint: '點一下 ＋' },
    { page: 'home', target: '#c-list', kind: 'swipe', swipeY: true, title: '對話會一直留著', text: '照片、檔案都留在對話裡；往上滑就能看更早的訊息，右上角放大鏡可以搜尋。', hint: '點一下對話區繼續' },
    { target: '#tabs [data-id="browser"]', kind: 'tap', title: '讓 AI 自己上網辦事', text: '在「瀏覽器」安裝內建 Linux（含 Chromium），AI 就能自己登入網站、掛號、訂東西。', hint: '點一下「瀏覽器」' },
    { target: '#tabs [data-id="ops"]', kind: 'tap', title: '監控', text: 'Bot 狀態、待審批、用了多少 token、終端機與通知都在這。', hint: '點一下「監控」' },
    { page: 'more', target: '[data-go="logic"]', kind: 'tap', title: '內建工具', text: '邏輯閘轉換器、電路工具、程式碼工具都在「更多」最上面；AI 也能直接操作這些工具的畫面。', hint: '點一下這個工具' },
    { page: 'more', target: '#more-help', kind: 'tap', title: '完整的使用指南在這', text: '每個功能怎麼用、可以怎麼說、遇到問題怎麼辦，都寫在「使用指南」；還有新手任務清單可以照著做一遍。', hint: '點一下「使用指南」' },
    { target: '#tabs [data-id="more"]', kind: 'tap', title: '先設定 AI 模型', text: '「更多 → 模型與金鑰」貼上 Gemini／Claude／ChatGPT 等金鑰；人設、連接器、權限也在這。要跟遠方的人一起用：「更多 → 開發者 → 聯機」產生連線連結傳給對方。', hint: '點一下「更多」完成教學' },
  ];
  let root = null; let i = 0; let raf = 0;
  const $ = (s) => document.querySelector(s);
  const wait = (sel, ms = 2500) => new Promise((res) => { const t0 = Date.now(); (function poll() { const el = $(sel); if (el && el.getBoundingClientRect().width) return res(el); if (Date.now() - t0 > ms) return res(null); setTimeout(poll, 80); })(); });
  function closeCoach() { cancelAnimationFrame(raf); window.removeEventListener('resize', place); if (root) root.remove(); root = null; }
  function markSeen() { try { localStorage.setItem(SEEN, '1'); } catch { /* ignore */ } if (LA.post && !LA.web) LA.post('/api/ui/flags', { key: 'tutorial_seen', value: true }).catch(() => {}); }
  function end(done) { markSeen(); closeCoach(); if (done) finishCard(); }
  // Anti-gravity-engine1：全螢幕卡片（歡迎／完成）
  function card(html) { const c = document.createElement('div'); c.className = 'coach-card'; c.innerHTML = `<div class="coach-panel">${html}</div>`; document.body.appendChild(c); return c; }
  function welcome() {
    const c = card(`<div class="coach-badge">${LA.icon('wave')}</div>
      <h2>歡迎使用${LA.icon ? '' : ''}</h2>
      <p class="sub">我是你的 AI 助理。像傳訊息一樣交代事情，我會自己動手把它做完。</p>
      <div class="coach-feats">
        <div>${LA.icon('send')}<span><b>直接說、直接做</b>　記帳、查資料、掛號、做 Excel／Word／PDF，打字或用說的都行。</span></div>
        <div>${LA.icon('sun')}<span><b>會排程、會提醒</b>　「每週一提醒我開會」這類長期任務都幫你盯著。</span></div>
        <div>${LA.icon('grid')}<span><b>工具與代理</b>　內建理工、資安、瀏覽器與手機代理，能自己上網辦事。</span></div>
      </div>
      <div class="row"><button class="coach-btn ghost" id="cw-skip">略過</button><button class="coach-btn pri" id="cw-go">開始導覽（約 1 分鐘）</button></div>
      <div class="coach-step">隨時可以在「設定／說明」重看這個導覽</div>`);
    c.addEventListener('click', (e) => {
      if (e.target.closest('#cw-go')) { c.remove(); runCoach(); }
      else if (e.target.closest('#cw-skip')) { c.remove(); markSeen(); finishCard(); }
    });
  }
  function finishCard() {
    const cli = LA.link && LA.link.mode === 'client';
    const noKey = !cli && LA.status && LA.status.model && !LA.status.model.has_key;
    const c = card(`<div class="coach-badge">${LA.icon('help')}</div>
      <h2>準備好了</h2>
      <p class="sub">${noKey ? '最後一步：貼上 AI 模型金鑰，我才能開始回話。' : '想做什麼直接跟我說就好。需要時可以隨時打開「使用指南」。'}</p>
      <div class="row">${noKey ? '<button class="coach-btn ghost" id="cf-guide">看指南</button><button class="coach-btn pri" id="cf-model">去設定模型</button>' : '<button class="coach-btn ghost" id="cf-guide">看使用指南</button><button class="coach-btn pri" id="cf-done">開始使用</button>'}</div>`);
    c.addEventListener('click', (e) => {
      if (e.target.closest('#cf-model')) { c.remove(); LA.go('models'); }
      else if (e.target.closest('#cf-guide')) { c.remove(); LA.go('more').then(() => { const h = LA.$('#more-help'); if (h) h.click(); }); }
      else if (e.target.closest('#cf-done') || e.target === c) c.remove();
    });
  }
  function place() {
    if (!root) return; const s = STEPS[i]; const el = $(s.target); if (!el) return;
    const r = el.getBoundingClientRect(); const pad = 6; const vh = window.innerHeight;
    const top = Math.max(4, r.top - pad); const h = Math.min(r.height + pad * 2, vh - top - 4);
    Object.assign(root.querySelector('.coach-hole').style, { left: r.left - pad + 'px', top: top + 'px', width: r.width + pad * 2 + 'px', height: h + 'px' });
    const hand = root.querySelector('.coach-hand'); hand.className = 'coach-hand ' + s.kind;
    if (s.kind === 'swipe' && s.swipeY) hand.style.animation = 'none';
    hand.style.left = Math.min(window.innerWidth - 64, r.left + r.width / 2 - 14) + 'px'; hand.style.top = Math.min(vh - 64, top + Math.min(h, 160) / 2 - 6) + 'px';
    const tip = root.querySelector('.coach-tip'); const below = top + h + 150 < vh - 40; tip.style.top = below ? top + h + 22 + 'px' : Math.max(70, top - 150) + 'px';
  }
  async function step(n) {
    i = n; if (i >= STEPS.length) return end(true); const s = STEPS[i];
    if (s.page && LA.cur !== s.page) await LA.go(s.page);
    if (s.before) s.before();
    const el = await wait(s.target); if (!el) return step(i + 1);   // 這一步的東西不在畫面上就跳過
    if (!root) return;
    root.querySelector('.coach-tip').innerHTML = `<b>${s.title}</b>${s.text}<small>${s.hint}</small>`;
    root.querySelector('.coach-dots').innerHTML = STEPS.map((_, k) => `<i class="${k === i ? 'on' : ''}"></i>`).join('');
    place();
  }
  function start() { document.querySelectorAll('.coach-card').forEach((x) => x.remove()); closeCoach(); markSeen(); welcome(); }   // 一顯示就記錄已看過
  function runCoach() {
    closeCoach(); i = 0;
    root = document.createElement('div'); root.className = 'coach'; root.setAttribute('role', 'dialog'); root.setAttribute('aria-label', '新手教學');
    root.innerHTML = `<div class="coach-hole"></div><div class="coach-tip"></div><div class="coach-hand">${HAND}</div><div class="coach-dots"></div><button class="coach-skip" id="coach-skip">跳過</button>`;
    document.body.appendChild(root);
    root.addEventListener('click', (e) => {
      if (e.target.closest('#coach-skip')) return end(false);
      const s = STEPS[i]; const el = s && $(s.target); if (!el) return;
      const r = el.getBoundingClientRect(); const x = e.clientX; const y = e.clientY;
      if (x < r.left - 8 || x > r.right + 8 || y < r.top - 8 || y > r.bottom + 8) {   // 點錯地方：手指晃一下提示
        const h = root.querySelector('.coach-hand'); h.animate([{ transform: 'translateX(0)' }, { transform: 'translateX(-8px)' }, { transform: 'translateX(8px)' }, { transform: 'translateX(0)' }], { duration: 300 }); return;
      }
      if (s.pass) el.click();
      step(i + 1);
    });
    window.addEventListener('resize', place);
    (function loop() { place(); raf = requestAnimationFrame(() => setTimeout(loop, 250)); })();
    step(0);
  }
  LA.startTutorial = start;
  let seen = false;
  try { seen = !!LA.web || !!localStorage.getItem(SEEN) || Object.keys(localStorage).some((k) => /^la_tutorial_v\d+_seen$/.test(k)); } catch { /* ignore */ }   // 網頁版不自動跳教學（那是給主機 App 的）；舊版看過的也算
  // 後端記錄為準（localStorage 可能被清掉或沒落地）；後端說看過就順手補回本機
  const serverSeen = () => (seen || !LA.api ? Promise.resolve(seen) : LA.api('/api/ui/flags').then((r) => { const s = !!(r && r.flags && r.flags.tutorial_seen); if (s) { try { localStorage.setItem(SEEN, '1'); } catch { /* ignore */ } } return s; }).catch(() => true));   // 連不到後台就不要自動跳（寧可漏掉也不要重複出現；「使用指南」隨時可以重看）
  // 等 boot.js 跑完（第一次要先選主機／聯機模式）才開始；不同 <script> 之間瀏覽器可能先跑計時器，所以等 load 事件
  const go = () => { const h = LA.$('#help'); if (h) { h.innerHTML = LA.icon('help'); h.onclick = () => start(); } Promise.resolve(LA.setup).then(() => (LA.termsGate ? LA.termsGate() : null)).catch(() => null).then(serverSeen).then((s) => { seen = s; if (!seen) setTimeout(start, 350); }); };   // 只有第一次才自動開始教學
  if (document.readyState === 'complete') setTimeout(go, 0); else window.addEventListener('load', go);
})();
