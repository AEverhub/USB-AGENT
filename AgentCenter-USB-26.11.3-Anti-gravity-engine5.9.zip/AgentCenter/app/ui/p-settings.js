'use strict';
/* B 設定頁：時區與排程、LINE/Discord/Telegram、帳號連結、Cloudflare 內網穿透、MCP、通知 */
(function () {
  const { esc, $ } = LA;
  const TZ = ['Asia/Taipei', 'Asia/Tokyo', 'Asia/Seoul', 'Asia/Hong_Kong', 'Asia/Singapore', 'Asia/Shanghai', 'Asia/Bangkok', 'Europe/London', 'Europe/Paris', 'America/New_York', 'America/Los_Angeles', 'Australia/Sydney', 'UTC'];
  const SECTIONS = [
    { id: 'time', title: '🕐 時區與排程', fields: [
      { key: 'tz', label: '時區', type: 'select', options: TZ },
      { key: 'quiet.enabled', label: '夜間限制（只有管理員與員工能用）', type: 'toggle' }, { key: 'quiet.start', label: '夜間開始', type: 'time' }, { key: 'quiet.end', label: '夜間結束', type: 'time' },
      { key: 'schedule.good_morning.enabled', label: '早安問候', type: 'toggle' }, { key: 'schedule.good_morning.at', label: '早安時間', type: 'time' },
      { key: 'schedule.good_night.enabled', label: '晚安問候', type: 'toggle' }, { key: 'schedule.good_night.at', label: '晚安時間', type: 'time' },
      { key: 'schedule.diary.enabled', label: '系統日記（給管理員）', type: 'toggle' }, { key: 'schedule.diary.at', label: '日記時間', type: 'time' },
      { key: 'schedule.news.enabled', label: '新聞日報（給用戶，可口頭拒收）', type: 'toggle' }, { key: 'schedule.news.at', label: '日報時間', type: 'time' }, { key: 'schedule.news.feed', label: '新聞 RSS 來源' } ] },
    { id: 'plat', title: '💬 平台（可同時啟用，共用同一模型與資料庫）', fields: [
      { key: 'platforms.line.enabled', label: 'LINE 啟用', type: 'toggle' }, { key: 'platforms.line.secret', label: 'LINE Channel secret', type: 'password' }, { key: 'platforms.line.token', label: 'LINE Channel access token（長期）', type: 'password' },
      { key: 'platforms.line.mode', label: 'LINE 接收方式', type: 'select', options: [['direct', '直連 Webhook（搭配內網穿透）'], ['relay', 'Cloudflare Worker 中繼（輪詢）']] },
      { key: 'platforms.line.auto_webhook', label: '公開網址變動時自動更新 LINE Webhook URL', type: 'toggle' },
      { key: 'platforms.line.relay_url', label: 'Worker 網址（中繼模式）', ph: 'https://xxx.workers.dev' }, { key: 'platforms.line.relay_token', label: 'Worker RELAY_TOKEN', type: 'password' },
      { key: 'platforms.telegram.enabled', label: 'Telegram 啟用', type: 'toggle' }, { key: 'platforms.telegram.token', label: 'Telegram Bot Token', type: 'password', hint: '@BotFather 取得；用長輪詢，不需要公開網址' },
      { key: 'platforms.discord.enabled', label: 'Discord 啟用', type: 'toggle' }, { key: 'platforms.discord.token', label: 'Discord Bot Token', type: 'password', hint: '需在開發者後台開啟 MESSAGE CONTENT INTENT；走 Gateway，不需要公開網址。要讓 AI 改頻道名稱、刪訊息：在伺服器設定 → 身分組，給 Bot 的身分組打開「管理頻道」「管理訊息」' },
      { key: 'policy.quote_reply', label: '引言（回覆）方式', type: 'select', options: [['smart', '智慧：群組一律引言；私訊在對方有引用時才引言'], ['always', '一律引言對方那則訊息'], ['never', '不引言']] },
      { key: 'bot.aliases', label: '群組喚醒名稱（被叫到才回）', type: 'list', ph: '小燈, 阿燈' } ] },
    { id: 'tun', title: '☁️ 內網穿透（Cloudflare）', fields: [
      { key: 'tunnel.enabled', label: '啟用內網穿透', type: 'toggle' },
      { key: 'tunnel.provider', label: '方式', type: 'select', options: [['auto', '自動（有 cloudflared 就用，否則 Worker 中繼，再不然 localtunnel）'], ['cloudflared', 'Cloudflare Tunnel（手機上跑 cloudflared）'], ['cloudflare-worker', 'Cloudflare Worker 中繼（不需二進位檔，最穩）'], ['localtunnel', 'localtunnel（純 JS 備援）'], ['manual', '手動填寫網址']] },
      { key: 'tunnel.cloudflare_token', label: 'Cloudflare 隧道 Token（具名隧道，選填）', type: 'password', hint: '填了＝固定網址；留空＝Quick Tunnel（隨機 trycloudflare.com 網址，會變動，App 會自動更新 LINE Webhook）' },
      { key: 'tunnel.cloudflare_hostname', label: '公開主機名稱（具名隧道用）', ph: 'bot.example.com', hint: 'Zero Trust → Tunnels → Public Hostname，Service 指向 http://127.0.0.1:8787' },
      { key: 'tunnel.manual_url', label: '手動網址（方式=manual）', ph: 'https://…' }, { key: 'tunnel.subdomain', label: 'localtunnel 子網域（選填）' } ] },
    { id: 'mcp', title: '🔌 MCP 連接器', fields: [{ key: 'mcp.servers', label: '連接器清單（JSON）', type: 'json', hint: 'HTTP：{"name":"notion","url":"https://…/mcp","token":"…"}　stdio：{"name":"x","command":"…","args":[…]}' }] },
    { id: 'browser', title: '🌐 瀏覽器（AI 與你共用）', fields: [
      { key: 'browser.enabled', label: '允許 AI 使用瀏覽器', type: 'toggle' },
      { key: 'browser.provider', label: '瀏覽器來源', type: 'select', options: [['auto', '自動（手機＝App 內瀏覽器；電腦＝本機 Chrome）'], ['linux', '內建 Linux／Termux 的 Chromium（App 自動啟動、掛掉自動重開）'], ['local', '本機 Chrome／Chromium／Edge'], ['cdp', '連到另一台機器的 Chrome（遠端除錯網址）'], ['android', 'App 內 WebView（手機）']] },
      { key: 'browser.chrome_path', label: 'Chrome 執行檔路徑（選填，自動偵測）' }, { key: 'browser.cdp_url', label: '遠端除錯網址（方式=cdp）', ph: 'http://192.168.1.10:9222' },
      { key: 'browser.headless', label: '無視窗模式（建議開；畫面從 App「瀏覽器」頁看）', type: 'toggle' },
      { key: 'browser.width', label: '視窗寬', type: 'number' }, { key: 'browser.height', label: '視窗高', type: 'number' },
      { key: 'browser.autostart', label: '後台啟動時就開瀏覽器', type: 'toggle' },
      { key: 'browser.idle_close_min', label: '閒置幾分鐘後自動關閉以省記憶體（0＝不關；登入狀態會保留）', type: 'number' }, { key: 'browser.proxy', label: 'Proxy（選填）', ph: 'http://host:port' } ] },
    { id: 'image', title: '🎨 圖片生成', fields: [
      { key: 'image.provider', label: '供應商', type: 'select', options: [['auto', '自動：Gemini → OpenAI → 免金鑰備援'], ['gemini', 'Gemini（用「模型」頁的 Gemini 金鑰）'], ['openai', 'OpenAI'], ['pollinations', '免金鑰（品質普通）']] },
      { key: 'image.model', label: 'Gemini 圖像模型', hint: '預設 gemini-2.5-flash-image，可看著使用者傳的圖來改圖' }, { key: 'image.openai_key', label: 'OpenAI API Key（選填）', type: 'password' }, { key: 'image.openai_model', label: 'OpenAI 圖像模型' },
    ] },
    { id: 'notify', title: '📣 重要事件推播', fields: [
      { key: 'notify.min_level', label: '推播到外部的最低等級', type: 'select', options: ['info', 'warn', 'error', 'critical'] }, { key: 'notify.to_admin_dm', label: '同時私訊管理員', type: 'toggle' },
      { key: 'notify.webhook_url', label: '外部 Webhook URL（POST JSON）', type: 'password', hint: '可填 Discord/Slack/自家服務的 webhook' }, { key: 'notify.ntfy_topic', label: 'ntfy 主題（手機即時推播）' }, { key: 'notify.ntfy_server', label: 'ntfy 伺服器' } ] },
  ];

  LA.register('settings', { name: '設定', title: 'B 設定頁', async render(main) {
    const { settings } = await LA.api('/api/settings'); const [mcp, tun] = await Promise.all([LA.api('/api/mcp'), LA.api('/api/tunnel')]);
    const tunnelHead = `<div class="url"><div class="lbl">目前公開網址</div><div class="mono">${esc(tun.url || (tun.status === 'up' ? '（隧道已連線，未填主機名稱）' : '尚未連線'))}</div>${tun.webhooks ? `<div class="lbl" style="margin-top:6px">LINE Webhook URL</div><div class="mono">${esc(tun.webhooks.line)}</div><div class="row" style="margin-top:6px"><button class="btn sm" data-copy="${esc(tun.webhooks.line)}">複製 Webhook URL</button></div>` : ''}<div class="hint">狀態：${esc(tun.status)}　方式：${esc(tun.mode || '—')}${tun.error ? `<br><span class="err">${esc(tun.error)}</span>` : ''}</div></div>`;
    main.innerHTML = `<div class="card"><h3>🧠 模型與金鑰</h3><div class="hint">Gemini／Claude／ChatGPT／NVIDIA／Groq 與金鑰池已移到底部「模型」分頁。</div><div class="row" style="margin-top:8px"><button class="btn" id="go-models">前往模型頁</button></div></div>` + SECTIONS.map((s) => `<div class="card" data-sec="${s.id}"><h3>${s.title}</h3>${s.id === 'tun' ? tunnelHead : ''}${s.fields.map((f) => LA.fieldHTML(f, settings)).join('')}
      ${s.id === 'mcp' ? `<div class="hint">已載入工具：${mcp.tools.length} 個${Object.keys(mcp.errors).length ? '<br><span class="err">' + Object.entries(mcp.errors).map(([k, v]) => esc(k + '：' + v)).join('<br>') + '</span>' : ''}</div>` : ''}
      <div class="row" style="margin-top:10px"><button class="btn pri" data-save="${s.id}">儲存</button>${s.id === 'mcp' ? '<button class="btn" id="mcp-re">重新連線</button>' : ''}${s.id === 'notify' ? '<button class="btn" id="n-test">送測試通知</button>' : ''}${s.id === 'plat' ? '<button class="btn" id="dc-test">測試 Discord Token</button>' : ''}${s.id === 'tun' ? '<button class="btn" id="t-re">套用並重啟穿透</button>' : ''}${s.id === 'plat' ? '<button class="btn" id="link">產生帳號連結驗證碼</button>' : ''}</div></div>`).join('');
    main.onclick = LA.guard(async (e) => {
      const c = e.target.closest('[data-copy]'); if (c) return LA.copy(c.dataset.copy);
      if (e.target.id === 'go-models') return LA.go('models');
      const sv = e.target.closest('[data-save]'); if (sv) { const items = LA.collect($(`[data-sec="${sv.dataset.save}"]`)).filter((i) => !(typeof i.value === 'string' && i.value === '' && $(`[data-key="${i.key}"]`).dataset.secret)); await LA.post('/api/settings', { items }); LA.toast('已儲存，並自動套用'); return; }
      if (e.target.id === 'mcp-re') { const r = await LA.post('/api/mcp/reload'); LA.toast(`已載入 ${r.tools} 個工具`); LA.go('settings'); }
      if (e.target.id === 'dc-test') { const inp = $('[data-key="platforms.discord.token"]'); const r = await LA.post('/api/platforms/discord/test', { token: inp && inp.value ? inp.value : '' });
        LA.modal(`<h3 style="margin-top:0">${r.ok ? '可以連線' : '有問題'}</h3>${r.bot ? `<p>Bot：<b>${esc(r.bot)}</b></p>` : ''}${r.error ? `<p>${esc(r.error)}</p>` : '<p>Token 正確、MESSAGE CONTENT INTENT 已開啟。記得按「儲存」並打開「Discord 啟用」。</p>'}<div class="row"><span class="mono small grow">錯誤代碼：${esc(r.code)}</span><button class="btn sm" data-copy="${esc(r.code + (r.error ? '：' + r.error : ''))}">複製</button></div>`); return; }
      if (e.target.id === 'n-test') { await LA.post('/api/notify/test'); LA.toast('已送出，請確認通知列／私訊'); }
      if (e.target.id === 't-re') { LA.toast('重啟穿透中…'); await LA.post('/api/tunnel/restart'); LA.go('settings'); }
      if (e.target.id === 'link') { const r = await LA.post('/api/link/start', {}); LA.modal(`<h3 style="margin-top:0">帳號連結驗證碼</h3><div style="font-size:34px;letter-spacing:6px;text-align:center;margin:12px 0" class="mono">${r.code}</div><p class="small mute">10 分鐘內有效。到「要連結的另一個平台」私訊 bot：<br><b>驗證碼 ${r.code}</b><br>連結後兩個平台共用同一份記憶與權限（原帳號：${esc(r.person)}）。<br>也可以直接對 AI 說「我要連結帳號」。</p><div class="row" style="justify-content:flex-end"><button class="btn pri" onclick="LA.closeModal()">好</button></div>`); }
    });
  } });

})();
