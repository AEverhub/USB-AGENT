'use strict';
(function () {
  // 26.12.3：服務選單併進對話頁。26.11.3：聯機模式（連到別人的主機）只留 對話｜聯機｜更多
  const TABS_HOST = [['home', 'chat', '對話'], ['browser', 'globe', '瀏覽器'], ['ops', 'bolt', '監控'], ['more', 'grid', '更多']];
  const TABS_CLIENT = [['home', 'chat', '對話'], ['groups', 'group', '群組'], ['more', 'grid', '更多']];
  const TABS_CONSOLE = [['home', 'chat', '對話'], ['groups', 'group', '群組'], ['ops', 'bolt', '監控'], ['more', 'grid', '更多']];   // 主機開放操作端給你時   // Revise3：聯機設定移到「更多 → 開發者 → 聯機」
  const nav = LA.$('#tabs');
  LA.renderTabs = () => { const T = LA.link.mode === 'client' ? (LA.link.client && LA.link.client.console ? TABS_CONSOLE : TABS_CLIENT) : TABS_HOST; nav.innerHTML = T.map(([id, ic, n]) => `<button data-id="${id}"><span>${LA.icon(ic)}</span>${n}${id === 'ops' ? '<i hidden>0</i>' : ''}</button>`).join(''); };
  LA.renderTabs();
  LA.$('#bell').insertAdjacentHTML('afterbegin', LA.icon('bell'));
  nav.onclick = (e) => { const b = e.target.closest('button'); if (b) LA.go(b.dataset.id); };
  LA.$('#bell').onclick = () => LA.go('ops');   // 通知與待審批在監控頁
  if (!LA.token && LA.webJoinUI) return void LA.webJoinUI();   // 26.11.3 pro5 網頁版：還沒加入主機 → 加入畫面
  if (!LA.token) { LA.$('#page').innerHTML = '<div class="card err">沒有存取憑證。請從 App 首頁開啟，或網址要帶 #t=你的token。</div>'; return; }
  LA.refreshStatus().catch(() => { LA.$('#pill').textContent = '離線'; });
  setInterval(() => { if (LA.cur !== 'ops') LA.refreshStatus().catch(() => { LA.$('#pill').className = 'pill bad'; LA.$('#pill').textContent = '離線'; }); }, 8000);
  new MutationObserver(() => LA.report()).observe(LA.$('#page'), { childList: true, subtree: true });
  // 26.11.3 Revise3：第一次一律是「單機」，直接進 App、馬上開始教學；聯機要到「更多 → 開發者 → 聯機」自己設定。
  // 例外：是點「連線連結」打開的 → 先問要不要同意連線
  LA.go('home');
  LA.setup = (async () => {
    try { LA.link = await LA.api('/api/link/state'); } catch { LA.link = { mode: '' }; }
    if (LA.link.mode === 'client') {   // 問主機我現在的角色／能不能看操作端（例如剛用 /claim 成為管理員）
      try { const me = await LA.api('/api/me'); LA.link.client = { ...(LA.link.client || {}), role: me.role, console: me.console || '' }; } catch { /* 主機離線就照舊 */ }
      LA.renderTabs(); if (LA.cur === 'home') LA.go('home');
    }
    if (LA.pendingJoin && LA.onJoinLink) { const j = LA.pendingJoin; LA.pendingJoin = null; await LA.onJoinLink(j); }
  })().catch(() => {});
})();
