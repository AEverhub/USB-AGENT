'use strict';
/* D 用戶身份管理（角色／權限／個別權限／個性檔案）與 E 前後總管（一鍵群發三平台） */
(function () {
  const { esc, $ } = LA;
  const ROLE = { admin: '管理員', staff: '員工', user: '用戶', guest: '訪客' };
  const PERM = { chat: '對話', search: '上網搜尋', files: '檔案', sheets: '試算表', ledger: '記帳', schedule: '排程提醒', terminal: '終端機', mcp: 'MCP 工具', skills: '技能', night: '夜間可用', news: '收新聞日報', broadcast: '群發', manage_users: '管理用戶', manage_app: '管理 App', request_download: '申請下載', image: 'AI 生圖' };
  const PLAT = { line: 'LINE', discord: 'Discord', telegram: 'Telegram', app: 'App', net: '聯機' };

  const PER = { hour: '每小時', day: '每天', week: '每週', total: '總共' };
  LA.register('users', { name: '用戶身份', title: 'D 用戶身份', async render(main) {
    const [d, ap] = await Promise.all([LA.api('/api/users'), LA.api('/api/approvals')]); const users = d.users; const pend = ap.filter((a) => a.kind === 'new_user');
    // 管理員在 LINE／Discord／Telegram 用講的改了權限 → 這頁自動同步（沒在編輯時才重畫）
    LA.every(5000, async () => { if (LA.cur !== 'users' || !LA.$('#modal').hidden) return; const n = await LA.api('/api/users'); if (JSON.stringify(n) !== JSON.stringify(d)) { LA.toast('權限已更新'); LA.go('users'); } });
    main.innerHTML = `${!users.some((u) => u.role === 'admin') ? '<div class="card"><h3>👑 還沒有管理員</h3><p class="small mute">最簡單：在這裡建立「App 管理員」，之後用「帳號連結驗證碼」把你的 LINE／Discord／Telegram 併進來。或在平台私訊 /claim 密碼（密碼在開發者頁設定）。</p><button class="btn pri" id="mkadmin">建立 App 管理員</button></div>' : ''}
      ${pend.length ? `<div class="card"><h3>🆕 新用戶待審核 <small>${pend.length}</small></h3><div class="list">${pend.map((a) => `<div>${esc(a.summary)}<div class="row" style="margin-top:6px"><button class="btn ok sm" data-ap="1" data-id="${a.id}">通過</button><button class="btn bad sm" data-ap="0" data-id="${a.id}">拒絕</button></div></div>`).join('')}</div></div>` : ''}
      <div class="card"><h3>👥 使用者 <small>${users.length} 人</small></h3><div class="list">${users.map((u) => `<div class="row" data-u="${u.id}" style="cursor:pointer"><span class="grow"><b>${esc(u.name || '未命名')}</b> <span class="tag ${u.role}">${ROLE[u.role]}</span>${u.status !== 'active' ? `<span class="tag guest">${esc(u.status)}</span>` : ''}${u.quota ? `<span class="tag guest">剩 ${u.quota.left}/${u.quota.limit} 次（${PER[u.quota.per] || u.quota.per}）</span>` : ''}<div class="mute small">${u.identities.map((i) => PLAT[i.platform] || i.platform).join(' + ') || '—'} · ${u.usage.messages} 則 · ${LA.fmtTime(u.last_seen)}</div></span><span>›</span></div>`).join('')}</div></div>
      <div class="card"><h3>🔐 各身份的預設權限</h3><div class="tblw"><table class="t"><thead><tr><th>權限</th>${['staff', 'user', 'guest'].map((r) => `<th>${ROLE[r]}</th>`).join('')}</tr></thead><tbody>${d.perms.map((p) => `<tr><td>${esc(PERM[p] || p)}</td>${['staff', 'user', 'guest'].map((r) => `<td><input type="checkbox" data-r="${r}" data-p="${p}" ${(d.roles[r] || []).includes(p) ? 'checked' : ''} style="width:auto"></td>`).join('')}</tr>`).join('')}</tbody></table></div><div class="hint">管理員固定擁有全部權限。個別使用者可在上方點進去再加權／禁止。夜間（預設 21:00–07:00）只有有「夜間可用」的身份能用。</div><button class="btn pri" id="saveroles" style="margin-top:8px">儲存預設權限</button></div>`;
    main.onclick = LA.guard(async (e) => {
      if (e.target.id === 'mkadmin') { await LA.post('/api/app-admin'); LA.toast('已建立'); return LA.go('users'); }
      const ap2 = e.target.closest('[data-ap]'); if (ap2) { await LA.post('/api/approvals/' + ap2.dataset.id, { approve: ap2.dataset.ap === '1' }); LA.toast('完成'); return LA.go('users'); }
      if (e.target.id === 'saveroles') { for (const r of ['staff', 'user', 'guest']) await LA.post('/api/roles', { role: r, perms: LA.$$(`[data-r="${r}"]:checked`, main).map((c) => c.dataset.p) }); return LA.toast('已儲存'); }
      const u = e.target.closest('[data-u]'); if (u) edit(users.find((x) => x.id === u.dataset.u), users, d.perms);
    });
  } });

  function edit(u, users, perms) {
    const tri = (p) => (u.perms.deny.includes(p) ? 'deny' : u.perms.allow.includes(p) ? 'allow' : 'def');
    LA.modal(`<h3 style="margin-top:0">${esc(u.name || '未命名')} <span class="tag ${u.role}">${ROLE[u.role]}</span></h3>
      <div class="hint">${u.identities.map((i) => `${PLAT[i.platform] || i.platform}: ${esc(i.name || i.uid)}`).join('<br>')}</div>
      <label class="f">顯示名稱</label><input id="u-n" value="${esc(u.name)}"><label class="f">身份</label><select id="u-r">${Object.entries(ROLE).map(([k, v]) => `<option value="${k}" ${u.role === k ? 'selected' : ''}>${v}</option>`).join('')}</select>
      <label class="f">狀態</label><select id="u-s">${['active', 'pending', 'blocked'].map((s) => `<option ${u.status === s ? 'selected' : ''}>${s}</option>`).join('')}</select>
      <label class="f">職責／備註（AI 會看到）</label><input id="u-i" value="${esc(u.instructions)}">
      <label class="f">個別權限（點一下切換：預設 → 允許 → 禁止）</label><div class="chips" id="u-p">${perms.map((p) => { const t = tri(p); return `<span class="chip ${t === 'allow' ? 'on' : t === 'deny' ? 'no' : ''}" data-p="${p}" data-t="${t}">${esc(PERM[p] || p)}${t === 'allow' ? ' ✓' : t === 'deny' ? ' ✕' : ''}</span>`; }).join('')}</div>
      <label class="f">可以叫 AI 幾次（管理員不受限；0＝不限）</label><div class="row"><input id="u-ql" type="number" min="0" value="${u.quota ? u.quota.limit : 0}" style="width:110px"><select id="u-qp">${Object.entries(PER).map(([k, n]) => `<option value="${k}" ${(u.quota ? u.quota.per : 'day') === k ? 'selected' : ''}>${n}</option>`).join('')}</select>${u.quota ? `<span class="small mute">目前剩 ${u.quota.left} 次</span>` : ''}</div><div class="hint">也可以在 LINE／群組直接跟 AI 說「小明每天只能叫你 3 次」（只有管理員說的才算）。</div>
      <label class="chk"><input type="checkbox" id="u-news" ${u.prefs.news ? 'checked' : ''}> 接收每日新聞日報</label><label class="chk"><input type="checkbox" id="u-greet" ${u.prefs.greet ? 'checked' : ''}> 接收早安／晚安</label><label class="chk"><input type="checkbox" id="u-night" ${u.prefs.night_ok ? 'checked' : ''}> 夜間也可使用（特別允許）</label>
      <div class="row" style="margin-top:12px"><button class="btn bad" id="u-del">刪除</button><button class="btn" id="u-merge">合併到…</button><button class="btn" id="u-link">連結碼</button><button class="btn pri grow" id="u-save">儲存</button></div>`, (m) => {
      $('#u-p', m).onclick = (e) => { const c = e.target.closest('.chip'); if (!c) return; const nx = { def: 'allow', allow: 'deny', deny: 'def' }[c.dataset.t]; c.dataset.t = nx; c.className = 'chip ' + (nx === 'allow' ? 'on' : nx === 'deny' ? 'no' : ''); c.textContent = (PERM[c.dataset.p] || c.dataset.p) + (nx === 'allow' ? ' ✓' : nx === 'deny' ? ' ✕' : ''); };
      $('#u-save', m).onclick = LA.guard(async () => { const chips = LA.$$('#u-p .chip', m); await LA.post('/api/users/' + u.id, { name: $('#u-n', m).value, role: $('#u-r', m).value, status: $('#u-s', m).value, instructions: $('#u-i', m).value, perms: { allow: chips.filter((c) => c.dataset.t === 'allow').map((c) => c.dataset.p), deny: chips.filter((c) => c.dataset.t === 'deny').map((c) => c.dataset.p) }, quota: { limit: +$('#u-ql', m).value || 0, per: $('#u-qp', m).value }, prefs: { news: $('#u-news', m).checked, greet: $('#u-greet', m).checked, night_ok: $('#u-night', m).checked } }); LA.closeModal(); LA.toast('已儲存'); LA.go('users'); });
      $('#u-del', m).onclick = LA.guard(async () => { if (await LA.confirm('刪除這位使用者（含身份對應）？')) { await LA.del('/api/users/' + u.id); LA.closeModal(); LA.go('users'); } });
      $('#u-link', m).onclick = LA.guard(async () => { const r = await LA.post('/api/link/start', { pid: u.id }); LA.toast('驗證碼 ' + r.code + '（10 分鐘內，到另一平台私訊「驗證碼 ' + r.code + '」）'); });
      $('#u-merge', m).onclick = LA.guard(async () => { const o = users.filter((x) => x.id !== u.id); LA.modal(`<h3 style="margin-top:0">把「${esc(u.name || u.id)}」合併到</h3><div class="hint">身份、記憶、記帳全部併過去，此人會被刪除。</div><div class="list">${o.map((x) => `<div class="row"><span class="grow">${esc(x.name || x.id)} (${ROLE[x.role]})</span><button class="btn sm" data-into="${x.id}">選這位</button></div>`).join('')}</div>`, (m2) => { m2.onclick = LA.guard(async (e) => { const b = e.target.closest('[data-into]'); if (b) { await LA.post(`/api/users/${u.id}/merge`, { into: b.dataset.into }); LA.closeModal(); LA.go('users'); } }); }); });
    });
  }

  LA.register('broadcast', { name: '群發訊息', title: 'E 前後總管（群發）', async render(main) {
    const [st, groups, users] = await Promise.all([LA.api('/api/status'), LA.api('/api/groups'), LA.api('/api/users')]);
    const plats = [['line', 'LINE'], ['discord', 'Discord'], ['telegram', 'Telegram']];
    main.innerHTML = `<div class="card"><h3>📢 一鍵群發 <small>${users.users.filter((u) => u.status === 'active' && u.role !== 'guest').length} 位用戶 · ${groups.length} 個群組</small></h3>
      <label class="f">訊息內容</label><textarea id="b-t" placeholder="要傳給大家的話…"></textarea>
      <label class="f">平台</label><div class="chips">${plats.map(([k, n]) => `<label class="chip"><input type="checkbox" class="b-p" value="${k}" ${st.platforms[k].enabled ? 'checked' : 'disabled'} style="width:auto"> ${n}${st.platforms[k].enabled ? '' : '（未啟用）'}</label>`).join('')}</div>
      <label class="f">對象身份（不選＝全部）</label><div class="chips">${['staff', 'user'].map((r) => `<label class="chip"><input type="checkbox" class="b-r" value="${r}" style="width:auto"> ${ROLE[r]}</label>`).join('')}</div>
      <label class="chk"><input type="checkbox" id="b-g"> 同時發到已知的群組</label><div class="hint">每位用戶只會收到一則（優先走他最近使用的平台）；已連結帳號不會重複收到。</div>
      <button class="btn pri" id="b-go" style="width:100%;margin-top:6px">📤 發送</button><div id="b-res"></div></div>
      <div class="card"><h3>已知群組</h3><div class="list">${groups.map((g) => `<div><b>${esc(g.name || '(未命名)')}</b> <span class="tag">${esc(g.platform)}</span><span class="mute small"> ${g.members} 人 · ${LA.fmtTime(g.last_seen)}</span></div>`).join('') || '<div class="mute">還沒有群組（bot 被加入並收到訊息後會自動出現）</div>'}</div></div>`;
    $('#b-go').onclick = LA.guard(async () => { const text = $('#b-t').value.trim(); if (!text) throw new Error('請輸入內容'); if (!(await LA.confirm('確定要群發給所選對象？'))) return; const b = $('#b-go'); b.disabled = true; b.textContent = '發送中…';
      try { const r = await LA.post('/api/broadcast', { text, platforms: LA.$$('.b-p:checked').map((c) => c.value), roles: LA.$$('.b-r:checked').map((c) => c.value), include_groups: $('#b-g').checked }); $('#b-res').innerHTML = `<div class="hint ${r.failed ? 'err' : 'okc'}">成功 ${r.sent}、失敗 ${r.failed}</div><div class="small mute">${r.details.map(esc).join('<br>')}</div>`; } finally { b.disabled = false; b.textContent = '📤 發送'; } });
  } });
})();
