'use strict';
/*
 * 26.11.3 Revise6 會議監聽：聽整場會議／演講，自動轉文字、整理重點（摘要、重點、決議、待辦、待確認）。
 *  ・用手機麥克風：連續錄音，每段約 25～45 秒（挑停頓的地方切）上傳轉文字；沒有雲端辨識金鑰時改用手機內建辨識。
 *  ・Discord：Bot 進語音頻道，依講者記錄（需要先安裝一次「Discord 收音程式」）。
 *  ・錄音時螢幕保持亮著（App 退到背景時手機可能會暫停錄音）。
 */
(function () {
  const { esc } = LA; const $ = (s, r = document) => r.querySelector(s);
  const AB = () => window.AndroidBridge || null;
  let view = { kind: 'list', id: null }; let rec = null; let poll = null;
  const fmtT = (ms) => { const s = Math.max(0, Math.round(ms / 1000)); const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), x = s % 60; return (h ? h + ':' + String(m).padStart(2, '0') : String(m).padStart(2, '0')) + ':' + String(x).padStart(2, '0'); };
  const STATUS = { live: ['記錄中', 'on'], processing: ['整理中', 'warn'], done: ['完成', ''], interrupted: ['中斷', 'bad'] };
  const pill = (s) => { const [t, c] = STATUS[s] || [s, '']; return `<span class="pill ${c}">${t}</span>`; };
  const keepOn = (on) => { try { AB() && AB().keepScreenOn && AB().keepScreenOn(!!on); } catch { /* ignore */ } };
  const b64 = (blob) => new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(String(r.result).split(',')[1] || ''); r.onerror = () => rej(r.error); r.readAsDataURL(blob); });

  // ---------------- 連續錄音（雲端辨識）----------------
  async function recorder(id, ui) {
    const stream = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true, channelCount: 1 } });
    const AC = window.AudioContext || window.webkitAudioContext; const ac = new AC(); if (ac.state === 'suspended') await ac.resume().catch(() => {});
    const src = ac.createMediaStreamSource(stream); const proc = ac.createScriptProcessor(4096, 1, 1); const rate = ac.sampleRate; const blockMs = 4096 / rate * 1000;
    let bufs = [], segStart = Date.now(), quietMs = 0, voiced = 0, floor = 0.004; const queue = []; let sending = false; let stopped = false; const st = { sent: 0, failed: 0, level: 0 };
    const pump = async () => {
      if (sending) return; sending = true;
      while (queue.length) {
        const job = queue[0]; let ok = false;
        for (let i = 0; i < 3 && !ok; i++) { try { await LA.post(`/api/meetings/${id}/audio`, { mime: 'audio/wav', data: await b64(job.blob), at: job.at }); ok = true; } catch (e) { if (/已經結束|找不到/.test(e.message)) { queue.length = 0; break; } await new Promise((r) => setTimeout(r, 1500 * (i + 1))); } }
        queue.shift(); if (ok) st.sent++; else st.failed++; ui(st, queue.length);
      }
      sending = false;
    };
    const cut = () => { const chunk = bufs; const at = segStart; const had = voiced; bufs = []; segStart = Date.now(); voiced = 0; quietMs = 0; if (had >= 6 && chunk.length) { queue.push({ blob: LA.voice.encodeWav(chunk, rate), at }); ui(st, queue.length); pump(); } };
    proc.onaudioprocess = (e) => {
      if (stopped) return; const d = e.inputBuffer.getChannelData(0); bufs.push(new Float32Array(d)); let s = 0; for (let i = 0; i < d.length; i++) s += d[i] * d[i]; const rms = Math.sqrt(s / d.length);
      const th = Math.max(0.012, floor * 2.6); if (rms > th) { voiced++; quietMs = 0; } else { quietMs += blockMs; floor = floor * 0.95 + rms * 0.05; }
      st.level = Math.min(1, rms / 0.12); const len = Date.now() - segStart;
      if ((len > 25000 && quietMs > 400) || len > 45000) cut();   // 挑停頓的地方切；最長 45 秒
    };
    src.connect(proc); proc.connect(ac.destination);
    return { st, async stop() { stopped = true; cut(); try { proc.disconnect(); src.disconnect(); } catch { /* ignore */ } stream.getTracks().forEach((t) => t.stop()); ac.close().catch(() => {}); for (let i = 0; i < 120 && (queue.length || sending); i++) await new Promise((r) => setTimeout(r, 500)); } };
  }
  // ---------------- 手機內建辨識（沒有雲端金鑰時）----------------
  function deviceLoop(id, ui) {
    let alive = true; let ctl = null; const st = { sent: 0, failed: 0, level: 0 };
    (async () => { while (alive) { const at = Date.now(); ctl = LA.voice.listen({ onLevel: (lv) => { st.level = lv; } }); try { const t = (await ctl.done).trim(); if (t && alive) { await LA.post(`/api/meetings/${id}/text`, { text: t, at }); st.sent++; ui(st, 0); } } catch (e) { if (/權限/.test(e.message)) { LA.toast(e.message, true); break; } await new Promise((r) => setTimeout(r, 600)); } } })();
    return { st, async stop() { alive = false; try { ctl && ctl.stop(); } catch { /* ignore */ } } };
  }

  // ---------------- 畫面 ----------------
  function notesHtml(m) {
    const n = m.notes || {}; const sec = (t, arr, f = (x) => esc(x)) => (arr && arr.length ? `<h4>${t}</h4><ul>${arr.map((x) => `<li>${f(x)}</li>`).join('')}</ul>` : '');
    return `${n.summary ? `<h4>摘要</h4><p>${esc(n.summary)}</p>` : ''}${sec('重點', n.points)}${sec('決議', n.decisions)}${sec('待辦', n.actions, (a) => `${a.who ? `<b>${esc(a.who)}</b>：` : ''}${esc(a.what)}${a.due ? `<span class="mute">（${esc(a.due)}）</span>` : ''}`)}${sec('待確認', n.questions)}`
      || `<p class="mute">${m.segments && m.segments.length ? '重點整理中…（每多一段內容會自動更新）' : '還沒有聽到內容'}</p>`;
  }
  const transcriptHtml = (m, last = 0) => { const seg = last ? m.segments.slice(-last) : m.segments; return seg.length ? seg.map((s) => `<div class="mt-seg"><span class="mono mute">${fmtT(s.at)}</span>${s.speaker ? `<b>${esc(s.speaker)}</b>` : ''}<span>${esc(s.text)}</span></div>`).join('') : '<div class="mute small">（還沒有逐字稿）</div>'; };

  async function listView(main) {
    view = { kind: 'list' }; clearInterval(poll);
    const r = await LA.api('/api/meetings'); const dv = r.discord; const live = r.items.find((m) => m.status === 'live' && m.source === 'app');
    main.innerHTML = `<div class="card"><h3>${LA.icon('mic')} 會議監聽 <small>聽整場會議或演講，自動整理重點</small></h3>
        <label class="f">會議名稱（選填，沒填會依內容自動取）</label><input id="mt-title" maxlength="60" placeholder="例：週會、產品發表會">
        <div class="row" style="margin-top:10px"><button class="btn pri" id="mt-start">${LA.icon('mic', 'sm')} 開始記錄（手機麥克風）</button></div>
        <div class="hint">${r.stt.length ? `語音辨識：雲端（${esc(r.stt.join('、'))}）` : '沒有雲端辨識金鑰：改用手機內建辨識（模型頁加 Groq／OpenAI／Gemini 金鑰會更準）'}。記錄時請讓螢幕保持亮著，把手機放在講者附近。</div>
        ${live ? `<div class="bwarn">有一場正在記錄：${esc(live.title)} <button class="btn sm" data-open="${esc(live.id)}">回到記錄</button></div>` : ''}</div>
      <div class="card"><h3>${LA.icon('group')} Discord 語音頻道 <small>Bot 進頻道聽，依講者記錄</small></h3>${discordCard(dv)}</div>
      <h3 style="margin:14px 2px 8px">會議記錄</h3><div class="list">${r.items.map((m) => `<button class="mt-item" data-open="${esc(m.id)}"><span class="grow"><b>${esc(m.title)}</b> ${pill(m.status)}<small>${new Date(m.startedAt).toLocaleString('zh-TW', { hour12: false })}・${m.source === 'discord' ? 'Discord「' + esc(m.channel) + '」' : '手機麥克風'}・${m.segments} 段</small>${m.summary ? `<small class="mt-sum">${esc(m.summary)}</small>` : ''}</span></button>`).join('') || '<div class="card mute">還沒有會議記錄。</div>'}</div>`;
    main.onclick = LA.guard(async (e) => {
      const o = e.target.closest('[data-open]'); if (o) return detail(main, o.dataset.open);
      if (e.target.closest('#mt-start')) return startApp(main, $('#mt-title', main).value);
      if (e.target.closest('#mt-install')) { await LA.post('/api/meetings/voice-worker/install', {}); LA.toast('開始安裝，約 1～5 分鐘'); return listView(main); }
      if (e.target.closest('#mt-chs')) { const r2 = await LA.api('/api/meetings/discord/channels'); const sel = $('#mt-ch', main); sel.innerHTML = r2.items.map((c) => `<option value="${esc(c.id)}">${esc(c.name)}${c.guild ? '（' + esc(c.guild) + '）' : ''}</option>`).join('') || '<option value="">（Bot 看不到任何語音頻道）</option>'; return; }
      if (e.target.closest('#mt-join')) { const ch = $('#mt-ch', main).value; if (!ch) return LA.toast('先選語音頻道', true); const b = e.target.closest('#mt-join'); b.disabled = true; b.textContent = '進入中…'; try { const m = await LA.post('/api/meetings/discord/join', { channel: ch, title: $('#mt-title', main).value }); LA.toast('已進入語音頻道開始記錄'); return detail(main, m.id); } finally { b.disabled = false; } }
    });
    if (dv && dv.job && dv.job.running) poll = setInterval(() => { if (LA.cur === 'meeting' && view.kind === 'list') listView(main); else clearInterval(poll); }, 3000);
  }
  function discordCard(dv) {
    if (!dv) return '<div class="mute">Discord 收音功能沒有啟動。</div>';
    const job = dv.job; const log = job ? `<pre class="mt-log">${esc((job.log || []).slice(-8).join('\n'))}</pre>` : '';
    if (!dv.where) return '<div class="hint">需要先到「瀏覽器」頁安裝<b>內建 Linux</b>（或設定外部 Termux）；伺服器版需要 Node.js 22.12 以上。原因：Discord 語音從 2026 年 3 月起強制端對端加密，要另外一支支援加密的收音程式才聽得到。</div>';
    if (!dv.installed) return `<div class="hint">第一次使用要安裝「Discord 收音程式」（${dv.where === 'local' ? '這台伺服器' : '手機的內建 Linux'}，約 1～5 分鐘，需要網路）。</div><div class="row"><button class="btn pri" id="mt-install" ${job && job.running ? 'disabled' : ''}>${job && job.running ? '安裝中…' : '安裝 Discord 收音程式'}</button></div>${job && job.ok === false ? `<div class="hint err">${esc(job.error || '')}</div>` : ''}${log}`;
    if (!dv.discord_ready) return '<div class="hint">Discord Bot 還沒連線：到「設定 → 平台 → Discord」開啟。</div>';
    return `<div class="row"><select id="mt-ch" class="grow"><option value="">按右邊載入語音頻道</option></select><button class="btn sm" id="mt-chs">載入頻道</button></div>
      <div class="row" style="margin-top:8px"><button class="btn pri" id="mt-join">進入並開始記錄</button></div>
      <div class="hint">也可以在 Discord 直接跟 AI 說「進『會議室』聽會議」。Bot 進頻道時會在頻道文字區公告正在記錄；結束後會議記錄貼回原頻道。收音程式在${dv.where === 'local' ? '這台伺服器' : '內建 Linux'}（Node ${esc(dv.node || '')}）。</div>`;
  }
  async function startApp(main, title) {
    const vs = LA.voice && (LA.voice.state || await LA.voice.load().catch(() => null)); void vs;
    const mode = LA.voice ? LA.voice.sttMode() : ''; if (!mode) throw new Error('沒有可用的語音辨識：模型頁加 Groq／OpenAI／Gemini 金鑰，或手機安裝 Google App');
    const m = await LA.post('/api/meetings', { title }); view = { kind: 'detail', id: m.id };
    try { const R = { id: m.id, mode, t0: Date.now(), ctl: null, pending: 0 }; rec = R; const ui = (st, q) => { R.pending = q; paintRec(); }; /* 用自己的參照：按「結束」後 rec 會清掉，最後一段上傳完仍會回呼 */ R.ctl = mode === 'cloud' ? await recorder(m.id, ui) : deviceLoop(m.id, ui); keepOn(true); }
    catch (e) { rec = null; await LA.post(`/api/meetings/${m.id}/stop`, {}).catch(() => {}); throw e; }
    return detail(main, m.id);
  }
  function paintRec() {
    const box = $('#mt-rec'); if (!box || !rec) return; const lv = rec.ctl && rec.ctl.st ? rec.ctl.st.level : 0;
    box.innerHTML = `<div class="mt-dot"></div><b class="mono">${fmtT(Date.now() - rec.t0)}</b><span class="mt-lv"><i style="width:${Math.round(lv * 100)}%"></i></span><small class="mute">${rec.mode === 'cloud' ? `已送 ${rec.ctl ? rec.ctl.st.sent : 0} 段${rec.pending ? `・待送 ${rec.pending}` : ''}` : `手機內建辨識・${rec.ctl ? rec.ctl.st.sent : 0} 句`}</small>`;
  }
  async function detail(main, id) {
    view = { kind: 'detail', id }; clearInterval(poll); let tab = 'notes';
    const draw = async () => {
      if (view.id !== id || LA.cur !== 'meeting') return; const m = await LA.api('/api/meetings/' + id); const mine = rec && rec.id === id; const live = m.status === 'live';
      const head = `<div class="row" style="align-items:center;gap:8px"><button class="ico" id="mt-back" title="返回">${LA.icon('back')}</button><div class="grow"><b>${esc(m.title)}</b> ${pill(m.status)}<div class="small mute">${new Date(m.startedAt).toLocaleString('zh-TW', { hour12: false })}・${m.source === 'discord' ? 'Discord「' + esc(m.discord.channel_name) + '」' + (m.worker && m.worker.state ? '・' + esc(m.worker.state) : '') : '手機麥克風'}・${m.segments.length} 段${m.pending ? `・轉文字中 ${m.pending}` : ''}</div></div></div>`;
      const ctrl = live ? `<div class="row" style="margin-top:10px">${mine ? '<div class="mt-rec" id="mt-rec"></div>' : ''}<button class="btn bad" id="mt-stop">${LA.icon('stop', 'sm')} 結束並整理</button></div>` : `<div class="row" style="margin-top:10px;flex-wrap:wrap"><button class="btn sm" data-exp="docx">匯出 Word</button><button class="btn sm" data-exp="pdf">匯出 PDF</button><button class="btn sm" data-exp="md">匯出 Markdown</button><button class="btn sm" id="mt-copy">${LA.icon('copy', 'sm')} 複製</button><button class="btn sm" id="mt-re">重新整理重點</button><button class="btn sm" id="mt-ren">改名</button><button class="btn sm" id="mt-del">刪除</button></div>`;
      const errs = (m.errors || []).slice(-3).map((x) => `<div class="hint err">${esc(x.msg)}</div>`).join('');
      const body = tab === 'notes' ? `<div class="mt-notes">${notesHtml(m)}</div>${live ? `<h4>最新發言</h4><div class="mt-tr">${transcriptHtml(m, 6)}</div>` : ''}` : `<div class="mt-tr">${transcriptHtml(m)}</div>`;
      const sc = $('#mt-body', main) ? $('#mt-body', main).scrollTop : 0;
      main.innerHTML = `<div class="card">${head}${ctrl}${errs}</div><div class="card"><div class="seg"><button class="${tab === 'notes' ? 'on' : ''}" data-tab="notes">重點</button><button class="${tab === 'tr' ? 'on' : ''}" data-tab="tr">逐字稿</button></div><div id="mt-body" class="mt-body">${body}</div></div>`;
      if ($('#mt-body', main)) $('#mt-body', main).scrollTop = sc; paintRec();
      if (m.status !== 'live' && m.status !== 'processing') clearInterval(poll);
    };
    main.onclick = LA.guard(async (e) => {
      const t = e.target;
      if (t.closest('#mt-back')) return listView(main);
      const tb = t.closest('[data-tab]'); if (tb) { tab = tb.dataset.tab; return draw(); }
      if (t.closest('#mt-stop')) { if (!await LA.confirm('結束記錄並整理完整會議記錄？')) return; if (rec && rec.id === id) { const r = rec; rec = null; keepOn(false); LA.toast('正在送出最後一段…'); await r.ctl.stop(); } await LA.post(`/api/meetings/${id}/stop`, {}); LA.toast('已結束，正在整理完整記錄（約半分鐘）'); clearInterval(poll); poll = setInterval(draw, 3000); return draw(); }
      const ex = t.closest('[data-exp]'); if (ex) { const f = await LA.post(`/api/meetings/${id}/export`, { format: ex.dataset.exp }); await LA.download(`/api/files/out/${encodeURIComponent(f.id)}`, f.name); return LA.toast('已下載：' + f.name); }
      if (t.closest('#mt-copy')) { const r = await LA.api(`/api/meetings/${id}/markdown?transcript=0`); LA.copy(r.text); return LA.toast('已複製會議記錄'); }
      if (t.closest('#mt-re')) { t.disabled = true; t.textContent = '整理中…'; try { await LA.post(`/api/meetings/${id}/summarize`, {}); LA.toast('已重新整理'); } finally { draw(); } return; }
      if (t.closest('#mt-ren')) { const v = await LA.ask('新的會議名稱', ''); if (v) { await LA.post(`/api/meetings/${id}/rename`, { title: v }); draw(); } return; }
      if (t.closest('#mt-del')) { if (await LA.confirm('刪除這場會議記錄？')) { await LA.del('/api/meetings/' + id); listView(main); } }
    });
    await draw(); poll = setInterval(draw, 4000); const tick = setInterval(() => { if (!rec || view.id !== id) return clearInterval(tick); paintRec(); }, 500);
  }
  LA.register('meeting', { name: '會議監聽', title: '會議監聽（整場會議轉文字＋重點）', async render(main) { if (rec) return detail(main, rec.id); if (view.kind === 'detail' && view.id) return detail(main, view.id); return listView(main); }, leave() { clearInterval(poll); } });
})();
