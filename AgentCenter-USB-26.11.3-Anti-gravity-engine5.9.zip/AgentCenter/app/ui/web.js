'use strict';
/*
 * 26.11.3 pro5 網頁版（給 iPhone／iPad／電腦用，不用安裝 App、不用 IPA 簽章）
 * 主機的公開網址 /net/app/ 會送出同一套畫面＋這支檔案。這裡把畫面接到主機對外的 /net/*：
 *   ・還沒加入 → 顯示「加入」畫面（名字；主機有密碼就輸入密碼；從連線連結來的不用密碼）
 *   ・加入後 → 聯機 token 存在這個瀏覽器（localStorage），之後打開就直接進對話
 *   ・對話、服務選單、檔案、群組走 /net/u/…；主機開放「操作端」給你時，管理頁走 /net/u/admin/…
 * iPhone：用 Safari 打開 → 分享 → 加入主畫面，就會像 App 一樣全螢幕。
 */
(function () {
  const KEY = 'la_web'; let S = null; try { S = JSON.parse(localStorage.getItem(KEY) || 'null'); } catch { S = null; }
  // engine5.7：從固定入口網頁（GitHub Pages 的 index.html）交過來的聯機身分：#s=<base64url JSON>
  //   主機的公開網址會變（每次重開內網穿透都不一樣），這個網址底下存的身分就跟著不見；入口網頁記住身分，每次帶過來
  { const m = /[#&]s=([A-Za-z0-9_-]{20,4000})/.exec(location.hash);
    if (m) { try { const j = JSON.parse(decodeURIComponent(escape(atob(m[1].replace(/-/g, '+').replace(/_/g, '/'))))); if (j && /^[A-Za-z0-9_-]{20,100}$/.test(j.token || '') && /^[A-Z]{4}\d{11}$/.test(j.id || '')) { S = { token: j.token, id: j.id, name: String(j.name || '').slice(0, 24), code: String(j.code || ''), host_name: String(j.host_name || '').slice(0, 24), role: j.role || 'user', status: j.status || 'active', console: j.console || '', version: j.version || '', entry: String(j.entry || '').slice(0, 300) }; try { localStorage.setItem(KEY, JSON.stringify(S)); localStorage.setItem('la_web_id', j.id); } catch { /* 無痕模式 */ } } } catch { /* 格式不對就照原本的加入畫面 */ }
      history.replaceState(null, '', location.pathname); } }
  const inv = (/[#&]i=([A-Za-z0-9_-]{8,40})/.exec(location.hash) || [])[1] || ''; if (inv) history.replaceState(null, '', location.pathname);
  const save = () => { try { localStorage.setItem(KEY, JSON.stringify(S)); } catch { /* 無痕模式存不了：這次開著還是能用 */ } };
  LA.web = true; document.documentElement.classList.add('web'); LA.webState = () => S;
  LA.webLeave = () => { const entry = S && S.entry; try { localStorage.removeItem(KEY); } catch { /* ignore */ } if (entry && /^https:\/\//.test(entry)) location.href = entry.split('#')[0] + '#leave'; else location.reload(); };   // engine5.7：從入口網頁來的，離開時回入口（入口也一起清掉身分）
  const isAdmin = () => !!(S && S.console);
  const RW = /^\/api\/(chat(\/|\?|$)|persona$|services(\/run)?(\?|$)|files\/(out|view)\/|me$|ngroups(\/|\?|$))/;
  LA.rw = (path) => { const p = String(path).split('#')[0]; if (p.startsWith('/net/')) return path; if (RW.test(p)) return '/net/u' + path; if (isAdmin() && /^\/api\//.test(p) && !/^\/api\/(link|transfer|deploy|debug\/report)(\/|$)/.test(p)) return '/net/u/admin' + path; return path; };
  const real = LA.api;
  LA.api = async (path, opt = {}) => {
    const p = String(path).split('?')[0];
    if (p === '/api/link/state') return { mode: 'client', web: true, me: { id: S.id, name: S.name }, client: { code: S.code, host_name: S.host_name, url: location.origin, console: S.console || '', role: S.role || 'user' } };
    if (p === '/api/status' && !isAdmin()) return { version: S.version || '', web: true, platforms: {}, model: null, supervisor: { state: 'running' }, pending: 0 };
    if (!RW.test(p) && !isAdmin()) throw new Error('網頁版沒有這個功能（要在主機的 App 上操作）');
    try { const r = await real(path, opt); if (p === '/api/me' && r && (r.console !== S.console || r.role !== S.role || r.name !== S.name)) { S.console = r.console || ''; S.role = r.role; S.name = r.name || S.name; save(); } return r; }
    catch (e) { if (/聯機已失效|未授權/.test(e.message)) { LA.toast('連線已失效，請重新加入'); setTimeout(LA.webLeave, 1200); } throw e; }
  };
  if (S && S.token) { LA.token = S.token; return; }

  // ---------- 還沒加入：加入畫面 ----------
  LA.token = ''; document.documentElement.classList.add('webjoin');
  const newId = () => { let id = ''; try { id = localStorage.getItem('la_web_id') || ''; } catch { /* ignore */ } if (/^[A-Z]{4}\d{11}$/.test(id)) return id; const r = new Uint32Array(15); crypto.getRandomValues(r); id = Array.from(r.slice(0, 4), (x) => 'ABCDEFGHJKLMNPQRSTUVWXYZ'[x % 24]).join('') + Array.from(r.slice(4), (x) => x % 10).join(''); try { localStorage.setItem('la_web_id', id); } catch { /* ignore */ } return id; };
  const jget = async (url, opt) => { const r = await fetch(url, opt); const j = await r.json().catch(() => ({})); if (!r.ok) throw new Error(j.error || '主機沒有回應（' + r.status + '）'); return j; };
  LA.webJoinUI = async () => {
    const page = LA.$('#page'); const esc = LA.esc; let info = null;
    try { info = await jget('/net/info'); } catch (e) { page.innerHTML = `<div class="card"><h3>連不上主機</h3><div class="hint err">${esc(e.message)}</div><div class="hint">主機那邊要開著 App 並啟動 Bot（內網穿透），這個網址才連得到。</div><button class="btn pri" onclick="location.reload()">再試一次</button></div>`; return; }
    const ios = /iPhone|iPad|iPod/.test(navigator.userAgent) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1); const standalone = window.navigator.standalone === true || matchMedia('(display-mode: standalone)').matches;
    page.innerHTML = `<div class="card webjoin-card"><img src="logo.png" alt="" class="webjoin-logo"><h3 style="justify-content:center">加入「${esc(info.name || '主機')}」的 AI 助理</h3>
      <div class="hint" style="text-align:center">你會成為主機上的一般用戶，可以用的功能由主機決定。</div>
      <label class="f">你的名字（中文或英文）</label><input id="wj-name" maxlength="20" autocomplete="nickname" placeholder="例：小美">
      ${info.locked && !inv ? '<label class="f">聯機密碼（跟主機要）</label><input id="wj-pass" type="password" autocomplete="off">' : ''}
      <label class="row small" style="margin-top:12px;gap:6px;align-items:flex-start"><input type="checkbox" id="wj-agree" style="width:auto;margin-top:2px"><span>我已閱讀並同意<button type="button" class="linkbtn" id="wj-terms">用戶條款</button></span></label>
      <div id="wj-err" class="hint err" hidden></div><button class="btn pri" id="wj-go" style="width:100%;margin-top:14px">加入</button>
      ${ios && !standalone ? '<div class="hint" style="margin-top:14px">iPhone／iPad：加入後按 Safari 下方的「分享」→「加入主畫面」，以後從主畫面點圖示就能像 App 一樣全螢幕使用。</div>' : ''}</div>`;
    const go = async () => {
      const err = LA.$('#wj-err'); const btn = LA.$('#wj-go'); const name = LA.$('#wj-name').value.trim(); err.hidden = true;
      if (!name) { err.hidden = false; err.textContent = '請輸入名字'; return; }
      if (!LA.$('#wj-agree').checked) { err.hidden = false; err.textContent = '請先閱讀並勾選同意用戶條款'; return; }
      btn.disabled = true; btn.textContent = '加入中…';
      try {
        const id = newId(); const r = await jget('/net/join', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ code: info.code, password: (LA.$('#wj-pass') || {}).value || '', invite: inv, id, name, agree: true }) });
        S = { token: r.token, id, name, code: r.code || info.code, host_name: r.host_name || info.name || '', role: r.role, status: r.status, console: r.console || '', version: info.version || '' }; save(); location.reload();
      } catch (e) { err.hidden = false; err.textContent = e.message; btn.disabled = false; btn.textContent = '加入'; }
    };
    LA.$('#wj-terms').onclick = async () => { try { const t = await jget('/net/terms'); LA.modal(`<div class="terms-doc">${LA.richText(t.text.replace(/^# (.+)$/m, '**$1**').replace(/^## (.+)$/gm, '\n**$1**'))}</div><div class="row" style="justify-content:flex-end;margin-top:12px"><button class="btn pri" onclick="LA.closeModal()">關閉</button></div>`); } catch (e) { LA.toast(e.message, true); } };
    LA.$('#wj-go').onclick = go; page.onkeydown = (e) => { if (e.key === 'Enter') go(); };
  };
})();
