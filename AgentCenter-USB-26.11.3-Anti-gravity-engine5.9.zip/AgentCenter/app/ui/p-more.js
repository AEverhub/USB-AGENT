'use strict';
/* 更多：次要頁面的入口（記帳、用戶、群發、設定、開發者）＋教學與版本資訊。底部導覽只留 5 個常用分頁，手機單手點得到。 */
(function () {
  const { esc } = LA;
  const ITEMS = [
    ['services', 'spark', '服務選單', '編輯對話頁下方的按鈕、自動化'],
    ['models', 'brain', '模型與金鑰', 'Gemini、Claude、ChatGPT、NVIDIA、Groq'],
    ['connect', 'plug', '連接器', 'Notion、Jira、Airtable…一鍵連結'],
    ['persona', 'mask', '人設', 'AI 的名字、身份、個性、說話風格'],
    ['files', 'folder', '檔案', '試算表、AI 工作區、備份'],
    ['users', 'users', '用戶', '身份、角色與權限、封鎖'],
    ['groups', 'group', '聯機群組', '和聯機的人開群組一起聊，打 @AI 叫 AI'],
    ['phone', 'grid', '手機代理', 'AI 浮動球：叫 AI 操作手機上的 App、連點器'],
    ['meeting', 'mic', '會議監聽', '聽整場會議或演講，自動整理重點；Discord 語音頻道'],
    ['transfer', 'transfer', '資料轉移', '換手機：下載資料檔，到新手機上傳'],
    ['broadcast', 'megaphone', '群發', '對全部或指定用戶發訊息'],
    ['ledger', 'list', '記帳表', '記帳與統計'],
    ['settings', 'settings', '設定', '平台、時區排程、穿透、MCP、通知'],
    ['dev', 'flask', '開發者', '認領密碼、除錯、背景程式'],
  ];
  LA.register('more', { name: '更多', title: '更多（次要功能入口）', async render(main) {
    const st = LA.status || await LA.refreshStatus().catch(() => null);
    const m = st && st.model;
    // 26.11.3 pro5 網頁版（iPhone／電腦）：一般用戶只看得到自己的連線資訊
    if (LA.web && !(LA.link.client && LA.link.client.console)) {
      const w = LA.webState() || {}; const ios = /iPhone|iPad|iPod/.test(navigator.userAgent) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1); const standalone = window.navigator.standalone === true || matchMedia('(display-mode: standalone)').matches;
      main.innerHTML = `<div class="card"><h3>${LA.icon('globe')} 網頁版 <small>連到「${esc(w.host_name || '主機')}」</small></h3><div class="kv small"><b>名字</b><span>${esc(w.name || '')}</span><b>ID</b><span class="mono">${esc(w.id || '')}</span><b>身分</b><span>${esc(w.role || 'user')}</span></div>
          <div class="hint">可以用的功能、使用次數由主機管理員決定。對話紀錄存在主機上，換裝置用同一個連結加入不會帶過去（ID 不同）。</div></div>
        ${standalone ? '' : `<div class="card"><h3>加到主畫面</h3><div class="hint">${ios ? 'iPhone／iPad：按 Safari 的「分享」按鈕 → 往下找「加入主畫面」→ 加入。之後從主畫面的圖示打開，就會像 App 一樣全螢幕。' : 'Android Chrome：右上角選單 →「加到主畫面」或「安裝應用程式」。電腦 Chrome／Edge：網址列右邊的安裝圖示。'}</div></div>`}
        <div class="mgrid"><button class="mtile" data-go="logic"><span>${LA.icon('grid')}</span><b>邏輯閘轉換器</b><small>化簡、接線圖、加減法器</small></button><button class="mtile" id="more-help"><span>${LA.icon('help')}</span><b>使用教學</b><small>重看新手引導</small></button><button class="mtile" id="web-leave"><span>${LA.icon('x')}</span><b>離開這台主機</b><small>清掉這個瀏覽器的連線</small></button></div>
        <div class="hint" style="text-align:center;margin-top:14px">Agent中控中心 網頁版${st && st.version ? ' v' + esc(st.version) : ''}</div>`;
      main.onclick = LA.guard(async (e) => { const g = e.target.closest('[data-go]'); if (g) return LA.go(g.dataset.go); if (e.target.closest('#more-help')) return LA.go('guide'); if (e.target.closest('#web-leave') && await LA.confirm('離開這台主機？這個瀏覽器會忘記連線，之後要重新用連結加入。')) LA.webLeave(); });
      return;
    }
    main.innerHTML = `<div class="card"><h3>${LA.icon('brain')} 目前模型 <small><span class="dot ${m && m.has_key ? 'ok' : 'bad'}"></span>${m && m.has_key ? '就緒' : '尚無金鑰'}</small></h3>
        <div class="mnow"><b>${esc(m ? (m.label || m.provider) : '—')}</b><span class="mono">${esc(m ? m.name : '')}</span></div><div class="row" style="margin-top:8px"><button class="btn" data-go="models">管理模型與金鑰</button></div></div>
      <div class="mgrid">${ITEMS.filter(([id]) => (LA.link.mode !== 'client' || ['transfer', 'dev'].includes(id) || (LA.link.client && LA.link.client.console === 'admin' && !['groups', 'browser'].includes(id))) && (id !== 'groups' || LA.link.mode === 'host')).map(([id, ic, n, d]) => `<button class="mtile" data-go="${id}"><span>${LA.icon(ic)}</span><b>${n}</b><small>${d}</small></button>`).join('')}
        <button class="mtile" id="more-voice"><span>${LA.icon('speaker')}</span><b>語音包</b><small>語音模式的聲音、語速、辨識方式</small></button>
        <button class="mtile" data-go="sites"><span>${LA.icon('web')}</span><b>網站工作室</b><small>AI 開發網頁系統、預覽、打包 zip</small></button>
        <button class="mtile" data-go="video"><span>${LA.icon('film')}</span><b>影片工作室</b><small>AI 寫分鏡、自動做影片</small></button>
        <button class="mtile" id="more-help"><span>${LA.icon('help')}</span><b>使用指南</b><small>新手任務、每個功能怎麼用、互動教學</small></button>
        <button class="mtile" data-go="terms"><span>${LA.icon('book')}</span><b>用戶條款</b><small>使用規範、資料與隱私</small></button></div>
      <div class="hint" style="text-align:center;margin-top:14px">Agent中控中心 v${esc(st ? st.version : '')}</div>`;
    main.onclick = (e) => { const g = e.target.closest('[data-go]'); if (g) return LA.go(g.dataset.go); if (e.target.closest('#more-help')) return LA.go('guide'); if (e.target.closest('#more-voice') && LA.voice) LA.guard(() => LA.voice.settings())(); };
  } });
})();
