'use strict';
/* A 操作頁：對話、待審批、Bot 狀態與啟停、公開網址（內網穿透）、審批、真實終端機、模型／記憶／消耗、App 內對話、通知中心 */
(function () {
  const { esc, $, $$ } = LA; let term = null;
  const DOT = { running: 'ok', starting: 'warn', stopped: '', failed: 'bad', gave_up: 'bad', error: 'bad' };
  const STATE = { running: '運作中', starting: '啟動中', stopped: '已停止', failed: '失敗', gave_up: '放棄重啟' };
  const PLAT = { line: 'LINE', telegram: 'Telegram', discord: 'Discord', hooks: 'Webhook 伺服器', tunnel: '內網穿透', scheduler: '排程器', mcp: 'MCP 連接器' };

  function tunnelCard(t) {
    const st = { up: ['ok', '已連線'], starting: ['warn', '連線中'], error: ['bad', '錯誤'], off: ['', '未啟用'] }[t.status] || ['', t.status];
    const url = t.url ? `<div class="url"><div class="lbl">公開網址</div><div class="mono">${esc(t.url)}</div><div class="row" style="margin-top:6px"><button class="btn sm" data-copy="${esc(t.url)}">複製網址</button></div></div>
      <div class="url"><div class="lbl">LINE Developers → Messaging API → Webhook URL 填這個</div><div class="mono">${esc(t.webhooks.line)}</div><div class="row" style="margin-top:6px"><button class="btn sm" data-copy="${esc(t.webhooks.line)}">複製 Webhook URL</button></div></div>`
      : `<div class="url mute">${t.status === 'starting' ? '正在建立通道…' : t.enabled ? '目前沒有公開網址' : '內網穿透已關閉（設定頁可開啟）'}</div>`;
    return `<div class="card"><h3>🌐 公開網址（內網穿透）<small><span class="dot ${st[0]}"></span>${st[1]}</small></h3>
      <div class="kv"><b>方式</b><span>${esc(t.mode || '—')}</span><b>本機入口</b><span class="mono">${esc(t.local)}</span>${t.since && t.status === 'up' ? `<b>已連線</b><span>${LA.fmtTime(t.since)}</span>` : ''}</div>
      ${url}${t.note ? `<div class="hint">ℹ️ ${esc(t.note)}</div>` : ''}${t.error ? `<div class="hint err">⚠️ ${esc(t.error)}</div>` : ''}
      <div class="row"><button class="btn sm" id="tun-re">重啟穿透</button><button class="btn sm" id="tun-set">穿透設定</button></div></div>`;
  }

  LA.register('ops', { title: 'A 操作頁', async render(main) {
    main.innerHTML = `<div id="a-appr"></div>
      <div class="card"><h3>💬 和 AI 說話 <small>以管理員身分</small></h3><div id="chat"></div><div class="row"><input id="chat-in" class="grow" placeholder="直接用自然語言下指令…"><button class="btn pri" id="chat-go">送出</button></div></div>
      <div id="a-status"></div><div id="a-info"></div><div id="a-tunnel"></div>
      <div class="card"><h3>🖥️ 終端機 <small id="term-st"></small></h3><pre class="term" id="term"></pre>
        <div class="row"><input id="term-in" class="grow" placeholder="輸入指令，Enter 送出（↑↓ 歷史）" autocapitalize="off" autocomplete="off" autocorrect="off" spellcheck="false"><button class="btn pri" id="term-go">送出</button></div>
        <div class="row" style="margin-top:8px"><button class="btn sm" id="term-clear">清除</button><button class="btn sm" id="term-new">重開</button><button class="btn sm" id="term-sw">${LA.termLinux ? '切到 Android shell' : '切到 Linux'}</button><button class="btn sm" data-q="pwd">pwd</button><button class="btn sm" data-q="ls -la">ls</button><button class="btn sm" data-q="uname -a">uname</button></div>
        <div class="hint">預設是 Android 系統 shell（toybox，沒有 apk／python）。按「切到 Linux」使用 App 內建的 Alpine Linux（要先在「瀏覽器」頁安裝）。下載類指令由你自己在這裡執行不需審批；AI 執行才要審批。</div></div>
      <div id="a-notes"></div>`;
    $('#a-status').onclick = LA.guard(async (e) => { const b = e.target.closest('[data-act]'); if (!b) return; b.disabled = true; try { await LA.post('/api/bot', { action: b.dataset.act }); await LA.refreshStatus(); await paint(); LA.toast('完成'); } finally { b.disabled = false; } });
    main.onclick = LA.guard(async (e) => {
      const c = e.target.closest('[data-copy]'); if (c) return LA.copy(c.dataset.copy);
      const go = e.target.closest('[data-go]'); if (go) return LA.go(go.dataset.go);
      if (e.target.id === 'tun-re') { LA.toast('重啟穿透中…'); await LA.post('/api/tunnel/restart'); await paint(); }
      if (e.target.id === 'tun-set') LA.go('settings');
      const q = e.target.closest('[data-q]'); if (q) sendTerm(q.dataset.q);
      const ap = e.target.closest('[data-ap]'); if (ap) { ap.disabled = true; await LA.post('/api/approvals/' + ap.dataset.id, { approve: ap.dataset.ap === '1' }); LA.toast(ap.dataset.ap === '1' ? '已核准' : '已拒絕'); await paint(); }
    });
    openTerm(); $('#term-go').onclick = () => sendTerm(); $('#term-clear').onclick = () => { $('#term').textContent = ''; }; $('#term-new').onclick = () => { closeTerm(); openTerm(); }; $('#term-sw').onclick = () => { LA.termLinux = !LA.termLinux; $('#term-sw').textContent = LA.termLinux ? '切到 Android shell' : '切到 Linux'; closeTerm(); openTerm(); };
    const hist = []; let hi = 0; $('#term-in').onkeydown = (e) => { if (e.key === 'Enter') sendTerm(); else if (e.key === 'ArrowUp') { hi = Math.max(0, hi - 1); e.target.value = hist[hi] || ''; e.preventDefault(); } else if (e.key === 'ArrowDown') { hi = Math.min(hist.length, hi + 1); e.target.value = hist[hi] || ''; e.preventDefault(); } };
    function sendTerm(cmd) { const i = $('#term-in'); const t = cmd ?? i.value; if (!t.trim() || !term) return; hist.push(t); hi = hist.length; i.value = ''; LA.post('/api/term/input', { id: term.id, text: t + '\n' }).catch((e) => LA.toast(e.message, true)); }
    const chat = async () => { const i = $('#chat-in'); const t = i.value.trim(); if (!t) return; i.value = ''; add('me', t); const w = add('ai', '…'); try { const r = await LA.post('/api/chat', { text: t }); w.textContent = r.text; for (const im of r.images || []) { const g = document.createElement('img'); g.src = `data:${im.mime};base64,${im.data}`; g.style.cssText = 'display:block;max-width:100%;border-radius:10px;margin:6px 0'; w.prepend(g); } } catch (e) { w.textContent = '⚠️ ' + e.message; w.classList.add('err'); } LA.report(); };
    const add = (who, t) => { const d = document.createElement('div'); d.className = 'bub ' + who; d.textContent = t; $('#chat').appendChild(d); d.scrollIntoView({ block: 'nearest' }); return d; };
    $('#chat-go').onclick = chat; $('#chat-in').onkeydown = (e) => { if (e.key === 'Enter') chat(); };
    await paint(); LA.every(3000, paint);
  }, leave() { closeTerm(); } });

  async function paint() {
    const [st, t, ap, nt] = await Promise.all([LA.refreshStatus(), LA.api('/api/tunnel'), LA.api('/api/approvals'), LA.api('/api/notifications')]); if (LA.cur !== 'ops') return;
    const sv = st.supervisor; const u = st.usage; const m = st.memory; const max = Math.max(1, ...u.days.map((d) => d.in + d.out));
    $('#a-status').innerHTML = `<div class="card"><h3>🤖 Bot 狀態 <small>${sv.running ? '已運作 ' + LA.fmtDur(sv.uptime_s) : '未啟動'}</small></h3>
      <div class="row" style="margin-bottom:10px"><button class="btn ok grow" data-act="start" ${sv.running ? 'disabled' : ''}>▶ 啟動</button><button class="btn bad grow" data-act="stop" ${!sv.running ? 'disabled' : ''}>■ 停止</button><button class="btn pri grow" data-act="restart">↻ 重啟</button></div>
      <div class="list">${sv.services.map((s) => { const p = st.platforms[s.name]; const label = PLAT[s.name] || s.name; const off = p && !p.enabled; return `<div class="row"><span class="grow"><span class="dot ${off ? '' : DOT[s.state] || ''}"></span>${esc(label)}</span><span class="mute small">${off ? '未啟用' : esc(STATE[s.state] || s.state)}${s.restarts ? ' · 重啟' + s.restarts + '次' : ''}</span></div>${s.error ? `<div class="hint err" style="margin:0">${esc(s.error)}</div>` : ''}`; }).join('')}</div>
      ${!st.has_admin ? '<div class="hint warn">⚠️ 還沒有管理員：到「用戶」頁建立 App 管理員，或在平台私訊 /claim 密碼。</div>' : ''}${!st.model.has_key ? '<div class="hint warn">⚠️ 還沒設定模型 API Key。<button class="btn sm" data-go="models">到模型頁設定</button></div>' : ''}</div>`;
    $('#a-tunnel').innerHTML = tunnelCard(t);
    $('#a-appr').innerHTML = ap.length ? `<div class="card"><h3>📝 待審批 <small>${ap.length} 件</small></h3><div class="list">${ap.map((a) => `<div><div><span class="tag">${esc(a.kind === 'download' ? '下載' : a.kind === 'new_user' ? '新用戶' : a.kind)}</span>#${a.id} ${esc(a.summary)}</div><div class="row" style="margin-top:6px"><button class="btn ok sm" data-ap="1" data-id="${a.id}">核准</button><button class="btn bad sm" data-ap="0" data-id="${a.id}">拒絕</button><span class="mute small">${LA.fmtTime(a.created)}</span></div></div>`).join('')}</div></div>` : '';
    $('#a-info').innerHTML = `<div class="card"><h3>📊 模型 · 記憶 · 消耗</h3><div class="kv"><b>模型</b><span>${esc(st.model.label || st.model.provider)} / ${esc(st.model.name)} ${st.model.has_key ? '' : '<span class="err">（無金鑰）</span>'} <button class="btn sm" data-go="models">切換</button></span>
      ${u.turns ? `<b>每次對話</b><span>平均 ${(u.turns.avg_in + u.turns.avg_out).toLocaleString()} tokens（輸入 ${u.turns.avg_in.toLocaleString()}・輸出 ${u.turns.avg_out.toLocaleString()}）・${u.turns.avg_rounds} 輪・送出工具 ${u.turns.avg_tools} 個${u.turns.experience ? `・已學會 ${u.turns.experience.entries} 種做法（重複用上 ${u.turns.experience.reused} 次）` : ''}${u.turns.skills ? `・技能 ${u.turns.skills.usable}／${u.turns.skills.total} 個可用${u.turns.skills.third ? `（第三方 ${u.turns.skills.third}）` : ''}` : ''}${u.turns.consolidate ? `・上次記憶整理 ${String(u.turns.consolidate.at).slice(5, 16).replace('T', ' ')}（合併 ${u.turns.consolidate.facts + u.turns.consolidate.vectors} 筆）` : ''}</span>` : ''}<b>今日</b><span>${u.today.calls} 次呼叫 · 輸入 ${u.today.in.toLocaleString()} · 輸出 ${u.today.out.toLocaleString()} tokens</span><b>累計</b><span>${u.total.calls} 次 · ${(u.total.in + u.total.out).toLocaleString()} tokens</span>
      <b>對話紀錄</b><span>${m.messages.toLocaleString()} 則（${LA.fmtBytes(m.bytes)}）</span><b>長期事實</b><span>${m.facts}</span><b>向量記憶</b><span>${m.vectors} 筆</span><b>使用者</b><span>${m.persons} 人</span><b>試算表</b><span>${m.sheets} 張</span><b>資料夾佔用</b><span>${LA.fmtBytes(m.disk_bytes)}</span></div>
      <div class="hint" style="margin-top:8px">近 14 天 token 用量</div><div class="bars">${u.days.map((d) => `<i title="${d.day}: ${d.in + d.out}" style="height:${Math.max(3, ((d.in + d.out) / max) * 100)}%"></i>`).join('') || '<span class="mute small">尚無資料</span>'}</div></div>`;
    $('#a-notes').innerHTML = `<div class="card"><h3>🔔 通知中心 <small><a href="#" id="nt-read" style="color:var(--ac)">全部已讀</a></small></h3><div class="list">${nt.items.slice().reverse().slice(0, 12).map((n) => `<div style="${n.read ? 'opacity:.55' : ''}"><span class="tag ${n.level === 'error' || n.level === 'critical' ? 'admin' : ''}">${esc(n.level)}</span><b>${esc(n.title)}</b> <span class="mute small">${LA.fmtTime(n.ts)}</span><div class="small mute" style="white-space:pre-wrap">${esc(n.text)}</div></div>`).join('') || '<div class="mute">沒有通知</div>'}</div></div>`;
    const r = $('#nt-read'); if (r) r.onclick = LA.guard(async (e) => { e.preventDefault(); await LA.post('/api/notifications/read'); await paint(); });
  }
  async function openTerm() {
    let r; try { r = await LA.post('/api/term/open', { linux: !!LA.termLinux }); } catch (e) { LA.termLinux = false; const sw = $('#term-sw'); if (sw) sw.textContent = '切到 Linux'; LA.toast(e.message, true); r = await LA.post('/api/term/open', {}); } term = { id: r.id }; const out = $('#term'); if (!out) return; out.textContent = r.buf || '';
    const es = new EventSource(`/api/term/stream?id=${r.id}&t=${encodeURIComponent(LA.token)}`); term.es = es; $('#term-st').innerHTML = '<span class="dot ok"></span>已連線';
    es.onmessage = (e) => { const o = $('#term'); if (!o) return; o.textContent = (o.textContent + JSON.parse(e.data)).slice(-40000); o.scrollTop = o.scrollHeight; }; es.onerror = () => { const s = $('#term-st'); if (s) s.innerHTML = '<span class="dot bad"></span>中斷'; };
    out.scrollTop = out.scrollHeight;
  }
  function closeTerm() { if (term) { try { term.es && term.es.close(); LA.post('/api/term/close', { id: term.id }).catch(() => {}); } catch { /* ignore */ } term = null; } }
})();
