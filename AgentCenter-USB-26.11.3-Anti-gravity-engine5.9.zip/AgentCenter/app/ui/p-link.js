'use strict';
/*
 * 聯機（26.11.3 Revise3）
 *  - 預設「單機」：App 第一次打開不問任何事，直接用＋教學。
 *  - 設定在「更多 → 開發者 → 聯機」：設為主機（產生連線連結）、或連到別人的主機（貼連結／從選單選／輸入聯機碼）。
 *  - 連線連結：主機按「分享連線連結」傳給對方 → 對方點開 → 按「同意」→ App 打開 → 再按「同意並連線」就連上，不用打代碼。
 */
(function () {
  const { esc } = LA; const $ = (s, r = document) => r.querySelector(s);

  /** 解析連線連結：agentcenter://join?…、https://目錄/j/碼-邀請、https://主機/net/j/碼-邀請 */
  LA.parseJoinLink = (s) => {
    const t = String(s || '').trim(); let u; try { u = new URL(t); } catch { return null; }
    if (u.protocol === 'agentcenter:') { const q = u.searchParams; const c = (q.get('c') || '').toUpperCase(); if (!/^[A-Z2-9]{6}$/.test(c)) return null; return { code: c, invite: q.get('k') || '', name: q.get('n') || '', directory: q.get('d') || '', url: q.get('u') || '' }; }
    const m = /^(\/net)?\/j\/([A-Z2-9]{6})-([A-Za-z0-9]{8,40})$/.exec(u.pathname); if (!m || !/^https?:$/.test(u.protocol)) return null;
    return m[1] ? { code: m[2], invite: m[3], name: '', directory: '', url: u.origin } : { code: m[2], invite: m[3], name: '', directory: u.origin, url: '' };
  };

  /** 點了連線連結 → 問一次「同意並連線」（名字已經有就不用再填） */
  LA.onJoinLink = (s) => new Promise((done) => {
    const j = LA.parseJoinLink(s); if (!j) { LA.toast('這不是有效的連線連結', true); return done(false); }
    const me = (LA.link && LA.link.me) || null; const ov = document.createElement('div'); ov.className = 'lk-ov'; document.body.appendChild(ov);
    const close = (ok) => { ov.classList.add('out'); setTimeout(() => { ov.remove(); done(ok); }, 250); };
    ov.innerHTML = `<div class="lk-box"><div class="lk-logo">${LA.icon('transfer', 'lg')}</div><h2>加入「${esc(j.name || '主機')}」的 AI 助理？</h2>
      <p class="mute">同意後，這台 App 會連到對方的主機，你會是那邊的一般用戶（能用什麼、能用幾次由主機決定）。這台原本的資料會保留，之後可以在「開發者 → 聯機」改回單機。</p>
      <label class="f">你的名字（中文或英文，讓主機知道你是誰）</label><input id="lk-name" maxlength="24" value="${esc(me ? me.name : '')}" placeholder="例：王小明／Amy">
      <div class="row" style="justify-content:space-between;margin-top:16px"><button class="btn" id="lk-no">不要</button><button class="btn pri" id="lk-yes">同意並連線</button></div><div id="lk-err" class="err small"></div></div>`;
    $('#lk-no', ov).onclick = () => close(false);
    $('#lk-yes', ov).onclick = async (e) => {
      const b = e.currentTarget; b.disabled = true; b.textContent = '連線中…';
      try {
        const r = await LA.post('/api/link/join', { name: $('#lk-name', ov).value, target: j.url ? `${j.code}@${j.url}` : j.code, invite: j.invite, directory: j.directory });
        LA.link = await LA.api('/api/link/state'); LA.renderTabs(); LA.go('home'); LA.toast(`已連上「${r.host_name || '主機'}」`); close(true);
      } catch (err) { $('#lk-err', ov).textContent = err.message; b.disabled = false; b.textContent = '同意並連線'; }
    };
  });

  const share = async (text) => {
    if (window.AndroidBridge && AndroidBridge.shareText) { try { AndroidBridge.shareText(text); return; } catch { /* 往下 */ } }
    if (navigator.share) { try { await navigator.share({ text }); return; } catch { /* 取消 */ } }
    LA.copy(text);
  };

  function joinFields() {
    return `<label class="f">貼上連線連結（最簡單）</label><input id="lk-paste" placeholder="https://…/j/…　或　agentcenter://join?…">
      <details style="margin-top:8px"><summary class="small mute">沒有連結？用聯機碼</summary>
        <label class="f">從清單選</label><select id="lk-sel"><option value="">讀取中…</option></select>
        <label class="f">或手動輸入</label><input id="lk-code" autocapitalize="characters" placeholder="聯機碼（例 K7P2QX）或 聯機碼@主機網址">
        <label class="f">聯機密碼</label><input id="lk-jpw" type="password" autocomplete="off" placeholder="主機有設才需要"></details>`;
  }
  async function fillDirectory(root) {
    const sel = $('#lk-sel', root); if (!sel) return;
    try {
      const d = await LA.api('/api/link/list');
      sel.innerHTML = `<option value="">${d.items.length ? '— 選一個 —' : (d.directory ? '目前沒有公開的聯機碼' : '沒有聯機目錄')}</option>` + d.items.map((x) => `<option value="${esc(x.code)}">${esc(x.code)}　${esc(x.name || '主機')}${x.locked ? '（要密碼）' : ''}${x.online ? '' : '（離線）'}</option>`).join('');
    } catch (e) { sel.innerHTML = `<option value="">讀不到聯機目錄：${esc(e.message)}</option>`; }
  }
  async function joinFrom(root) {
    const pasted = ($('#lk-paste', root) || {}).value || '';
    if (pasted.trim()) { const ok = await LA.onJoinLink(pasted.trim()); if (!ok) return; return; }
    const target = (($('#lk-code', root) || {}).value || '').trim() || (($('#lk-sel', root) || {}).value || '');
    if (!target) throw new Error('請貼上連線連結，或選／輸入聯機碼');
    const me = LA.link.me; let name = me && me.name; if (!name) { name = await LA.ask('你的名字（中文或英文）', ''); if (!name) return; }
    const r = await LA.post('/api/link/join', { target, password: ($('#lk-jpw', root) || {}).value || '', name });
    LA.link = await LA.api('/api/link/state'); LA.renderTabs(); LA.toast(`已連上「${r.host_name || '主機'}」`); LA.go('home');
  }

  /** 開發者頁「聯機」分頁的內容（也給 'link' 頁用） */
  /** engine5.7 聯機碼產生器：固定入口（GitHub Pages）的連結＋QR Code，iPhone 用相機掃一下就能加入 */
  function genCard(s, inv) {
    const e = s.web_entry || ''; const h = s.host || {};
    const qr = (t) => { try { return window.QR ? QR.svg(t, { size: 200, margin: 3 }) : ''; } catch { return ''; } };
    let body;
    if (!e) body = `<div class="hint">先把專案裡的 <span class="mono">web/index.html</span> 放到 GitHub Pages（步驟見 web/README.md），再把網址貼在下面。之後這裡會產生：給 iPhone／iPad 掃的 QR Code、分享連結、大字的聯機碼。</div>`;
    else if (!inv.gh) body = `<div class="err small">${esc(inv.note || '主機還連不到外面：到「監控」啟動 Bot（內網穿透）後才會產生連結')}</div>`;
    else body = `<div class="lk-gen" style="text-align:center;margin:10px 0">
        <div class="lk-qr" style="display:inline-block;background:#fff;padding:6px;border-radius:10px;line-height:0">${qr(inv.gh)}</div>
        <div class="small mute" style="margin-top:6px">用 iPhone 相機掃這個 → 填名字 → 加入（不用密碼）</div>
        <div class="mono" style="font-size:28px;letter-spacing:3px;margin-top:10px;user-select:all">${esc(h.code || '')}</div>
        <div class="small mute">聯機碼${h.locked ? '・用聯機碼加入要輸入聯機密碼' : ''}</div></div>
      <label class="f">邀請連結（不用密碼）</label><div class="mono small lk-url">${esc(inv.gh)}</div>
      <div class="row" style="gap:8px;margin-top:6px;flex-wrap:wrap"><button class="btn pri sm" id="lk-sharegh">分享</button><button class="btn sm" data-copy="${esc(inv.gh)}">複製</button></div>
      <label class="f" style="margin-top:10px">只帶聯機碼的連結${h.locked ? '（要密碼）' : ''}</label><div class="mono small lk-url">${esc(inv.gh_code)}</div>
      <div class="row" style="gap:8px;margin-top:6px"><button class="btn sm" data-copy="${esc(inv.gh_code)}">複製</button></div>
      <div class="hint">${inv.gh_stable ? '有聯機目錄：這些連結和 QR Code 一直有效，主機重開也不用重新分享。' : '<b>注意：</b>沒有設定聯機目錄，連結裡帶的是主機現在的網址，主機重開後要回來這裡重新產生。'}邀請連結外流了，到上面按「重設連結」，舊的邀請碼就失效。</div>`;
    return `<div class="card" id="lk-gencard"><h3 style="margin-top:0">${LA.icon('link')} 聯機碼產生器 <small>QR Code・分享連結</small></h3>${body}
      <details style="margin-top:10px"${e ? '' : ' open'}><summary class="small">網頁入口網址（GitHub Pages）</summary>
        <input id="lk-entry" value="${esc(e)}" placeholder="https://你的帳號.github.io/agent/" inputmode="url" style="margin-top:6px"><button class="btn sm" id="lk-esave" style="margin-top:6px">儲存入口網址</button></details></div>`;
  }
  LA.renderLink = async (main) => {
    const s = LA.link = await LA.api('/api/link/state'); const me = s.me;
    const who = me ? `<div class="kv"><b>名字</b><span>${esc(me.name)}</span><b>ID</b><span class="mono">${esc(me.id)} <button class="btn sm" data-copy="${esc(me.id)}">複製</button></span></div>` : '<div class="hint">還沒有聯機身分（設為主機或連線時會自動產生：4 個英文字母＋11 位數字）</div>';
    if (!s.mode) {
      main.innerHTML = `<div class="card"><h3 style="margin-top:0">目前是單機模式</h3><div class="hint" style="margin-top:0">只有這台自己用。想讓遠方的人一起用同一個 AI，選下面其中一個。</div></div>
        <div class="card"><h3 style="margin-top:0">${LA.icon('home')} 設為主機</h3><div class="small mute">這台當 AI 主機，你是管理員。產生一個連線連結，傳給對方，對方點開按「同意」就能連進來。</div>
          <label class="f">你的名字</label><input id="lk-hname" maxlength="24" placeholder="例：王大明">
          <div class="row" style="justify-content:flex-end;margin-top:10px"><button class="btn pri" id="lk-mkhost">設為主機並產生連結</button></div></div>
        <div class="card"><h3 style="margin-top:0">${LA.icon('transfer')} 連到別人的主機／伺服器</h3><div class="small mute">貼上對方給你的連線連結（伺服器安裝完會印出連結）。連上後你是那邊的一般用戶，能用什麼、能不能看操作端由那邊的管理員決定；伺服器的管理員用「/claim 密碼」取得。</div>${joinFields()}<div class="row" style="justify-content:flex-end;margin-top:10px"><button class="btn pri" id="lk-join">連線</button></div></div>
        <div class="card"><h3 style="margin-top:0">${LA.icon('server')} 把 AI 裝到伺服器</h3><div class="small mute">要讓 AI 24 小時在雲端或家裡的主機上跑：到「伺服器」分頁產生一串安裝指令。</div><button class="btn sm" id="lk-srv" style="margin-top:8px">前往伺服器安裝</button></div>`;
      fillDirectory(main);
    } else if (s.mode === 'host') {
      const h = s.host; const inv = h.invite || {};
      main.innerHTML = `<div class="card"><div class="small mute">主機模式・你是管理員</div><h3 style="margin:6px 0">連線連結</h3>
          ${inv.url ? `<div class="mono small lk-url">${esc(inv.url)}</div><div class="row" style="gap:8px;margin-top:8px;flex-wrap:wrap"><button class="btn pri" id="lk-share">分享連線連結</button><button class="btn sm" data-copy="${esc(inv.url)}">複製</button><button class="btn sm" id="lk-reset">重設連結</button></div>
            <div class="hint">對方點開連結 → 按「同意」→ App 打開後再按「同意並連線」。拿到連結的人不用密碼就能加入，外流了就按「重設連結」，舊的會失效。${inv.stable ? '' : '<br><b>注意：</b>沒有設定聯機目錄，主機重開後網址會變，要重新分享連結。'}</div>`
          : `<div class="err small">${esc(inv.note || '還沒有公開網址')}</div><button class="btn sm" data-go="ops" style="margin-top:6px">到監控啟動 Bot</button>`}</div>
        ${inv.web ? `<div class="card"><h3 style="margin-top:0">網頁版 <small>iPhone、iPad、電腦用（不用安裝）</small></h3><div class="mono small lk-url">${esc(inv.web)}</div><div class="row" style="gap:8px;margin-top:8px;flex-wrap:wrap"><button class="btn pri" id="lk-shareweb">分享網頁版連結</button><button class="btn sm" data-copy="${esc(inv.web)}">複製</button></div>
          <div class="hint">對方用 Safari（iPhone）或任何瀏覽器打開 → 填名字 → 加入。iPhone 再按「分享 → 加入主畫面」，就會像 App 一樣全螢幕。上面的連線連結點開也有「用網頁版開啟」的按鈕。這台主機要開著而且 Bot（內網穿透）在跑，對方才連得到；主機重開後如果公開網址變了，要重新分享。</div></div>` : ''}
        ${genCard(s, inv)}
        <div class="card"><h3 style="margin-top:0">聯機進來的人 <small>${h.members.length} 位</small></h3><div class="list">${h.members.map((m) => `<div class="row"><span class="grow"><b>${esc(m.name)}</b> <span class="mono small mute">${esc(m.id || '')}</span></span><span class="tag">${esc(m.role)}</span>${m.status !== 'active' ? `<span class="tag guest">${esc(m.status)}</span>` : ''}</div>`).join('') || '<div class="mute">還沒有人</div>'}</div>
          <div class="hint">權限、使用次數、封鎖到「更多 → 用戶」管理（標示「聯機」）。</div></div>
        <details class="card"><summary><b>進階：聯機碼、密碼、目錄</b></summary>
          <div class="kv" style="margin-top:8px"><b>聯機碼</b><span class="mono">${esc(h.code)} <button class="btn sm" data-copy="${esc(h.code)}">複製</button></span><b>公開網址</b><span>${h.url ? esc(h.url) : '還沒有'}</span><b>目錄登記</b><span>${h.announced ? '已登記 ' + LA.fmtTime(h.announced.at) : (h.public ? '等待中' : '不公開')}</span></div>
          <label class="chk"><input type="checkbox" id="lk-pub" ${h.public ? 'checked' : ''}> 公開在聯機清單（別人用聯機碼選單看得到）</label>
          <label class="f">聯機密碼（只有用聯機碼加入才需要；連線連結不用）</label><input id="lk-pw" type="password" autocomplete="new-password" placeholder="${h.locked ? '已設定（留空＝不變）' : '不填＝不需要密碼'}">
          <div class="row" style="gap:8px;margin-top:8px"><button class="btn sm pri" id="lk-save">儲存</button>${h.locked ? '<button class="btn sm" id="lk-nopw">取消密碼</button>' : ''}<button class="btn sm" id="lk-ann">立刻登記目錄</button></div>
          <label class="f" style="margin-top:12px">聯機目錄網址</label><input id="lk-dir" value="${esc(s.directory || '')}" placeholder="https://xxx.workers.dev（部署 relay/cloudflare-worker.mjs）"><button class="btn sm" id="lk-dsave" style="margin-top:6px">儲存目錄網址</button></details>
        <div class="card"><h3 style="margin-top:0">我的身分</h3>${who}<div class="row" style="margin-top:10px;gap:8px"><button class="btn sm bad" id="lk-solo">改回單機</button></div></div>`;
    } else {
      const c = s.client;
      main.innerHTML = `<div class="card"><div class="small mute">已連到別人的主機・一般用戶</div><h2 style="margin:6px 0">${esc(c.host_name || '主機')}</h2><div class="kv"><b>狀態</b><span>${c.joined ? '<span class="ok-t">已連線</span>' : '<span class="err">需要重新連線</span>'}</span><b>聯機碼</b><span class="mono">${esc(c.code || '')}</span></div></div>
        <div class="card"><h3 style="margin-top:0">我的身分</h3>${who}<div class="kv" style="margin-top:6px"><b>角色</b><span>${esc(c.role || 'user')}${c.console ? `・可以${c.console === 'admin' ? '操作' : '看'}主機的操作端` : ''}</span></div>
          ${c.role !== 'admin' ? '<div class="hint">如果這是你自己的伺服器：在對話裡傳「/claim 伺服器密碼」就會成為管理員。</div>' : ''}</div>
        <div class="card"><h3 style="margin-top:0">換主機／重新連線</h3>${joinFields()}<div class="row" style="justify-content:flex-end;margin-top:10px"><button class="btn pri" id="lk-join">連線</button></div></div>
        <div class="card"><button class="btn bad sm" id="lk-solo">中斷連線、改回單機</button></div>`;
      fillDirectory(main);
    }
    main.onclick = LA.guard(async (e) => {
      const t = e.target.closest('button'); if (!t) return; const id = t.id;
      const cp = t.closest('[data-copy]'); if (cp) return LA.copy(cp.dataset.copy);
      const again = () => LA.renderLink(main);
      if (id === 'lk-mkhost') { const n = $('#lk-hname', main).value.trim(); if (!n) throw new Error('請填你的名字'); await LA.post('/api/link/host', { name: n }); LA.toast('已設為主機'); return again(); }
      if (id === 'lk-share') { const s2 = LA.link.host.invite; return share(`邀請你使用我的 AI 助理，點這個連結、按「同意」就能連上：\n${s2.url}`); }
      if (id === 'lk-shareweb') return share(`用網頁就能使用我的 AI 助理（iPhone 用 Safari 打開，再「加入主畫面」）：\n${LA.link.host.invite.web}`);
      if (id === 'lk-sharegh') return share(`用手機或電腦就能使用我的 AI 助理，點開連結、填名字就能加入（iPhone 用 Safari 打開，再「加入主畫面」）：\n${LA.link.host.invite.gh}`);
      if (id === 'lk-esave') { await LA.post('/api/link/host/update', { web_entry: $('#lk-entry', main).value.trim() }); LA.toast('已儲存'); return again(); }
      if (id === 'lk-reset' && await LA.confirm('重設連線連結？舊連結會失效（已經連進來的人不受影響）。')) { await LA.post('/api/link/host/update', { reset_invite: true }); LA.toast('已產生新連結'); return again(); }
      if (id === 'lk-join') return joinFrom(main);
      if (id === 'lk-srv') return LA.devTab('srv');
      if (id === 'lk-ann') { await LA.post('/api/link/announce'); LA.toast('已登記'); return again(); }
      if (id === 'lk-save') { await LA.post('/api/link/host/update', { public: $('#lk-pub', main).checked, password: $('#lk-pw', main).value }); LA.toast('已儲存'); return again(); }
      if (id === 'lk-nopw' && await LA.confirm('取消聯機密碼？')) { await LA.post('/api/link/host/update', { clear_password: true }); return again(); }
      if (id === 'lk-dsave') { await LA.post('/api/settings', { key: 'link.directory_url', value: $('#lk-dir', main).value.trim() }); LA.toast('已儲存'); return again(); }
      if (id === 'lk-solo' && await LA.confirm(s.mode === 'host' ? '改回單機？別人就連不進來了（資料、聯機碼保留，之後可以再設回主機）。' : '中斷連線、改回單機？')) {
        await LA.post('/api/link/leave'); LA.link = await LA.api('/api/link/state'); LA.renderTabs(); LA.toast('已改回單機'); return LA.cur === 'home' ? LA.go('home') : again();
      }
    });
  };
  LA.register('link', { name: '聯機', title: '聯機', render: (main) => LA.renderLink(main) });
})();
