'use strict';
/* 對話（App 第一頁）：像傳訊息一樣交代事情。歷史與 LINE／Telegram／Discord 私訊共用；＋ 可拍照、掃發票、叫出服務。
   26.12：畫面只做「增量更新」——外框只畫一次，新訊息附加到最後、等待中的那則原地換內容，
   不再整頁重畫（舊版每次重畫會把捲動位置歸零再平滑捲到底 → 抖動；輸入框也會被重建、鍵盤跳掉）。 */
(function () {
  const { esc, $ } = LA;
  let msgs = []; let persona = null; let tiles = []; let busy = false; let pendingImg = null; let pendingFile = null; let replyTo = null; let root = null; let more = false; let loadingOld = false;
  // Anti-gravity-engine1：服務選單預設「收起」，畫面更乾淨（要打開過一次才會記住展開）；按 grid 鈕隨時開關
  const menuOpen = () => { try { return localStorage.getItem('la_chat_menu') === '1'; } catch { return false; } };
  const media = (n) => LA.rw(`/api/chat/media/${encodeURIComponent(n)}`) + `?t=${encodeURIComponent(LA.token)}`;
  const PLAT = { line: 'LINE', telegram: 'Telegram', discord: 'Discord', app: '', system: '排程', net: '' };
  const fmt = (t) => { const d = new Date(t || Date.now()); return `${d.getHours()}:${String(d.getMinutes()).padStart(2, '0')}`; };
  const day = (t) => new Date(t || Date.now()).toDateString();
  const initial = () => esc(((persona && persona.name) || 'AI').slice(0, 1));
  const list = () => root && $('#c-list', root);
  const nearBottom = () => { const l = list(); return !l || l.scrollHeight - l.scrollTop - l.clientHeight < 120; };
  const toBottom = () => { const l = list(); if (l) l.scrollTop = l.scrollHeight; };

  // 26.11.3 Revise8：檔案卡。圖片直接顯示、影片顯示畫面＋播放鍵（點了用 App 內建播放器）、其他檔案點了先確認再下載
  const viewUrl = (id) => `${LA.rw('/api/files/view/' + encodeURIComponent(id))}?t=${encodeURIComponent(LA.token)}`;
  const kindOf = (f) => { const t = String(f.mime || ''); const n = String(f.name || ''); return /^video\//.test(t) || /\.(mp4|mov|webm|m4v)$/i.test(n) ? 'video' : /^image\//.test(t) || /\.(png|jpe?g|webp|gif)$/i.test(n) ? 'image' : /^audio\//.test(t) || /\.(mp3|m4a|wav|ogg)$/i.test(n) ? 'audio' : 'file'; };
  const sizeOf = (b) => (!b ? '' : b >= 1048576 ? (b / 1048576).toFixed(1) + ' MB' : Math.max(1, Math.round(b / 1024)) + ' KB');
  function fileCard(f) {
    const k = kindOf(f); const id = f.id ? esc(f.id) : ''; const nm = esc(f.name || '檔案'); const meta = `${nm}${f.size ? '・' + sizeOf(f.size) : ''}`;
    if (k === 'image' && (f.id || f.local)) return `<img class="cfimg" src="${f.local || viewUrl(f.id)}" alt="" loading="lazy" data-zoom="1">`;
    if (k === 'video') return `<button class="cvid" ${id ? `data-play="${id}"` : 'disabled'} data-name="${nm}" data-kind="video">${f.id || f.local ? `<video src="${f.local || viewUrl(f.id)}#t=0.1" preload="metadata" muted playsinline></video>` : ''}<i class="cplay">${LA.icon('play')}</i><small>${meta}${id ? '' : '・傳送中'}</small></button>`;
    const icon = k === 'audio' ? 'speaker' : /\.(xlsx|csv)$/i.test(f.name) ? 'table' : 'doc';
    return `<button class="cfile" ${id ? (k === 'audio' ? `data-play="${id}" data-kind="audio"` : `data-file="${id}"`) : 'disabled'} data-name="${nm}" data-size="${esc(sizeOf(f.size))}">${LA.icon(icon)}<span class="grow"><b>${nm}</b><small>${f.size ? sizeOf(f.size) + '・' : ''}${!id ? '傳送中…' : k === 'audio' ? '點一下播放' : '點一下下載'}</small></span>${LA.icon(k === 'audio' ? 'play' : 'down')}</button>`;
  }
  /** App 內建播放器：影片／音訊，可以下載 */
  function player(id, name, kind) {
    const src = viewUrl(id); LA.modal(`<div class="cplayer">${kind === 'audio' ? `<audio src="${src}" controls autoplay style="width:100%"></audio>` : `<video src="${src}" controls autoplay playsinline></video>`}<div class="row" style="margin-top:10px;justify-content:space-between"><b class="grow" style="min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc(name)}</b><button class="btn" id="cp-dl">${LA.icon('down', 'sm')} 下載</button><button class="btn" id="cp-x">關閉</button></div></div>`, (m) => {
      m.querySelector('#cp-x').onclick = () => { const v = m.querySelector('video,audio'); if (v) v.pause(); LA.closeModal(); };
      m.querySelector('#cp-dl').onclick = LA.guard(async () => { await LA.download(`/api/files/out/${encodeURIComponent(id)}`, name); LA.toast('已下載：' + name); });
    });
  }
  /** 選一個檔案傳給 AI（最大 20MB）；圖片照舊直接顯示 */
  function pickFile() {
    return new Promise((resolve) => {
      const inp = document.createElement('input'); inp.type = 'file'; inp.style.display = 'none'; document.body.appendChild(inp);
      inp.onchange = () => { const f = inp.files && inp.files[0]; inp.remove(); if (!f) return resolve(null); if (f.size > 20 * 1024 * 1024) { LA.toast('檔案超過 20MB', true); return resolve(null); }
        const r = new FileReader(); r.onload = () => { const data = String(r.result).split(',')[1] || ''; resolve({ name: f.name, mime: f.type || '', size: f.size, data, local: /^(image|video)\//.test(f.type) ? URL.createObjectURL(f) : '' }); }; r.onerror = () => resolve(null); r.readAsDataURL(f); };
      inp.click();
    });
  }
  function msgNode(m, prev) {
    const frag = document.createDocumentFragment();
    if (!prev || day(prev.ts) !== day(m.ts)) { const d = document.createElement('div'); d.className = 'cday'; d.textContent = new Date(m.ts || Date.now()).toLocaleDateString('zh-TW', { month: 'long', day: 'numeric', weekday: 'short' }); frag.appendChild(d); }
    const el = document.createElement('div'); fillMsg(el, m); frag.appendChild(el); m._el = el; return frag;
  }
  function fillMsg(el, m) {
    el.className = `cmsg ${m.role === 'assistant' ? 'ai' : 'me'}${m.wait ? ' wait' : ''}`;
    const tag = m.platform && PLAT[m.platform] ? `<i class="cplat">${PLAT[m.platform]}</i>` : '';
    const imgs = [...(m.img ? [m.img] : []), ...(m.imgs || []).map(media), ...(m.images || []).map((im) => `data:${im.mime};base64,${im.data}`)];
    const files = (m.files || []).map(fileCard).join('');
    const text = m.wait ? `<span class="dots"><i></i><i></i><i></i></span>${m.doing ? `<span class="cdoing">${esc(m.doing)}</span>` : ''}${m.bstep ? `<img class="cbshot" src="${LA.rw('/api/browser/step/' + m.bstep)}?t=${encodeURIComponent(LA.token)}" alt="">` : ''}` : (m.text && !(imgs.length && /^\[圖片\]$/.test(m.text)) ? LA.richText(m.text) : '');
    const qt = m.quote && m.quote.text ? `<div class="cquote"><b>${esc(m.quote.name || '')}</b>${esc(String(m.quote.text).slice(0, 120))}</div>` : '';
    el._m = m;   // 長按選單用
    el.innerHTML = `<div class="cb">${qt}${imgs.map((u) => `<img src="${u}" alt="" loading="lazy" data-zoom="1">`).join('')}${text}${files}</div><div class="cmeta">${tag}${fmt(m.ts)}</div>`;
    for (const img of el.querySelectorAll('img')) img.addEventListener('load', () => { if (nearBottom()) toBottom(); }, { once: true });   // 圖片載入後高度改變：仍在底部就跟著到底
  }
  /** 往上捲到頂：載入更早的訊息（保持目前看的位置不跳） */
  async function loadOlder() {
    if (loadingOld || !more || !msgs.length) return; loadingOld = true; const l = list();
    try {
      const r = await LA.api(`/api/chat/history?limit=40&before=${msgs[0].ts}`); const old = r.items || []; more = !!r.more; if (!old.length) return;
      const h0 = l.scrollHeight; const top0 = l.scrollTop; const frag = document.createDocumentFragment(); old.forEach((m, i) => frag.appendChild(msgNode(m, old[i - 1])));
      const firstDay = l.querySelector('.cday'); if (firstDay && old.length && day(old[old.length - 1].ts) === day(msgs[0].ts)) firstDay.remove();
      l.insertBefore(frag, l.firstChild); msgs = [...old, ...msgs]; l.scrollTop = top0 + (l.scrollHeight - h0);
    } finally { loadingOld = false; }
  }
  function renderList() {
    const l = list(); if (!l) return;
    if (!msgs.length) { l.innerHTML = `<div class="cempty"><div class="cav big">${initial()}</div><b>${esc((persona && persona.name) || '你的 AI 助理')}</b><p>想做什麼直接說，像傳訊息一樣。<br>也可以按 ＋ 拍發票、掃 QR 或叫出服務。</p></div>`; return; }
    l.innerHTML = ''; msgs.forEach((m, i) => l.appendChild(msgNode(m, msgs[i - 1]))); toBottom();
  }
  function push(m) {
    const l = list(); const stick = nearBottom();
    if (!msgs.length && l) l.innerHTML = '';
    msgs.push(m); if (l) l.appendChild(msgNode(m, msgs[msgs.length - 2])); if (stick) toBottom();
  }
  function header() {
    const st = LA.status; const cli = LA.link.mode === 'client'; const m = cli ? null : st && st.model;
    const h = $('#c-head', root); if (h) h.innerHTML = `<div class="cav">${initial()}</div><div class="grow"><b>${esc((persona && persona.name) || 'AI 助理')}</b><small>${cli ? `<span class="dot ok"></span>聯機：${esc((LA.link.client && LA.link.client.host_name) || '主機')}` : m && !m.has_key ? '<span class="err">還沒設定模型</span>' : `<span class="dot ${st && st.supervisor.running ? 'ok' : ''}"></span>${esc(m ? (m.label || m.provider) : '')}`}</small></div><button class="ico" id="c-voice" title="語音模式（用講的跟 AI 聊天）">${LA.icon('wave')}</button><button class="ico" id="c-search" title="搜尋對話">${LA.icon('search')}</button>${cli ? '' : `<button class="ico" data-go="persona" title="人設">${LA.icon('mask')}</button>`}`;
    const w = $('#c-warn', root); if (w) { w.hidden = !(m && !m.has_key); }
  }
  function preview() {
    const p = $('#c-prev', root); if (!p) return; p.hidden = !pendingImg && !replyTo && !pendingFile;
    p.innerHTML = (replyTo ? `<div class="creply grow"><b>回覆 ${replyTo.role === 'assistant' ? 'AI' : '自己'}</b><span>${esc(String(replyTo.text).slice(0, 80))}</span></div><button class="ico" id="c-noreply" title="取消回覆">${LA.icon('x')}</button>` : '')
      + (pendingImg ? `<img src="${pendingImg.preview}" alt=""><span class="grow small mute">照片已附上，打字說要做什麼（不打字＝當收據記帳）</span><button class="btn sm" id="c-noimg">移除</button>` : '')
      + (pendingFile ? `${pendingFile.local && /^image/.test(pendingFile.mime) ? `<img src="${pendingFile.local}" alt="">` : `<span class="cfchip">${LA.icon(/^video/.test(pendingFile.mime) ? 'play' : 'doc')}</span>`}<span class="grow small"><b>${esc(pendingFile.name)}</b><span class="mute">・${sizeOf(pendingFile.size)}・可以再打字說要做什麼</span></span><button class="btn sm" id="c-nofile">移除</button>` : '');
  }
  /** 26.11.3 Revise4：長按訊息（電腦：右鍵）→ 像 LINE 的選單：回覆、複製、開啟連結、分享 */
  function msgMenu(el, x, y) {
    const m = el._m; if (!m || m.wait) return; closeMenu(); const links = [...new Set(String(m.text || '').match(LA.URL_RE) || [])].slice(0, 3);
    const items = [['reply', 'reply', '回覆'], ['copy', 'copy', '複製'], ...links.map((u, i) => ['link' + i, 'link', links.length > 1 ? '開啟連結 ' + (i + 1) : '開啟連結']), ['share', 'share', '分享'], ...(m.role !== 'assistant' && m.text ? [['again', 'refresh', '再問一次']] : [])];
    const menu = document.createElement('div'); menu.className = 'cmenu-pop'; menu.innerHTML = items.map(([k, ic, n]) => `<button data-k="${k}">${LA.icon(ic)}<span>${n}</span></button>`).join('');
    document.body.appendChild(menu); el.classList.add('picked'); if (navigator.vibrate) { try { navigator.vibrate(12); } catch { /* ignore */ } }
    const r = menu.getBoundingClientRect(); const vw = window.innerWidth; const vh = window.innerHeight;
    menu.style.left = Math.max(8, Math.min(vw - r.width - 8, x - r.width / 2)) + 'px'; menu.style.top = (y - r.height - 14 > 60 ? y - r.height - 14 : Math.min(vh - r.height - 8, y + 18)) + 'px';
    menu.onclick = async (e) => {
      const b = e.target.closest('[data-k]'); if (!b) return; const k = b.dataset.k; closeMenu();
      if (k === 'reply') { replyTo = { text: m.text || (m.imgs && m.imgs.length ? '[圖片]' : ''), role: m.role, ts: m.ts }; preview(); $('#c-in', root).focus(); }
      else if (k === 'copy') LA.copy(m.text || '');
      else if (k.startsWith('link')) { const a = document.createElement('a'); a.href = links[+k.slice(4)]; a.target = '_blank'; a.rel = 'noopener'; document.body.appendChild(a); a.click(); a.remove(); }
      else if (k === 'share') { if (window.AndroidBridge && AndroidBridge.shareText) AndroidBridge.shareText(m.text || ''); else if (navigator.share) navigator.share({ text: m.text || '' }).catch(() => {}); else LA.copy(m.text || ''); }
      else if (k === 'again') send({ text: m.text }, m.text);
    };
    setTimeout(() => document.addEventListener('pointerdown', outside, true), 0);
  }
  function outside(e) { if (!e.target.closest('.cmenu-pop')) closeMenu(); }
  function closeMenu() { document.removeEventListener('pointerdown', outside, true); document.querySelectorAll('.cmenu-pop').forEach((x) => x.remove()); document.querySelectorAll('.cmsg.picked').forEach((x) => x.classList.remove('picked')); }
  function bindLongPress(list) {
    let t = null; let sx = 0; let sy = 0;
    list.addEventListener('pointerdown', (e) => { const el = e.target.closest('.cmsg'); if (!el || e.target.closest('a,button,img')) return; sx = e.clientX; sy = e.clientY; clearTimeout(t); t = setTimeout(() => { t = null; list._lp = Date.now(); msgMenu(el, sx, sy); }, 480); });
    const cancel = (e) => { if (t && (!e || e.type !== 'pointermove' || Math.hypot(e.clientX - sx, e.clientY - sy) > 10)) { clearTimeout(t); t = null; } };
    list.addEventListener('pointermove', cancel); list.addEventListener('pointerup', () => cancel()); list.addEventListener('pointercancel', () => cancel()); list.addEventListener('scroll', () => { cancel(); closeMenu(); }, { passive: true });
    list.addEventListener('contextmenu', (e) => { const el = e.target.closest('.cmsg'); if (!el) return; e.preventDefault(); if (!list._lp || Date.now() - list._lp > 800) msgMenu(el, e.clientX, e.clientY); });
  }
  /** 服務選單（像 LINE 的圖文選單）：放在輸入框下方，可收合 */
  function menu() { return `<div class="cmenu-grid">${tiles.map((t) => `<button data-tile="${esc(t.id)}">${LA.icon(LA.tileIcon(t.icon))}<span>${esc(t.name)}</span></button>`).join('')}${LA.link.mode === 'client' ? '' : `<button data-go="services">${LA.icon('edit')}<span>編輯選單</span></button>`}</div>`; }
  function shell(main) {
    main.innerHTML = `<div class="chat"><div class="chead" id="c-head"></div><div class="tp" id="c-tasks" hidden></div>
      <div class="cwarn" id="c-warn" hidden>還沒設定 AI 模型，AI 暫時不會回話。<button class="btn sm pri" data-go="models">去設定</button></div>
      <div class="clist" id="c-list"></div><div class="cprev" id="c-prev" hidden></div>
      <div class="ccomp"><button class="ico cplus" id="c-menu" title="服務選單">${LA.icon('grid')}</button><button class="ico cplus" id="c-plus" title="拍照／掃 QR">${LA.icon('plus')}</button><textarea id="c-in" rows="1" placeholder="跟 ${esc((persona && persona.name) || 'AI')} 說…" enterkeyhint="send"></textarea><button class="ico cplus cmic" id="c-mic" title="用說的輸入">${LA.icon('mic')}</button><button class="csend" id="c-send" title="送出">${LA.icon('send')}</button></div>
      <div class="cmenu" id="c-menuwrap" ${menuOpen() ? '' : 'hidden'}>${menu()}</div></div>`;
    root = main; header(); renderList();
    if (LA.taskPanel && LA.link.mode !== 'client') LA.taskPanel.mount($('#c-tasks', root));   // 26.11.3 pro8 排程／長期任務下拉面板
    const i = $('#c-in', root); i.oninput = () => { i.style.height = 'auto'; i.style.height = Math.min(i.scrollHeight, 140) + 'px'; };
    i.onfocus = () => { const w = $('#c-menuwrap', root); if (w && !w.hidden) { w.hidden = true; w.dataset.auto = '1'; } };   // 打字時收起選單，像 LINE 一樣
    $('#c-list', root).onscroll = (e) => { if (e.target.scrollTop < 80) loadOlder(); };
    bindLongPress($('#c-list', root));
    if (LA.voice) LA.voice.bindMic($('#c-mic', root), i);
  }
  async function send(payload, label, img, ufile) {
    if (busy) return ''; busy = true; const sb = root && $('#c-send', root); if (sb) sb.disabled = true;
    const quote = replyTo && !payload.id ? { text: replyTo.text, role: replyTo.role, ts: replyTo.ts } : null; if (quote) { payload = { ...payload, quote }; replyTo = null; preview(); }
    const um = { role: 'user', text: label, img, ts: Date.now(), ...(ufile ? { files: [{ name: ufile.name, size: ufile.size, mime: ufile.mime, local: ufile.local }] } : {}), ...(quote ? { quote: { text: quote.text, name: quote.role === 'assistant' ? 'AI' : '我' } } : {}) }; push(um); const w = { role: 'assistant', wait: true, ts: Date.now() }; push(w);
    // 等待時每秒問一次「AI 正在做什麼」，顯示在等待泡泡裡（思考中／正在搜尋／正在網頁上操作…）
    const pt = setInterval(async () => { try { const p = await LA.api('/api/chat/progress'); if (!w.wait || p.idle) return; const label = `${p.doing}${p.round > 1 ? `・第 ${p.round} 步` : ''}${p.sec >= 8 ? `・${p.sec} 秒` : ''}`; if ((label !== w.doing || (p.browser_step && p.browser_step !== w.bstep)) && w._el) { w.doing = label; if (p.browser_step && LA.link.mode !== 'client') w.bstep = p.browser_step; fillMsg(w._el, w); } } catch { /* ignore */ } }, 1000);
    try {
      const r = payload.id ? await LA.post('/api/services/run', payload) : await LA.post('/api/chat', payload);
      Object.assign(w, { wait: false, text: r.text || '（完成）', images: r.images || [], files: r.files || [], ts: Date.now() });
      if (ufile && r.user_files && r.user_files.length && um._el) { um.files = r.user_files.map((f) => ({ ...f, local: ufile.local })); fillMsg(um._el, um); }
      else if (ufile && um._el && /^image/.test(ufile.mime)) { um.files = []; um.img = ufile.local; fillMsg(um._el, um); }
      if (r.kind === 'einvoice') LA.toast(r.duplicate ? '這張發票之前記過了' : '已記帳');
    } catch (e) { Object.assign(w, { wait: false, text: '發生問題：' + e.message }); }
    clearInterval(pt); busy = false; if (sb) sb.disabled = false; if (LA.taskPanel) LA.taskPanel.refresh().catch(() => {});   // AI 可能剛排了任務
    if (w._el && LA.cur === 'home') { const stick = nearBottom(); fillMsg(w._el, w); if (stick) toBottom(); }
    return w.text || '';
  }
  async function search() {
    const q = await LA.ask('搜尋對話紀錄', '', { hint: '輸入關鍵字（包含 LINE／Telegram／Discord 私訊）' }); if (!q || !q.trim()) return;
    const r = await LA.api('/api/chat/search?q=' + encodeURIComponent(q.trim()));
    LA.modal(`<h3 style="margin-top:0">「${esc(q)}」${r.items.length} 則</h3><div class="list">${r.items.map((m) => `<div><div class="small mute">${new Date(m.ts).toLocaleString('zh-TW', { hour12: false })}・${m.role === 'assistant' ? 'AI' : '你'}${m.platform && PLAT[m.platform] ? '・' + PLAT[m.platform] : ''}</div><div style="white-space:pre-wrap">${esc(String(m.text).slice(0, 400))}</div></div>`).join('') || '<div class="mute">沒有找到</div>'}</div>`);
  }
  /** 給其他頁面用（例如服務頁按了按鈕）：切到對話頁並送出 */
  // 26.11.3 pro2：同一個函式名稱以前被定義兩次（語音模式拿到的是另一個版本，送出去是空的）→ 合併成一個：可以傳文字或 payload
  LA.chatSend = async (payload, label, img) => { if (typeof payload === 'string') { label = label || payload; payload = { text: payload }; } if (LA.cur !== 'home') await LA.go('home'); return send(payload, label, img); };

  function sheet() {
    const s = LA.modal(`<div class="sgrab"></div><div class="sheetgrid">
      <button data-a="cam">${LA.icon('camera', 'lg')}拍照／選圖</button><button data-a="qr">${LA.icon('qr', 'lg')}掃發票 QR</button><button data-a="send">${LA.icon('clip', 'lg')}傳送檔案</button><button data-a="file">${LA.icon('doc', 'lg')}幫我做檔案</button><button data-a="brief">${LA.icon('sun', 'lg')}今天有什麼事</button></div>
      <div class="hint" style="text-align:center;margin-top:8px">拍發票、收據、帳單，不用打字就會自動記帳</div>`);
    s.onclick = LA.guard(async (e) => {
      const b = e.target.closest('[data-a]'); if (!b) return; LA.closeModal(); const a = b.dataset.a;
      if (a === 'cam') { pendingImg = await LA.pickPhoto(); preview(); $('#c-in', root).focus(); }
      if (a === 'send') { const f = await pickFile(); if (f) { pendingFile = f; pendingImg = null; preview(); $('#c-in', root).focus(); } }
      if (a === 'qr') { const q = await LA.scanQr(); await send({ id: 'scan_invoice', qr: [q] }, '掃了一張 QR Code'); }
      if (a === 'file') { const v = await LA.ask('要做什麼檔案？', '', { hint: '例：把這個月的支出整理成 Excel／幫我寫一份旅遊行程 Word／會議記錄 PDF' }); if (v && v.trim()) await send({ text: v.trim() + '（請做成檔案給我）' }, v.trim()); }
      if (a === 'brief') await send({ text: '今天有什麼事？講重點就好。' }, '今天有什麼事？');
    });
  }

  LA.register('home', { name: '對話', title: '對話（和 AI 說話；第一頁）', async render(main) {
    document.body.classList.add('chatmode');
    const [h, pz, sv] = await Promise.all([LA.api('/api/chat/history?limit=60').catch(() => ({ items: [] })), LA.api('/api/persona').catch(() => null), LA.api('/api/services').catch(() => ({ items: [] })), LA.status ? null : LA.refreshStatus().catch(() => null)]);
    if (!busy) { msgs = h.items || []; more = !!h.more; } persona = pz && pz.persona && pz.persona.enabled ? pz.persona : null; tiles = sv.items || []; shell(main);
    const go = () => {
      const i = $('#c-in', root); const v = i.value.trim(); const img = pendingImg; const pf = pendingFile; if (!v && !img && !pf) return; i.value = ''; i.style.height = ''; pendingImg = null; pendingFile = null; preview();
      if (pf) return send({ text: v, file: { name: pf.name, mime: pf.mime, data: pf.data } }, v, null, pf);
      if (img) return send(v ? { text: v, image: { mime: img.mime, data: img.data } } : { id: 'photo_receipt', image: { mime: img.mime, data: img.data } }, v || '（照片：幫我記帳）', img.preview);
      return send({ text: v }, v);
    };
    main.onclick = LA.guard(async (e) => {
      const t = e.target; const g = t.closest('[data-go]'); if (g) return LA.go(g.dataset.go);
      if (t.closest('#c-send')) return go();
      if (t.closest('#c-plus')) return sheet();
      if (t.closest('#c-menu')) { const w = $('#c-menuwrap', root); w.hidden = !w.hidden; try { localStorage.setItem('la_chat_menu', w.hidden ? '0' : '1'); } catch { /* ignore */ } if (!w.hidden) { $('#c-in', root).blur(); } return; }
      if (t.closest('#c-search')) return search();
      if (t.closest('#c-voice')) return LA.voice.openMode((x) => LA.chatSend(x));
      const fb = t.closest('[data-file]'); if (fb) { if (!await LA.confirm(`要下載「${fb.dataset.name}」${fb.dataset.size ? `（${fb.dataset.size}）` : ''}嗎？`)) return; await LA.download(`/api/files/out/${encodeURIComponent(fb.dataset.file)}`, fb.dataset.name); return LA.toast('已下載：' + fb.dataset.name); }
      const zi = t.closest('[data-zoom]'); if (zi) { LA.modal(`<img src="${zi.src}" style="width:100%;border-radius:12px" alt="">`); return; }
      if (t.closest('#c-noimg')) { pendingImg = null; return preview(); }
      if (t.closest('#c-nofile')) { pendingFile = null; return preview(); }
      const pl = t.closest('[data-play]'); if (pl) return player(pl.dataset.play, pl.dataset.name, pl.dataset.kind);
      if (t.closest('#c-noreply')) { replyTo = null; return preview(); }
      const tile = t.closest('[data-tile]'); if (tile) return LA.runTile(tiles.find((x) => x.id === tile.dataset.tile));
    });
    main.onkeydown = (e) => { if (e.target.id === 'c-in' && e.key === 'Enter' && !e.shiftKey && !e.isComposing) { e.preventDefault(); go(); } };
    // 其他平台（LINE 等）有新訊息：只附加新的，不重畫
    LA.every(15000, async () => {
      if (busy || LA.cur !== 'home') return; header(); const r = await LA.api('/api/chat/history?limit=60'); const items = r.items || [];
      const lastTs = msgs.length ? msgs[msgs.length - 1].ts : 0; const fresh = items.filter((m) => m.ts > lastTs);
      const known = new Set(msgs.map((m) => `${m.role}|${m.text}`)); for (const m of fresh) if (!known.has(`${m.role}|${m.text}`)) push(m);
    });
  }, leave() { document.body.classList.remove('chatmode'); root = null; } });
})();
