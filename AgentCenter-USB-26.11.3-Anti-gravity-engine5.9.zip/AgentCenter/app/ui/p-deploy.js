'use strict';
/* 26.11.3 Revise4 開發者 → 伺服器：用一串指令把 AI 後台（程式＋資料庫）部署到別台主機（Linux 伺服器／VPS／Termux） */
(function () {
  const { esc } = LA; const $ = (s, r = document) => r.querySelector(s);
  LA.renderDeploy = async (main) => {
    main.innerHTML = `<div class="card"><h3 style="margin-top:0">${LA.icon('server')} 部署到伺服器</h3>
        <div class="small mute">把這台的 AI（程式＋資料庫）搬到一台 24 小時開著的主機上：Linux 伺服器、VPS、樹莓派，或另一支手機的 Termux。之後手機只要「連到伺服器」就能用，關機也不影響 AI。</div>
        <label class="f">伺服器名稱</label><input id="dp-name" maxlength="24" placeholder="例：家裡的伺服器">
        <label class="f">伺服器的 /claim 密碼（必填，至少 6 個字）</label><input id="dp-claim" type="password" autocomplete="new-password" placeholder="連上伺服器後傳「/claim 這個密碼」就成為管理員">
        <label class="chk"><input type="checkbox" id="dp-data" checked> 把這台的資料一起帶過去（對話、記帳、記憶、用戶、設定）</label>
        <label class="f">資料保護密碼（選填）</label><input id="dp-pw" type="password" autocomplete="new-password" placeholder="填了才會把 API 金鑰、Bot token 加密帶過去">
        <details><summary class="small mute">進階：伺服器公開網址、連接埠</summary>
          <label class="f">伺服器公開網址</label><input id="dp-url" placeholder="https://ai.example.com（不填＝安裝時自動用伺服器的 IP）">
          <label class="f">對外連接埠</label><input id="dp-port" type="number" value="8787"></details>
        <div class="row" style="justify-content:flex-end;margin-top:12px"><button class="btn pri" id="dp-go">產生安裝指令</button></div></div><div id="dp-out"></div>
      <div class="card small mute"><b>裝好之後</b><br>1. 安裝最後會印出「連線連結」，在手機點開按同意（或到「開發者 → 聯機」貼上）就連到伺服器。<br>2. 在對話裡傳「/claim 你設定的密碼」成為伺服器的管理員，就能看到並操作伺服器的監控與設定。<br>3. 其他人連進來是一般用戶，能用什麼、看不看得到操作端，由你在「用戶」頁決定（權限「console_view」＝可以看監控）。</div>`;
    $('#dp-go', main).onclick = LA.guard(async (e) => {
      const b = e.currentTarget; b.disabled = true; b.textContent = '打包中…';
      try {
        const r = await LA.post('/api/deploy/prepare', { name: $('#dp-name', main).value.trim(), claim_password: $('#dp-claim', main).value, include_data: $('#dp-data', main).checked, password: $('#dp-pw', main).value, public_url: $('#dp-url', main).value.trim(), port: +$('#dp-port', main).value || 8787 });
        const cmd = (label, c) => (c ? `<label class="f">${label}</label><div class="dp-cmd mono">${esc(c)}</div><button class="btn sm" data-copy="${esc(c)}">複製</button>` : '');
        $('#dp-out', main).innerHTML = `<div class="card"><h3 style="margin-top:0">安裝指令</h3><div class="small mute">程式 ${r.files} 個檔案（${esc(r.bundle_size)}）${r.data ? `＋資料 ${esc(r.data.size)}${r.data.secrets ? '（含加密金鑰）' : '（不含金鑰）'}` : '（不帶資料）'}。指令 60 分鐘內有效。</div>
          ${r.command ? cmd('Linux 伺服器／VPS（在伺服器的終端機貼上執行）', r.command) + cmd('Termux（另一支手機）', r.termux) + cmd('有設資料保護密碼時', r.with_password) : `<div class="err small" style="margin-top:8px">${esc(r.note)}</div>`}
          <label class="f">或下載安裝檔（不需要這台手機在線上）</label><button class="btn" id="dp-dl">下載 agent-center-install.sh</button><div class="hint">傳到伺服器後執行：bash agent-center-install.sh</div></div>`;
        $('#dp-dl', main).onclick = LA.guard(async () => { await LA.download(r.standalone, 'agent-center-install.sh'); LA.toast('已下載'); });
      } finally { b.disabled = false; b.textContent = '產生安裝指令'; }
    });
    main.addEventListener('click', (e) => { const c = e.target.closest('[data-copy]'); if (c && !c.closest('#modal')) LA.copy(c.dataset.copy); });
  };
})();
