'use strict';
/* 自動化頁：每日簡報、監控哨兵、語音轉文字、手機能力。這些也都能直接用講的叫 AI 設定。 */
(function () {
  const { esc, $ } = LA;
  const COND = [['changed', '內容有變動'], ['contains', '出現關鍵字'], ['missing', '關鍵字消失'], ['lt', '數字低於'], ['gt', '數字高於']];
  const EXT = [['text', '整頁文字'], ['regex', '正規表達式取值'], ['json', 'JSON 路徑取值']];
  const SPEECH = { groq: 'Groq Whisper', openai: 'OpenAI Whisper', gemini: 'Gemini' };
  const ago = (t) => (t ? LA.fmtTime(t) : '尚未檢查');

  function wrow(w) {
    const st = w.last_ok === false ? `<span class="err">❌ ${esc(w.last_error)}</span>` : w.last_value ? `→ <span class="mono">${esc(w.last_value.slice(0, 90))}</span>` : '';
    return `<div class="krow"><div class="grow"><b>${w.enabled ? '' : '⏸ '}${esc(w.name)}</b> <span class="tag">${esc((COND.find((c) => c[0] === w.cond) || [])[1] || w.cond)}${w.value !== '' ? ' ' + esc(w.value) : ''}</span>
      <div class="small mute">每 ${w.every_min} 分 · ${ago(w.last_at)} ${st}${w.fired ? ` · 已通知 ${w.fired} 次` : ''}</div><div class="small mute mono">${esc(w.url)}</div></div>
      <div class="kbtn"><button class="btn sm" data-wc="${w.id}">檢查</button><button class="btn sm" data-wt="${w.id}" data-on="${w.enabled ? 1 : 0}">${w.enabled ? '暫停' : '恢復'}</button><button class="btn sm bad" data-wd="${w.id}">刪除</button></div></div>`;
  }
  function paint(main, s) {
    const b = s.brief; const sp = s.speech;
    main.innerHTML = `<div class="card"><h3>☀️ 每日簡報 <small>${b.enabled ? '每天 ' + esc(b.at) + ' 送給管理員' : '未開啟'}</small></h3>
        <div class="hint">天氣＋今天行程＋未讀重要信＋今日提醒＋待審批＋哨兵觸發＋手機電量，整理成一則訊息。行程與信件要先在「瀏覽器」頁連上 Google。</div>
        <label class="chk"><input type="checkbox" id="b-on" ${b.enabled ? 'checked' : ''}> 每天自動送出</label>
        <div class="row"><div class="grow"><label class="f">時間</label><input id="b-at" type="time" value="${esc(b.at)}"></div><div class="grow"><label class="f">天氣城市</label><input id="b-city" value="${esc(b.city)}" placeholder="Taipei"></div></div>
        <div class="row" style="margin-top:10px"><button class="btn pri" id="b-save">儲存</button><button class="btn" id="b-prev">預覽</button><button class="btn" id="b-send">現在送出</button></div>
        <pre class="term" id="b-out" hidden style="white-space:pre-wrap;max-height:320px"></pre></div>
      <div class="card"><h3>🔔 監控哨兵 <small>${s.watches.length} 個</small></h3>
        <div class="hint">定時檢查網頁／API，條件成立就推播。也可以直接跟 AI 說：「幫我盯著這個網址，價格低於 3000 通知我」。</div>
        ${s.watches.map(wrow).join('') || '<div class="hint">還沒有哨兵。</div>'}
        <details style="margin-top:10px"><summary class="btn">＋ 新增哨兵</summary>
          <label class="f">名稱</label><input id="w-name" placeholder="例：顯示卡價格">
          <label class="f">網址</label><input id="w-url" placeholder="https://…" autocapitalize="off" spellcheck="false">
          <label class="f">取值方式</label><select id="w-ext">${EXT.map(([v, n]) => `<option value="${v}">${n}</option>`).join('')}</select>
          <div id="w-pat-box" hidden><label class="f">正規表達式（第一個括號就是取到的值）</label><input id="w-pat" class="mono" placeholder="售價\\s*\\$?([\\d,]+)" autocapitalize="off" spellcheck="false"></div>
          <div id="w-path-box" hidden><label class="f">JSON 路徑</label><input id="w-path" class="mono" placeholder="data.items[0].price" autocapitalize="off" spellcheck="false"></div>
          <label class="f">什麼時候通知</label><select id="w-cond">${COND.map(([v, n]) => `<option value="${v}">${n}</option>`).join('')}</select>
          <div id="w-val-box" hidden><label class="f">關鍵字／數字門檻</label><input id="w-val"></div>
          <div class="row"><div class="grow"><label class="f">每幾分鐘檢查</label><input id="w-every" type="number" value="30" min="5"></div><label class="chk" style="margin-top:22px"><input type="checkbox" id="w-once"> 觸發一次就停</label></div>
          <div class="row" style="margin-top:10px"><button class="btn pri" id="w-add">建立並試抓一次</button></div></details></div>
      <div class="card"><h3>🎤 語音訊息轉文字 <small>${sp.enabled === false ? '已關閉' : sp.routes.length ? '可用' : '<span class="err">沒有可用金鑰</span>'}</small></h3>
        <div class="hint">在 LINE／Telegram／Discord 傳語音給 AI，會先轉成文字再回答。使用順序：${sp.routes.length ? sp.routes.map((r) => SPEECH[r]).join(' → ') : '（模型頁加入 Groq、OpenAI 或 Gemini 金鑰即可，不用另外設定）'}</div>
        <label class="chk"><input type="checkbox" id="s-on" ${sp.enabled === false ? '' : 'checked'}> 啟用語音轉文字</label></div>
      <div class="card"><h3>📱 手機能力 <small><span class="dot ${s.phone.ready ? 'ok' : ''}"></span>${s.phone.ready ? 'Termux 已連線' : '未連線'}</small></h3>
        <div class="hint">讓 AI 讀電量／位置／剪貼簿／聯絡人／簡訊、跳通知、朗讀、手電筒、拍照；<b>發簡訊與打電話一律要你審批</b>。需要：「瀏覽器」頁完成 Termux 安裝＋安裝「Termux:API」App（F-Droid）並在系統設定給它權限。</div>
        <div class="row" style="margin-top:8px"><button class="btn" id="p-test" ${s.phone.ready ? '' : 'disabled'}>測試（讀電量與 Wi-Fi）</button><button class="btn" data-go="browser">Termux 設定</button></div><pre class="term" id="p-out" hidden style="white-space:pre-wrap"></pre></div>`;
    const sync = () => { const e = $('#w-ext').value, c = $('#w-cond').value; $('#w-pat-box').hidden = e !== 'regex'; $('#w-path-box').hidden = e !== 'json'; $('#w-val-box').hidden = c === 'changed'; };
    $('#w-ext').onchange = sync; $('#w-cond').onchange = sync; sync();
  }

  LA.register('auto', { name: '自動化', title: '自動化（每日簡報、監控哨兵、語音、手機）', async render(main) {
    const load = async () => { paint(main, await LA.api('/api/auto/state')); if (LA.iconize) LA.iconize(main); };
    await load();
    main.onclick = LA.guard(async (e) => {
      const t = e.target; const busy = async (btn, fn) => { btn.disabled = true; try { return await fn(); } finally { btn.disabled = false; } };
      const go = t.closest('[data-go]'); if (go) return LA.go(go.dataset.go);
      if (t.id === 'b-save') { await LA.post('/api/brief/config', { enabled: $('#b-on').checked, at: $('#b-at').value, city: $('#b-city').value }); LA.toast('已儲存'); return load(); }
      if (t.id === 'b-prev') return busy(t, async () => { const o = $('#b-out'); o.hidden = false; o.textContent = '產生中…'; const r = await LA.post('/api/brief/preview'); o.textContent = r.text; });
      if (t.id === 'b-send') return busy(t, async () => { const r = await LA.post('/api/brief/send'); LA.toast(r.sent ? `已送給 ${r.sent} 位管理員` : '沒有可以送的管理員（要先建立管理員並連上平台）', !r.sent); });
      if (t.id === 's-on') { await LA.post('/api/brief/config', { speech_enabled: t.checked }); LA.toast(t.checked ? '已啟用語音轉文字' : '已關閉語音轉文字'); return; }
      if (t.id === 'p-test') return busy(t, async () => { const o = $('#p-out'); o.hidden = false; o.textContent = '讀取中…'; const r = await LA.api('/api/phone/status'); o.textContent = JSON.stringify({ battery: r.battery, wifi: r.wifi }, null, 1); });
      if (t.id === 'w-add') return busy(t, async () => {
        const body = { name: $('#w-name').value.trim(), url: $('#w-url').value.trim(), extract: $('#w-ext').value, pattern: $('#w-pat').value, path: $('#w-path').value.trim(), cond: $('#w-cond').value, value: $('#w-val').value.trim(), every_min: +$('#w-every').value || 30, once: $('#w-once').checked };
        const r = await LA.post('/api/watch', body); const f = r.first || {};
        LA.toast(f.error ? `已建立，但第一次抓取失敗：${f.error}` : `已建立，目前值：${(f.value || '（空）').slice(0, 60)}`, !!f.error); return load();
      });
      const wc = t.closest('[data-wc]'); if (wc) return busy(wc, async () => { const r = await LA.post(`/api/watch/${wc.dataset.wc}/check`); LA.toast(r.error ? '❌ ' + r.error : `目前值：${(r.value || '（空）').slice(0, 80)}${r.fired ? '（條件成立）' : ''}`, !!r.error); await load(); });
      const wt = t.closest('[data-wt]'); if (wt) { await LA.post(`/api/watch/${wt.dataset.wt}`, { enabled: wt.dataset.on !== '1' }); return load(); }
      const wd = t.closest('[data-wd]'); if (wd) { if (!(await LA.confirm('刪除這個哨兵？'))) return; await LA.del(`/api/watch/${wd.dataset.wd}`); LA.toast('已刪除'); return load(); }
    });
  } });
})();
