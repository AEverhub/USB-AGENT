'use strict';
/*
 * 26.11.3 Revise5 語音：聊天麥克風（說話變文字）＋語音模式（用講話的方式跟 AI 聊天）＋語音包。
 *  ・語音轉文字：有雲端金鑰（Groq／OpenAI／Gemini）就錄成 16kHz WAV 上傳辨識；沒有就用手機內建辨識（Android SpeechRecognizer）。
 *  ・文字轉語音：語音包是 Gemini／OpenAI 就由後台產生聲音；「手機內建語音」用 Android TextToSpeech（電腦瀏覽器用 speechSynthesis）。
 *  ・自動偵測講完：開始說話後安靜約 1.3 秒就自動送出。
 */
(function () {
  const { esc } = LA; const $ = (s, r = document) => r.querySelector(s);
  const AB = () => window.AndroidBridge || null;
  const isAndroid = () => !!(AB() && typeof AB().ttsVoices === 'function');
  const V = LA.voice = { state: null, _h: {} };
  const on = (k, f) => { (V._h[k] = V._h[k] || []).push(f); return () => { V._h[k] = (V._h[k] || []).filter((x) => x !== f); }; };
  /** Android 原生回呼（MainActivity 用 evaluateJavascript 呼叫） */
  V._native = (kind, a, b) => { for (const f of (V._h[kind] || []).slice()) { try { f(a, b); } catch (e) { console.warn(e); } } };
  V.load = async () => { V.state = await LA.api('/api/voice/state'); return V.state; };
  const st = async () => V.state || V.load();
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

  // ---------------- 錄音（WAV）----------------
  function encodeWav(chunks, inRate, outRate = 16000) {
    let len = 0; for (const c of chunks) len += c.length; const all = new Float32Array(len); let o = 0; for (const c of chunks) { all.set(c, o); o += c.length; }
    const ratio = inRate / outRate; const n = Math.floor(all.length / ratio); const pcm = new Int16Array(n);
    for (let i = 0; i < n; i++) { const s0 = Math.floor(i * ratio), s1 = Math.min(all.length, Math.floor((i + 1) * ratio)); let sum = 0; for (let j = s0; j < s1; j++) sum += all[j]; const v = Math.max(-1, Math.min(1, sum / Math.max(1, s1 - s0))); pcm[i] = v < 0 ? v * 0x8000 : v * 0x7fff; }
    const buf = new ArrayBuffer(44 + pcm.length * 2); const dv = new DataView(buf); const w = (p, t) => { for (let i = 0; i < t.length; i++) dv.setUint8(p + i, t.charCodeAt(i)); };
    w(0, 'RIFF'); dv.setUint32(4, 36 + pcm.length * 2, true); w(8, 'WAVE'); w(12, 'fmt '); dv.setUint32(16, 16, true); dv.setUint16(20, 1, true); dv.setUint16(22, 1, true); dv.setUint32(24, outRate, true); dv.setUint32(28, outRate * 2, true); dv.setUint16(32, 2, true); dv.setUint16(34, 16, true); w(36, 'data'); dv.setUint32(40, pcm.length * 2, true);
    new Int16Array(buf, 44).set(pcm); return new Blob([buf], { type: 'audio/wav' });
  }
  V.encodeWav = encodeWav;
  function record({ vad = true, maxMs = 60000, silenceMs = 1300, waitMs = 9000, onLevel } = {}) {
    const ctl = { stop: () => {}, cancel: () => {} };
    ctl.done = (async () => {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) throw new Error('這裡不能錄音（瀏覽器不支援麥克風）');
      let stream; try { stream = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true, channelCount: 1 } }); }
      catch (e) { throw new Error(/NotAllowed|Permission/i.test(e.name + e.message) ? '沒有麥克風權限：請允許 App 使用麥克風（手機設定 → 應用程式 → Agent中控中心 → 權限）' : '打不開麥克風：' + e.message); }
      const AC = window.AudioContext || window.webkitAudioContext; const ac = new AC(); if (ac.state === 'suspended') await ac.resume().catch(() => {});
      const src = ac.createMediaStreamSource(stream); const proc = ac.createScriptProcessor(4096, 1, 1); const bufs = []; let started = false, lastVoice = 0, floor = 0.004, cancelled = false; const t0 = performance.now();
      return await new Promise((resolve) => {
        let done = false; const finish = (reason) => { if (done) return; done = true; try { proc.disconnect(); src.disconnect(); } catch { /* ignore */ } stream.getTracks().forEach((t) => t.stop()); const rate = ac.sampleRate; ac.close().catch(() => {});
          resolve({ blob: cancelled || (vad && !started) ? null : encodeWav(bufs, rate), reason, ms: performance.now() - t0 }); };
        ctl.stop = () => { started = true; finish('manual'); }; ctl.cancel = () => { cancelled = true; finish('cancel'); };
        proc.onaudioprocess = (e) => {
          const d = e.inputBuffer.getChannelData(0); bufs.push(new Float32Array(d)); let s = 0; for (let i = 0; i < d.length; i++) s += d[i] * d[i]; const rms = Math.sqrt(s / d.length); const now = performance.now();
          if (!started) { floor = floor * 0.9 + rms * 0.1; while (bufs.length > 6) bufs.shift(); }   // 開口前只留最後半秒
          const th = Math.max(0.012, floor * 2.6); if (rms > th) { if (now - t0 > 250) started = true; lastVoice = now; }
          if (onLevel) onLevel(Math.min(1, rms / 0.12), started);
          if (vad && started && now - lastVoice > silenceMs) finish('silence'); else if (vad && !started && now - t0 > waitMs) finish('nospeech'); else if (now - t0 > maxMs) finish('max');
        };
        src.connect(proc); proc.connect(ac.destination);
      });
    })();
    return ctl;
  }
  const b64 = (blob) => new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(String(r.result).split(',')[1] || ''); r.onerror = () => rej(r.error); r.readAsDataURL(blob); });

  // ---------------- 語音轉文字 ----------------
  V.sttMode = () => {
    const s = V.state; const pref = (s && s.settings.stt) || 'auto'; const cloud = !!(s && s.stt.enabled && s.stt.cloud.length); const canRec = !!(navigator.mediaDevices && navigator.mediaDevices.getUserMedia);
    let nat = false; try { nat = !!(AB() && AB().sttAvailable && AB().sttAvailable()); } catch { /* ignore */ }
    if (pref === 'device' && nat) return 'device'; if (cloud && canRec && pref !== 'device') return 'cloud'; if (nat) return 'device'; if (canRec && cloud) return 'cloud'; return '';
  };
  /** 聽一段話 → 文字。回傳 { stop(), cancel(), done: Promise<string> }。onPartial：手機內建辨識的即時字幕 */
  V.listen = function (o = {}) {
    const mode = V.sttMode(); const ctl = { mode, stop: () => {}, cancel: () => {} };
    if (!mode) { ctl.done = Promise.reject(new Error('沒有可用的語音辨識：模型頁加入 Groq／OpenAI／Gemini 任一家的金鑰，或在手機安裝「Google」App 的語音辨識')); return ctl; }
    if (mode === 'cloud') {
      const r = record(o); ctl.stop = r.stop; ctl.cancel = r.cancel;
      ctl.done = r.done.then(async (x) => { if (!x.blob) return ''; if (o.onStage) o.onStage('transcribing'); const res = await LA.post('/api/voice/transcribe', { mime: 'audio/wav', data: await b64(x.blob) }); if (!res.ok) throw new Error(res.error || '辨識失敗'); return res.text || ''; });
      return ctl;
    }
    // 手機內建辨識
    let offs = []; const clean = () => { offs.forEach((f) => f()); offs = []; };
    ctl.done = new Promise((resolve, reject) => {
      let last = ''; let settled = false; const ok = (t) => { if (settled) return; settled = true; clean(); resolve(t); }; const bad = (e) => { if (settled) return; settled = true; clean(); reject(e); };
      offs.push(on('stt', (k, v) => {
        if (k === 'partial') { last = v || last; if (o.onPartial) o.onPartial(last); }
        else if (k === 'level') { if (o.onLevel) o.onLevel(+v || 0, true); }
        else if (k === 'final') ok(v || last);
        else if (k === 'error') { const code = String(v); if (code === '7' || code === '6') ok(last); else if (code === 'perm' || code === '9') bad(new Error('沒有麥克風權限：請允許 App 使用麥克風')); else if (code === '5' && last) ok(last); else bad(new Error('手機語音辨識失敗（代碼 ' + code + '）')); }
      }));
      ctl.stop = () => { try { AB().sttStop(); } catch { /* ignore */ } setTimeout(() => ok(last), 2500); };
      ctl.cancel = () => { try { AB().sttCancel(); } catch { /* ignore */ } ok(''); };
      try { AB().sttStart('zh-TW'); } catch (e) { bad(e); }
    });
    return ctl;
  };

  // ---------------- 文字轉語音 ----------------
  let deviceVoices = null;
  V.deviceVoices = async () => {
    if (isAndroid()) { for (let i = 0; i < 20; i++) { try { const r = JSON.parse(AB().ttsVoices()); if (r.state === 2) return (deviceVoices = r.voices || []); if (r.state === -1) return []; } catch { return []; } await sleep(300); } return []; }
    if (window.speechSynthesis) { let v = speechSynthesis.getVoices(); if (!v.length) { await sleep(400); v = speechSynthesis.getVoices(); } return v.filter((x) => /^(zh|en|ja)/i.test(x.lang)).map((x) => ({ name: x.name, locale: x.lang, network: !x.localService })); }
    return [];
  };
  let curStop = null;
  V.stopSpeaking = () => { if (curStop) { const f = curStop; curStop = null; f(); } };
  /** 念出一段文字。回傳 Promise（念完／被停止時 resolve）。opts.pack：指定語音包 id（試聽用） */
  let speakGen = 0;
  V.speak = async function (text, opts = {}) {
    // engine4.6：兩次 speak 幾乎同時發生時（例如自動朗讀＋手動按），舊的那次在等網路時還沒登記「停止」，會跟新的一起念 → 同一句聽到兩次。用世代編號讓舊的自己放棄
    const gen = ++speakGen; V.stopSpeaking(); const s = await st(); if (gen !== speakGen) return; const pack = opts.pack ? s.packs.find((p) => p.id === opts.pack) : s.current; if (!pack) throw new Error('沒有可用的語音包');
    const prep = await LA.post('/api/voice/speakable', { text }); const parts = prep.chunks || []; if (!parts.length || gen !== speakGen) return;
    let stopped = false; const rate = +s.settings.rate || 1, pitch = +s.settings.pitch || 1;
    if (pack.provider === 'device') return speakDevice(parts, s.settings, () => stopped, (f) => { curStop = () => { stopped = true; f(); }; }, opts);
    // 雲端：第一段一拿到就播，同時先抓下一段
    const fetchPart = (t) => LA.post('/api/voice/tts', { text: t, pack: pack.id, raw: true });
    let next = fetchPart(parts[0]); let audio = null; curStop = () => { stopped = true; if (audio) { audio.pause(); audio.src = ''; } };
    for (let i = 0; i < parts.length && !stopped; i++) {
      if (gen !== speakGen) { stopped = true; break; }
      let r; try { r = await next; } catch (e) { if (i === 0 && !opts.noFallback) { LA.toast('雲端語音失敗，改用手機內建語音：' + e.message, true); return speakDevice(parts, s.settings, () => stopped, (f) => { curStop = () => { stopped = true; f(); }; }, opts); } throw e; }
      if (i + 1 < parts.length) next = fetchPart(parts[i + 1]); if (stopped || gen !== speakGen) break;
      if (r.device) { await speakDevice([r.text], s.settings, () => stopped, (f) => { curStop = () => { stopped = true; f(); }; }, opts); continue; }
      if (i === 0 && opts.onStart) opts.onStart();
      await new Promise((res) => { audio = new Audio(`data:${r.mime};base64,${r.data}`); audio.playbackRate = rate; audio.preservesPitch = true; audio.onended = res; audio.onerror = res; audio.play().catch((e) => { LA.toast('播放失敗：' + e.message, true); res(); }); });
    }
    void pitch; if (gen === speakGen) curStop = null;
  };
  async function speakDevice(parts, cfg, isStopped, setStop, opts) {
    const rate = +cfg.rate || 1, pitch = +cfg.pitch || 1;
    if (isAndroid()) {
      await V.deviceVoices(); const ids = parts.map((_, i) => 'u' + Date.now().toString(36) + i); const lastId = ids[ids.length - 1];
      await new Promise((resolve) => {
        const off = on('tts', (id, ev) => { if (id === ids[0] && ev === 'start' && opts.onStart) opts.onStart(); if ((id === lastId && (ev === 'done' || ev === 'error')) || ev === 'stop') { off(); resolve(); } });
        setStop(() => { try { AB().ttsStop(); } catch { /* ignore */ } off(); resolve(); });
        let okAny = false; parts.forEach((t, i) => { if (AB().ttsSpeak(ids[i], t, cfg.device_voice || '', rate, pitch, i === 0)) okAny = true; });
        if (!okAny) { off(); LA.toast('手機的文字轉語音還沒準備好（設定 → 系統 → 語言 → 文字轉語音輸出 可安裝中文語音）', true); resolve(); }
      });
      return;
    }
    if (!window.speechSynthesis) { LA.toast('這個瀏覽器不支援語音播放', true); return; }
    const vs = speechSynthesis.getVoices(); const voice = vs.find((v) => v.name === cfg.device_voice) || vs.find((v) => /zh[-_]TW/i.test(v.lang)) || vs.find((v) => /^zh/i.test(v.lang));
    await new Promise((resolve) => {
      setStop(() => { speechSynthesis.cancel(); resolve(); }); let i = 0;
      const nextU = () => { if (isStopped() || i >= parts.length) return resolve(); const u = new SpeechSynthesisUtterance(parts[i++]); u.lang = (voice && voice.lang) || 'zh-TW'; if (voice) u.voice = voice; u.rate = rate; u.pitch = pitch; u.onstart = () => { if (i === 1 && opts.onStart) opts.onStart(); }; u.onend = nextU; u.onerror = nextU; speechSynthesis.speak(u); };
      nextU();
    });
  }

  // ---------------- 聊天輸入框的麥克風 ----------------
  /** 把麥克風按鈕綁到輸入框：按一下開始、講完自動停（或再按一下停），文字放進輸入框，不會自動送出 */
  V.bindMic = function (btn, input) {
    let ctl = null;
    btn.onclick = LA.guard(async () => {
      if (ctl) { ctl.stop(); return; }
      await st().catch(() => null); const base = input.value; const ph = input.placeholder; btn.classList.add('rec'); input.placeholder = '聆聽中…'; V.stopSpeaking();
      ctl = V.listen({ silenceMs: 1600, waitMs: 10000, onLevel: (lv) => btn.style.setProperty('--lv', lv.toFixed(2)), onPartial: (t) => { input.value = (base ? base + ' ' : '') + t; }, onStage: () => { input.placeholder = '辨識中…'; } });
      try { const t = (await ctl.done).trim(); if (t) { input.value = (base ? base.replace(/\s+$/, '') + ' ' : '') + t; input.dispatchEvent(new Event('input')); input.focus(); } else if (ctl.mode === 'cloud') LA.toast('沒有聽到聲音'); }
      finally { ctl = null; btn.classList.remove('rec'); btn.style.removeProperty('--lv'); input.placeholder = ph; }
    });
  };

  // ---------------- 語音模式 ----------------
  /** send(text) → Promise<回覆文字>，由對話頁提供 */
  V.openMode = async function (send) {
    const s = await V.load(); let state = 'idle', ctl = null, alive = true, miss = 0;
    const el = document.createElement('div'); el.className = 'vm'; document.body.appendChild(el); document.body.classList.add('vm-open');
    el.innerHTML = `<div class="vm-top"><button class="btn sm" id="vm-pack">${LA.icon('speaker', 'sm')} <span id="vm-pname"></span></button><span class="grow"></span><button class="ico" id="vm-x" title="結束語音模式">${LA.icon('x')}</button></div>
      <div class="vm-mid"><button class="vm-orb" id="vm-orb" aria-label="說話"><i></i><i></i><i></i>${LA.icon('mic')}</button><div class="vm-state" id="vm-state"></div><div class="vm-you" id="vm-you"></div><div class="vm-ai" id="vm-ai"></div></div>
      <div class="vm-bot"><button class="btn sm" id="vm-auto"></button><button class="btn sm" id="vm-stop">${LA.icon('stop', 'sm')} 停止</button></div>`;
    const orb = $('#vm-orb', el), stEl = $('#vm-state', el), you = $('#vm-you', el), ai = $('#vm-ai', el);
    const auto = () => V.state.settings.auto_listen !== false;
    const paint = () => { $('#vm-pname', el).textContent = (V.state.current && V.state.current.name) || '語音包'; $('#vm-auto', el).textContent = auto() ? '講完自動再聽：開' : '講完自動再聽：關'; };
    const set = (x, msg) => { state = x; el.dataset.st = x; stEl.textContent = msg || { idle: '點中間的圓開始說話', listening: '聆聽中…講完停一下就會送出', transcribing: '辨識中…', thinking: 'AI 思考中…', speaking: 'AI 說話中（點一下可以打斷）' }[x] || ''; };
    paint(); set('idle'); if (!V.sttMode()) set('idle', '沒有可用的語音辨識：模型頁加入 Groq／OpenAI／Gemini 金鑰，或在手機安裝 Google App');
    const close = () => { alive = false; if (ctl) ctl.cancel(); V.stopSpeaking(); el.remove(); document.body.classList.remove('vm-open'); };
    const listen = async () => {
      if (!alive) return; V.stopSpeaking(); set('listening'); you.textContent = '';
      ctl = V.listen({ silenceMs: 1300, waitMs: 9000, onLevel: (lv) => orb.style.setProperty('--lv', lv.toFixed(2)), onPartial: (t) => { you.textContent = t; }, onStage: () => set('transcribing') });
      let text = ''; try { text = (await ctl.done).trim(); } catch (e) { ctl = null; if (alive) { set('idle', e.message); } return; } ctl = null; orb.style.removeProperty('--lv'); if (!alive) return;
      if (!text) { miss++; if (miss >= 2 || !auto()) { miss = 0; return set('idle', '沒聽到聲音。點中間的圓再說一次'); } return listen(); }
      miss = 0; you.textContent = text; set('thinking'); ai.textContent = '';
      let reply = ''; try { reply = await send(text); } catch (e) { reply = '發生問題：' + e.message; } if (!alive) return;
      ai.innerHTML = LA.richText ? LA.richText(reply) : esc(reply);
      if (V.state.settings.speak_replies !== false) { set('speaking'); try { await V.speak(reply, { onStart: () => set('speaking') }); } catch (e) { LA.toast('念不出來：' + e.message, true); } }
      if (!alive) return; if (auto()) listen(); else set('idle');
    };
    orb.onclick = () => { if (state === 'idle') return listen(); if (state === 'listening' && ctl) return ctl.stop(); if (state === 'speaking') { V.stopSpeaking(); return; } };
    $('#vm-x', el).onclick = close; $('#vm-stop', el).onclick = () => { if (ctl) ctl.cancel(); V.stopSpeaking(); set('idle'); };
    $('#vm-auto', el).onclick = LA.guard(async () => { V.state = await LA.post('/api/voice/settings', { auto_listen: !auto() }); paint(); });
    $('#vm-pack', el).onclick = () => V.settings(() => paint());
    if (V.sttMode()) listen();
    return { close };
  };

  // ---------------- 語音包設定 ----------------
  V.settings = async function (onChange) {
    const s = await V.load(); const dv = await V.deviceVoices().catch(() => []); const cs = s.settings; const cur = s.current && s.current.id;
    const packRow = (p) => `<label class="vp ${p.available ? '' : 'off'}"><input type="radio" name="vp" value="${esc(p.id)}" ${cs.pack === p.id ? 'checked' : ''} ${p.available ? '' : 'disabled'}><span class="grow"><b>${esc(p.name)}</b>${p.id === cur ? ' <span class="pill on">使用中</span>' : ''}<small>${esc(p.desc || '')}${p.available ? '' : `・需要模型頁的 ${p.provider === 'gemini' ? 'Gemini' : 'OpenAI'} 金鑰`}</small></span><button class="btn sm" data-try="${esc(p.id)}" ${p.available ? '' : 'disabled'}>試聽</button></label>`;
    const m = LA.modal(`<h3 style="margin-top:0">${LA.icon('speaker')} 語音包</h3>
      <label class="chk"><input type="radio" name="vp" value="auto" ${cs.pack === 'auto' ? 'checked' : ''}> 自動（有 Gemini 金鑰用「溫暖親切」，有 OpenAI 用「自然對話」，都沒有用手機內建）</label>
      <div class="list vp-list">${s.packs.map(packRow).join('')}</div>
      <label class="f">語速 <span id="vs-rv">${(+cs.rate).toFixed(2)}</span>×</label><input type="range" id="vs-rate" min="0.6" max="1.8" step="0.05" value="${+cs.rate || 1}">
      <label class="f">音調（手機內建語音）<span id="vs-pv">${(+cs.pitch).toFixed(2)}</span></label><input type="range" id="vs-pitch" min="0.6" max="1.6" step="0.05" value="${+cs.pitch || 1}">
      <label class="f">手機內建語音的聲音</label><select id="vs-dv"><option value="">自動（中文）</option>${dv.map((v) => `<option value="${esc(v.name)}" ${cs.device_voice === v.name ? 'selected' : ''}>${esc(v.locale)}・${esc(v.name)}${v.network ? '（要網路）' : ''}</option>`).join('')}</select>
      <label class="f">語音辨識</label><select id="vs-stt"><option value="auto" ${cs.stt === 'auto' ? 'selected' : ''}>自動（有雲端金鑰用雲端，較準）</option><option value="cloud" ${cs.stt === 'cloud' ? 'selected' : ''}>雲端（Groq／OpenAI／Gemini）</option><option value="device" ${cs.stt === 'device' ? 'selected' : ''}>手機內建（免金鑰）</option></select>
      <div class="mute small">雲端辨識可用：${s.stt.cloud.length ? esc(s.stt.cloud.join('、')) : '沒有（模型頁加金鑰）'}</div>
      <details style="margin-top:10px"><summary>自訂語音包</summary>
        <label class="f">名稱</label><input id="vc-name" maxlength="20" value="${esc((cs.custom && cs.custom.name) || '')}" placeholder="例：我的管家">
        <label class="f">來源</label><select id="vc-prov"><option value="gemini">Gemini</option><option value="openai">OpenAI</option></select>
        <label class="f">聲音</label><select id="vc-voice"></select>
        <label class="f">說話風格（給雲端語音的提示）</label><input id="vc-style" maxlength="200" value="${esc((cs.custom && cs.custom.style) || '')}" placeholder="例：像管家一樣有禮貌、語氣平穩，台灣華語">
        <div class="row" style="margin-top:8px"><button class="btn sm" id="vc-save">儲存自訂語音包</button>${cs.custom ? '<button class="btn sm" id="vc-del">刪除</button>' : ''}</div></details>
      <div class="row" style="justify-content:flex-end;margin-top:12px"><button class="btn pri" id="vs-ok">完成</button></div>`);
    const root = m || document; const prov = $('#vc-prov', root), vsel = $('#vc-voice', root);
    const fillV = () => { const list = prov.value === 'openai' ? s.voices.openai : s.voices.gemini; vsel.innerHTML = list.map((v) => `<option ${cs.custom && cs.custom.voice === v ? 'selected' : ''}>${esc(v)}</option>`).join(''); };
    if (cs.custom && cs.custom.provider) prov.value = cs.custom.provider === 'openai' ? 'openai' : 'gemini'; fillV(); prov.onchange = fillV;
    const save = async (b) => { V.state = await LA.post('/api/voice/settings', b); if (onChange) onChange(V.state); };
    root.onchange = LA.guard(async (e) => {
      const t = e.target; if (t.name === 'vp') await save({ pack: t.value }); else if (t.id === 'vs-dv') await save({ device_voice: t.value }); else if (t.id === 'vs-stt') await save({ stt: t.value });
      else if (t.id === 'vs-rate') await save({ rate: +t.value }); else if (t.id === 'vs-pitch') await save({ pitch: +t.value });
    });
    root.oninput = (e) => { if (e.target.id === 'vs-rate') $('#vs-rv', root).textContent = (+e.target.value).toFixed(2); if (e.target.id === 'vs-pitch') $('#vs-pv', root).textContent = (+e.target.value).toFixed(2); };
    root.onclick = LA.guard(async (e) => {
      const tr = e.target.closest('[data-try]'); if (tr) { e.preventDefault(); tr.disabled = true; try { await V.speak('你好，我是你的 AI 助理。今天想聊什麼呢？', { pack: tr.dataset.try, noFallback: true }); } finally { tr.disabled = false; } return; }
      if (e.target.closest('#vc-save')) { await save({ custom: { name: $('#vc-name', root).value, provider: prov.value, voice: vsel.value, style: $('#vc-style', root).value } }); await save({ pack: 'custom' }); LA.closeModal(); return LA.toast('已儲存並改用自訂語音包'); }
      if (e.target.closest('#vc-del')) { await save({ custom: null, pack: 'auto' }); LA.closeModal(); return LA.toast('已刪除自訂語音包'); }
      if (e.target.closest('#vs-ok')) { V.stopSpeaking(); LA.closeModal(); }
    });
  };
})();
