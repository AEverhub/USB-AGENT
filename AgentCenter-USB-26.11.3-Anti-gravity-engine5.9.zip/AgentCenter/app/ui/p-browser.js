'use strict';
/* G 瀏覽器頁：AI 與管理員共用的瀏覽器（Manus 式）。看 AI 操作、隨時接手登入／輸入驗證碼、交還給 AI；帳密保險箱。 */
(function () {
  const { esc, $ } = LA; let alive = false; let st = null; let busy = false; let lastUrl = null;
  // 26.11.3 Revise6：Manus 式步驟串流——AI（或你接手時）每做一個動作，後台截一張圖用 SSE 推過來；下方時間軸可以點回看每一步
  let es = null; let steps = []; let viewSeq = null; let lastEvt = 0; let showOn = true; let clearAt = 0;
  const stepUrl = (seq) => `/api/browser/step/${seq}?t=${encodeURIComponent(LA.token)}`;
  const latest = () => steps[steps.length - 1] || null;

  const modeText = (s) => (!s.enabled ? '已關閉' : !s.connected ? '未啟動' : s.control === 'user' ? '你接手中' : 'AI 控制中');
  function head(s) {
    const dot = !s.enabled ? '' : !s.connected ? 'warn' : s.control === 'user' ? 'warn' : 'ok';
    const prov = { local: '本機 Chrome', cdp: '遠端 Chrome', android: 'App 內瀏覽器', linux: '內建 Linux 的 Chromium（App 自動管理）' }[s.provider] || s.provider;
    return `<div class="card"><h3>🌐 AI 瀏覽器 <small><span class="dot ${dot}"></span>${modeText(s)}</small></h3>
      <div class="kv"><b>方式</b><span>${esc(prov)}</span><b>AI 最近動作</b><span>${s.last_action && s.last_action.text ? esc(s.last_action.text) + '（' + LA.fmtTime(s.last_action.ts) + '）' : '—'}</span>${s.google ? `<b>Google</b><span>${s.google.signed_in ? '已登入' + (s.google.session_until ? '（約到 ' + esc(s.google.session_until) + '）' : '') : '未登入'}</span>` : ''}</div>
      ${s.handoff ? `<div class="bwarn">🖐 ${esc(s.handoff.reason)}<div class="hint">處理完（登入、驗證碼、確認）請按「交還給 AI」，AI 會自動回到原本的聊天室繼續。</div></div>` : ''}
      ${s.error ? `<div class="hint err">⚠️ ${esc(s.error)}</div>` : ''}
      <div class="row">${!s.connected ? '<button class="btn pri" id="b-start">啟動瀏覽器</button>' : s.control === 'user' ? '<button class="btn ok" id="b-give">交還給 AI</button>' : '<button class="btn pri" id="b-take">接手操作</button>'}${s.connected ? '<button class="btn" id="b-stop">關閉</button>' : ''}
        ${s.connected || steps.length || (window.AndroidBridge && AndroidBridge.browserOpen && s.provider === 'android') ? '<button class="btn" id="b-native">全螢幕</button>' : ''}</div>
      ${window.AndroidBridge && AndroidBridge.browserEnable && s.provider === 'android' && !s.connected ? `<div class="hint">手機版使用 App 內建的 WebView 當瀏覽器，按「啟動瀏覽器」即可開始。${AndroidBridge.browserEnabled && !AndroidBridge.browserEnabled() ? '<div class="row"><button class="btn sm" id="b-enable">啟用 App 內瀏覽器</button></div>' : ''}</div>` : ''}
      ${!s.connected && s.provider === 'local' && !s.chrome ? '<div class="hint err">這台機器找不到 Chrome／Chromium／Edge。請安裝或到設定頁「瀏覽器」填執行檔路徑。</div>' : ''}</div>`;
  }
  function viewer(s) {
    const tabs = (s.tabs || []).map((t) => `<button class="tab ${t.active ? 'on' : ''}" data-tab="${esc(t.id)}" title="${esc(t.url)}">${esc(t.title || t.url || '(新分頁)')}</button>`).join('');
    const user = s.control === 'user';
    return `<div class="card"><div class="bbar"><button class="btn" data-nav="back" ${user ? '' : 'disabled'}>◀</button><button class="btn" data-nav="forward" ${user ? '' : 'disabled'}>▶</button><button class="btn" data-nav="reload" ${user ? '' : 'disabled'}>⟳</button>
      <input id="b-url" placeholder="${user ? '輸入網址或搜尋文字' : '接手後才能輸入網址'}" value="${esc((s.page && s.page.url) || '')}" ${user ? '' : 'disabled'} autocapitalize="off" autocorrect="off" spellcheck="false"><button class="btn pri" id="b-go" ${user ? '' : 'disabled'}>前往</button></div>
      ${s.provider !== 'android' ? `<div class="btabs">${tabs}${user ? '<button class="tab" id="b-newtab">＋ 新分頁</button>' : ''}</div>` : ''}
      <div class="bframe ${user ? 'user' : 'ai'}" id="b-frame">${s.connected || steps.length ? '<img id="b-img" alt="">' : '<div class="bempty">瀏覽器還沒啟動。按上方「啟動瀏覽器」，或直接叫 AI 去開網頁。</div>'}<div class="bovl" id="b-ovl">${user ? '你可以直接點、滑、打字（點畫面後打字會送進網頁）' : 'AI 控制中：只能看。要自己登入或輸入驗證碼請按「接手操作」'}</div></div>
      ${user && s.connected ? `<input id="b-kb" style="position:absolute;opacity:0;height:1px;width:1px;left:-99px" autocapitalize="off" autocomplete="off" autocorrect="off" spellcheck="false">
      <div class="row" style="margin-top:8px"><input id="b-text" class="grow" placeholder="要輸入的文字（帳號、驗證碼…）" autocomplete="off"><button class="btn pri" id="b-send">輸入</button></div>
      <div class="bkeys"><button class="btn" data-key="Enter">Enter</button><button class="btn" data-key="Tab">Tab</button><button class="btn" data-key="Backspace">⌫</button><button class="btn" data-key="Escape">Esc</button><button class="btn" data-key="ArrowUp">↑</button><button class="btn" data-key="ArrowDown">↓</button><button class="btn" data-key="PageDown">下頁</button><button class="btn" data-key="Control+a">全選</button></div>` : ''}</div>`;
  }
  function gcard(s) {
    const g = s.gws; if (!g) return '';
    const head = g.connected
      ? `<div class="vrow"><div class="grow"><b>✅ 已連線</b> <span class="mute">${esc(g.email || g.mode)}（${g.mode === 'oauth' ? 'OAuth 授權' : 'Service Account'}）</span><div class="mute">今天已寄 ${g.sent_today}/${g.send_cap} 封 · 寄信${g.send_requires_approval ? '需你審批' : '直接寄出'}</div></div><button class="btn sm" id="g-test">測試</button> <button class="btn sm" id="g-disc">中斷連線</button></div>`
      : '<div class="mute" style="padding:6px 0">尚未連線。連線後 AI 能直接寄 Gmail、填 Google 表單、讀寫 Sheets／Docs／雲端硬碟／日曆／Tasks，<b>完全不用瀏覽器登入</b>，所以不會被 Google 的自動化偵測或 WebView 登入封鎖擋下。</div>';
    return `<div class="card"><h3>🔌 Google Workspace API <small>官方 API・不經瀏覽器・不會被擋</small></h3>${head}
      <details ${g.connected ? '' : 'open'} style="margin-top:8px"><summary class="btn sm" style="display:inline-block">${g.connected ? '設定／重新授權' : '開始連線（約 3 分鐘）'}</summary>
        <div class="hint"><b>步驟 1</b>：Google Cloud Console 建立專案 → 啟用 Gmail／Drive／Sheets／Docs／Calendar／Tasks／Forms API → 「OAuth 同意畫面」選外部並把自己加為測試使用者 → 「憑證」建立 OAuth 用戶端 ID，類型選<b>電腦版應用程式</b>。（個人 Gmail 與 Workspace 皆可）</div>
        <label class="f">OAuth 用戶端 ID</label><input id="g-cid" autocapitalize="off" autocomplete="off" placeholder="${g.client_id_set ? '（已設定，要換才填）' : 'xxxx.apps.googleusercontent.com'}">
        <label class="f">OAuth 用戶端密鑰</label><input id="g-sec" type="password" autocomplete="new-password" placeholder="${g.client_secret_set ? '（已設定，要換才填）' : 'GOCSPX-…'}">
        <div class="row" style="margin-top:8px"><button class="btn" id="g-save">儲存</button> <button class="btn pri" id="g-auth">步驟 2：產生授權連結</button></div>
        <div id="g-url" class="hint" style="display:none;word-break:break-all"></div>
        <div class="hint"><b>步驟 3</b>：在<b>你自己的</b>瀏覽器開連結並按同意。最後會跳到一個「無法連線 127.0.0.1」的頁面，這是正常的——把<b>網址列整串網址</b>（含 code=…）貼到下面：</div>
        <input id="g-code" autocapitalize="off" autocomplete="off" placeholder="http://127.0.0.1:53682/?code=…"><div class="row" style="margin-top:8px"><button class="btn pri" id="g-ex">完成授權</button></div>
        <details style="margin-top:8px"><summary class="mute">進階：Service Account（Workspace 網域委派）／直接貼 refresh token</summary>
          <label class="f">Service Account JSON</label><textarea id="g-sa" rows="3" autocapitalize="off" placeholder="貼上金鑰檔內容"></textarea>
          <label class="f">代表的使用者 Email（網域委派才需要）</label><input id="g-sub" autocapitalize="off" placeholder="you@yourcompany.com"><div class="row" style="margin-top:8px"><button class="btn" id="g-sasave">連線 Service Account</button></div>
          <label class="f">或：refresh token</label><input id="g-rt" type="password" autocomplete="new-password"><div class="row" style="margin-top:8px"><button class="btn" id="g-rtsave">使用此 token</button></div></details>
        <label class="f" style="margin-top:10px"><input type="checkbox" id="g-appr" ${g.send_requires_approval ? 'checked' : ''}> 寄信要我審批才寄出（建議保持開啟）</label>
      </details>
      <details style="margin-top:8px"><summary class="btn sm" style="display:inline-block">填「需要登入」的別人表單${g.form_cookie && g.form_cookie.saved ? '（已設定 ✅）' : ''}</summary>
        <div class="hint">公開表單不用設定就能填。若表單要求登入 Google（組織內部、限填一次、收集帳號），貼上<b>已登入 Google 的瀏覽器</b> Cookie，AI 就能以你的身分填。取得方式：電腦 Chrome 開 docs.google.com → F12 → Network → 重新整理 → 點任一請求 → Request Headers 的 <code>cookie:</code> 整串複製。Cookie 加密存放、AI 看不到、只會送給 google.com；等同你的登入狀態，不用時請按「清除」。回覆會記在你的帳號下。</div>
        <textarea id="g-ck" rows="3" autocapitalize="off" autocomplete="off" placeholder="SID=…; HSID=…; …"></textarea>
        <div class="row" style="margin-top:8px"><button class="btn" id="g-cksave">儲存 Cookie</button> <button class="btn sm" id="g-ckclear">清除</button></div></details>
      <div class="hint">憑證以 AES-256-GCM 加密存在手機上，AI 看不到 token 或密鑰；整個 google 設定 AI 不能改（包含審批開關）。</div></div>`;
  }

  /** 內建 Linux（PRoot＋Alpine，不需 Termux App） */
  function lcard(s) {
    const L = s.linux; if (!L) return ''; const j = L.job;
    const bar = j && j.running ? `<div class="lbar"><i style="width:${Math.round((j.step / j.steps) * 100)}%"></i></div><div class="small">${esc(j.phase)}（${j.step}/${j.steps}）</div><div class="small mute mono">${esc(j.last || '')}</div>` : '';
    let body;
    if (!L.supported) body = '<div class="mute">這個 App 版本沒有內建 PRoot，暫時只能用下方的外部 Termux。<br><span class="small">開發者：建置 APK 前執行 <span class="mono">scripts/fetch-proot-android.sh</span>。</span></div>';
    else if (!L.installed) body = `<div class="mute">在 App 裡直接建一台 Linux 給 AI 用（不需要安裝 Termux）：bash、node、python、git，可選裝真正的 Chromium。第一次需要網路，約 3–10 分鐘（含 Chromium 約多 200MB）。</div>${bar}
      ${j && !j.running && j.ok === false ? `<div class="err small">上次失敗：${esc(j.error)}</div>` : ''}
      <div class="row" style="margin-top:8px;flex-wrap:wrap;gap:6px"><button class="btn pri" id="l-install" ${j && j.running ? 'disabled' : ''}>安裝內建 Linux</button><button class="btn" id="l-install-c" ${j && j.running ? 'disabled' : ''}>安裝（含 Chromium）</button>${j && j.ok === false ? `<button class="btn" id="l-diag">檢查相容性</button>` : ''}</div>`;
    else body = `<div class="vrow"><div class="grow"><b>${L.bridge.running ? '✅ 執行中' : L.mode !== 'embedded' ? '⏸ 未使用（目前用外部 Termux）' : '⚠️ 未執行'}</b> <span class="mute">Alpine ${esc(L.version)} · ${esc(L.arch)}${L.chromium ? ' · Chromium' : ''}</span>${L.bridge.error && !L.bridge.running ? `<div class="err small">${esc(L.bridge.error)}</div>` : ''}</div></div>${bar}
      <div class="row" style="margin-top:6px;flex-wrap:wrap;gap:6px">${L.bridge.running ? '<button class="btn sm" id="l-stop">停止</button>' : '<button class="btn sm pri" id="l-start">啟動並讓 AI 使用</button>'}${L.chromium ? '' : `<button class="btn sm" id="l-install-c" ${j && j.running ? 'disabled' : ''}>加裝 Chromium</button>`}<button class="btn sm" data-goterm="1">開 Linux 終端機</button><button class="btn sm bad" id="l-reset">重設</button></div>
      <div class="hint">AI 用的工具和外部 Termux 相同（終端機、背景工作、檔案、Chromium）。App 的工作區在 Linux 裡是 <span class="mono">~/workspace</span>。手機功能（簡訊、定位…）需要外部 Termux:API，內建 Linux 沒有。</div>`;
    const lg = j && (j.running || j.ok === false) && L.log.length ? `<pre class="term" style="max-height:140px;white-space:pre-wrap">${esc(L.log.slice(-8).join('\n'))}</pre>` : '';
    return `<div class="card"><h3>🐧 內建 Linux <small>不需 Termux App</small></h3>${body}${lg}</div>`;
  }
  function tcard(s) {
    const t = s.termux; if (!t) return '';
    const h = s.termux_health;
    const status = !t.configured ? '<div class="mute" style="padding:6px 0">尚未設定。Termux 提供<b>完整 Linux</b>（bash／python／git／node／pkg）與<b>真正的 Chromium</b>（不是 Android WebView，Google 登入與表單不會被擋），AI 可以自己裝工具、跑腳本、用 Chromium 操作網頁。</div>'
      : `<div class="vrow"><div class="grow"><b>${h ? (h.ok ? '✅ 已連線' : '⚠️ 連不上') : '已設定'}</b> <span class="mute">${esc(t.url)}</span>${h && h.ok ? `<div class="mute">${esc(h.arch || '')} · Chromium ${h.chromium && h.chromium.installed ? (h.chromium.running ? '執行中 port ' + h.chromium.port : '已安裝') : '未安裝'}${t.using_for_browser ? ' · <b>目前是 AI 的瀏覽器</b>' : ''}</div>` : (h && h.error ? `<div class="mute">${esc(h.error)}</div>` : '')}</div><button class="btn sm" id="t-test">測試連線</button></div>
        <div class="row" style="margin-top:6px;flex-wrap:wrap;gap:6px"><button class="btn pri" id="t-use">啟動 Chromium 並設為 AI 瀏覽器</button> <button class="btn sm" id="t-restore">改回 App 內瀏覽器</button></div>
        <label class="f" style="margin-top:8px"><input type="checkbox" id="t-full" ${t.full_access ? 'checked' : ''}> 完整權限模式：把 Termux 當成 AI 的獨立電腦（任何路徑、可跑數小時任務、不必逐步詢問）</label>
        <div class="row" style="margin-top:8px"><input id="t-cmd" class="grow" autocapitalize="off" autocomplete="off" placeholder="試跑指令，例如：python3 --version"><button class="btn sm" id="t-run">執行</button></div><pre id="t-out" class="mute" style="white-space:pre-wrap;max-height:160px;overflow:auto;margin:6px 0 0"></pre>`;
    return `<div class="card"><h3>📦 外部 Termux（選用） <small>要簡訊／定位等手機功能時才需要</small></h3>${status}
      <details ${t.configured ? '' : 'open'} style="margin-top:8px"><summary class="btn sm" style="display:inline-block">${t.configured ? '重新安裝／修復' : '安裝步驟（約 10 分鐘）'}</summary>
        <div class="hint"><b>1.</b> 安裝 Termux（請從 <b>F-Droid</b> 或 GitHub Releases 安裝，Google Play 版本太舊）。<br><b>2.</b> 按下面按鈕複製安裝指令，開啟 Termux 貼上執行（會裝 Node／Python／Git／<b>Chromium</b>，需下載數百 MB，請連 Wi-Fi）。<br><b>3.</b> 完成後它會自動向本 App 註冊，回來按「測試連線」。<br><b>4.</b> Android 設定 → 電池 → 把 Termux 設為「不受限制」，否則切到背景會被系統殺掉。</div>
        <div class="row" style="margin-top:8px"><button class="btn pri" id="t-copy">複製安裝指令</button></div>
        <details style="margin-top:8px"><summary class="mute">手動設定橋接網址／token</summary>
          <label class="f">橋接網址</label><input id="t-url" autocapitalize="off" value="${esc(t.url)}"><label class="f">橋接 token</label><input id="t-tok" type="password" autocomplete="new-password" placeholder="${t.token_set ? '（已設定，要換才填）' : ''}"><div class="row" style="margin-top:8px"><button class="btn" id="t-save">儲存</button></div></details></details>
      <div class="hint">安全：橋接程式只聽 127.0.0.1、每個請求都要 token；Termux 是另一個 App／使用者，AI 在裡面讀不到本 App 的金鑰與設定；AI 的 Termux 指令會寫入稽核紀錄，可用設定「AI 可使用終端機」一鍵關閉。</div></div>`;
  }

  function vault(s) {
    const rows = (s.vault || []).map((v) => `<div class="vrow"><div class="grow"><b>${esc(v.name)}</b> <span class="mute">${esc(v.site || '')}</span><div class="mute">${esc(v.username || '—')} · ${v.has_password ? '有密碼' : '無密碼'}${v.has_totp ? ' · 兩步驟碼' : ''}</div></div><button class="btn sm" data-vdel="${esc(v.id)}">刪除</button></div>`).join('');
    return `<div class="card"><h3>🔑 帳密保險箱 <small>AI 只看得到名稱，看不到密碼</small></h3>${rows || '<div class="mute" style="padding:6px 0">還沒有帳號。你也可以不存，遇到登入時按「接手操作」自己登入一次，登入狀態會保留。</div>'}
      <div class="hint">給 AI 一個 Google 帳號：新增後跟 AI 說「登入 Google」即可。AI 會自己填帳號密碼；若有「兩步驟驗證碼種子」也能自動過關；遇到簡訊／人機驗證會叫你接手。密碼以 AES-256-GCM 加密存在手機上，不會出現在對話、日誌或 AI 的檔案工具裡。</div>
      <details style="margin-top:8px"><summary class="btn sm" style="display:inline-block">＋ 新增帳號</summary>
        <label class="f">名稱</label><input id="v-name" placeholder="例如：Google 主帳號">
        <label class="f">網站</label><input id="v-site" placeholder="google.com" value="google.com">
        <label class="f">帳號（Email／手機）</label><input id="v-user" autocapitalize="off" autocomplete="off">
        <label class="f">密碼</label><input id="v-pw" type="password" autocomplete="new-password">
        <label class="f">兩步驟驗證碼種子（選填，Base32）</label><input id="v-totp" placeholder="驗證器 App 的設定金鑰；沒有就留空" autocapitalize="off" autocomplete="off">
        <div class="hint">Google 帳號需到「安全性 → 兩步驟驗證 → 驗證器應用程式」設定時顯示的那串金鑰。用簡訊／手機提示驗證的帳號沒辦法自動過，到時請你接手。</div>
        <div class="row" style="margin-top:8px"><button class="btn pri" id="v-save">儲存</button></div></details></div>`;
  }

  async function loadFrame() {
    if (!alive || busy || !st || !st.connected || steps.length) return; const img = $('#b-img'); if (!img) return; busy = true;   // 有步驟串流就不輪詢（每一步會推過來）
    try { const r = await fetch('/api/browser/frame', { headers: { authorization: 'Bearer ' + LA.token } }); if (r.ok) { const b = await r.blob(); const u = URL.createObjectURL(b); const old = img.src; img.onload = () => { if (old && old.startsWith('blob:')) URL.revokeObjectURL(old); }; img.src = u; } } catch { /* 下一輪再試 */ }
    busy = false;
  }
  async function loop() {
    // 備援：串流斷掉時每 3 秒對一次最新步驟；還沒有任何步驟時偶爾抓一張畫面
    while (alive) {
      if (!steps.length) await loadFrame();
      else if (Date.now() - lastEvt > 6000) { try { const r = await LA.api('/api/browser/steps'); for (const m of r.items || []) addStep(m); lastEvt = Date.now(); } catch { /* ignore */ } }
      await new Promise((r) => setTimeout(r, 3000));
    }
  }
  async function pollState(main, force) {
    const s = await LA.api('/api/browser/state'); s.gws = await LA.api('/api/google/state').catch(() => null); s.termux = await LA.api('/api/termux/state').catch(() => null); s.linux = await LA.api('/api/linux/state').catch(() => null); s.termux_health = st ? st.termux_health : null; const lk = (x) => JSON.stringify(x && x.linux ? [x.linux.installed, x.linux.chromium, x.linux.bridge.running, x.linux.mode, x.linux.job && [x.linux.job.step, x.linux.job.running, x.linux.job.last, x.linux.job.ok]] : null); const changed = !st || force || lk(s) !== lk(st) || JSON.stringify([s.connected, s.control, s.enabled, s.error, s.handoff, (s.tabs || []).map((t) => t.id + t.title), s.vault.length, s.google && s.google.signed_in, JSON.stringify(s.gws), JSON.stringify(s.termux), JSON.stringify(s.termux_health)]) !== JSON.stringify([st.connected, st.control, st.enabled, st.error, st.handoff, (st.tabs || []).map((t) => t.id + t.title), st.vault.length, st.google && st.google.signed_in, JSON.stringify(st.gws), JSON.stringify(st.termux), JSON.stringify(st.termux_health)]);
    const keepVault = ($('#v-name') && ($('#v-name').value || $('#v-user').value)) || ($('#g-cid') && ($('#g-cid').value || $('#g-sec').value || $('#g-code').value || $('#g-sa').value || $('#g-rt').value || ($('#g-ck') && $('#g-ck').value))) || ($('#t-tok') && ($('#t-tok').value || $('#t-cmd').value)) || ($('#g-url') && $('#g-url').style.display !== 'none');
    st = s; if (changed && !keepVault) paint(main); else if ($('#b-url') && s.page && s.page.url !== lastUrl && document.activeElement !== $('#b-url')) { $('#b-url').value = s.page.url; }
    lastUrl = s.page && s.page.url; const ov = $('#b-ovl'); if (ov && !steps.length && s.control !== 'user' && s.last_action && s.last_action.text) ov.textContent = 'AI：' + s.last_action.text;
  }
  function paint(main) {
    main.innerHTML = `<div id="b-head">${head(st)}</div>${viewer(st)}${timeline()}${lcard(st)}${tcard(st)}${gcard(st)}${vault(st)}`; if (LA.iconize) LA.iconize(main); bindFrame(); showStep();
  }
  // 26.11.3 pro2.1：圖片紀錄可刪除（全部／這一張）、可隱藏；任務做完 5 分鐘自動刪
  const clearNote = () => (clearAt ? `約 ${Math.max(1, Math.round((clearAt - Date.now()) / 60000))} 分鐘後自動刪除` : '任務做完 5 分鐘後自動刪除');
  function timeline() {
    if (!showOn) return `<div class="card bsteps-card" id="b-tl"><div class="row" style="justify-content:space-between"><b>操作步驟</b><span class="mute small">圖片紀錄已隱藏（${clearNote()}）</span><button class="btn sm" id="b-hshow">顯示</button><button class="btn sm danger" id="b-hclear">清除紀錄</button></div></div>`;
    return `<div class="card bsteps-card" id="b-tl"><div class="row" style="justify-content:space-between"><b>操作步驟</b><span class="mute small" id="b-stepinfo">${steps.length ? `共 ${steps.length} 步` : '還沒有動作'}</span><button class="btn sm" id="b-live" ${viewSeq ? '' : 'hidden'}>回到最新</button><button class="btn sm" id="b-hdel" ${viewSeq ? '' : 'hidden'}>刪除這張</button><button class="btn sm" id="b-hhide">隱藏</button><button class="btn sm danger" id="b-hclear" ${steps.length ? '' : 'disabled'}>清除紀錄</button></div>
      <div class="small mute" id="b-clearnote">${steps.length ? clearNote() : ''}</div><div class="bsteps" id="b-steps">${steps.map(stepChip).join('')}</div></div>`;
  }
  function redrawTl() { const t = $('#b-tl'); if (t) { t.outerHTML = timeline(); if (LA.iconize) LA.iconize(document.querySelector('main')); } if (!steps.length) { const img = $('#b-img'); if (img) { img.removeAttribute('src'); delete img.dataset.seq; } const ov = $('#b-ovl'); if (ov) ov.textContent = ''; } showStep(); }
  async function reloadSteps() { try { const r = await LA.api('/api/browser/steps'); steps = r.items || []; showOn = r.show !== false; clearAt = r.clear_at || 0; } catch { steps = []; } if (viewSeq && !steps.some((x) => x.seq === viewSeq)) viewSeq = null; redrawTl(); }
  const stepChip = (x) => `<button class="bstep ${x.seq === (viewSeq || (latest() || {}).seq) ? 'on' : ''} ${x.by === 'user' ? 'me' : ''}" data-step="${x.seq}" title="${esc(x.url || '')}"><img src="${stepUrl(x.seq)}" alt="" loading="lazy"><span><b>${x.seq}</b> ${esc(x.label)}</span></button>`;
  /** 把目前要看的那一步放到大畫面（viewSeq＝null 代表跟著最新） */
  function showStep() {
    const x = viewSeq ? steps.find((s) => s.seq === viewSeq) : latest(); const img = $('#b-img'); if (!x || !img) return;
    if (img.dataset.seq !== String(x.seq)) { img.src = stepUrl(x.seq); img.dataset.seq = x.seq; }
    const ov = $('#b-ovl'); if (ov) ov.textContent = `${viewSeq ? '回看' : x.by === 'user' ? '你' : 'AI'}・第 ${x.seq} 步：${x.label}`;
    const info = $('#b-stepinfo'); if (info) info.textContent = `共 ${steps.length} 步`; const lv = $('#b-live'); if (lv) lv.hidden = !viewSeq; const hd = $('#b-hdel'); if (hd) hd.hidden = !viewSeq; const hc = $('#b-hclear'); if (hc && showOn) hc.disabled = !steps.length;
    for (const b of document.querySelectorAll('.bstep')) b.classList.toggle('on', +b.dataset.step === x.seq);
  }
  function addStep(m) {
    if (!m || !showOn || steps.some((s) => s.seq === m.seq)) return; clearAt = 0; const cn = $('#b-clearnote'); if (cn) cn.textContent = clearNote(); steps.push(m); if (steps.length > 80) steps.shift(); lastEvt = Date.now();
    const box = $('#b-steps'); if (box) { box.insertAdjacentHTML('beforeend', stepChip(m)); while (box.children.length > 80) box.firstElementChild.remove(); if (!viewSeq) box.scrollLeft = box.scrollWidth; }
    if (!$('#b-img') && st) { st.connected = true; const main = document.querySelector('main'); if (main && LA.cur === 'browser') paint(main); }
    showStep(); if (fsHook) fsHook();
  }
  /** App 內全螢幕：同一個瀏覽器、同一條步驟串流；接手時可以點、捲、打字 */
  function fullscreen() {
    document.querySelectorAll('.bfs').forEach((x) => x.remove()); const el = document.createElement('div'); el.className = 'bfs'; document.body.appendChild(el);
    const user = () => st && st.control === 'user';
    const draw = () => { const x = latest(); el.innerHTML = `<div class="bfs-top"><div class="grow" style="min-width:0"><b>${user() ? '你接手中' : 'AI 控制中'}</b><br><small id="bfs-lbl">${x ? esc(`第 ${x.seq} 步：${x.label}`) : ''}</small></div>${user() ? '<button class="btn sm ok" id="bfs-give">交還給 AI</button>' : '<button class="btn sm" id="bfs-take">接手</button>'}<button class="ico" id="bfs-x" title="關閉全螢幕">${LA.icon('x')}</button></div>
      <div class="bfs-view"><img id="bfs-img" alt="" src="${x ? stepUrl(x.seq) : ''}"></div>${user() ? '<div class="bfs-keys"><input id="bfs-t" placeholder="輸入文字（按 Enter 送出）" autocomplete="off"><button class="btn sm" data-k="Enter">Enter</button><button class="btn sm" data-k="Backspace">刪除</button><button class="btn sm" data-k="Tab">Tab</button><button class="btn sm" data-nav2="back">上一頁</button></div>' : ''}`; bind(); };
    const refresh = () => { const x = latest(); const img = el.querySelector('#bfs-img'); if (x && img) { img.src = stepUrl(x.seq); const l = el.querySelector('#bfs-lbl'); if (l) l.textContent = `第 ${x.seq} 步：${x.label}`; } };
    const bind = () => {
      const img = el.querySelector('#bfs-img'); let down = null; const pos = (e) => { const r = img.getBoundingClientRect(); return { x: (e.clientX - r.left) / r.width, y: (e.clientY - r.top) / r.height }; };
      if (user() && img) { img.addEventListener('pointerdown', (e) => { down = { ...pos(e), cy: e.clientY }; }); img.addEventListener('pointerup', (e) => { if (!down) return; const p = pos(e); const mv = down.cy - e.clientY; down = null; if (Math.abs(mv) > 12) send({ type: 'scroll', x: p.x, y: p.y, dy: mv * 2 }); else send({ type: 'click', x: p.x, y: p.y }); }); }
      const ti = el.querySelector('#bfs-t'); if (ti) ti.addEventListener('keydown', (e) => { if (e.key === 'Enter' && !e.isComposing) { e.preventDefault(); const v = ti.value; ti.value = ''; (v ? LA.post('/api/browser/input', { type: 'text', text: v }) : Promise.resolve()).then(() => send({ type: 'key', key: 'Enter' })); } });
    };
    el.onclick = LA.guard(async (e) => {
      if (e.target.closest('#bfs-x')) { off(); el.remove(); return; }
      if (e.target.closest('#bfs-take')) { await LA.post('/api/browser/takeover', {}); st.control = 'user'; return draw(); }
      if (e.target.closest('#bfs-give')) { await LA.post('/api/browser/giveback', {}); st.control = 'ai'; return draw(); }
      const k = e.target.closest('[data-k]'); if (k) return send({ type: 'key', key: k.dataset.k }); const nv = e.target.closest('[data-nav2]'); if (nv) return send({ type: nv.dataset.nav2 });
    });
    const h = () => refresh(); fsHook = h; const off = () => { fsHook = null; };
    draw();
  }
  let fsHook = null;
  function connectEvents() {
    try { if (es) es.close(); } catch { /* ignore */ }
    es = new EventSource(`/api/browser/events?t=${encodeURIComponent(LA.token)}`);
    es.addEventListener('step', (e) => { try { addStep(JSON.parse(e.data)); } catch { /* ignore */ } });
    es.addEventListener('hello', () => { lastEvt = Date.now(); });
    es.addEventListener('cleared', () => { reloadSteps(); });
    es.addEventListener('clear_at', (e) => { try { clearAt = JSON.parse(e.data).at || 0; const cn = $('#b-clearnote'); if (cn) cn.textContent = clearNote(); } catch { /* ignore */ } });
    es.onerror = () => { /* 瀏覽器會自動重連；同時有輪詢備援 */ };
  }
  const send = (body) => LA.post('/api/browser/input', body).then(() => { busy = false; viewSeq = null; showStep(); }).catch((e) => LA.toast(e.message, true));
  function bindFrame() {
    const fr = $('#b-frame'); const img = $('#b-img'); if (!fr || !img || st.control !== 'user') return;
    const pos = (e) => { const r = img.getBoundingClientRect(); const t = e.changedTouches ? e.changedTouches[0] : e; return { x: (t.clientX - r.left) / r.width, y: (t.clientY - r.top) / r.height }; };
    let down = null;
    img.addEventListener('pointerdown', (e) => { down = { ...pos(e), t: Date.now(), cy: e.clientY }; });
    img.addEventListener('pointerup', (e) => { if (!down) return; const p = pos(e); const moved = Math.abs(e.clientY - down.cy);
      if (moved > 12) send({ type: 'scroll', x: p.x, y: p.y, dy: (down.cy - e.clientY) * 2 }); else { send({ type: 'click', x: p.x, y: p.y, right: Date.now() - down.t > 700 }); const kb = $('#b-kb'); if (kb) kb.focus({ preventScroll: true }); } down = null; });
    img.addEventListener('wheel', (e) => { e.preventDefault(); const p = pos(e); send({ type: 'scroll', x: p.x, y: p.y, dy: e.deltaY }); }, { passive: false });
    const kb = $('#b-kb'); if (kb) { kb.addEventListener('input', () => { const v = kb.value; kb.value = ''; if (v) send({ type: 'text', text: v }); });
      kb.addEventListener('keydown', (e) => { const m = { Enter: 'Enter', Backspace: 'Backspace', Tab: 'Tab', Escape: 'Escape', ArrowUp: 'ArrowUp', ArrowDown: 'ArrowDown', ArrowLeft: 'ArrowLeft', ArrowRight: 'ArrowRight' }[e.key]; if (m) { e.preventDefault(); send({ type: 'key', key: m }); } }); }
  }

  LA.register('browser', { title: 'G 瀏覽器頁（AI 與你共用）',
    leave() { alive = false; try { es && es.close(); } catch { /* ignore */ } es = null; fsHook = null; document.querySelectorAll('.bfs').forEach((x) => x.remove()); },
    async render(main) {
      alive = true; st = null; lastUrl = null; viewSeq = null;
      try { const r0 = await LA.api('/api/browser/steps'); steps = r0.items || []; showOn = r0.show !== false; clearAt = r0.clear_at || 0; } catch { steps = []; }
      await pollState(main, true); connectEvents();
      loop(); const iv = setInterval(() => { if (!alive) return clearInterval(iv); pollState(main).catch(() => {}); }, 2000); LA.timers.push(iv);
      main.onclick = LA.guard(async (e) => {
        const t = e.target; const id = t.id; const act = async (url, body, msg) => { await LA.post(url, body || {}); await pollState(main, true); if (msg) LA.toast(msg); };
        const sc = t.closest('[data-step]'); if (sc) { const n = +sc.dataset.step; viewSeq = n === (latest() || {}).seq ? null : n; return showStep(); }
        if (id === 'b-live') { viewSeq = null; return showStep(); }
        if (id === 'b-hclear') { if (await LA.confirm('刪除全部圖片紀錄？（瀏覽器步驟、手機代理步驟、存下來的瀏覽器截圖都會刪掉）')) { const r = await LA.post('/api/browser/steps/clear', {}); viewSeq = null; await reloadSteps(); LA.toast(`已刪除 ${r.steps} 張紀錄`); } return; }
        if (id === 'b-hdel') { if (viewSeq) { await LA.api('/api/browser/step/' + viewSeq, { method: 'DELETE' }); viewSeq = null; await reloadSteps(); LA.toast('已刪除這張'); } return; }
        if (id === 'b-hhide' || id === 'b-hshow') { await LA.post('/api/browser/steps/settings', { show: id === 'b-hshow' }); viewSeq = null; await reloadSteps(); return; }
        if (id === 'b-start') { t.disabled = true; t.textContent = '啟動中…'; try { await act('/api/browser/start'); } finally { t.disabled = false; } }
        else if (id === 'b-stop') { if (await LA.confirm('關閉瀏覽器？登入狀態會保留。')) await act('/api/browser/stop'); }
        else if (id === 'b-take') await act('/api/browser/takeover', {}, '已接手：現在由你操作，AI 會等待');
        else if (id === 'b-give') await act('/api/browser/giveback', {}, '已交還給 AI（若是它請你接手的，它會自動繼續）');
        // 26.11.3 Revise6：全螢幕要看的是「AI 正在用的那個瀏覽器」。只有 App 內 WebView 模式才開原生全螢幕；Chromium（內建 Linux／本機）在 App 裡全螢幕顯示同一個畫面
        else if (id === 'b-native') { if (st.provider === 'android' && window.AndroidBridge && AndroidBridge.browserOpen) AndroidBridge.browserOpen(); else fullscreen(); }
        else if (id === 'b-enable') { AndroidBridge.browserEnable(true); LA.toast('已啟用，請稍候再按「啟動瀏覽器」'); }
        else if (id === 'b-go') { const u = $('#b-url').value; await send({ type: 'goto', url: u }); }
        else if (id === 'b-send') { const v = $('#b-text').value; if (v) { await send({ type: 'text', text: v }); $('#b-text').value = ''; } }
        else if (id === 'b-newtab') await send({ type: 'tab', action: 'new' });
        else if (t.dataset.nav) await send({ type: t.dataset.nav });
        else if (t.dataset.key) await send({ type: 'key', key: t.dataset.key });
        else if (t.dataset.tab) { if (st.control === 'user') await send({ type: 'tab', action: 'switch', id: t.dataset.tab }); else LA.toast('接手後才能切換分頁'); }
        else if (id === 'g-save') { await LA.post('/api/google/config', { client_id: $('#g-cid').value, client_secret: $('#g-sec').value, send_requires_approval: $('#g-appr').checked }); $('#g-cid').value = ''; $('#g-sec').value = ''; LA.toast('已儲存'); await pollState(main, true); }
        else if (id === 'g-auth') { await LA.post('/api/google/config', { client_id: $('#g-cid').value, client_secret: $('#g-sec').value }); const r = await LA.post('/api/google/auth-url', {}); const u = $('#g-url'); u.style.display = 'block'; u.innerHTML = '<a target="_blank" rel="noopener" href="' + esc(r.url) + '">點這裡到 Google 授權</a>（若沒反應，長按複製後貼到你的瀏覽器）'; }
        else if (id === 'g-ex') { const v = $('#g-code').value.trim(); if (!v) return LA.toast('請貼上網址或 code', true); await LA.post('/api/google/auth-code', { code: v }); LA.toast('Google 已連線'); await pollState(main, true); }
        else if (id === 'g-sasave') { await LA.post('/api/google/service-account', { json: $('#g-sa').value, subject: $('#g-sub').value }); LA.toast('Service Account 已連線'); await pollState(main, true); }
        else if (id === 'g-rtsave') { await LA.post('/api/google/refresh-token', { token: $('#g-rt').value }); LA.toast('已連線'); await pollState(main, true); }
        else if (id === 'g-cksave') { const v = $('#g-ck').value.trim(); if (!v) return LA.toast('請貼上 Cookie', true); await LA.post('/api/google/form-cookie', { cookie: v }); $('#g-ck').value = ''; LA.toast('已加密儲存'); await pollState(main, true); }
        else if (id === 'g-ckclear') { await LA.del('/api/google/form-cookie'); LA.toast('已清除'); await pollState(main, true); }
        else if (id === 'l-install' || id === 'l-install-c') { await LA.post('/api/linux/install', { chromium: id === 'l-install-c' }); LA.toast('開始安裝，可以先離開這頁，完成後會自動啟用'); await pollState(main, true); }
        else if (id === 'l-start') { t.disabled = true; t.textContent = '啟動中…'; try { await act('/api/linux/start', {}, '內建 Linux 已啟動'); } finally { t.disabled = false; } }
        else if (id === 'l-diag') { t.disabled = true; t.textContent = '檢查中…'; try { const d = await LA.post('/api/linux/diagnose', {}); LA.modal(`<h3 style="margin-top:0">${d.ok ? '可以執行' : '無法執行'}</h3><p>${esc(d.hint)}</p><pre class="term" style="max-height:260px;white-space:pre-wrap">${esc((d.lines || []).join('\n'))}</pre>${d.ok ? '<p class="small mute">已記住這個模式，再按一次「安裝」即可。</p>' : ''}`); await pollState(main, true); } finally { t.disabled = false; t.textContent = '檢查相容性'; } }
        else if (id === 'l-stop') await act('/api/linux/stop', {}, '已停止');
        else if (id === 'l-reset') { const v = await LA.ask('重設會刪除整個內建 Linux（含裝好的套件與檔案；App 工作區不受影響）。確定請輸入 RESET', ''); if (v === 'RESET') await act('/api/linux/reset', { confirm: 'RESET' }, '已重設'); }
        else if (t.closest('[data-goterm]')) { LA.termLinux = true; LA.go('ops'); }
        else if (id === 't-copy') { await LA.copy(`curl -fsSL -H "authorization: Bearer ${LA.token}" ${location.origin}/api/termux/setup.sh | bash`); LA.toast('已複製，請到 Termux 貼上執行'); }
        else if (id === 't-full') { await LA.post('/api/termux/config', { full_access: $('#t-full').checked }); LA.toast($('#t-full').checked ? '已開啟完整權限模式' : '已關閉，AI 只能動 Termux 的 HOME'); await pollState(main, true); }
        else if (id === 't-save') { await LA.post('/api/termux/config', { url: $('#t-url').value, token: $('#t-tok').value }); $('#t-tok').value = ''; LA.toast('已儲存'); await pollState(main, true); }
        else if (id === 't-test') { try { const r = await LA.post('/api/termux/test', {}); st.termux_health = r; LA.toast('Termux 連線正常'); } catch (e) { st.termux_health = { ok: false, error: e.message }; LA.toast(e.message, true); } await pollState(main, true); }
        else if (id === 't-use') { t.disabled = true; t.textContent = '啟動中…'; try { await LA.post('/api/termux/chromium', { action: 'use' }); LA.toast('Chromium 已啟動，AI 現在用它瀏覽網頁'); } finally { await pollState(main, true); } }
        else if (id === 't-restore') { await LA.post('/api/termux/chromium', { action: 'restore' }); LA.toast('已改回 App 內瀏覽器'); await pollState(main, true); }
        else if (id === 't-run') { const c = $('#t-cmd').value.trim(); if (!c) return; $('#t-out').textContent = '執行中…'; try { const r = await LA.post('/api/termux/exec', { cmd: c, timeout_s: 60 }); $('#t-out').textContent = r.text; } catch (e) { $('#t-out').textContent = e.message; } }
        else if (id === 'g-test') { const r = await LA.post('/api/google/test', {}); LA.toast('Gmail 連線正常：' + r.email); }
        else if (id === 'g-disc') { if (await LA.confirm('中斷 Google API 連線？（會撤銷授權）')) { await LA.post('/api/google/disconnect', {}); await pollState(main, true); } }
        else if (t.dataset.vdel) { if (await LA.confirm('刪除這組帳號？')) { await LA.del('/api/vault/' + t.dataset.vdel); await pollState(main, true); } }
        else if (id === 'v-save') { await LA.post('/api/vault', { name: $('#v-name').value, site: $('#v-site').value, username: $('#v-user').value, password: $('#v-pw').value, totp: $('#v-totp').value }); LA.toast('已加密儲存'); await pollState(main, true); }
      });
      main.onkeydown = (e) => { if (e.target.id === 'b-url' && e.key === 'Enter') $('#b-go').click(); if (e.target.id === 'b-text' && e.key === 'Enter') $('#b-send').click(); };
    } });
})();
