'use strict';
/*
 * 26.11.3 pro10 使用指南（詳細的新手教學）＋用戶條款
 *  ・使用指南：新手任務清單（照著做一遍，做過的會打勾）＋每個功能的說明（怎麼開、怎麼說、注意什麼），例句點一下就送到對話
 *  ・用戶條款頁；第一次使用（或條款更新）會先跳出來，勾選同意才開始用
 */
(function () {
  const { esc } = LA; const $ = (s, r = document) => r.querySelector(s);
  const DONE = 'la_guide_done'; let done = {}; try { done = JSON.parse(localStorage.getItem(DONE) || '{}') || {}; } catch { done = {}; }
  const mark = (id) => { done[id] = 1; try { localStorage.setItem(DONE, JSON.stringify(done)); } catch { /* ignore */ } };
  let open = ''; let q = '';

  // 新手任務：照順序做一遍就會用了
  const TASKS = [
    { id: 'key', t: '設定 AI 模型金鑰', d: '沒有金鑰 AI 不會回話。到「模型與金鑰」貼上 Gemini（或其他供應商）的 API Key。', go: 'models', btn: '去設定' },
    { id: 'hello', t: '跟 AI 說第一句話', d: '回到對話，像傳訊息一樣打字就可以。', say: '你好，你可以幫我做什麼？' },
    { id: 'ledger', t: '記一筆帳', d: '直接說花了多少，AI 會自己分類並回報餘額。', say: '午餐 120 元' },
    { id: 'remind', t: '設一個提醒', d: '說時間和事情就好；排好的會出現在對話上方的「排程」長條。', say: '10 分鐘後提醒我喝水' },
    { id: 'tool', t: '打開一個工具', d: '「更多」最上面有邏輯閘、電路、程式碼三個工具。', go: 'circuit', btn: '打開電路工具' },
    { id: 'persona', t: '幫 AI 取名字、設個性', d: '到「人設」設定名字、說話風格、怎麼稱呼你。', go: 'persona', btn: '去設定' },
    { id: 'platform', t: '（選做）接上 LINE／Discord／Telegram', d: '到「連接器」照步驟貼上各平台的金鑰，就能在通訊軟體裡用同一個 AI。', go: 'connect', btn: '去設定' },
  ];
  // 每個功能的說明。say＝例句（點了送到對話）；go＝帶你去那一頁
  const SECTIONS = [
    { id: 'start', icon: 'key', t: '開始之前：模型與金鑰', body: [
      '這個 App 本身不含 AI 模型，要接你自己的金鑰。最常用的是 Google Gemini。',
      ['到 Google AI Studio 用 Google 帳號申請 API Key。', '「更多 → 模型與金鑰」貼上，按儲存。', '可以填好幾家供應商並排順序：第一家用量用完會自動換下一家。'],
      '注意：用量與費用依各供應商的方案計算，由金鑰持有人負擔。金鑰只存在這支手機，不會出現在對話或紀錄裡。'], go: 'models' },
    { id: 'chat', icon: 'chat', t: '對話：打字、語音、照片、檔案', body: [
      '有事直接說，不用記指令。講得很省略也可以（「那個幫我弄一下」「跟上次一樣」），它會從前面的對話和你的習慣推斷，猜不到才會問你。',
      ['輸入框右邊的麥克風：按一下開始說，講完自動變成文字。', '左邊的「＋」：拍照、選圖片、掃 QR、傳檔案。拍發票或收據會自動記帳。', '長按一則訊息可以引用它來回覆（「這個幫我改短一點」）。', '右上角放大鏡可以搜尋以前的對話。'],
      '回答裡的表格、公式、圖表、程式碼都會排好；程式碼可以一鍵複製。'], say: ['幫我把這段話改得更有禮貌：明天不能來', '台北到高雄怎麼去最快？', '幫我規劃週末兩天一夜的宜蘭行程'] },
    { id: 'ledger', icon: 'wallet', t: '記帳', body: [
      '說出金額就會記，AI 會判斷是必要支出、非必要支出、固定收入或非固定收入，並回報目前餘額。',
      ['「午餐 120」「昨天加油 800」「發薪水 42000」。', '拍發票、收據照片也能記。', '「這個月花了多少？」「上個月吃飯花多少？」可以查。', '完整帳本在「更多 → 記帳」，可以匯出。']], say: ['午餐 120 元', '這個月花了多少？'], go: 'ledger' },
    { id: 'tasks', icon: 'calendar', t: '排程、長期任務、計時器', body: [
      '三種「到時間做事」的方式：',
      ['排程：只做一次。「明天早上 8 點提醒我帶便當」。', '長期任務：會重複。「每週一、四晚上 8 點提醒我倒垃圾」「每月 5 號提醒我繳房租」「每 3 天提醒我澆花」。', '計時器：單純倒數，時間到手機響鈴。「計時 5 分鐘」。'],
      '排程和長期任務到時間是「AI 去做那件事再告訴你」，所以也可以排「每天早上 7 點整理今天的行程和天氣給我」。對話頁上方的長條點開可以看、暫停、修改、取消。'], say: ['10 分鐘後提醒我關火', '每週一、四晚上 8 點提醒我倒垃圾', '計時 3 分鐘'] },
    { id: 'menu', icon: 'grid', t: '服務選單與技能卡', body: [
      '輸入框左邊的格子按鈕會打開服務選單：常用的事做成一顆一顆的按鈕（掃發票、連結帳號、各種工具…）。',
      ['最後一格「編輯選單」可以新增、刪除、排順序。', '也可以自己做按鈕：寫一句固定要 AI 做的事，之後一按就做。']] },
    { id: 'tools', icon: 'circuit', t: '內建工具：邏輯閘、電路、程式碼', body: [
      '在「更多」最上面。三個工具 AI 都能直接操作，你看到的畫面會跟著變。',
      ['邏輯閘轉換器：輸入布林式或真值表，化簡成 SOP／POS／只用 NAND／NOR，畫電路圖、卡諾圖、實際 IC 接線圖，還有加減法器。', '電路工具：放電阻、電容、LED、電晶體、7805、運放、555、感測器，算每個點的電壓、電流、功率，會警告會燒掉的零件；有計算機（LED 限流電阻、分壓、色碼…）。', '程式碼工具：寫程式、執行（JavaScript 直接跑；Python、C 等要先裝內建 Linux）、請 AI 解釋、修 bug、轉語言。'],
      '圖都可以縮放、下載成 PNG 或 SVG。'], say: ['把 A\'B + AB\' 化簡並用 NAND 做', '5V 點一顆藍光 LED 要多大電阻？', '幫我寫一個排序的 Python 程式'], go: 'logic' },
    { id: 'stem', icon: 'calc', t: '數學、理工、工程計算', body: [
      'AI 會用內建的求解工具算，不是自己估：',
      ['解方程、多項式的根、聯立方程、矩陣（反矩陣、特徵值）、微分、積分、統計、擬合。', '工程：梁的撓度與應力、管路壓損、理想氣體、拋體、扭矩與轉速、熱傳。', '單位換算：「60 mph 等於多少 km/h」「30 坪幾平方公尺」。'],
      '它會列出假設、公式、代入過程和單位，方便你驗算。'], say: ['解 x^3 − 2x = 5', '60 mph 等於多少 km/h？', '一根 2 公尺的鋼梁中間放 100 公斤會彎多少？截面 5×10 公分'] },
    { id: 'phone', icon: 'grid', t: '手機代理：讓 AI 操作手機', body: [
      '開啟無障礙服務後，螢幕上會有一顆 AI 浮動球，AI 可以幫你開 App、點、滑、打字。',
      ['下指令：打字或按麥克風說，例：「打開 LINE，把明天 9 點開會傳給王小明」。', '計時器與音樂：倒數計時；播放手機裡原本就有的音樂（要允許讀取音樂）。', '連點器、巨集：重複點同一個地方，或照固定順序重複一串動作。', '遊戲協助：寫目標後按「遊戲協助」，AI 會看截圖幫你操作畫面。'],
      '安全：付款、轉帳、刪除、安裝、授權、送出訊息這類按鈕一定先問你；AI 不會幫你輸入密碼。有些遊戲禁止自動操作，是否使用請自行判斷。'], say: ['計時 5 分鐘', '放點音樂', '手機還有多少電？'], go: 'phone' },
    { id: 'browser', icon: 'globe', t: '瀏覽器與內建 Linux', body: [
      '到「瀏覽器」頁安裝內建 Linux（含 Chromium）後，AI 可以自己打開網站、登入、填表、掛號、訂東西，每一步都有截圖可以看。',
      ['帳號密碼請存在保險箱，AI 只會拿去登入，不會顯示出來。', '裝了 Linux 之後，程式碼工具也能跑 Python、C 等語言。']], go: 'browser' },
    { id: 'platforms', icon: 'link', t: '在 LINE／Discord／Telegram 裡用', body: [
      '到「連接器」照各平台的步驟設定，就能在通訊軟體裡跟同一個 AI 說話，資料是共用的。',
      ['第一次要「私訊」機器人：/claim 你的密碼（密碼在「開發者」頁設定），成為管理員。', '其他人要先經過你審核才能用。', '在群組裡要 @ 它或回覆它的訊息，它才會回應；群組訊息只保留 32 小時。']], go: 'connect' },
    { id: 'share', icon: 'users', t: '給家人朋友用：聯機與網頁版', body: [
      '不想讓別人裝 App 也可以：',
      ['「開發者 → 聯機」產生連線連結，對方用瀏覽器打開就能用（iPhone 也可以，加到主畫面像 App 一樣）。', '「用戶」頁可以設定每個人的權限、每天可以用幾次。']], go: 'users' },
    { id: 'persona', icon: 'spark', t: '人設、記憶與習慣', body: [
      'AI 會記住你告訴它的事（「我對花生過敏」「我老闆叫王大明」），也會觀察你喜歡的說話方式。',
      ['「人設」頁：名字、個性、說話風格、怎麼稱呼你。', '「以後都…」「不准…」這類話會變成長期規則。', '想讓它忘記：「忘記我的地址」。']], say: ['記住我對花生過敏', '以後回答都簡短一點'], go: 'persona' },
    { id: 'security', icon: 'shield', t: '資安顧問（只做防禦）', body: [
      '把程式碼貼給它說「幫我做資安稽核」，它會列出弱點、嚴重度和修法；描述你的系統說「做紅隊綠隊評估」會得到檢查清單和強化建議。',
      '它只做防禦：不會寫攻擊程式，也不會幫忙攻擊別人的系統。'], say: ['怎麼安全地儲存使用者密碼？'] },
    { id: 'safety', icon: 'shield', t: '權限與安全', body: [
      ['只有管理員說的話能改設定、權限、規則；其他人、網頁內容、別的機器人說的都只是資料。', '下載、發簡訊、打電話、付款這類動作一定要你核准。', '密碼類設定只能在 App 裡改，不能用對話改。', '「監控」頁可以看 AI 做過什麼、待你審批的事、用了多少 token。']], go: 'ops' },
    { id: 'tokens', icon: 'bolt', t: '省 token 的用法', body: [
      ['一次把事情說完整，比來回問好幾次省。', '固定要做的事存成技能卡或長期任務。', '重複的畫面操作用巨集或連點器，不用每一步都叫 AI 看畫面。', '計算、換單位、解方程交給工具算（AI 會自己用），不用叫它一步一步解釋。', '「監控」頁可以看每天用了多少。']] },
    { id: 'trouble', icon: 'help', t: '遇到問題怎麼辦', body: [
      ['AI 不回話：先看「模型與金鑰」有沒有填、金鑰額度有沒有用完；再看上方狀態是不是「運作中」。', '平台收不到訊息：到「監控」看該平台的狀態；手機的電池設定要改成「不受限制」，不然背景會被系統關掉。', '手機代理不動：到無障礙設定確認服務還開著。', '音樂播不了：要允許 App 讀取音樂；手機裡要真的有音樂檔。', '還是不行：「開發者」頁按「下載運行記錄」，把檔案交給開發者（金鑰會自動遮蔽）。']], go: 'dev' },
  ];
  const html = (b) => (Array.isArray(b) ? `<ul>${b.map((x) => `<li>${esc(x)}</li>`).join('')}</ul>` : `<p>${esc(b)}</p>`);
  function render(main) {
    const n = TASKS.filter((t) => done[t.id]).length; const kw = q.trim().toLowerCase();
    const secs = SECTIONS.filter((s) => !kw || (s.t + JSON.stringify(s.body) + (s.say || []).join('')).toLowerCase().includes(kw));
    main.innerHTML = `<div class="card"><h3>${LA.icon('help')} 使用指南</h3>
      <p class="mute small">第一次用，照「新手任務」做一遍就會了；想知道某個功能怎麼用，看下面的說明。例句點一下會直接送到對話。</p>
      <div class="row"><button class="btn pri" id="g-coach">${LA.icon('play', 'sm')} 互動教學（帶你點一遍）</button><button class="btn" data-go="terms">用戶條款</button></div></div>
      <div class="card"><h3>新手任務 <small>${n}／${TASKS.length}</small></h3><div class="g-bar"><i style="width:${Math.round((n / TASKS.length) * 100)}%"></i></div>
        <div class="g-tasks">${TASKS.map((t, i) => `<div class="g-task ${done[t.id] ? 'ok' : ''}"><button class="g-chk" data-done="${t.id}" title="標記完成">${done[t.id] ? LA.icon('check', 'sm') : i + 1}</button><div class="grow"><b>${esc(t.t)}</b><small>${esc(t.d)}</small></div>${t.say ? `<button class="btn sm" data-say="${esc(t.say)}" data-task="${t.id}">試試看</button>` : `<button class="btn sm" data-go="${t.go}" data-task="${t.id}">${esc(t.btn || '前往')}</button>`}</div>`).join('')}</div></div>
      <div class="card"><h3>功能說明</h3><input id="g-q" placeholder="搜尋，例：音樂、提醒、金鑰" value="${esc(q)}">
        <div class="g-secs">${secs.map((s) => `<div class="g-sec ${open === s.id || kw ? 'open' : ''}"><button class="g-head" data-sec="${s.id}"><span class="g-ic">${LA.icon(s.icon, 'sm')}</span><b class="grow">${esc(s.t)}</b>${LA.icon('next', 'sm')}</button>
          ${open === s.id || kw ? `<div class="g-body">${s.body.map(html).join('')}${s.say ? `<div class="g-say">${s.say.map((x) => `<button data-say="${esc(x)}">${esc(x)}</button>`).join('')}</div>` : ''}${s.go ? `<div class="row" style="margin-top:8px"><button class="btn sm pri" data-go="${s.go}">帶我去</button></div>` : ''}</div>` : ''}</div>`).join('') || '<div class="mute small" style="padding:10px">找不到相關說明。可以直接問 AI：「怎麼…？」</div>'}</div></div>`;
  }
  LA.register('guide', { name: '使用指南', title: '使用指南（新手任務與功能說明）',
    async render(main) {
      render(main);
      main.onclick = LA.guard(async (e) => {
        const t = e.target;
        if (t.closest('#g-coach')) { if (LA.startTutorial) LA.startTutorial(); return; }
        const dn = t.closest('[data-done]'); if (dn) { if (done[dn.dataset.done]) delete done[dn.dataset.done]; else done[dn.dataset.done] = 1; try { localStorage.setItem(DONE, JSON.stringify(done)); } catch { /* ignore */ } return render(main); }
        const say = t.closest('[data-say]'); if (say) { if (say.dataset.task) mark(say.dataset.task); await LA.go('home'); if (LA.chatSend) return LA.chatSend(say.dataset.say); return; }
        const go = t.closest('[data-go]'); if (go) { if (go.dataset.task) mark(go.dataset.task); return LA.go(go.dataset.go); }
        const sc = t.closest('[data-sec]'); if (sc) { open = open === sc.dataset.sec ? '' : sc.dataset.sec; const y = window.scrollY; render(main); window.scrollTo(0, y); return; }
      });
      main.oninput = (e) => { if (e.target.id === 'g-q') { q = e.target.value; const pos = e.target.selectionStart; render(main); const i = $('#g-q', main); i.focus(); try { i.setSelectionRange(pos, pos); } catch { /* ignore */ } } };
    } });

  // ---------------- 用戶條款 ----------------
  const termsHtml = (text) => `<div class="terms-doc">${LA.richText(String(text || '').replace(/^# (.+)$/m, '**$1**').replace(/^## (.+)$/gm, '\n**$1**'))}</div>`;
  const getTerms = async () => (LA.web && !(LA.link.client && LA.link.client.console) ? fetch('/net/terms').then((r) => r.json()).then((j) => ({ ...j, accepted: true })) : LA.api('/api/terms'));
  LA.register('terms', { name: '用戶條款', title: '用戶條款',
    async render(main) {
      let t; try { t = await getTerms(); } catch (e) { main.innerHTML = `<div class="card"><div class="hint err">${esc(e.message)}</div></div>`; return; }
      main.innerHTML = `<div class="card"><h3>${LA.icon('book')} 用戶條款 <small>版本 ${esc(t.version)}</small></h3>${t.accepted_at ? `<div class="hint small">你已在 ${new Date(t.accepted_at).toLocaleString('zh-TW', { hour12: false })} 同意${t.accepted ? '' : '舊版條款；條款已更新，請重新閱讀'}。</div>` : ''}${termsHtml(t.text)}
        <div class="row" style="margin-top:12px"><button class="btn" id="tm-dl">${LA.icon('download', 'sm')} 下載條款</button>${t.accepted === false ? '<button class="btn pri" id="tm-ok">我同意</button>' : ''}</div></div>`;
      main.onclick = LA.guard(async (e) => {
        if (e.target.closest('#tm-dl')) { await LA.saveBlob(new Blob([t.text], { type: 'text/markdown;charset=utf-8' }), 'user-terms.md'); return LA.toast('已下載'); }
        if (e.target.closest('#tm-ok')) { await LA.post('/api/terms/accept', { agree: true }); LA.toast('已同意'); return LA.go('terms'); }
      });
    } });
  /** 第一次使用／條款更新：要先同意才開始。網頁版在加入畫面就勾過了，這裡不再問。 */
  LA.termsGate = async () => {
    if (LA.web) return true; let t; try { t = await LA.api('/api/terms'); } catch { return true; }   // 讀不到就不擋（例如聯機用戶端）
    if (t.accepted) return true;
    return new Promise((resolve) => {
      const w = document.createElement('div'); w.className = 'terms-gate'; w.setAttribute('role', 'dialog'); w.setAttribute('aria-label', '用戶條款');
      w.innerHTML = `<div class="terms-box"><h3>${t.accepted_version ? '用戶條款更新了' : '開始使用前，請先閱讀用戶條款'}</h3><div class="terms-scroll">${termsHtml(t.text)}</div>
        <label class="row small" style="gap:8px;margin-top:10px"><input type="checkbox" id="tg-chk" style="width:auto"> 我已閱讀並同意以上條款</label>
        <div id="tg-err" class="hint err" hidden></div><button class="btn pri" id="tg-ok" style="width:100%;margin-top:10px">同意並開始使用</button></div>`;
      document.body.appendChild(w);
      w.querySelector('#tg-ok').onclick = async () => { const err = w.querySelector('#tg-err'); if (!w.querySelector('#tg-chk').checked) { err.hidden = false; err.textContent = '請先勾選「我已閱讀並同意」'; return; } try { await LA.post('/api/terms/accept', { agree: true }); w.remove(); resolve(true); } catch (e) { err.hidden = false; err.textContent = e.message; } };
    });
  };
})();
