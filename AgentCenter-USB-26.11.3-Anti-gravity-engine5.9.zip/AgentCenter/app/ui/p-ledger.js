'use strict';
/* 記帳表（常駐）：1–2 列合併標題、第 3 列欄名、第 4 列起資料；全部置中；收入綠／支出紅／餘額 >0 藍、<0 紅加負號 */
(function () {
  const { esc, $ } = LA; let owner = '';
  const LEGEND = '<span style="color:var(--g)">綠＝收入（固定／非固定）</span> · <span style="color:var(--r)">紅＝支出（必要／非必要）</span> · <span style="color:var(--b)">藍＝餘額 &gt; 0</span> · <span style="color:var(--r)">紅負號＝餘額 &lt; 0</span>';

  LA.register('ledger', { name: '記帳表', title: '記帳表', async render(main) {
    const L = await LA.api('/api/ledger' + (owner ? '?owner=' + encodeURIComponent(owner) : '')); const s = L.summary;
    main.innerHTML = `<div class="card"><div class="row"><select id="own" class="grow">${[['', '全部'], ...L.owners.map((o) => [o.id, o.name])].map(([v, n]) => `<option value="${esc(v)}" ${v === owner ? 'selected' : ''}>${esc(n)}</option>`).join('')}</select><button class="btn" id="xl">匯出 xlsx</button><button class="btn" id="cv">csv</button></div>
      <div class="row small" style="margin-top:8px"><span>近 ${s.days} 天：收入 <b style="color:var(--g)">${s.income}</b></span><span>支出 <b style="color:var(--r)">${s.expense}</b></span><span>淨額 <b>${s.net}</b></span><span>餘額 <b style="color:${s.balance > 0 ? 'var(--b)' : s.balance < 0 ? 'var(--r)' : 'inherit'}">${s.balance < 0 ? '-' + Math.abs(s.balance) : s.balance}</b></span></div></div>
      <div class="tblw"><table class="t ledger"><thead><tr><th class="title" colspan="8" rowspan="2">${esc(L.title)}</th></tr><tr></tr>
      <tr>${L.headers.map((h) => `<th>${esc(h)}</th>`).join('')}</tr></thead><tbody>${L.rows.map((r) => `<tr data-id="${r.id}" style="cursor:pointer"><td>${r.no}</td><td>${r.date}</td><td>${r.time}</td><td style="color:${r.kindColor}">${r.kind}</td><td style="color:${r.amountColor}">${r.amount}</td><td>${esc(r.note)}</td><td style="color:${r.tagColor}">${esc(r.tag)}</td><td style="color:${r.balanceColor}">${r.balanceText}</td></tr>`).join('') || '<tr><td colspan="8" class="mute">還沒有紀錄。對 AI 說「午餐 120」，或按下方新增。</td></tr>'}</tbody></table></div>
      <div class="hint">${LEGEND}。「AI提示」由 AI 判斷；點一列可編輯／刪除。</div>
      <div class="card" style="margin-top:12px"><h3>＋ 新增一筆</h3><div class="row"><select id="k" style="width:auto"><option value="expense">支出</option><option value="income">收入</option></select><input id="amt" type="number" inputmode="decimal" placeholder="金額" class="grow"></div><input id="note" placeholder="項目說明（例：午餐）" style="margin-top:8px"><div class="hint">分類（必要／固定…）會自動判斷；之後可點該列修改。時間＝現在（台北時間）。</div><button class="btn pri" id="add">記下</button></div>`;
    $('#own').onchange = (e) => { owner = e.target.value; LA.go('ledger'); };
    $('#xl').onclick = LA.guard(() => LA.download('/api/ledger/export?fmt=xlsx' + (owner ? '&owner=' + encodeURIComponent(owner) : ''), '記帳表.xlsx')); $('#cv').onclick = LA.guard(() => LA.download('/api/ledger/export?fmt=csv' + (owner ? '&owner=' + encodeURIComponent(owner) : ''), '記帳表.csv'));
    $('#add').onclick = LA.guard(async () => { const amount = Number($('#amt').value); if (!(amount > 0)) throw new Error('請輸入大於 0 的金額'); await LA.post('/api/ledger', { owner: owner || '*', kind: $('#k').value, amount, note: $('#note').value }); LA.toast('已記錄'); LA.go('ledger'); });
    main.onclick = LA.guard(async (e) => { const tr = e.target.closest('tr[data-id]'); if (!tr) return; const r = L.rows.find((x) => String(x.id) === tr.dataset.id);
      LA.modal(`<h3 style="margin-top:0">第 ${r.no} 筆 · ${r.date} ${r.time}</h3><label class="f">類型</label><select id="e-k"><option value="expense" ${r.kind === '支出' ? 'selected' : ''}>支出</option><option value="income" ${r.kind === '收入' ? 'selected' : ''}>收入</option></select><label class="f">金額</label><input id="e-a" type="number" value="${r.amount}"><label class="f">說明</label><input id="e-n" value="${esc(r.note)}"><label class="f">AI 提示</label><select id="e-t">${['必要支出', '非必要支出', '固定收入', '非固定收入'].map((t) => `<option ${t === r.tag ? 'selected' : ''}>${t}</option>`).join('')}</select>
        <div class="row" style="margin-top:12px;justify-content:space-between"><button class="btn bad" id="e-d">刪除</button><button class="btn pri" id="e-s">儲存</button></div>`, (m) => {
        $('#e-s', m).onclick = LA.guard(async () => { await LA.api('/api/ledger/' + r.id, { method: 'PUT', body: { kind: $('#e-k', m).value, amount: Number($('#e-a', m).value), note: $('#e-n', m).value, tag: $('#e-t', m).value } }); LA.closeModal(); LA.go('ledger'); });
        $('#e-d', m).onclick = LA.guard(async () => { if (await LA.confirm('刪除這筆？')) { await LA.del('/api/ledger/' + r.id); LA.closeModal(); LA.go('ledger'); } }); }); });
  } });
})();
