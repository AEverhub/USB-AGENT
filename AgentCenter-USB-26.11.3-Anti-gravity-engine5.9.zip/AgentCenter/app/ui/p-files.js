'use strict';
/* C 本地端試算表與檔案管理（AI 也能操作同一份資料） */
(function () {
  const { esc, $ } = LA; let tab = 'sheets'; let path = '.'; let sheetId = null;
  const colName = (i) => { let s = ''; i++; while (i > 0) { const m = (i - 1) % 26; s = String.fromCharCode(65 + m) + s; i = Math.floor((i - 1) / 26); } return s; };

  LA.register('files', { title: 'C 試算表與檔案', async render(main) {
    main.innerHTML = `<div class="seg"><button data-t="sheets" class="${tab === 'sheets' ? 'on' : ''}">📋 試算表</button><button data-t="files" class="${tab === 'files' ? 'on' : ''}">📁 檔案</button></div><div id="c-body"></div>`;
    main.onclick = LA.guard(async (e) => { const b = e.target.closest('[data-t]'); if (b) { tab = b.dataset.t; sheetId = null; LA.go('files'); } });
    await (tab === 'sheets' ? sheets() : files());
  } });

  async function sheets() {
    const body = $('#c-body');
    if (sheetId) return sheetView(body);
    const list = await LA.api('/api/sheets');
    body.innerHTML = `<div class="card"><h3>試算表 <small>AI 也能讀寫；公式用 =SUM(B2:B9)</small></h3><div class="list">${list.map((s) => `<div class="row" data-open="${s.id}" style="cursor:pointer"><span class="grow"><b>${esc(s.name)}</b><div class="mute small">${s.rows} 列 × ${s.cols} 欄 · v${s.version} · ${LA.fmtTime(s.updated)}</div></span><span>›</span></div>`).join('') || '<div class="mute">還沒有試算表。常駐的「記帳表」在獨立頁面。</div>'}</div><div class="row" style="margin-top:10px"><button class="btn pri" id="sh-new">＋ 新增試算表</button></div></div>`;
    body.onclick = LA.guard(async (e) => { const o = e.target.closest('[data-open]'); if (o) { sheetId = o.dataset.open; return sheets(); }
      if (e.target.id === 'sh-new') { const n = await LA.ask('表名'); if (!n) return; const h = await LA.ask('欄名（用逗號分隔）', '項目,金額,備註'); if (!h) return; await LA.post('/api/sheets', { name: n, headers: h.split(/[,，]/).map((x) => x.trim()) }); sheets(); } });
  }
  async function sheetView(body) {
    const r = await LA.api('/api/sheets/' + sheetId); const s = r.sheet; const comp = r.computed;
    body.innerHTML = `<div class="card"><h3>${esc(s.name)} <small>v${s.version}</small></h3><div class="row" style="margin-bottom:8px"><button class="btn sm" id="back">‹ 返回</button><button class="btn sm" id="addrow">＋ 列</button><button class="btn sm" id="xlsx">匯出 xlsx</button><button class="btn sm" id="csv">匯出 csv</button><button class="btn sm" id="hist">版本</button><button class="btn sm bad" id="del">刪除</button></div>
      <div class="tblw"><table class="t sheetgrid"><thead><tr><th></th>${s.headers.map((h, i) => `<th data-cell="${colName(i)}1">${colName(i)}<div class="mute small">${esc(h)}</div></th>`).join('')}</tr></thead><tbody>${comp.map((row, ri) => `<tr><th>${ri + 2}</th>${row.map((v, ci) => { const raw = s.rows[ri][ci]; const fx = typeof raw === 'string' && raw.startsWith('='); return `<td class="${fx ? 'fx' : ''}" data-cell="${colName(ci)}${ri + 2}" data-raw="${esc(raw)}">${esc(v)}</td>`; }).join('')}</tr>`).join('')}</tbody></table></div><div class="hint">點儲存格可編輯；點欄名改標題。</div></div>`;
    body.onclick = LA.guard(async (e) => {
      const c = e.target.closest('[data-cell]'); if (c) { const cur = c.dataset.raw ?? (c.querySelector('div') ? c.querySelector('div').textContent : ''); const v = await LA.ask('編輯 ' + c.dataset.cell, cur, { hint: '以 = 開頭是公式' }); if (v === null) return; await LA.post(`/api/sheets/${sheetId}/cell`, { cell: c.dataset.cell, value: v }); return sheets(); }
      if (e.target.id === 'back') { sheetId = null; return sheets(); } if (e.target.id === 'addrow') { await LA.post(`/api/sheets/${sheetId}/rows`, { rows: [new Array(s.headers.length).fill('')] }); return sheets(); }
      if (e.target.id === 'xlsx') return LA.download(`/api/sheets/${sheetId}/export?fmt=xlsx`, s.name + '.xlsx'); if (e.target.id === 'csv') return LA.download(`/api/sheets/${sheetId}/export?fmt=csv`, s.name + '.csv');
      if (e.target.id === 'del') { if (await LA.confirm(`刪除「${s.name}」？`)) { await LA.del('/api/sheets/' + sheetId); sheetId = null; sheets(); } }
      if (e.target.id === 'hist') { LA.modal(`<h3 style="margin-top:0">版本紀錄</h3><div class="list">${s.versions.slice().reverse().map((v) => `<div class="row"><span class="grow">v${v.v} · ${esc(v.note)}<div class="mute small">${LA.fmtTime(v.ts)}</div></span><button class="btn sm" data-rv="${v.v}">還原</button></div>`).join('') || '<div class="mute">沒有紀錄</div>'}</div>`, (m) => { m.onclick = LA.guard(async (ev) => { const b = ev.target.closest('[data-rv]'); if (b) { await LA.post(`/api/sheets/${sheetId}/restore`, { version: +b.dataset.rv }); LA.closeModal(); sheets(); } }); }); }
    });
  }

  async function files() {
    const body = $('#c-body'); const r = await LA.api('/api/files?scope=data&path=' + encodeURIComponent(path));
    const crumbs = path === '.' ? [] : path.split('/'); const up = crumbs.slice(0, -1).join('/') || '.';
    body.innerHTML = `<div class="card"><h3>檔案 <small>${LA.fmtBytes(r.disk_bytes)}</small></h3><div class="mono mute" style="margin-bottom:8px">data/${path === '.' ? '' : esc(path)}</div>
      <div class="row" style="margin-bottom:8px">${path !== '.' ? '<button class="btn sm" id="up">‹ 上層</button>' : ''}<button class="btn sm" id="mk">＋ 資料夾</button><button class="btn sm" id="nf">＋ 文字檔</button><label class="btn sm" style="margin:0">⬆ 上傳<input type="file" id="up-f" hidden multiple></label></div>
      <div class="list">${r.items.map((f) => `<div class="row"><span class="grow" data-f="${esc(f.path)}" data-d="${f.dir ? 1 : 0}" style="cursor:pointer">${f.dir ? '📁' : '📄'} ${esc(f.name)}<div class="mute small">${f.dir ? '' : LA.fmtBytes(f.size) + ' · '}${LA.fmtTime(f.mtime)}</div></span><button class="btn sm" data-m="${esc(f.path)}" data-d="${f.dir ? 1 : 0}">⋯</button></div>`).join('') || '<div class="mute">（空）</div>'}</div>
      <div class="hint">workspace/ 是 AI 的工作區；skills/、diary/、news/ 是 AI 的技能與日誌。</div></div>`;
    $('#up-f').onchange = LA.guard(async (e) => { for (const f of e.target.files) { await LA.api(`/api/files/upload?scope=data&path=${encodeURIComponent((path === '.' ? '' : path + '/') + f.name)}`, { method: 'POST', body: await f.arrayBuffer(), raw: true }); } LA.toast('上傳完成'); files(); });
    body.onclick = LA.guard(async (e) => {
      if (e.target.id === 'up') { path = up; return files(); }
      if (e.target.id === 'mk') { const n = await LA.ask('資料夾名稱'); if (n) { await LA.post('/api/files/mkdir?scope=data', { path: (path === '.' ? '' : path + '/') + n }); files(); } }
      if (e.target.id === 'nf') { const n = await LA.ask('檔名（含副檔名）'); if (n) { await LA.post('/api/files/write?scope=data', { path: (path === '.' ? '' : path + '/') + n, content: '' }); files(); } }
      const f = e.target.closest('[data-f]'); if (f) { if (f.dataset.d === '1') { path = f.dataset.f; return files(); } const t = await LA.api('/api/files/read?scope=data&path=' + encodeURIComponent(f.dataset.f)); const v = await LA.ask(f.dataset.f, t.content, { multiline: true }); if (v !== null && v !== t.content) { await LA.post('/api/files/write?scope=data', { path: f.dataset.f, content: v }); LA.toast('已儲存（舊版已快照）'); } }
      const m = e.target.closest('[data-m]'); if (m) { const p = m.dataset.m; LA.modal(`<h3 style="margin-top:0" class="mono">${esc(p)}</h3><div class="row"><button class="btn" id="m-dl" ${m.dataset.d === '1' ? 'disabled' : ''}>下載</button><button class="btn" id="m-mv">移動／改名</button><button class="btn bad" id="m-rm">刪除</button></div><div class="hint">刪除與覆蓋前會自動快照，可在開發者頁還原。</div>`, (s) => {
        $('#m-dl', s).onclick = LA.guard(async () => { await LA.download('/api/files/download?scope=data&path=' + encodeURIComponent(p), p.split('/').pop()); LA.closeModal(); });
        $('#m-mv', s).onclick = LA.guard(async () => { LA.closeModal(); const n = await LA.ask('新路徑', p); if (n && n !== p) { await LA.post('/api/files/move?scope=data', { from: p, to: n }); files(); } });
        $('#m-rm', s).onclick = LA.guard(async () => { LA.closeModal(); if (await LA.confirm('刪除 ' + p + '？')) { await LA.del('/api/files?scope=data&path=' + encodeURIComponent(p)); files(); } }); }); }
    });
  }
})();
