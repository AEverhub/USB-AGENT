'use strict';
/* 資料轉移：換手機時，舊手機下載一個 JSON 檔，到新手機上傳即可。金鑰只在設了密碼時才會加密帶過去。 */
(function () {
  const { esc } = LA; const $ = (s) => LA.$(s);
  const STEP = (n, t, d) => `<div class="tstep"><span class="tnum">${n}</span><div><b>${t}</b><div class="small mute">${d}</div></div></div>`;
  LA.register('transfer', { name: '資料轉移', title: '資料轉移', async render(main) {
    const s = await LA.api('/api/transfer/summary');
    main.innerHTML = `
      <div class="card"><div class="row" style="gap:12px;align-items:center">${LA.icon('transfer', 'lg')}<div class="grow"><h3 style="margin:0">換手機？三步搬家</h3><div class="small mute">對話、記帳、記憶、人設、自動化、用戶與權限都會一起搬。</div></div></div>
        <div class="tsteps">${STEP(1, '舊手機：下載資料檔', '在這一頁按「下載資料檔」，存到雲端硬碟或傳給自己')}${STEP(2, '新手機：安裝 App', '打開後到「更多 → 資料轉移」')}${STEP(3, '新手機：上傳資料檔', '確認內容後匯入，後台會自動重啟')}</div></div>
      <div class="card"><h3 style="margin-top:0">${LA.icon('download')} 下載這台的資料</h3>
        <div class="small mute" style="margin-bottom:8px">目前 ${esc(s.size)}・${s.counts.users} 位用戶・${s.counts.ledger} 筆記帳・${s.counts.memories} 則記憶・${s.counts.chats} 段對話</div>
        <div class="list small">${s.parts.slice(0, 8).map((p) => `<div class="row"><span class="grow">${esc(PART[p.name] || p.name)}</span><span class="mute">${esc(p.size)}</span></div>`).join('')}</div>
        <label class="chk"><input type="checkbox" id="x-media" checked> 包含對話裡的照片</label>
        <label class="chk"><input type="checkbox" id="x-ws" checked> 包含工作區檔案（AI 做的檔案、試算表）</label>
        <label class="f">保護密碼（選填）</label><input id="x-pw" type="password" autocomplete="new-password" placeholder="填了才會帶走 API 金鑰、Bot token、帳密">
        <div class="hint">不填：金鑰和帳密完全不會放進檔案，新手機要重新貼金鑰、重新登入。填了：用這組密碼加密（AES-256），匯入時要輸入同一組。請別把檔案和密碼一起傳。</div>
        <div class="row" style="justify-content:flex-end;margin-top:10px"><button class="btn pri" id="x-go">下載資料檔</button></div></div>
      <div class="card"><h3 style="margin-top:0">${LA.icon('upload')} 從舊手機匯入</h3>
        <div class="hint" style="margin-top:0">會取代這台目前的資料（匯入前自動備份到「備份」資料夾）。這台的內建 Linux 與 Termux 設定會保留。</div>
        <input type="file" id="i-file" accept=".json,application/json" hidden>
        <div class="row" style="justify-content:flex-end;margin-top:10px"><button class="btn" id="i-pick">選擇資料檔</button></div><div id="i-out"></div></div>`;
    $('#x-go').onclick = async (e) => {
      const b = e.currentTarget; const pw = $('#x-pw').value;
      if (pw && pw.length < 6) return LA.toast('密碼至少 6 個字', true);
      b.disabled = true; b.textContent = '整理中…';
      try {
        const r = await LA.post('/api/transfer/export', { password: pw, media: $('#x-media').checked, workspace: $('#x-ws').checked });
        b.textContent = `下載中（${r.size_text}）…`; await LA.download(`/api/transfer/file/${r.id}?name=${encodeURIComponent(r.name)}`, r.name);
        LA.modal(`<h3 style="margin-top:0">${LA.icon('check')} 資料檔已下載</h3><p>${esc(r.name)}（${esc(r.size_text)}）</p><p class="small mute">在「下載」資料夾。${r.secrets ? '含加密的金鑰，匯入時要輸入剛剛的密碼。' : '不含金鑰與帳密。'}</p><p class="small mute">把它傳到新手機，打開 App →「更多 → 資料轉移」→「選擇資料檔」。</p><div class="row" style="justify-content:flex-end"><button class="btn pri" onclick="LA.closeModal()">好</button></div>`);
      } catch (err) { LA.toast(err.message, true); } finally { b.disabled = false; b.textContent = "下載資料檔"; }
    };
    $('#i-pick').onclick = () => $('#i-file').click();
    $('#i-file').onchange = async (e) => {
      const f = e.target.files[0]; e.target.value = ''; if (!f) return; const out = $('#i-out');
      out.innerHTML = `<div class="small mute" style="margin-top:8px">上傳中（${Math.max(1, Math.round(f.size / 1024))} KB）…</div>`;
      try {
        const r = await fetch('/api/transfer/upload', { method: 'POST', headers: { authorization: 'Bearer ' + LA.token, 'content-type': 'application/octet-stream' }, body: f });
        const p = await r.json(); if (!r.ok) throw new Error(p.error || '上傳失敗');
        const c = p.summary && p.summary.counts;
        out.innerHTML = `<div class="tprev"><b>確認要匯入這份資料？</b>
          <div class="small">來源版本 ${esc(p.app_version || '?')}・${esc(new Date(p.created).toLocaleString('zh-TW', { hour12: false }))}</div>
          <div class="small">${c ? `${c.users} 位用戶・${c.ledger} 筆記帳・${c.memories} 則記憶・` : ''}${p.chats} 段對話・${p.media} 張照片・${p.workspace} 個工作區檔案</div>
          ${p.has_secrets ? `<label class="f">金鑰保護密碼</label><input id="i-pw" type="password" placeholder="舊手機下載時設的密碼（不填＝不匯入金鑰）"><div class="hint">不填密碼也可以匯入，金鑰會沿用這台原本的。</div>` : '<div class="hint">這份檔案不含金鑰，匯入後這台原本的金鑰會保留。</div>'}
          <div class="row" style="justify-content:flex-end;gap:8px;margin-top:10px"><button class="btn" id="i-no">取消</button><button class="btn pri" id="i-yes">匯入並重新啟動</button></div></div>`;
        $('#i-no').onclick = () => { out.innerHTML = ''; };
        $('#i-yes').onclick = async (ev) => {
          const btn = ev.currentTarget; const pw = ($('#i-pw') || {}).value || ''; if (!(await LA.confirm('匯入會取代這台目前的資料（會先自動備份），完成後後台重新啟動。確定？'))) return;
          btn.disabled = true; btn.textContent = '匯入中…';
          try {
            const d = await LA.post('/api/transfer/import', { id: p.id, password: pw, confirm: true });
            out.innerHTML = `<div class="tprev"><b>${LA.icon('check')} 匯入完成（${d.files} 個檔案${d.secrets ? '，含金鑰' : ''}）</b><div class="small mute">後台重新啟動中，畫面會自動重新整理。${d.secrets_skipped ? '金鑰沒有匯入（沒填密碼），沿用這台原本的。' : ''}</div></div>`;
            const t0 = Date.now(); await new Promise((ok) => setTimeout(ok, 2500));
            (async function wait() { try { const r2 = await fetch('/api/status', { headers: { authorization: 'Bearer ' + LA.token } }); if (r2.ok) return location.reload(); } catch { /* 還在重啟 */ } if (Date.now() - t0 < 90000) setTimeout(wait, 1200); else location.reload(); })();
          } catch (err) { LA.toast(err.message, true); btn.disabled = false; btn.textContent = '匯入並重新啟動'; }
        };
      } catch (err) { out.innerHTML = `<div class="tprev bad">${esc(err.message)}</div>`; }
    };
  } });
  const PART = { 'db.json': '資料庫（用戶、記帳、排程、權限…）', 'vectors.json': '長期記憶', 'settings.json': '設定（不含金鑰）', messages: '對話紀錄', chatmedia: '對話照片', workspace: '工作區檔案', skills: '技能', workers: '背景工人', diary: '系統日記', news: '新聞摘要', home: 'AI 的家目錄', '金鑰與授權': '金鑰與授權（要設密碼才會帶）' };
})();
