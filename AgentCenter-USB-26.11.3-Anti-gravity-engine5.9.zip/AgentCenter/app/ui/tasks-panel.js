'use strict';
/*
 * 26.11.3 pro8 對話頁上方的「排程」下拉面板
 *  ・平常是一條細長條：排程幾個、長期任務幾個、下一個是什麼時候
 *  ・點一下（或往下拉）展開：「排程」＝只跑一次的提醒；「長期任務」＝會重複的（每天、每週一、四、每月…）＋ App 自己的每日工作
 *  ・每個項目可以暫停／恢復（長期任務）、改時間或內容、取消；也可以直接新增
 *  ・和 AI 的 schedule_task／list_tasks／update_task／cancel_task 是同一份資料
 */
(function () {
  const { esc } = LA; const $ = (s, r = document) => r.querySelector(s);
  const WD = ['日', '一', '二', '三', '四', '五', '六'];
  let data = null; let open = false; let tab = 'once'; let host = null; let timer = null; let failed = false;
  const remember = () => { try { localStorage.setItem('la_tp_tab', tab); } catch { /* ignore */ } };
  try { tab = localStorage.getItem('la_tp_tab') || 'once'; } catch { /* ignore */ }

  async function load() { try { data = await LA.api('/api/tasks'); failed = false; } catch { data = null; failed = true; } }
  const next = () => { if (!data) return null; const all = [...data.once, ...data.recurring].filter((x) => x.status === 'pending').sort((a, b) => a.run_at - b.run_at); return all[0] || null; };
  function strip() {
    if (!data) return ''; const n1 = data.once.length, n2 = data.recurring.length; const nx = next();
    return `<button class="tp-strip ${open ? 'on' : ''}" id="tp-toggle" aria-expanded="${open}">
      <span class="tp-ic">${LA.icon('calendar', 'sm')}</span>
      <span class="tp-sum"><b>排程 ${n1}</b><i></i><b>長期 ${n2}</b></span>
      <span class="tp-next">${nx ? `下一個 <em>${esc(nx.when)}</em> ${esc(nx.instruction)}` : '沒有待辦的排程，點這裡新增'}</span>
      <span class="tp-car">${LA.icon('next', 'sm')}</span></button>`;
  }
  function item(x) {
    const paused = x.status === 'paused';
    return `<div class="tp-item ${paused ? 'paused' : ''}" data-tid="${x.id}">
      <div class="tp-when"><b>${esc(x.kind === 'recurring' ? x.repeat_text : x.when)}</b><small>${paused ? '已暫停' : x.kind === 'recurring' ? `下次 ${esc(x.when)}・${esc(x.left)}` : esc(x.left)}</small></div>
      <div class="tp-body"><div class="tp-txt">${esc(x.instruction)}</div><div class="tp-meta">#${x.id}${x.owner ? '・' + esc(x.owner) : ''}${x.target ? '・' + esc(x.target) : ''}${x.runs ? `・已執行 ${x.runs} 次（上次 ${esc(x.last_text)}）` : ''}</div></div>
      <div class="tp-act">${x.kind === 'recurring' ? `<button class="ico" data-tact="${paused ? 'resume' : 'pause'}" title="${paused ? '恢復' : '暫停'}">${LA.icon(paused ? 'play' : 'pause', 'sm')}</button>` : ''}<button class="ico" data-tact="edit" title="修改">${LA.icon('edit', 'sm')}</button><button class="ico" data-tact="cancel" title="取消">${LA.icon('trash', 'sm')}</button></div></div>`;
  }
  function panel() {
    if (!data) return ''; const list = tab === 'once' ? data.once : data.recurring;
    return `<div class="tp-panel" id="tp-panel">
      <div class="tp-tabs"><button class="${tab === 'once' ? 'on' : ''}" data-tk="once">排程<span>${data.once.length}</span></button><button class="${tab === 'rec' ? 'on' : ''}" data-tk="rec">長期任務<span>${data.recurring.length}</span></button><span class="grow"></span><button class="btn sm pri" id="tp-add">${LA.icon('plus', 'sm')} 新增</button></div>
      <div class="tp-hint">${tab === 'once' ? '只會執行一次的提醒，時間到 AI 會做完並傳訊息給你。' : '會重複的工作：每天、每週幾（可以一週好幾天）、每月、每 N 天。可以暫停。'}</div>
      <div class="tp-list">${list.length ? list.map(item).join('') : `<div class="tp-empty">${LA.icon(tab === 'once' ? 'clock' : 'refresh')}<div>${tab === 'once' ? '沒有排程' : '沒有長期任務'}</div><small>可以按「新增」，或直接跟 AI 說：「${tab === 'once' ? '明天早上 8 點提醒我帶便當' : '每週一、四晚上 8 點提醒我倒垃圾'}」</small></div>`}</div>
      ${tab === 'rec' && data.system && data.system.length ? `<div class="tp-sys"><div class="tp-sysh">App 每天自動做的事</div>${data.system.map((s) => `<label class="tp-srow"><span class="grow"><b>${esc(s.name)}</b><small>${esc(s.repeat_text)}</small></span><span class="sw"><input type="checkbox" data-sys="${esc(s.key)}" ${s.enabled ? 'checked' : ''}><i></i></span></label>`).join('')}<button class="linkbtn small" data-go="auto">更多設定</button></div>` : ''}
      <button class="tp-close" id="tp-close">${LA.icon('up', 'sm')} 收起</button></div>`;
  }
  function paint() {
    if (!host || !host.isConnected) return; if (failed || !data) { host.hidden = true; return; } host.hidden = false;
    host.innerHTML = strip() + (open ? panel() : ''); host.classList.toggle('open', open);
  }
  /** 新增／修改表單 */
  function form(x) {
    const now = new Date(Date.now() + 3600e3); const pad = (n) => String(n).padStart(2, '0');
    const local = (ts) => { const d = new Date(ts); return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`; };
    const rep = x ? x.repeat : tab === 'rec' ? 'weekly' : 'none'; const days = x && x.days ? x.days : [new Date(x ? x.run_at : now).getDay()];
    return new Promise((resolve) => {
      const s = LA.modal(`<h3 style="margin-top:0">${x ? '修改 #' + x.id : '新增' + (tab === 'rec' ? '長期任務' : '排程')}</h3>
        <label class="f">要做什麼（AI 到時候會照做並傳訊息給你）</label><textarea id="tf-txt" rows="3" maxlength="1000" placeholder="例：提醒我倒垃圾／整理今天台股收盤給我">${esc(x ? x.instruction : '')}</textarea>
        <label class="f">${rep === 'none' ? '時間' : '第一次（之後照重複規則）'}</label><input id="tf-at" type="datetime-local" value="${local(x ? x.run_at : now.setMinutes(0, 0, 0))}">
        <label class="f">重複</label><div class="seg tf-rep">${[['none', '不重複'], ['daily', '每天'], ['weekly', '每週'], ['monthly', '每月'], ['every', '每 N 天'], ['hourly', '每小時']].map(([k, n]) => `<button data-rep="${k}" class="${k === rep ? 'on' : ''}">${n}</button>`).join('')}</div>
        <div id="tf-days" class="tf-days" ${rep === 'weekly' ? '' : 'hidden'}>${[1, 2, 3, 4, 5, 6, 0].map((d) => `<button data-day="${d}" class="${days.includes(d) ? 'on' : ''}">${WD[d]}</button>`).join('')}<span class="mute small">可以選好幾天（例：一、四＝一週兩次）</span></div>
        <div id="tf-every" ${rep === 'every' ? '' : 'hidden'} class="row"><span>每</span><input id="tf-n" type="number" min="1" max="365" value="${(x && x.every) || 2}" style="width:6em"><span>天一次</span></div>
        <div id="tf-err" class="hint err" hidden></div>
        <div class="row" style="justify-content:flex-end;margin-top:14px"><button class="btn" id="tf-no">取消</button><button class="btn pri" id="tf-ok">${x ? '儲存' : '建立'}</button></div>`);
      const root = s || document; let r = rep;
      root.querySelector('.tf-rep').onclick = (e) => { const b = e.target.closest('[data-rep]'); if (!b) return; r = b.dataset.rep; root.querySelectorAll('[data-rep]').forEach((y) => y.classList.toggle('on', y === b)); root.querySelector('#tf-days').hidden = r !== 'weekly'; root.querySelector('#tf-every').hidden = r !== 'every'; };
      root.querySelector('#tf-days').onclick = (e) => { const b = e.target.closest('[data-day]'); if (b) b.classList.toggle('on'); };
      root.querySelector('#tf-no').onclick = () => { LA.closeModal(); resolve(null); };
      root.querySelector('#tf-ok').onclick = async () => {
        const err = root.querySelector('#tf-err'); err.hidden = true; const at = root.querySelector('#tf-at').value.replace('T', ' ');
        const body = { instruction: root.querySelector('#tf-txt').value.trim(), at, repeat: r };
        if (r === 'weekly') { const d = [...root.querySelectorAll('[data-day].on')].map((b) => +b.dataset.day); if (!d.length) { err.hidden = false; err.textContent = '至少選一天'; return; } body.days = d.join(','); } else if (x) body.days = null;
        if (r === 'every') body.every = +root.querySelector('#tf-n').value || 1;
        if (!body.instruction) { err.hidden = false; err.textContent = '請寫要做什麼'; return; }
        try { const v = x ? await LA.post(`/api/tasks/${x.id}`, { action: 'edit', ...body }) : await LA.post('/api/tasks', body); LA.closeModal(); resolve(v); } catch (e) { err.hidden = false; err.textContent = e.message; }
      };
    });
  }
  async function onClick(e) {
    const t = e.target;
    if (t.closest('#tp-toggle')) { open = !open; if (open) await load(); paint(); return true; }
    if (t.closest('#tp-close')) { open = false; paint(); return true; }
    const tk = t.closest('[data-tk]'); if (tk) { tab = tk.dataset.tk; remember(); paint(); return true; }
    if (t.closest('#tp-add')) { const v = await form(null); if (v) { tab = v.kind === 'recurring' ? 'rec' : 'once'; remember(); await load(); paint(); LA.toast(`已建立 #${v.id}：${v.kind === 'recurring' ? v.repeat_text : v.when}`); } return true; }
    const a = t.closest('[data-tact]'); if (a) {
      const id = +a.closest('[data-tid]').dataset.tid; const x = [...data.once, ...data.recurring].find((y) => y.id === id); const act = a.dataset.tact;
      if (act === 'edit') { const v = await form(x); if (v) { await load(); paint(); LA.toast('已儲存'); } return true; }
      if (act === 'cancel' && !(await LA.confirm(`取消 #${id}「${x.instruction.slice(0, 30)}」？`))) return true;
      await LA.post(`/api/tasks/${id}`, { action: act }); await load(); paint(); LA.toast({ cancel: '已取消', pause: '已暫停', resume: '已恢復' }[act]); return true;
    }
    return false;
  }
  async function onChange(e) { const k = e.target.dataset && e.target.dataset.sys; if (!k) return false; try { data = await LA.post('/api/tasks/system', { key: k, enabled: e.target.checked }); LA.toast(e.target.checked ? '已開啟' : '已關閉'); } catch (er) { LA.toast(er.message, true); e.target.checked = !e.target.checked; } paint(); return true; }
  /** 往下拉長條也能展開（手機） */
  function bindPull(el) { let y0 = null; el.addEventListener('touchstart', (e) => { if (e.target.closest('#tp-toggle')) y0 = e.touches[0].clientY; }, { passive: true }); el.addEventListener('touchmove', (e) => { if (y0 != null && !open && e.touches[0].clientY - y0 > 28) { y0 = null; open = true; load().then(paint); } }, { passive: true }); el.addEventListener('touchend', () => { y0 = null; }, { passive: true }); }

  LA.taskPanel = {
    async mount(el) { host = el; bindPull(el); el.onclick = LA.guard(onClick); el.onchange = LA.guard(onChange); await load(); paint(); clearInterval(timer); timer = setInterval(async () => { if (!host || !host.isConnected) return clearInterval(timer); if (document.hidden) return; await load(); paint(); }, 30000); },
    refresh: async () => { await load(); paint(); },
    close() { open = false; paint(); },
  };
})();
