'use strict';
/*
 * engine5.7：QR Code 產生器（不用外部程式庫、離線可用）
 *   ・位元組模式（UTF-8）、錯誤修正等級 M、版本 1～15 自動選（最多約 410 個英數字，網址夠用）
 *   ・自動挑最好的遮罩（標準的 4 條扣分規則）
 *   用法：QR.matrix(文字) → 二維陣列（true＝黑）；QR.svg(文字, { size, margin, dark, light }) → SVG 字串
 */
(function (root) {
  // 等級 M：[總碼字數, 每塊錯誤修正碼字數, [[塊數, 每塊資料碼字數], ...]]
  const M = [null,
    [26, 10, [[1, 16]]], [44, 16, [[1, 28]]], [70, 26, [[1, 44]]], [100, 18, [[2, 32]]], [134, 24, [[2, 43]]],
    [172, 16, [[4, 27]]], [196, 18, [[4, 31]]], [242, 22, [[2, 38], [2, 39]]], [292, 22, [[3, 36], [2, 37]]], [346, 26, [[4, 43], [1, 44]]],
    [404, 30, [[1, 50], [4, 51]]], [466, 22, [[6, 36], [2, 37]]], [532, 22, [[8, 37], [1, 38]]], [581, 24, [[4, 40], [5, 41]]], [655, 24, [[5, 41], [5, 42]]]];
  const ALIGN = [null, [], [6, 18], [6, 22], [6, 26], [6, 30], [6, 34], [6, 22, 38], [6, 24, 42], [6, 26, 46], [6, 28, 50], [6, 30, 54], [6, 32, 58], [6, 34, 62], [6, 26, 46, 66], [6, 26, 48, 70]];
  const REMAIN = [0, 0, 7, 7, 7, 7, 7, 0, 0, 0, 0, 0, 0, 0, 3, 3];

  // ---- GF(256)（多項式 0x11D）與 Reed-Solomon ----
  const EXP = new Array(512), LOG = new Array(256);
  for (let i = 0, x = 1; i < 255; i++) { EXP[i] = x; LOG[x] = i; x <<= 1; if (x & 0x100) x ^= 0x11d; }
  for (let i = 255; i < 512; i++) EXP[i] = EXP[i - 255];
  const mul = (a, b) => (a && b ? EXP[LOG[a] + LOG[b]] : 0);
  function rsGen(n) { let g = [1]; for (let i = 0; i < n; i++) { const ng = new Array(g.length + 1).fill(0); for (let j = 0; j < g.length; j++) { ng[j] ^= g[j]; ng[j + 1] ^= mul(g[j], EXP[i]); } g = ng; } return g; }
  function rsRem(data, n) { const g = rsGen(n); const r = data.concat(new Array(n).fill(0)); for (let i = 0; i < data.length; i++) { const c = r[i]; if (c) for (let j = 0; j < g.length; j++) r[i + j] ^= mul(g[j], c); } return r.slice(data.length); }

  function utf8(s) { const out = []; for (const ch of String(s)) { let c = ch.codePointAt(0); if (c < 0x80) out.push(c); else if (c < 0x800) out.push(0xc0 | c >> 6, 0x80 | c & 63); else if (c < 0x10000) out.push(0xe0 | c >> 12, 0x80 | c >> 6 & 63, 0x80 | c & 63); else out.push(0xf0 | c >> 18, 0x80 | c >> 12 & 63, 0x80 | c >> 6 & 63, 0x80 | c & 63); } return out; }
  const dataCap = (v) => M[v][2].reduce((a, [n, d]) => a + n * d, 0);

  /** 把文字編成這個版本的全部碼字（資料＋錯誤修正，已交錯） */
  function codewords(bytes, v) {
    const cap = dataCap(v); const bits = []; const put = (val, n) => { for (let i = n - 1; i >= 0; i--) bits.push((val >> i) & 1); };
    put(4, 4); put(bytes.length, v < 10 ? 8 : 16); for (const b of bytes) put(b, 8);
    for (let i = 0; i < 4 && bits.length < cap * 8; i++) bits.push(0);
    while (bits.length % 8) bits.push(0);
    const data = []; for (let i = 0; i < bits.length; i += 8) { let b = 0; for (let j = 0; j < 8; j++) b = b << 1 | bits[i + j]; data.push(b); }
    for (let p = 0; data.length < cap; p++) data.push(p % 2 ? 0x11 : 0xec);
    const blocks = []; let k = 0; for (const [n, d] of M[v][2]) for (let i = 0; i < n; i++) { blocks.push(data.slice(k, k + d)); k += d; }
    const ecs = blocks.map((b) => rsRem(b, M[v][1]));
    const out = []; const maxD = Math.max(...blocks.map((b) => b.length));
    for (let i = 0; i < maxD; i++) for (const b of blocks) if (i < b.length) out.push(b[i]);
    for (let i = 0; i < M[v][1]; i++) for (const e of ecs) out.push(e[i]);
    return out;
  }

  function bch(val, poly, bitsPoly) { let v = val << (bitsPoly - 1); const deg = (x) => 31 - Math.clz32(x); while (deg(v) >= bitsPoly - 1) v ^= poly << (deg(v) - (bitsPoly - 1)); return v; }
  const MASKS = [(r, c) => (r + c) % 2 === 0, (r) => r % 2 === 0, (r, c) => c % 3 === 0, (r, c) => (r + c) % 3 === 0, (r, c) => (Math.floor(r / 2) + Math.floor(c / 3)) % 2 === 0,
    (r, c) => (r * c) % 2 + (r * c) % 3 === 0, (r, c) => ((r * c) % 2 + (r * c) % 3) % 2 === 0, (r, c) => ((r + c) % 2 + (r * c) % 3) % 2 === 0];

  function build(v, cw, mask) {
    const n = 17 + 4 * v; const m = Array.from({ length: n }, () => new Array(n).fill(false)); const fn = Array.from({ length: n }, () => new Array(n).fill(false));
    const set = (r, c, val) => { m[r][c] = val; fn[r][c] = true; };
    const finder = (r0, c0) => { for (let r = -1; r <= 7; r++) for (let c = -1; c <= 7; c++) { const rr = r0 + r, cc = c0 + c; if (rr < 0 || cc < 0 || rr >= n || cc >= n) continue; const on = r >= 0 && r <= 6 && c >= 0 && c <= 6 && (r === 0 || r === 6 || c === 0 || c === 6 || (r >= 2 && r <= 4 && c >= 2 && c <= 4)); set(rr, cc, on); } };
    finder(0, 0); finder(0, n - 7); finder(n - 7, 0);
    for (let i = 8; i < n - 8; i++) { set(6, i, i % 2 === 0); set(i, 6, i % 2 === 0); }
    const al = ALIGN[v]; const L = al.length - 1; al.forEach((r, i) => al.forEach((c, j) => { if ((i === 0 && j === 0) || (i === 0 && j === L) || (i === L && j === 0)) return;   /* 三個角跟定位圖案重疊，不放 */ for (let dr = -2; dr <= 2; dr++) for (let dc = -2; dc <= 2; dc++) set(r + dr, c + dc, Math.max(Math.abs(dr), Math.abs(dc)) !== 1); }));
    // 保留格式區、版本區
    for (let i = 0; i < 9; i++) { if (!fn[8][i]) set(8, i, false); if (!fn[i][8]) set(i, 8, false); }
    for (let i = 0; i < 8; i++) { set(8, n - 1 - i, false); set(n - 1 - i, 8, false); }
    set(n - 8, 8, true);   // 暗模組
    if (v >= 7) { const vb = (v << 12) | bch(v, 0x1f25, 13); for (let i = 0; i < 18; i++) { const bit = !!((vb >> i) & 1); const a = Math.floor(i / 3), b = n - 11 + (i % 3); set(a, b, bit); set(b, a, bit); } }
    // 放資料（右下開始之字形，跳過第 6 欄）
    const bits = []; for (const c of cw) for (let i = 7; i >= 0; i--) bits.push((c >> i) & 1); for (let i = 0; i < REMAIN[v]; i++) bits.push(0);
    let k = 0, up = true;
    for (let col = n - 1; col > 0; col -= 2) {
      if (col === 6) col = 5;
      for (let i = 0; i < n; i++) { const r = up ? n - 1 - i : i; for (const c of [col, col - 1]) { if (fn[r][c]) continue; const b = k < bits.length ? bits[k++] : 0; m[r][c] = !!b !== MASKS[mask](r, c); } }
      up = !up;
    }
    // 格式資訊（等級 M＝00）
    const fmt = (((0 << 3) | mask) << 10 | bch((0 << 3) | mask, 0x537, 11)) ^ 0x5412;
    const fb = (i) => !!((fmt >> i) & 1);
    for (let i = 0; i <= 5; i++) m[i][8] = fb(i);          // 第一份：左上，沿第 8 欄往下……
    m[7][8] = fb(6); m[8][8] = fb(7); m[8][7] = fb(8);
    for (let i = 9; i < 15; i++) m[8][14 - i] = fb(i);     // ……再沿第 8 列往左
    for (let i = 0; i < 8; i++) m[8][n - 1 - i] = fb(i);   // 第二份：右上第 8 列
    for (let i = 8; i < 15; i++) m[n - 15 + i][8] = fb(i); // 左下第 8 欄
    return m;
  }

  function penalty(m) {
    const n = m.length; let p = 0;
    for (let t = 0; t < 2; t++) for (let i = 0; i < n; i++) { let run = 1; for (let j = 1; j < n; j++) { const a = t ? m[j][i] : m[i][j], b = t ? m[j - 1][i] : m[i][j - 1]; if (a === b) { run++; if (run === 5) p += 3; else if (run > 5) p++; } else run = 1; } }
    for (let i = 0; i < n - 1; i++) for (let j = 0; j < n - 1; j++) { const c = m[i][j]; if (c === m[i + 1][j] && c === m[i][j + 1] && c === m[i + 1][j + 1]) p += 3; }
    const pat1 = [1, 0, 1, 1, 1, 0, 1, 0, 0, 0, 0], pat2 = [0, 0, 0, 0, 1, 0, 1, 1, 1, 0, 1];
    for (let i = 0; i < n; i++) for (let j = 0; j <= n - 11; j++) for (const pat of [pat1, pat2]) { let h = true, vv = true; for (let k = 0; k < 11; k++) { if (+m[i][j + k] !== pat[k]) h = false; if (+m[j + k][i] !== pat[k]) vv = false; } if (h) p += 40; if (vv) p += 40; }
    let dark = 0; for (const row of m) for (const c of row) if (c) dark++; p += Math.floor(Math.abs(dark * 20 - n * n * 10) / (n * n)) * 10;
    return p;
  }

  function matrix(text) {
    const bytes = utf8(text); let v = 1;
    while (v <= 15 && bytes.length + Math.ceil((4 + (v < 10 ? 8 : 16)) / 8) > dataCap(v)) v++;
    if (v > 15) throw new Error('文字太長，QR Code 放不下');
    const cw = codewords(bytes, v); let best = null, bestP = Infinity;
    for (let mask = 0; mask < 8; mask++) { const m = build(v, cw, mask); const p = penalty(m); if (p < bestP) { bestP = p; best = m; } }
    return best;
  }
  function svg(text, { size = 220, margin = 4, dark = '#000', light = '#fff' } = {}) {
    const m = matrix(text); const n = m.length + margin * 2; let d = '';
    for (let r = 0; r < m.length; r++) for (let c = 0; c < m.length; c++) if (m[r][c]) d += `M${c + margin} ${r + margin}h1v1h-1z`;
    return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${n} ${n}" width="${size}" height="${size}" shape-rendering="crispEdges" role="img" aria-label="QR Code"><rect width="${n}" height="${n}" fill="${light}"/><path d="${d}" fill="${dark}"/></svg>`;
  }
  const QR = { matrix, svg };
  if (typeof module !== 'undefined' && module.exports) module.exports = QR; else root.QR = QR;
})(typeof window !== 'undefined' ? window : this);
