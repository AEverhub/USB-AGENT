'use strict';
/* 服務頁：服務按鈕（可自訂）＋自動化入口。按鈕的結果會出現在「對話」頁。也提供 LA.pickPhoto／LA.scanQr 給其他頁用。 */
(function () {
  const { esc, $ } = LA;
  let tiles = []; let editing = false;

  // ---------- 拍照／掃碼 ----------
  /** 選或拍一張照片 → 縮到最長邊 1600、JPEG，回傳 {mime,data} */
  LA.pickPhoto = () => new Promise((resolve, reject) => {
    const i = document.createElement('input'); i.type = 'file'; i.accept = 'image/*'; i.setAttribute('capture', 'environment');
    i.onchange = () => { const f = i.files && i.files[0]; if (!f) return reject(new Error('沒有選照片')); const fr = new FileReader();
      fr.onload = () => { const img = new Image(); img.onload = () => { const k = Math.min(1, 1600 / Math.max(img.width, img.height)); const c = document.createElement('canvas'); c.width = Math.round(img.width * k); c.height = Math.round(img.height * k); c.getContext('2d').drawImage(img, 0, 0, c.width, c.height); resolve({ mime: 'image/jpeg', data: c.toDataURL('image/jpeg', 0.85).split(',')[1], preview: c.toDataURL('image/jpeg', 0.5) }); }; img.onerror = () => reject(new Error('讀不了這張照片')); img.src = fr.result; };
      fr.onerror = () => reject(new Error('讀不了這張照片')); fr.readAsDataURL(f); };
    i.click();
  });
  /** 掃 QR：App 內用 Google 掃碼器；瀏覽器用 BarcodeDetector；都不行就讓使用者貼上文字 */
  LA.scanQr = () => new Promise((resolve, reject) => {
    if (window.AndroidBridge && AndroidBridge.scanQr) { window.LA_onScan = (text, err) => { window.LA_onScan = null; if (text) resolve(text); else reject(new Error(err === 'cancel' ? '已取消掃描' : err || '掃描失敗')); }; AndroidBridge.scanQr(); return; }
    if ('BarcodeDetector' in window && navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
      const s = LA.modal('<h3 style="margin-top:0">對準 QR Code</h3><video id="qv" playsinline muted style="width:100%;border-radius:12px;background:#000"></video><div class="row" style="justify-content:flex-end;margin-top:10px"><button class="btn" id="qx">取消</button></div>');
      let stream = null; let done = false; const stop = () => { done = true; try { stream && stream.getTracks().forEach((t) => t.stop()); } catch { /* ignore */ } LA.closeModal(); };
      $('#qx', s).onclick = () => { stop(); reject(new Error('已取消掃描')); };
      navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } }).then(async (st) => { stream = st; const v = $('#qv', s); v.srcObject = st; await v.play(); const det = new window.BarcodeDetector({ formats: ['qr_code'] });
        const loop = async () => { if (done) return; try { const r = await det.detect(v); if (r.length) { stop(); return resolve(r[0].rawValue); } } catch { /* 下一格 */ } setTimeout(loop, 250); }; loop(); })
        .catch(() => { stop(); LA.ask('相機無法使用。可以把 QR Code 的文字貼在這裡：', '', { multiline: true }).then((t) => (t ? resolve(t.trim()) : reject(new Error('已取消')))); });
      return;
    }
    LA.ask('這個環境不能掃描。請貼上 QR Code 的文字：', '', { multiline: true }).then((t) => (t ? resolve(t.trim()) : reject(new Error('已取消'))));
  });

  // ---------- 畫面 ----------
  function grid() {
    return `<div class="sgrid">${tiles.map((t, i) => `<button class="stile" data-tile="${esc(t.id)}"><span class="si">${LA.icon(LA.tileIcon(t.icon))}</span><b>${esc(t.name)}</b>${t.desc ? `<small>${esc(t.desc)}</small>` : ''}${editing ? `<span class="sedit"><i data-up="${i}" title="往前">${LA.icon('up')}</i><i data-ed="${i}" title="修改">${LA.icon('edit')}</i><i data-del="${i}" title="刪除">${LA.icon('trash')}</i></span>` : ''}</button>`).join('')}
      ${editing ? `<button class="stile add" id="s-add"><span class="si">${LA.icon('plus')}</span><b>新增服務</b><small>寫好要 AI 做的事</small></button>` : ''}</div>`;
  }
  function paint(main) {
    main.innerHTML = `<div class="phead"><div><h2>服務</h2><p>點一下就交給 AI；按「編輯」可以自己加按鈕，寫好要它做的事。</p></div><button class="btn sm" id="h-edit">${editing ? '完成' : '編輯'}</button></div>
      ${editing ? '<div class="row" style="margin-bottom:10px"><button class="btn sm" id="h-reset">還原預設</button><span class="hint">↑ 調整順序（對話頁上方會顯示前 8 個）</span></div>' : ''}
      ${grid()}
      <div class="phead" style="margin-top:20px"><div><h2>自動幫你做</h2><p>每天簡報、監控網頁、語音轉文字、手機能力</p></div><button class="btn sm" data-go="auto">設定</button></div>`;
  }
  /** 執行一個服務按鈕：收集需要的輸入 → 交給對話頁送出（結果出現在對話裡） */
  /** 口述記帳：按下去就開始聽，講完自動停，辨識出來的話交給 AI 記帳 */
  async function voiceTile(def) {
    if (!LA.voice) throw new Error('語音功能沒有載入'); await LA.voice.load().catch(() => null);
    let ctl = null; const m = LA.modal(`<div class="vt"><div class="vt-orb" id="vt-orb">${LA.icon('mic')}</div><b>${esc(def.name)}</b><div class="mute small" id="vt-st">請說，例如「午餐 120、搭計程車 250」</div><div id="vt-txt" class="vt-txt"></div><div class="row" style="justify-content:center;margin-top:12px"><button class="btn" id="vt-x">取消</button><button class="btn pri" id="vt-stop">說完了</button></div></div>`);
    const root = m || document; const orb = root.querySelector('#vt-orb');
    root.querySelector('#vt-x').onclick = () => { if (ctl) ctl.cancel(); LA.closeModal(); };
    root.querySelector('#vt-stop').onclick = () => { if (ctl) ctl.stop(); };
    ctl = LA.voice.listen({ silenceMs: 1500, waitMs: 10000, onLevel: (lv) => orb.style.setProperty('--lv', lv.toFixed(2)), onPartial: (t) => { root.querySelector('#vt-txt').textContent = t; }, onStage: () => { root.querySelector('#vt-st').textContent = '辨識中…'; } });
    let text = ''; try { text = (await ctl.done).trim(); } catch (e) { LA.closeModal(); throw e; }
    LA.closeModal(); if (!text) return LA.toast('沒有聽到內容，再按一次試試');
    return LA.chatSend({ id: def.id, text }, `${def.name}：${text}`);
  }
  /** 連結其他帳號：產生驗證碼，到 LINE／Discord／Telegram 私訊機器人「驗證碼 123456」 */
  async function linkAccount(def) {
    const r = await LA.post('/api/services/run', { id: def.id }); const names = { line: 'LINE', discord: 'Discord', telegram: 'Telegram' };
    LA.modal(`<h3 style="margin-top:0">${LA.icon('link')} 連結其他帳號</h3><p>到要連結的平台私訊機器人，傳這句話：</p><div class="vt-code" id="lk-code">驗證碼 ${esc(r.code)}</div>
      <div class="row" style="justify-content:center"><button class="btn pri" id="lk-copy">${LA.icon('copy', 'sm')} 複製</button></div>
      <ul class="small"><li>10 分鐘內有效，用一次就失效。</li><li>可以連的平台：${r.platforms && r.platforms.length ? r.platforms.map((p) => names[p]).join('、') : '目前沒有開啟的平台（設定 → 平台）'}</li><li>連結後兩邊是同一個人：共用記憶、記帳、提醒和權限。</li></ul>
      <div class="row" style="justify-content:flex-end"><button class="btn" onclick="LA.closeModal()">關閉</button></div>`, (mm) => { mm.querySelector('#lk-copy').onclick = () => { LA.copy('驗證碼 ' + r.code); LA.toast('已複製'); }; });
  }
  LA.runTile = async (def) => {
    if (!def) return;
    // 26.11.3 pro2：標籤不再顯示圖示的代號（以前會出現「pen 記一筆」）
    if (/^open:(logic|circuit|code|sites|video)$/.test(def.action || '')) return LA.go(def.action.slice(5));
    if (def.action === 'link') return linkAccount(def);
    if (def.input === 'voice') return voiceTile(def);
    if (def.input === 'qr') { const q = await LA.scanQr(); return LA.chatSend({ id: def.id, qr: [q] }, def.name); }
    if (def.input === 'photo') { const img = await LA.pickPhoto(); return LA.chatSend({ id: def.id, image: { mime: img.mime, data: img.data } }, def.name, img.preview); }
    if (def.input === 'text') { const v = await LA.ask(def.name, '', { hint: def.placeholder || def.desc || '' }); if (!v || !v.trim()) return; return LA.chatSend({ id: def.id, text: v.trim() }, `${def.name}：${v.trim()}`); }
    return LA.chatSend({ id: def.id }, def.name);
  };
  function editor(t, onSave) {
    t = t || { icon: 'spark', name: '', input: 'text', prompt: '', placeholder: '', desc: '' }; let icon = LA.tileIcon(t.icon);
    const s = LA.modal(`<h3 style="margin-top:0">${t.name ? '修改服務' : '新增服務'}</h3>
      <label class="f">名稱</label><input id="e-name" value="${esc(t.name)}" placeholder="例：訂明天的早餐">
      <label class="f">圖示</label><div class="icpick" id="e-icons">${LA.TILE_ICONS.map((n) => `<button type="button" data-ic="${n}" class="${n === icon ? 'on' : ''}">${LA.icon(n)}</button>`).join('')}</div>
      <label class="f">按下去要先</label><select id="e-input">${[['none', '直接執行'], ['text', '先打一句話'], ['photo', '先拍照／選圖'], ['qr', '先掃 QR Code']].map(([v, n]) => `<option value="${v}" ${t.input === v ? 'selected' : ''}>${n}</option>`).join('')}</select>
      ${t.action === 'einvoice' ? '<div class="hint">這是內建的電子發票記帳，不經 AI。</div>' : `<label class="f">要 AI 做的事（{input} 會換成你輸入的內容）</label><textarea id="e-prompt" placeholder="例：幫我在 Foodpanda 訂 {input}，送到家裡，付款前先問我">${esc(t.prompt || '')}</textarea>`}
      <label class="f">輸入框提示（選填）</label><input id="e-ph" value="${esc(t.placeholder || '')}">
      <label class="f">說明（選填）</label><input id="e-desc" value="${esc(t.desc || '')}">
      <div class="row" style="justify-content:flex-end;margin-top:12px"><button class="btn" id="e-no">取消</button><button class="btn pri" id="e-ok">儲存</button></div>`);
    $('#e-no', s).onclick = LA.closeModal;
    $('#e-icons', s).onclick = (ev) => { const b = ev.target.closest('[data-ic]'); if (!b) return; icon = b.dataset.ic; LA.$$('#e-icons button', s).forEach((x) => x.classList.toggle('on', x === b)); };
    $('#e-ok', s).onclick = LA.guard(async () => { const n = { ...t, icon, name: $('#e-name', s).value.trim(), input: $('#e-input', s).value, prompt: $('#e-prompt', s) ? $('#e-prompt', s).value.trim() : t.prompt, placeholder: $('#e-ph', s).value.trim(), desc: $('#e-desc', s).value.trim() }; if (!n.name) throw new Error('請輸入名稱'); if (!n.action && !n.prompt) throw new Error('請寫要 AI 做的事'); await onSave(n); LA.closeModal(); });
  }

  LA.register('services', { name: '服務', title: '服務（服務按鈕、自動化入口）', async render(main) {
    const sv = await LA.api('/api/services'); tiles = sv.items; paint(main);
    const save = async (list) => { const r = await LA.post('/api/services', { items: list }); tiles = r.items; paint(main); };
    main.onclick = LA.guard(async (e) => {
      const t = e.target;
      const g = t.closest('[data-go]'); if (g) return LA.go(g.dataset.go);
      if (t.closest('#h-edit')) { editing = !editing; return paint(main); }
      if (t.closest('#h-reset')) { if (await LA.confirm('還原成預設的服務按鈕？你自己加的會被刪除。')) { const r = await LA.post('/api/services/reset'); tiles = r.items; paint(main); } return; }
      if (t.closest('#s-add')) return editor(null, (n) => save([...tiles, n]));
      const up = t.closest('[data-up]'); if (up) { const i = +up.dataset.up; if (i > 0) { const l = tiles.slice(); [l[i - 1], l[i]] = [l[i], l[i - 1]]; await save(l); } return; }
      const ed = t.closest('[data-ed]'); if (ed) { const i = +ed.dataset.ed; return editor(tiles[i], (n) => save(tiles.map((x, j) => (j === i ? n : x)))); }
      const del = t.closest('[data-del]'); if (del) { const i = +del.dataset.del; if (await LA.confirm(`刪除「${tiles[i].name}」？`)) await save(tiles.filter((_, j) => j !== i)); return; }
      const tile = t.closest('[data-tile]'); if (!tile || editing) return; return LA.runTile(tiles.find((x) => x.id === tile.dataset.tile));
    });
  } });
})();
