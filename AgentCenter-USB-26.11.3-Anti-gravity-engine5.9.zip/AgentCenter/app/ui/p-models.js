'use strict';
/* 模型頁：Gemini／Claude／ChatGPT／NVIDIA／Groq／自訂（OpenAI 相容）。選供應商 → 填金鑰（可先測試）→ 查可用模型 → 設為主要。
   金鑰只存在後台，這個頁面永遠只拿到「已設定」遮罩，不會看到明文。 */
(function () {
  const { esc, $, $$ } = LA;
  const MASK = '••••已設定';
  const ADV = [
    { key: 'model.thinking', label: '思考量（越低回覆越快）', type: 'select', options: [['low', '低（快，建議）'], ['off', '最低（最快，複雜任務較弱）'], ['auto', '模型預設（慢但較深入）']], hint: '只對 Gemini 2.5／3 系列有效，其他供應商會忽略。' },
    { key: 'model.max_tokens', label: '單次輸出上限（tokens）', type: 'number' },
    { key: 'model.history', label: '帶入的歷史訊息數', type: 'number' }, { key: 'model.no_repeat', label: '不要重複同一句話（使用者要求重複時例外）', type: 'toggle' }, { key: 'model.vague_help', label: '模糊需求先自己推斷再做（不要只反問）', type: 'toggle' },
    { key: 'model.max_rounds', label: '單次最多工具輪數', type: 'number' },
    { key: 'model.eco', label: '省額度模式', type: 'select', options: [['auto', '自動（建議：重點工具說明完整，其他精簡）'], ['on', '更省（說明更短、歷史 8 則、工具結果更短；複雜任務可能多查一次用法）'], ['off', '關閉（全部完整送出）']], hint: '每次對話送給模型的字數越少，免費額度用得越慢。' },
    { key: 'model.experience', label: '經驗記憶（記住做成功的做法，下次類似的事直接照做）', type: 'toggle' },
    { key: 'skills.auto_attach', label: '最相關的技能自動附上全文（省一次讀取；第三方技能不會自動附上）', type: 'toggle' },
    { key: 'memory.consolidate.enabled', label: '每天凌晨整理記憶（合併重複的事實，不花額度）', type: 'toggle' },
    { key: 'usb.organize.enabled', label: 'USB 版：插上 USB、有網路時自動整理散落的檔案', type: 'toggle' },
  ];
  let S = null;            // { providers, current, keys, settings }
  let sel = null;          // 目前展開的供應商 id
  let found = {};          // 各供應商「查詢可用模型」的結果快取

  async function load() {
    const [pv, keys, st] = await Promise.all([LA.api('/api/model-providers'), LA.api('/api/model-keys'), LA.api('/api/settings')]);
    S = { providers: pv.providers, current: pv.current, keys: keys.items, settings: st.settings };
    if (!sel || !S.providers.find((p) => p.id === sel)) sel = S.current.provider;
  }
  const prov = (id) => S.providers.find((p) => p.id === id) || { id, label: id };
  const keysOf = (id) => S.keys.map((k, i) => ({ ...k, i })).filter((k) => k.provider === id);
  const legacy = (id) => S.settings.model && S.settings.model[id + '_key'] === MASK;
  const modelOf = (id) => (id === S.current.provider ? S.current.name : (S.current.provider_models || {})[id] || prov(id).default_model || '');
  const keyState = (k) => (k.enabled === false ? ['', '停用'] : k.exhausted ? ['bad', '失效／耗盡'] : k.rate_limited && k.cooldown_until > Date.now() ? ['warn', `忙碌中（每分鐘上限，約 ${Math.max(1, Math.ceil((k.cooldown_until - Date.now()) / 1000))} 秒後恢復）`] : ['ok', '可用']);

  /** 把整個金鑰池原樣送回（未改的用遮罩＋from 指回原位置），再依 edit 調整 */
  async function saveKeys(edit) {
    let items = S.keys.map((k, i) => ({ from: i, label: k.label, provider: k.provider, model: k.model, base_url: k.base_url || '', enabled: k.enabled !== false, key: MASK }));
    items = edit(items);   // 26.11.3 pro3：不限組數
    await LA.post('/api/model-keys', { items }); await load();
  }

  function head() {
    const c = S.current; const p = prov(c.provider); const nx = (c.order || []).slice(1).map(prov); const fb = nx[0] || null; const has = p.has_key;
    return `<div class="card mhead"><h3>🧠 目前使用 <small><span class="dot ${has ? 'ok' : 'bad'}"></span>${has ? '金鑰就緒' : '尚無金鑰'}</small></h3>
      <div class="mnow"><b>${esc(p.label)}</b><span class="mono">${esc(c.name || '—')}</span></div>
      <div class="hint">${fb ? `額度用完時依序改用：${nx.map((x) => `${esc(x.label.replace(/ \(.*\)/, ''))}${x.has_key ? '' : '（沒金鑰，跳過）'}`).join(' → ')}` : '順序：只有這一家（下方「供應商順序」可以加第二、第三家）'}</div>
      <div class="row" style="margin-top:8px"><button class="btn pri" id="m-test">測試目前模型</button><span class="hint" id="m-test-out"></span></div></div>`;
  }
  function tiles() {
    return `<div class="ptiles">${S.providers.map((p) => `<button class="ptile ${p.id === sel ? 'sel' : ''}" data-prov="${p.id}"><span class="dot ${p.has_key ? 'ok' : ''}"></span><b>${esc(p.label.replace(/ \(.*\)/, ''))}</b>${p.id === S.current.provider ? '<i>使用中</i>' : (S.current.order || []).includes(p.id) ? `<i class="fb">第 ${(S.current.order || []).indexOf(p.id) + 1} 順位</i>` : ''}</button>`).join('')}</div>`;
  }
  function panel() {
    const p = prov(sel); const ks = keysOf(sel); const isCur = sel === S.current.provider; const m = modelOf(sel); const list = found[sel];
    const lg = legacy(sel) && !ks.length;
    return `<div class="card" id="m-panel"><h3>${esc(p.label)} <small>${isCur ? '目前主要供應商' : p.has_key ? '已有金鑰' : '尚未設定'}</small></h3>
      ${p.key_url ? `<div class="hint">申請金鑰：<span class="mono">${esc(p.key_url)}</span> <button class="btn sm" data-copy="${esc(p.key_url)}">複製</button></div>` : '<div class="hint">任何支援 OpenAI Chat Completions 的服務都能接（Ollama、LM Studio、OpenRouter、自架 vLLM…）。沒有金鑰的本機服務請隨便填一個字串。</div>'}
      ${sel === 'custom' ? `<label class="f">API 網址（到 /v1 為止）</label><input id="m-base" value="${esc(S.current.custom_base_url || '')}" placeholder="https://example.com/v1">` : ''}
      <label class="f">模型名稱</label><div class="row"><input id="m-model" class="grow" list="m-dl" value="${esc(m)}" placeholder="${esc(p.default_model || '模型 ID')}" autocapitalize="off" autocomplete="off" spellcheck="false"><button class="btn" id="m-find">查詢可用模型</button></div>
      <datalist id="m-dl">${(list || []).map((x) => `<option value="${esc(x.id)}">`).join('')}</datalist>
      ${list ? `<div class="chips mlist">${list.length ? list.slice(0, 80).map((x) => `<button class="chip" data-pick="${esc(x.id)}">${esc(x.id)}${x.vision ? ' 👁' : ''}</button>`).join('') : '<span class="mute small">這把金鑰沒有查到可用的聊天模型</span>'}</div><div class="hint">👁＝支援看圖。點一下就填入；沒有 👁 的模型收到圖片時，系統會自動改成文字說明而不是報錯。</div>` : '<div class="hint">不確定型號？按「查詢可用模型」向供應商查這把金鑰實際能用的清單（各家常換型號，不用背）。</div>'}
      <h4 class="mh">金鑰（${ks.length} 組${lg ? '，另有舊版單一金鑰' : ''}）</h4>
      ${ks.map((k) => { const st = keyState(k); return `<div class="krow"><div class="grow"><b>${esc(k.label || '金鑰 ' + (k.i + 1))}</b> <span class="mono">${esc(k.key)}</span><div class="small mute"><span class="dot ${st[0]}"></span>${st[1]}${k.model ? ' · ' + esc(k.model) : ''}${k.last_error ? '<br><span class="err">' + esc(k.last_error) + '</span>' : ''}</div></div>
        <div class="kbtn"><button class="btn sm" data-ktest="${k.i}">測試</button><button class="btn sm" data-ktog="${k.i}">${k.enabled === false ? '啟用' : '停用'}</button><button class="btn sm bad" data-kdel="${k.i}">刪除</button></div></div>`; }).join('')}
      ${lg ? `<div class="krow"><div class="grow"><b>舊版單一金鑰</b> <span class="mono">${MASK}</span><div class="small mute">只在金鑰池沒有這一家時使用</div></div><div class="kbtn"><button class="btn sm bad" data-klegacy="${sel}">清除</button></div></div>` : ''}
      ${!ks.length && !lg ? '<div class="hint">還沒有金鑰。貼上後按「測試並加入」，成功才會存。</div>' : ''}
      <div class="kadd"><input id="k-label" placeholder="名稱（選填，例：主用）"><input id="k-key" type="password" autocomplete="off" placeholder="貼上 ${esc(p.label.replace(/ \(.*\)/, ''))} API Key"><div class="row"><button class="btn pri grow" id="k-add">測試並加入</button><button class="btn" id="k-addnt">不測試直接加入</button></div></div>
      <div class="row" style="margin-top:12px"><button class="btn ok grow" id="m-use">${isCur ? '儲存模型設定' : '設為主要模型'}</button>${S.keys.some((k) => k.exhausted) ? '<button class="btn" id="k-reset">重設耗盡狀態</button>' : ''}</div>
      <div class="hint">金鑰只存在後台、AI 看不到也不能修改；金鑰組數不限，會在額度／權限／速率錯誤時自動輪換。注意：同一個帳號（同一個專案）建的多把金鑰通常共用同一份額度，多加幾把不會變出更多免費額度；請遵守各家的使用條款。</div></div>`;
  }
  // 26.11.3 pro3：供應商順序（取代原本只能選一家的「備援供應商」）
  let draft = null;   // 編輯中的順序
  function orderCard() {
    const c = S.current; const o = draft || c.order || [c.provider]; const rest = S.providers.filter((p) => !o.includes(p.id)); const dirty = draft && draft.join() !== (c.order || []).join();
    const kst = (id) => { const ks = keysOf(id); const out = ks.filter((k) => k.exhausted).length; return ks.length ? `${ks.length} 組金鑰${out ? `，${out} 組用完／失效` : ''}` : legacy(id) ? '舊版單一金鑰' : '沒有金鑰（會跳過）'; };
    return `<div class="card" id="m-order"><h3>${LA.icon ? LA.icon('list') : ''} 供應商順序</h3><div class="hint">由上往下用。第一個＝主要；它的額度用完、金鑰全失效、服務故障或連不上，就自動跳下一個，對話不中斷；額度恢復後又會先用第一個。沒有金鑰的會直接跳過。請求本身有問題（例如格式錯誤）不會換家。</div>
      <div class="olist">${o.map((id, i) => { const p = prov(id); return `<div class="orow"><span class="onum">${i + 1}</span><div class="grow"><b>${esc(p.label.replace(/ \(.*\)/, ''))}</b> <span class="mono small">${esc(modelOf(id) || '—')}</span><div class="small mute"><span class="dot ${p.has_key ? 'ok' : 'bad'}"></span>${esc(kst(id))}</div></div>
        <div class="kbtn"><button class="btn sm" data-oup="${i}" ${i ? '' : 'disabled'} aria-label="往上">上移</button><button class="btn sm" data-odn="${i}" ${i < o.length - 1 ? '' : 'disabled'} aria-label="往下">下移</button><button class="btn sm bad" data-orm="${i}" ${o.length > 1 ? '' : 'disabled'}>移除</button></div></div>`; }).join('')}</div>
      ${rest.length ? `<div class="row" style="margin-top:8px"><select id="o-add" class="grow"><option value="">＋ 加入供應商…</option>${rest.map((p) => `<option value="${p.id}">${esc(p.label)}${p.has_key ? '' : '（還沒有金鑰）'}</option>`).join('')}</select></div>` : ''}
      <div class="row" style="margin-top:10px"><button class="btn pri" id="o-save" ${dirty ? '' : 'disabled'}>儲存順序</button>${dirty ? '<button class="btn" id="o-undo">取消</button><span class="hint">還沒儲存</span>' : ''}</div>
      <label class="f" style="margin-top:10px">主要那家的備用型號（同一家另一個模型，選填）</label><div class="row"><input id="fb-model" class="grow" value="${esc(c.fallback_model || '')}" placeholder="例：${esc(prov(o[0]).default_model || '')}" autocapitalize="off" autocomplete="off" spellcheck="false"><button class="btn" id="fb-save">儲存</button></div></div>`;
  }
  function advCard() {
    return `<div class="card" data-sec="model-adv"><h3>⚙️ 進階</h3>${ADV.map((f) => LA.fieldHTML(f, S.settings)).join('')}<div class="row" style="margin-top:10px"><button class="btn pri" id="adv-save">儲存</button></div></div>`;
  }
  function schemaCard() { return `<div class="card"><h3>🧪 工具相容性</h3><div class="hint">檢查每個工具（含連接器帶來的）能不能送給目前的模型。不相容的會被自動暫停，不會讓整個 AI 停擺；參數仍由 App 用原始規格驗證。</div><div class="row" style="margin-top:8px"><button class="btn" id="sc-run">檢查</button><button class="btn sm" id="sc-reset">清除暫停名單</button></div><div id="sc-out"></div></div>`; }
  function paint(main) { main.innerHTML = head() + tiles() + panel() + orderCard() + advCard() + schemaCard(); if (LA.iconize) LA.iconize(main); }

  LA.register('models', { name: '模型', title: '模型與金鑰（Gemini／Claude／ChatGPT／NVIDIA／Groq）', async render(main) {
    await load(); paint(main);
    const redraw = async () => { await load(); paint(main); };
    const keep = () => { const mi = $('#m-model'), mb = $('#m-base'); return { model: mi ? mi.value.trim() : '', base: mb ? mb.value.trim() : '' }; };
    main.onchange = (e) => { if (e.target.id === 'o-add' && e.target.value) { draft = [...(draft || S.current.order || [S.current.provider]), e.target.value]; paint(main); } };
    main.onclick = LA.guard(async (e) => {
      const t = e.target; const c = t.closest('[data-copy]'); if (c) return LA.copy(c.dataset.copy);
      const tile = t.closest('[data-prov]'); if (tile) { sel = tile.dataset.prov; return paint(main); }
      const pick = t.closest('[data-pick]'); if (pick) { $('#m-model').value = pick.dataset.pick; return; }
      const withBusy = async (btn, txt, fn) => { const old = btn.textContent; btn.disabled = true; btn.textContent = txt; try { return await fn(); } finally { btn.disabled = false; btn.textContent = old; } };
      if (t.id === 'm-test') return withBusy(t, '測試中…', async () => { const r = await LA.post('/api/model-test'); $('#m-test-out').textContent = ''; LA.toast(`模型測試成功（${prov(r.provider).label} / ${r.model}）：${r.text}`); });
      if (t.id === 'm-find') return withBusy(t, '查詢中…', async () => { const { base } = keep(); const r = await LA.post('/api/model-list', { provider: sel, base_url: base || S.current.custom_base_url || '' }); found[sel] = r.models; const cur = keep(); paint(main); $('#m-model').value = cur.model; if (sel === 'custom' && cur.base) $('#m-base').value = cur.base; LA.toast(`找到 ${r.models.length} 個模型`); });
      if (t.id === 'k-add' || t.id === 'k-addnt') {
        const key = $('#k-key').value.trim(); if (!key) throw new Error('請先貼上 API Key'); const label = $('#k-label').value.trim(); const { model, base } = keep();
        if (sel === 'custom' && !(base || S.current.custom_base_url)) throw new Error('自訂供應商要先填 API 網址');
        return withBusy(t, '處理中…', async () => {
          if (t.id === 'k-add') { const r = await LA.post('/api/model-test', { provider: sel, model: model || modelOf(sel), key, base_url: base || S.current.custom_base_url || '' }); LA.toast(`金鑰有效（回覆：${r.text || 'OK'}）`); }
          if (sel === 'custom' && base) await LA.post('/api/model-select', { provider: S.current.provider, model: S.current.name, custom_base_url: base });
          await saveKeys((items) => [...items, { from: -1, label: label || `${prov(sel).label.replace(/ \(.*\)/, '')} ${keysOf(sel).length + 1}`, provider: sel, model: '', base_url: sel === 'custom' ? (base || S.current.custom_base_url || '') : '', enabled: true, key }]);
          await LA.refreshStatus().catch(() => {}); paint(main); LA.toast('金鑰已加入');
        });
      }
      const kt = t.closest('[data-ktest]'); if (kt) return withBusy(kt, '…', async () => { const i = +kt.dataset.ktest; const k = S.keys[i]; const r = await LA.post('/api/model-test', { provider: k.provider, model: k.model || keep().model || modelOf(k.provider), key: MASK, index: i }); LA.toast(`這把金鑰有效：${r.text || 'OK'}`); });
      const tg = t.closest('[data-ktog]'); if (tg) { const i = +tg.dataset.ktog; await saveKeys((items) => items.map((x, j) => (j === i ? { ...x, enabled: x.enabled === false } : x))); paint(main); return; }
      const kd = t.closest('[data-kdel]'); if (kd) { if (!(await LA.confirm('確定刪除這組金鑰？刪除後無法復原。'))) return; const i = +kd.dataset.kdel; await saveKeys((items) => items.filter((_, j) => j !== i)); paint(main); LA.toast('已刪除'); return; }
      const kl = t.closest('[data-klegacy]'); if (kl) { if (!(await LA.confirm('清除舊版單一金鑰？'))) return; await LA.post('/api/settings', { items: [{ key: `model.${kl.dataset.klegacy}_key`, value: '' }] }); await redraw(); return; }
      if (t.id === 'k-reset') { await LA.post('/api/model-keys/reset'); await redraw(); LA.toast('已重設'); return; }
      if (t.id === 'm-use') {
        const { model, base } = keep(); if (!model) throw new Error('請先填模型名稱（或按「查詢可用模型」挑一個）');
        if (!prov(sel).has_key) { if (!(await LA.confirm(`${prov(sel).label} 還沒有金鑰，設成主要後 AI 會無法回應。仍要設定嗎？`))) return; }
        await LA.post('/api/model-select', { provider: sel, model, ...(sel === 'custom' ? { custom_base_url: base || S.current.custom_base_url || '' } : {}) }); await LA.refreshStatus().catch(() => {}); await redraw(); LA.toast(`已切換為 ${prov(sel).label} / ${model}`); return;
      }
      const ou = t.closest('[data-oup]'), od = t.closest('[data-odn]'), orm = t.closest('[data-orm]');
      if (ou || od || orm) { const o = [...(draft || S.current.order || [S.current.provider])]; const i = +(ou || od || orm).dataset[ou ? 'oup' : od ? 'odn' : 'orm']; if (orm) o.splice(i, 1); else { const j = ou ? i - 1 : i + 1; [o[i], o[j]] = [o[j], o[i]]; } draft = o; return paint(main); }
      if (t.id === 'o-undo') { draft = null; return paint(main); }
      if (t.id === 'o-save') { const o = draft || S.current.order; if (!prov(o[0]).has_key && !(await LA.confirm(`${prov(o[0]).label} 還沒有金鑰，排第一的話每次都會先跳過它。仍要儲存嗎？`))) return; const r = await LA.post('/api/model-order', { order: o }); draft = null; await LA.refreshStatus().catch(() => {}); await redraw(); LA.toast(`已儲存：${r.order.map((x) => prov(x).label.replace(/ \(.*\)/, '')).join(' → ')}`); return; }
      if (t.id === 'fb-save') { await LA.post('/api/model-select', { provider: S.current.provider, model: S.current.name, fallback_model: $('#fb-model').value.trim() }); await redraw(); LA.toast('已儲存'); return; }
      if (t.id === 'sc-run') return withBusy(t, '檢查中…', async () => { const r = await LA.api('/api/model-schema-check'); const bad = [...r.skipped, ...r.quarantined.filter((q) => !r.skipped.some((x) => x.tool === q.tool))]; $('#sc-out').innerHTML = `<div class="hint ${bad.length ? 'err' : 'okc'}">${esc(prov(r.provider).label)}：${r.sent}/${r.total} 個工具可送出${bad.length ? `，${bad.length} 個暫停` : '，全部相容'}</div>${bad.map((b) => `<div class="small mono" style="margin-top:4px">${esc(b.tool)}：${esc(String(b.reason).slice(0, 200))}</div>`).join('')}`; });
      if (t.id === 'sc-reset') { await LA.post('/api/model-schema-check/reset'); LA.toast('已清除，下次對話會重新檢查'); return; }
      if (t.id === 'adv-save') { await LA.post('/api/settings', { items: LA.collect($('[data-sec="model-adv"]')) }); await redraw(); LA.toast('已儲存，並自動套用'); }
    });
  } });
})();
