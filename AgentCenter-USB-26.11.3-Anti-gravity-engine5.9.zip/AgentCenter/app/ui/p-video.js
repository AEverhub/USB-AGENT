'use strict';
/*
 * 26.11.3 Anti-gravity-engine2：影片工作室（和 AI 的 video_make 共用同一個佇列）
 *  ・清單：排隊中／製作中 %／完成（直接播放、下載）／失敗（重做）
 *  ・預覽播放器：用跟錄製完全一樣的畫法即時播放分鏡（可拖曳時間軸）
 *  ・自己寫：一行一格「標題｜內容」，選尺寸、風格、音樂 → 開始製作
 */
(function () {
  const { esc } = LA; const $ = (s, r = document) => r.querySelector(s);
  const ST = { drafting: 'AI 寫分鏡中', queued: '排隊算圖', rendering: '製作中', done: '完成', error: '失敗' };
  const EX = ['介紹番茄工作法的短影音', '咖啡店新品上市的宣傳短片', '30 秒說明如何設定強密碼', '公司年度回顧，橫式，電影感', '給小朋友的刷牙教學'];
  let draft = '';
  let pv = null; // { spec, imgs, t, playing, raf }
  const SAMPLE = '三分鐘看懂番茄工作法\n為什麼總是分心？｜手機通知、待辦太多、不知道先做哪個\n怎麼做｜選一件事、計時 25 分鐘、休息 5 分鐘、四輪後長休息\n85%｜試過的人覺得更專注\n今天就試一輪！｜設好計時器，從最小的一件事開始';
  /** 「標題｜內容」一行一格 → 分鏡 */
  function parse(txt) {
    const lines = String(txt).split('\n').map((l) => l.trim()).filter(Boolean); const scenes = [];
    lines.forEach((l, i) => {
      const [a, ...rest] = l.split(/[｜|]/); const b = rest.join('｜').trim(); const head = a.trim();
      if (!b) { scenes.push({ layout: i === 0 ? 'title' : i === lines.length - 1 ? 'end' : 'text', title: head }); return; }
      if (/^[\d\s$NT.,%+倍萬億千百-]+$/.test(head) && /\d/.test(head)) { scenes.push({ layout: 'stat', stat: { value: head, label: b } }); return; }
      const parts = b.split(/[、，,]/).map((x) => x.trim()).filter(Boolean);
      if (parts.length >= 3 && parts.every((x) => x.length <= 22)) { scenes.push({ layout: 'bullets', title: head, bullets: parts.slice(0, 6) }); return; }
      scenes.push({ layout: i === lines.length - 1 ? 'end' : 'text', title: head, text: b });
    });
    return scenes;
  }
  function stopPreview() { if (pv) { pv.playing = false; cancelAnimationFrame(pv.raf); } }
  function draw() { const cv = $('#vp-cv'); if (!cv || !pv) return; const g = cv.getContext('2d'); LA.vid.frame(g, pv.spec, pv.t, pv.imgs); const sl = $('#vp-t'); if (sl) sl.value = String(Math.round(pv.t * 10)); const lb = $('#vp-lb'); if (lb) lb.textContent = `${pv.t.toFixed(1)} / ${pv.spec.duration} 秒`; }
  function play() { if (!pv) return; pv.playing = true; let last = performance.now(); const btn = $('#vp-play'); if (btn) btn.innerHTML = LA.icon('pause');
    const step = (now) => { if (!pv || !pv.playing) return; pv.t += (now - last) / 1000; last = now; if (pv.t >= pv.spec.duration) { pv.t = pv.spec.duration; pv.playing = false; if (btn) btn.innerHTML = LA.icon('play'); draw(); return; } draw(); pv.raf = requestAnimationFrame(step); }; pv.raf = requestAnimationFrame(step); }
  async function openPreview(spec, assets) { stopPreview(); pv = { spec, imgs: assets ? await LA.vid.loadAssets({ assets }) : [], t: 0, playing: false }; const box = $('#vp'); if (!box) return;
    box.hidden = false; const cv = $('#vp-cv'); cv.width = spec.w; cv.height = spec.h; cv.style.aspectRatio = `${spec.w}/${spec.h}`; const sl = $('#vp-t'); sl.max = String(Math.round(spec.duration * 10)); draw(); box.scrollIntoView({ behavior: 'smooth', block: 'center' }); play(); }
  async function view(main) {
    const ta = $('#v-req'); if (ta) draft = ta.value;
    const det = {}; for (const id of ['v-mat', 'v-eng', 'v-adv']) { const el = document.getElementById(id); if (el) det[id] = el.open; }
    const [r, cp, en] = await Promise.all([LA.api('/api/video'), LA.api('/api/video/caps').catch(() => null), LA.api('/api/video/engine').catch(() => null)]); const list = r.videos || [];
    const vs = (cp && cp.settings) || {}; const capRow = (ok, name, how) => `<div class="vcap ${ok ? 'ok' : ''}">${LA.icon(ok ? 'check' : 'x')}<b>${name}</b><span class="mute small">${ok ? '可用' : esc(how)}</span></div>`;
    main.innerHTML = `
      <div class="card gen-hero"><h3>想做什麼影片？</h3>
        <p class="mute small">一句話就好。AI 會自己寫分鏡與旁白、配人聲、找實拍素材、配圖、選直式或橫式、風格和背景音樂，做好自動放到對話裡（通常 1～3 分鐘）。${en && en.passed ? '專業引擎（HyperFrames）已啟用，在背景算圖。' : 'App 畫面要開著才會算圖。'}</p>
        <div class="gen-row"><textarea id="v-req" rows="2" placeholder="例：介紹番茄工作法的短影音">${esc(draft)}</textarea><button class="btn pri" id="v-go">生成</button></div>
        <div class="chips">${EX.map((a) => `<button class="chip" data-ex="${esc(a)}">${esc(a)}</button>`).join('')}</div>
        ${r.pending || r.drafting ? `<p class="hint">${r.drafting ? `${r.drafting} 支 AI 寫分鏡中　` : ''}${r.pending ? `${r.pending} 支排隊／製作中${LA.vid.busy() ? '（這台正在做）' : ''}` : ''}</p>` : ''}
      </div>
      <div class="card" id="vp" hidden><div class="vp-wrap"><canvas id="vp-cv"></canvas></div>
        <div class="row" style="margin-top:8px"><button class="btn sm" id="vp-play">${LA.icon('play')}</button><input type="range" id="vp-t" min="0" max="100" value="0" class="grow"><span class="mute small" id="vp-lb"></span><button class="btn sm" id="vp-x">${LA.icon('x')}</button></div>
        <p class="mute small">預覽沒有聲音；正式影片會加上旁白人聲與背景音樂。</p></div>
      <div class="card"><h3>影片</h3>${list.length ? list.map((v) => `<div class="vrow">
          <div class="grow"><b>${esc(v.title)}</b><div class="mute small">${v.scenes} 格・${v.duration} 秒・${{ portrait: '直式', landscape: '橫式', square: '方形' }[v.size] || ''}・${LA.fmtTime(v.created)}</div>
            <div class="small ${v.status === 'error' ? 'bad' : v.status === 'done' ? 'ok' : ''}">${ST[v.status] || v.status}${v.status === 'drafting' && v.stage ? `：${esc(v.stage)}` : ''}${v.status === 'rendering' ? ` ${v.progress}%` : ''}${v.status === 'error' ? '：' + esc(v.error) : ''}${v.status === 'queued' && v.error ? `（上次：${esc(v.error)}）` : ''}</div>
            ${v.status === 'rendering' ? `<div class="vbar"><i style="width:${v.progress}%"></i></div>` : v.status === 'drafting' ? '<div class="vbar gen-bar"><i></i></div>' : ''}
            ${v.status === 'done' && v.file ? `<video class="vplay" controls playsinline preload="metadata" src="${LA.rw('/api/files/view/' + encodeURIComponent(v.file.id))}?t=${encodeURIComponent(LA.token)}"></video>` : ''}</div>
          <div class="vact">${v.scenes ? `<button class="btn sm" data-pv="${v.id}">預覽</button>` : ''}${v.status === 'done' && v.file ? `<button class="btn sm pri" data-dl="${v.file.id}" data-name="${esc(v.file.name)}">下載</button>` : ''}${['error', 'done'].includes(v.status) ? `<button class="btn sm" data-re="${v.id}">重做</button>` : ''}<button class="btn sm" data-rm="${v.id}">${LA.icon('trash')}</button></div>
        </div>`).join('') : '<p class="mute">還沒有影片。</p>'}</div>
      ${cp ? `<details class="card adv" id="v-mat"${det['v-mat'] ? ' open' : ''}><summary>人聲與素材</summary>
        <div class="vcaps">${capRow(cp.narration, '旁白人聲' + (cp.voice ? `（${esc(cp.voice)}）` : ''), '在 Android App 裡會用手機內建語音（免費）；或加 Gemini／OpenAI 金鑰')}${capRow(cp.stock, '實拍素材' + (cp.stock_source ? `（${esc(cp.stock_source)}）` : ''), '下面開啟「免費實拍」')}${capRow(cp.images, 'AI 插圖（免費出圖）', '開啟自動配圖')}${capRow(cp.avatar, '虛擬主持人（免費插畫角色，會對嘴）', '下面主持人選「自動」')}${capRow(cp.presenter, '真人數位主持人（HeyGen，付費・選用）', '不填也行，會用免費虛擬主持人')}${capRow(cp.web_shot, 'AI 自己截網頁畫面', '瀏覽器服務沒開')}${capRow(cp.app_shot, 'AI 自己截手機 App 畫面（只限管理員）', '到「手機代理」打開無障礙服務（Android 11 以上）')}${capRow(cp.ai_clips, 'AI 實景影片（Gemini Omni，付費・選用）', '不開也行，會用免費出圖＋鏡頭推移代替')}</div>
        <p class="mute small">全部免費也能做：手機內建語音念旁白、Wikimedia Commons 自由授權實拍、免費出圖、虛擬主持人。付費服務只是選配。</p>
        <p class="mute small">真人影像只來自：你自己的影片照片、Pexels 授權實拍、HeyGen 虛擬主持人、AI 生成的虛構人物；不會合成真實人物。</p>
        <div class="vset">
          <label class="f">算圖引擎</label><select data-vk="engine"><option value="auto">自動（專業引擎測試通過才用）</option><option value="hyperframes">優先用專業引擎（HyperFrames）</option><option value="app">只用 App 畫面</option></select>
          <label class="f">旁白語音包</label><select data-vk="voice_pack"><option value="">自動（有雲端金鑰用雲端，額度用完自動改手機語音）</option>${cp.device_voice ? '<option value="device">手機內建語音（免費、離線）</option>' : ''}${(cp.packs || []).map((p) => `<option value="${esc(p.id)}"${p.available ? '' : ' disabled'}>${esc(p.name)}${p.available ? '' : '（沒有金鑰）'}</option>`).join('')}</select>
          <label class="f">虛擬人物（主持人）</label><select data-vk="avatar"><option value="auto">自動（要主持人時才出現）</option><option value="always">每支有旁白的影片都放</option><option value="off">不要虛擬人物</option></select>
          <label class="f">旁白聲音與虛擬人物的性別（會一致：男聲配男生、女聲配女生）</label><select data-vk="gender"><option value="auto">自動（你說「男生聲音」「女主持人」就照你說的）</option><option value="male">男</option><option value="female">女</option></select>
          <label class="ck"><input type="checkbox" data-vk="narration"> 自動配旁白人聲</label>
          <label class="ck"><input type="checkbox" data-vk="free_stock"> 免費實拍（Wikimedia Commons，不用金鑰）</label>
          <label class="ck"><input type="checkbox" data-vk="footage"> 自動找實拍素材</label>
          <label class="ck"><input type="checkbox" data-vk="auto_images"> 自動 AI 配圖</label>
          <label class="ck"><input type="checkbox" data-vk="ai_clips"> AI 實景片段（Gemini Omni，會產生費用）</label>
          <label class="f">Pexels 金鑰（選填，免費申請：pexels.com/api，素材更多）</label><input type="password" data-vk="pexels_key" autocomplete="off" placeholder="貼上金鑰">
          <label class="f">HeyGen 金鑰（選填、付費：真人外觀主持人）</label><input type="password" data-vk="heygen_key" autocomplete="off" placeholder="貼上金鑰">
          <label class="f">HeyGen 主持人 ID（avatar_id）與聲音 ID（選填）</label><div class="row" style="gap:6px"><input data-vk="heygen_avatar" placeholder="主持人 avatar_id" class="grow"><input data-vk="heygen_voice" placeholder="voice_id（選填）" class="grow"></div>
          <div class="row" style="margin-top:8px"><button class="btn pri" id="v-save">儲存</button></div>
        </div></details>` : ''}
      ${en ? `<details class="card adv" id="v-eng"${det['v-eng'] ? ' open' : ''}><summary>專業引擎（HyperFrames）${en.passed ? '・已啟用' : ''}</summary>
        <p class="mute small">在 Termux 裡安裝 HyperFrames＋GSAP＋FFmpeg＋Chromium（Remotion 盡量裝），並下載 7 個影片技能。裝好並測試通過後，影片改在背景算圖，不用開著 App 畫面。這是非官方的手機安裝方式，失敗會自動改用 App 畫面算圖。</p>
        <div class="mute small">Termux：${en.termux ? '已連線' : '未設定（先到 Termux 頁面完成連線）'}｜安裝：${en.installed_at ? '完成' : en.installing ? '進行中' : '未安裝'}｜測試：${en.passed ? '通過' : en.test_error ? '未通過：' + esc(en.test_error) : '還沒測'}${en.imported && en.imported.length ? `｜已匯入技能 ${en.imported.length} 份` : ''}</div>
        <div class="row" style="flex-wrap:wrap;gap:6px;margin-top:8px"><button class="btn" data-ve="install"${en.termux ? '' : ' disabled'}>安裝</button><button class="btn" data-ve="log"${en.install_job ? '' : ' disabled'}>安裝進度</button><button class="btn" data-ve="check"${en.termux ? '' : ' disabled'}>檢查</button><button class="btn" data-ve="import"${en.termux ? '' : ' disabled'}>匯入技能</button><button class="btn" data-ve="test"${en.termux ? '' : ' disabled'}>測試算圖</button></div>
        <pre class="vlog" id="v-log" hidden></pre>
        <div class="mute small" style="margin-top:6px">${(en.repos || []).map((x) => `${esc(x.name)}（${esc(x.license)}）`).join('、')}</div></details>` : ''}
      <details class="card adv" id="v-adv"${det['v-adv'] ? ' open' : ''}><summary>進階：自己寫分鏡</summary>
        <label class="f">影片標題（第一行）與分鏡：一行一格「標題｜內容」；內容用頓號分 3 項以上會變條列；標題是數字會變成跳動的大數字</label>
        <textarea id="vs" rows="7">${esc(SAMPLE)}</textarea>
        <div class="row" style="flex-wrap:wrap;gap:6px;margin-top:8px">
          <select id="v-size"><option value="portrait">直式 9:16</option><option value="landscape">橫式 16:9</option><option value="square">方形 1:1</option></select>
          <select id="v-theme"><option value="dark">深色科技</option><option value="vivid">鮮豔</option><option value="ocean">海洋</option><option value="warm">暖色</option><option value="light">淺色</option><option value="mono">黑白</option></select>
          <select id="v-music"><option value="calm">柔和音樂</option><option value="upbeat">輕快音樂</option><option value="cinematic">電影感</option><option value="none">不要音樂</option></select>
        </div>
        <div class="row" style="margin-top:8px"><button class="btn" id="v-prev">預覽</button><button class="btn" id="v-make">照這個分鏡製作</button></div>
      </details>`;
    for (const el of main.querySelectorAll('[data-vk]')) { const v = vs[el.dataset.vk]; if (el.type === 'checkbox') el.checked = !!v; else if (el.type === 'password') el.placeholder = v ? '已設定（留空不變）' : el.placeholder; else el.value = v == null ? '' : v; }
    LA.report();
  }
  const specOf = () => { const lines = $('#vs').value.split('\n'); const title = (lines[0] || '').split(/[｜|]/)[0].trim(); return { title, size: $('#v-size').value, theme: $('#v-theme').value, music: $('#v-music').value, scenes: parse($('#vs').value) }; };
  LA.register('video', { name: '影片工作室', title: '影片工作室（一句話生成影片）',
    leave() { stopPreview(); LA.vid.onProgress = null; LA.vid.onDone = null; },
    async render(main) {
      await view(main); let rt = 0;
      LA.vid.onProgress = () => { if (Date.now() - rt > 2500 && !(pv && pv.playing)) { rt = Date.now(); view(main).catch(() => {}); } }; LA.vid.onDone = () => view(main).catch(() => {});
      LA.timers.push(setInterval(() => { if (LA.cur === 'video' && !(pv && pv.playing) && !document.querySelector('#vs:focus, #v-req:focus, .vset :focus') && !(document.getElementById('v-log') && !document.getElementById('v-log').hidden)) LA.api('/api/video').then((q) => { if (q.pending || q.drafting) view(main).catch(() => {}); }).catch(() => {}); }, 4000));
      main.onkeydown = (e) => { if (e.target.id === 'v-req' && e.key === 'Enter' && !e.shiftKey && !e.isComposing) { e.preventDefault(); const b = $('#v-go'); if (b) b.click(); } };
      main.oninput = (e) => { if (e.target.id === 'vp-t' && pv) { pv.playing = false; pv.t = Number(e.target.value) / 10; const b = $('#vp-play'); if (b) b.innerHTML = LA.icon('play'); draw(); } };
      main.onclick = LA.guard(async (e) => {
        const t = e.target;
        const ex = t.closest('[data-ex]'); if (ex) { const i = $('#v-req'); i.value = ex.dataset.ex; i.focus(); return; }
        if (t.closest('#v-go')) { const q = $('#v-req').value.trim(); if (!q) { $('#v-req').focus(); return LA.toast('說一句想做什麼影片', true); } t.closest('#v-go').disabled = true; await LA.post('/api/video/auto', { request: q }); draft = ''; LA.toast('開始做了：AI 先寫分鏡，接著自動算圖'); return view(main); }
        if (t.closest('#vp-play')) { if (!pv) return; if (pv.playing) { pv.playing = false; t.closest('#vp-play').innerHTML = LA.icon('play'); } else { if (pv.t >= pv.spec.duration) pv.t = 0; play(); } return; }
        if (t.closest('#vp-x')) { stopPreview(); $('#vp').hidden = true; return; }
        const p = t.closest('[data-pv]'); if (p) { const v = await LA.api('/api/video/' + p.dataset.pv); return openPreview(v.spec, v.assets); }
        const d = t.closest('[data-dl]'); if (d) { await LA.download(`/api/files/out/${encodeURIComponent(d.dataset.dl)}`, d.dataset.name); LA.toast('已下載：' + d.dataset.name); return; }
        const re = t.closest('[data-re]'); if (re) { await LA.post(`/api/video/${re.dataset.re}/retry`); LA.toast('已重新排入'); return view(main); }
        const rm = t.closest('[data-rm]'); if (rm) { if (!await LA.confirm('刪除這支影片？')) return; await LA.del('/api/video/' + rm.dataset.rm); return view(main); }
        if (t.closest('#v-prev')) { const s = specOf(); if (!s.scenes.length) return LA.toast('先寫分鏡', true); const sizes = { portrait: [720, 1280], landscape: [1280, 720], square: [720, 720] }; const [w, h] = sizes[s.size];
          const sc = s.scenes.map((x) => ({ bullets: [], text: '', title: '', caption: '', bg: [], anim: x.layout === 'bullets' ? 'slide' : 'fade', duration: x.layout === 'title' || x.layout === 'end' ? 3.5 : Math.min(12, 2.8 + ((x.title || '') + (x.text || '') + (x.bullets || []).join('')).length * 0.11 + (x.bullets || []).length * 0.6), ...x }));
          return openPreview({ ...s, w, h, fps: 30, watermark: true, scenes: sc, duration: Math.round(sc.reduce((a, x) => a + x.duration, 0) * 10) / 10 }, null); }
        if (t.closest('#v-save')) { const items = []; for (const el of main.querySelectorAll('[data-vk]')) { const k = 'video.' + el.dataset.vk; if (el.type === 'checkbox') items.push({ key: k, value: el.checked }); else if (el.type === 'password') { if (el.value.trim()) items.push({ key: k, value: el.value.trim() }); } else items.push({ key: k, value: el.value.trim() }); }
          await LA.post('/api/settings', { items }); LA.toast('已儲存'); return view(main); }
        const ve = t.closest('[data-ve]'); if (ve) { const a = ve.dataset.ve; const lg = $('#v-log'); const show = (txt) => { lg.hidden = false; lg.textContent = txt; };
          if (a === 'install') { if (!await LA.confirm('在 Termux 安裝 HyperFrames、GSAP、FFmpeg、Chromium 與影片技能？會下載數百 MB，約 10～30 分鐘。')) return; const r = await LA.post('/api/video/engine/install'); show(r.text || '已開始安裝'); return; }
          ve.disabled = true; show('處理中…');
          try { if (a === 'log') { const r = await LA.api('/api/video/engine/log'); show((r.done ? '安裝完成\n' : '安裝中…\n') + (r.log || '').split('\n').slice(-30).join('\n')); }
            if (a === 'check') { const r = await LA.post('/api/video/engine/check'); show(`${r.ok ? '環境齊全' : '還缺：' + (r.missing || []).join('、')}\n${Object.entries(r.versions || {}).map(([k, v]) => k + '：' + v).join('\n')}\n${r.doctor || ''}`); }
            if (a === 'import') { const r = await LA.post('/api/video/engine/import'); show(`已匯入 ${r.imported.length} 份：${r.imported.join('、')}`); }
            if (a === 'test') { show('算一支 2 格測試片，約 1～3 分鐘…'); const r = await LA.post('/api/video/engine/test'); show(r.ok ? `測試通過：${r.sec} 秒算出 ${Math.round(r.size / 1024)} KB，之後自動用專業引擎` : '測試沒通過：' + r.error); }
          } finally { ve.disabled = false; } return; }
        if (t.closest('#v-make')) { const s = specOf(); if (!s.scenes.length) return LA.toast('先寫分鏡', true); await LA.post('/api/video', s); LA.toast('已排入製作，畫面開著就會開始'); return view(main); }
      });
    } });
})();
