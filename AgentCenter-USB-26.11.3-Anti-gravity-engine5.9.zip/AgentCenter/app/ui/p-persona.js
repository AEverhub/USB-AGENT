'use strict';
/* 人設：名字、身份、個性、說話風格、和你的關係、稱呼；只影響說話方式，不改權限與安全規則 */
(function () {
  const { esc, $ } = LA;
  const F = [['name', '名字', '例：小燈'], ['identity', '身份', '例：我的私人管家，什麼雜事都幫我打理'], ['personality', '個性', '例：細心、可靠、偶爾幽默'], ['style', '說話風格', '例：台灣口語、簡短、像 LINE 聊天'], ['relation', '和你的關係', '例：多年老朋友'], ['call_user', '怎麼稱呼你', '例：老大、阿明'], ['avoid', '不要這樣說話', '例：不要一直道歉、不要用敬語']];
  LA.register('persona', { name: '人設', title: '人設（AI 的名字、身份、個性、說話風格）', async render(main) {
    const { persona: p, presets } = await LA.api('/api/persona');
    main.innerHTML = `<div class="card"><h3>🎭 人設 <small>只影響說話方式</small></h3>
      <div class="hint">選一個範本再改，或全部自己寫。設定後 AI 在 LINE／Telegram／Discord 和 App 裡都用這個個性說話。</div>
      <div class="chips" style="margin:8px 0">${Object.entries(presets).map(([k, v]) => `<button class="chip" data-preset="${k}">${esc(v.label)}</button>`).join('')}</div>
      <label class="chk"><input type="checkbox" id="p-on" ${p.enabled ? 'checked' : ''}> 啟用人設</label>
      ${F.map(([k, l, ph]) => `<label class="f">${l}</label>${k === 'identity' || k === 'avoid' ? `<textarea id="p-${k}" placeholder="${esc(ph)}" style="min-height:60px">${esc(p[k] || '')}</textarea>` : `<input id="p-${k}" value="${esc(p[k] || '')}" placeholder="${esc(ph)}">`}`).join('')}
      <label class="f">表情符號</label><select id="p-emoji">${[['none', '不用'], ['few', '偶爾'], ['many', '常用']].map(([v, n]) => `<option value="${v}" ${p.emoji === v ? 'selected' : ''}>${n}</option>`).join('')}</select>
      <label class="chk" style="margin-top:10px"><input type="checkbox" id="p-human" ${p.humanize !== false ? 'checked' : ''}> 說話像真人（自動去掉「身為 AI」「希望對你有幫助」這類機器人腔）</label>
      <div class="row" style="margin-top:12px"><button class="btn pri" id="p-save">儲存</button><button class="btn" id="p-try">儲存並試聊一句</button></div><div id="p-out"></div></div>`;
    main.onclick = LA.guard(async (e) => {
      const pr = e.target.closest('[data-preset]'); if (pr) { const v = presets[pr.dataset.preset]; for (const k of ['identity', 'personality', 'style', 'relation']) $('#p-' + k).value = v[k] || ''; $('#p-emoji').value = v.emoji || 'few'; $('#p-on').checked = true; LA.toast(`已套用「${v.label}」，名字和稱呼自己填`); return; }
      const save = async () => { const b = { enabled: $('#p-on').checked, emoji: $('#p-emoji').value, humanize: $('#p-human').checked }; for (const [k] of F) b[k] = $('#p-' + k).value.trim(); await LA.post('/api/persona', b); };
      if (e.target.id === 'p-save') { await save(); LA.toast('人設已儲存'); }
      if (e.target.id === 'p-try') { const b = e.target; b.disabled = true; try { await save(); const out = $('#p-out'); out.innerHTML = '<div class="bub ai">…</div>'; const r = await LA.post('/api/chat', { text: '嗨，簡單跟我打個招呼，順便說你今天能幫我做什麼。' }); out.innerHTML = `<div class="bub ai">${esc(r.text)}</div>`; } finally { b.disabled = false; } }
    });
  } });
})();
