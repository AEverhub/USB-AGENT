/**
 * Agent中控中心 26.11.3 Revise6：Discord 語音會議收音程式。
 *  ・由後台啟動（伺服器上直接開子行程，手機上在內建 Linux 裡跑），設定從 JSON 檔或環境變數 AGENT_VOICE_CFG 讀，讀完就刪檔。
 *  ・用 @discordjs/voice（含 DAVE 端對端加密）進語音頻道，依講者收 Opus 封包；
 *    一位講者停頓約 1.2 秒（或連續講滿 60 秒）就把那一段 POST 給後台，由後台轉文字與整理重點。
 *  ・不解碼聲音、不存檔；每 5 秒跟後台確認一次，會議結束就離開頻道並結束。
 *  ・不需要 Bot token：只用主程式進頻道時拿到的語音 token（短效）。
 */
import fs from 'node:fs';
import { pathToFileURL } from 'node:url';

export async function run(cfg, V, { fetchFn = globalThis.fetch, exit = (c) => process.exit(c), pingMs = 5000 } = {}) {
  const post = (body) => fetchFn(`${cfg.api}/api/meeting-ingest/${cfg.meeting}`, { method: 'POST', headers: { 'content-type': 'application/json', 'x-meeting-token': cfg.token }, body: JSON.stringify(body) })
    .then((r) => r.json()).catch((e) => ({ error: e.message }));
  let methods = null; let fed = false; let stopped = false;
  const feed = () => {
    if (fed || !methods) return; fed = true;
    methods.onVoiceStateUpdate({ guild_id: cfg.guild_id, channel_id: cfg.channel_id, user_id: cfg.user_id, session_id: cfg.session_id, deaf: false, mute: false, self_deaf: false, self_mute: true, self_video: false, suppress: false, request_to_speak_timestamp: null });
    methods.onVoiceServerUpdate({ guild_id: cfg.guild_id, token: cfg.voice_token, endpoint: cfg.endpoint });
  };
  const adapterCreator = (m) => {
    methods = m;
    return {
      sendPayload(p) {
        // 第一次的「加入」主程式已經送過了，這裡只把拿到的資料餵進去；之後的離開／重新加入才轉給主程式送
        if (p && p.op === 4 && p.d && p.d.channel_id && !fed) { setImmediate(feed); return true; }
        post({ type: 'gateway', payload: p }); return true;
      },
      destroy() { methods = null; },
    };
  };
  const conn = V.joinVoiceChannel({ channelId: cfg.channel_id, guildId: cfg.guild_id, adapterCreator, selfDeaf: false, selfMute: true });
  setTimeout(feed, 300);
  const end = async (why) => {
    if (stopped) return; stopped = true; clearInterval(iv);
    try { conn.destroy(); } catch { /* 已經斷了 */ }
    await post({ type: 'status', state: 'ended', reason: why || '' }); setTimeout(() => exit(0), 200);
  };
  conn.on('stateChange', (o, n) => {
    post({ type: 'status', state: n.status });
    if (n.status === V.VoiceConnectionStatus.Disconnected) {
      // 被踢、網路斷：5 秒內自己接回來就繼續，接不回來就結束
      Promise.race([V.entersState(conn, V.VoiceConnectionStatus.Signalling, 5000), V.entersState(conn, V.VoiceConnectionStatus.Connecting, 5000)]).catch(() => end('disconnected'));
    } else if (n.status === V.VoiceConnectionStatus.Destroyed) end('destroyed');
  });
  conn.on('error', (e) => post({ type: 'status', error: String(e && e.message || e) }));
  const iv = setInterval(async () => {
    const r = await post({ type: 'ping' });
    for (const ev of (r && r.events) || []) { if (!methods) break; if (ev.t === 'VOICE_SERVER_UPDATE') methods.onVoiceServerUpdate(ev.d); else if (ev.t === 'VOICE_STATE_UPDATE') methods.onVoiceStateUpdate(ev.d); }
    if (r && r.stop) end('stopped');
  }, pingMs);
  try { await V.entersState(conn, V.VoiceConnectionStatus.Ready, 30000); }
  catch (e) { await post({ type: 'status', error: '連不上語音頻道：' + (e && e.message || e) }); await end('timeout'); return { conn, end }; }
  await post({ type: 'status', state: 'ready' });
  const active = new Set();
  conn.receiver.speaking.on('start', (userId) => {
    if (active.has(userId) || userId === cfg.user_id || stopped) return; active.add(userId);
    let at = Date.now(); let pk = [];
    const flush = () => { if (pk.length >= 25) post({ type: 'audio', speaker_id: userId, at, channels: 2, packets: pk.map((b) => Buffer.from(b).toString('base64')) }); pk = []; at = Date.now(); };
    const s = conn.receiver.subscribe(userId, { end: { behavior: V.EndBehaviorType.AfterSilence, duration: cfg.silence_ms || 1200 } });
    s.on('data', (b) => { pk.push(b); if (pk.length >= 3000) flush(); });   // 3000 包 × 20ms＝60 秒
    s.on('end', () => { active.delete(userId); flush(); });
    s.on('error', () => { active.delete(userId); });
  });
  return { conn, end };
}

const isMain = !!process.argv[1] && import.meta.url === pathToFileURL(fs.realpathSync(process.argv[1])).href;
if (isMain) {
  let cfg; const f = process.argv[2];
  try { cfg = f ? JSON.parse(fs.readFileSync(f, 'utf8')) : JSON.parse(process.env.AGENT_VOICE_CFG || '{}'); } catch (e) { console.error('讀不到設定：' + e.message); process.exit(2); }
  if (f) { try { fs.unlinkSync(f); } catch { /* ignore */ } }   // 設定裡有短效 token：讀完就刪
  const V = await import('@discordjs/voice');
  run(cfg, V).catch((e) => { console.error(e); process.exit(1); });
}
