#!/bin/sh
# Agent 中控中心 USB 專版：自動啟動小幫手（macOS）。install｜uninstall｜watch
ACT="${1:-install}"
H="$HOME/Library/Application Support/AgentCenterUSB"
PL="$HOME/Library/LaunchAgents/com.agentcenter.usbwatch.plist"
case "$ACT" in
install)
  AC="$(cd "$(dirname "$0")/.." && pwd)"
  [ -f "$AC/app/portable.js" ] || { echo "找不到 AgentCenter 程式：$AC"; exit 1; }
  [ -f "$AC/usb-id" ] || (LC_ALL=C tr -dc 'a-f0-9' < /dev/urandom | head -c 32 > "$AC/usb-id")
  ID="$(tr -d ' \r\n' < "$AC/usb-id")"
  mkdir -p "$H" "$HOME/Library/LaunchAgents"
  cp "$0" "$H/watch.sh"; chmod +x "$H/watch.sh"
  touch "$H/ids.txt"; grep -qx "$ID" "$H/ids.txt" || echo "$ID" >> "$H/ids.txt"
  cat > "$PL" <<PLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
  <key>Label</key><string>com.agentcenter.usbwatch</string>
  <key>ProgramArguments</key><array><string>/bin/sh</string><string>$H/watch.sh</string><string>watch</string></array>
  <key>StartOnMount</key><true/>
  <key>RunAtLoad</key><true/>
</dict></plist>
PLIST
  launchctl unload "$PL" 2>/dev/null; launchctl load -w "$PL"
  echo "✓ 已安裝自動啟動小幫手。之後在這台 Mac 插上這支 USB 就會自動打開啟動程式（有網路時還會自動整理檔案）。"
  echo "  要移除：執行 USB 裡的「移除自動啟動-Mac.command」" ;;
uninstall)
  launchctl unload "$PL" 2>/dev/null; rm -f "$PL"; rm -rf "$H"
  echo "✓ 已從這台 Mac 移除自動啟動小幫手。" ;;
watch)
  # 每次有磁碟掛上時 launchd 會叫一次：找已登記的 USB，還沒開就打開
  sleep 2
  for AC in /Volumes/*/AgentCenter; do
    [ -f "$AC/usb-id" ] || continue
    ID="$(tr -d ' \r\n' < "$AC/usb-id")"; grep -qx "$ID" "$H/ids.txt" 2>/dev/null || continue
    R="$AC/data/.running.json"
    if [ -f "$R" ] && [ $(( $(date +%s) - $(stat -f %m "$R") )) -lt 90 ]; then continue; fi
    M="$TMPDIR/agentcenter-$ID"; V="$(stat -f %d "$AC" 2>/dev/null)"
    [ -f "$M" ] && [ "$(cat "$M")" = "$V" ] && continue
    echo "$V" > "$M"
    open -a Terminal "$AC/啟動-Mac.command"
  done ;;
esac
