#!/bin/sh
# Agent 中控中心 USB 專版：自動啟動小幫手（Linux 桌面）。install｜uninstall｜watch
ACT="${1:-install}"
H="${XDG_DATA_HOME:-$HOME/.local/share}/agentcenter-usb"
AUTO="${XDG_CONFIG_HOME:-$HOME/.config}/autostart/agentcenter-usb.desktop"
term() { for t in x-terminal-emulator gnome-terminal konsole xfce4-terminal mate-terminal lxterminal xterm; do
  if command -v "$t" >/dev/null 2>&1; then case "$t" in gnome-terminal) "$t" -- sh "$1" & ;; *) "$t" -e sh "$1" & ;; esac; return 0; fi; done; return 1; }
case "$ACT" in
install)
  AC="$(cd "$(dirname "$0")/.." && pwd)"
  [ -f "$AC/app/portable.js" ] || { echo "找不到 AgentCenter 程式：$AC"; exit 1; }
  [ -f "$AC/usb-id" ] || (LC_ALL=C tr -dc 'a-f0-9' < /dev/urandom | head -c 32 > "$AC/usb-id")
  ID="$(tr -d ' \r\n' < "$AC/usb-id")"
  mkdir -p "$H" "$(dirname "$AUTO")"; cp "$0" "$H/watch.sh"; chmod +x "$H/watch.sh"
  touch "$H/ids.txt"; grep -qx "$ID" "$H/ids.txt" || echo "$ID" >> "$H/ids.txt"
  printf '[Desktop Entry]\nType=Application\nName=Agent Center USB\nExec=sh "%s" watch\nX-GNOME-Autostart-enabled=true\nNoDisplay=true\n' "$H/watch.sh" > "$AUTO"
  pkill -f "agentcenter-usb/watch.sh watch" 2>/dev/null; nohup sh "$H/watch.sh" watch >/dev/null 2>&1 &
  echo "✓ 已安裝自動啟動小幫手。之後登入桌面、插上這支 USB 就會自動打開啟動程式（有網路時還會自動整理檔案）。"
  echo "  要移除：執行 USB 裡的「移除自動啟動-Linux.sh」" ;;
uninstall)
  pkill -f "agentcenter-usb/watch.sh watch" 2>/dev/null; rm -f "$AUTO"; rm -rf "$H"
  echo "✓ 已移除自動啟動小幫手。" ;;
watch)
  L=""
  while :; do
    NOW=""
    for AC in /media/*/AgentCenter /media/*/*/AgentCenter /run/media/*/*/AgentCenter /mnt/*/AgentCenter; do
      [ -f "$AC/usb-id" ] || continue
      ID="$(tr -d ' \r\n' < "$AC/usb-id")"; grep -qx "$ID" "$H/ids.txt" 2>/dev/null || continue
      NOW="$NOW|$ID"
      case "$L" in *"|$ID"*) continue ;; esac
      R="$AC/data/.running.json"
      if [ -f "$R" ] && [ $(( $(date +%s) - $(stat -c %Y "$R") )) -lt 90 ]; then continue; fi
      term "$AC/啟動-Linux.sh" || sh "$AC/啟動-Linux.sh" --no-open >/dev/null 2>&1 &
    done
    L="$NOW"; sleep 5
  done ;;
esac
