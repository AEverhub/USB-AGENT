﻿# T-Dongle-S3 小螢幕：把狀態和進度傳給 Dongle（沒有插 Dongle 就什麼都不做）
# 用法：. dongle.ps1 之後呼叫 Dongle-Open / Dongle-Say / Dongle-Close
$script:DongleSp = $null
function Dongle-Open {
  try {
    $n = (Get-CimInstance Win32_PnPEntity | Where-Object { $_.PNPDeviceID -match 'VID_303A' -and $_.Name -match '\(COM\d+\)' } | Select-Object -First 1).Name
    if (-not $n) { return $false }
    $com = [regex]::Match($n, 'COM\d+').Value
    $sp = New-Object System.IO.Ports.SerialPort $com, 115200
    $sp.Encoding = [Text.Encoding]::UTF8; $sp.NewLine = "`n"; $sp.DtrEnable = $true; $sp.WriteTimeout = 1000
    $sp.Open(); $script:DongleSp = $sp; return $true
  } catch { $script:DongleSp = $null; return $false }
}
function Dongle-Say([string]$k, [string]$v) { if ($script:DongleSp) { try { $script:DongleSp.WriteLine("$k $v") } catch { $script:DongleSp = $null } } }
function Dongle-Screen([string]$state, [string]$title, [string]$l1 = '', [string]$l2 = '') {
  if ($state) { Dongle-Say 'S' $state }; if ($title) { Dongle-Say 'T' $title }; Dongle-Say '1' $l1; Dongle-Say '2' $l2; Dongle-Say 'P' '0 0'
}
function Dongle-Close { if ($script:DongleSp) { try { $script:DongleSp.Close() } catch {}; $script:DongleSp = $null } }
