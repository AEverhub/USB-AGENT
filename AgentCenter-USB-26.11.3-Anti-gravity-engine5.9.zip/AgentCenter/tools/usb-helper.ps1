﻿param([ValidateSet('install','uninstall','watch')][string]$Action = 'install', [string]$Usb = '')
# Agent 中控中心 USB 專版：自動啟動小幫手（Windows）
#  install   ：把小幫手裝到這台電腦（不需要管理員權限），登入後在背景執行；插上「這支」USB 就自動打開啟動程式
#  uninstall ：移除小幫手
#  watch     ：（小幫手自己用）每 4 秒看一次有沒有插上已登記的 USB
$ErrorActionPreference = 'Stop'
$Home2 = Join-Path $env:LOCALAPPDATA 'AgentCenterUSB'
$IdsFile = Join-Path $Home2 'ids.txt'   # 注意：PowerShell 變數不分大小寫，不能跟下面的 $ids（清單）同名
$Startup = Join-Path ([Environment]::GetFolderPath('Startup')) 'AgentCenterUSB.vbs'
$Log = Join-Path $Home2 'watch.log'
function Log([string]$m) { try { $line = (Get-Date -Format 'MM-dd HH:mm:ss') + ' ' + $m; Add-Content -Path $Log -Value $line -Encoding UTF8; if ((Get-Item $Log).Length -gt 200KB) { $k = Get-Content $Log -Tail 300; Set-Content $Log $k -Encoding UTF8 } } catch {} }

function Stop-Watcher {
  try { Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" | Where-Object { $_.CommandLine -like '*AgentCenterUSB*watch.ps1*-Action watch*' } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue } } catch {}
}

if ($Action -eq 'install') {
  $ac = $Usb.TrimEnd('\')
  if (-not (Test-Path (Join-Path $ac 'app\portable.js'))) { Write-Host "找不到 AgentCenter 程式：$ac"; exit 1 }
  $idFile = Join-Path $ac 'usb-id'
  if (-not (Test-Path $idFile)) { [IO.File]::WriteAllText($idFile, [guid]::NewGuid().ToString('N')) }
  $id = ([IO.File]::ReadAllText($idFile)).Trim()
  New-Item -ItemType Directory -Path $Home2 -Force | Out-Null
  Copy-Item $PSCommandPath (Join-Path $Home2 'watch.ps1') -Force
  $old = @(); if (Test-Path $IdsFile) { $old = Get-Content $IdsFile | Where-Object { $_ } }
  if ($old -notcontains $id) { Add-Content -Path $IdsFile -Value $id -Encoding ASCII }
  $cmd = 'powershell.exe -NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File "' + (Join-Path $Home2 'watch.ps1') + '" -Action watch'
  $vbs = 'CreateObject("WScript.Shell").Run "' + $cmd.Replace('"', '""') + '", 0, False'
  [IO.File]::WriteAllText($Startup, $vbs, [Text.Encoding]::Unicode)
  Stop-Watcher
  Start-Process -FilePath 'wscript.exe' -ArgumentList ('"' + $Startup + '"') -WindowStyle Hidden
  Log "安裝：登記 $id"
  Start-Sleep -Seconds 3
  $w = Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" | Where-Object { $_.CommandLine -like '*AgentCenterUSB*watch.ps1*-Action watch*' }
  if (-not $w) { Write-Host '⚠ 背景小幫手沒有跑起來（可能被防毒軟體擋了）。請把這個視窗的畫面告訴 AI。' -ForegroundColor Yellow; Log '安裝後沒看到背景程式' } else { Write-Host "（背景小幫手執行中，PID $($w[0].ProcessId)）" }
  Write-Host "✓ 已安裝自動啟動小幫手。之後在這台電腦插上這支 USB（有網路時還會自動整理檔案），就會自動打開啟動程式。"
  Write-Host "  要移除：執行 USB 裡的「移除自動啟動-Windows.bat」"
  exit 0
}

if ($Action -eq 'uninstall') {
  Stop-Watcher
  Remove-Item $Startup -Force -ErrorAction SilentlyContinue
  Remove-Item $Home2 -Recurse -Force -ErrorAction SilentlyContinue
  Write-Host "✓ 已從這台電腦移除自動啟動小幫手。"
  exit 0
}

# ---- watch ----
# 背景程式開的視窗 Windows 通常不給焦點（會躲在後面或只在工作列閃）→ 用標題找到啟動視窗，拉到最前面，讓你可以直接輸入密碼
try { Add-Type -Namespace AC -Name W -MemberDefinition @'
[DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
[DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr h, int n);
[DllImport("user32.dll")] public static extern bool IsIconic(IntPtr h);
[DllImport("user32.dll")] public static extern void keybd_event(byte vk, byte scan, uint flags, UIntPtr extra);
'@ } catch { Log ('Add-Type 失敗：' + $_.Exception.Message) }
function Focus-Window([string]$title) {
  if (-not ('AC.W' -as [type])) { return }
  for ($t = 0; $t -lt 30; $t++) {
    Start-Sleep -Milliseconds 500
    $p = Get-Process | Where-Object { $_.MainWindowTitle -like "*$title*" } | Select-Object -First 1
    if ($p -and $p.MainWindowHandle -ne [IntPtr]::Zero) {
      $h = $p.MainWindowHandle
      if ([AC.W]::IsIconic($h)) { [void][AC.W]::ShowWindow($h, 9) }
      [AC.W]::keybd_event(0x12, 0, 0, [UIntPtr]::Zero); [AC.W]::keybd_event(0x12, 0, 2, [UIntPtr]::Zero)   # 按一下 Alt：Windows 才允許把別的視窗拉到前面
      $ok = [AC.W]::SetForegroundWindow($h); Log "拉到前面：$ok"; return
    }
  }
}
# ---- watch ----
$mutex = New-Object Threading.Mutex($false, 'Local\AgentCenterUSBWatch')
if (-not $mutex.WaitOne(0)) { Log '已經有一個在跑，這個結束'; exit 0 }
Log "開始監看（PID $PID）"
$launched = @{}
$sys = ($env:SystemDrive + '\').ToUpper()
while ($true) {
  try {
    $ids = @(); if (Test-Path $IdsFile) { $ids = Get-Content $IdsFile | Where-Object { $_ } | ForEach-Object { $_.Trim() } }
    $seen = @{}
    foreach ($d in [IO.DriveInfo]::GetDrives()) {
      if (-not $d.IsReady -or $d.Name.ToUpper() -eq $sys) { continue }
      $ac = Join-Path $d.Name 'AgentCenter'; $idf = Join-Path $ac 'usb-id'
      if (-not (Test-Path $idf)) { continue }
      $id = ([IO.File]::ReadAllText($idf)).Trim(); if ($ids -notcontains $id) { continue }
      $key = $d.Name + '|' + $id; $seen[$key] = $true
      if ($launched.ContainsKey($key)) { continue }
      $launched[$key] = $true; Log "看到 USB $($d.Name)"
      $run = Join-Path $ac 'data\.running.json'
      if ((Test-Path $run) -and ((Get-Date) - (Get-Item $run).LastWriteTime).TotalSeconds -lt 90) { Log '已經在執行，不重開'; continue }
      $bat = Get-ChildItem -Path $ac -Filter '*-Windows.bat' | Where-Object { $_.Name -like '啟動-*' } | Select-Object -First 1
      if ($bat) { Start-Process -FilePath $bat.FullName -WorkingDirectory $ac; Log "開啟 $($bat.FullName)"; Focus-Window 'Agent Center USB' } else { Log "找不到啟動檔：$ac" }
    }
    foreach ($k in @($launched.Keys)) { if (-not $seen.ContainsKey($k)) { $launched.Remove($k); Log "USB 拔掉了：$k" } }
  } catch { Log ('錯誤：' + $_.Exception.Message) }
  Start-Sleep -Seconds 4
}
