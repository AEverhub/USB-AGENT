﻿param([Parameter(Mandatory=$true)][string]$Dest, [string]$Arch = 'x64')
# 第一次啟動時下載 Node.js（官方網站 nodejs.org，下載後比對官方 SHA-256 才使用）
$ErrorActionPreference = 'Stop'
$dl = Join-Path $PSScriptRoot 'dongle.ps1'; if (Test-Path $dl) { . $dl; [void](Dongle-Open) } else { function Dongle-Say($k, $v) {}; function Dongle-Screen($a, $b, $c, $d) {}; function Dongle-Close {} }
try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 } catch {}
$base = 'https://nodejs.org/dist/latest-v22.x/'
if ($env:NODE_MIRROR) { $base = $env:NODE_MIRROR }
try {
  $wc = New-Object System.Net.WebClient
  $sums = $wc.DownloadString($base + 'SHASUMS256.txt')
  $line = ($sums -split "`n" | Where-Object { $_ -match "node-v[\d.]+-win-$Arch\.zip\s*$" } | Select-Object -First 1)
  if (-not $line) { throw "找不到 win-$Arch 的 Node.js" }
  $parts = $line.Trim() -split '\s+'; $hash = $parts[0]; $name = $parts[1]
  $tmp = Join-Path $env:TEMP ('agent-node-' + [guid]::NewGuid().ToString('N'))
  New-Item -ItemType Directory -Path $tmp | Out-Null
  $zip = Join-Path $tmp $name
  Write-Host "下載 $name ..."
  Dongle-Screen 'busy' '下載 Node.js' '' ''
  # engine5.9：最多等 5 分鐘（網路斷掉會自動接著下載）；視窗上也顯示進度
  $limit = 300; $sw = [Diagnostics.Stopwatch]::StartNew(); $got = [int64]0; $total = [int64]-1; $last = -1; $lastShow = -1; $buf = New-Object byte[] 262144
  $out = [IO.File]::Create($zip)
  try {
    while ($true) {
      $left = $limit - [int]$sw.Elapsed.TotalSeconds
      if ($left -le 0) { throw "下載超過 5 分鐘還沒完成（已下載 $([math]::Round($got / 1MB, 1)) MB），先停止。網路順一點再啟動一次" }
      try {
        $req = [Net.HttpWebRequest]::Create($base + $name); $req.Timeout = $left * 1000; $req.ReadWriteTimeout = [math]::Min(60, $left) * 1000
        if ($got -gt 0) { $req.AddRange($got) }
        $res = $req.GetResponse(); if ($total -lt 0) { $total = [int64]$res.ContentLength + $got }
        if ($got -gt 0 -and [int]$res.StatusCode -ne 206) { $got = 0; $out.SetLength(0); $total = [int64]$res.ContentLength }   # 伺服器不支援接續 → 從頭來
        $in = $res.GetResponseStream()
        while (($n = $in.Read($buf, 0, $buf.Length)) -gt 0) {
          $out.Write($buf, 0, $n); $got += $n
          if ($sw.Elapsed.TotalSeconds -gt $limit) { throw '逾時' }
          if ($total -gt 0) { $p = [int](100 * $got / $total); if ($p -ne $last) { $last = $p; Dongle-Say 'P' "$p 100"; Dongle-Say '1' "下載 Node.js $p%" }
            $t = [int]$sw.Elapsed.TotalSeconds; if ($t -ne $lastShow) { $lastShow = $t; $sp = $got / [math]::Max(1, $sw.Elapsed.TotalSeconds); $eta = if ($sp -gt 0) { [int](($total - $got) / $sp) } else { 0 }
              Write-Host -NoNewline ("`r  {0,3}%  {1:N1} / {2:N1} MB  {3:N1} MB/s  還要約 {4} 秒（最多等 5 分鐘）   " -f $p, ($got / 1MB), ($total / 1MB), ($sp / 1MB), $eta) } }
        }
        $in.Close(); $res.Close()
        if ($total -le 0 -or $got -ge $total) { break }
      } catch {
        if ($sw.Elapsed.TotalSeconds -ge $limit) { throw "下載超過 5 分鐘還沒完成（已下載 $([math]::Round($got / 1MB, 1)) MB），先停止。網路順一點再啟動一次" }
        Write-Host ''; Write-Host "  網路中斷，接著下載…（$($_.Exception.Message)）"; Start-Sleep -Seconds 2
      }
    }
  } finally { $out.Close() }
  Write-Host ''
  $got = (Get-FileHash -Algorithm SHA256 $zip).Hash.ToLower()
  if ($got -ne $hash.ToLower()) { throw "檔案檢查碼不符，可能下載不完整或被竄改，已放棄" }
  Expand-Archive -Path $zip -DestinationPath $tmp -Force
  $src = Join-Path $tmp ($name -replace '\.zip$', '')
  New-Item -ItemType Directory -Path $Dest -Force | Out-Null
  Copy-Item (Join-Path $src 'node.exe') (Join-Path $Dest 'node.exe') -Force
  Copy-Item (Join-Path $src 'LICENSE') (Join-Path $Dest 'LICENSE') -Force -ErrorAction SilentlyContinue
  Remove-Item $tmp -Recurse -Force -ErrorAction SilentlyContinue
  Write-Host "Node.js 已放進 USB：$Dest"
  Dongle-Screen 'boot' '啟動中…' '' ''; Dongle-Close
} catch {
  Write-Host ("下載 Node.js 失敗：" + $_.Exception.Message)
  Dongle-Screen 'error' '下載 Node 失敗' '檢查網路' ''; Dongle-Close
  exit 1
}
