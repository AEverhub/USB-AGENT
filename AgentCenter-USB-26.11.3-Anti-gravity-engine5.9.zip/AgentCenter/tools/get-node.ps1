﻿param([Parameter(Mandatory=$true)][string]$Dest, [string]$Arch = 'x64')
# 第一次啟動時下載 Node.js（官方網站 nodejs.org，下載後比對官方 SHA-256 才使用）
$ErrorActionPreference = 'Stop'
$dl = Join-Path $PSScriptRoot 'dongle.ps1'; if (Test-Path $dl) { . $dl; [void](Dongle-Open) } else { function Dongle-Say($k, $v) {}; function Dongle-Screen($a, $b, $c, $d) {}; function Dongle-Close {} }
try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 } catch {}
$base = 'https://nodejs.org/dist/latest-v22.x/'
if ($env:NODE_MIRROR) { $base = $env:NODE_MIRROR }
try {
  $wc = New-Object System.Net.WebClient
  $sums = $wc.DownloadString($base + 'SHASUMS256.txt')
  $line = ($sums -split "`n" | Where-Object { $_ -match "node-v[\d.]+-win-$Arch\.zip\s*$" } | Select-Object -First 1)
  if (-not $line) { throw "找不到 win-$Arch 的 Node.js" }
  $parts = $line.Trim() -split '\s+'; $hash = $parts[0]; $name = $parts[1]
  $tmp = Join-Path $env:TEMP ('agent-node-' + [guid]::NewGuid().ToString('N'))
  New-Item -ItemType Directory -Path $tmp | Out-Null
  $zip = Join-Path $tmp $name
  Write-Host "下載 $name ..."
  Dongle-Screen 'busy' '下載 Node.js' '' ''
  $req = [Net.HttpWebRequest]::Create($base + $name); $res = $req.GetResponse(); $total = [int64]$res.ContentLength
  $in = $res.GetResponseStream(); $out = [IO.File]::Create($zip); $buf = New-Object byte[] 262144; $got = [int64]0; $last = -1
  while (($n = $in.Read($buf, 0, $buf.Length)) -gt 0) { $out.Write($buf, 0, $n); $got += $n; if ($total -gt 0) { $p = [int](100 * $got / $total); if ($p -ne $last) { $last = $p; Dongle-Say 'P' "$p 100"; Dongle-Say '1' "下載 Node.js $p%" } } }
  $out.Close(); $in.Close(); $res.Close()
  $got = (Get-FileHash -Algorithm SHA256 $zip).Hash.ToLower()
  if ($got -ne $hash.ToLower()) { throw "檔案檢查碼不符，可能下載不完整或被竄改，已放棄" }
  Expand-Archive -Path $zip -DestinationPath $tmp -Force
  $src = Join-Path $tmp ($name -replace '\.zip$', '')
  New-Item -ItemType Directory -Path $Dest -Force | Out-Null
  Copy-Item (Join-Path $src 'node.exe') (Join-Path $Dest 'node.exe') -Force
  Copy-Item (Join-Path $src 'LICENSE') (Join-Path $Dest 'LICENSE') -Force -ErrorAction SilentlyContinue
  Remove-Item $tmp -Recurse -Force -ErrorAction SilentlyContinue
  Write-Host "Node.js 已放進 USB：$Dest"
  Dongle-Screen 'boot' '啟動中…' '' ''; Dongle-Close
} catch {
  Write-Host ("下載 Node.js 失敗：" + $_.Exception.Message)
  Dongle-Screen 'error' '下載 Node 失敗' '檢查網路' ''; Dongle-Close
  exit 1
}
