﻿# engine5.8 啟動流程只跑一次：同一台電腦上已經有 Agent 中控中心的啟動視窗（啟動中或執行中）→ 把那個視窗叫到前面，這個不再開
#   插上 Dongle 自動打字、自動啟動小幫手、手動雙擊、按 Dongle 按鈕……不管被叫幾次，都只會有一個在跑
#   判斷方式：看所有 cmd.exe 的指令列有沒有在跑 AgentCenter\start.bat 或 啟動-*.bat；最早開的那個留下，其他的結束
#   （用指令列判斷，不看視窗標題：Windows 11 的「終端機」裡拿不到 cmd 的標題）
#   回傳：0＝我是唯一的（繼續啟動）、1＝已經有一個了（不要啟動）
param([switch]$Quiet)
try {
  $re = '\\AgentCenter\\(start|啟動-[^\\"]*)\.bat'
  $all = @(Get-CimInstance Win32_Process -Filter "Name='cmd.exe'" | Where-Object { $_.CommandLine -and $_.CommandLine -match $re })
  $me = (Get-CimInstance Win32_Process -Filter "ProcessId=$PID").ParentProcessId
  $mine = $all | Where-Object { $_.ProcessId -eq $me } | Select-Object -First 1
  # 已經跑完、停在「按任意鍵繼續」的舊視窗不算（底下沒有 node／powershell 在跑）
  $busy = { param($p) @(Get-CimInstance Win32_Process -Filter "ParentProcessId=$($p.ProcessId)" | Where-Object { $_.Name -notin @('conhost.exe', 'OpenConsole.exe') }).Count -gt 0 }
  $others = @($all | Where-Object { $_.ProcessId -ne $me -and (& $busy $_) })
  if ($mine) { $others = @($others | Where-Object { $_.CreationDate -lt $mine.CreationDate -or ($_.CreationDate -eq $mine.CreationDate -and $_.ProcessId -lt $mine.ProcessId) }) }
  if (-not $others.Count) { exit 0 }
  $first = $others | Sort-Object CreationDate | Select-Object -First 1
  if (-not $Quiet) { Write-Host 'Agent Center 已經在另一個視窗啟動了，這個視窗不用再開（會自動關閉）。' -ForegroundColor Yellow }
  $sh = New-Object -ComObject WScript.Shell
  if (-not $sh.AppActivate([int]$first.ProcessId)) { [void]$sh.AppActivate('Agent Center USB') }
  exit 1
} catch { exit 0 }   # 判斷不了就照常啟動（不能因為這個開不起來）
