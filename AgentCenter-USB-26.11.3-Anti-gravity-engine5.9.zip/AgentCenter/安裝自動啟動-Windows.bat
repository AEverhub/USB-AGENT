@echo off
rem Install the auto-start helper on THIS computer (no admin needed). Messages are printed by PowerShell.
setlocal
chcp 65001 >nul
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\usb-helper.ps1" -Action install -Usb "%~dp0."
echo.
pause
