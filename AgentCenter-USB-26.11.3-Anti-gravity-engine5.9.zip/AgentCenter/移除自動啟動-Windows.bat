@echo off
rem Remove the auto-start helper from THIS computer (no admin needed). Messages are printed by PowerShell.
setlocal
chcp 65001 >nul
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\usb-helper.ps1" -Action uninstall
echo.
pause
