#!/bin/sh
# 在 Finder 雙擊就會開「終端機」執行
cd "$(dirname "$0")" || exit 1
/bin/sh ./tools/run.sh "$@"
echo
printf "按 Enter 關閉視窗..."; read _
