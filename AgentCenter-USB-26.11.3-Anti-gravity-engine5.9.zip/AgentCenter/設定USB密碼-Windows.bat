@echo off
rem Agent Center USB launcher (Windows). All messages are printed by Node in UTF-8.
setlocal
chcp 65001 >nul
title Agent Center USB
cd /d "%~dp0"
set "ARCH=x64"
if /i "%PROCESSOR_ARCHITECTURE%"=="ARM64" set "ARCH=arm64"
set "NODEDIR=%~dp0node\win-%ARCH%"
set "NODE=%NODEDIR%\node.exe"
if exist "%NODE%" goto cache
echo First run: downloading Node.js to the USB (30-50 MB, only once)...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\get-node.ps1" -Dest "%NODEDIR%" -Arch %ARCH%
if exist "%NODE%" goto cache
where node >nul 2>nul
if errorlevel 1 goto nonode
echo Download failed, using the Node.js installed on this computer.
set "NODE=node"
goto run
:nonode
echo.
echo Node.js download failed and this computer has no Node.js.
echo Check the internet connection and run this again, or install Node.js 18+ from https://nodejs.org
pause
exit /b 1
:cache
rem Copy node.exe to this computer once: reading 30-80 MB from a USB stick / T-Dongle every start is slow.
set "CACHE=%LOCALAPPDATA%\AgentCenterNode\win-%ARCH%"
set "S1=" & set "S2="
for %%A in ("%NODE%") do set "S1=%%~zA"
if exist "%CACHE%\node.exe" for %%A in ("%CACHE%\node.exe") do set "S2=%%~zA"
if "%S1%"=="%S2%" goto usecache
echo Copying Node.js to this computer (only once)...
mkdir "%CACHE%" 2>nul
copy /y "%NODE%" "%CACHE%\node.exe" >nul
:usecache
if exist "%CACHE%\node.exe" set "NODE=%CACHE%\node.exe"
:run
"%NODE%" "%~dp0app\portable.js" --change-password %*
echo.
pause
