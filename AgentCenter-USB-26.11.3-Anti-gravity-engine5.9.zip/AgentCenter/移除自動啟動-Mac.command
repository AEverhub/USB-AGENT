#!/bin/sh
cd "$(dirname "$0")" || exit 1
/bin/sh ./tools/usb-helper-mac.sh uninstall
printf "按 Enter 關閉視窗..."; read _
