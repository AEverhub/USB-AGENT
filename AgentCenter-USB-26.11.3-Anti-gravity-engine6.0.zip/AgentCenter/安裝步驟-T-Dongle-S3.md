# Agent 中控中心 USB 版：安裝步驟（LilyGO T-Dongle-S3）

版本：26.11.3-Anti-gravity-engine6.0
用一般 USB 隨身碟的話，請看另一份 `安裝步驟-一般USB.md`。

## 它怎麼運作

T-Dongle-S3 的韌體只負責**引導**，AI 和所有功能都在 **TF 卡**上、在電腦上執行（TF 卡就是那支「USB」）：

1. 插上 Windows 電腦 → 電腦看到一支隨身碟（TF 卡）。
2. 約 6 秒後，Dongle 假裝成鍵盤，開 PowerShell 打入一行引導指令。
3. TF 卡**還沒有軟體** → 從你設定的網址下載、檢查 SHA-256、裝進 TF 卡；**已經有** → 直接啟動（有網路時順便檢查新版，更新不動你的資料）。
4. 小螢幕顯示狀態：找 TF 卡、下載軟體 37%、安裝中、請輸入密碼、AI 就緒、整理檔案 12/40、已存檔可以拔除……

> AI 裝不進 Dongle 本身：它只有 512 KB 記憶體、沒有 PSRAM。Dongle ＝ 鑰匙＋儲存空間＋狀態螢幕。

## 你需要

- LilyGO T-Dongle-S3（有螢幕的版本）＋ TF 卡（例如 64 GB）
- 一台 Windows 電腦，裝 **Arduino IDE 2**（只有燒錄韌體時需要）
- 一把 AI 金鑰（Google Gemini 有免費額度：https://aistudio.google.com/apikey）
- 想讓**空白 TF 卡自動安裝**：一個放檔案的網址（GitHub Releases 免費）。不想放網路也可以，見「做法 B」。

---

## 一、準備 TF 卡

把 TF 卡格式化成 **exFAT**（用讀卡機，或等韌體燒好後插著 Dongle，在檔案總管對新磁碟按右鍵 → 格式化）。

接下來二選一：

### 做法 A：自動下載安裝（推薦，之後也會自動更新）

1. 把 zip 裡 **`上傳用/`** 的三個檔案（`AgentCenter-USB-….zip`、`latest.json`、`boot.ps1`）上傳到同一個網址底下。
   最簡單：在 GitHub 建一個 Release，把三個檔案當附件上傳，網址就是
   `https://github.com/<你的帳號>/<專案>/releases/latest/download/`
2. 記下這個網址（結尾要有 `/`），第二節燒韌體時填進去。
3. TF 卡保持空的就好。

⚠ 自動下載＝執行網路上的程式。**只填你自己能控制的網址**；網址被別人控制，等於讓別人在你的電腦上執行程式。

### 做法 B：自己複製（不用網路空間）

把 zip 裡的 **`AgentCenter` 資料夾整個複製到 TF 卡根目錄**（等複製視窗跑完）。韌體的網址留空。插上照樣自動啟動，只是不會自動安裝或更新。

## 二之一、燒錄韌體：用瀏覽器（推薦，不用裝 Arduino）

1. 把 `原始碼/agent-26.6.0/tdongle/web-flash/` 整個資料夾上傳到你的 GitHub 存放庫，資料夾名稱改成 `flash`。
2. 存放庫「Settings → Pages」：Source 選 **Deploy from a branch**、Branch 選 **main / (root)** → Save。
3. 一兩分鐘後用電腦版 Chrome／Edge 打開 `https://你的帳號.github.io/存放庫名稱/flash/`。
4. 按住 Dongle 按鈕插上電腦 → 按「開始燒錄」→ 選裝置 → 安裝。網頁上有完整步驟。

這份韌體已經把下載網址編進去了（`https://raw.githubusercontent.com/AEverhub/USB-AGENT/main/`）。要換網址就用下面 Arduino 的方式自己編。

## 二、燒錄韌體：用 Arduino IDE（要改設定時才需要，約 15 分鐘）

1. Arduino IDE 2 →「開發板管理員」安裝 **esp32 by Espressif Systems**（3.x 版）。
2. 「程式庫管理員」安裝 **Adafruit ST7735 and ST7789 Library**、**Adafruit GFX Library**。
3. 打開 `原始碼/agent-26.6.0/tdongle/AgentDongle/AgentDongle.ino`，在 `config.h` 填：
   ```c
   #define BOOT_BASE_URL "https://github.com/<你的帳號>/<專案>/releases/latest/download/"   // 做法 B 留 ""
   ```
4. Tools 選單設定：
   | 項目 | 選 |
   |---|---|
   | Board | **ESP32S3 Dev Module** |
   | USB Mode | **USB-OTG (TinyUSB)** |
   | USB CDC On Boot | **Disabled** |
   | Flash Size | **16MB** |
   | PSRAM | **Disabled** |
5. **按住 Dongle 的按鈕再插上電腦**（進入下載模式）→ 選序列埠 → 按「上傳」。
6. 燒完拔掉，把 TF 卡插進 Dongle。

## 三、第一次插上（約 5～15 分鐘，只有第一次）

1. **電腦要在解鎖狀態**（已經進入桌面），插上 Dongle。
2. 約 6 秒後會自己打開「執行」視窗打一行字（約 10 秒），**不要動鍵盤滑鼠**；不用管現在是中文還是英文輸入法。
3. 做法 A：螢幕顯示「下載軟體 xx%」→「安裝到 TF 卡」。ESP32-S3 的 USB 每秒約 1 MB，要幾分鐘。
4. 接著下載 Node.js（約 35 MB），並複製一份到電腦上（之後啟動就快）。
5. 啟動視窗問 **USB 密碼**（建議設，輸入 `y` → 兩次密碼）和 **AI 金鑰**（`1` = Gemini → 貼上）。
6. 瀏覽器自動打開控制台，螢幕顯示「AI 就緒」。

之後每次插上（任何 Windows 電腦，不用先裝小幫手）都會自動開，只要輸入 USB 密碼。

## 開發版（選用）

燒錄頁有「開發版」按鈕。開發版多了：在控制台跟 AI 說「把 D 槽的畢旅照片複製到 TF 卡」「把桌面的舊專案搬到 TF 卡」「看一下電腦有哪些磁碟」，AI 會幫你找、複製或搬運。

- 搬運（原檔會刪）一定會先跟你確認，確認內容一樣才刪原檔。
- 系統資料夾（Windows、Program Files、AppData…）不能動；TF 卡上的 AgentCenter 不會被複製出去。
- 預設放到 TF 卡的「從電腦複製／電腦名稱」資料夾。

## 四、按鈕

| 操作 | 作用 |
|---|---|
| 短按 | AI 還沒開（電腦沒回應）時＝再試一次；AI 開了之後＝看目前狀態（**每次插上只會開一次 AI**） |
| 長按 3 秒 | 下次插上先檢查更新（只用一次） |
| 長按 8 秒 | 開／關「插上自動啟動」（會記住；關掉後要按按鈕才啟動） |

## 手機連線（開發版預設開）

手機和電腦連**同一個 Wi-Fi**，用手機相機掃電腦啟動視窗上的 QR Code：
- 手機上就能跟 AI 說話（「把 D 槽的畢旅照片複製到 TF 卡」）。
- 「檔案頁」：看 TF 卡和電腦的 C:、D:，點「下載」存到手機，點「→USB」複製到 TF 卡，「上傳到這裡」把手機的照片存進 TF 卡。
- Windows 第一次會問防火牆：勾「私人網路」並允許。
- 只在家裡或信任的 Wi-Fi 用；每次重開 QR Code 都會換新的。一般版要用就跟 AI 說「開手機連線」。

## 五、平常怎麼用

跟一般 USB 版一樣，在控制台跟 AI 說：「整理一下 USB」「復原整理」「我的期末報告找不到，幫我拿出來」「存回去」。整理時螢幕會顯示進度。

**讓 iPhone／iPad 也能用**：控制台「更多 → 開發者 → 聯機」設為主機並啟動 Bot；把 `網頁版/index.html` 放到 GitHub Pages、網址填進「聯機碼產生器」，就會出現 QR Code 讓對方用相機掃（細節見 `安裝步驟-一般USB.md` 第四節）。

## 六、拔除

1. 在啟動視窗按 **Ctrl+C**，螢幕顯示「已存檔」。
2. 工作列「安全移除硬體」→ 螢幕顯示「已退出」（藍燈）。
3. 拔掉。

## 七、Mac／Linux

用鍵盤打字的引導只支援 Windows。Mac／Linux：在電腦上執行一次 TF 卡裡 `AgentCenter` 的「安裝自動啟動」（Mac：`安裝自動啟動-Mac.command`；Linux：`sh 安裝自動啟動-Linux.sh`），之後插上會自動開；小螢幕的狀態顯示照樣有效。

## 八、遇到問題

| 狀況 | 怎麼辦 |
|---|---|
| 插在鎖定畫面 | 打的字可能跑進密碼欄（算一次登入失敗）。長按按鈕 8 秒關掉自動啟動，進桌面後再短按 |
| 擔心注音輸入法 | 不用管：Dongle 用 Alt＋數字鍵盤打字，中文輸入法不會攔截。插上後就一直等電腦回應；真的沒反應就按一下按鈕再試 |
| 插上沒跳出視窗（公司電腦、防毒） | 可能擋了新鍵盤裝置或 PowerShell。直接雙擊 TF 卡裡的 `AgentCenter\start.bat` |
| 螢幕全黑 | 韌體裡的 `LCD_BL_ON` 改成 `HIGH` 重燒 |
| 畫面偏移或顏色反了 | 韌體裡 `INITR_MINI160x80_PLUGIN` 改成 `INITR_MINI160x80` 重燒 |
| 停在「下載軟體」很久 | 檢查 `BOOT_BASE_URL` 是否正確、結尾有 `/`；在瀏覽器打開「網址 + latest.json」看得到內容才對 |
| 啟動視窗出現紅字 | 把整段訊息貼給 AI |

## ⚠ 目前狀態（老實說）

- **韌體還沒有在實機上測過**：只做過 C++ 語法檢查；PowerShell 引導程式也還沒在 Windows 上實跑。第一次用請在旁邊看著，有問題把螢幕畫面和視窗訊息拍給 AI。
- TF 卡上的 USB 版本身（啟動、密碼、金鑰、自動整理）和一般 USB 版是同一套，已經在 Windows 上實測過。
- 安全性同一般 USB 版：USB 密碼只加密金鑰類資料；不要在不信任的電腦上使用。
