'use strict';
/**
 * engine6.0：手機連線（區域網路 HTTP 伺服器）
 *   手機和電腦連同一個 Wi-Fi → 掃 QR Code → 手機上就能用：
 *     ・/        完整控制台（跟 AI 對話、下指令搬檔案）——轉送到本機的控制 API，手機用自己的「手機碼」，拿不到電腦上的管理 token
 *     ・/files   檔案頁：看 USB／這台電腦的磁碟（C:、D:…）、點一下下載到手機、把電腦的檔案複製到 USB、從手機上傳到 USB
 *   安全：
 *     ・預設關閉（開發版預設開）；開關：設定 phone_link.enabled、AI 工具 phone_access、控制台
 *     ・只接受區域網路的連線（192.168.x.x、10.x.x.x、172.16-31.x.x、169.254.x.x、IPv6 本地位址）
 *     ・手機碼每次開啟都換新的（舊的 QR Code 立刻失效）；猜錯太多次（每分鐘 20 次）會暫時封鎖那台裝置
 *     ・電腦的檔案規則跟 pcfiles 一樣（系統資料夾不能看，電腦檔案只有開發版能看）；USB 上的 AgentCenter（金鑰）永遠看不到
 *     ・不是 https：同一個 Wi-Fi 上有心人可以竊聽，請只在自己家裡／信任的網路開
 */
const http = require('http');
const fs = require('fs');
const os = require('os');
const path = require('path');
const crypto = require('crypto');
const { logger } = require('../core/log');
const log = logger('phone');

const PRIVATE = /^(::ffff:)?(10\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.|169\.254\.|127\.)|^::1$|^f[cd][0-9a-f]{2}:|^fe80:/i;
const human = (n) => (n >= 1024 ** 3 ? (n / 1024 ** 3).toFixed(1) + ' GB' : n >= 1048576 ? (n / 1048576).toFixed(1) + ' MB' : Math.max(1, Math.round(n / 1024)) + ' KB');

/** 這台電腦在區域網路上的位址（Wi-Fi／有線，排除虛擬網卡） */
function lanIps() {
  const out = [];
  for (const [name, list] of Object.entries(os.networkInterfaces())) {
    if (/vmware|virtualbox|vbox|hyper-v|vethernet|docker|wsl|loopback|tailscale|zerotier|utun|br-|veth/i.test(name)) continue;
    for (const a of list || []) if (a.family === 'IPv4' && !a.internal && PRIVATE.test(a.address) && !a.address.startsWith('169.254.')) out.push({ name, ip: a.address });
  }
  out.sort((a, b) => (/wi-?fi|wlan|無線/i.test(b.name) - /wi-?fi|wlan|無線/i.test(a.name)) || (a.ip.startsWith('192.168.') ? -1 : 1));
  return out;
}

class Phone {
  constructor(ctx) { this.ctx = ctx; this.server = null; this.port = 0; this.code = ''; this.fails = new Map(); this.apiPort = 0; }
  get S() { return this.ctx.settings; }
  edition() { return this.ctx.pc ? this.ctx.pc.edition() : 'normal'; }
  wanted() { const v = this.S.get('phone_link.enabled', ''); return v === true || v === 'true' || ((v === '' || v == null) && this.edition() === 'dev'); }
  running() { return !!this.server; }
  urls() { return lanIps().map((x) => ({ ...x, url: `http://${x.ip}:${this.port}/#t=${this.code}`, files: `http://${x.ip}:${this.port}/files#t=${this.code}` })); }
  status() { return { enabled: this.wanted(), running: this.running(), port: this.port, urls: this.running() ? this.urls() : [], pc: !!(this.ctx.pc && this.ctx.pc.enabled()) }; }

  /** 開啟（apiPort＝本機控制 API 的埠）；已經開著就換一個新的手機碼 */
  async start(apiPort = this.apiPort) {
    this.apiPort = apiPort || (this.ctx.api && this.ctx.api.port) || 0; if (!this.apiPort) throw new Error('控制台還沒啟動');
    this.code = crypto.randomBytes(20).toString('hex');   // 十六進位：控制台網頁只認這種格式
    if (this.server) return this.status();
    const want = +this.S.get('phone_link.port', 8790) || 8790;
    this.server = http.createServer((req, res) => this.handle(req, res).catch((e) => { log.warn(e.message); if (!res.headersSent) this.json(res, 500, { error: e.message }); }));
    this.server.requestTimeout = 0; this.server.headersTimeout = 30000;   // 大檔案上傳／下載不要逾時
    for (let p = want; p < want + 20; p++) {
      const ok = await new Promise((r) => { this.server.once('error', () => r(false)); this.server.listen(p, '0.0.0.0', () => r(true)); });
      if (ok) { this.port = p; break; }
    }
    if (!this.port) { this.server = null; throw new Error(`${want} 附近的連接埠都被占用了`); }
    log.info(`手機連線：${this.urls().map((u) => `http://${u.ip}:${this.port}`).join('、') || '（找不到區域網路位址）'}`);
    this.screen();
    return this.status();
  }
  stop() { if (this.server) { try { this.server.close(); this.server.closeAllConnections && this.server.closeAllConnections(); } catch { /* ignore */ } } this.server = null; this.port = 0; this.code = ''; }
  screen() { const td = this.ctx.tdongle; const u = this.urls()[0]; if (td && td.fd != null && u) td.screen({ l2: `手機 ${u.ip}:${this.port}` }); }

  json(res, code, obj) { res.writeHead(code, { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' }); res.end(JSON.stringify(obj)); }
  _tok(req, url) { return (req.headers.authorization || '').replace(/^Bearer\s+/i, '') || url.searchParams.get('t') || ''; }
  _ok(tok) { const a = Buffer.from(String(tok)), b = Buffer.from(this.code); return !!this.code && a.length === b.length && crypto.timingSafeEqual(a, b); }

  async handle(req, res) {
    const ip = String(req.socket.remoteAddress || '');
    if (!PRIVATE.test(ip)) { res.writeHead(403); return res.end('只接受同一個區域網路的連線'); }
    const url = new URL(req.url, 'http://x'); const p = url.pathname;
    const f = this.fails.get(ip); if (f && f.n >= 20 && Date.now() - f.at < 60e3) return this.json(res, 429, { error: '猜錯太多次，等一分鐘再試' });
    if (p === '/files' || p === '/files/') { res.writeHead(200, { 'content-type': 'text/html; charset=utf-8', 'cache-control': 'no-store' }); return res.end(FILES_PAGE); }
    const needAuth = p.startsWith('/api/') || p.startsWith('/files/');
    if (needAuth) {
      if (!this._ok(this._tok(req, url))) { const g = this.fails.get(ip) || { n: 0, at: 0 }; if (Date.now() - g.at > 60e3) g.n = 0; g.n++; g.at = Date.now(); this.fails.set(ip, g); return this.json(res, 401, { error: '手機碼不對或過期了：請在電腦上重新掃 QR Code' }); }
      this.fails.delete(ip);
    }
    if (p.startsWith('/files/')) return this.files(p.slice(7), url, req, res);
    return this.proxy(req, res, url);
  }

  /** 轉送到本機控制台：手機碼換成真正的 token（手機拿不到） */
  proxy(req, res, url) {
    if (url.searchParams.has('t')) url.searchParams.set('t', this.ctx.token);
    const headers = { ...req.headers, host: `127.0.0.1:${this.apiPort}` }; delete headers.origin; delete headers.referer;
    if (headers.authorization) headers.authorization = 'Bearer ' + this.ctx.token;
    const up = http.request({ host: '127.0.0.1', port: this.apiPort, method: req.method, path: url.pathname + url.search, headers }, (r) => { res.writeHead(r.statusCode, r.headers); r.pipe(res); });
    up.on('error', (e) => { if (!res.headersSent) this.json(res, 502, { error: '控制台沒有回應：' + e.message }); else res.end(); });
    req.pipe(up);
  }

  /** 位置：「usb:路徑」＝USB 上；「pc:完整路徑」＝這台電腦（開發版） */
  _where(w) {
    const s = String(w || ''); const usb = this.ctx.usb;
    if (!s || s === 'usb:' || s.startsWith('usb:')) { if (!usb || !usb.active()) throw new Error('不是 USB 版'); const abs = usb._abs(s.slice(4)); return { kind: 'usb', abs, root: path.resolve(usb.root()) }; }
    if (s.startsWith('pc:')) { if (!this.ctx.pc || !this.ctx.pc.enabled()) throw new Error('看電腦的磁碟只有開發版能用'); return { kind: 'pc', abs: this.ctx.pc.resolve(s.slice(3)) }; }
    throw new Error('位置格式不對');
  }
  _id(w) { return w.kind === 'usb' ? 'usb:' + path.relative(w.root, w.abs).split(path.sep).join('/') : 'pc:' + w.abs; }

  async files(op, url, req, res) {
    const q = Object.fromEntries(url.searchParams);
    try {
      if (op === 'roots' && req.method === 'GET') {
        const roots = []; const usb = this.ctx.usb;
        if (usb && usb.active()) roots.push({ id: 'usb:', name: 'USB（TF 卡）', note: '' });
        if (this.ctx.pc && this.ctx.pc.enabled()) for (const d of this.ctx.pc.drives()) roots.push({ id: 'pc:' + d.path, name: `電腦 ${d.label}`, note: `剩 ${human(d.free)}／共 ${human(d.size)}` });
        return this.json(res, 200, { roots, pc: !!(this.ctx.pc && this.ctx.pc.enabled()), host: os.hostname() });
      }
      if (op === 'list' && req.method === 'GET') {
        const w = this._where(q.at); let r;
        if (w.kind === 'usb') r = this.ctx.usb.list(path.relative(w.root, w.abs)); else r = this.ctx.pc.list(w.abs);
        const id = this._id(w); const join = (n) => (id.endsWith('/') || id.endsWith(':') || /[\\/]$/.test(id) ? id + n : id + (w.kind === 'pc' ? path.sep : '/') + n);
        const parent = w.kind === 'usb' ? (path.resolve(w.abs) === w.root ? null : this._id({ ...w, abs: path.dirname(w.abs) })) : (path.dirname(w.abs) === w.abs ? null : 'pc:' + path.dirname(w.abs));
        return this.json(res, 200, { at: id, parent, total: r.total, items: r.items.map((x) => ({ ...x, id: join(x.name) })) });
      }
      if (op === 'get' && req.method === 'GET') {
        const w = this._where(q.at); const st = fs.statSync(w.abs); if (!st.isFile()) throw new Error('不是檔案');
        const name = path.basename(w.abs);
        res.writeHead(200, { 'content-type': 'application/octet-stream', 'content-length': st.size, 'content-disposition': `attachment; filename="${encodeURIComponent(name).replace(/['()]/g, escape)}"; filename*=UTF-8''${encodeURIComponent(name)}`, 'cache-control': 'no-store' });
        const td = this.ctx.tdongle; if (td && td.fd != null) td.screen({ state: 'busy', title: '傳到手機', l1: name, total: 0 });
        const s = fs.createReadStream(w.abs); s.pipe(res); s.on('close', () => { if (td && td.fd != null) td.screen({ state: 'ready', title: '傳到手機完成', l1: name }); });
        return;
      }
      if (op === 'copy' && req.method === 'POST') {   // 電腦 → USB（伺服器上直接複製）
        const w = this._where(q.at); if (w.kind !== 'pc') throw new Error('只能把電腦的檔案複製到 USB');
        const r = await this.ctx.pc.transfer({ from: w.abs, to: q.to ? 'USB:' + q.to : undefined, confirm: q.confirm === '1' });
        return this.json(res, 200, r);
      }
      if (op === 'put' && req.method === 'PUT') {      // 手機 → USB
        const usb = this.ctx.usb; if (!usb || !usb.active()) throw new Error('不是 USB 版');
        const dir = usb._abs(q.dir || '手機上傳'); fs.mkdirSync(dir, { recursive: true });
        const name = path.basename(String(q.name || '')).replace(/[\\/:*?"<>|\u0000-\u001f]/g, '_').slice(0, 180); if (!name || name === '.' || name === '..') throw new Error('檔名不對');
        let fin = name; const ext = path.extname(name); const base = name.slice(0, name.length - ext.length); for (let i = 2; fs.existsSync(path.join(dir, fin)); i++) fin = `${base} (${i})${ext}`;
        const tmp = path.join(dir, fin + '.uploading'); const out = fs.createWriteStream(tmp); let n = 0; const max = 4 * 1024 ** 3;
        await new Promise((ok, bad) => { req.on('data', (d) => { n += d.length; if (n > max) { req.destroy(); bad(new Error('檔案太大（上限 4 GB）')); } }); req.pipe(out); out.on('finish', ok); out.on('error', bad); req.on('error', bad); })
          .catch((e) => { try { fs.unlinkSync(tmp); } catch { /* ignore */ } throw e; });
        fs.renameSync(tmp, path.join(dir, fin)); usb._idx = null;
        const td = this.ctx.tdongle; if (td && td.fd != null) td.screen({ state: 'ready', title: '手機上傳完成', l1: fin, total: 0 });
        return this.json(res, 200, { ok: true, saved: path.relative(path.resolve(usb.root()), path.join(dir, fin)), size: n });
      }
      return this.json(res, 404, { error: '沒有這個功能' });
    } catch (e) { return this.json(res, 400, { error: e.message }); }
  }
}

/* 手機檔案頁（單一檔案、不用外部資源） */
const FILES_PAGE = `<!doctype html><html lang="zh-Hant"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<meta name="apple-mobile-web-app-capable" content="yes"><title>檔案</title><style>
:root{--bg:#f6f7f9;--card:#fff;--fg:#1b1f24;--mute:#5c6670;--line:#e3e7eb;--acc:#0b6bcb;--ok:#127a3a;--err:#b42318}
@media (prefers-color-scheme:dark){:root{--bg:#111417;--card:#1a1f24;--fg:#e8ecef;--mute:#9aa5af;--line:#2c343b;--acc:#5aa9ff;--ok:#4cc27a;--err:#ff7b72}}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--fg);font:16px/1.5 system-ui,-apple-system,"PingFang TC","Microsoft JhengHei",sans-serif}
header{position:sticky;top:0;background:var(--bg);padding:12px 16px 8px;border-bottom:1px solid var(--line);z-index:1}
h1{font-size:19px;margin:0}#at{color:var(--mute);font-size:13px;word-break:break-all;margin-top:2px}
.bar{display:flex;gap:8px;margin-top:8px;flex-wrap:wrap}button,.btn{font:inherit;font-size:15px;padding:7px 12px;border-radius:9px;border:1px solid var(--line);background:var(--card);color:var(--fg);cursor:pointer;text-decoration:none}
button.pri{background:var(--acc);color:#fff;border-color:var(--acc)}main{padding:8px 12px 80px}
.it{display:flex;align-items:center;gap:10px;background:var(--card);border:1px solid var(--line);border-radius:10px;padding:10px 12px;margin:6px 0}
.it .n{flex:1;min-width:0;word-break:break-all}.it .m{color:var(--mute);font-size:13px}.ic{font-size:20px;width:26px;text-align:center}
#msg{margin:8px 16px;font-size:14px}#msg.err{color:var(--err)}#msg.ok{color:var(--ok)}.mute{color:var(--mute);font-size:14px}
</style></head><body><header><h1 id="ttl">檔案</h1><div id="at"></div><div class="bar"><button id="up">⬆ 上一層</button><button id="home">🏠 磁碟</button><label class="btn" id="upl" hidden>📤 上傳到這裡<input type="file" id="file" multiple hidden></label><a class="btn" id="chat" href="/">💬 跟 AI 說</a></div></header>
<div id="msg"></div><main id="list"></main>
<script>
const tok=(location.hash.match(/t=([\\w-]+)/)||[])[1]||localStorage.getItem('pt')||'';if(tok){try{localStorage.setItem('pt',tok)}catch{}}
document.getElementById('chat').href='/#t='+tok;
const $=(s)=>document.querySelector(s);let cur=null,parent=null;
const hs=(n)=>n>=1073741824?(n/1073741824).toFixed(1)+' GB':n>=1048576?(n/1048576).toFixed(1)+' MB':Math.max(1,Math.round(n/1024))+' KB';
const say=(t,c='')=>{const m=$('#msg');m.textContent=t;m.className=c};
async function api(p,o={}){const r=await fetch('/files/'+p,{...o,headers:{...(o.headers||{}),authorization:'Bearer '+tok}});const j=await r.json().catch(()=>({error:'連線失敗'}));if(!r.ok)throw new Error(j.error||r.status);return j}
const esc=(s)=>String(s).replace(/[&<>"]/g,(c)=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
async function roots(){cur=null;parent=null;$('#upl').hidden=true;$('#up').disabled=true;say('');try{const j=await api('roots');$('#ttl').textContent='檔案・'+j.host;$('#at').textContent=j.pc?'':'（看電腦的磁碟要用開發版）';
$('#list').innerHTML=j.roots.map((r)=>'<div class="it" data-d="'+esc(r.id)+'"><span class="ic">'+(r.id.startsWith('usb')?'🔑':'💽')+'</span><div class="n">'+esc(r.name)+'<div class="m">'+esc(r.note)+'</div></div></div>').join('')||'<p class="mute">沒有可以看的位置</p>'}catch(e){say(e.message,'err')}}
async function open(at){say('');try{const j=await api('list?at='+encodeURIComponent(at));cur=j.at;parent=j.parent;$('#at').textContent=cur.replace(/^usb:/,'USB／').replace(/^pc:/,'電腦 ');$('#up').disabled=false;$('#upl').hidden=!cur.startsWith('usb:');
$('#list').innerHTML=(j.items.map((x)=>x.dir?'<div class="it" data-d="'+esc(x.id)+'"><span class="ic">📁</span><div class="n">'+esc(x.name)+'</div></div>':'<div class="it"><span class="ic">📄</span><div class="n">'+esc(x.name)+'<div class="m">'+hs(x.size)+'・'+new Date(x.mtime).toLocaleDateString()+'</div></div><a class="btn" href="/files/get?at='+encodeURIComponent(x.id)+'&t='+tok+'" download>下載</a>'+(x.id.startsWith('pc:')?'<button data-c="'+esc(x.id)+'">→USB</button>':'')+'</div>').join('')||'<p class="mute">這裡是空的</p>')+(j.total>j.items.length?'<p class="mute">只列前 '+j.items.length+' 項（共 '+j.total+'）</p>':'')}catch(e){say(e.message,'err')}}
$('#list').onclick=async(e)=>{const d=e.target.closest('[data-d]');const c=e.target.closest('[data-c]');if(c){e.stopPropagation();c.disabled=true;say('複製到 USB 中…');try{let r=await api('copy?at='+encodeURIComponent(c.dataset.c),{method:'POST'});if(r.need_confirm){if(!confirm('共 '+r.count+' 個檔案、'+r.size+'，確定複製到 USB？')){say('');c.disabled=false;return}r=await api('copy?confirm=1&at='+encodeURIComponent(c.dataset.c),{method:'POST'})}say('已複製到 USB：'+r.top.split(/[\\\\/]/).slice(-2).join('/'),'ok')}catch(x){say(x.message,'err')}c.disabled=false;return}if(d)open(d.dataset.d)};
$('#up').onclick=()=>parent?open(parent):roots();$('#home').onclick=roots;
$('#file').onchange=async(e)=>{const dir=cur.slice(4);for(const f of e.target.files){say('上傳 '+f.name+'（'+hs(f.size)+'）…');try{const r=await fetch('/files/put?dir='+encodeURIComponent(dir||'手機上傳')+'&name='+encodeURIComponent(f.name),{method:'PUT',headers:{authorization:'Bearer '+tok},body:f});const j=await r.json();if(!r.ok)throw new Error(j.error);say('已存到 USB：'+j.saved,'ok')}catch(x){say(f.name+'：'+x.message,'err')}}e.target.value='';open(cur)};
if(!tok)say('請在電腦上掃 QR Code 進來','err');else roots();
</script></body></html>`;

/** 在啟動視窗印出手機用的 QR Code（半格字元，兩列擠一行） */
function banner(st) {
  const u = st.urls && st.urls[0]; if (!u) return '\n  手機連線：找不到這台電腦的 Wi-Fi／區域網路位址（電腦要連上網路）\n';
  const m = require('../../ui/qr').matrix(u.url); const n = m.length; const at = (r, c) => r >= 0 && c >= 0 && r < n && c < n && m[r][c];
  const lines = []; for (let r = -2; r < n + 2; r += 2) { let s = '  '; for (let c = -2; c < n + 2; c++) { const a = at(r, c), b = at(r + 1, c); s += a && b ? ' ' : a ? '▄' : b ? '▀' : '█'; } lines.push(s); }
  return `\n  ── 手機連線（手機和這台電腦連同一個 Wi-Fi，用相機掃）──\n${lines.join('\n')}\n  ${u.url}\n  檔案頁（下載電腦／USB 的檔案）：${u.files}\n  Windows 跳出防火牆詢問時，請勾「私人網路」並允許。\n`;
}
module.exports = { Phone, lanIps, PRIVATE, banner };
