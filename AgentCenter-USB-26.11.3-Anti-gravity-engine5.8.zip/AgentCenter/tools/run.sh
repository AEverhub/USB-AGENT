#!/bin/sh
# Agent 中控中心 USB 版：macOS／Linux 共用啟動程式（由 啟動-Mac.command／啟動-Linux.sh 呼叫）
HERE="$(cd "$(dirname "$0")/.." && pwd)"
case "$(uname -s)" in Darwin) plat=darwin ;; Linux) plat=linux ;; *) echo "不支援這個系統：$(uname -s)"; exit 1 ;; esac
case "$(uname -m)" in x86_64|amd64) arch=x64 ;; arm64|aarch64) arch=arm64 ;; armv7l) arch=armv7l ;; *) arch="$(uname -m)" ;; esac
DIR="$HERE/node/$plat-$arch"
NODE="$DIR/node"

fetch() { if command -v curl >/dev/null 2>&1; then curl -fsSL "$1" -o "$2"; else wget -q "$1" -O "$2"; fi; }
sha() { if command -v shasum >/dev/null 2>&1; then shasum -a 256 "$1" | awk '{print $1}'; else sha256sum "$1" | awk '{print $1}'; fi; }

if [ ! -f "$NODE" ]; then
  echo "第一次啟動：下載 Node.js 到 USB（約 30～50 MB，只需要一次）..."
  base="${NODE_MIRROR:-https://nodejs.org/dist/latest-v22.x/}"
  tmp="$(mktemp -d 2>/dev/null || mktemp -d -t agentnode)"
  if fetch "${base}SHASUMS256.txt" "$tmp/sums"; then
    line="$(grep -E " node-v[0-9.]+-$plat-$arch\.tar\.gz$" "$tmp/sums" | head -n 1)"
    hash="$(echo "$line" | awk '{print $1}')"; name="$(echo "$line" | awk '{print $2}')"
    if [ -n "$name" ] && fetch "$base$name" "$tmp/$name" && [ "$(sha "$tmp/$name")" = "$hash" ]; then
      # 只解出 node 本體（USB 常是 exFAT，不支援壓縮檔裡的捷徑）
      tar -xzf "$tmp/$name" -C "$tmp" "${name%.tar.gz}/bin/node" && mkdir -p "$DIR" && cp "$tmp/${name%.tar.gz}/bin/node" "$NODE" && chmod +x "$NODE" 2>/dev/null
      echo "Node.js 已放進 USB：$DIR"
    else
      echo "下載 Node.js 失敗（或檢查碼不符）"
    fi
  else
    echo "連不上 nodejs.org"
  fi
  rm -rf "$tmp"
fi

if [ -f "$NODE" ]; then
  # 把 node 複製到這台電腦一次（USB／T-Dongle 每次讀幾十 MB 很慢；USB 檔案系統也常不給執行權限）
  if [ "$plat" = darwin ]; then C="$HOME/Library/Caches/agentcenter-node/$plat-$arch"; else C="${XDG_CACHE_HOME:-$HOME/.cache}/agentcenter-node/$plat-$arch"; fi
  S1="$(wc -c < "$NODE" | tr -d ' ')"; S2="$( [ -f "$C/node" ] && wc -c < "$C/node" | tr -d ' ')"
  if [ "$S1" != "$S2" ]; then echo "把 Node.js 複製到這台電腦（只有第一次）..."; mkdir -p "$C" && cp "$NODE" "$C/node.tmp" && chmod +x "$C/node.tmp" && mv "$C/node.tmp" "$C/node"; fi
  if [ -x "$C/node" ]; then NODE="$C/node"
  elif [ ! -x "$NODE" ]; then T="${TMPDIR:-/tmp}/agent-node-$plat-$arch"; cp "$NODE" "$T" && chmod +x "$T" && NODE="$T"; fi
fi
if [ ! -f "$NODE" ]; then
  if command -v node >/dev/null 2>&1; then echo "改用這台電腦已安裝的 Node.js"; NODE="$(command -v node)"
  else echo "沒有 Node.js：請確認網路後重新執行，或到 https://nodejs.org 安裝 18 以上的版本"; exit 1; fi
fi
if [ "$plat" = darwin ]; then xattr -d com.apple.quarantine "$NODE" 2>/dev/null; fi
exec "$NODE" "$HERE/app/portable.js" "$@"
